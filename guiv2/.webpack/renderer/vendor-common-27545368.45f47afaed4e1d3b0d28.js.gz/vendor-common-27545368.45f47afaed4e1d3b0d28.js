"use strict";
(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[3258],{

/***/ 69982:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



if (false) // removed by dead control flow
{} else {
  module.exports = __webpack_require__(80213);
}


/***/ }),

/***/ 80213:
/***/ ((__unused_webpack_module, exports) => {

/**
 * @license React
 * scheduler.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {

          'use strict';

/* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart ===
    'function'
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
}
          var enableSchedulerDebugging = false;
var enableProfiling = false;
var frameYieldMs = 5;

function push(heap, node) {
  var index = heap.length;
  heap.push(node);
  siftUp(heap, node, index);
}
function peek(heap) {
  return heap.length === 0 ? null : heap[0];
}
function pop(heap) {
  if (heap.length === 0) {
    return null;
  }

  var first = heap[0];
  var last = heap.pop();

  if (last !== first) {
    heap[0] = last;
    siftDown(heap, last, 0);
  }

  return first;
}

function siftUp(heap, node, i) {
  var index = i;

  while (index > 0) {
    var parentIndex = index - 1 >>> 1;
    var parent = heap[parentIndex];

    if (compare(parent, node) > 0) {
      // The parent is larger. Swap positions.
      heap[parentIndex] = node;
      heap[index] = parent;
      index = parentIndex;
    } else {
      // The parent is smaller. Exit.
      return;
    }
  }
}

function siftDown(heap, node, i) {
  var index = i;
  var length = heap.length;
  var halfLength = length >>> 1;

  while (index < halfLength) {
    var leftIndex = (index + 1) * 2 - 1;
    var left = heap[leftIndex];
    var rightIndex = leftIndex + 1;
    var right = heap[rightIndex]; // If the left or right node is smaller, swap with the smaller of those.

    if (compare(left, node) < 0) {
      if (rightIndex < length && compare(right, left) < 0) {
        heap[index] = right;
        heap[rightIndex] = node;
        index = rightIndex;
      } else {
        heap[index] = left;
        heap[leftIndex] = node;
        index = leftIndex;
      }
    } else if (rightIndex < length && compare(right, node) < 0) {
      heap[index] = right;
      heap[rightIndex] = node;
      index = rightIndex;
    } else {
      // Neither child is smaller. Exit.
      return;
    }
  }
}

function compare(a, b) {
  // Compare sort index first, then task id.
  var diff = a.sortIndex - b.sortIndex;
  return diff !== 0 ? diff : a.id - b.id;
}

// TODO: Use symbols?
var ImmediatePriority = 1;
var UserBlockingPriority = 2;
var NormalPriority = 3;
var LowPriority = 4;
var IdlePriority = 5;

function markTaskErrored(task, ms) {
}

/* eslint-disable no-var */

var hasPerformanceNow = typeof performance === 'object' && typeof performance.now === 'function';

if (hasPerformanceNow) {
  var localPerformance = performance;

  exports.unstable_now = function () {
    return localPerformance.now();
  };
} else {
  var localDate = Date;
  var initialTime = localDate.now();

  exports.unstable_now = function () {
    return localDate.now() - initialTime;
  };
} // Max 31 bit integer. The max integer size in V8 for 32-bit systems.
// Math.pow(2, 30) - 1
// 0b111111111111111111111111111111


var maxSigned31BitInt = 1073741823; // Times out immediately

var IMMEDIATE_PRIORITY_TIMEOUT = -1; // Eventually times out

var USER_BLOCKING_PRIORITY_TIMEOUT = 250;
var NORMAL_PRIORITY_TIMEOUT = 5000;
var LOW_PRIORITY_TIMEOUT = 10000; // Never times out

var IDLE_PRIORITY_TIMEOUT = maxSigned31BitInt; // Tasks are stored on a min heap

var taskQueue = [];
var timerQueue = []; // Incrementing id counter. Used to maintain insertion order.

var taskIdCounter = 1; // Pausing the scheduler is useful for debugging.
var currentTask = null;
var currentPriorityLevel = NormalPriority; // This is set while performing work, to prevent re-entrance.

var isPerformingWork = false;
var isHostCallbackScheduled = false;
var isHostTimeoutScheduled = false; // Capture local references to native APIs, in case a polyfill overrides them.

var localSetTimeout = typeof setTimeout === 'function' ? setTimeout : null;
var localClearTimeout = typeof clearTimeout === 'function' ? clearTimeout : null;
var localSetImmediate = typeof setImmediate !== 'undefined' ? setImmediate : null; // IE and Node.js + jsdom

var isInputPending = typeof navigator !== 'undefined' && navigator.scheduling !== undefined && navigator.scheduling.isInputPending !== undefined ? navigator.scheduling.isInputPending.bind(navigator.scheduling) : null;

function advanceTimers(currentTime) {
  // Check for tasks that are no longer delayed and add them to the queue.
  var timer = peek(timerQueue);

  while (timer !== null) {
    if (timer.callback === null) {
      // Timer was cancelled.
      pop(timerQueue);
    } else if (timer.startTime <= currentTime) {
      // Timer fired. Transfer to the task queue.
      pop(timerQueue);
      timer.sortIndex = timer.expirationTime;
      push(taskQueue, timer);
    } else {
      // Remaining timers are pending.
      return;
    }

    timer = peek(timerQueue);
  }
}

function handleTimeout(currentTime) {
  isHostTimeoutScheduled = false;
  advanceTimers(currentTime);

  if (!isHostCallbackScheduled) {
    if (peek(taskQueue) !== null) {
      isHostCallbackScheduled = true;
      requestHostCallback(flushWork);
    } else {
      var firstTimer = peek(timerQueue);

      if (firstTimer !== null) {
        requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
      }
    }
  }
}

function flushWork(hasTimeRemaining, initialTime) {


  isHostCallbackScheduled = false;

  if (isHostTimeoutScheduled) {
    // We scheduled a timeout but it's no longer needed. Cancel it.
    isHostTimeoutScheduled = false;
    cancelHostTimeout();
  }

  isPerformingWork = true;
  var previousPriorityLevel = currentPriorityLevel;

  try {
    if (enableProfiling) {
      try {
        return workLoop(hasTimeRemaining, initialTime);
      } catch (error) {
        if (currentTask !== null) {
          var currentTime = exports.unstable_now();
          markTaskErrored(currentTask, currentTime);
          currentTask.isQueued = false;
        }

        throw error;
      }
    } else {
      // No catch in prod code path.
      return workLoop(hasTimeRemaining, initialTime);
    }
  } finally {
    currentTask = null;
    currentPriorityLevel = previousPriorityLevel;
    isPerformingWork = false;
  }
}

function workLoop(hasTimeRemaining, initialTime) {
  var currentTime = initialTime;
  advanceTimers(currentTime);
  currentTask = peek(taskQueue);

  while (currentTask !== null && !(enableSchedulerDebugging )) {
    if (currentTask.expirationTime > currentTime && (!hasTimeRemaining || shouldYieldToHost())) {
      // This currentTask hasn't expired, and we've reached the deadline.
      break;
    }

    var callback = currentTask.callback;

    if (typeof callback === 'function') {
      currentTask.callback = null;
      currentPriorityLevel = currentTask.priorityLevel;
      var didUserCallbackTimeout = currentTask.expirationTime <= currentTime;

      var continuationCallback = callback(didUserCallbackTimeout);
      currentTime = exports.unstable_now();

      if (typeof continuationCallback === 'function') {
        currentTask.callback = continuationCallback;
      } else {

        if (currentTask === peek(taskQueue)) {
          pop(taskQueue);
        }
      }

      advanceTimers(currentTime);
    } else {
      pop(taskQueue);
    }

    currentTask = peek(taskQueue);
  } // Return whether there's additional work


  if (currentTask !== null) {
    return true;
  } else {
    var firstTimer = peek(timerQueue);

    if (firstTimer !== null) {
      requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
    }

    return false;
  }
}

function unstable_runWithPriority(priorityLevel, eventHandler) {
  switch (priorityLevel) {
    case ImmediatePriority:
    case UserBlockingPriority:
    case NormalPriority:
    case LowPriority:
    case IdlePriority:
      break;

    default:
      priorityLevel = NormalPriority;
  }

  var previousPriorityLevel = currentPriorityLevel;
  currentPriorityLevel = priorityLevel;

  try {
    return eventHandler();
  } finally {
    currentPriorityLevel = previousPriorityLevel;
  }
}

function unstable_next(eventHandler) {
  var priorityLevel;

  switch (currentPriorityLevel) {
    case ImmediatePriority:
    case UserBlockingPriority:
    case NormalPriority:
      // Shift down to normal priority
      priorityLevel = NormalPriority;
      break;

    default:
      // Anything lower than normal priority should remain at the current level.
      priorityLevel = currentPriorityLevel;
      break;
  }

  var previousPriorityLevel = currentPriorityLevel;
  currentPriorityLevel = priorityLevel;

  try {
    return eventHandler();
  } finally {
    currentPriorityLevel = previousPriorityLevel;
  }
}

function unstable_wrapCallback(callback) {
  var parentPriorityLevel = currentPriorityLevel;
  return function () {
    // This is a fork of runWithPriority, inlined for performance.
    var previousPriorityLevel = currentPriorityLevel;
    currentPriorityLevel = parentPriorityLevel;

    try {
      return callback.apply(this, arguments);
    } finally {
      currentPriorityLevel = previousPriorityLevel;
    }
  };
}

function unstable_scheduleCallback(priorityLevel, callback, options) {
  var currentTime = exports.unstable_now();
  var startTime;

  if (typeof options === 'object' && options !== null) {
    var delay = options.delay;

    if (typeof delay === 'number' && delay > 0) {
      startTime = currentTime + delay;
    } else {
      startTime = currentTime;
    }
  } else {
    startTime = currentTime;
  }

  var timeout;

  switch (priorityLevel) {
    case ImmediatePriority:
      timeout = IMMEDIATE_PRIORITY_TIMEOUT;
      break;

    case UserBlockingPriority:
      timeout = USER_BLOCKING_PRIORITY_TIMEOUT;
      break;

    case IdlePriority:
      timeout = IDLE_PRIORITY_TIMEOUT;
      break;

    case LowPriority:
      timeout = LOW_PRIORITY_TIMEOUT;
      break;

    case NormalPriority:
    default:
      timeout = NORMAL_PRIORITY_TIMEOUT;
      break;
  }

  var expirationTime = startTime + timeout;
  var newTask = {
    id: taskIdCounter++,
    callback: callback,
    priorityLevel: priorityLevel,
    startTime: startTime,
    expirationTime: expirationTime,
    sortIndex: -1
  };

  if (startTime > currentTime) {
    // This is a delayed task.
    newTask.sortIndex = startTime;
    push(timerQueue, newTask);

    if (peek(taskQueue) === null && newTask === peek(timerQueue)) {
      // All tasks are delayed, and this is the task with the earliest delay.
      if (isHostTimeoutScheduled) {
        // Cancel an existing timeout.
        cancelHostTimeout();
      } else {
        isHostTimeoutScheduled = true;
      } // Schedule a timeout.


      requestHostTimeout(handleTimeout, startTime - currentTime);
    }
  } else {
    newTask.sortIndex = expirationTime;
    push(taskQueue, newTask);
    // wait until the next time we yield.


    if (!isHostCallbackScheduled && !isPerformingWork) {
      isHostCallbackScheduled = true;
      requestHostCallback(flushWork);
    }
  }

  return newTask;
}

function unstable_pauseExecution() {
}

function unstable_continueExecution() {

  if (!isHostCallbackScheduled && !isPerformingWork) {
    isHostCallbackScheduled = true;
    requestHostCallback(flushWork);
  }
}

function unstable_getFirstCallbackNode() {
  return peek(taskQueue);
}

function unstable_cancelCallback(task) {
  // remove from the queue because you can't remove arbitrary nodes from an
  // array based heap, only the first one.)


  task.callback = null;
}

function unstable_getCurrentPriorityLevel() {
  return currentPriorityLevel;
}

var isMessageLoopRunning = false;
var scheduledHostCallback = null;
var taskTimeoutID = -1; // Scheduler periodically yields in case there is other work on the main
// thread, like user events. By default, it yields multiple times per frame.
// It does not attempt to align with frame boundaries, since most tasks don't
// need to be frame aligned; for those that do, use requestAnimationFrame.

var frameInterval = frameYieldMs;
var startTime = -1;

function shouldYieldToHost() {
  var timeElapsed = exports.unstable_now() - startTime;

  if (timeElapsed < frameInterval) {
    // The main thread has only been blocked for a really short amount of time;
    // smaller than a single frame. Don't yield yet.
    return false;
  } // The main thread has been blocked for a non-negligible amount of time. We


  return true;
}

function requestPaint() {

}

function forceFrameRate(fps) {
  if (fps < 0 || fps > 125) {
    // Using console['error'] to evade Babel and ESLint
    console['error']('forceFrameRate takes a positive int between 0 and 125, ' + 'forcing frame rates higher than 125 fps is not supported');
    return;
  }

  if (fps > 0) {
    frameInterval = Math.floor(1000 / fps);
  } else {
    // reset the framerate
    frameInterval = frameYieldMs;
  }
}

var performWorkUntilDeadline = function () {
  if (scheduledHostCallback !== null) {
    var currentTime = exports.unstable_now(); // Keep track of the start time so we can measure how long the main thread
    // has been blocked.

    startTime = currentTime;
    var hasTimeRemaining = true; // If a scheduler task throws, exit the current browser task so the
    // error can be observed.
    //
    // Intentionally not using a try-catch, since that makes some debugging
    // techniques harder. Instead, if `scheduledHostCallback` errors, then
    // `hasMoreWork` will remain true, and we'll continue the work loop.

    var hasMoreWork = true;

    try {
      hasMoreWork = scheduledHostCallback(hasTimeRemaining, currentTime);
    } finally {
      if (hasMoreWork) {
        // If there's more work, schedule the next message event at the end
        // of the preceding one.
        schedulePerformWorkUntilDeadline();
      } else {
        isMessageLoopRunning = false;
        scheduledHostCallback = null;
      }
    }
  } else {
    isMessageLoopRunning = false;
  } // Yielding to the browser will give it a chance to paint, so we can
};

var schedulePerformWorkUntilDeadline;

if (typeof localSetImmediate === 'function') {
  // Node.js and old IE.
  // There's a few reasons for why we prefer setImmediate.
  //
  // Unlike MessageChannel, it doesn't prevent a Node.js process from exiting.
  // (Even though this is a DOM fork of the Scheduler, you could get here
  // with a mix of Node.js 15+, which has a MessageChannel, and jsdom.)
  // https://github.com/facebook/react/issues/20756
  //
  // But also, it runs earlier which is the semantic we want.
  // If other browsers ever implement it, it's better to use it.
  // Although both of these would be inferior to native scheduling.
  schedulePerformWorkUntilDeadline = function () {
    localSetImmediate(performWorkUntilDeadline);
  };
} else if (typeof MessageChannel !== 'undefined') {
  // DOM and Worker environments.
  // We prefer MessageChannel because of the 4ms setTimeout clamping.
  var channel = new MessageChannel();
  var port = channel.port2;
  channel.port1.onmessage = performWorkUntilDeadline;

  schedulePerformWorkUntilDeadline = function () {
    port.postMessage(null);
  };
} else {
  // We should only fallback here in non-browser environments.
  schedulePerformWorkUntilDeadline = function () {
    localSetTimeout(performWorkUntilDeadline, 0);
  };
}

function requestHostCallback(callback) {
  scheduledHostCallback = callback;

  if (!isMessageLoopRunning) {
    isMessageLoopRunning = true;
    schedulePerformWorkUntilDeadline();
  }
}

function requestHostTimeout(callback, ms) {
  taskTimeoutID = localSetTimeout(function () {
    callback(exports.unstable_now());
  }, ms);
}

function cancelHostTimeout() {
  localClearTimeout(taskTimeoutID);
  taskTimeoutID = -1;
}

var unstable_requestPaint = requestPaint;
var unstable_Profiling =  null;

exports.unstable_IdlePriority = IdlePriority;
exports.unstable_ImmediatePriority = ImmediatePriority;
exports.unstable_LowPriority = LowPriority;
exports.unstable_NormalPriority = NormalPriority;
exports.unstable_Profiling = unstable_Profiling;
exports.unstable_UserBlockingPriority = UserBlockingPriority;
exports.unstable_cancelCallback = unstable_cancelCallback;
exports.unstable_continueExecution = unstable_continueExecution;
exports.unstable_forceFrameRate = forceFrameRate;
exports.unstable_getCurrentPriorityLevel = unstable_getCurrentPriorityLevel;
exports.unstable_getFirstCallbackNode = unstable_getFirstCallbackNode;
exports.unstable_next = unstable_next;
exports.unstable_pauseExecution = unstable_pauseExecution;
exports.unstable_requestPaint = unstable_requestPaint;
exports.unstable_runWithPriority = unstable_runWithPriority;
exports.unstable_scheduleCallback = unstable_scheduleCallback;
exports.unstable_shouldYield = shouldYieldToHost;
exports.unstable_wrapCallback = unstable_wrapCallback;
          /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop ===
    'function'
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
}
        
  })();
}


/***/ }),

/***/ 95703:
/***/ (() => {


// UNUSED EXPORTS: incircle, incirclefast, insphere, inspherefast, orient2d, orient2dfast, orient3d, orient3dfast

;// ./node_modules/robust-predicates/esm/util.js
const epsilon = 1.1102230246251565e-16;
const util_splitter = 134217729;
const util_resulterrbound = (3 + 8 * epsilon) * epsilon;

// fast_expansion_sum_zeroelim routine from oritinal code
function util_sum(elen, e, flen, f, h) {
    let Q, Qnew, hh, bvirt;
    let enow = e[0];
    let fnow = f[0];
    let eindex = 0;
    let findex = 0;
    if ((fnow > enow) === (fnow > -enow)) {
        Q = enow;
        enow = e[++eindex];
    } else {
        Q = fnow;
        fnow = f[++findex];
    }
    let hindex = 0;
    if (eindex < elen && findex < flen) {
        if ((fnow > enow) === (fnow > -enow)) {
            Qnew = enow + Q;
            hh = Q - (Qnew - enow);
            enow = e[++eindex];
        } else {
            Qnew = fnow + Q;
            hh = Q - (Qnew - fnow);
            fnow = f[++findex];
        }
        Q = Qnew;
        if (hh !== 0) {
            h[hindex++] = hh;
        }
        while (eindex < elen && findex < flen) {
            if ((fnow > enow) === (fnow > -enow)) {
                Qnew = Q + enow;
                bvirt = Qnew - Q;
                hh = Q - (Qnew - bvirt) + (enow - bvirt);
                enow = e[++eindex];
            } else {
                Qnew = Q + fnow;
                bvirt = Qnew - Q;
                hh = Q - (Qnew - bvirt) + (fnow - bvirt);
                fnow = f[++findex];
            }
            Q = Qnew;
            if (hh !== 0) {
                h[hindex++] = hh;
            }
        }
    }
    while (eindex < elen) {
        Qnew = Q + enow;
        bvirt = Qnew - Q;
        hh = Q - (Qnew - bvirt) + (enow - bvirt);
        enow = e[++eindex];
        Q = Qnew;
        if (hh !== 0) {
            h[hindex++] = hh;
        }
    }
    while (findex < flen) {
        Qnew = Q + fnow;
        bvirt = Qnew - Q;
        hh = Q - (Qnew - bvirt) + (fnow - bvirt);
        fnow = f[++findex];
        Q = Qnew;
        if (hh !== 0) {
            h[hindex++] = hh;
        }
    }
    if (Q !== 0 || hindex === 0) {
        h[hindex++] = Q;
    }
    return hindex;
}

function util_sum_three(alen, a, blen, b, clen, c, tmp, out) {
    return util_sum(util_sum(alen, a, blen, b, tmp), tmp, clen, c, out);
}

// scale_expansion_zeroelim routine from oritinal code
function util_scale(elen, e, b, h) {
    let Q, sum, hh, product1, product0;
    let bvirt, c, ahi, alo, bhi, blo;

    c = util_splitter * b;
    bhi = c - (c - b);
    blo = b - bhi;
    let enow = e[0];
    Q = enow * b;
    c = util_splitter * enow;
    ahi = c - (c - enow);
    alo = enow - ahi;
    hh = alo * blo - (Q - ahi * bhi - alo * bhi - ahi * blo);
    let hindex = 0;
    if (hh !== 0) {
        h[hindex++] = hh;
    }
    for (let i = 1; i < elen; i++) {
        enow = e[i];
        product1 = enow * b;
        c = util_splitter * enow;
        ahi = c - (c - enow);
        alo = enow - ahi;
        product0 = alo * blo - (product1 - ahi * bhi - alo * bhi - ahi * blo);
        sum = Q + product0;
        bvirt = sum - Q;
        hh = Q - (sum - bvirt) + (product0 - bvirt);
        if (hh !== 0) {
            h[hindex++] = hh;
        }
        Q = product1 + sum;
        hh = sum - (Q - product1);
        if (hh !== 0) {
            h[hindex++] = hh;
        }
    }
    if (Q !== 0 || hindex === 0) {
        h[hindex++] = Q;
    }
    return hindex;
}

function util_negate(elen, e) {
    for (let i = 0; i < elen; i++) e[i] = -e[i];
    return elen;
}

function util_estimate(elen, e) {
    let Q = e[0];
    for (let i = 1; i < elen; i++) Q += e[i];
    return Q;
}

function vec(n) {
    return new Float64Array(n);
}

;// ./node_modules/robust-predicates/esm/orient2d.js


const ccwerrboundA = (3 + 16 * epsilon) * epsilon;
const ccwerrboundB = (2 + 12 * epsilon) * epsilon;
const ccwerrboundC = (9 + 64 * epsilon) * epsilon * epsilon;

const B = vec(4);
const C1 = vec(8);
const C2 = vec(12);
const D = vec(16);
const u = vec(4);

function orient2dadapt(ax, ay, bx, by, cx, cy, detsum) {
    let acxtail, acytail, bcxtail, bcytail;
    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _0, s1, s0, t1, t0, u3;

    const acx = ax - cx;
    const bcx = bx - cx;
    const acy = ay - cy;
    const bcy = by - cy;

    s1 = acx * bcy;
    c = splitter * acx;
    ahi = c - (c - acx);
    alo = acx - ahi;
    c = splitter * bcy;
    bhi = c - (c - bcy);
    blo = bcy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = acy * bcx;
    c = splitter * acy;
    ahi = c - (c - acy);
    alo = acy - ahi;
    c = splitter * bcx;
    bhi = c - (c - bcx);
    blo = bcx - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    B[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    B[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    B[2] = _j - (u3 - bvirt) + (_i - bvirt);
    B[3] = u3;

    let det = estimate(4, B);
    let errbound = ccwerrboundB * detsum;
    if (det >= errbound || -det >= errbound) {
        return det;
    }

    bvirt = ax - acx;
    acxtail = ax - (acx + bvirt) + (bvirt - cx);
    bvirt = bx - bcx;
    bcxtail = bx - (bcx + bvirt) + (bvirt - cx);
    bvirt = ay - acy;
    acytail = ay - (acy + bvirt) + (bvirt - cy);
    bvirt = by - bcy;
    bcytail = by - (bcy + bvirt) + (bvirt - cy);

    if (acxtail === 0 && acytail === 0 && bcxtail === 0 && bcytail === 0) {
        return det;
    }

    errbound = ccwerrboundC * detsum + resulterrbound * Math.abs(det);
    det += (acx * bcytail + bcy * acxtail) - (acy * bcxtail + bcx * acytail);
    if (det >= errbound || -det >= errbound) return det;

    s1 = acxtail * bcy;
    c = splitter * acxtail;
    ahi = c - (c - acxtail);
    alo = acxtail - ahi;
    c = splitter * bcy;
    bhi = c - (c - bcy);
    blo = bcy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = acytail * bcx;
    c = splitter * acytail;
    ahi = c - (c - acytail);
    alo = acytail - ahi;
    c = splitter * bcx;
    bhi = c - (c - bcx);
    blo = bcx - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    u[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    u[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    u[2] = _j - (u3 - bvirt) + (_i - bvirt);
    u[3] = u3;
    const C1len = sum(4, B, 4, u, C1);

    s1 = acx * bcytail;
    c = splitter * acx;
    ahi = c - (c - acx);
    alo = acx - ahi;
    c = splitter * bcytail;
    bhi = c - (c - bcytail);
    blo = bcytail - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = acy * bcxtail;
    c = splitter * acy;
    ahi = c - (c - acy);
    alo = acy - ahi;
    c = splitter * bcxtail;
    bhi = c - (c - bcxtail);
    blo = bcxtail - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    u[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    u[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    u[2] = _j - (u3 - bvirt) + (_i - bvirt);
    u[3] = u3;
    const C2len = sum(C1len, C1, 4, u, C2);

    s1 = acxtail * bcytail;
    c = splitter * acxtail;
    ahi = c - (c - acxtail);
    alo = acxtail - ahi;
    c = splitter * bcytail;
    bhi = c - (c - bcytail);
    blo = bcytail - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = acytail * bcxtail;
    c = splitter * acytail;
    ahi = c - (c - acytail);
    alo = acytail - ahi;
    c = splitter * bcxtail;
    bhi = c - (c - bcxtail);
    blo = bcxtail - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    u[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    u[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    u[2] = _j - (u3 - bvirt) + (_i - bvirt);
    u[3] = u3;
    const Dlen = sum(C2len, C2, 4, u, D);

    return D[Dlen - 1];
}

function orient2d(ax, ay, bx, by, cx, cy) {
    const detleft = (ay - cy) * (bx - cx);
    const detright = (ax - cx) * (by - cy);
    const det = detleft - detright;

    const detsum = Math.abs(detleft + detright);
    if (Math.abs(det) >= ccwerrboundA * detsum) return det;

    return -orient2dadapt(ax, ay, bx, by, cx, cy, detsum);
}

function orient2dfast(ax, ay, bx, by, cx, cy) {
    return (ay - cy) * (bx - cx) - (ax - cx) * (by - cy);
}

;// ./node_modules/robust-predicates/esm/orient3d.js


const o3derrboundA = (7 + 56 * epsilon) * epsilon;
const o3derrboundB = (3 + 28 * epsilon) * epsilon;
const o3derrboundC = (26 + 288 * epsilon) * epsilon * epsilon;

const bc = vec(4);
const ca = vec(4);
const ab = vec(4);
const at_b = vec(4);
const at_c = vec(4);
const bt_c = vec(4);
const bt_a = vec(4);
const ct_a = vec(4);
const ct_b = vec(4);
const bct = vec(8);
const cat = vec(8);
const abt = vec(8);
const orient3d_u = vec(4);

const _8 = vec(8);
const _8b = vec(8);
const _16 = vec(8);
const _12 = vec(12);

let fin = vec(192);
let fin2 = vec(192);

function finadd(finlen, alen, a) {
    finlen = sum(finlen, fin, alen, a, fin2);
    const tmp = fin; fin = fin2; fin2 = tmp;
    return finlen;
}

function tailinit(xtail, ytail, ax, ay, bx, by, a, b) {
    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _k, _0, s1, s0, t1, t0, u3, negate;
    if (xtail === 0) {
        if (ytail === 0) {
            a[0] = 0;
            b[0] = 0;
            return 1;
        } else {
            negate = -ytail;
            s1 = negate * ax;
            c = splitter * negate;
            ahi = c - (c - negate);
            alo = negate - ahi;
            c = splitter * ax;
            bhi = c - (c - ax);
            blo = ax - bhi;
            a[0] = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            a[1] = s1;
            s1 = ytail * bx;
            c = splitter * ytail;
            ahi = c - (c - ytail);
            alo = ytail - ahi;
            c = splitter * bx;
            bhi = c - (c - bx);
            blo = bx - bhi;
            b[0] = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            b[1] = s1;
            return 2;
        }
    } else {
        if (ytail === 0) {
            s1 = xtail * ay;
            c = splitter * xtail;
            ahi = c - (c - xtail);
            alo = xtail - ahi;
            c = splitter * ay;
            bhi = c - (c - ay);
            blo = ay - bhi;
            a[0] = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            a[1] = s1;
            negate = -xtail;
            s1 = negate * by;
            c = splitter * negate;
            ahi = c - (c - negate);
            alo = negate - ahi;
            c = splitter * by;
            bhi = c - (c - by);
            blo = by - bhi;
            b[0] = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            b[1] = s1;
            return 2;
        } else {
            s1 = xtail * ay;
            c = splitter * xtail;
            ahi = c - (c - xtail);
            alo = xtail - ahi;
            c = splitter * ay;
            bhi = c - (c - ay);
            blo = ay - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = ytail * ax;
            c = splitter * ytail;
            ahi = c - (c - ytail);
            alo = ytail - ahi;
            c = splitter * ax;
            bhi = c - (c - ax);
            blo = ax - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 - t0;
            bvirt = s0 - _i;
            a[0] = s0 - (_i + bvirt) + (bvirt - t0);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 - t1;
            bvirt = _0 - _i;
            a[1] = _0 - (_i + bvirt) + (bvirt - t1);
            u3 = _j + _i;
            bvirt = u3 - _j;
            a[2] = _j - (u3 - bvirt) + (_i - bvirt);
            a[3] = u3;
            s1 = ytail * bx;
            c = splitter * ytail;
            ahi = c - (c - ytail);
            alo = ytail - ahi;
            c = splitter * bx;
            bhi = c - (c - bx);
            blo = bx - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = xtail * by;
            c = splitter * xtail;
            ahi = c - (c - xtail);
            alo = xtail - ahi;
            c = splitter * by;
            bhi = c - (c - by);
            blo = by - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 - t0;
            bvirt = s0 - _i;
            b[0] = s0 - (_i + bvirt) + (bvirt - t0);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 - t1;
            bvirt = _0 - _i;
            b[1] = _0 - (_i + bvirt) + (bvirt - t1);
            u3 = _j + _i;
            bvirt = u3 - _j;
            b[2] = _j - (u3 - bvirt) + (_i - bvirt);
            b[3] = u3;
            return 4;
        }
    }
}

function tailadd(finlen, a, b, k, z) {
    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _k, _0, s1, s0, u3;
    s1 = a * b;
    c = splitter * a;
    ahi = c - (c - a);
    alo = a - ahi;
    c = splitter * b;
    bhi = c - (c - b);
    blo = b - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    c = splitter * k;
    bhi = c - (c - k);
    blo = k - bhi;
    _i = s0 * k;
    c = splitter * s0;
    ahi = c - (c - s0);
    alo = s0 - ahi;
    orient3d_u[0] = alo * blo - (_i - ahi * bhi - alo * bhi - ahi * blo);
    _j = s1 * k;
    c = splitter * s1;
    ahi = c - (c - s1);
    alo = s1 - ahi;
    _0 = alo * blo - (_j - ahi * bhi - alo * bhi - ahi * blo);
    _k = _i + _0;
    bvirt = _k - _i;
    orient3d_u[1] = _i - (_k - bvirt) + (_0 - bvirt);
    u3 = _j + _k;
    orient3d_u[2] = _k - (u3 - _j);
    orient3d_u[3] = u3;
    finlen = finadd(finlen, 4, orient3d_u);
    if (z !== 0) {
        c = splitter * z;
        bhi = c - (c - z);
        blo = z - bhi;
        _i = s0 * z;
        c = splitter * s0;
        ahi = c - (c - s0);
        alo = s0 - ahi;
        orient3d_u[0] = alo * blo - (_i - ahi * bhi - alo * bhi - ahi * blo);
        _j = s1 * z;
        c = splitter * s1;
        ahi = c - (c - s1);
        alo = s1 - ahi;
        _0 = alo * blo - (_j - ahi * bhi - alo * bhi - ahi * blo);
        _k = _i + _0;
        bvirt = _k - _i;
        orient3d_u[1] = _i - (_k - bvirt) + (_0 - bvirt);
        u3 = _j + _k;
        orient3d_u[2] = _k - (u3 - _j);
        orient3d_u[3] = u3;
        finlen = finadd(finlen, 4, orient3d_u);
    }
    return finlen;
}

function orient3dadapt(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, permanent) {
    let finlen;
    let adxtail, bdxtail, cdxtail;
    let adytail, bdytail, cdytail;
    let adztail, bdztail, cdztail;
    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _k, _0, s1, s0, t1, t0, u3;

    const adx = ax - dx;
    const bdx = bx - dx;
    const cdx = cx - dx;
    const ady = ay - dy;
    const bdy = by - dy;
    const cdy = cy - dy;
    const adz = az - dz;
    const bdz = bz - dz;
    const cdz = cz - dz;

    s1 = bdx * cdy;
    c = splitter * bdx;
    ahi = c - (c - bdx);
    alo = bdx - ahi;
    c = splitter * cdy;
    bhi = c - (c - cdy);
    blo = cdy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cdx * bdy;
    c = splitter * cdx;
    ahi = c - (c - cdx);
    alo = cdx - ahi;
    c = splitter * bdy;
    bhi = c - (c - bdy);
    blo = bdy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    bc[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    bc[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    bc[2] = _j - (u3 - bvirt) + (_i - bvirt);
    bc[3] = u3;
    s1 = cdx * ady;
    c = splitter * cdx;
    ahi = c - (c - cdx);
    alo = cdx - ahi;
    c = splitter * ady;
    bhi = c - (c - ady);
    blo = ady - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = adx * cdy;
    c = splitter * adx;
    ahi = c - (c - adx);
    alo = adx - ahi;
    c = splitter * cdy;
    bhi = c - (c - cdy);
    blo = cdy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ca[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ca[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    ca[2] = _j - (u3 - bvirt) + (_i - bvirt);
    ca[3] = u3;
    s1 = adx * bdy;
    c = splitter * adx;
    ahi = c - (c - adx);
    alo = adx - ahi;
    c = splitter * bdy;
    bhi = c - (c - bdy);
    blo = bdy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = bdx * ady;
    c = splitter * bdx;
    ahi = c - (c - bdx);
    alo = bdx - ahi;
    c = splitter * ady;
    bhi = c - (c - ady);
    blo = ady - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ab[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ab[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    ab[2] = _j - (u3 - bvirt) + (_i - bvirt);
    ab[3] = u3;

    finlen = sum(
        sum(
            scale(4, bc, adz, _8), _8,
            scale(4, ca, bdz, _8b), _8b, _16), _16,
        scale(4, ab, cdz, _8), _8, fin);

    let det = estimate(finlen, fin);
    let errbound = o3derrboundB * permanent;
    if (det >= errbound || -det >= errbound) {
        return det;
    }

    bvirt = ax - adx;
    adxtail = ax - (adx + bvirt) + (bvirt - dx);
    bvirt = bx - bdx;
    bdxtail = bx - (bdx + bvirt) + (bvirt - dx);
    bvirt = cx - cdx;
    cdxtail = cx - (cdx + bvirt) + (bvirt - dx);
    bvirt = ay - ady;
    adytail = ay - (ady + bvirt) + (bvirt - dy);
    bvirt = by - bdy;
    bdytail = by - (bdy + bvirt) + (bvirt - dy);
    bvirt = cy - cdy;
    cdytail = cy - (cdy + bvirt) + (bvirt - dy);
    bvirt = az - adz;
    adztail = az - (adz + bvirt) + (bvirt - dz);
    bvirt = bz - bdz;
    bdztail = bz - (bdz + bvirt) + (bvirt - dz);
    bvirt = cz - cdz;
    cdztail = cz - (cdz + bvirt) + (bvirt - dz);

    if (adxtail === 0 && bdxtail === 0 && cdxtail === 0 &&
        adytail === 0 && bdytail === 0 && cdytail === 0 &&
        adztail === 0 && bdztail === 0 && cdztail === 0) {
        return det;
    }

    errbound = o3derrboundC * permanent + resulterrbound * Math.abs(det);
    det +=
        adz * (bdx * cdytail + cdy * bdxtail - (bdy * cdxtail + cdx * bdytail)) + adztail * (bdx * cdy - bdy * cdx) +
        bdz * (cdx * adytail + ady * cdxtail - (cdy * adxtail + adx * cdytail)) + bdztail * (cdx * ady - cdy * adx) +
        cdz * (adx * bdytail + bdy * adxtail - (ady * bdxtail + bdx * adytail)) + cdztail * (adx * bdy - ady * bdx);
    if (det >= errbound || -det >= errbound) {
        return det;
    }

    const at_len = tailinit(adxtail, adytail, bdx, bdy, cdx, cdy, at_b, at_c);
    const bt_len = tailinit(bdxtail, bdytail, cdx, cdy, adx, ady, bt_c, bt_a);
    const ct_len = tailinit(cdxtail, cdytail, adx, ady, bdx, bdy, ct_a, ct_b);

    const bctlen = sum(bt_len, bt_c, ct_len, ct_b, bct);
    finlen = finadd(finlen, scale(bctlen, bct, adz, _16), _16);

    const catlen = sum(ct_len, ct_a, at_len, at_c, cat);
    finlen = finadd(finlen, scale(catlen, cat, bdz, _16), _16);

    const abtlen = sum(at_len, at_b, bt_len, bt_a, abt);
    finlen = finadd(finlen, scale(abtlen, abt, cdz, _16), _16);

    if (adztail !== 0) {
        finlen = finadd(finlen, scale(4, bc, adztail, _12), _12);
        finlen = finadd(finlen, scale(bctlen, bct, adztail, _16), _16);
    }
    if (bdztail !== 0) {
        finlen = finadd(finlen, scale(4, ca, bdztail, _12), _12);
        finlen = finadd(finlen, scale(catlen, cat, bdztail, _16), _16);
    }
    if (cdztail !== 0) {
        finlen = finadd(finlen, scale(4, ab, cdztail, _12), _12);
        finlen = finadd(finlen, scale(abtlen, abt, cdztail, _16), _16);
    }

    if (adxtail !== 0) {
        if (bdytail !== 0) {
            finlen = tailadd(finlen, adxtail, bdytail, cdz, cdztail);
        }
        if (cdytail !== 0) {
            finlen = tailadd(finlen, -adxtail, cdytail, bdz, bdztail);
        }
    }
    if (bdxtail !== 0) {
        if (cdytail !== 0) {
            finlen = tailadd(finlen, bdxtail, cdytail, adz, adztail);
        }
        if (adytail !== 0) {
            finlen = tailadd(finlen, -bdxtail, adytail, cdz, cdztail);
        }
    }
    if (cdxtail !== 0) {
        if (adytail !== 0) {
            finlen = tailadd(finlen, cdxtail, adytail, bdz, bdztail);
        }
        if (bdytail !== 0) {
            finlen = tailadd(finlen, -cdxtail, bdytail, adz, adztail);
        }
    }

    return fin[finlen - 1];
}

function orient3d(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz) {
    const adx = ax - dx;
    const bdx = bx - dx;
    const cdx = cx - dx;
    const ady = ay - dy;
    const bdy = by - dy;
    const cdy = cy - dy;
    const adz = az - dz;
    const bdz = bz - dz;
    const cdz = cz - dz;

    const bdxcdy = bdx * cdy;
    const cdxbdy = cdx * bdy;

    const cdxady = cdx * ady;
    const adxcdy = adx * cdy;

    const adxbdy = adx * bdy;
    const bdxady = bdx * ady;

    const det =
        adz * (bdxcdy - cdxbdy) +
        bdz * (cdxady - adxcdy) +
        cdz * (adxbdy - bdxady);

    const permanent =
        (Math.abs(bdxcdy) + Math.abs(cdxbdy)) * Math.abs(adz) +
        (Math.abs(cdxady) + Math.abs(adxcdy)) * Math.abs(bdz) +
        (Math.abs(adxbdy) + Math.abs(bdxady)) * Math.abs(cdz);

    const errbound = o3derrboundA * permanent;
    if (det > errbound || -det > errbound) {
        return det;
    }

    return orient3dadapt(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, permanent);
}

function orient3dfast(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz) {
    const adx = ax - dx;
    const bdx = bx - dx;
    const cdx = cx - dx;
    const ady = ay - dy;
    const bdy = by - dy;
    const cdy = cy - dy;
    const adz = az - dz;
    const bdz = bz - dz;
    const cdz = cz - dz;

    return adx * (bdy * cdz - bdz * cdy) +
        bdx * (cdy * adz - cdz * ady) +
        cdx * (ady * bdz - adz * bdy);
}

;// ./node_modules/robust-predicates/esm/incircle.js


const iccerrboundA = (10 + 96 * epsilon) * epsilon;
const iccerrboundB = (4 + 48 * epsilon) * epsilon;
const iccerrboundC = (44 + 576 * epsilon) * epsilon * epsilon;

const incircle_bc = vec(4);
const incircle_ca = vec(4);
const incircle_ab = vec(4);
const aa = vec(4);
const bb = vec(4);
const cc = vec(4);
const incircle_u = vec(4);
const v = vec(4);
const axtbc = vec(8);
const aytbc = vec(8);
const bxtca = vec(8);
const bytca = vec(8);
const cxtab = vec(8);
const cytab = vec(8);
const incircle_abt = vec(8);
const incircle_bct = vec(8);
const incircle_cat = vec(8);
const abtt = vec(4);
const bctt = vec(4);
const catt = vec(4);

const incircle_8 = vec(8);
const incircle_16 = vec(16);
const _16b = vec(16);
const _16c = vec(16);
const _32 = vec(32);
const _32b = vec(32);
const _48 = vec(48);
const _64 = vec(64);

let incircle_fin = vec(1152);
let incircle_fin2 = vec(1152);

function incircle_finadd(finlen, a, alen) {
    finlen = sum(finlen, incircle_fin, a, alen, incircle_fin2);
    const tmp = incircle_fin; incircle_fin = incircle_fin2; incircle_fin2 = tmp;
    return finlen;
}

function incircleadapt(ax, ay, bx, by, cx, cy, dx, dy, permanent) {
    let finlen;
    let adxtail, bdxtail, cdxtail, adytail, bdytail, cdytail;
    let axtbclen, aytbclen, bxtcalen, bytcalen, cxtablen, cytablen;
    let abtlen, bctlen, catlen;
    let abttlen, bcttlen, cattlen;
    let n1, n0;

    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _0, s1, s0, t1, t0, u3;

    const adx = ax - dx;
    const bdx = bx - dx;
    const cdx = cx - dx;
    const ady = ay - dy;
    const bdy = by - dy;
    const cdy = cy - dy;

    s1 = bdx * cdy;
    c = splitter * bdx;
    ahi = c - (c - bdx);
    alo = bdx - ahi;
    c = splitter * cdy;
    bhi = c - (c - cdy);
    blo = cdy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cdx * bdy;
    c = splitter * cdx;
    ahi = c - (c - cdx);
    alo = cdx - ahi;
    c = splitter * bdy;
    bhi = c - (c - bdy);
    blo = bdy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    incircle_bc[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    incircle_bc[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    incircle_bc[2] = _j - (u3 - bvirt) + (_i - bvirt);
    incircle_bc[3] = u3;
    s1 = cdx * ady;
    c = splitter * cdx;
    ahi = c - (c - cdx);
    alo = cdx - ahi;
    c = splitter * ady;
    bhi = c - (c - ady);
    blo = ady - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = adx * cdy;
    c = splitter * adx;
    ahi = c - (c - adx);
    alo = adx - ahi;
    c = splitter * cdy;
    bhi = c - (c - cdy);
    blo = cdy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    incircle_ca[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    incircle_ca[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    incircle_ca[2] = _j - (u3 - bvirt) + (_i - bvirt);
    incircle_ca[3] = u3;
    s1 = adx * bdy;
    c = splitter * adx;
    ahi = c - (c - adx);
    alo = adx - ahi;
    c = splitter * bdy;
    bhi = c - (c - bdy);
    blo = bdy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = bdx * ady;
    c = splitter * bdx;
    ahi = c - (c - bdx);
    alo = bdx - ahi;
    c = splitter * ady;
    bhi = c - (c - ady);
    blo = ady - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    incircle_ab[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    incircle_ab[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    incircle_ab[2] = _j - (u3 - bvirt) + (_i - bvirt);
    incircle_ab[3] = u3;

    finlen = sum(
        sum(
            sum(
                scale(scale(4, incircle_bc, adx, incircle_8), incircle_8, adx, incircle_16), incircle_16,
                scale(scale(4, incircle_bc, ady, incircle_8), incircle_8, ady, _16b), _16b, _32), _32,
            sum(
                scale(scale(4, incircle_ca, bdx, incircle_8), incircle_8, bdx, incircle_16), incircle_16,
                scale(scale(4, incircle_ca, bdy, incircle_8), incircle_8, bdy, _16b), _16b, _32b), _32b, _64), _64,
        sum(
            scale(scale(4, incircle_ab, cdx, incircle_8), incircle_8, cdx, incircle_16), incircle_16,
            scale(scale(4, incircle_ab, cdy, incircle_8), incircle_8, cdy, _16b), _16b, _32), _32, incircle_fin);

    let det = estimate(finlen, incircle_fin);
    let errbound = iccerrboundB * permanent;
    if (det >= errbound || -det >= errbound) {
        return det;
    }

    bvirt = ax - adx;
    adxtail = ax - (adx + bvirt) + (bvirt - dx);
    bvirt = ay - ady;
    adytail = ay - (ady + bvirt) + (bvirt - dy);
    bvirt = bx - bdx;
    bdxtail = bx - (bdx + bvirt) + (bvirt - dx);
    bvirt = by - bdy;
    bdytail = by - (bdy + bvirt) + (bvirt - dy);
    bvirt = cx - cdx;
    cdxtail = cx - (cdx + bvirt) + (bvirt - dx);
    bvirt = cy - cdy;
    cdytail = cy - (cdy + bvirt) + (bvirt - dy);
    if (adxtail === 0 && bdxtail === 0 && cdxtail === 0 && adytail === 0 && bdytail === 0 && cdytail === 0) {
        return det;
    }

    errbound = iccerrboundC * permanent + resulterrbound * Math.abs(det);
    det += ((adx * adx + ady * ady) * ((bdx * cdytail + cdy * bdxtail) - (bdy * cdxtail + cdx * bdytail)) +
        2 * (adx * adxtail + ady * adytail) * (bdx * cdy - bdy * cdx)) +
        ((bdx * bdx + bdy * bdy) * ((cdx * adytail + ady * cdxtail) - (cdy * adxtail + adx * cdytail)) +
        2 * (bdx * bdxtail + bdy * bdytail) * (cdx * ady - cdy * adx)) +
        ((cdx * cdx + cdy * cdy) * ((adx * bdytail + bdy * adxtail) - (ady * bdxtail + bdx * adytail)) +
        2 * (cdx * cdxtail + cdy * cdytail) * (adx * bdy - ady * bdx));

    if (det >= errbound || -det >= errbound) {
        return det;
    }

    if (bdxtail !== 0 || bdytail !== 0 || cdxtail !== 0 || cdytail !== 0) {
        s1 = adx * adx;
        c = splitter * adx;
        ahi = c - (c - adx);
        alo = adx - ahi;
        s0 = alo * alo - (s1 - ahi * ahi - (ahi + ahi) * alo);
        t1 = ady * ady;
        c = splitter * ady;
        ahi = c - (c - ady);
        alo = ady - ahi;
        t0 = alo * alo - (t1 - ahi * ahi - (ahi + ahi) * alo);
        _i = s0 + t0;
        bvirt = _i - s0;
        aa[0] = s0 - (_i - bvirt) + (t0 - bvirt);
        _j = s1 + _i;
        bvirt = _j - s1;
        _0 = s1 - (_j - bvirt) + (_i - bvirt);
        _i = _0 + t1;
        bvirt = _i - _0;
        aa[1] = _0 - (_i - bvirt) + (t1 - bvirt);
        u3 = _j + _i;
        bvirt = u3 - _j;
        aa[2] = _j - (u3 - bvirt) + (_i - bvirt);
        aa[3] = u3;
    }
    if (cdxtail !== 0 || cdytail !== 0 || adxtail !== 0 || adytail !== 0) {
        s1 = bdx * bdx;
        c = splitter * bdx;
        ahi = c - (c - bdx);
        alo = bdx - ahi;
        s0 = alo * alo - (s1 - ahi * ahi - (ahi + ahi) * alo);
        t1 = bdy * bdy;
        c = splitter * bdy;
        ahi = c - (c - bdy);
        alo = bdy - ahi;
        t0 = alo * alo - (t1 - ahi * ahi - (ahi + ahi) * alo);
        _i = s0 + t0;
        bvirt = _i - s0;
        bb[0] = s0 - (_i - bvirt) + (t0 - bvirt);
        _j = s1 + _i;
        bvirt = _j - s1;
        _0 = s1 - (_j - bvirt) + (_i - bvirt);
        _i = _0 + t1;
        bvirt = _i - _0;
        bb[1] = _0 - (_i - bvirt) + (t1 - bvirt);
        u3 = _j + _i;
        bvirt = u3 - _j;
        bb[2] = _j - (u3 - bvirt) + (_i - bvirt);
        bb[3] = u3;
    }
    if (adxtail !== 0 || adytail !== 0 || bdxtail !== 0 || bdytail !== 0) {
        s1 = cdx * cdx;
        c = splitter * cdx;
        ahi = c - (c - cdx);
        alo = cdx - ahi;
        s0 = alo * alo - (s1 - ahi * ahi - (ahi + ahi) * alo);
        t1 = cdy * cdy;
        c = splitter * cdy;
        ahi = c - (c - cdy);
        alo = cdy - ahi;
        t0 = alo * alo - (t1 - ahi * ahi - (ahi + ahi) * alo);
        _i = s0 + t0;
        bvirt = _i - s0;
        cc[0] = s0 - (_i - bvirt) + (t0 - bvirt);
        _j = s1 + _i;
        bvirt = _j - s1;
        _0 = s1 - (_j - bvirt) + (_i - bvirt);
        _i = _0 + t1;
        bvirt = _i - _0;
        cc[1] = _0 - (_i - bvirt) + (t1 - bvirt);
        u3 = _j + _i;
        bvirt = u3 - _j;
        cc[2] = _j - (u3 - bvirt) + (_i - bvirt);
        cc[3] = u3;
    }

    if (adxtail !== 0) {
        axtbclen = scale(4, incircle_bc, adxtail, axtbc);
        finlen = incircle_finadd(finlen, sum_three(
            scale(axtbclen, axtbc, 2 * adx, incircle_16), incircle_16,
            scale(scale(4, cc, adxtail, incircle_8), incircle_8, bdy, _16b), _16b,
            scale(scale(4, bb, adxtail, incircle_8), incircle_8, -cdy, _16c), _16c, _32, _48), _48);
    }
    if (adytail !== 0) {
        aytbclen = scale(4, incircle_bc, adytail, aytbc);
        finlen = incircle_finadd(finlen, sum_three(
            scale(aytbclen, aytbc, 2 * ady, incircle_16), incircle_16,
            scale(scale(4, bb, adytail, incircle_8), incircle_8, cdx, _16b), _16b,
            scale(scale(4, cc, adytail, incircle_8), incircle_8, -bdx, _16c), _16c, _32, _48), _48);
    }
    if (bdxtail !== 0) {
        bxtcalen = scale(4, incircle_ca, bdxtail, bxtca);
        finlen = incircle_finadd(finlen, sum_three(
            scale(bxtcalen, bxtca, 2 * bdx, incircle_16), incircle_16,
            scale(scale(4, aa, bdxtail, incircle_8), incircle_8, cdy, _16b), _16b,
            scale(scale(4, cc, bdxtail, incircle_8), incircle_8, -ady, _16c), _16c, _32, _48), _48);
    }
    if (bdytail !== 0) {
        bytcalen = scale(4, incircle_ca, bdytail, bytca);
        finlen = incircle_finadd(finlen, sum_three(
            scale(bytcalen, bytca, 2 * bdy, incircle_16), incircle_16,
            scale(scale(4, cc, bdytail, incircle_8), incircle_8, adx, _16b), _16b,
            scale(scale(4, aa, bdytail, incircle_8), incircle_8, -cdx, _16c), _16c, _32, _48), _48);
    }
    if (cdxtail !== 0) {
        cxtablen = scale(4, incircle_ab, cdxtail, cxtab);
        finlen = incircle_finadd(finlen, sum_three(
            scale(cxtablen, cxtab, 2 * cdx, incircle_16), incircle_16,
            scale(scale(4, bb, cdxtail, incircle_8), incircle_8, ady, _16b), _16b,
            scale(scale(4, aa, cdxtail, incircle_8), incircle_8, -bdy, _16c), _16c, _32, _48), _48);
    }
    if (cdytail !== 0) {
        cytablen = scale(4, incircle_ab, cdytail, cytab);
        finlen = incircle_finadd(finlen, sum_three(
            scale(cytablen, cytab, 2 * cdy, incircle_16), incircle_16,
            scale(scale(4, aa, cdytail, incircle_8), incircle_8, bdx, _16b), _16b,
            scale(scale(4, bb, cdytail, incircle_8), incircle_8, -adx, _16c), _16c, _32, _48), _48);
    }

    if (adxtail !== 0 || adytail !== 0) {
        if (bdxtail !== 0 || bdytail !== 0 || cdxtail !== 0 || cdytail !== 0) {
            s1 = bdxtail * cdy;
            c = splitter * bdxtail;
            ahi = c - (c - bdxtail);
            alo = bdxtail - ahi;
            c = splitter * cdy;
            bhi = c - (c - cdy);
            blo = cdy - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = bdx * cdytail;
            c = splitter * bdx;
            ahi = c - (c - bdx);
            alo = bdx - ahi;
            c = splitter * cdytail;
            bhi = c - (c - cdytail);
            blo = cdytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            incircle_u[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            incircle_u[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            incircle_u[2] = _j - (u3 - bvirt) + (_i - bvirt);
            incircle_u[3] = u3;
            s1 = cdxtail * -bdy;
            c = splitter * cdxtail;
            ahi = c - (c - cdxtail);
            alo = cdxtail - ahi;
            c = splitter * -bdy;
            bhi = c - (c - -bdy);
            blo = -bdy - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = cdx * -bdytail;
            c = splitter * cdx;
            ahi = c - (c - cdx);
            alo = cdx - ahi;
            c = splitter * -bdytail;
            bhi = c - (c - -bdytail);
            blo = -bdytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            v[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            v[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            v[2] = _j - (u3 - bvirt) + (_i - bvirt);
            v[3] = u3;
            bctlen = sum(4, incircle_u, 4, v, incircle_bct);
            s1 = bdxtail * cdytail;
            c = splitter * bdxtail;
            ahi = c - (c - bdxtail);
            alo = bdxtail - ahi;
            c = splitter * cdytail;
            bhi = c - (c - cdytail);
            blo = cdytail - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = cdxtail * bdytail;
            c = splitter * cdxtail;
            ahi = c - (c - cdxtail);
            alo = cdxtail - ahi;
            c = splitter * bdytail;
            bhi = c - (c - bdytail);
            blo = bdytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 - t0;
            bvirt = s0 - _i;
            bctt[0] = s0 - (_i + bvirt) + (bvirt - t0);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 - t1;
            bvirt = _0 - _i;
            bctt[1] = _0 - (_i + bvirt) + (bvirt - t1);
            u3 = _j + _i;
            bvirt = u3 - _j;
            bctt[2] = _j - (u3 - bvirt) + (_i - bvirt);
            bctt[3] = u3;
            bcttlen = 4;
        } else {
            incircle_bct[0] = 0;
            bctlen = 1;
            bctt[0] = 0;
            bcttlen = 1;
        }
        if (adxtail !== 0) {
            const len = scale(bctlen, incircle_bct, adxtail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(axtbclen, axtbc, adxtail, incircle_16), incircle_16,
                scale(len, _16c, 2 * adx, _32), _32, _48), _48);

            const len2 = scale(bcttlen, bctt, adxtail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * adx, incircle_16), incircle_16,
                scale(len2, incircle_8, adxtail, _16b), _16b,
                scale(len, _16c, adxtail, _32), _32, _32b, _64), _64);

            if (bdytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, cc, adxtail, incircle_8), incircle_8, bdytail, incircle_16), incircle_16);
            }
            if (cdytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, bb, -adxtail, incircle_8), incircle_8, cdytail, incircle_16), incircle_16);
            }
        }
        if (adytail !== 0) {
            const len = scale(bctlen, incircle_bct, adytail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(aytbclen, aytbc, adytail, incircle_16), incircle_16,
                scale(len, _16c, 2 * ady, _32), _32, _48), _48);

            const len2 = scale(bcttlen, bctt, adytail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * ady, incircle_16), incircle_16,
                scale(len2, incircle_8, adytail, _16b), _16b,
                scale(len, _16c, adytail, _32), _32, _32b, _64), _64);
        }
    }
    if (bdxtail !== 0 || bdytail !== 0) {
        if (cdxtail !== 0 || cdytail !== 0 || adxtail !== 0 || adytail !== 0) {
            s1 = cdxtail * ady;
            c = splitter * cdxtail;
            ahi = c - (c - cdxtail);
            alo = cdxtail - ahi;
            c = splitter * ady;
            bhi = c - (c - ady);
            blo = ady - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = cdx * adytail;
            c = splitter * cdx;
            ahi = c - (c - cdx);
            alo = cdx - ahi;
            c = splitter * adytail;
            bhi = c - (c - adytail);
            blo = adytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            incircle_u[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            incircle_u[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            incircle_u[2] = _j - (u3 - bvirt) + (_i - bvirt);
            incircle_u[3] = u3;
            n1 = -cdy;
            n0 = -cdytail;
            s1 = adxtail * n1;
            c = splitter * adxtail;
            ahi = c - (c - adxtail);
            alo = adxtail - ahi;
            c = splitter * n1;
            bhi = c - (c - n1);
            blo = n1 - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = adx * n0;
            c = splitter * adx;
            ahi = c - (c - adx);
            alo = adx - ahi;
            c = splitter * n0;
            bhi = c - (c - n0);
            blo = n0 - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            v[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            v[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            v[2] = _j - (u3 - bvirt) + (_i - bvirt);
            v[3] = u3;
            catlen = sum(4, incircle_u, 4, v, incircle_cat);
            s1 = cdxtail * adytail;
            c = splitter * cdxtail;
            ahi = c - (c - cdxtail);
            alo = cdxtail - ahi;
            c = splitter * adytail;
            bhi = c - (c - adytail);
            blo = adytail - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = adxtail * cdytail;
            c = splitter * adxtail;
            ahi = c - (c - adxtail);
            alo = adxtail - ahi;
            c = splitter * cdytail;
            bhi = c - (c - cdytail);
            blo = cdytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 - t0;
            bvirt = s0 - _i;
            catt[0] = s0 - (_i + bvirt) + (bvirt - t0);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 - t1;
            bvirt = _0 - _i;
            catt[1] = _0 - (_i + bvirt) + (bvirt - t1);
            u3 = _j + _i;
            bvirt = u3 - _j;
            catt[2] = _j - (u3 - bvirt) + (_i - bvirt);
            catt[3] = u3;
            cattlen = 4;
        } else {
            incircle_cat[0] = 0;
            catlen = 1;
            catt[0] = 0;
            cattlen = 1;
        }
        if (bdxtail !== 0) {
            const len = scale(catlen, incircle_cat, bdxtail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(bxtcalen, bxtca, bdxtail, incircle_16), incircle_16,
                scale(len, _16c, 2 * bdx, _32), _32, _48), _48);

            const len2 = scale(cattlen, catt, bdxtail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * bdx, incircle_16), incircle_16,
                scale(len2, incircle_8, bdxtail, _16b), _16b,
                scale(len, _16c, bdxtail, _32), _32, _32b, _64), _64);

            if (cdytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, aa, bdxtail, incircle_8), incircle_8, cdytail, incircle_16), incircle_16);
            }
            if (adytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, cc, -bdxtail, incircle_8), incircle_8, adytail, incircle_16), incircle_16);
            }
        }
        if (bdytail !== 0) {
            const len = scale(catlen, incircle_cat, bdytail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(bytcalen, bytca, bdytail, incircle_16), incircle_16,
                scale(len, _16c, 2 * bdy, _32), _32, _48), _48);

            const len2 = scale(cattlen, catt, bdytail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * bdy, incircle_16), incircle_16,
                scale(len2, incircle_8, bdytail, _16b), _16b,
                scale(len, _16c, bdytail, _32), _32,  _32b, _64), _64);
        }
    }
    if (cdxtail !== 0 || cdytail !== 0) {
        if (adxtail !== 0 || adytail !== 0 || bdxtail !== 0 || bdytail !== 0) {
            s1 = adxtail * bdy;
            c = splitter * adxtail;
            ahi = c - (c - adxtail);
            alo = adxtail - ahi;
            c = splitter * bdy;
            bhi = c - (c - bdy);
            blo = bdy - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = adx * bdytail;
            c = splitter * adx;
            ahi = c - (c - adx);
            alo = adx - ahi;
            c = splitter * bdytail;
            bhi = c - (c - bdytail);
            blo = bdytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            incircle_u[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            incircle_u[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            incircle_u[2] = _j - (u3 - bvirt) + (_i - bvirt);
            incircle_u[3] = u3;
            n1 = -ady;
            n0 = -adytail;
            s1 = bdxtail * n1;
            c = splitter * bdxtail;
            ahi = c - (c - bdxtail);
            alo = bdxtail - ahi;
            c = splitter * n1;
            bhi = c - (c - n1);
            blo = n1 - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = bdx * n0;
            c = splitter * bdx;
            ahi = c - (c - bdx);
            alo = bdx - ahi;
            c = splitter * n0;
            bhi = c - (c - n0);
            blo = n0 - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 + t0;
            bvirt = _i - s0;
            v[0] = s0 - (_i - bvirt) + (t0 - bvirt);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 + t1;
            bvirt = _i - _0;
            v[1] = _0 - (_i - bvirt) + (t1 - bvirt);
            u3 = _j + _i;
            bvirt = u3 - _j;
            v[2] = _j - (u3 - bvirt) + (_i - bvirt);
            v[3] = u3;
            abtlen = sum(4, incircle_u, 4, v, incircle_abt);
            s1 = adxtail * bdytail;
            c = splitter * adxtail;
            ahi = c - (c - adxtail);
            alo = adxtail - ahi;
            c = splitter * bdytail;
            bhi = c - (c - bdytail);
            blo = bdytail - bhi;
            s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
            t1 = bdxtail * adytail;
            c = splitter * bdxtail;
            ahi = c - (c - bdxtail);
            alo = bdxtail - ahi;
            c = splitter * adytail;
            bhi = c - (c - adytail);
            blo = adytail - bhi;
            t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
            _i = s0 - t0;
            bvirt = s0 - _i;
            abtt[0] = s0 - (_i + bvirt) + (bvirt - t0);
            _j = s1 + _i;
            bvirt = _j - s1;
            _0 = s1 - (_j - bvirt) + (_i - bvirt);
            _i = _0 - t1;
            bvirt = _0 - _i;
            abtt[1] = _0 - (_i + bvirt) + (bvirt - t1);
            u3 = _j + _i;
            bvirt = u3 - _j;
            abtt[2] = _j - (u3 - bvirt) + (_i - bvirt);
            abtt[3] = u3;
            abttlen = 4;
        } else {
            incircle_abt[0] = 0;
            abtlen = 1;
            abtt[0] = 0;
            abttlen = 1;
        }
        if (cdxtail !== 0) {
            const len = scale(abtlen, incircle_abt, cdxtail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(cxtablen, cxtab, cdxtail, incircle_16), incircle_16,
                scale(len, _16c, 2 * cdx, _32), _32, _48), _48);

            const len2 = scale(abttlen, abtt, cdxtail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * cdx, incircle_16), incircle_16,
                scale(len2, incircle_8, cdxtail, _16b), _16b,
                scale(len, _16c, cdxtail, _32), _32, _32b, _64), _64);

            if (adytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, bb, cdxtail, incircle_8), incircle_8, adytail, incircle_16), incircle_16);
            }
            if (bdytail !== 0) {
                finlen = incircle_finadd(finlen, scale(scale(4, aa, -cdxtail, incircle_8), incircle_8, bdytail, incircle_16), incircle_16);
            }
        }
        if (cdytail !== 0) {
            const len = scale(abtlen, incircle_abt, cdytail, _16c);
            finlen = incircle_finadd(finlen, sum(
                scale(cytablen, cytab, cdytail, incircle_16), incircle_16,
                scale(len, _16c, 2 * cdy, _32), _32, _48), _48);

            const len2 = scale(abttlen, abtt, cdytail, incircle_8);
            finlen = incircle_finadd(finlen, sum_three(
                scale(len2, incircle_8, 2 * cdy, incircle_16), incircle_16,
                scale(len2, incircle_8, cdytail, _16b), _16b,
                scale(len, _16c, cdytail, _32), _32, _32b, _64), _64);
        }
    }

    return incircle_fin[finlen - 1];
}

function incircle(ax, ay, bx, by, cx, cy, dx, dy) {
    const adx = ax - dx;
    const bdx = bx - dx;
    const cdx = cx - dx;
    const ady = ay - dy;
    const bdy = by - dy;
    const cdy = cy - dy;

    const bdxcdy = bdx * cdy;
    const cdxbdy = cdx * bdy;
    const alift = adx * adx + ady * ady;

    const cdxady = cdx * ady;
    const adxcdy = adx * cdy;
    const blift = bdx * bdx + bdy * bdy;

    const adxbdy = adx * bdy;
    const bdxady = bdx * ady;
    const clift = cdx * cdx + cdy * cdy;

    const det =
        alift * (bdxcdy - cdxbdy) +
        blift * (cdxady - adxcdy) +
        clift * (adxbdy - bdxady);

    const permanent =
        (Math.abs(bdxcdy) + Math.abs(cdxbdy)) * alift +
        (Math.abs(cdxady) + Math.abs(adxcdy)) * blift +
        (Math.abs(adxbdy) + Math.abs(bdxady)) * clift;

    const errbound = iccerrboundA * permanent;

    if (det > errbound || -det > errbound) {
        return det;
    }
    return incircleadapt(ax, ay, bx, by, cx, cy, dx, dy, permanent);
}

function incirclefast(ax, ay, bx, by, cx, cy, dx, dy) {
    const adx = ax - dx;
    const ady = ay - dy;
    const bdx = bx - dx;
    const bdy = by - dy;
    const cdx = cx - dx;
    const cdy = cy - dy;

    const abdet = adx * bdy - bdx * ady;
    const bcdet = bdx * cdy - cdx * bdy;
    const cadet = cdx * ady - adx * cdy;
    const alift = adx * adx + ady * ady;
    const blift = bdx * bdx + bdy * bdy;
    const clift = cdx * cdx + cdy * cdy;

    return alift * bcdet + blift * cadet + clift * abdet;
}

;// ./node_modules/robust-predicates/esm/insphere.js


const isperrboundA = (16 + 224 * epsilon) * epsilon;
const isperrboundB = (5 + 72 * epsilon) * epsilon;
const isperrboundC = (71 + 1408 * epsilon) * epsilon * epsilon;

const insphere_ab = vec(4);
const insphere_bc = vec(4);
const cd = vec(4);
const de = vec(4);
const ea = vec(4);
const ac = vec(4);
const bd = vec(4);
const ce = vec(4);
const da = vec(4);
const eb = vec(4);

const abc = vec(24);
const bcd = vec(24);
const cde = vec(24);
const dea = vec(24);
const eab = vec(24);
const abd = vec(24);
const bce = vec(24);
const cda = vec(24);
const deb = vec(24);
const eac = vec(24);

const adet = vec(1152);
const bdet = vec(1152);
const cdet = vec(1152);
const ddet = vec(1152);
const edet = vec(1152);
const abdet = vec(2304);
const cddet = vec(2304);
const cdedet = vec(3456);
const deter = vec(5760);

const insphere_8 = vec(8);
const insphere_8b = vec(8);
const _8c = vec(8);
const insphere_16 = vec(16);
const _24 = vec(24);
const insphere_48 = vec(48);
const _48b = vec(48);
const _96 = vec(96);
const _192 = vec(192);
const _384x = vec(384);
const _384y = vec(384);
const _384z = vec(384);
const _768 = vec(768);

function sum_three_scale(a, b, c, az, bz, cz, out) {
    return sum_three(
        scale(4, a, az, insphere_8), insphere_8,
        scale(4, b, bz, insphere_8b), insphere_8b,
        scale(4, c, cz, _8c), _8c, insphere_16, out);
}

function liftexact(alen, a, blen, b, clen, c, dlen, d, x, y, z, out) {
    const len = sum(
        sum(alen, a, blen, b, insphere_48), insphere_48,
        negate(sum(clen, c, dlen, d, _48b), _48b), _48b, _96);

    return sum_three(
        scale(scale(len, _96, x, _192), _192, x, _384x), _384x,
        scale(scale(len, _96, y, _192), _192, y, _384y), _384y,
        scale(scale(len, _96, z, _192), _192, z, _384z), _384z, _768, out);
}

function insphereexact(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, ex, ey, ez) {
    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _0, s1, s0, t1, t0, u3;

    s1 = ax * by;
    c = splitter * ax;
    ahi = c - (c - ax);
    alo = ax - ahi;
    c = splitter * by;
    bhi = c - (c - by);
    blo = by - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = bx * ay;
    c = splitter * bx;
    ahi = c - (c - bx);
    alo = bx - ahi;
    c = splitter * ay;
    bhi = c - (c - ay);
    blo = ay - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    insphere_ab[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    insphere_ab[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    insphere_ab[2] = _j - (u3 - bvirt) + (_i - bvirt);
    insphere_ab[3] = u3;
    s1 = bx * cy;
    c = splitter * bx;
    ahi = c - (c - bx);
    alo = bx - ahi;
    c = splitter * cy;
    bhi = c - (c - cy);
    blo = cy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cx * by;
    c = splitter * cx;
    ahi = c - (c - cx);
    alo = cx - ahi;
    c = splitter * by;
    bhi = c - (c - by);
    blo = by - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    insphere_bc[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    insphere_bc[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    insphere_bc[2] = _j - (u3 - bvirt) + (_i - bvirt);
    insphere_bc[3] = u3;
    s1 = cx * dy;
    c = splitter * cx;
    ahi = c - (c - cx);
    alo = cx - ahi;
    c = splitter * dy;
    bhi = c - (c - dy);
    blo = dy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = dx * cy;
    c = splitter * dx;
    ahi = c - (c - dx);
    alo = dx - ahi;
    c = splitter * cy;
    bhi = c - (c - cy);
    blo = cy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    cd[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    cd[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    cd[2] = _j - (u3 - bvirt) + (_i - bvirt);
    cd[3] = u3;
    s1 = dx * ey;
    c = splitter * dx;
    ahi = c - (c - dx);
    alo = dx - ahi;
    c = splitter * ey;
    bhi = c - (c - ey);
    blo = ey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = ex * dy;
    c = splitter * ex;
    ahi = c - (c - ex);
    alo = ex - ahi;
    c = splitter * dy;
    bhi = c - (c - dy);
    blo = dy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    de[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    de[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    de[2] = _j - (u3 - bvirt) + (_i - bvirt);
    de[3] = u3;
    s1 = ex * ay;
    c = splitter * ex;
    ahi = c - (c - ex);
    alo = ex - ahi;
    c = splitter * ay;
    bhi = c - (c - ay);
    blo = ay - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = ax * ey;
    c = splitter * ax;
    ahi = c - (c - ax);
    alo = ax - ahi;
    c = splitter * ey;
    bhi = c - (c - ey);
    blo = ey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ea[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ea[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    ea[2] = _j - (u3 - bvirt) + (_i - bvirt);
    ea[3] = u3;
    s1 = ax * cy;
    c = splitter * ax;
    ahi = c - (c - ax);
    alo = ax - ahi;
    c = splitter * cy;
    bhi = c - (c - cy);
    blo = cy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cx * ay;
    c = splitter * cx;
    ahi = c - (c - cx);
    alo = cx - ahi;
    c = splitter * ay;
    bhi = c - (c - ay);
    blo = ay - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ac[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ac[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    ac[2] = _j - (u3 - bvirt) + (_i - bvirt);
    ac[3] = u3;
    s1 = bx * dy;
    c = splitter * bx;
    ahi = c - (c - bx);
    alo = bx - ahi;
    c = splitter * dy;
    bhi = c - (c - dy);
    blo = dy - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = dx * by;
    c = splitter * dx;
    ahi = c - (c - dx);
    alo = dx - ahi;
    c = splitter * by;
    bhi = c - (c - by);
    blo = by - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    bd[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    bd[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    bd[2] = _j - (u3 - bvirt) + (_i - bvirt);
    bd[3] = u3;
    s1 = cx * ey;
    c = splitter * cx;
    ahi = c - (c - cx);
    alo = cx - ahi;
    c = splitter * ey;
    bhi = c - (c - ey);
    blo = ey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = ex * cy;
    c = splitter * ex;
    ahi = c - (c - ex);
    alo = ex - ahi;
    c = splitter * cy;
    bhi = c - (c - cy);
    blo = cy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ce[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ce[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    ce[2] = _j - (u3 - bvirt) + (_i - bvirt);
    ce[3] = u3;
    s1 = dx * ay;
    c = splitter * dx;
    ahi = c - (c - dx);
    alo = dx - ahi;
    c = splitter * ay;
    bhi = c - (c - ay);
    blo = ay - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = ax * dy;
    c = splitter * ax;
    ahi = c - (c - ax);
    alo = ax - ahi;
    c = splitter * dy;
    bhi = c - (c - dy);
    blo = dy - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    da[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    da[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    da[2] = _j - (u3 - bvirt) + (_i - bvirt);
    da[3] = u3;
    s1 = ex * by;
    c = splitter * ex;
    ahi = c - (c - ex);
    alo = ex - ahi;
    c = splitter * by;
    bhi = c - (c - by);
    blo = by - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = bx * ey;
    c = splitter * bx;
    ahi = c - (c - bx);
    alo = bx - ahi;
    c = splitter * ey;
    bhi = c - (c - ey);
    blo = ey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    eb[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    eb[1] = _0 - (_i + bvirt) + (bvirt - t1);
    u3 = _j + _i;
    bvirt = u3 - _j;
    eb[2] = _j - (u3 - bvirt) + (_i - bvirt);
    eb[3] = u3;

    const abclen = sum_three_scale(insphere_ab, insphere_bc, ac, cz, az, -bz, abc);
    const bcdlen = sum_three_scale(insphere_bc, cd, bd, dz, bz, -cz, bcd);
    const cdelen = sum_three_scale(cd, de, ce, ez, cz, -dz, cde);
    const dealen = sum_three_scale(de, ea, da, az, dz, -ez, dea);
    const eablen = sum_three_scale(ea, insphere_ab, eb, bz, ez, -az, eab);
    const abdlen = sum_three_scale(insphere_ab, bd, da, dz, az, bz, abd);
    const bcelen = sum_three_scale(insphere_bc, ce, eb, ez, bz, cz, bce);
    const cdalen = sum_three_scale(cd, da, ac, az, cz, dz, cda);
    const deblen = sum_three_scale(de, eb, bd, bz, dz, ez, deb);
    const eaclen = sum_three_scale(ea, ac, ce, cz, ez, az, eac);

    const deterlen = sum_three(
        liftexact(cdelen, cde, bcelen, bce, deblen, deb, bcdlen, bcd, ax, ay, az, adet), adet,
        liftexact(dealen, dea, cdalen, cda, eaclen, eac, cdelen, cde, bx, by, bz, bdet), bdet,
        sum_three(
            liftexact(eablen, eab, deblen, deb, abdlen, abd, dealen, dea, cx, cy, cz, cdet), cdet,
            liftexact(abclen, abc, eaclen, eac, bcelen, bce, eablen, eab, dx, dy, dz, ddet), ddet,
            liftexact(bcdlen, bcd, abdlen, abd, cdalen, cda, abclen, abc, ex, ey, ez, edet), edet, cddet, cdedet), cdedet, abdet, deter);

    return deter[deterlen - 1];
}

const xdet = vec(96);
const ydet = vec(96);
const zdet = vec(96);
const insphere_fin = vec(1152);

function liftadapt(a, b, c, az, bz, cz, x, y, z, out) {
    const len = sum_three_scale(a, b, c, az, bz, cz, _24);
    return sum_three(
        scale(scale(len, _24, x, insphere_48), insphere_48, x, xdet), xdet,
        scale(scale(len, _24, y, insphere_48), insphere_48, y, ydet), ydet,
        scale(scale(len, _24, z, insphere_48), insphere_48, z, zdet), zdet, _192, out);
}

function insphereadapt(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, ex, ey, ez, permanent) {
    let ab3, bc3, cd3, da3, ac3, bd3;

    let aextail, bextail, cextail, dextail;
    let aeytail, beytail, ceytail, deytail;
    let aeztail, beztail, ceztail, deztail;

    let bvirt, c, ahi, alo, bhi, blo, _i, _j, _0, s1, s0, t1, t0;

    const aex = ax - ex;
    const bex = bx - ex;
    const cex = cx - ex;
    const dex = dx - ex;
    const aey = ay - ey;
    const bey = by - ey;
    const cey = cy - ey;
    const dey = dy - ey;
    const aez = az - ez;
    const bez = bz - ez;
    const cez = cz - ez;
    const dez = dz - ez;

    s1 = aex * bey;
    c = splitter * aex;
    ahi = c - (c - aex);
    alo = aex - ahi;
    c = splitter * bey;
    bhi = c - (c - bey);
    blo = bey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = bex * aey;
    c = splitter * bex;
    ahi = c - (c - bex);
    alo = bex - ahi;
    c = splitter * aey;
    bhi = c - (c - aey);
    blo = aey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    insphere_ab[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    insphere_ab[1] = _0 - (_i + bvirt) + (bvirt - t1);
    ab3 = _j + _i;
    bvirt = ab3 - _j;
    insphere_ab[2] = _j - (ab3 - bvirt) + (_i - bvirt);
    insphere_ab[3] = ab3;
    s1 = bex * cey;
    c = splitter * bex;
    ahi = c - (c - bex);
    alo = bex - ahi;
    c = splitter * cey;
    bhi = c - (c - cey);
    blo = cey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cex * bey;
    c = splitter * cex;
    ahi = c - (c - cex);
    alo = cex - ahi;
    c = splitter * bey;
    bhi = c - (c - bey);
    blo = bey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    insphere_bc[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    insphere_bc[1] = _0 - (_i + bvirt) + (bvirt - t1);
    bc3 = _j + _i;
    bvirt = bc3 - _j;
    insphere_bc[2] = _j - (bc3 - bvirt) + (_i - bvirt);
    insphere_bc[3] = bc3;
    s1 = cex * dey;
    c = splitter * cex;
    ahi = c - (c - cex);
    alo = cex - ahi;
    c = splitter * dey;
    bhi = c - (c - dey);
    blo = dey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = dex * cey;
    c = splitter * dex;
    ahi = c - (c - dex);
    alo = dex - ahi;
    c = splitter * cey;
    bhi = c - (c - cey);
    blo = cey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    cd[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    cd[1] = _0 - (_i + bvirt) + (bvirt - t1);
    cd3 = _j + _i;
    bvirt = cd3 - _j;
    cd[2] = _j - (cd3 - bvirt) + (_i - bvirt);
    cd[3] = cd3;
    s1 = dex * aey;
    c = splitter * dex;
    ahi = c - (c - dex);
    alo = dex - ahi;
    c = splitter * aey;
    bhi = c - (c - aey);
    blo = aey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = aex * dey;
    c = splitter * aex;
    ahi = c - (c - aex);
    alo = aex - ahi;
    c = splitter * dey;
    bhi = c - (c - dey);
    blo = dey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    da[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    da[1] = _0 - (_i + bvirt) + (bvirt - t1);
    da3 = _j + _i;
    bvirt = da3 - _j;
    da[2] = _j - (da3 - bvirt) + (_i - bvirt);
    da[3] = da3;
    s1 = aex * cey;
    c = splitter * aex;
    ahi = c - (c - aex);
    alo = aex - ahi;
    c = splitter * cey;
    bhi = c - (c - cey);
    blo = cey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = cex * aey;
    c = splitter * cex;
    ahi = c - (c - cex);
    alo = cex - ahi;
    c = splitter * aey;
    bhi = c - (c - aey);
    blo = aey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    ac[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    ac[1] = _0 - (_i + bvirt) + (bvirt - t1);
    ac3 = _j + _i;
    bvirt = ac3 - _j;
    ac[2] = _j - (ac3 - bvirt) + (_i - bvirt);
    ac[3] = ac3;
    s1 = bex * dey;
    c = splitter * bex;
    ahi = c - (c - bex);
    alo = bex - ahi;
    c = splitter * dey;
    bhi = c - (c - dey);
    blo = dey - bhi;
    s0 = alo * blo - (s1 - ahi * bhi - alo * bhi - ahi * blo);
    t1 = dex * bey;
    c = splitter * dex;
    ahi = c - (c - dex);
    alo = dex - ahi;
    c = splitter * bey;
    bhi = c - (c - bey);
    blo = bey - bhi;
    t0 = alo * blo - (t1 - ahi * bhi - alo * bhi - ahi * blo);
    _i = s0 - t0;
    bvirt = s0 - _i;
    bd[0] = s0 - (_i + bvirt) + (bvirt - t0);
    _j = s1 + _i;
    bvirt = _j - s1;
    _0 = s1 - (_j - bvirt) + (_i - bvirt);
    _i = _0 - t1;
    bvirt = _0 - _i;
    bd[1] = _0 - (_i + bvirt) + (bvirt - t1);
    bd3 = _j + _i;
    bvirt = bd3 - _j;
    bd[2] = _j - (bd3 - bvirt) + (_i - bvirt);
    bd[3] = bd3;

    const finlen = sum(
        sum(
            negate(liftadapt(insphere_bc, cd, bd, dez, bez, -cez, aex, aey, aez, adet), adet), adet,
            liftadapt(cd, da, ac, aez, cez, dez, bex, bey, bez, bdet), bdet, abdet), abdet,
        sum(
            negate(liftadapt(da, insphere_ab, bd, bez, dez, aez, cex, cey, cez, cdet), cdet), cdet,
            liftadapt(insphere_ab, insphere_bc, ac, cez, aez, -bez, dex, dey, dez, ddet), ddet, cddet), cddet, insphere_fin);

    let det = estimate(finlen, insphere_fin);
    let errbound = isperrboundB * permanent;
    if (det >= errbound || -det >= errbound) {
        return det;
    }

    bvirt = ax - aex;
    aextail = ax - (aex + bvirt) + (bvirt - ex);
    bvirt = ay - aey;
    aeytail = ay - (aey + bvirt) + (bvirt - ey);
    bvirt = az - aez;
    aeztail = az - (aez + bvirt) + (bvirt - ez);
    bvirt = bx - bex;
    bextail = bx - (bex + bvirt) + (bvirt - ex);
    bvirt = by - bey;
    beytail = by - (bey + bvirt) + (bvirt - ey);
    bvirt = bz - bez;
    beztail = bz - (bez + bvirt) + (bvirt - ez);
    bvirt = cx - cex;
    cextail = cx - (cex + bvirt) + (bvirt - ex);
    bvirt = cy - cey;
    ceytail = cy - (cey + bvirt) + (bvirt - ey);
    bvirt = cz - cez;
    ceztail = cz - (cez + bvirt) + (bvirt - ez);
    bvirt = dx - dex;
    dextail = dx - (dex + bvirt) + (bvirt - ex);
    bvirt = dy - dey;
    deytail = dy - (dey + bvirt) + (bvirt - ey);
    bvirt = dz - dez;
    deztail = dz - (dez + bvirt) + (bvirt - ez);
    if (aextail === 0 && aeytail === 0 && aeztail === 0 &&
        bextail === 0 && beytail === 0 && beztail === 0 &&
        cextail === 0 && ceytail === 0 && ceztail === 0 &&
        dextail === 0 && deytail === 0 && deztail === 0) {
        return det;
    }

    errbound = isperrboundC * permanent + resulterrbound * Math.abs(det);

    const abeps = (aex * beytail + bey * aextail) - (aey * bextail + bex * aeytail);
    const bceps = (bex * ceytail + cey * bextail) - (bey * cextail + cex * beytail);
    const cdeps = (cex * deytail + dey * cextail) - (cey * dextail + dex * ceytail);
    const daeps = (dex * aeytail + aey * dextail) - (dey * aextail + aex * deytail);
    const aceps = (aex * ceytail + cey * aextail) - (aey * cextail + cex * aeytail);
    const bdeps = (bex * deytail + dey * bextail) - (bey * dextail + dex * beytail);
    det +=
        (((bex * bex + bey * bey + bez * bez) * ((cez * daeps + dez * aceps + aez * cdeps) +
        (ceztail * da3 + deztail * ac3 + aeztail * cd3)) + (dex * dex + dey * dey + dez * dez) *
        ((aez * bceps - bez * aceps + cez * abeps) + (aeztail * bc3 - beztail * ac3 + ceztail * ab3))) -
        ((aex * aex + aey * aey + aez * aez) * ((bez * cdeps - cez * bdeps + dez * bceps) +
        (beztail * cd3 - ceztail * bd3 + deztail * bc3)) + (cex * cex + cey * cey + cez * cez) *
        ((dez * abeps + aez * bdeps + bez * daeps) + (deztail * ab3 + aeztail * bd3 + beztail * da3)))) +
        2 * (((bex * bextail + bey * beytail + bez * beztail) * (cez * da3 + dez * ac3 + aez * cd3) +
        (dex * dextail + dey * deytail + dez * deztail) * (aez * bc3 - bez * ac3 + cez * ab3)) -
        ((aex * aextail + aey * aeytail + aez * aeztail) * (bez * cd3 - cez * bd3 + dez * bc3) +
        (cex * cextail + cey * ceytail + cez * ceztail) * (dez * ab3 + aez * bd3 + bez * da3)));

    if (det >= errbound || -det >= errbound) {
        return det;
    }

    return insphereexact(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, ex, ey, ez);
}

function insphere(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, ex, ey, ez) {
    const aex = ax - ex;
    const bex = bx - ex;
    const cex = cx - ex;
    const dex = dx - ex;
    const aey = ay - ey;
    const bey = by - ey;
    const cey = cy - ey;
    const dey = dy - ey;
    const aez = az - ez;
    const bez = bz - ez;
    const cez = cz - ez;
    const dez = dz - ez;

    const aexbey = aex * bey;
    const bexaey = bex * aey;
    const ab = aexbey - bexaey;
    const bexcey = bex * cey;
    const cexbey = cex * bey;
    const bc = bexcey - cexbey;
    const cexdey = cex * dey;
    const dexcey = dex * cey;
    const cd = cexdey - dexcey;
    const dexaey = dex * aey;
    const aexdey = aex * dey;
    const da = dexaey - aexdey;
    const aexcey = aex * cey;
    const cexaey = cex * aey;
    const ac = aexcey - cexaey;
    const bexdey = bex * dey;
    const dexbey = dex * bey;
    const bd = bexdey - dexbey;

    const alift = aex * aex + aey * aey + aez * aez;
    const blift = bex * bex + bey * bey + bez * bez;
    const clift = cex * cex + cey * cey + cez * cez;
    const dlift = dex * dex + dey * dey + dez * dez;

    const det =
        (clift * (dez * ab + aez * bd + bez * da) - dlift * (aez * bc - bez * ac + cez * ab)) +
        (alift * (bez * cd - cez * bd + dez * bc) - blift * (cez * da + dez * ac + aez * cd));

    const aezplus = Math.abs(aez);
    const bezplus = Math.abs(bez);
    const cezplus = Math.abs(cez);
    const dezplus = Math.abs(dez);
    const aexbeyplus = Math.abs(aexbey) + Math.abs(bexaey);
    const bexceyplus = Math.abs(bexcey) + Math.abs(cexbey);
    const cexdeyplus = Math.abs(cexdey) + Math.abs(dexcey);
    const dexaeyplus = Math.abs(dexaey) + Math.abs(aexdey);
    const aexceyplus = Math.abs(aexcey) + Math.abs(cexaey);
    const bexdeyplus = Math.abs(bexdey) + Math.abs(dexbey);
    const permanent =
        (cexdeyplus * bezplus + bexdeyplus * cezplus + bexceyplus * dezplus) * alift +
        (dexaeyplus * cezplus + aexceyplus * dezplus + cexdeyplus * aezplus) * blift +
        (aexbeyplus * dezplus + bexdeyplus * aezplus + dexaeyplus * bezplus) * clift +
        (bexceyplus * aezplus + aexceyplus * bezplus + aexbeyplus * cezplus) * dlift;

    const errbound = isperrboundA * permanent;
    if (det > errbound || -det > errbound) {
        return det;
    }
    return -insphereadapt(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, ex, ey, ez, permanent);
}

function inspherefast(pax, pay, paz, pbx, pby, pbz, pcx, pcy, pcz, pdx, pdy, pdz, pex, pey, pez) {
    const aex = pax - pex;
    const bex = pbx - pex;
    const cex = pcx - pex;
    const dex = pdx - pex;
    const aey = pay - pey;
    const bey = pby - pey;
    const cey = pcy - pey;
    const dey = pdy - pey;
    const aez = paz - pez;
    const bez = pbz - pez;
    const cez = pcz - pez;
    const dez = pdz - pez;

    const ab = aex * bey - bex * aey;
    const bc = bex * cey - cex * bey;
    const cd = cex * dey - dex * cey;
    const da = dex * aey - aex * dey;
    const ac = aex * cey - cex * aey;
    const bd = bex * dey - dex * bey;

    const abc = aez * bc - bez * ac + cez * ab;
    const bcd = bez * cd - cez * bd + dez * bc;
    const cda = cez * da + dez * ac + aez * cd;
    const dab = dez * ab + aez * bd + bez * da;

    const alift = aex * aex + aey * aey + aez * aez;
    const blift = bex * bex + bey * bey + bez * bez;
    const clift = cex * cex + cey * cey + cez * cez;
    const dlift = dex * dex + dey * dey + dez * dez;

    return (clift * dab - dlift * abc) + (alift * bcd - blift * cda);
}

;// ./node_modules/robust-predicates/index.js







/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi0yNzU0NTM2OC4yNmM2N2NmMWQyNDY0Nzg3NzViYS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBYTs7QUFFYixJQUFJLEtBQXFDLEVBQUU7QUFBQSxFQUUxQyxDQUFDO0FBQ0YsRUFBRSwyQ0FBMEQ7QUFDNUQ7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVhOztBQUViLElBQUksSUFBcUM7QUFDekM7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQzs7QUFFbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUEsRUFBRSxvQkFBb0I7QUFDdEI7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBOztBQUVBLEVBQUUsb0JBQW9CO0FBQ3RCO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTs7O0FBR0Esb0NBQW9DOztBQUVwQyxxQ0FBcUM7O0FBRXJDO0FBQ0E7QUFDQSxrQ0FBa0M7O0FBRWxDLCtDQUErQzs7QUFFL0M7QUFDQSxxQkFBcUI7O0FBRXJCLHVCQUF1QjtBQUN2QjtBQUNBLDJDQUEyQzs7QUFFM0M7QUFDQTtBQUNBLG9DQUFvQzs7QUFFcEM7QUFDQTtBQUNBLG1GQUFtRjs7QUFFbkY7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7O0FBR0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFFBQVE7O0FBRVI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxNQUFNO0FBQ047QUFDQTs7QUFFQTtBQUNBLElBQUk7OztBQUdKO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQSxRQUFROzs7QUFHUjtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSw2QkFBNkI7O0FBRTdCO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7OztBQUdKO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDhDQUE4QztBQUM5Qzs7QUFFQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSxJQUFJO0FBQ0o7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLDZCQUE2QjtBQUM3QixrQ0FBa0M7QUFDbEMsNEJBQTRCO0FBQzVCLCtCQUErQjtBQUMvQiwwQkFBMEI7QUFDMUIscUNBQXFDO0FBQ3JDLCtCQUErQjtBQUMvQixrQ0FBa0M7QUFDbEMsK0JBQStCO0FBQy9CLHdDQUF3QztBQUN4QyxxQ0FBcUM7QUFDckMscUJBQXFCO0FBQ3JCLCtCQUErQjtBQUMvQiw2QkFBNkI7QUFDN0IsZ0NBQWdDO0FBQ2hDLGlDQUFpQztBQUNqQyw0QkFBNEI7QUFDNUIsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7Ozs7Ozs7Ozs7O0FDem5CTztBQUNBLE1BQU0sYUFBUTtBQUNkLE1BQU0sbUJBQWM7O0FBRTNCO0FBQ08sU0FBUyxRQUFHO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPLFNBQVMsY0FBUztBQUN6QixXQUFXLFFBQUcsQ0FBQyxRQUFHO0FBQ2xCOztBQUVBO0FBQ08sU0FBUyxVQUFLO0FBQ3JCO0FBQ0E7O0FBRUEsUUFBUSxhQUFRO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxhQUFRO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFVBQVU7QUFDOUI7QUFDQTtBQUNBLFlBQVksYUFBUTtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPLFNBQVMsV0FBTTtBQUN0QixvQkFBb0IsVUFBVTtBQUM5QjtBQUNBOztBQUVPLFNBQVMsYUFBUTtBQUN4QjtBQUNBLG9CQUFvQixVQUFVO0FBQzlCO0FBQ0E7O0FBRU87QUFDUDtBQUNBOzs7QUN6SWdGOztBQUVoRiwrQkFBK0IsT0FBTyxJQUFJLE9BQU87QUFDakQsK0JBQStCLE9BQU8sSUFBSSxPQUFPO0FBQ2pELCtCQUErQixPQUFPLElBQUksT0FBTyxHQUFHLE9BQU87O0FBRTNELFVBQVUsR0FBRztBQUNiLFdBQVcsR0FBRztBQUNkLFdBQVcsR0FBRztBQUNkLFVBQVUsR0FBRztBQUNiLFVBQVUsR0FBRzs7QUFFYjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFTztBQUNQO0FBQ0E7OztBQ3ZMdUY7O0FBRXZGLCtCQUErQixPQUFPLElBQUksT0FBTztBQUNqRCwrQkFBK0IsT0FBTyxJQUFJLE9BQU87QUFDakQsaUNBQWlDLE9BQU8sSUFBSSxPQUFPLEdBQUcsT0FBTzs7QUFFN0QsV0FBVyxHQUFHO0FBQ2QsV0FBVyxHQUFHO0FBQ2QsV0FBVyxHQUFHO0FBQ2QsYUFBYSxHQUFHO0FBQ2hCLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7QUFDaEIsYUFBYSxHQUFHO0FBQ2hCLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7QUFDaEIsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsTUFBTSxVQUFDLEdBQUcsR0FBRzs7QUFFYixXQUFXLEdBQUc7QUFDZCxZQUFZLEdBQUc7QUFDZixZQUFZLEdBQUc7QUFDZixZQUFZLEdBQUc7O0FBRWYsVUFBVSxHQUFHO0FBQ2IsV0FBVyxHQUFHOztBQUVkO0FBQ0E7QUFDQSxxQkFBcUIsWUFBWTtBQUNqQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxVQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFVBQUM7QUFDTDtBQUNBLElBQUksVUFBQztBQUNMLElBQUksVUFBQztBQUNMLCtCQUErQixVQUFDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLFVBQUM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsVUFBQztBQUNUO0FBQ0EsUUFBUSxVQUFDO0FBQ1QsUUFBUSxVQUFDO0FBQ1QsbUNBQW1DLFVBQUM7QUFDcEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7O0FDN2NrRzs7QUFFbEcsZ0NBQWdDLE9BQU8sSUFBSSxPQUFPO0FBQ2xELCtCQUErQixPQUFPLElBQUksT0FBTztBQUNqRCxpQ0FBaUMsT0FBTyxJQUFJLE9BQU8sR0FBRyxPQUFPOztBQUU3RCxNQUFNLFdBQUUsR0FBRyxHQUFHO0FBQ2QsTUFBTSxXQUFFLEdBQUcsR0FBRztBQUNkLE1BQU0sV0FBRSxHQUFHLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxNQUFNLFVBQUMsR0FBRyxHQUFHO0FBQ2IsVUFBVSxHQUFHO0FBQ2IsY0FBYyxHQUFHO0FBQ2pCLGNBQWMsR0FBRztBQUNqQixjQUFjLEdBQUc7QUFDakIsY0FBYyxHQUFHO0FBQ2pCLGNBQWMsR0FBRztBQUNqQixjQUFjLEdBQUc7QUFDakIsTUFBTSxZQUFHLEdBQUcsR0FBRztBQUNmLE1BQU0sWUFBRyxHQUFHLEdBQUc7QUFDZixNQUFNLFlBQUcsR0FBRyxHQUFHO0FBQ2YsYUFBYSxHQUFHO0FBQ2hCLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7O0FBRWhCLE1BQU0sVUFBRSxHQUFHLEdBQUc7QUFDZCxNQUFNLFdBQUcsR0FBRyxHQUFHO0FBQ2YsYUFBYSxHQUFHO0FBQ2hCLGFBQWEsR0FBRztBQUNoQixZQUFZLEdBQUc7QUFDZixhQUFhLEdBQUc7QUFDaEIsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHOztBQUVmLElBQUksWUFBRyxHQUFHLEdBQUc7QUFDYixJQUFJLGFBQUksR0FBRyxHQUFHOztBQUVkLFNBQVMsZUFBTTtBQUNmLHlCQUF5QixZQUFHLFdBQVcsYUFBSTtBQUMzQyxnQkFBZ0IsWUFBRyxFQUFFLFlBQUcsR0FBRyxhQUFJLEVBQUUsYUFBSTtBQUNyQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ04sSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTixJQUFJLFdBQUU7O0FBRU47QUFDQTtBQUNBO0FBQ0EsK0JBQStCLFdBQUUsT0FBTyxVQUFFLEdBQUcsVUFBRSxPQUFPLFdBQUcsR0FBRyxXQUFHO0FBQy9ELCtCQUErQixXQUFFLE9BQU8sVUFBRSxHQUFHLFVBQUU7QUFDL0M7QUFDQSwrQkFBK0IsV0FBRSxPQUFPLFVBQUUsR0FBRyxVQUFFLE9BQU8sV0FBRyxHQUFHLFdBQUc7QUFDL0QsK0JBQStCLFdBQUUsT0FBTyxVQUFFLEdBQUcsVUFBRTtBQUMvQztBQUNBLDJCQUEyQixXQUFFLE9BQU8sVUFBRSxHQUFHLFVBQUUsT0FBTyxXQUFHLEdBQUcsV0FBRztBQUMzRCwyQkFBMkIsV0FBRSxPQUFPLFVBQUUsR0FBRyxVQUFFLCtCQUErQixZQUFHOztBQUU3RSwrQkFBK0IsWUFBRztBQUNsQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDRCQUE0QixXQUFFO0FBQzlCLGlCQUFpQixlQUFNO0FBQ3ZCLDRDQUE0QyxXQUFHLEdBQUcsV0FBRztBQUNyRCx3Q0FBd0MsVUFBRSxHQUFHLFVBQUU7QUFDL0Msd0NBQXdDLFVBQUUsR0FBRyxVQUFFO0FBQy9DO0FBQ0E7QUFDQSw0QkFBNEIsV0FBRTtBQUM5QixpQkFBaUIsZUFBTTtBQUN2Qiw0Q0FBNEMsV0FBRyxHQUFHLFdBQUc7QUFDckQsd0NBQXdDLFVBQUUsR0FBRyxVQUFFO0FBQy9DLHdDQUF3QyxVQUFFLEdBQUcsVUFBRTtBQUMvQztBQUNBO0FBQ0EsNEJBQTRCLFdBQUU7QUFDOUIsaUJBQWlCLGVBQU07QUFDdkIsNENBQTRDLFdBQUcsR0FBRyxXQUFHO0FBQ3JELHdDQUF3QyxVQUFFLEdBQUcsVUFBRTtBQUMvQyx3Q0FBd0MsVUFBRSxHQUFHLFVBQUU7QUFDL0M7QUFDQTtBQUNBLDRCQUE0QixXQUFFO0FBQzlCLGlCQUFpQixlQUFNO0FBQ3ZCLDRDQUE0QyxXQUFHLEdBQUcsV0FBRztBQUNyRCx3Q0FBd0MsVUFBRSxHQUFHLFVBQUU7QUFDL0Msd0NBQXdDLFVBQUUsR0FBRyxVQUFFO0FBQy9DO0FBQ0E7QUFDQSw0QkFBNEIsV0FBRTtBQUM5QixpQkFBaUIsZUFBTTtBQUN2Qiw0Q0FBNEMsV0FBRyxHQUFHLFdBQUc7QUFDckQsd0NBQXdDLFVBQUUsR0FBRyxVQUFFO0FBQy9DLHdDQUF3QyxVQUFFLEdBQUcsVUFBRTtBQUMvQztBQUNBO0FBQ0EsNEJBQTRCLFdBQUU7QUFDOUIsaUJBQWlCLGVBQU07QUFDdkIsNENBQTRDLFdBQUcsR0FBRyxXQUFHO0FBQ3JELHdDQUF3QyxVQUFFLEdBQUcsVUFBRTtBQUMvQyx3Q0FBd0MsVUFBRSxHQUFHLFVBQUU7QUFDL0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksVUFBQztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQUM7QUFDYjtBQUNBO0FBQ0EsWUFBWSxVQUFDO0FBQ2IsWUFBWSxVQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixVQUFDLFFBQVEsWUFBRztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1YsWUFBWSxZQUFHO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxZQUFHO0FBQ3pDLHFCQUFxQixlQUFNO0FBQzNCLGdEQUFnRCxXQUFHLEdBQUcsV0FBRztBQUN6RDs7QUFFQSx1REFBdUQsVUFBRTtBQUN6RCxxQkFBcUIsZUFBTTtBQUMzQiw0QkFBNEIsVUFBRSxXQUFXLFdBQUcsR0FBRyxXQUFHO0FBQ2xELDRCQUE0QixVQUFFO0FBQzlCOztBQUVBO0FBQ0EseUJBQXlCLGVBQU0scUNBQXFDLFVBQUUsR0FBRyxVQUFFLFdBQVcsV0FBRyxHQUFHLFdBQUc7QUFDL0Y7QUFDQTtBQUNBLHlCQUF5QixlQUFNLHNDQUFzQyxVQUFFLEdBQUcsVUFBRSxXQUFXLFdBQUcsR0FBRyxXQUFHO0FBQ2hHO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxZQUFHO0FBQ3pDLHFCQUFxQixlQUFNO0FBQzNCLGdEQUFnRCxXQUFHLEdBQUcsV0FBRztBQUN6RDs7QUFFQSx1REFBdUQsVUFBRTtBQUN6RCxxQkFBcUIsZUFBTTtBQUMzQiw0QkFBNEIsVUFBRSxXQUFXLFdBQUcsR0FBRyxXQUFHO0FBQ2xELDRCQUE0QixVQUFFO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQUM7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxVQUFDO0FBQ2I7QUFDQTtBQUNBLFlBQVksVUFBQztBQUNiLFlBQVksVUFBQztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLFVBQUMsUUFBUSxZQUFHO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVixZQUFZLFlBQUc7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLFlBQUc7QUFDekMscUJBQXFCLGVBQU07QUFDM0IsZ0RBQWdELFdBQUcsR0FBRyxXQUFHO0FBQ3pEOztBQUVBLHVEQUF1RCxVQUFFO0FBQ3pELHFCQUFxQixlQUFNO0FBQzNCLDRCQUE0QixVQUFFLFdBQVcsV0FBRyxHQUFHLFdBQUc7QUFDbEQsNEJBQTRCLFVBQUU7QUFDOUI7O0FBRUE7QUFDQSx5QkFBeUIsZUFBTSxxQ0FBcUMsVUFBRSxHQUFHLFVBQUUsV0FBVyxXQUFHLEdBQUcsV0FBRztBQUMvRjtBQUNBO0FBQ0EseUJBQXlCLGVBQU0sc0NBQXNDLFVBQUUsR0FBRyxVQUFFLFdBQVcsV0FBRyxHQUFHLFdBQUc7QUFDaEc7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLFlBQUc7QUFDekMscUJBQXFCLGVBQU07QUFDM0IsZ0RBQWdELFdBQUcsR0FBRyxXQUFHO0FBQ3pEOztBQUVBLHVEQUF1RCxVQUFFO0FBQ3pELHFCQUFxQixlQUFNO0FBQzNCLDRCQUE0QixVQUFFLFdBQVcsV0FBRyxHQUFHLFdBQUc7QUFDbEQsNEJBQTRCLFVBQUU7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksVUFBQztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFVBQUM7QUFDYjtBQUNBO0FBQ0EsWUFBWSxVQUFDO0FBQ2IsWUFBWSxVQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsVUFBQyxRQUFRLFlBQUc7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWLFlBQVksWUFBRztBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsWUFBRztBQUN6QyxxQkFBcUIsZUFBTTtBQUMzQixnREFBZ0QsV0FBRyxHQUFHLFdBQUc7QUFDekQ7O0FBRUEsdURBQXVELFVBQUU7QUFDekQscUJBQXFCLGVBQU07QUFDM0IsNEJBQTRCLFVBQUUsV0FBVyxXQUFHLEdBQUcsV0FBRztBQUNsRCw0QkFBNEIsVUFBRTtBQUM5Qjs7QUFFQTtBQUNBLHlCQUF5QixlQUFNLHFDQUFxQyxVQUFFLEdBQUcsVUFBRSxXQUFXLFdBQUcsR0FBRyxXQUFHO0FBQy9GO0FBQ0E7QUFDQSx5QkFBeUIsZUFBTSxzQ0FBc0MsVUFBRSxHQUFHLFVBQUUsV0FBVyxXQUFHLEdBQUcsV0FBRztBQUNoRztBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsWUFBRztBQUN6QyxxQkFBcUIsZUFBTTtBQUMzQixnREFBZ0QsV0FBRyxHQUFHLFdBQUc7QUFDekQ7O0FBRUEsdURBQXVELFVBQUU7QUFDekQscUJBQXFCLGVBQU07QUFDM0IsNEJBQTRCLFVBQUUsV0FBVyxXQUFHLEdBQUcsV0FBRztBQUNsRCw0QkFBNEIsVUFBRTtBQUM5QjtBQUNBO0FBQ0E7O0FBRUEsV0FBVyxZQUFHO0FBQ2Q7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7O0FDNXZCMEc7O0FBRTFHLGlDQUFpQyxPQUFPLElBQUksT0FBTztBQUNuRCwrQkFBK0IsT0FBTyxJQUFJLE9BQU87QUFDakQsa0NBQWtDLE9BQU8sSUFBSSxPQUFPLEdBQUcsT0FBTzs7QUFFOUQsTUFBTSxXQUFFLEdBQUcsR0FBRztBQUNkLE1BQU0sV0FBRSxHQUFHLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7QUFDZCxXQUFXLEdBQUc7O0FBRWQsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHO0FBQ2YsWUFBWSxHQUFHOztBQUVmLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7QUFDaEIsYUFBYSxHQUFHO0FBQ2hCLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7QUFDaEIsY0FBYyxHQUFHO0FBQ2pCLGNBQWMsR0FBRztBQUNqQixlQUFlLEdBQUc7QUFDbEIsY0FBYyxHQUFHOztBQUVqQixNQUFNLFVBQUUsR0FBRyxHQUFHO0FBQ2QsTUFBTSxXQUFHLEdBQUcsR0FBRztBQUNmLFlBQVksR0FBRztBQUNmLE1BQU0sV0FBRyxHQUFHLEdBQUc7QUFDZixZQUFZLEdBQUc7QUFDZixNQUFNLFdBQUcsR0FBRyxHQUFHO0FBQ2YsYUFBYSxHQUFHO0FBQ2hCLFlBQVksR0FBRztBQUNmLGFBQWEsR0FBRztBQUNoQixjQUFjLEdBQUc7QUFDakIsY0FBYyxHQUFHO0FBQ2pCLGNBQWMsR0FBRztBQUNqQixhQUFhLEdBQUc7O0FBRWhCO0FBQ0E7QUFDQSx3QkFBd0IsVUFBRSxHQUFHLFVBQUU7QUFDL0Isd0JBQXdCLFdBQUcsR0FBRyxXQUFHO0FBQ2pDLG1DQUFtQyxXQUFHO0FBQ3RDOztBQUVBO0FBQ0E7QUFDQSw4QkFBOEIsV0FBRyxHQUFHLFdBQUc7QUFDdkM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ04sSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTixJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxtQ0FBbUMsV0FBRSxFQUFFLFdBQUU7QUFDekMsbUNBQW1DLFdBQUU7QUFDckM7QUFDQTtBQUNBLHVDQUF1QyxXQUFFO0FBQ3pDLG1DQUFtQyxXQUFFO0FBQ3JDLG1DQUFtQyxXQUFFO0FBQ3JDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLGFBQWEsR0FBRztBQUNoQixhQUFhLEdBQUc7QUFDaEIsYUFBYSxHQUFHO0FBQ2hCLE1BQU0sWUFBRyxHQUFHLEdBQUc7O0FBRWY7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLFdBQUcsR0FBRyxXQUFHO0FBQzFDLGlDQUFpQyxXQUFHLEdBQUcsV0FBRztBQUMxQyxpQ0FBaUMsV0FBRyxHQUFHLFdBQUc7QUFDMUM7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ04sSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxXQUFFO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBRTtBQUNOO0FBQ0E7QUFDQSxJQUFJLFdBQUU7QUFDTixJQUFJLFdBQUU7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw2QkFBNkIsV0FBRTtBQUMvQjtBQUNBO0FBQ0EsaUNBQWlDLFdBQUU7QUFDbkMsc0JBQXNCLFdBQUUsRUFBRSxXQUFFLGlFQUFpRSxZQUFHOztBQUVoRywrQkFBK0IsWUFBRztBQUNsQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7Ozs7QUM1dkJ5RDtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3NjaGVkdWxlci9pbmRleC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9zY2hlZHVsZXIvY2pzL3NjaGVkdWxlci5kZXZlbG9wbWVudC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yb2J1c3QtcHJlZGljYXRlcy9lc20vdXRpbC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yb2J1c3QtcHJlZGljYXRlcy9lc20vb3JpZW50MmQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcm9idXN0LXByZWRpY2F0ZXMvZXNtL29yaWVudDNkLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JvYnVzdC1wcmVkaWNhdGVzL2VzbS9pbmNpcmNsZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yb2J1c3QtcHJlZGljYXRlcy9lc20vaW5zcGhlcmUuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcm9idXN0LXByZWRpY2F0ZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnO1xuXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJykge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2pzL3NjaGVkdWxlci5wcm9kdWN0aW9uLm1pbi5qcycpO1xufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Nqcy9zY2hlZHVsZXIuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2UgUmVhY3RcbiAqIHNjaGVkdWxlci5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgRmFjZWJvb2ssIEluYy4gYW5kIGl0cyBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgICAndXNlIHN0cmljdCc7XG5cbi8qIGdsb2JhbCBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18gKi9cbmlmIChcbiAgdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RhcnQgPT09XG4gICAgJ2Z1bmN0aW9uJ1xuKSB7XG4gIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RhcnQobmV3IEVycm9yKCkpO1xufVxuICAgICAgICAgIHZhciBlbmFibGVTY2hlZHVsZXJEZWJ1Z2dpbmcgPSBmYWxzZTtcbnZhciBlbmFibGVQcm9maWxpbmcgPSBmYWxzZTtcbnZhciBmcmFtZVlpZWxkTXMgPSA1O1xuXG5mdW5jdGlvbiBwdXNoKGhlYXAsIG5vZGUpIHtcbiAgdmFyIGluZGV4ID0gaGVhcC5sZW5ndGg7XG4gIGhlYXAucHVzaChub2RlKTtcbiAgc2lmdFVwKGhlYXAsIG5vZGUsIGluZGV4KTtcbn1cbmZ1bmN0aW9uIHBlZWsoaGVhcCkge1xuICByZXR1cm4gaGVhcC5sZW5ndGggPT09IDAgPyBudWxsIDogaGVhcFswXTtcbn1cbmZ1bmN0aW9uIHBvcChoZWFwKSB7XG4gIGlmIChoZWFwLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgdmFyIGZpcnN0ID0gaGVhcFswXTtcbiAgdmFyIGxhc3QgPSBoZWFwLnBvcCgpO1xuXG4gIGlmIChsYXN0ICE9PSBmaXJzdCkge1xuICAgIGhlYXBbMF0gPSBsYXN0O1xuICAgIHNpZnREb3duKGhlYXAsIGxhc3QsIDApO1xuICB9XG5cbiAgcmV0dXJuIGZpcnN0O1xufVxuXG5mdW5jdGlvbiBzaWZ0VXAoaGVhcCwgbm9kZSwgaSkge1xuICB2YXIgaW5kZXggPSBpO1xuXG4gIHdoaWxlIChpbmRleCA+IDApIHtcbiAgICB2YXIgcGFyZW50SW5kZXggPSBpbmRleCAtIDEgPj4+IDE7XG4gICAgdmFyIHBhcmVudCA9IGhlYXBbcGFyZW50SW5kZXhdO1xuXG4gICAgaWYgKGNvbXBhcmUocGFyZW50LCBub2RlKSA+IDApIHtcbiAgICAgIC8vIFRoZSBwYXJlbnQgaXMgbGFyZ2VyLiBTd2FwIHBvc2l0aW9ucy5cbiAgICAgIGhlYXBbcGFyZW50SW5kZXhdID0gbm9kZTtcbiAgICAgIGhlYXBbaW5kZXhdID0gcGFyZW50O1xuICAgICAgaW5kZXggPSBwYXJlbnRJbmRleDtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlIHBhcmVudCBpcyBzbWFsbGVyLiBFeGl0LlxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBzaWZ0RG93bihoZWFwLCBub2RlLCBpKSB7XG4gIHZhciBpbmRleCA9IGk7XG4gIHZhciBsZW5ndGggPSBoZWFwLmxlbmd0aDtcbiAgdmFyIGhhbGZMZW5ndGggPSBsZW5ndGggPj4+IDE7XG5cbiAgd2hpbGUgKGluZGV4IDwgaGFsZkxlbmd0aCkge1xuICAgIHZhciBsZWZ0SW5kZXggPSAoaW5kZXggKyAxKSAqIDIgLSAxO1xuICAgIHZhciBsZWZ0ID0gaGVhcFtsZWZ0SW5kZXhdO1xuICAgIHZhciByaWdodEluZGV4ID0gbGVmdEluZGV4ICsgMTtcbiAgICB2YXIgcmlnaHQgPSBoZWFwW3JpZ2h0SW5kZXhdOyAvLyBJZiB0aGUgbGVmdCBvciByaWdodCBub2RlIGlzIHNtYWxsZXIsIHN3YXAgd2l0aCB0aGUgc21hbGxlciBvZiB0aG9zZS5cblxuICAgIGlmIChjb21wYXJlKGxlZnQsIG5vZGUpIDwgMCkge1xuICAgICAgaWYgKHJpZ2h0SW5kZXggPCBsZW5ndGggJiYgY29tcGFyZShyaWdodCwgbGVmdCkgPCAwKSB7XG4gICAgICAgIGhlYXBbaW5kZXhdID0gcmlnaHQ7XG4gICAgICAgIGhlYXBbcmlnaHRJbmRleF0gPSBub2RlO1xuICAgICAgICBpbmRleCA9IHJpZ2h0SW5kZXg7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoZWFwW2luZGV4XSA9IGxlZnQ7XG4gICAgICAgIGhlYXBbbGVmdEluZGV4XSA9IG5vZGU7XG4gICAgICAgIGluZGV4ID0gbGVmdEluZGV4O1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmlnaHRJbmRleCA8IGxlbmd0aCAmJiBjb21wYXJlKHJpZ2h0LCBub2RlKSA8IDApIHtcbiAgICAgIGhlYXBbaW5kZXhdID0gcmlnaHQ7XG4gICAgICBoZWFwW3JpZ2h0SW5kZXhdID0gbm9kZTtcbiAgICAgIGluZGV4ID0gcmlnaHRJbmRleDtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTmVpdGhlciBjaGlsZCBpcyBzbWFsbGVyLiBFeGl0LlxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBjb21wYXJlKGEsIGIpIHtcbiAgLy8gQ29tcGFyZSBzb3J0IGluZGV4IGZpcnN0LCB0aGVuIHRhc2sgaWQuXG4gIHZhciBkaWZmID0gYS5zb3J0SW5kZXggLSBiLnNvcnRJbmRleDtcbiAgcmV0dXJuIGRpZmYgIT09IDAgPyBkaWZmIDogYS5pZCAtIGIuaWQ7XG59XG5cbi8vIFRPRE86IFVzZSBzeW1ib2xzP1xudmFyIEltbWVkaWF0ZVByaW9yaXR5ID0gMTtcbnZhciBVc2VyQmxvY2tpbmdQcmlvcml0eSA9IDI7XG52YXIgTm9ybWFsUHJpb3JpdHkgPSAzO1xudmFyIExvd1ByaW9yaXR5ID0gNDtcbnZhciBJZGxlUHJpb3JpdHkgPSA1O1xuXG5mdW5jdGlvbiBtYXJrVGFza0Vycm9yZWQodGFzaywgbXMpIHtcbn1cblxuLyogZXNsaW50LWRpc2FibGUgbm8tdmFyICovXG5cbnZhciBoYXNQZXJmb3JtYW5jZU5vdyA9IHR5cGVvZiBwZXJmb3JtYW5jZSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHBlcmZvcm1hbmNlLm5vdyA9PT0gJ2Z1bmN0aW9uJztcblxuaWYgKGhhc1BlcmZvcm1hbmNlTm93KSB7XG4gIHZhciBsb2NhbFBlcmZvcm1hbmNlID0gcGVyZm9ybWFuY2U7XG5cbiAgZXhwb3J0cy51bnN0YWJsZV9ub3cgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIGxvY2FsUGVyZm9ybWFuY2Uubm93KCk7XG4gIH07XG59IGVsc2Uge1xuICB2YXIgbG9jYWxEYXRlID0gRGF0ZTtcbiAgdmFyIGluaXRpYWxUaW1lID0gbG9jYWxEYXRlLm5vdygpO1xuXG4gIGV4cG9ydHMudW5zdGFibGVfbm93ID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBsb2NhbERhdGUubm93KCkgLSBpbml0aWFsVGltZTtcbiAgfTtcbn0gLy8gTWF4IDMxIGJpdCBpbnRlZ2VyLiBUaGUgbWF4IGludGVnZXIgc2l6ZSBpbiBWOCBmb3IgMzItYml0IHN5c3RlbXMuXG4vLyBNYXRoLnBvdygyLCAzMCkgLSAxXG4vLyAwYjExMTExMTExMTExMTExMTExMTExMTExMTExMTExMVxuXG5cbnZhciBtYXhTaWduZWQzMUJpdEludCA9IDEwNzM3NDE4MjM7IC8vIFRpbWVzIG91dCBpbW1lZGlhdGVseVxuXG52YXIgSU1NRURJQVRFX1BSSU9SSVRZX1RJTUVPVVQgPSAtMTsgLy8gRXZlbnR1YWxseSB0aW1lcyBvdXRcblxudmFyIFVTRVJfQkxPQ0tJTkdfUFJJT1JJVFlfVElNRU9VVCA9IDI1MDtcbnZhciBOT1JNQUxfUFJJT1JJVFlfVElNRU9VVCA9IDUwMDA7XG52YXIgTE9XX1BSSU9SSVRZX1RJTUVPVVQgPSAxMDAwMDsgLy8gTmV2ZXIgdGltZXMgb3V0XG5cbnZhciBJRExFX1BSSU9SSVRZX1RJTUVPVVQgPSBtYXhTaWduZWQzMUJpdEludDsgLy8gVGFza3MgYXJlIHN0b3JlZCBvbiBhIG1pbiBoZWFwXG5cbnZhciB0YXNrUXVldWUgPSBbXTtcbnZhciB0aW1lclF1ZXVlID0gW107IC8vIEluY3JlbWVudGluZyBpZCBjb3VudGVyLiBVc2VkIHRvIG1haW50YWluIGluc2VydGlvbiBvcmRlci5cblxudmFyIHRhc2tJZENvdW50ZXIgPSAxOyAvLyBQYXVzaW5nIHRoZSBzY2hlZHVsZXIgaXMgdXNlZnVsIGZvciBkZWJ1Z2dpbmcuXG52YXIgY3VycmVudFRhc2sgPSBudWxsO1xudmFyIGN1cnJlbnRQcmlvcml0eUxldmVsID0gTm9ybWFsUHJpb3JpdHk7IC8vIFRoaXMgaXMgc2V0IHdoaWxlIHBlcmZvcm1pbmcgd29yaywgdG8gcHJldmVudCByZS1lbnRyYW5jZS5cblxudmFyIGlzUGVyZm9ybWluZ1dvcmsgPSBmYWxzZTtcbnZhciBpc0hvc3RDYWxsYmFja1NjaGVkdWxlZCA9IGZhbHNlO1xudmFyIGlzSG9zdFRpbWVvdXRTY2hlZHVsZWQgPSBmYWxzZTsgLy8gQ2FwdHVyZSBsb2NhbCByZWZlcmVuY2VzIHRvIG5hdGl2ZSBBUElzLCBpbiBjYXNlIGEgcG9seWZpbGwgb3ZlcnJpZGVzIHRoZW0uXG5cbnZhciBsb2NhbFNldFRpbWVvdXQgPSB0eXBlb2Ygc2V0VGltZW91dCA9PT0gJ2Z1bmN0aW9uJyA/IHNldFRpbWVvdXQgOiBudWxsO1xudmFyIGxvY2FsQ2xlYXJUaW1lb3V0ID0gdHlwZW9mIGNsZWFyVGltZW91dCA9PT0gJ2Z1bmN0aW9uJyA/IGNsZWFyVGltZW91dCA6IG51bGw7XG52YXIgbG9jYWxTZXRJbW1lZGlhdGUgPSB0eXBlb2Ygc2V0SW1tZWRpYXRlICE9PSAndW5kZWZpbmVkJyA/IHNldEltbWVkaWF0ZSA6IG51bGw7IC8vIElFIGFuZCBOb2RlLmpzICsganNkb21cblxudmFyIGlzSW5wdXRQZW5kaW5nID0gdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnNjaGVkdWxpbmcgIT09IHVuZGVmaW5lZCAmJiBuYXZpZ2F0b3Iuc2NoZWR1bGluZy5pc0lucHV0UGVuZGluZyAhPT0gdW5kZWZpbmVkID8gbmF2aWdhdG9yLnNjaGVkdWxpbmcuaXNJbnB1dFBlbmRpbmcuYmluZChuYXZpZ2F0b3Iuc2NoZWR1bGluZykgOiBudWxsO1xuXG5mdW5jdGlvbiBhZHZhbmNlVGltZXJzKGN1cnJlbnRUaW1lKSB7XG4gIC8vIENoZWNrIGZvciB0YXNrcyB0aGF0IGFyZSBubyBsb25nZXIgZGVsYXllZCBhbmQgYWRkIHRoZW0gdG8gdGhlIHF1ZXVlLlxuICB2YXIgdGltZXIgPSBwZWVrKHRpbWVyUXVldWUpO1xuXG4gIHdoaWxlICh0aW1lciAhPT0gbnVsbCkge1xuICAgIGlmICh0aW1lci5jYWxsYmFjayA9PT0gbnVsbCkge1xuICAgICAgLy8gVGltZXIgd2FzIGNhbmNlbGxlZC5cbiAgICAgIHBvcCh0aW1lclF1ZXVlKTtcbiAgICB9IGVsc2UgaWYgKHRpbWVyLnN0YXJ0VGltZSA8PSBjdXJyZW50VGltZSkge1xuICAgICAgLy8gVGltZXIgZmlyZWQuIFRyYW5zZmVyIHRvIHRoZSB0YXNrIHF1ZXVlLlxuICAgICAgcG9wKHRpbWVyUXVldWUpO1xuICAgICAgdGltZXIuc29ydEluZGV4ID0gdGltZXIuZXhwaXJhdGlvblRpbWU7XG4gICAgICBwdXNoKHRhc2tRdWV1ZSwgdGltZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBSZW1haW5pbmcgdGltZXJzIGFyZSBwZW5kaW5nLlxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRpbWVyID0gcGVlayh0aW1lclF1ZXVlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBoYW5kbGVUaW1lb3V0KGN1cnJlbnRUaW1lKSB7XG4gIGlzSG9zdFRpbWVvdXRTY2hlZHVsZWQgPSBmYWxzZTtcbiAgYWR2YW5jZVRpbWVycyhjdXJyZW50VGltZSk7XG5cbiAgaWYgKCFpc0hvc3RDYWxsYmFja1NjaGVkdWxlZCkge1xuICAgIGlmIChwZWVrKHRhc2tRdWV1ZSkgIT09IG51bGwpIHtcbiAgICAgIGlzSG9zdENhbGxiYWNrU2NoZWR1bGVkID0gdHJ1ZTtcbiAgICAgIHJlcXVlc3RIb3N0Q2FsbGJhY2soZmx1c2hXb3JrKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIGZpcnN0VGltZXIgPSBwZWVrKHRpbWVyUXVldWUpO1xuXG4gICAgICBpZiAoZmlyc3RUaW1lciAhPT0gbnVsbCkge1xuICAgICAgICByZXF1ZXN0SG9zdFRpbWVvdXQoaGFuZGxlVGltZW91dCwgZmlyc3RUaW1lci5zdGFydFRpbWUgLSBjdXJyZW50VGltZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGZsdXNoV29yayhoYXNUaW1lUmVtYWluaW5nLCBpbml0aWFsVGltZSkge1xuXG5cbiAgaXNIb3N0Q2FsbGJhY2tTY2hlZHVsZWQgPSBmYWxzZTtcblxuICBpZiAoaXNIb3N0VGltZW91dFNjaGVkdWxlZCkge1xuICAgIC8vIFdlIHNjaGVkdWxlZCBhIHRpbWVvdXQgYnV0IGl0J3Mgbm8gbG9uZ2VyIG5lZWRlZC4gQ2FuY2VsIGl0LlxuICAgIGlzSG9zdFRpbWVvdXRTY2hlZHVsZWQgPSBmYWxzZTtcbiAgICBjYW5jZWxIb3N0VGltZW91dCgpO1xuICB9XG5cbiAgaXNQZXJmb3JtaW5nV29yayA9IHRydWU7XG4gIHZhciBwcmV2aW91c1ByaW9yaXR5TGV2ZWwgPSBjdXJyZW50UHJpb3JpdHlMZXZlbDtcblxuICB0cnkge1xuICAgIGlmIChlbmFibGVQcm9maWxpbmcpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiB3b3JrTG9vcChoYXNUaW1lUmVtYWluaW5nLCBpbml0aWFsVGltZSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoY3VycmVudFRhc2sgIT09IG51bGwpIHtcbiAgICAgICAgICB2YXIgY3VycmVudFRpbWUgPSBleHBvcnRzLnVuc3RhYmxlX25vdygpO1xuICAgICAgICAgIG1hcmtUYXNrRXJyb3JlZChjdXJyZW50VGFzaywgY3VycmVudFRpbWUpO1xuICAgICAgICAgIGN1cnJlbnRUYXNrLmlzUXVldWVkID0gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTm8gY2F0Y2ggaW4gcHJvZCBjb2RlIHBhdGguXG4gICAgICByZXR1cm4gd29ya0xvb3AoaGFzVGltZVJlbWFpbmluZywgaW5pdGlhbFRpbWUpO1xuICAgIH1cbiAgfSBmaW5hbGx5IHtcbiAgICBjdXJyZW50VGFzayA9IG51bGw7XG4gICAgY3VycmVudFByaW9yaXR5TGV2ZWwgPSBwcmV2aW91c1ByaW9yaXR5TGV2ZWw7XG4gICAgaXNQZXJmb3JtaW5nV29yayA9IGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHdvcmtMb29wKGhhc1RpbWVSZW1haW5pbmcsIGluaXRpYWxUaW1lKSB7XG4gIHZhciBjdXJyZW50VGltZSA9IGluaXRpYWxUaW1lO1xuICBhZHZhbmNlVGltZXJzKGN1cnJlbnRUaW1lKTtcbiAgY3VycmVudFRhc2sgPSBwZWVrKHRhc2tRdWV1ZSk7XG5cbiAgd2hpbGUgKGN1cnJlbnRUYXNrICE9PSBudWxsICYmICEoZW5hYmxlU2NoZWR1bGVyRGVidWdnaW5nICkpIHtcbiAgICBpZiAoY3VycmVudFRhc2suZXhwaXJhdGlvblRpbWUgPiBjdXJyZW50VGltZSAmJiAoIWhhc1RpbWVSZW1haW5pbmcgfHwgc2hvdWxkWWllbGRUb0hvc3QoKSkpIHtcbiAgICAgIC8vIFRoaXMgY3VycmVudFRhc2sgaGFzbid0IGV4cGlyZWQsIGFuZCB3ZSd2ZSByZWFjaGVkIHRoZSBkZWFkbGluZS5cbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHZhciBjYWxsYmFjayA9IGN1cnJlbnRUYXNrLmNhbGxiYWNrO1xuXG4gICAgaWYgKHR5cGVvZiBjYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY3VycmVudFRhc2suY2FsbGJhY2sgPSBudWxsO1xuICAgICAgY3VycmVudFByaW9yaXR5TGV2ZWwgPSBjdXJyZW50VGFzay5wcmlvcml0eUxldmVsO1xuICAgICAgdmFyIGRpZFVzZXJDYWxsYmFja1RpbWVvdXQgPSBjdXJyZW50VGFzay5leHBpcmF0aW9uVGltZSA8PSBjdXJyZW50VGltZTtcblxuICAgICAgdmFyIGNvbnRpbnVhdGlvbkNhbGxiYWNrID0gY2FsbGJhY2soZGlkVXNlckNhbGxiYWNrVGltZW91dCk7XG4gICAgICBjdXJyZW50VGltZSA9IGV4cG9ydHMudW5zdGFibGVfbm93KCk7XG5cbiAgICAgIGlmICh0eXBlb2YgY29udGludWF0aW9uQ2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgY3VycmVudFRhc2suY2FsbGJhY2sgPSBjb250aW51YXRpb25DYWxsYmFjaztcbiAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgaWYgKGN1cnJlbnRUYXNrID09PSBwZWVrKHRhc2tRdWV1ZSkpIHtcbiAgICAgICAgICBwb3AodGFza1F1ZXVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBhZHZhbmNlVGltZXJzKGN1cnJlbnRUaW1lKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcG9wKHRhc2tRdWV1ZSk7XG4gICAgfVxuXG4gICAgY3VycmVudFRhc2sgPSBwZWVrKHRhc2tRdWV1ZSk7XG4gIH0gLy8gUmV0dXJuIHdoZXRoZXIgdGhlcmUncyBhZGRpdGlvbmFsIHdvcmtcblxuXG4gIGlmIChjdXJyZW50VGFzayAhPT0gbnVsbCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIHZhciBmaXJzdFRpbWVyID0gcGVlayh0aW1lclF1ZXVlKTtcblxuICAgIGlmIChmaXJzdFRpbWVyICE9PSBudWxsKSB7XG4gICAgICByZXF1ZXN0SG9zdFRpbWVvdXQoaGFuZGxlVGltZW91dCwgZmlyc3RUaW1lci5zdGFydFRpbWUgLSBjdXJyZW50VGltZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHVuc3RhYmxlX3J1bldpdGhQcmlvcml0eShwcmlvcml0eUxldmVsLCBldmVudEhhbmRsZXIpIHtcbiAgc3dpdGNoIChwcmlvcml0eUxldmVsKSB7XG4gICAgY2FzZSBJbW1lZGlhdGVQcmlvcml0eTpcbiAgICBjYXNlIFVzZXJCbG9ja2luZ1ByaW9yaXR5OlxuICAgIGNhc2UgTm9ybWFsUHJpb3JpdHk6XG4gICAgY2FzZSBMb3dQcmlvcml0eTpcbiAgICBjYXNlIElkbGVQcmlvcml0eTpcbiAgICAgIGJyZWFrO1xuXG4gICAgZGVmYXVsdDpcbiAgICAgIHByaW9yaXR5TGV2ZWwgPSBOb3JtYWxQcmlvcml0eTtcbiAgfVxuXG4gIHZhciBwcmV2aW91c1ByaW9yaXR5TGV2ZWwgPSBjdXJyZW50UHJpb3JpdHlMZXZlbDtcbiAgY3VycmVudFByaW9yaXR5TGV2ZWwgPSBwcmlvcml0eUxldmVsO1xuXG4gIHRyeSB7XG4gICAgcmV0dXJuIGV2ZW50SGFuZGxlcigpO1xuICB9IGZpbmFsbHkge1xuICAgIGN1cnJlbnRQcmlvcml0eUxldmVsID0gcHJldmlvdXNQcmlvcml0eUxldmVsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHVuc3RhYmxlX25leHQoZXZlbnRIYW5kbGVyKSB7XG4gIHZhciBwcmlvcml0eUxldmVsO1xuXG4gIHN3aXRjaCAoY3VycmVudFByaW9yaXR5TGV2ZWwpIHtcbiAgICBjYXNlIEltbWVkaWF0ZVByaW9yaXR5OlxuICAgIGNhc2UgVXNlckJsb2NraW5nUHJpb3JpdHk6XG4gICAgY2FzZSBOb3JtYWxQcmlvcml0eTpcbiAgICAgIC8vIFNoaWZ0IGRvd24gdG8gbm9ybWFsIHByaW9yaXR5XG4gICAgICBwcmlvcml0eUxldmVsID0gTm9ybWFsUHJpb3JpdHk7XG4gICAgICBicmVhaztcblxuICAgIGRlZmF1bHQ6XG4gICAgICAvLyBBbnl0aGluZyBsb3dlciB0aGFuIG5vcm1hbCBwcmlvcml0eSBzaG91bGQgcmVtYWluIGF0IHRoZSBjdXJyZW50IGxldmVsLlxuICAgICAgcHJpb3JpdHlMZXZlbCA9IGN1cnJlbnRQcmlvcml0eUxldmVsO1xuICAgICAgYnJlYWs7XG4gIH1cblxuICB2YXIgcHJldmlvdXNQcmlvcml0eUxldmVsID0gY3VycmVudFByaW9yaXR5TGV2ZWw7XG4gIGN1cnJlbnRQcmlvcml0eUxldmVsID0gcHJpb3JpdHlMZXZlbDtcblxuICB0cnkge1xuICAgIHJldHVybiBldmVudEhhbmRsZXIoKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjdXJyZW50UHJpb3JpdHlMZXZlbCA9IHByZXZpb3VzUHJpb3JpdHlMZXZlbDtcbiAgfVxufVxuXG5mdW5jdGlvbiB1bnN0YWJsZV93cmFwQ2FsbGJhY2soY2FsbGJhY2spIHtcbiAgdmFyIHBhcmVudFByaW9yaXR5TGV2ZWwgPSBjdXJyZW50UHJpb3JpdHlMZXZlbDtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAvLyBUaGlzIGlzIGEgZm9yayBvZiBydW5XaXRoUHJpb3JpdHksIGlubGluZWQgZm9yIHBlcmZvcm1hbmNlLlxuICAgIHZhciBwcmV2aW91c1ByaW9yaXR5TGV2ZWwgPSBjdXJyZW50UHJpb3JpdHlMZXZlbDtcbiAgICBjdXJyZW50UHJpb3JpdHlMZXZlbCA9IHBhcmVudFByaW9yaXR5TGV2ZWw7XG5cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGNhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGN1cnJlbnRQcmlvcml0eUxldmVsID0gcHJldmlvdXNQcmlvcml0eUxldmVsO1xuICAgIH1cbiAgfTtcbn1cblxuZnVuY3Rpb24gdW5zdGFibGVfc2NoZWR1bGVDYWxsYmFjayhwcmlvcml0eUxldmVsLCBjYWxsYmFjaywgb3B0aW9ucykge1xuICB2YXIgY3VycmVudFRpbWUgPSBleHBvcnRzLnVuc3RhYmxlX25vdygpO1xuICB2YXIgc3RhcnRUaW1lO1xuXG4gIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ29iamVjdCcgJiYgb3B0aW9ucyAhPT0gbnVsbCkge1xuICAgIHZhciBkZWxheSA9IG9wdGlvbnMuZGVsYXk7XG5cbiAgICBpZiAodHlwZW9mIGRlbGF5ID09PSAnbnVtYmVyJyAmJiBkZWxheSA+IDApIHtcbiAgICAgIHN0YXJ0VGltZSA9IGN1cnJlbnRUaW1lICsgZGVsYXk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXJ0VGltZSA9IGN1cnJlbnRUaW1lO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBzdGFydFRpbWUgPSBjdXJyZW50VGltZTtcbiAgfVxuXG4gIHZhciB0aW1lb3V0O1xuXG4gIHN3aXRjaCAocHJpb3JpdHlMZXZlbCkge1xuICAgIGNhc2UgSW1tZWRpYXRlUHJpb3JpdHk6XG4gICAgICB0aW1lb3V0ID0gSU1NRURJQVRFX1BSSU9SSVRZX1RJTUVPVVQ7XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgVXNlckJsb2NraW5nUHJpb3JpdHk6XG4gICAgICB0aW1lb3V0ID0gVVNFUl9CTE9DS0lOR19QUklPUklUWV9USU1FT1VUO1xuICAgICAgYnJlYWs7XG5cbiAgICBjYXNlIElkbGVQcmlvcml0eTpcbiAgICAgIHRpbWVvdXQgPSBJRExFX1BSSU9SSVRZX1RJTUVPVVQ7XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgTG93UHJpb3JpdHk6XG4gICAgICB0aW1lb3V0ID0gTE9XX1BSSU9SSVRZX1RJTUVPVVQ7XG4gICAgICBicmVhaztcblxuICAgIGNhc2UgTm9ybWFsUHJpb3JpdHk6XG4gICAgZGVmYXVsdDpcbiAgICAgIHRpbWVvdXQgPSBOT1JNQUxfUFJJT1JJVFlfVElNRU9VVDtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgdmFyIGV4cGlyYXRpb25UaW1lID0gc3RhcnRUaW1lICsgdGltZW91dDtcbiAgdmFyIG5ld1Rhc2sgPSB7XG4gICAgaWQ6IHRhc2tJZENvdW50ZXIrKyxcbiAgICBjYWxsYmFjazogY2FsbGJhY2ssXG4gICAgcHJpb3JpdHlMZXZlbDogcHJpb3JpdHlMZXZlbCxcbiAgICBzdGFydFRpbWU6IHN0YXJ0VGltZSxcbiAgICBleHBpcmF0aW9uVGltZTogZXhwaXJhdGlvblRpbWUsXG4gICAgc29ydEluZGV4OiAtMVxuICB9O1xuXG4gIGlmIChzdGFydFRpbWUgPiBjdXJyZW50VGltZSkge1xuICAgIC8vIFRoaXMgaXMgYSBkZWxheWVkIHRhc2suXG4gICAgbmV3VGFzay5zb3J0SW5kZXggPSBzdGFydFRpbWU7XG4gICAgcHVzaCh0aW1lclF1ZXVlLCBuZXdUYXNrKTtcblxuICAgIGlmIChwZWVrKHRhc2tRdWV1ZSkgPT09IG51bGwgJiYgbmV3VGFzayA9PT0gcGVlayh0aW1lclF1ZXVlKSkge1xuICAgICAgLy8gQWxsIHRhc2tzIGFyZSBkZWxheWVkLCBhbmQgdGhpcyBpcyB0aGUgdGFzayB3aXRoIHRoZSBlYXJsaWVzdCBkZWxheS5cbiAgICAgIGlmIChpc0hvc3RUaW1lb3V0U2NoZWR1bGVkKSB7XG4gICAgICAgIC8vIENhbmNlbCBhbiBleGlzdGluZyB0aW1lb3V0LlxuICAgICAgICBjYW5jZWxIb3N0VGltZW91dCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaXNIb3N0VGltZW91dFNjaGVkdWxlZCA9IHRydWU7XG4gICAgICB9IC8vIFNjaGVkdWxlIGEgdGltZW91dC5cblxuXG4gICAgICByZXF1ZXN0SG9zdFRpbWVvdXQoaGFuZGxlVGltZW91dCwgc3RhcnRUaW1lIC0gY3VycmVudFRpbWUpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBuZXdUYXNrLnNvcnRJbmRleCA9IGV4cGlyYXRpb25UaW1lO1xuICAgIHB1c2godGFza1F1ZXVlLCBuZXdUYXNrKTtcbiAgICAvLyB3YWl0IHVudGlsIHRoZSBuZXh0IHRpbWUgd2UgeWllbGQuXG5cblxuICAgIGlmICghaXNIb3N0Q2FsbGJhY2tTY2hlZHVsZWQgJiYgIWlzUGVyZm9ybWluZ1dvcmspIHtcbiAgICAgIGlzSG9zdENhbGxiYWNrU2NoZWR1bGVkID0gdHJ1ZTtcbiAgICAgIHJlcXVlc3RIb3N0Q2FsbGJhY2soZmx1c2hXb3JrKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbmV3VGFzaztcbn1cblxuZnVuY3Rpb24gdW5zdGFibGVfcGF1c2VFeGVjdXRpb24oKSB7XG59XG5cbmZ1bmN0aW9uIHVuc3RhYmxlX2NvbnRpbnVlRXhlY3V0aW9uKCkge1xuXG4gIGlmICghaXNIb3N0Q2FsbGJhY2tTY2hlZHVsZWQgJiYgIWlzUGVyZm9ybWluZ1dvcmspIHtcbiAgICBpc0hvc3RDYWxsYmFja1NjaGVkdWxlZCA9IHRydWU7XG4gICAgcmVxdWVzdEhvc3RDYWxsYmFjayhmbHVzaFdvcmspO1xuICB9XG59XG5cbmZ1bmN0aW9uIHVuc3RhYmxlX2dldEZpcnN0Q2FsbGJhY2tOb2RlKCkge1xuICByZXR1cm4gcGVlayh0YXNrUXVldWUpO1xufVxuXG5mdW5jdGlvbiB1bnN0YWJsZV9jYW5jZWxDYWxsYmFjayh0YXNrKSB7XG4gIC8vIHJlbW92ZSBmcm9tIHRoZSBxdWV1ZSBiZWNhdXNlIHlvdSBjYW4ndCByZW1vdmUgYXJiaXRyYXJ5IG5vZGVzIGZyb20gYW5cbiAgLy8gYXJyYXkgYmFzZWQgaGVhcCwgb25seSB0aGUgZmlyc3Qgb25lLilcblxuXG4gIHRhc2suY2FsbGJhY2sgPSBudWxsO1xufVxuXG5mdW5jdGlvbiB1bnN0YWJsZV9nZXRDdXJyZW50UHJpb3JpdHlMZXZlbCgpIHtcbiAgcmV0dXJuIGN1cnJlbnRQcmlvcml0eUxldmVsO1xufVxuXG52YXIgaXNNZXNzYWdlTG9vcFJ1bm5pbmcgPSBmYWxzZTtcbnZhciBzY2hlZHVsZWRIb3N0Q2FsbGJhY2sgPSBudWxsO1xudmFyIHRhc2tUaW1lb3V0SUQgPSAtMTsgLy8gU2NoZWR1bGVyIHBlcmlvZGljYWxseSB5aWVsZHMgaW4gY2FzZSB0aGVyZSBpcyBvdGhlciB3b3JrIG9uIHRoZSBtYWluXG4vLyB0aHJlYWQsIGxpa2UgdXNlciBldmVudHMuIEJ5IGRlZmF1bHQsIGl0IHlpZWxkcyBtdWx0aXBsZSB0aW1lcyBwZXIgZnJhbWUuXG4vLyBJdCBkb2VzIG5vdCBhdHRlbXB0IHRvIGFsaWduIHdpdGggZnJhbWUgYm91bmRhcmllcywgc2luY2UgbW9zdCB0YXNrcyBkb24ndFxuLy8gbmVlZCB0byBiZSBmcmFtZSBhbGlnbmVkOyBmb3IgdGhvc2UgdGhhdCBkbywgdXNlIHJlcXVlc3RBbmltYXRpb25GcmFtZS5cblxudmFyIGZyYW1lSW50ZXJ2YWwgPSBmcmFtZVlpZWxkTXM7XG52YXIgc3RhcnRUaW1lID0gLTE7XG5cbmZ1bmN0aW9uIHNob3VsZFlpZWxkVG9Ib3N0KCkge1xuICB2YXIgdGltZUVsYXBzZWQgPSBleHBvcnRzLnVuc3RhYmxlX25vdygpIC0gc3RhcnRUaW1lO1xuXG4gIGlmICh0aW1lRWxhcHNlZCA8IGZyYW1lSW50ZXJ2YWwpIHtcbiAgICAvLyBUaGUgbWFpbiB0aHJlYWQgaGFzIG9ubHkgYmVlbiBibG9ja2VkIGZvciBhIHJlYWxseSBzaG9ydCBhbW91bnQgb2YgdGltZTtcbiAgICAvLyBzbWFsbGVyIHRoYW4gYSBzaW5nbGUgZnJhbWUuIERvbid0IHlpZWxkIHlldC5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0gLy8gVGhlIG1haW4gdGhyZWFkIGhhcyBiZWVuIGJsb2NrZWQgZm9yIGEgbm9uLW5lZ2xpZ2libGUgYW1vdW50IG9mIHRpbWUuIFdlXG5cblxuICByZXR1cm4gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gcmVxdWVzdFBhaW50KCkge1xuXG59XG5cbmZ1bmN0aW9uIGZvcmNlRnJhbWVSYXRlKGZwcykge1xuICBpZiAoZnBzIDwgMCB8fCBmcHMgPiAxMjUpIHtcbiAgICAvLyBVc2luZyBjb25zb2xlWydlcnJvciddIHRvIGV2YWRlIEJhYmVsIGFuZCBFU0xpbnRcbiAgICBjb25zb2xlWydlcnJvciddKCdmb3JjZUZyYW1lUmF0ZSB0YWtlcyBhIHBvc2l0aXZlIGludCBiZXR3ZWVuIDAgYW5kIDEyNSwgJyArICdmb3JjaW5nIGZyYW1lIHJhdGVzIGhpZ2hlciB0aGFuIDEyNSBmcHMgaXMgbm90IHN1cHBvcnRlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChmcHMgPiAwKSB7XG4gICAgZnJhbWVJbnRlcnZhbCA9IE1hdGguZmxvb3IoMTAwMCAvIGZwcyk7XG4gIH0gZWxzZSB7XG4gICAgLy8gcmVzZXQgdGhlIGZyYW1lcmF0ZVxuICAgIGZyYW1lSW50ZXJ2YWwgPSBmcmFtZVlpZWxkTXM7XG4gIH1cbn1cblxudmFyIHBlcmZvcm1Xb3JrVW50aWxEZWFkbGluZSA9IGZ1bmN0aW9uICgpIHtcbiAgaWYgKHNjaGVkdWxlZEhvc3RDYWxsYmFjayAhPT0gbnVsbCkge1xuICAgIHZhciBjdXJyZW50VGltZSA9IGV4cG9ydHMudW5zdGFibGVfbm93KCk7IC8vIEtlZXAgdHJhY2sgb2YgdGhlIHN0YXJ0IHRpbWUgc28gd2UgY2FuIG1lYXN1cmUgaG93IGxvbmcgdGhlIG1haW4gdGhyZWFkXG4gICAgLy8gaGFzIGJlZW4gYmxvY2tlZC5cblxuICAgIHN0YXJ0VGltZSA9IGN1cnJlbnRUaW1lO1xuICAgIHZhciBoYXNUaW1lUmVtYWluaW5nID0gdHJ1ZTsgLy8gSWYgYSBzY2hlZHVsZXIgdGFzayB0aHJvd3MsIGV4aXQgdGhlIGN1cnJlbnQgYnJvd3NlciB0YXNrIHNvIHRoZVxuICAgIC8vIGVycm9yIGNhbiBiZSBvYnNlcnZlZC5cbiAgICAvL1xuICAgIC8vIEludGVudGlvbmFsbHkgbm90IHVzaW5nIGEgdHJ5LWNhdGNoLCBzaW5jZSB0aGF0IG1ha2VzIHNvbWUgZGVidWdnaW5nXG4gICAgLy8gdGVjaG5pcXVlcyBoYXJkZXIuIEluc3RlYWQsIGlmIGBzY2hlZHVsZWRIb3N0Q2FsbGJhY2tgIGVycm9ycywgdGhlblxuICAgIC8vIGBoYXNNb3JlV29ya2Agd2lsbCByZW1haW4gdHJ1ZSwgYW5kIHdlJ2xsIGNvbnRpbnVlIHRoZSB3b3JrIGxvb3AuXG5cbiAgICB2YXIgaGFzTW9yZVdvcmsgPSB0cnVlO1xuXG4gICAgdHJ5IHtcbiAgICAgIGhhc01vcmVXb3JrID0gc2NoZWR1bGVkSG9zdENhbGxiYWNrKGhhc1RpbWVSZW1haW5pbmcsIGN1cnJlbnRUaW1lKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKGhhc01vcmVXb3JrKSB7XG4gICAgICAgIC8vIElmIHRoZXJlJ3MgbW9yZSB3b3JrLCBzY2hlZHVsZSB0aGUgbmV4dCBtZXNzYWdlIGV2ZW50IGF0IHRoZSBlbmRcbiAgICAgICAgLy8gb2YgdGhlIHByZWNlZGluZyBvbmUuXG4gICAgICAgIHNjaGVkdWxlUGVyZm9ybVdvcmtVbnRpbERlYWRsaW5lKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpc01lc3NhZ2VMb29wUnVubmluZyA9IGZhbHNlO1xuICAgICAgICBzY2hlZHVsZWRIb3N0Q2FsbGJhY2sgPSBudWxsO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpc01lc3NhZ2VMb29wUnVubmluZyA9IGZhbHNlO1xuICB9IC8vIFlpZWxkaW5nIHRvIHRoZSBicm93c2VyIHdpbGwgZ2l2ZSBpdCBhIGNoYW5jZSB0byBwYWludCwgc28gd2UgY2FuXG59O1xuXG52YXIgc2NoZWR1bGVQZXJmb3JtV29ya1VudGlsRGVhZGxpbmU7XG5cbmlmICh0eXBlb2YgbG9jYWxTZXRJbW1lZGlhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gTm9kZS5qcyBhbmQgb2xkIElFLlxuICAvLyBUaGVyZSdzIGEgZmV3IHJlYXNvbnMgZm9yIHdoeSB3ZSBwcmVmZXIgc2V0SW1tZWRpYXRlLlxuICAvL1xuICAvLyBVbmxpa2UgTWVzc2FnZUNoYW5uZWwsIGl0IGRvZXNuJ3QgcHJldmVudCBhIE5vZGUuanMgcHJvY2VzcyBmcm9tIGV4aXRpbmcuXG4gIC8vIChFdmVuIHRob3VnaCB0aGlzIGlzIGEgRE9NIGZvcmsgb2YgdGhlIFNjaGVkdWxlciwgeW91IGNvdWxkIGdldCBoZXJlXG4gIC8vIHdpdGggYSBtaXggb2YgTm9kZS5qcyAxNSssIHdoaWNoIGhhcyBhIE1lc3NhZ2VDaGFubmVsLCBhbmQganNkb20uKVxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QvaXNzdWVzLzIwNzU2XG4gIC8vXG4gIC8vIEJ1dCBhbHNvLCBpdCBydW5zIGVhcmxpZXIgd2hpY2ggaXMgdGhlIHNlbWFudGljIHdlIHdhbnQuXG4gIC8vIElmIG90aGVyIGJyb3dzZXJzIGV2ZXIgaW1wbGVtZW50IGl0LCBpdCdzIGJldHRlciB0byB1c2UgaXQuXG4gIC8vIEFsdGhvdWdoIGJvdGggb2YgdGhlc2Ugd291bGQgYmUgaW5mZXJpb3IgdG8gbmF0aXZlIHNjaGVkdWxpbmcuXG4gIHNjaGVkdWxlUGVyZm9ybVdvcmtVbnRpbERlYWRsaW5lID0gZnVuY3Rpb24gKCkge1xuICAgIGxvY2FsU2V0SW1tZWRpYXRlKHBlcmZvcm1Xb3JrVW50aWxEZWFkbGluZSk7XG4gIH07XG59IGVsc2UgaWYgKHR5cGVvZiBNZXNzYWdlQ2hhbm5lbCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgLy8gRE9NIGFuZCBXb3JrZXIgZW52aXJvbm1lbnRzLlxuICAvLyBXZSBwcmVmZXIgTWVzc2FnZUNoYW5uZWwgYmVjYXVzZSBvZiB0aGUgNG1zIHNldFRpbWVvdXQgY2xhbXBpbmcuXG4gIHZhciBjaGFubmVsID0gbmV3IE1lc3NhZ2VDaGFubmVsKCk7XG4gIHZhciBwb3J0ID0gY2hhbm5lbC5wb3J0MjtcbiAgY2hhbm5lbC5wb3J0MS5vbm1lc3NhZ2UgPSBwZXJmb3JtV29ya1VudGlsRGVhZGxpbmU7XG5cbiAgc2NoZWR1bGVQZXJmb3JtV29ya1VudGlsRGVhZGxpbmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgcG9ydC5wb3N0TWVzc2FnZShudWxsKTtcbiAgfTtcbn0gZWxzZSB7XG4gIC8vIFdlIHNob3VsZCBvbmx5IGZhbGxiYWNrIGhlcmUgaW4gbm9uLWJyb3dzZXIgZW52aXJvbm1lbnRzLlxuICBzY2hlZHVsZVBlcmZvcm1Xb3JrVW50aWxEZWFkbGluZSA9IGZ1bmN0aW9uICgpIHtcbiAgICBsb2NhbFNldFRpbWVvdXQocGVyZm9ybVdvcmtVbnRpbERlYWRsaW5lLCAwKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVxdWVzdEhvc3RDYWxsYmFjayhjYWxsYmFjaykge1xuICBzY2hlZHVsZWRIb3N0Q2FsbGJhY2sgPSBjYWxsYmFjaztcblxuICBpZiAoIWlzTWVzc2FnZUxvb3BSdW5uaW5nKSB7XG4gICAgaXNNZXNzYWdlTG9vcFJ1bm5pbmcgPSB0cnVlO1xuICAgIHNjaGVkdWxlUGVyZm9ybVdvcmtVbnRpbERlYWRsaW5lKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVxdWVzdEhvc3RUaW1lb3V0KGNhbGxiYWNrLCBtcykge1xuICB0YXNrVGltZW91dElEID0gbG9jYWxTZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICBjYWxsYmFjayhleHBvcnRzLnVuc3RhYmxlX25vdygpKTtcbiAgfSwgbXMpO1xufVxuXG5mdW5jdGlvbiBjYW5jZWxIb3N0VGltZW91dCgpIHtcbiAgbG9jYWxDbGVhclRpbWVvdXQodGFza1RpbWVvdXRJRCk7XG4gIHRhc2tUaW1lb3V0SUQgPSAtMTtcbn1cblxudmFyIHVuc3RhYmxlX3JlcXVlc3RQYWludCA9IHJlcXVlc3RQYWludDtcbnZhciB1bnN0YWJsZV9Qcm9maWxpbmcgPSAgbnVsbDtcblxuZXhwb3J0cy51bnN0YWJsZV9JZGxlUHJpb3JpdHkgPSBJZGxlUHJpb3JpdHk7XG5leHBvcnRzLnVuc3RhYmxlX0ltbWVkaWF0ZVByaW9yaXR5ID0gSW1tZWRpYXRlUHJpb3JpdHk7XG5leHBvcnRzLnVuc3RhYmxlX0xvd1ByaW9yaXR5ID0gTG93UHJpb3JpdHk7XG5leHBvcnRzLnVuc3RhYmxlX05vcm1hbFByaW9yaXR5ID0gTm9ybWFsUHJpb3JpdHk7XG5leHBvcnRzLnVuc3RhYmxlX1Byb2ZpbGluZyA9IHVuc3RhYmxlX1Byb2ZpbGluZztcbmV4cG9ydHMudW5zdGFibGVfVXNlckJsb2NraW5nUHJpb3JpdHkgPSBVc2VyQmxvY2tpbmdQcmlvcml0eTtcbmV4cG9ydHMudW5zdGFibGVfY2FuY2VsQ2FsbGJhY2sgPSB1bnN0YWJsZV9jYW5jZWxDYWxsYmFjaztcbmV4cG9ydHMudW5zdGFibGVfY29udGludWVFeGVjdXRpb24gPSB1bnN0YWJsZV9jb250aW51ZUV4ZWN1dGlvbjtcbmV4cG9ydHMudW5zdGFibGVfZm9yY2VGcmFtZVJhdGUgPSBmb3JjZUZyYW1lUmF0ZTtcbmV4cG9ydHMudW5zdGFibGVfZ2V0Q3VycmVudFByaW9yaXR5TGV2ZWwgPSB1bnN0YWJsZV9nZXRDdXJyZW50UHJpb3JpdHlMZXZlbDtcbmV4cG9ydHMudW5zdGFibGVfZ2V0Rmlyc3RDYWxsYmFja05vZGUgPSB1bnN0YWJsZV9nZXRGaXJzdENhbGxiYWNrTm9kZTtcbmV4cG9ydHMudW5zdGFibGVfbmV4dCA9IHVuc3RhYmxlX25leHQ7XG5leHBvcnRzLnVuc3RhYmxlX3BhdXNlRXhlY3V0aW9uID0gdW5zdGFibGVfcGF1c2VFeGVjdXRpb247XG5leHBvcnRzLnVuc3RhYmxlX3JlcXVlc3RQYWludCA9IHVuc3RhYmxlX3JlcXVlc3RQYWludDtcbmV4cG9ydHMudW5zdGFibGVfcnVuV2l0aFByaW9yaXR5ID0gdW5zdGFibGVfcnVuV2l0aFByaW9yaXR5O1xuZXhwb3J0cy51bnN0YWJsZV9zY2hlZHVsZUNhbGxiYWNrID0gdW5zdGFibGVfc2NoZWR1bGVDYWxsYmFjaztcbmV4cG9ydHMudW5zdGFibGVfc2hvdWxkWWllbGQgPSBzaG91bGRZaWVsZFRvSG9zdDtcbmV4cG9ydHMudW5zdGFibGVfd3JhcENhbGxiYWNrID0gdW5zdGFibGVfd3JhcENhbGxiYWNrO1xuICAgICAgICAgIC8qIGdsb2JhbCBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18gKi9cbmlmIChcbiAgdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5yZWdpc3RlckludGVybmFsTW9kdWxlU3RvcCA9PT1cbiAgICAnZnVuY3Rpb24nXG4pIHtcbiAgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wKG5ldyBFcnJvcigpKTtcbn1cbiAgICAgICAgXG4gIH0pKCk7XG59XG4iLCJleHBvcnQgY29uc3QgZXBzaWxvbiA9IDEuMTEwMjIzMDI0NjI1MTU2NWUtMTY7XG5leHBvcnQgY29uc3Qgc3BsaXR0ZXIgPSAxMzQyMTc3Mjk7XG5leHBvcnQgY29uc3QgcmVzdWx0ZXJyYm91bmQgPSAoMyArIDggKiBlcHNpbG9uKSAqIGVwc2lsb247XG5cbi8vIGZhc3RfZXhwYW5zaW9uX3N1bV96ZXJvZWxpbSByb3V0aW5lIGZyb20gb3JpdGluYWwgY29kZVxuZXhwb3J0IGZ1bmN0aW9uIHN1bShlbGVuLCBlLCBmbGVuLCBmLCBoKSB7XG4gICAgbGV0IFEsIFFuZXcsIGhoLCBidmlydDtcbiAgICBsZXQgZW5vdyA9IGVbMF07XG4gICAgbGV0IGZub3cgPSBmWzBdO1xuICAgIGxldCBlaW5kZXggPSAwO1xuICAgIGxldCBmaW5kZXggPSAwO1xuICAgIGlmICgoZm5vdyA+IGVub3cpID09PSAoZm5vdyA+IC1lbm93KSkge1xuICAgICAgICBRID0gZW5vdztcbiAgICAgICAgZW5vdyA9IGVbKytlaW5kZXhdO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIFEgPSBmbm93O1xuICAgICAgICBmbm93ID0gZlsrK2ZpbmRleF07XG4gICAgfVxuICAgIGxldCBoaW5kZXggPSAwO1xuICAgIGlmIChlaW5kZXggPCBlbGVuICYmIGZpbmRleCA8IGZsZW4pIHtcbiAgICAgICAgaWYgKChmbm93ID4gZW5vdykgPT09IChmbm93ID4gLWVub3cpKSB7XG4gICAgICAgICAgICBRbmV3ID0gZW5vdyArIFE7XG4gICAgICAgICAgICBoaCA9IFEgLSAoUW5ldyAtIGVub3cpO1xuICAgICAgICAgICAgZW5vdyA9IGVbKytlaW5kZXhdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgUW5ldyA9IGZub3cgKyBRO1xuICAgICAgICAgICAgaGggPSBRIC0gKFFuZXcgLSBmbm93KTtcbiAgICAgICAgICAgIGZub3cgPSBmWysrZmluZGV4XTtcbiAgICAgICAgfVxuICAgICAgICBRID0gUW5ldztcbiAgICAgICAgaWYgKGhoICE9PSAwKSB7XG4gICAgICAgICAgICBoW2hpbmRleCsrXSA9IGhoO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlIChlaW5kZXggPCBlbGVuICYmIGZpbmRleCA8IGZsZW4pIHtcbiAgICAgICAgICAgIGlmICgoZm5vdyA+IGVub3cpID09PSAoZm5vdyA+IC1lbm93KSkge1xuICAgICAgICAgICAgICAgIFFuZXcgPSBRICsgZW5vdztcbiAgICAgICAgICAgICAgICBidmlydCA9IFFuZXcgLSBRO1xuICAgICAgICAgICAgICAgIGhoID0gUSAtIChRbmV3IC0gYnZpcnQpICsgKGVub3cgLSBidmlydCk7XG4gICAgICAgICAgICAgICAgZW5vdyA9IGVbKytlaW5kZXhdO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBRbmV3ID0gUSArIGZub3c7XG4gICAgICAgICAgICAgICAgYnZpcnQgPSBRbmV3IC0gUTtcbiAgICAgICAgICAgICAgICBoaCA9IFEgLSAoUW5ldyAtIGJ2aXJ0KSArIChmbm93IC0gYnZpcnQpO1xuICAgICAgICAgICAgICAgIGZub3cgPSBmWysrZmluZGV4XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFEgPSBRbmV3O1xuICAgICAgICAgICAgaWYgKGhoICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgaFtoaW5kZXgrK10gPSBoaDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICB3aGlsZSAoZWluZGV4IDwgZWxlbikge1xuICAgICAgICBRbmV3ID0gUSArIGVub3c7XG4gICAgICAgIGJ2aXJ0ID0gUW5ldyAtIFE7XG4gICAgICAgIGhoID0gUSAtIChRbmV3IC0gYnZpcnQpICsgKGVub3cgLSBidmlydCk7XG4gICAgICAgIGVub3cgPSBlWysrZWluZGV4XTtcbiAgICAgICAgUSA9IFFuZXc7XG4gICAgICAgIGlmIChoaCAhPT0gMCkge1xuICAgICAgICAgICAgaFtoaW5kZXgrK10gPSBoaDtcbiAgICAgICAgfVxuICAgIH1cbiAgICB3aGlsZSAoZmluZGV4IDwgZmxlbikge1xuICAgICAgICBRbmV3ID0gUSArIGZub3c7XG4gICAgICAgIGJ2aXJ0ID0gUW5ldyAtIFE7XG4gICAgICAgIGhoID0gUSAtIChRbmV3IC0gYnZpcnQpICsgKGZub3cgLSBidmlydCk7XG4gICAgICAgIGZub3cgPSBmWysrZmluZGV4XTtcbiAgICAgICAgUSA9IFFuZXc7XG4gICAgICAgIGlmIChoaCAhPT0gMCkge1xuICAgICAgICAgICAgaFtoaW5kZXgrK10gPSBoaDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoUSAhPT0gMCB8fCBoaW5kZXggPT09IDApIHtcbiAgICAgICAgaFtoaW5kZXgrK10gPSBRO1xuICAgIH1cbiAgICByZXR1cm4gaGluZGV4O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc3VtX3RocmVlKGFsZW4sIGEsIGJsZW4sIGIsIGNsZW4sIGMsIHRtcCwgb3V0KSB7XG4gICAgcmV0dXJuIHN1bShzdW0oYWxlbiwgYSwgYmxlbiwgYiwgdG1wKSwgdG1wLCBjbGVuLCBjLCBvdXQpO1xufVxuXG4vLyBzY2FsZV9leHBhbnNpb25femVyb2VsaW0gcm91dGluZSBmcm9tIG9yaXRpbmFsIGNvZGVcbmV4cG9ydCBmdW5jdGlvbiBzY2FsZShlbGVuLCBlLCBiLCBoKSB7XG4gICAgbGV0IFEsIHN1bSwgaGgsIHByb2R1Y3QxLCBwcm9kdWN0MDtcbiAgICBsZXQgYnZpcnQsIGMsIGFoaSwgYWxvLCBiaGksIGJsbztcblxuICAgIGMgPSBzcGxpdHRlciAqIGI7XG4gICAgYmhpID0gYyAtIChjIC0gYik7XG4gICAgYmxvID0gYiAtIGJoaTtcbiAgICBsZXQgZW5vdyA9IGVbMF07XG4gICAgUSA9IGVub3cgKiBiO1xuICAgIGMgPSBzcGxpdHRlciAqIGVub3c7XG4gICAgYWhpID0gYyAtIChjIC0gZW5vdyk7XG4gICAgYWxvID0gZW5vdyAtIGFoaTtcbiAgICBoaCA9IGFsbyAqIGJsbyAtIChRIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBsZXQgaGluZGV4ID0gMDtcbiAgICBpZiAoaGggIT09IDApIHtcbiAgICAgICAgaFtoaW5kZXgrK10gPSBoaDtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBlbGVuOyBpKyspIHtcbiAgICAgICAgZW5vdyA9IGVbaV07XG4gICAgICAgIHByb2R1Y3QxID0gZW5vdyAqIGI7XG4gICAgICAgIGMgPSBzcGxpdHRlciAqIGVub3c7XG4gICAgICAgIGFoaSA9IGMgLSAoYyAtIGVub3cpO1xuICAgICAgICBhbG8gPSBlbm93IC0gYWhpO1xuICAgICAgICBwcm9kdWN0MCA9IGFsbyAqIGJsbyAtIChwcm9kdWN0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgICAgIHN1bSA9IFEgKyBwcm9kdWN0MDtcbiAgICAgICAgYnZpcnQgPSBzdW0gLSBRO1xuICAgICAgICBoaCA9IFEgLSAoc3VtIC0gYnZpcnQpICsgKHByb2R1Y3QwIC0gYnZpcnQpO1xuICAgICAgICBpZiAoaGggIT09IDApIHtcbiAgICAgICAgICAgIGhbaGluZGV4KytdID0gaGg7XG4gICAgICAgIH1cbiAgICAgICAgUSA9IHByb2R1Y3QxICsgc3VtO1xuICAgICAgICBoaCA9IHN1bSAtIChRIC0gcHJvZHVjdDEpO1xuICAgICAgICBpZiAoaGggIT09IDApIHtcbiAgICAgICAgICAgIGhbaGluZGV4KytdID0gaGg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKFEgIT09IDAgfHwgaGluZGV4ID09PSAwKSB7XG4gICAgICAgIGhbaGluZGV4KytdID0gUTtcbiAgICB9XG4gICAgcmV0dXJuIGhpbmRleDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5lZ2F0ZShlbGVuLCBlKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlbGVuOyBpKyspIGVbaV0gPSAtZVtpXTtcbiAgICByZXR1cm4gZWxlbjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVzdGltYXRlKGVsZW4sIGUpIHtcbiAgICBsZXQgUSA9IGVbMF07XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBlbGVuOyBpKyspIFEgKz0gZVtpXTtcbiAgICByZXR1cm4gUTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZlYyhuKSB7XG4gICAgcmV0dXJuIG5ldyBGbG9hdDY0QXJyYXkobik7XG59XG4iLCJpbXBvcnQge2Vwc2lsb24sIHNwbGl0dGVyLCByZXN1bHRlcnJib3VuZCwgZXN0aW1hdGUsIHZlYywgc3VtfSBmcm9tICcuL3V0aWwuanMnO1xuXG5jb25zdCBjY3dlcnJib3VuZEEgPSAoMyArIDE2ICogZXBzaWxvbikgKiBlcHNpbG9uO1xuY29uc3QgY2N3ZXJyYm91bmRCID0gKDIgKyAxMiAqIGVwc2lsb24pICogZXBzaWxvbjtcbmNvbnN0IGNjd2VycmJvdW5kQyA9ICg5ICsgNjQgKiBlcHNpbG9uKSAqIGVwc2lsb24gKiBlcHNpbG9uO1xuXG5jb25zdCBCID0gdmVjKDQpO1xuY29uc3QgQzEgPSB2ZWMoOCk7XG5jb25zdCBDMiA9IHZlYygxMik7XG5jb25zdCBEID0gdmVjKDE2KTtcbmNvbnN0IHUgPSB2ZWMoNCk7XG5cbmZ1bmN0aW9uIG9yaWVudDJkYWRhcHQoYXgsIGF5LCBieCwgYnksIGN4LCBjeSwgZGV0c3VtKSB7XG4gICAgbGV0IGFjeHRhaWwsIGFjeXRhaWwsIGJjeHRhaWwsIGJjeXRhaWw7XG4gICAgbGV0IGJ2aXJ0LCBjLCBhaGksIGFsbywgYmhpLCBibG8sIF9pLCBfaiwgXzAsIHMxLCBzMCwgdDEsIHQwLCB1MztcblxuICAgIGNvbnN0IGFjeCA9IGF4IC0gY3g7XG4gICAgY29uc3QgYmN4ID0gYnggLSBjeDtcbiAgICBjb25zdCBhY3kgPSBheSAtIGN5O1xuICAgIGNvbnN0IGJjeSA9IGJ5IC0gY3k7XG5cbiAgICBzMSA9IGFjeCAqIGJjeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhY3g7XG4gICAgYWhpID0gYyAtIChjIC0gYWN4KTtcbiAgICBhbG8gPSBhY3ggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmN5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGJjeSk7XG4gICAgYmxvID0gYmN5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGFjeSAqIGJjeDtcbiAgICBjID0gc3BsaXR0ZXIgKiBhY3k7XG4gICAgYWhpID0gYyAtIChjIC0gYWN5KTtcbiAgICBhbG8gPSBhY3kgLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmN4O1xuICAgIGJoaSA9IGMgLSAoYyAtIGJjeCk7XG4gICAgYmxvID0gYmN4IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIEJbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBCWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgdTMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICBCWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgQlszXSA9IHUzO1xuXG4gICAgbGV0IGRldCA9IGVzdGltYXRlKDQsIEIpO1xuICAgIGxldCBlcnJib3VuZCA9IGNjd2VycmJvdW5kQiAqIGRldHN1bTtcbiAgICBpZiAoZGV0ID49IGVycmJvdW5kIHx8IC1kZXQgPj0gZXJyYm91bmQpIHtcbiAgICAgICAgcmV0dXJuIGRldDtcbiAgICB9XG5cbiAgICBidmlydCA9IGF4IC0gYWN4O1xuICAgIGFjeHRhaWwgPSBheCAtIChhY3ggKyBidmlydCkgKyAoYnZpcnQgLSBjeCk7XG4gICAgYnZpcnQgPSBieCAtIGJjeDtcbiAgICBiY3h0YWlsID0gYnggLSAoYmN4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gY3gpO1xuICAgIGJ2aXJ0ID0gYXkgLSBhY3k7XG4gICAgYWN5dGFpbCA9IGF5IC0gKGFjeSArIGJ2aXJ0KSArIChidmlydCAtIGN5KTtcbiAgICBidmlydCA9IGJ5IC0gYmN5O1xuICAgIGJjeXRhaWwgPSBieSAtIChiY3kgKyBidmlydCkgKyAoYnZpcnQgLSBjeSk7XG5cbiAgICBpZiAoYWN4dGFpbCA9PT0gMCAmJiBhY3l0YWlsID09PSAwICYmIGJjeHRhaWwgPT09IDAgJiYgYmN5dGFpbCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gZGV0O1xuICAgIH1cblxuICAgIGVycmJvdW5kID0gY2N3ZXJyYm91bmRDICogZGV0c3VtICsgcmVzdWx0ZXJyYm91bmQgKiBNYXRoLmFicyhkZXQpO1xuICAgIGRldCArPSAoYWN4ICogYmN5dGFpbCArIGJjeSAqIGFjeHRhaWwpIC0gKGFjeSAqIGJjeHRhaWwgKyBiY3ggKiBhY3l0YWlsKTtcbiAgICBpZiAoZGV0ID49IGVycmJvdW5kIHx8IC1kZXQgPj0gZXJyYm91bmQpIHJldHVybiBkZXQ7XG5cbiAgICBzMSA9IGFjeHRhaWwgKiBiY3k7XG4gICAgYyA9IHNwbGl0dGVyICogYWN4dGFpbDtcbiAgICBhaGkgPSBjIC0gKGMgLSBhY3h0YWlsKTtcbiAgICBhbG8gPSBhY3h0YWlsIC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGJjeTtcbiAgICBiaGkgPSBjIC0gKGMgLSBiY3kpO1xuICAgIGJsbyA9IGJjeSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBhY3l0YWlsICogYmN4O1xuICAgIGMgPSBzcGxpdHRlciAqIGFjeXRhaWw7XG4gICAgYWhpID0gYyAtIChjIC0gYWN5dGFpbCk7XG4gICAgYWxvID0gYWN5dGFpbCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiY3g7XG4gICAgYmhpID0gYyAtIChjIC0gYmN4KTtcbiAgICBibG8gPSBiY3ggLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgdVswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIHVbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIHVbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICB1WzNdID0gdTM7XG4gICAgY29uc3QgQzFsZW4gPSBzdW0oNCwgQiwgNCwgdSwgQzEpO1xuXG4gICAgczEgPSBhY3ggKiBiY3l0YWlsO1xuICAgIGMgPSBzcGxpdHRlciAqIGFjeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBhY3gpO1xuICAgIGFsbyA9IGFjeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiY3l0YWlsO1xuICAgIGJoaSA9IGMgLSAoYyAtIGJjeXRhaWwpO1xuICAgIGJsbyA9IGJjeXRhaWwgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gYWN5ICogYmN4dGFpbDtcbiAgICBjID0gc3BsaXR0ZXIgKiBhY3k7XG4gICAgYWhpID0gYyAtIChjIC0gYWN5KTtcbiAgICBhbG8gPSBhY3kgLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmN4dGFpbDtcbiAgICBiaGkgPSBjIC0gKGMgLSBiY3h0YWlsKTtcbiAgICBibG8gPSBiY3h0YWlsIC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIHVbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICB1WzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgdTMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICB1WzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgdVszXSA9IHUzO1xuICAgIGNvbnN0IEMybGVuID0gc3VtKEMxbGVuLCBDMSwgNCwgdSwgQzIpO1xuXG4gICAgczEgPSBhY3h0YWlsICogYmN5dGFpbDtcbiAgICBjID0gc3BsaXR0ZXIgKiBhY3h0YWlsO1xuICAgIGFoaSA9IGMgLSAoYyAtIGFjeHRhaWwpO1xuICAgIGFsbyA9IGFjeHRhaWwgLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmN5dGFpbDtcbiAgICBiaGkgPSBjIC0gKGMgLSBiY3l0YWlsKTtcbiAgICBibG8gPSBiY3l0YWlsIC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGFjeXRhaWwgKiBiY3h0YWlsO1xuICAgIGMgPSBzcGxpdHRlciAqIGFjeXRhaWw7XG4gICAgYWhpID0gYyAtIChjIC0gYWN5dGFpbCk7XG4gICAgYWxvID0gYWN5dGFpbCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiY3h0YWlsO1xuICAgIGJoaSA9IGMgLSAoYyAtIGJjeHRhaWwpO1xuICAgIGJsbyA9IGJjeHRhaWwgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgdVswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIHVbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIHVbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICB1WzNdID0gdTM7XG4gICAgY29uc3QgRGxlbiA9IHN1bShDMmxlbiwgQzIsIDQsIHUsIEQpO1xuXG4gICAgcmV0dXJuIERbRGxlbiAtIDFdO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gb3JpZW50MmQoYXgsIGF5LCBieCwgYnksIGN4LCBjeSkge1xuICAgIGNvbnN0IGRldGxlZnQgPSAoYXkgLSBjeSkgKiAoYnggLSBjeCk7XG4gICAgY29uc3QgZGV0cmlnaHQgPSAoYXggLSBjeCkgKiAoYnkgLSBjeSk7XG4gICAgY29uc3QgZGV0ID0gZGV0bGVmdCAtIGRldHJpZ2h0O1xuXG4gICAgY29uc3QgZGV0c3VtID0gTWF0aC5hYnMoZGV0bGVmdCArIGRldHJpZ2h0KTtcbiAgICBpZiAoTWF0aC5hYnMoZGV0KSA+PSBjY3dlcnJib3VuZEEgKiBkZXRzdW0pIHJldHVybiBkZXQ7XG5cbiAgICByZXR1cm4gLW9yaWVudDJkYWRhcHQoYXgsIGF5LCBieCwgYnksIGN4LCBjeSwgZGV0c3VtKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG9yaWVudDJkZmFzdChheCwgYXksIGJ4LCBieSwgY3gsIGN5KSB7XG4gICAgcmV0dXJuIChheSAtIGN5KSAqIChieCAtIGN4KSAtIChheCAtIGN4KSAqIChieSAtIGN5KTtcbn1cbiIsImltcG9ydCB7ZXBzaWxvbiwgc3BsaXR0ZXIsIHJlc3VsdGVycmJvdW5kLCBlc3RpbWF0ZSwgdmVjLCBzdW0sIHNjYWxlfSBmcm9tICcuL3V0aWwuanMnO1xuXG5jb25zdCBvM2RlcnJib3VuZEEgPSAoNyArIDU2ICogZXBzaWxvbikgKiBlcHNpbG9uO1xuY29uc3QgbzNkZXJyYm91bmRCID0gKDMgKyAyOCAqIGVwc2lsb24pICogZXBzaWxvbjtcbmNvbnN0IG8zZGVycmJvdW5kQyA9ICgyNiArIDI4OCAqIGVwc2lsb24pICogZXBzaWxvbiAqIGVwc2lsb247XG5cbmNvbnN0IGJjID0gdmVjKDQpO1xuY29uc3QgY2EgPSB2ZWMoNCk7XG5jb25zdCBhYiA9IHZlYyg0KTtcbmNvbnN0IGF0X2IgPSB2ZWMoNCk7XG5jb25zdCBhdF9jID0gdmVjKDQpO1xuY29uc3QgYnRfYyA9IHZlYyg0KTtcbmNvbnN0IGJ0X2EgPSB2ZWMoNCk7XG5jb25zdCBjdF9hID0gdmVjKDQpO1xuY29uc3QgY3RfYiA9IHZlYyg0KTtcbmNvbnN0IGJjdCA9IHZlYyg4KTtcbmNvbnN0IGNhdCA9IHZlYyg4KTtcbmNvbnN0IGFidCA9IHZlYyg4KTtcbmNvbnN0IHUgPSB2ZWMoNCk7XG5cbmNvbnN0IF84ID0gdmVjKDgpO1xuY29uc3QgXzhiID0gdmVjKDgpO1xuY29uc3QgXzE2ID0gdmVjKDgpO1xuY29uc3QgXzEyID0gdmVjKDEyKTtcblxubGV0IGZpbiA9IHZlYygxOTIpO1xubGV0IGZpbjIgPSB2ZWMoMTkyKTtcblxuZnVuY3Rpb24gZmluYWRkKGZpbmxlbiwgYWxlbiwgYSkge1xuICAgIGZpbmxlbiA9IHN1bShmaW5sZW4sIGZpbiwgYWxlbiwgYSwgZmluMik7XG4gICAgY29uc3QgdG1wID0gZmluOyBmaW4gPSBmaW4yOyBmaW4yID0gdG1wO1xuICAgIHJldHVybiBmaW5sZW47XG59XG5cbmZ1bmN0aW9uIHRhaWxpbml0KHh0YWlsLCB5dGFpbCwgYXgsIGF5LCBieCwgYnksIGEsIGIpIHtcbiAgICBsZXQgYnZpcnQsIGMsIGFoaSwgYWxvLCBiaGksIGJsbywgX2ksIF9qLCBfaywgXzAsIHMxLCBzMCwgdDEsIHQwLCB1MywgbmVnYXRlO1xuICAgIGlmICh4dGFpbCA9PT0gMCkge1xuICAgICAgICBpZiAoeXRhaWwgPT09IDApIHtcbiAgICAgICAgICAgIGFbMF0gPSAwO1xuICAgICAgICAgICAgYlswXSA9IDA7XG4gICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5lZ2F0ZSA9IC15dGFpbDtcbiAgICAgICAgICAgIHMxID0gbmVnYXRlICogYXg7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBuZWdhdGU7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBuZWdhdGUpO1xuICAgICAgICAgICAgYWxvID0gbmVnYXRlIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYXg7XG4gICAgICAgICAgICBiaGkgPSBjIC0gKGMgLSBheCk7XG4gICAgICAgICAgICBibG8gPSBheCAtIGJoaTtcbiAgICAgICAgICAgIGFbMF0gPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgYVsxXSA9IHMxO1xuICAgICAgICAgICAgczEgPSB5dGFpbCAqIGJ4O1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogeXRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSB5dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSB5dGFpbCAtIGFoaTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJ4O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYngpO1xuICAgICAgICAgICAgYmxvID0gYnggLSBiaGk7XG4gICAgICAgICAgICBiWzBdID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIGJbMV0gPSBzMTtcbiAgICAgICAgICAgIHJldHVybiAyO1xuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHl0YWlsID09PSAwKSB7XG4gICAgICAgICAgICBzMSA9IHh0YWlsICogYXk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiB4dGFpbDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYXk7XG4gICAgICAgICAgICBiaGkgPSBjIC0gKGMgLSBheSk7XG4gICAgICAgICAgICBibG8gPSBheSAtIGJoaTtcbiAgICAgICAgICAgIGFbMF0gPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgYVsxXSA9IHMxO1xuICAgICAgICAgICAgbmVnYXRlID0gLXh0YWlsO1xuICAgICAgICAgICAgczEgPSBuZWdhdGUgKiBieTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIG5lZ2F0ZTtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIG5lZ2F0ZSk7XG4gICAgICAgICAgICBhbG8gPSBuZWdhdGUgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBieTtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIGJ5KTtcbiAgICAgICAgICAgIGJsbyA9IGJ5IC0gYmhpO1xuICAgICAgICAgICAgYlswXSA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgICAgICAgICBiWzFdID0gczE7XG4gICAgICAgICAgICByZXR1cm4gMjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHMxID0geHRhaWwgKiBheTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0geHRhaWwpO1xuICAgICAgICAgICAgYWxvID0geHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBheTtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIGF5KTtcbiAgICAgICAgICAgIGJsbyA9IGF5IC0gYmhpO1xuICAgICAgICAgICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgdDEgPSB5dGFpbCAqIGF4O1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogeXRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSB5dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSB5dGFpbCAtIGFoaTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGF4O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYXgpO1xuICAgICAgICAgICAgYmxvID0gYXggLSBiaGk7XG4gICAgICAgICAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgICAgICAgICBfaSA9IHMwIC0gdDA7XG4gICAgICAgICAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgICAgICAgICBhWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgICAgICAgICBfaiA9IHMxICsgX2k7XG4gICAgICAgICAgICBidmlydCA9IF9qIC0gczE7XG4gICAgICAgICAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2kgPSBfMCAtIHQxO1xuICAgICAgICAgICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgICAgICAgICAgYVsxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgICAgICAgICAgdTMgPSBfaiArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgICAgICAgICAgYVsyXSA9IF9qIC0gKHUzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgICAgICAgICAgYVszXSA9IHUzO1xuICAgICAgICAgICAgczEgPSB5dGFpbCAqIGJ4O1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogeXRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSB5dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSB5dGFpbCAtIGFoaTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJ4O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYngpO1xuICAgICAgICAgICAgYmxvID0gYnggLSBiaGk7XG4gICAgICAgICAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgICAgICAgICB0MSA9IHh0YWlsICogYnk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiB4dGFpbDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYnk7XG4gICAgICAgICAgICBiaGkgPSBjIC0gKGMgLSBieSk7XG4gICAgICAgICAgICBibG8gPSBieSAtIGJoaTtcbiAgICAgICAgICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIF9pID0gczAgLSB0MDtcbiAgICAgICAgICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICAgICAgICAgIGJbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICAgICAgICAgIF9qID0gczEgKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICAgICAgICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICBfaSA9IF8wIC0gdDE7XG4gICAgICAgICAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgICAgICAgICBiWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgICAgICAgICB1MyA9IF9qICsgX2k7XG4gICAgICAgICAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgICAgICAgICBiWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICBiWzNdID0gdTM7XG4gICAgICAgICAgICByZXR1cm4gNDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZnVuY3Rpb24gdGFpbGFkZChmaW5sZW4sIGEsIGIsIGssIHopIHtcbiAgICBsZXQgYnZpcnQsIGMsIGFoaSwgYWxvLCBiaGksIGJsbywgX2ksIF9qLCBfaywgXzAsIHMxLCBzMCwgdTM7XG4gICAgczEgPSBhICogYjtcbiAgICBjID0gc3BsaXR0ZXIgKiBhO1xuICAgIGFoaSA9IGMgLSAoYyAtIGEpO1xuICAgIGFsbyA9IGEgLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYjtcbiAgICBiaGkgPSBjIC0gKGMgLSBiKTtcbiAgICBibG8gPSBiIC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBjID0gc3BsaXR0ZXIgKiBrO1xuICAgIGJoaSA9IGMgLSAoYyAtIGspO1xuICAgIGJsbyA9IGsgLSBiaGk7XG4gICAgX2kgPSBzMCAqIGs7XG4gICAgYyA9IHNwbGl0dGVyICogczA7XG4gICAgYWhpID0gYyAtIChjIC0gczApO1xuICAgIGFsbyA9IHMwIC0gYWhpO1xuICAgIHVbMF0gPSBhbG8gKiBibG8gLSAoX2kgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9qID0gczEgKiBrO1xuICAgIGMgPSBzcGxpdHRlciAqIHMxO1xuICAgIGFoaSA9IGMgLSAoYyAtIHMxKTtcbiAgICBhbG8gPSBzMSAtIGFoaTtcbiAgICBfMCA9IGFsbyAqIGJsbyAtIChfaiAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2sgPSBfaSArIF8wO1xuICAgIGJ2aXJ0ID0gX2sgLSBfaTtcbiAgICB1WzFdID0gX2kgLSAoX2sgLSBidmlydCkgKyAoXzAgLSBidmlydCk7XG4gICAgdTMgPSBfaiArIF9rO1xuICAgIHVbMl0gPSBfayAtICh1MyAtIF9qKTtcbiAgICB1WzNdID0gdTM7XG4gICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgNCwgdSk7XG4gICAgaWYgKHogIT09IDApIHtcbiAgICAgICAgYyA9IHNwbGl0dGVyICogejtcbiAgICAgICAgYmhpID0gYyAtIChjIC0geik7XG4gICAgICAgIGJsbyA9IHogLSBiaGk7XG4gICAgICAgIF9pID0gczAgKiB6O1xuICAgICAgICBjID0gc3BsaXR0ZXIgKiBzMDtcbiAgICAgICAgYWhpID0gYyAtIChjIC0gczApO1xuICAgICAgICBhbG8gPSBzMCAtIGFoaTtcbiAgICAgICAgdVswXSA9IGFsbyAqIGJsbyAtIChfaSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgICAgIF9qID0gczEgKiB6O1xuICAgICAgICBjID0gc3BsaXR0ZXIgKiBzMTtcbiAgICAgICAgYWhpID0gYyAtIChjIC0gczEpO1xuICAgICAgICBhbG8gPSBzMSAtIGFoaTtcbiAgICAgICAgXzAgPSBhbG8gKiBibG8gLSAoX2ogLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICBfayA9IF9pICsgXzA7XG4gICAgICAgIGJ2aXJ0ID0gX2sgLSBfaTtcbiAgICAgICAgdVsxXSA9IF9pIC0gKF9rIC0gYnZpcnQpICsgKF8wIC0gYnZpcnQpO1xuICAgICAgICB1MyA9IF9qICsgX2s7XG4gICAgICAgIHVbMl0gPSBfayAtICh1MyAtIF9qKTtcbiAgICAgICAgdVszXSA9IHUzO1xuICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCA0LCB1KTtcbiAgICB9XG4gICAgcmV0dXJuIGZpbmxlbjtcbn1cblxuZnVuY3Rpb24gb3JpZW50M2RhZGFwdChheCwgYXksIGF6LCBieCwgYnksIGJ6LCBjeCwgY3ksIGN6LCBkeCwgZHksIGR6LCBwZXJtYW5lbnQpIHtcbiAgICBsZXQgZmlubGVuO1xuICAgIGxldCBhZHh0YWlsLCBiZHh0YWlsLCBjZHh0YWlsO1xuICAgIGxldCBhZHl0YWlsLCBiZHl0YWlsLCBjZHl0YWlsO1xuICAgIGxldCBhZHp0YWlsLCBiZHp0YWlsLCBjZHp0YWlsO1xuICAgIGxldCBidmlydCwgYywgYWhpLCBhbG8sIGJoaSwgYmxvLCBfaSwgX2osIF9rLCBfMCwgczEsIHMwLCB0MSwgdDAsIHUzO1xuXG4gICAgY29uc3QgYWR4ID0gYXggLSBkeDtcbiAgICBjb25zdCBiZHggPSBieCAtIGR4O1xuICAgIGNvbnN0IGNkeCA9IGN4IC0gZHg7XG4gICAgY29uc3QgYWR5ID0gYXkgLSBkeTtcbiAgICBjb25zdCBiZHkgPSBieSAtIGR5O1xuICAgIGNvbnN0IGNkeSA9IGN5IC0gZHk7XG4gICAgY29uc3QgYWR6ID0gYXogLSBkejtcbiAgICBjb25zdCBiZHogPSBieiAtIGR6O1xuICAgIGNvbnN0IGNkeiA9IGN6IC0gZHo7XG5cbiAgICBzMSA9IGJkeCAqIGNkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZHg7XG4gICAgYWhpID0gYyAtIChjIC0gYmR4KTtcbiAgICBhbG8gPSBiZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogY2R5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGNkeSk7XG4gICAgYmxvID0gY2R5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGNkeCAqIGJkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZHg7XG4gICAgYWhpID0gYyAtIChjIC0gY2R4KTtcbiAgICBhbG8gPSBjZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmR5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGJkeSk7XG4gICAgYmxvID0gYmR5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGJjWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgYmNbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGJjWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgYmNbM10gPSB1MztcbiAgICBzMSA9IGNkeCAqIGFkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZHg7XG4gICAgYWhpID0gYyAtIChjIC0gY2R4KTtcbiAgICBhbG8gPSBjZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYWR5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGFkeSk7XG4gICAgYmxvID0gYWR5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGFkeCAqIGNkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhZHg7XG4gICAgYWhpID0gYyAtIChjIC0gYWR4KTtcbiAgICBhbG8gPSBhZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogY2R5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGNkeSk7XG4gICAgYmxvID0gY2R5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGNhWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgY2FbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGNhWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgY2FbM10gPSB1MztcbiAgICBzMSA9IGFkeCAqIGJkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhZHg7XG4gICAgYWhpID0gYyAtIChjIC0gYWR4KTtcbiAgICBhbG8gPSBhZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmR5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGJkeSk7XG4gICAgYmxvID0gYmR5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGJkeCAqIGFkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZHg7XG4gICAgYWhpID0gYyAtIChjIC0gYmR4KTtcbiAgICBhbG8gPSBiZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYWR5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGFkeSk7XG4gICAgYmxvID0gYWR5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGFiWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgYWJbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGFiWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgYWJbM10gPSB1MztcblxuICAgIGZpbmxlbiA9IHN1bShcbiAgICAgICAgc3VtKFxuICAgICAgICAgICAgc2NhbGUoNCwgYmMsIGFkeiwgXzgpLCBfOCxcbiAgICAgICAgICAgIHNjYWxlKDQsIGNhLCBiZHosIF84YiksIF84YiwgXzE2KSwgXzE2LFxuICAgICAgICBzY2FsZSg0LCBhYiwgY2R6LCBfOCksIF84LCBmaW4pO1xuXG4gICAgbGV0IGRldCA9IGVzdGltYXRlKGZpbmxlbiwgZmluKTtcbiAgICBsZXQgZXJyYm91bmQgPSBvM2RlcnJib3VuZEIgKiBwZXJtYW5lbnQ7XG4gICAgaWYgKGRldCA+PSBlcnJib3VuZCB8fCAtZGV0ID49IGVycmJvdW5kKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgYnZpcnQgPSBheCAtIGFkeDtcbiAgICBhZHh0YWlsID0gYXggLSAoYWR4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZHgpO1xuICAgIGJ2aXJ0ID0gYnggLSBiZHg7XG4gICAgYmR4dGFpbCA9IGJ4IC0gKGJkeCArIGJ2aXJ0KSArIChidmlydCAtIGR4KTtcbiAgICBidmlydCA9IGN4IC0gY2R4O1xuICAgIGNkeHRhaWwgPSBjeCAtIChjZHggKyBidmlydCkgKyAoYnZpcnQgLSBkeCk7XG4gICAgYnZpcnQgPSBheSAtIGFkeTtcbiAgICBhZHl0YWlsID0gYXkgLSAoYWR5ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZHkpO1xuICAgIGJ2aXJ0ID0gYnkgLSBiZHk7XG4gICAgYmR5dGFpbCA9IGJ5IC0gKGJkeSArIGJ2aXJ0KSArIChidmlydCAtIGR5KTtcbiAgICBidmlydCA9IGN5IC0gY2R5O1xuICAgIGNkeXRhaWwgPSBjeSAtIChjZHkgKyBidmlydCkgKyAoYnZpcnQgLSBkeSk7XG4gICAgYnZpcnQgPSBheiAtIGFkejtcbiAgICBhZHp0YWlsID0gYXogLSAoYWR6ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZHopO1xuICAgIGJ2aXJ0ID0gYnogLSBiZHo7XG4gICAgYmR6dGFpbCA9IGJ6IC0gKGJkeiArIGJ2aXJ0KSArIChidmlydCAtIGR6KTtcbiAgICBidmlydCA9IGN6IC0gY2R6O1xuICAgIGNkenRhaWwgPSBjeiAtIChjZHogKyBidmlydCkgKyAoYnZpcnQgLSBkeik7XG5cbiAgICBpZiAoYWR4dGFpbCA9PT0gMCAmJiBiZHh0YWlsID09PSAwICYmIGNkeHRhaWwgPT09IDAgJiZcbiAgICAgICAgYWR5dGFpbCA9PT0gMCAmJiBiZHl0YWlsID09PSAwICYmIGNkeXRhaWwgPT09IDAgJiZcbiAgICAgICAgYWR6dGFpbCA9PT0gMCAmJiBiZHp0YWlsID09PSAwICYmIGNkenRhaWwgPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGRldDtcbiAgICB9XG5cbiAgICBlcnJib3VuZCA9IG8zZGVycmJvdW5kQyAqIHBlcm1hbmVudCArIHJlc3VsdGVycmJvdW5kICogTWF0aC5hYnMoZGV0KTtcbiAgICBkZXQgKz1cbiAgICAgICAgYWR6ICogKGJkeCAqIGNkeXRhaWwgKyBjZHkgKiBiZHh0YWlsIC0gKGJkeSAqIGNkeHRhaWwgKyBjZHggKiBiZHl0YWlsKSkgKyBhZHp0YWlsICogKGJkeCAqIGNkeSAtIGJkeSAqIGNkeCkgK1xuICAgICAgICBiZHogKiAoY2R4ICogYWR5dGFpbCArIGFkeSAqIGNkeHRhaWwgLSAoY2R5ICogYWR4dGFpbCArIGFkeCAqIGNkeXRhaWwpKSArIGJkenRhaWwgKiAoY2R4ICogYWR5IC0gY2R5ICogYWR4KSArXG4gICAgICAgIGNkeiAqIChhZHggKiBiZHl0YWlsICsgYmR5ICogYWR4dGFpbCAtIChhZHkgKiBiZHh0YWlsICsgYmR4ICogYWR5dGFpbCkpICsgY2R6dGFpbCAqIChhZHggKiBiZHkgLSBhZHkgKiBiZHgpO1xuICAgIGlmIChkZXQgPj0gZXJyYm91bmQgfHwgLWRldCA+PSBlcnJib3VuZCkge1xuICAgICAgICByZXR1cm4gZGV0O1xuICAgIH1cblxuICAgIGNvbnN0IGF0X2xlbiA9IHRhaWxpbml0KGFkeHRhaWwsIGFkeXRhaWwsIGJkeCwgYmR5LCBjZHgsIGNkeSwgYXRfYiwgYXRfYyk7XG4gICAgY29uc3QgYnRfbGVuID0gdGFpbGluaXQoYmR4dGFpbCwgYmR5dGFpbCwgY2R4LCBjZHksIGFkeCwgYWR5LCBidF9jLCBidF9hKTtcbiAgICBjb25zdCBjdF9sZW4gPSB0YWlsaW5pdChjZHh0YWlsLCBjZHl0YWlsLCBhZHgsIGFkeSwgYmR4LCBiZHksIGN0X2EsIGN0X2IpO1xuXG4gICAgY29uc3QgYmN0bGVuID0gc3VtKGJ0X2xlbiwgYnRfYywgY3RfbGVuLCBjdF9iLCBiY3QpO1xuICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKGJjdGxlbiwgYmN0LCBhZHosIF8xNiksIF8xNik7XG5cbiAgICBjb25zdCBjYXRsZW4gPSBzdW0oY3RfbGVuLCBjdF9hLCBhdF9sZW4sIGF0X2MsIGNhdCk7XG4gICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc2NhbGUoY2F0bGVuLCBjYXQsIGJkeiwgXzE2KSwgXzE2KTtcblxuICAgIGNvbnN0IGFidGxlbiA9IHN1bShhdF9sZW4sIGF0X2IsIGJ0X2xlbiwgYnRfYSwgYWJ0KTtcbiAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzY2FsZShhYnRsZW4sIGFidCwgY2R6LCBfMTYpLCBfMTYpO1xuXG4gICAgaWYgKGFkenRhaWwgIT09IDApIHtcbiAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc2NhbGUoNCwgYmMsIGFkenRhaWwsIF8xMiksIF8xMik7XG4gICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKGJjdGxlbiwgYmN0LCBhZHp0YWlsLCBfMTYpLCBfMTYpO1xuICAgIH1cbiAgICBpZiAoYmR6dGFpbCAhPT0gMCkge1xuICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzY2FsZSg0LCBjYSwgYmR6dGFpbCwgXzEyKSwgXzEyKTtcbiAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc2NhbGUoY2F0bGVuLCBjYXQsIGJkenRhaWwsIF8xNiksIF8xNik7XG4gICAgfVxuICAgIGlmIChjZHp0YWlsICE9PSAwKSB7XG4gICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKDQsIGFiLCBjZHp0YWlsLCBfMTIpLCBfMTIpO1xuICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzY2FsZShhYnRsZW4sIGFidCwgY2R6dGFpbCwgXzE2KSwgXzE2KTtcbiAgICB9XG5cbiAgICBpZiAoYWR4dGFpbCAhPT0gMCkge1xuICAgICAgICBpZiAoYmR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgZmlubGVuID0gdGFpbGFkZChmaW5sZW4sIGFkeHRhaWwsIGJkeXRhaWwsIGNkeiwgY2R6dGFpbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNkeXRhaWwgIT09IDApIHtcbiAgICAgICAgICAgIGZpbmxlbiA9IHRhaWxhZGQoZmlubGVuLCAtYWR4dGFpbCwgY2R5dGFpbCwgYmR6LCBiZHp0YWlsKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoYmR4dGFpbCAhPT0gMCkge1xuICAgICAgICBpZiAoY2R5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgZmlubGVuID0gdGFpbGFkZChmaW5sZW4sIGJkeHRhaWwsIGNkeXRhaWwsIGFkeiwgYWR6dGFpbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFkeXRhaWwgIT09IDApIHtcbiAgICAgICAgICAgIGZpbmxlbiA9IHRhaWxhZGQoZmlubGVuLCAtYmR4dGFpbCwgYWR5dGFpbCwgY2R6LCBjZHp0YWlsKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoY2R4dGFpbCAhPT0gMCkge1xuICAgICAgICBpZiAoYWR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgZmlubGVuID0gdGFpbGFkZChmaW5sZW4sIGNkeHRhaWwsIGFkeXRhaWwsIGJkeiwgYmR6dGFpbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGJkeXRhaWwgIT09IDApIHtcbiAgICAgICAgICAgIGZpbmxlbiA9IHRhaWxhZGQoZmlubGVuLCAtY2R4dGFpbCwgYmR5dGFpbCwgYWR6LCBhZHp0YWlsKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmaW5bZmlubGVuIC0gMV07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBvcmllbnQzZChheCwgYXksIGF6LCBieCwgYnksIGJ6LCBjeCwgY3ksIGN6LCBkeCwgZHksIGR6KSB7XG4gICAgY29uc3QgYWR4ID0gYXggLSBkeDtcbiAgICBjb25zdCBiZHggPSBieCAtIGR4O1xuICAgIGNvbnN0IGNkeCA9IGN4IC0gZHg7XG4gICAgY29uc3QgYWR5ID0gYXkgLSBkeTtcbiAgICBjb25zdCBiZHkgPSBieSAtIGR5O1xuICAgIGNvbnN0IGNkeSA9IGN5IC0gZHk7XG4gICAgY29uc3QgYWR6ID0gYXogLSBkejtcbiAgICBjb25zdCBiZHogPSBieiAtIGR6O1xuICAgIGNvbnN0IGNkeiA9IGN6IC0gZHo7XG5cbiAgICBjb25zdCBiZHhjZHkgPSBiZHggKiBjZHk7XG4gICAgY29uc3QgY2R4YmR5ID0gY2R4ICogYmR5O1xuXG4gICAgY29uc3QgY2R4YWR5ID0gY2R4ICogYWR5O1xuICAgIGNvbnN0IGFkeGNkeSA9IGFkeCAqIGNkeTtcblxuICAgIGNvbnN0IGFkeGJkeSA9IGFkeCAqIGJkeTtcbiAgICBjb25zdCBiZHhhZHkgPSBiZHggKiBhZHk7XG5cbiAgICBjb25zdCBkZXQgPVxuICAgICAgICBhZHogKiAoYmR4Y2R5IC0gY2R4YmR5KSArXG4gICAgICAgIGJkeiAqIChjZHhhZHkgLSBhZHhjZHkpICtcbiAgICAgICAgY2R6ICogKGFkeGJkeSAtIGJkeGFkeSk7XG5cbiAgICBjb25zdCBwZXJtYW5lbnQgPVxuICAgICAgICAoTWF0aC5hYnMoYmR4Y2R5KSArIE1hdGguYWJzKGNkeGJkeSkpICogTWF0aC5hYnMoYWR6KSArXG4gICAgICAgIChNYXRoLmFicyhjZHhhZHkpICsgTWF0aC5hYnMoYWR4Y2R5KSkgKiBNYXRoLmFicyhiZHopICtcbiAgICAgICAgKE1hdGguYWJzKGFkeGJkeSkgKyBNYXRoLmFicyhiZHhhZHkpKSAqIE1hdGguYWJzKGNkeik7XG5cbiAgICBjb25zdCBlcnJib3VuZCA9IG8zZGVycmJvdW5kQSAqIHBlcm1hbmVudDtcbiAgICBpZiAoZGV0ID4gZXJyYm91bmQgfHwgLWRldCA+IGVycmJvdW5kKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIG9yaWVudDNkYWRhcHQoYXgsIGF5LCBheiwgYngsIGJ5LCBieiwgY3gsIGN5LCBjeiwgZHgsIGR5LCBkeiwgcGVybWFuZW50KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG9yaWVudDNkZmFzdChheCwgYXksIGF6LCBieCwgYnksIGJ6LCBjeCwgY3ksIGN6LCBkeCwgZHksIGR6KSB7XG4gICAgY29uc3QgYWR4ID0gYXggLSBkeDtcbiAgICBjb25zdCBiZHggPSBieCAtIGR4O1xuICAgIGNvbnN0IGNkeCA9IGN4IC0gZHg7XG4gICAgY29uc3QgYWR5ID0gYXkgLSBkeTtcbiAgICBjb25zdCBiZHkgPSBieSAtIGR5O1xuICAgIGNvbnN0IGNkeSA9IGN5IC0gZHk7XG4gICAgY29uc3QgYWR6ID0gYXogLSBkejtcbiAgICBjb25zdCBiZHogPSBieiAtIGR6O1xuICAgIGNvbnN0IGNkeiA9IGN6IC0gZHo7XG5cbiAgICByZXR1cm4gYWR4ICogKGJkeSAqIGNkeiAtIGJkeiAqIGNkeSkgK1xuICAgICAgICBiZHggKiAoY2R5ICogYWR6IC0gY2R6ICogYWR5KSArXG4gICAgICAgIGNkeCAqIChhZHkgKiBiZHogLSBhZHogKiBiZHkpO1xufVxuIiwiaW1wb3J0IHtlcHNpbG9uLCBzcGxpdHRlciwgcmVzdWx0ZXJyYm91bmQsIGVzdGltYXRlLCB2ZWMsIHN1bSwgc3VtX3RocmVlLCBzY2FsZX0gZnJvbSAnLi91dGlsLmpzJztcblxuY29uc3QgaWNjZXJyYm91bmRBID0gKDEwICsgOTYgKiBlcHNpbG9uKSAqIGVwc2lsb247XG5jb25zdCBpY2NlcnJib3VuZEIgPSAoNCArIDQ4ICogZXBzaWxvbikgKiBlcHNpbG9uO1xuY29uc3QgaWNjZXJyYm91bmRDID0gKDQ0ICsgNTc2ICogZXBzaWxvbikgKiBlcHNpbG9uICogZXBzaWxvbjtcblxuY29uc3QgYmMgPSB2ZWMoNCk7XG5jb25zdCBjYSA9IHZlYyg0KTtcbmNvbnN0IGFiID0gdmVjKDQpO1xuY29uc3QgYWEgPSB2ZWMoNCk7XG5jb25zdCBiYiA9IHZlYyg0KTtcbmNvbnN0IGNjID0gdmVjKDQpO1xuY29uc3QgdSA9IHZlYyg0KTtcbmNvbnN0IHYgPSB2ZWMoNCk7XG5jb25zdCBheHRiYyA9IHZlYyg4KTtcbmNvbnN0IGF5dGJjID0gdmVjKDgpO1xuY29uc3QgYnh0Y2EgPSB2ZWMoOCk7XG5jb25zdCBieXRjYSA9IHZlYyg4KTtcbmNvbnN0IGN4dGFiID0gdmVjKDgpO1xuY29uc3QgY3l0YWIgPSB2ZWMoOCk7XG5jb25zdCBhYnQgPSB2ZWMoOCk7XG5jb25zdCBiY3QgPSB2ZWMoOCk7XG5jb25zdCBjYXQgPSB2ZWMoOCk7XG5jb25zdCBhYnR0ID0gdmVjKDQpO1xuY29uc3QgYmN0dCA9IHZlYyg0KTtcbmNvbnN0IGNhdHQgPSB2ZWMoNCk7XG5cbmNvbnN0IF84ID0gdmVjKDgpO1xuY29uc3QgXzE2ID0gdmVjKDE2KTtcbmNvbnN0IF8xNmIgPSB2ZWMoMTYpO1xuY29uc3QgXzE2YyA9IHZlYygxNik7XG5jb25zdCBfMzIgPSB2ZWMoMzIpO1xuY29uc3QgXzMyYiA9IHZlYygzMik7XG5jb25zdCBfNDggPSB2ZWMoNDgpO1xuY29uc3QgXzY0ID0gdmVjKDY0KTtcblxubGV0IGZpbiA9IHZlYygxMTUyKTtcbmxldCBmaW4yID0gdmVjKDExNTIpO1xuXG5mdW5jdGlvbiBmaW5hZGQoZmlubGVuLCBhLCBhbGVuKSB7XG4gICAgZmlubGVuID0gc3VtKGZpbmxlbiwgZmluLCBhLCBhbGVuLCBmaW4yKTtcbiAgICBjb25zdCB0bXAgPSBmaW47IGZpbiA9IGZpbjI7IGZpbjIgPSB0bXA7XG4gICAgcmV0dXJuIGZpbmxlbjtcbn1cblxuZnVuY3Rpb24gaW5jaXJjbGVhZGFwdChheCwgYXksIGJ4LCBieSwgY3gsIGN5LCBkeCwgZHksIHBlcm1hbmVudCkge1xuICAgIGxldCBmaW5sZW47XG4gICAgbGV0IGFkeHRhaWwsIGJkeHRhaWwsIGNkeHRhaWwsIGFkeXRhaWwsIGJkeXRhaWwsIGNkeXRhaWw7XG4gICAgbGV0IGF4dGJjbGVuLCBheXRiY2xlbiwgYnh0Y2FsZW4sIGJ5dGNhbGVuLCBjeHRhYmxlbiwgY3l0YWJsZW47XG4gICAgbGV0IGFidGxlbiwgYmN0bGVuLCBjYXRsZW47XG4gICAgbGV0IGFidHRsZW4sIGJjdHRsZW4sIGNhdHRsZW47XG4gICAgbGV0IG4xLCBuMDtcblxuICAgIGxldCBidmlydCwgYywgYWhpLCBhbG8sIGJoaSwgYmxvLCBfaSwgX2osIF8wLCBzMSwgczAsIHQxLCB0MCwgdTM7XG5cbiAgICBjb25zdCBhZHggPSBheCAtIGR4O1xuICAgIGNvbnN0IGJkeCA9IGJ4IC0gZHg7XG4gICAgY29uc3QgY2R4ID0gY3ggLSBkeDtcbiAgICBjb25zdCBhZHkgPSBheSAtIGR5O1xuICAgIGNvbnN0IGJkeSA9IGJ5IC0gZHk7XG4gICAgY29uc3QgY2R5ID0gY3kgLSBkeTtcblxuICAgIHMxID0gYmR4ICogY2R5O1xuICAgIGMgPSBzcGxpdHRlciAqIGJkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBiZHgpO1xuICAgIGFsbyA9IGJkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZHk7XG4gICAgYmhpID0gYyAtIChjIC0gY2R5KTtcbiAgICBibG8gPSBjZHkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gY2R4ICogYmR5O1xuICAgIGMgPSBzcGxpdHRlciAqIGNkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBjZHgpO1xuICAgIGFsbyA9IGNkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZHk7XG4gICAgYmhpID0gYyAtIChjIC0gYmR5KTtcbiAgICBibG8gPSBiZHkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgYmNbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBiY1sxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgYmNbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBiY1szXSA9IHUzO1xuICAgIHMxID0gY2R4ICogYWR5O1xuICAgIGMgPSBzcGxpdHRlciAqIGNkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBjZHgpO1xuICAgIGFsbyA9IGNkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhZHk7XG4gICAgYmhpID0gYyAtIChjIC0gYWR5KTtcbiAgICBibG8gPSBhZHkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gYWR4ICogY2R5O1xuICAgIGMgPSBzcGxpdHRlciAqIGFkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBhZHgpO1xuICAgIGFsbyA9IGFkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZHk7XG4gICAgYmhpID0gYyAtIChjIC0gY2R5KTtcbiAgICBibG8gPSBjZHkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgY2FbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBjYVsxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgY2FbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBjYVszXSA9IHUzO1xuICAgIHMxID0gYWR4ICogYmR5O1xuICAgIGMgPSBzcGxpdHRlciAqIGFkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBhZHgpO1xuICAgIGFsbyA9IGFkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZHk7XG4gICAgYmhpID0gYyAtIChjIC0gYmR5KTtcbiAgICBibG8gPSBiZHkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gYmR4ICogYWR5O1xuICAgIGMgPSBzcGxpdHRlciAqIGJkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBiZHgpO1xuICAgIGFsbyA9IGJkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhZHk7XG4gICAgYmhpID0gYyAtIChjIC0gYWR5KTtcbiAgICBibG8gPSBhZHkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgYWJbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBhYlsxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgYWJbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBhYlszXSA9IHUzO1xuXG4gICAgZmlubGVuID0gc3VtKFxuICAgICAgICBzdW0oXG4gICAgICAgICAgICBzdW0oXG4gICAgICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYmMsIGFkeCwgXzgpLCBfOCwgYWR4LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYmMsIGFkeSwgXzgpLCBfOCwgYWR5LCBfMTZiKSwgXzE2YiwgXzMyKSwgXzMyLFxuICAgICAgICAgICAgc3VtKFxuICAgICAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGNhLCBiZHgsIF84KSwgXzgsIGJkeCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGNhLCBiZHksIF84KSwgXzgsIGJkeSwgXzE2YiksIF8xNmIsIF8zMmIpLCBfMzJiLCBfNjQpLCBfNjQsXG4gICAgICAgIHN1bShcbiAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGFiLCBjZHgsIF84KSwgXzgsIGNkeCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYWIsIGNkeSwgXzgpLCBfOCwgY2R5LCBfMTZiKSwgXzE2YiwgXzMyKSwgXzMyLCBmaW4pO1xuXG4gICAgbGV0IGRldCA9IGVzdGltYXRlKGZpbmxlbiwgZmluKTtcbiAgICBsZXQgZXJyYm91bmQgPSBpY2NlcnJib3VuZEIgKiBwZXJtYW5lbnQ7XG4gICAgaWYgKGRldCA+PSBlcnJib3VuZCB8fCAtZGV0ID49IGVycmJvdW5kKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgYnZpcnQgPSBheCAtIGFkeDtcbiAgICBhZHh0YWlsID0gYXggLSAoYWR4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZHgpO1xuICAgIGJ2aXJ0ID0gYXkgLSBhZHk7XG4gICAgYWR5dGFpbCA9IGF5IC0gKGFkeSArIGJ2aXJ0KSArIChidmlydCAtIGR5KTtcbiAgICBidmlydCA9IGJ4IC0gYmR4O1xuICAgIGJkeHRhaWwgPSBieCAtIChiZHggKyBidmlydCkgKyAoYnZpcnQgLSBkeCk7XG4gICAgYnZpcnQgPSBieSAtIGJkeTtcbiAgICBiZHl0YWlsID0gYnkgLSAoYmR5ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZHkpO1xuICAgIGJ2aXJ0ID0gY3ggLSBjZHg7XG4gICAgY2R4dGFpbCA9IGN4IC0gKGNkeCArIGJ2aXJ0KSArIChidmlydCAtIGR4KTtcbiAgICBidmlydCA9IGN5IC0gY2R5O1xuICAgIGNkeXRhaWwgPSBjeSAtIChjZHkgKyBidmlydCkgKyAoYnZpcnQgLSBkeSk7XG4gICAgaWYgKGFkeHRhaWwgPT09IDAgJiYgYmR4dGFpbCA9PT0gMCAmJiBjZHh0YWlsID09PSAwICYmIGFkeXRhaWwgPT09IDAgJiYgYmR5dGFpbCA9PT0gMCAmJiBjZHl0YWlsID09PSAwKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgZXJyYm91bmQgPSBpY2NlcnJib3VuZEMgKiBwZXJtYW5lbnQgKyByZXN1bHRlcnJib3VuZCAqIE1hdGguYWJzKGRldCk7XG4gICAgZGV0ICs9ICgoYWR4ICogYWR4ICsgYWR5ICogYWR5KSAqICgoYmR4ICogY2R5dGFpbCArIGNkeSAqIGJkeHRhaWwpIC0gKGJkeSAqIGNkeHRhaWwgKyBjZHggKiBiZHl0YWlsKSkgK1xuICAgICAgICAyICogKGFkeCAqIGFkeHRhaWwgKyBhZHkgKiBhZHl0YWlsKSAqIChiZHggKiBjZHkgLSBiZHkgKiBjZHgpKSArXG4gICAgICAgICgoYmR4ICogYmR4ICsgYmR5ICogYmR5KSAqICgoY2R4ICogYWR5dGFpbCArIGFkeSAqIGNkeHRhaWwpIC0gKGNkeSAqIGFkeHRhaWwgKyBhZHggKiBjZHl0YWlsKSkgK1xuICAgICAgICAyICogKGJkeCAqIGJkeHRhaWwgKyBiZHkgKiBiZHl0YWlsKSAqIChjZHggKiBhZHkgLSBjZHkgKiBhZHgpKSArXG4gICAgICAgICgoY2R4ICogY2R4ICsgY2R5ICogY2R5KSAqICgoYWR4ICogYmR5dGFpbCArIGJkeSAqIGFkeHRhaWwpIC0gKGFkeSAqIGJkeHRhaWwgKyBiZHggKiBhZHl0YWlsKSkgK1xuICAgICAgICAyICogKGNkeCAqIGNkeHRhaWwgKyBjZHkgKiBjZHl0YWlsKSAqIChhZHggKiBiZHkgLSBhZHkgKiBiZHgpKTtcblxuICAgIGlmIChkZXQgPj0gZXJyYm91bmQgfHwgLWRldCA+PSBlcnJib3VuZCkge1xuICAgICAgICByZXR1cm4gZGV0O1xuICAgIH1cblxuICAgIGlmIChiZHh0YWlsICE9PSAwIHx8IGJkeXRhaWwgIT09IDAgfHwgY2R4dGFpbCAhPT0gMCB8fCBjZHl0YWlsICE9PSAwKSB7XG4gICAgICAgIHMxID0gYWR4ICogYWR4O1xuICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHg7XG4gICAgICAgIGFoaSA9IGMgLSAoYyAtIGFkeCk7XG4gICAgICAgIGFsbyA9IGFkeCAtIGFoaTtcbiAgICAgICAgczAgPSBhbG8gKiBhbG8gLSAoczEgLSBhaGkgKiBhaGkgLSAoYWhpICsgYWhpKSAqIGFsbyk7XG4gICAgICAgIHQxID0gYWR5ICogYWR5O1xuICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHk7XG4gICAgICAgIGFoaSA9IGMgLSAoYyAtIGFkeSk7XG4gICAgICAgIGFsbyA9IGFkeSAtIGFoaTtcbiAgICAgICAgdDAgPSBhbG8gKiBhbG8gLSAodDEgLSBhaGkgKiBhaGkgLSAoYWhpICsgYWhpKSAqIGFsbyk7XG4gICAgICAgIF9pID0gczAgKyB0MDtcbiAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICBhYVswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICBfaiA9IHMxICsgX2k7XG4gICAgICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgX2kgPSBfMCArIHQxO1xuICAgICAgICBidmlydCA9IF9pIC0gXzA7XG4gICAgICAgIGFhWzFdID0gXzAgLSAoX2kgLSBidmlydCkgKyAodDEgLSBidmlydCk7XG4gICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgICAgICBhYVsyXSA9IF9qIC0gKHUzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgICAgICBhYVszXSA9IHUzO1xuICAgIH1cbiAgICBpZiAoY2R4dGFpbCAhPT0gMCB8fCBjZHl0YWlsICE9PSAwIHx8IGFkeHRhaWwgIT09IDAgfHwgYWR5dGFpbCAhPT0gMCkge1xuICAgICAgICBzMSA9IGJkeCAqIGJkeDtcbiAgICAgICAgYyA9IHNwbGl0dGVyICogYmR4O1xuICAgICAgICBhaGkgPSBjIC0gKGMgLSBiZHgpO1xuICAgICAgICBhbG8gPSBiZHggLSBhaGk7XG4gICAgICAgIHMwID0gYWxvICogYWxvIC0gKHMxIC0gYWhpICogYWhpIC0gKGFoaSArIGFoaSkgKiBhbG8pO1xuICAgICAgICB0MSA9IGJkeSAqIGJkeTtcbiAgICAgICAgYyA9IHNwbGl0dGVyICogYmR5O1xuICAgICAgICBhaGkgPSBjIC0gKGMgLSBiZHkpO1xuICAgICAgICBhbG8gPSBiZHkgLSBhaGk7XG4gICAgICAgIHQwID0gYWxvICogYWxvIC0gKHQxIC0gYWhpICogYWhpIC0gKGFoaSArIGFoaSkgKiBhbG8pO1xuICAgICAgICBfaSA9IHMwICsgdDA7XG4gICAgICAgIGJ2aXJ0ID0gX2kgLSBzMDtcbiAgICAgICAgYmJbMF0gPSBzMCAtIChfaSAtIGJ2aXJ0KSArICh0MCAtIGJ2aXJ0KTtcbiAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICBidmlydCA9IF9qIC0gczE7XG4gICAgICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgYnZpcnQgPSBfaSAtIF8wO1xuICAgICAgICBiYlsxXSA9IF8wIC0gKF9pIC0gYnZpcnQpICsgKHQxIC0gYnZpcnQpO1xuICAgICAgICB1MyA9IF9qICsgX2k7XG4gICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgYmJbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgYmJbM10gPSB1MztcbiAgICB9XG4gICAgaWYgKGFkeHRhaWwgIT09IDAgfHwgYWR5dGFpbCAhPT0gMCB8fCBiZHh0YWlsICE9PSAwIHx8IGJkeXRhaWwgIT09IDApIHtcbiAgICAgICAgczEgPSBjZHggKiBjZHg7XG4gICAgICAgIGMgPSBzcGxpdHRlciAqIGNkeDtcbiAgICAgICAgYWhpID0gYyAtIChjIC0gY2R4KTtcbiAgICAgICAgYWxvID0gY2R4IC0gYWhpO1xuICAgICAgICBzMCA9IGFsbyAqIGFsbyAtIChzMSAtIGFoaSAqIGFoaSAtIChhaGkgKyBhaGkpICogYWxvKTtcbiAgICAgICAgdDEgPSBjZHkgKiBjZHk7XG4gICAgICAgIGMgPSBzcGxpdHRlciAqIGNkeTtcbiAgICAgICAgYWhpID0gYyAtIChjIC0gY2R5KTtcbiAgICAgICAgYWxvID0gY2R5IC0gYWhpO1xuICAgICAgICB0MCA9IGFsbyAqIGFsbyAtICh0MSAtIGFoaSAqIGFoaSAtIChhaGkgKyBhaGkpICogYWxvKTtcbiAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICBidmlydCA9IF9pIC0gczA7XG4gICAgICAgIGNjWzBdID0gczAgLSAoX2kgLSBidmlydCkgKyAodDAgLSBidmlydCk7XG4gICAgICAgIF9qID0gczEgKyBfaTtcbiAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgICAgICBfaSA9IF8wICsgdDE7XG4gICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgY2NbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgdTMgPSBfaiArIF9pO1xuICAgICAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgICAgIGNjWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgIGNjWzNdID0gdTM7XG4gICAgfVxuXG4gICAgaWYgKGFkeHRhaWwgIT09IDApIHtcbiAgICAgICAgYXh0YmNsZW4gPSBzY2FsZSg0LCBiYywgYWR4dGFpbCwgYXh0YmMpO1xuICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW1fdGhyZWUoXG4gICAgICAgICAgICBzY2FsZShheHRiY2xlbiwgYXh0YmMsIDIgKiBhZHgsIF8xNiksIF8xNixcbiAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGNjLCBhZHh0YWlsLCBfOCksIF84LCBiZHksIF8xNmIpLCBfMTZiLFxuICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYmIsIGFkeHRhaWwsIF84KSwgXzgsIC1jZHksIF8xNmMpLCBfMTZjLCBfMzIsIF80OCksIF80OCk7XG4gICAgfVxuICAgIGlmIChhZHl0YWlsICE9PSAwKSB7XG4gICAgICAgIGF5dGJjbGVuID0gc2NhbGUoNCwgYmMsIGFkeXRhaWwsIGF5dGJjKTtcbiAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtX3RocmVlKFxuICAgICAgICAgICAgc2NhbGUoYXl0YmNsZW4sIGF5dGJjLCAyICogYWR5LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICBzY2FsZShzY2FsZSg0LCBiYiwgYWR5dGFpbCwgXzgpLCBfOCwgY2R4LCBfMTZiKSwgXzE2YixcbiAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGNjLCBhZHl0YWlsLCBfOCksIF84LCAtYmR4LCBfMTZjKSwgXzE2YywgXzMyLCBfNDgpLCBfNDgpO1xuICAgIH1cbiAgICBpZiAoYmR4dGFpbCAhPT0gMCkge1xuICAgICAgICBieHRjYWxlbiA9IHNjYWxlKDQsIGNhLCBiZHh0YWlsLCBieHRjYSk7XG4gICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHN1bV90aHJlZShcbiAgICAgICAgICAgIHNjYWxlKGJ4dGNhbGVuLCBieHRjYSwgMiAqIGJkeCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYWEsIGJkeHRhaWwsIF84KSwgXzgsIGNkeSwgXzE2YiksIF8xNmIsXG4gICAgICAgICAgICBzY2FsZShzY2FsZSg0LCBjYywgYmR4dGFpbCwgXzgpLCBfOCwgLWFkeSwgXzE2YyksIF8xNmMsIF8zMiwgXzQ4KSwgXzQ4KTtcbiAgICB9XG4gICAgaWYgKGJkeXRhaWwgIT09IDApIHtcbiAgICAgICAgYnl0Y2FsZW4gPSBzY2FsZSg0LCBjYSwgYmR5dGFpbCwgYnl0Y2EpO1xuICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW1fdGhyZWUoXG4gICAgICAgICAgICBzY2FsZShieXRjYWxlbiwgYnl0Y2EsIDIgKiBiZHksIF8xNiksIF8xNixcbiAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGNjLCBiZHl0YWlsLCBfOCksIF84LCBhZHgsIF8xNmIpLCBfMTZiLFxuICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYWEsIGJkeXRhaWwsIF84KSwgXzgsIC1jZHgsIF8xNmMpLCBfMTZjLCBfMzIsIF80OCksIF80OCk7XG4gICAgfVxuICAgIGlmIChjZHh0YWlsICE9PSAwKSB7XG4gICAgICAgIGN4dGFibGVuID0gc2NhbGUoNCwgYWIsIGNkeHRhaWwsIGN4dGFiKTtcbiAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtX3RocmVlKFxuICAgICAgICAgICAgc2NhbGUoY3h0YWJsZW4sIGN4dGFiLCAyICogY2R4LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICBzY2FsZShzY2FsZSg0LCBiYiwgY2R4dGFpbCwgXzgpLCBfOCwgYWR5LCBfMTZiKSwgXzE2YixcbiAgICAgICAgICAgIHNjYWxlKHNjYWxlKDQsIGFhLCBjZHh0YWlsLCBfOCksIF84LCAtYmR5LCBfMTZjKSwgXzE2YywgXzMyLCBfNDgpLCBfNDgpO1xuICAgIH1cbiAgICBpZiAoY2R5dGFpbCAhPT0gMCkge1xuICAgICAgICBjeXRhYmxlbiA9IHNjYWxlKDQsIGFiLCBjZHl0YWlsLCBjeXRhYik7XG4gICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHN1bV90aHJlZShcbiAgICAgICAgICAgIHNjYWxlKGN5dGFibGVuLCBjeXRhYiwgMiAqIGNkeSwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgc2NhbGUoc2NhbGUoNCwgYWEsIGNkeXRhaWwsIF84KSwgXzgsIGJkeCwgXzE2YiksIF8xNmIsXG4gICAgICAgICAgICBzY2FsZShzY2FsZSg0LCBiYiwgY2R5dGFpbCwgXzgpLCBfOCwgLWFkeCwgXzE2YyksIF8xNmMsIF8zMiwgXzQ4KSwgXzQ4KTtcbiAgICB9XG5cbiAgICBpZiAoYWR4dGFpbCAhPT0gMCB8fCBhZHl0YWlsICE9PSAwKSB7XG4gICAgICAgIGlmIChiZHh0YWlsICE9PSAwIHx8IGJkeXRhaWwgIT09IDAgfHwgY2R4dGFpbCAhPT0gMCB8fCBjZHl0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICBzMSA9IGJkeHRhaWwgKiBjZHk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBiZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gYmR4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBiZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogY2R5O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gY2R5KTtcbiAgICAgICAgICAgIGJsbyA9IGNkeSAtIGJoaTtcbiAgICAgICAgICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIHQxID0gYmR4ICogY2R5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJkeDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIGJkeCk7XG4gICAgICAgICAgICBhbG8gPSBiZHggLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gY2R5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBjZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICAgICAgdVswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgICAgIHVbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIHVbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHVbM10gPSB1MztcbiAgICAgICAgICAgIHMxID0gY2R4dGFpbCAqIC1iZHk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gY2R4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBjZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogLWJkeTtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIC1iZHkpO1xuICAgICAgICAgICAgYmxvID0gLWJkeSAtIGJoaTtcbiAgICAgICAgICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIHQxID0gY2R4ICogLWJkeXRhaWw7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHg7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBjZHgpO1xuICAgICAgICAgICAgYWxvID0gY2R4IC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogLWJkeXRhaWw7XG4gICAgICAgICAgICBiaGkgPSBjIC0gKGMgLSAtYmR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSAtYmR5dGFpbCAtIGJoaTtcbiAgICAgICAgICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIF9pID0gczAgKyB0MDtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBzMDtcbiAgICAgICAgICAgIHZbMF0gPSBzMCAtIChfaSAtIGJ2aXJ0KSArICh0MCAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9qID0gczEgKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICAgICAgICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICBfaSA9IF8wICsgdDE7XG4gICAgICAgICAgICBidmlydCA9IF9pIC0gXzA7XG4gICAgICAgICAgICB2WzFdID0gXzAgLSAoX2kgLSBidmlydCkgKyAodDEgLSBidmlydCk7XG4gICAgICAgICAgICB1MyA9IF9qICsgX2k7XG4gICAgICAgICAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgICAgICAgICB2WzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICB2WzNdID0gdTM7XG4gICAgICAgICAgICBiY3RsZW4gPSBzdW0oNCwgdSwgNCwgdiwgYmN0KTtcbiAgICAgICAgICAgIHMxID0gYmR4dGFpbCAqIGNkeXRhaWw7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBiZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gYmR4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBiZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogY2R5dGFpbDtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIGNkeXRhaWwpO1xuICAgICAgICAgICAgYmxvID0gY2R5dGFpbCAtIGJoaTtcbiAgICAgICAgICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIHQxID0gY2R4dGFpbCAqIGJkeXRhaWw7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gY2R4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBjZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYmR5dGFpbDtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIGJkeXRhaWwpO1xuICAgICAgICAgICAgYmxvID0gYmR5dGFpbCAtIGJoaTtcbiAgICAgICAgICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIF9pID0gczAgLSB0MDtcbiAgICAgICAgICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICAgICAgICAgIGJjdHRbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICAgICAgICAgIF9qID0gczEgKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICAgICAgICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICBfaSA9IF8wIC0gdDE7XG4gICAgICAgICAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgICAgICAgICBiY3R0WzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgICAgICAgICB1MyA9IF9qICsgX2k7XG4gICAgICAgICAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgICAgICAgICBiY3R0WzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgICAgICAgICBiY3R0WzNdID0gdTM7XG4gICAgICAgICAgICBiY3R0bGVuID0gNDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGJjdFswXSA9IDA7XG4gICAgICAgICAgICBiY3RsZW4gPSAxO1xuICAgICAgICAgICAgYmN0dFswXSA9IDA7XG4gICAgICAgICAgICBiY3R0bGVuID0gMTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYWR4dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgY29uc3QgbGVuID0gc2NhbGUoYmN0bGVuLCBiY3QsIGFkeHRhaWwsIF8xNmMpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtKFxuICAgICAgICAgICAgICAgIHNjYWxlKGF4dGJjbGVuLCBheHRiYywgYWR4dGFpbCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgMiAqIGFkeCwgXzMyKSwgXzMyLCBfNDgpLCBfNDgpO1xuXG4gICAgICAgICAgICBjb25zdCBsZW4yID0gc2NhbGUoYmN0dGxlbiwgYmN0dCwgYWR4dGFpbCwgXzgpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtX3RocmVlKFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbjIsIF84LCAyICogYWR4LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuMiwgXzgsIGFkeHRhaWwsIF8xNmIpLCBfMTZiLFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgYWR4dGFpbCwgXzMyKSwgXzMyLCBfMzJiLCBfNjQpLCBfNjQpO1xuXG4gICAgICAgICAgICBpZiAoYmR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKHNjYWxlKDQsIGNjLCBhZHh0YWlsLCBfOCksIF84LCBiZHl0YWlsLCBfMTYpLCBfMTYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNkeXRhaWwgIT09IDApIHtcbiAgICAgICAgICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzY2FsZShzY2FsZSg0LCBiYiwgLWFkeHRhaWwsIF84KSwgXzgsIGNkeXRhaWwsIF8xNiksIF8xNik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFkeXRhaWwgIT09IDApIHtcbiAgICAgICAgICAgIGNvbnN0IGxlbiA9IHNjYWxlKGJjdGxlbiwgYmN0LCBhZHl0YWlsLCBfMTZjKTtcbiAgICAgICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHN1bShcbiAgICAgICAgICAgICAgICBzY2FsZShheXRiY2xlbiwgYXl0YmMsIGFkeXRhaWwsIF8xNiksIF8xNixcbiAgICAgICAgICAgICAgICBzY2FsZShsZW4sIF8xNmMsIDIgKiBhZHksIF8zMiksIF8zMiwgXzQ4KSwgXzQ4KTtcblxuICAgICAgICAgICAgY29uc3QgbGVuMiA9IHNjYWxlKGJjdHRsZW4sIGJjdHQsIGFkeXRhaWwsIF84KTtcbiAgICAgICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHN1bV90aHJlZShcbiAgICAgICAgICAgICAgICBzY2FsZShsZW4yLCBfOCwgMiAqIGFkeSwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbjIsIF84LCBhZHl0YWlsLCBfMTZiKSwgXzE2YixcbiAgICAgICAgICAgICAgICBzY2FsZShsZW4sIF8xNmMsIGFkeXRhaWwsIF8zMiksIF8zMiwgXzMyYiwgXzY0KSwgXzY0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoYmR4dGFpbCAhPT0gMCB8fCBiZHl0YWlsICE9PSAwKSB7XG4gICAgICAgIGlmIChjZHh0YWlsICE9PSAwIHx8IGNkeXRhaWwgIT09IDAgfHwgYWR4dGFpbCAhPT0gMCB8fCBhZHl0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICBzMSA9IGNkeHRhaWwgKiBhZHk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gY2R4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBjZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYWR5O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYWR5KTtcbiAgICAgICAgICAgIGJsbyA9IGFkeSAtIGJoaTtcbiAgICAgICAgICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIHQxID0gY2R4ICogYWR5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGNkeDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIGNkeCk7XG4gICAgICAgICAgICBhbG8gPSBjZHggLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYWR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBhZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICAgICAgdVswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgICAgIHVbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIHVbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHVbM10gPSB1MztcbiAgICAgICAgICAgIG4xID0gLWNkeTtcbiAgICAgICAgICAgIG4wID0gLWNkeXRhaWw7XG4gICAgICAgICAgICBzMSA9IGFkeHRhaWwgKiBuMTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGFkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBhZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGFkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBuMTtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIG4xKTtcbiAgICAgICAgICAgIGJsbyA9IG4xIC0gYmhpO1xuICAgICAgICAgICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgdDEgPSBhZHggKiBuMDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGFkeDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIGFkeCk7XG4gICAgICAgICAgICBhbG8gPSBhZHggLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBuMDtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIG4wKTtcbiAgICAgICAgICAgIGJsbyA9IG4wIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICAgICAgdlswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgICAgIHZbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIHZbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHZbM10gPSB1MztcbiAgICAgICAgICAgIGNhdGxlbiA9IHN1bSg0LCB1LCA0LCB2LCBjYXQpO1xuICAgICAgICAgICAgczEgPSBjZHh0YWlsICogYWR5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGNkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBjZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGNkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYWR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBhZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgdDEgPSBhZHh0YWlsICogY2R5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGFkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBhZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGFkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBjZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gY2R5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBjZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCAtIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgICAgICAgICAgY2F0dFswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgLSB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICAgICAgICAgIGNhdHRbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIGNhdHRbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIGNhdHRbM10gPSB1MztcbiAgICAgICAgICAgIGNhdHRsZW4gPSA0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2F0WzBdID0gMDtcbiAgICAgICAgICAgIGNhdGxlbiA9IDE7XG4gICAgICAgICAgICBjYXR0WzBdID0gMDtcbiAgICAgICAgICAgIGNhdHRsZW4gPSAxO1xuICAgICAgICB9XG4gICAgICAgIGlmIChiZHh0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICBjb25zdCBsZW4gPSBzY2FsZShjYXRsZW4sIGNhdCwgYmR4dGFpbCwgXzE2Yyk7XG4gICAgICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW0oXG4gICAgICAgICAgICAgICAgc2NhbGUoYnh0Y2FsZW4sIGJ4dGNhLCBiZHh0YWlsLCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuLCBfMTZjLCAyICogYmR4LCBfMzIpLCBfMzIsIF80OCksIF80OCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGxlbjIgPSBzY2FsZShjYXR0bGVuLCBjYXR0LCBiZHh0YWlsLCBfOCk7XG4gICAgICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW1fdGhyZWUoXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuMiwgXzgsIDIgKiBiZHgsIF8xNiksIF8xNixcbiAgICAgICAgICAgICAgICBzY2FsZShsZW4yLCBfOCwgYmR4dGFpbCwgXzE2YiksIF8xNmIsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuLCBfMTZjLCBiZHh0YWlsLCBfMzIpLCBfMzIsIF8zMmIsIF82NCksIF82NCk7XG5cbiAgICAgICAgICAgIGlmIChjZHl0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc2NhbGUoc2NhbGUoNCwgYWEsIGJkeHRhaWwsIF84KSwgXzgsIGNkeXRhaWwsIF8xNiksIF8xNik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYWR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKHNjYWxlKDQsIGNjLCAtYmR4dGFpbCwgXzgpLCBfOCwgYWR5dGFpbCwgXzE2KSwgXzE2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoYmR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgY29uc3QgbGVuID0gc2NhbGUoY2F0bGVuLCBjYXQsIGJkeXRhaWwsIF8xNmMpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtKFxuICAgICAgICAgICAgICAgIHNjYWxlKGJ5dGNhbGVuLCBieXRjYSwgYmR5dGFpbCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgMiAqIGJkeSwgXzMyKSwgXzMyLCBfNDgpLCBfNDgpO1xuXG4gICAgICAgICAgICBjb25zdCBsZW4yID0gc2NhbGUoY2F0dGxlbiwgY2F0dCwgYmR5dGFpbCwgXzgpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtX3RocmVlKFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbjIsIF84LCAyICogYmR5LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuMiwgXzgsIGJkeXRhaWwsIF8xNmIpLCBfMTZiLFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgYmR5dGFpbCwgXzMyKSwgXzMyLCAgXzMyYiwgXzY0KSwgXzY0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoY2R4dGFpbCAhPT0gMCB8fCBjZHl0YWlsICE9PSAwKSB7XG4gICAgICAgIGlmIChhZHh0YWlsICE9PSAwIHx8IGFkeXRhaWwgIT09IDAgfHwgYmR4dGFpbCAhPT0gMCB8fCBiZHl0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICBzMSA9IGFkeHRhaWwgKiBiZHk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHh0YWlsO1xuICAgICAgICAgICAgYWhpID0gYyAtIChjIC0gYWR4dGFpbCk7XG4gICAgICAgICAgICBhbG8gPSBhZHh0YWlsIC0gYWhpO1xuICAgICAgICAgICAgYyA9IHNwbGl0dGVyICogYmR5O1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYmR5KTtcbiAgICAgICAgICAgIGJsbyA9IGJkeSAtIGJoaTtcbiAgICAgICAgICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICAgICAgICAgIHQxID0gYWR4ICogYmR5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGFkeDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIGFkeCk7XG4gICAgICAgICAgICBhbG8gPSBhZHggLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBiZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYmR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBiZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICAgICAgdVswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgICAgIHVbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIHVbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHVbM10gPSB1MztcbiAgICAgICAgICAgIG4xID0gLWFkeTtcbiAgICAgICAgICAgIG4wID0gLWFkeXRhaWw7XG4gICAgICAgICAgICBzMSA9IGJkeHRhaWwgKiBuMTtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBiZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGJkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBuMTtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIG4xKTtcbiAgICAgICAgICAgIGJsbyA9IG4xIC0gYmhpO1xuICAgICAgICAgICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgdDEgPSBiZHggKiBuMDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJkeDtcbiAgICAgICAgICAgIGFoaSA9IGMgLSAoYyAtIGJkeCk7XG4gICAgICAgICAgICBhbG8gPSBiZHggLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBuMDtcbiAgICAgICAgICAgIGJoaSA9IGMgLSAoYyAtIG4wKTtcbiAgICAgICAgICAgIGJsbyA9IG4wIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCArIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBfaSAtIHMwO1xuICAgICAgICAgICAgdlswXSA9IHMwIC0gKF9pIC0gYnZpcnQpICsgKHQwIC0gYnZpcnQpO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgKyB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gX2kgLSBfMDtcbiAgICAgICAgICAgIHZbMV0gPSBfMCAtIChfaSAtIGJ2aXJ0KSArICh0MSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIHZbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIHZbM10gPSB1MztcbiAgICAgICAgICAgIGFidGxlbiA9IHN1bSg0LCB1LCA0LCB2LCBhYnQpO1xuICAgICAgICAgICAgczEgPSBhZHh0YWlsICogYmR5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGFkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBhZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGFkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBiZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYmR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBiZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgdDEgPSBiZHh0YWlsICogYWR5dGFpbDtcbiAgICAgICAgICAgIGMgPSBzcGxpdHRlciAqIGJkeHRhaWw7XG4gICAgICAgICAgICBhaGkgPSBjIC0gKGMgLSBiZHh0YWlsKTtcbiAgICAgICAgICAgIGFsbyA9IGJkeHRhaWwgLSBhaGk7XG4gICAgICAgICAgICBjID0gc3BsaXR0ZXIgKiBhZHl0YWlsO1xuICAgICAgICAgICAgYmhpID0gYyAtIChjIC0gYWR5dGFpbCk7XG4gICAgICAgICAgICBibG8gPSBhZHl0YWlsIC0gYmhpO1xuICAgICAgICAgICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgICAgICAgICAgX2kgPSBzMCAtIHQwO1xuICAgICAgICAgICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgICAgICAgICAgYWJ0dFswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgICAgICAgICAgX2ogPSBzMSArIF9pO1xuICAgICAgICAgICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgICAgICAgICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIF9pID0gXzAgLSB0MTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICAgICAgICAgIGFidHRbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICAgICAgICAgIHUzID0gX2ogKyBfaTtcbiAgICAgICAgICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICAgICAgICAgIGFidHRbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICAgICAgICAgIGFidHRbM10gPSB1MztcbiAgICAgICAgICAgIGFidHRsZW4gPSA0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYWJ0WzBdID0gMDtcbiAgICAgICAgICAgIGFidGxlbiA9IDE7XG4gICAgICAgICAgICBhYnR0WzBdID0gMDtcbiAgICAgICAgICAgIGFidHRsZW4gPSAxO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjZHh0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICBjb25zdCBsZW4gPSBzY2FsZShhYnRsZW4sIGFidCwgY2R4dGFpbCwgXzE2Yyk7XG4gICAgICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW0oXG4gICAgICAgICAgICAgICAgc2NhbGUoY3h0YWJsZW4sIGN4dGFiLCBjZHh0YWlsLCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuLCBfMTZjLCAyICogY2R4LCBfMzIpLCBfMzIsIF80OCksIF80OCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGxlbjIgPSBzY2FsZShhYnR0bGVuLCBhYnR0LCBjZHh0YWlsLCBfOCk7XG4gICAgICAgICAgICBmaW5sZW4gPSBmaW5hZGQoZmlubGVuLCBzdW1fdGhyZWUoXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuMiwgXzgsIDIgKiBjZHgsIF8xNiksIF8xNixcbiAgICAgICAgICAgICAgICBzY2FsZShsZW4yLCBfOCwgY2R4dGFpbCwgXzE2YiksIF8xNmIsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuLCBfMTZjLCBjZHh0YWlsLCBfMzIpLCBfMzIsIF8zMmIsIF82NCksIF82NCk7XG5cbiAgICAgICAgICAgIGlmIChhZHl0YWlsICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc2NhbGUoc2NhbGUoNCwgYmIsIGNkeHRhaWwsIF84KSwgXzgsIGFkeXRhaWwsIF8xNiksIF8xNik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYmR5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGZpbmxlbiA9IGZpbmFkZChmaW5sZW4sIHNjYWxlKHNjYWxlKDQsIGFhLCAtY2R4dGFpbCwgXzgpLCBfOCwgYmR5dGFpbCwgXzE2KSwgXzE2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoY2R5dGFpbCAhPT0gMCkge1xuICAgICAgICAgICAgY29uc3QgbGVuID0gc2NhbGUoYWJ0bGVuLCBhYnQsIGNkeXRhaWwsIF8xNmMpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtKFxuICAgICAgICAgICAgICAgIHNjYWxlKGN5dGFibGVuLCBjeXRhYiwgY2R5dGFpbCwgXzE2KSwgXzE2LFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgMiAqIGNkeSwgXzMyKSwgXzMyLCBfNDgpLCBfNDgpO1xuXG4gICAgICAgICAgICBjb25zdCBsZW4yID0gc2NhbGUoYWJ0dGxlbiwgYWJ0dCwgY2R5dGFpbCwgXzgpO1xuICAgICAgICAgICAgZmlubGVuID0gZmluYWRkKGZpbmxlbiwgc3VtX3RocmVlKFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbjIsIF84LCAyICogY2R5LCBfMTYpLCBfMTYsXG4gICAgICAgICAgICAgICAgc2NhbGUobGVuMiwgXzgsIGNkeXRhaWwsIF8xNmIpLCBfMTZiLFxuICAgICAgICAgICAgICAgIHNjYWxlKGxlbiwgXzE2YywgY2R5dGFpbCwgXzMyKSwgXzMyLCBfMzJiLCBfNjQpLCBfNjQpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGZpbltmaW5sZW4gLSAxXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluY2lyY2xlKGF4LCBheSwgYngsIGJ5LCBjeCwgY3ksIGR4LCBkeSkge1xuICAgIGNvbnN0IGFkeCA9IGF4IC0gZHg7XG4gICAgY29uc3QgYmR4ID0gYnggLSBkeDtcbiAgICBjb25zdCBjZHggPSBjeCAtIGR4O1xuICAgIGNvbnN0IGFkeSA9IGF5IC0gZHk7XG4gICAgY29uc3QgYmR5ID0gYnkgLSBkeTtcbiAgICBjb25zdCBjZHkgPSBjeSAtIGR5O1xuXG4gICAgY29uc3QgYmR4Y2R5ID0gYmR4ICogY2R5O1xuICAgIGNvbnN0IGNkeGJkeSA9IGNkeCAqIGJkeTtcbiAgICBjb25zdCBhbGlmdCA9IGFkeCAqIGFkeCArIGFkeSAqIGFkeTtcblxuICAgIGNvbnN0IGNkeGFkeSA9IGNkeCAqIGFkeTtcbiAgICBjb25zdCBhZHhjZHkgPSBhZHggKiBjZHk7XG4gICAgY29uc3QgYmxpZnQgPSBiZHggKiBiZHggKyBiZHkgKiBiZHk7XG5cbiAgICBjb25zdCBhZHhiZHkgPSBhZHggKiBiZHk7XG4gICAgY29uc3QgYmR4YWR5ID0gYmR4ICogYWR5O1xuICAgIGNvbnN0IGNsaWZ0ID0gY2R4ICogY2R4ICsgY2R5ICogY2R5O1xuXG4gICAgY29uc3QgZGV0ID1cbiAgICAgICAgYWxpZnQgKiAoYmR4Y2R5IC0gY2R4YmR5KSArXG4gICAgICAgIGJsaWZ0ICogKGNkeGFkeSAtIGFkeGNkeSkgK1xuICAgICAgICBjbGlmdCAqIChhZHhiZHkgLSBiZHhhZHkpO1xuXG4gICAgY29uc3QgcGVybWFuZW50ID1cbiAgICAgICAgKE1hdGguYWJzKGJkeGNkeSkgKyBNYXRoLmFicyhjZHhiZHkpKSAqIGFsaWZ0ICtcbiAgICAgICAgKE1hdGguYWJzKGNkeGFkeSkgKyBNYXRoLmFicyhhZHhjZHkpKSAqIGJsaWZ0ICtcbiAgICAgICAgKE1hdGguYWJzKGFkeGJkeSkgKyBNYXRoLmFicyhiZHhhZHkpKSAqIGNsaWZ0O1xuXG4gICAgY29uc3QgZXJyYm91bmQgPSBpY2NlcnJib3VuZEEgKiBwZXJtYW5lbnQ7XG5cbiAgICBpZiAoZGV0ID4gZXJyYm91bmQgfHwgLWRldCA+IGVycmJvdW5kKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuICAgIHJldHVybiBpbmNpcmNsZWFkYXB0KGF4LCBheSwgYngsIGJ5LCBjeCwgY3ksIGR4LCBkeSwgcGVybWFuZW50KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluY2lyY2xlZmFzdChheCwgYXksIGJ4LCBieSwgY3gsIGN5LCBkeCwgZHkpIHtcbiAgICBjb25zdCBhZHggPSBheCAtIGR4O1xuICAgIGNvbnN0IGFkeSA9IGF5IC0gZHk7XG4gICAgY29uc3QgYmR4ID0gYnggLSBkeDtcbiAgICBjb25zdCBiZHkgPSBieSAtIGR5O1xuICAgIGNvbnN0IGNkeCA9IGN4IC0gZHg7XG4gICAgY29uc3QgY2R5ID0gY3kgLSBkeTtcblxuICAgIGNvbnN0IGFiZGV0ID0gYWR4ICogYmR5IC0gYmR4ICogYWR5O1xuICAgIGNvbnN0IGJjZGV0ID0gYmR4ICogY2R5IC0gY2R4ICogYmR5O1xuICAgIGNvbnN0IGNhZGV0ID0gY2R4ICogYWR5IC0gYWR4ICogY2R5O1xuICAgIGNvbnN0IGFsaWZ0ID0gYWR4ICogYWR4ICsgYWR5ICogYWR5O1xuICAgIGNvbnN0IGJsaWZ0ID0gYmR4ICogYmR4ICsgYmR5ICogYmR5O1xuICAgIGNvbnN0IGNsaWZ0ID0gY2R4ICogY2R4ICsgY2R5ICogY2R5O1xuXG4gICAgcmV0dXJuIGFsaWZ0ICogYmNkZXQgKyBibGlmdCAqIGNhZGV0ICsgY2xpZnQgKiBhYmRldDtcbn1cbiIsImltcG9ydCB7ZXBzaWxvbiwgc3BsaXR0ZXIsIHJlc3VsdGVycmJvdW5kLCBlc3RpbWF0ZSwgdmVjLCBzdW0sIHN1bV90aHJlZSwgc2NhbGUsIG5lZ2F0ZX0gZnJvbSAnLi91dGlsLmpzJztcblxuY29uc3QgaXNwZXJyYm91bmRBID0gKDE2ICsgMjI0ICogZXBzaWxvbikgKiBlcHNpbG9uO1xuY29uc3QgaXNwZXJyYm91bmRCID0gKDUgKyA3MiAqIGVwc2lsb24pICogZXBzaWxvbjtcbmNvbnN0IGlzcGVycmJvdW5kQyA9ICg3MSArIDE0MDggKiBlcHNpbG9uKSAqIGVwc2lsb24gKiBlcHNpbG9uO1xuXG5jb25zdCBhYiA9IHZlYyg0KTtcbmNvbnN0IGJjID0gdmVjKDQpO1xuY29uc3QgY2QgPSB2ZWMoNCk7XG5jb25zdCBkZSA9IHZlYyg0KTtcbmNvbnN0IGVhID0gdmVjKDQpO1xuY29uc3QgYWMgPSB2ZWMoNCk7XG5jb25zdCBiZCA9IHZlYyg0KTtcbmNvbnN0IGNlID0gdmVjKDQpO1xuY29uc3QgZGEgPSB2ZWMoNCk7XG5jb25zdCBlYiA9IHZlYyg0KTtcblxuY29uc3QgYWJjID0gdmVjKDI0KTtcbmNvbnN0IGJjZCA9IHZlYygyNCk7XG5jb25zdCBjZGUgPSB2ZWMoMjQpO1xuY29uc3QgZGVhID0gdmVjKDI0KTtcbmNvbnN0IGVhYiA9IHZlYygyNCk7XG5jb25zdCBhYmQgPSB2ZWMoMjQpO1xuY29uc3QgYmNlID0gdmVjKDI0KTtcbmNvbnN0IGNkYSA9IHZlYygyNCk7XG5jb25zdCBkZWIgPSB2ZWMoMjQpO1xuY29uc3QgZWFjID0gdmVjKDI0KTtcblxuY29uc3QgYWRldCA9IHZlYygxMTUyKTtcbmNvbnN0IGJkZXQgPSB2ZWMoMTE1Mik7XG5jb25zdCBjZGV0ID0gdmVjKDExNTIpO1xuY29uc3QgZGRldCA9IHZlYygxMTUyKTtcbmNvbnN0IGVkZXQgPSB2ZWMoMTE1Mik7XG5jb25zdCBhYmRldCA9IHZlYygyMzA0KTtcbmNvbnN0IGNkZGV0ID0gdmVjKDIzMDQpO1xuY29uc3QgY2RlZGV0ID0gdmVjKDM0NTYpO1xuY29uc3QgZGV0ZXIgPSB2ZWMoNTc2MCk7XG5cbmNvbnN0IF84ID0gdmVjKDgpO1xuY29uc3QgXzhiID0gdmVjKDgpO1xuY29uc3QgXzhjID0gdmVjKDgpO1xuY29uc3QgXzE2ID0gdmVjKDE2KTtcbmNvbnN0IF8yNCA9IHZlYygyNCk7XG5jb25zdCBfNDggPSB2ZWMoNDgpO1xuY29uc3QgXzQ4YiA9IHZlYyg0OCk7XG5jb25zdCBfOTYgPSB2ZWMoOTYpO1xuY29uc3QgXzE5MiA9IHZlYygxOTIpO1xuY29uc3QgXzM4NHggPSB2ZWMoMzg0KTtcbmNvbnN0IF8zODR5ID0gdmVjKDM4NCk7XG5jb25zdCBfMzg0eiA9IHZlYygzODQpO1xuY29uc3QgXzc2OCA9IHZlYyg3NjgpO1xuXG5mdW5jdGlvbiBzdW1fdGhyZWVfc2NhbGUoYSwgYiwgYywgYXosIGJ6LCBjeiwgb3V0KSB7XG4gICAgcmV0dXJuIHN1bV90aHJlZShcbiAgICAgICAgc2NhbGUoNCwgYSwgYXosIF84KSwgXzgsXG4gICAgICAgIHNjYWxlKDQsIGIsIGJ6LCBfOGIpLCBfOGIsXG4gICAgICAgIHNjYWxlKDQsIGMsIGN6LCBfOGMpLCBfOGMsIF8xNiwgb3V0KTtcbn1cblxuZnVuY3Rpb24gbGlmdGV4YWN0KGFsZW4sIGEsIGJsZW4sIGIsIGNsZW4sIGMsIGRsZW4sIGQsIHgsIHksIHosIG91dCkge1xuICAgIGNvbnN0IGxlbiA9IHN1bShcbiAgICAgICAgc3VtKGFsZW4sIGEsIGJsZW4sIGIsIF80OCksIF80OCxcbiAgICAgICAgbmVnYXRlKHN1bShjbGVuLCBjLCBkbGVuLCBkLCBfNDhiKSwgXzQ4YiksIF80OGIsIF85Nik7XG5cbiAgICByZXR1cm4gc3VtX3RocmVlKFxuICAgICAgICBzY2FsZShzY2FsZShsZW4sIF85NiwgeCwgXzE5MiksIF8xOTIsIHgsIF8zODR4KSwgXzM4NHgsXG4gICAgICAgIHNjYWxlKHNjYWxlKGxlbiwgXzk2LCB5LCBfMTkyKSwgXzE5MiwgeSwgXzM4NHkpLCBfMzg0eSxcbiAgICAgICAgc2NhbGUoc2NhbGUobGVuLCBfOTYsIHosIF8xOTIpLCBfMTkyLCB6LCBfMzg0eiksIF8zODR6LCBfNzY4LCBvdXQpO1xufVxuXG5mdW5jdGlvbiBpbnNwaGVyZWV4YWN0KGF4LCBheSwgYXosIGJ4LCBieSwgYnosIGN4LCBjeSwgY3osIGR4LCBkeSwgZHosIGV4LCBleSwgZXopIHtcbiAgICBsZXQgYnZpcnQsIGMsIGFoaSwgYWxvLCBiaGksIGJsbywgX2ksIF9qLCBfMCwgczEsIHMwLCB0MSwgdDAsIHUzO1xuXG4gICAgczEgPSBheCAqIGJ5O1xuICAgIGMgPSBzcGxpdHRlciAqIGF4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGF4KTtcbiAgICBhbG8gPSBheCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBieTtcbiAgICBiaGkgPSBjIC0gKGMgLSBieSk7XG4gICAgYmxvID0gYnkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gYnggKiBheTtcbiAgICBjID0gc3BsaXR0ZXIgKiBieDtcbiAgICBhaGkgPSBjIC0gKGMgLSBieCk7XG4gICAgYWxvID0gYnggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYXk7XG4gICAgYmhpID0gYyAtIChjIC0gYXkpO1xuICAgIGJsbyA9IGF5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGFiWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgYWJbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGFiWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgYWJbM10gPSB1MztcbiAgICBzMSA9IGJ4ICogY3k7XG4gICAgYyA9IHNwbGl0dGVyICogYng7XG4gICAgYWhpID0gYyAtIChjIC0gYngpO1xuICAgIGFsbyA9IGJ4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGN5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGN5KTtcbiAgICBibG8gPSBjeSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBjeCAqIGJ5O1xuICAgIGMgPSBzcGxpdHRlciAqIGN4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGN4KTtcbiAgICBhbG8gPSBjeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBieTtcbiAgICBiaGkgPSBjIC0gKGMgLSBieSk7XG4gICAgYmxvID0gYnkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgYmNbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBiY1sxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgYmNbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBiY1szXSA9IHUzO1xuICAgIHMxID0gY3ggKiBkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBjeCk7XG4gICAgYWxvID0gY3ggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogZHk7XG4gICAgYmhpID0gYyAtIChjIC0gZHkpO1xuICAgIGJsbyA9IGR5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGR4ICogY3k7XG4gICAgYyA9IHNwbGl0dGVyICogZHg7XG4gICAgYWhpID0gYyAtIChjIC0gZHgpO1xuICAgIGFsbyA9IGR4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGN5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGN5KTtcbiAgICBibG8gPSBjeSAtIGJoaTtcbiAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2kgPSBzMCAtIHQwO1xuICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICBjZFswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIGNkWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgdTMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICBjZFsyXSA9IF9qIC0gKHUzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIGNkWzNdID0gdTM7XG4gICAgczEgPSBkeCAqIGV5O1xuICAgIGMgPSBzcGxpdHRlciAqIGR4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGR4KTtcbiAgICBhbG8gPSBkeCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBleSk7XG4gICAgYmxvID0gZXkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gZXggKiBkeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBleDtcbiAgICBhaGkgPSBjIC0gKGMgLSBleCk7XG4gICAgYWxvID0gZXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogZHk7XG4gICAgYmhpID0gYyAtIChjIC0gZHkpO1xuICAgIGJsbyA9IGR5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGRlWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgZGVbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGRlWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgZGVbM10gPSB1MztcbiAgICBzMSA9IGV4ICogYXk7XG4gICAgYyA9IHNwbGl0dGVyICogZXg7XG4gICAgYWhpID0gYyAtIChjIC0gZXgpO1xuICAgIGFsbyA9IGV4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGF5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGF5KTtcbiAgICBibG8gPSBheSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBheCAqIGV5O1xuICAgIGMgPSBzcGxpdHRlciAqIGF4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGF4KTtcbiAgICBhbG8gPSBheCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBleSk7XG4gICAgYmxvID0gZXkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgZWFbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBlYVsxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgZWFbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBlYVszXSA9IHUzO1xuICAgIHMxID0gYXggKiBjeTtcbiAgICBjID0gc3BsaXR0ZXIgKiBheDtcbiAgICBhaGkgPSBjIC0gKGMgLSBheCk7XG4gICAgYWxvID0gYXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogY3k7XG4gICAgYmhpID0gYyAtIChjIC0gY3kpO1xuICAgIGJsbyA9IGN5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGN4ICogYXk7XG4gICAgYyA9IHNwbGl0dGVyICogY3g7XG4gICAgYWhpID0gYyAtIChjIC0gY3gpO1xuICAgIGFsbyA9IGN4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGF5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGF5KTtcbiAgICBibG8gPSBheSAtIGJoaTtcbiAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2kgPSBzMCAtIHQwO1xuICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICBhY1swXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIGFjWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgdTMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICBhY1syXSA9IF9qIC0gKHUzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIGFjWzNdID0gdTM7XG4gICAgczEgPSBieCAqIGR5O1xuICAgIGMgPSBzcGxpdHRlciAqIGJ4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGJ4KTtcbiAgICBhbG8gPSBieCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBkeTtcbiAgICBiaGkgPSBjIC0gKGMgLSBkeSk7XG4gICAgYmxvID0gZHkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gZHggKiBieTtcbiAgICBjID0gc3BsaXR0ZXIgKiBkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBkeCk7XG4gICAgYWxvID0gZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYnk7XG4gICAgYmhpID0gYyAtIChjIC0gYnkpO1xuICAgIGJsbyA9IGJ5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGJkWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgYmRbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGJkWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgYmRbM10gPSB1MztcbiAgICBzMSA9IGN4ICogZXk7XG4gICAgYyA9IHNwbGl0dGVyICogY3g7XG4gICAgYWhpID0gYyAtIChjIC0gY3gpO1xuICAgIGFsbyA9IGN4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGV5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGV5KTtcbiAgICBibG8gPSBleSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBleCAqIGN5O1xuICAgIGMgPSBzcGxpdHRlciAqIGV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGV4KTtcbiAgICBhbG8gPSBleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjeTtcbiAgICBiaGkgPSBjIC0gKGMgLSBjeSk7XG4gICAgYmxvID0gY3kgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgY2VbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBjZVsxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIHUzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IHUzIC0gX2o7XG4gICAgY2VbMl0gPSBfaiAtICh1MyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBjZVszXSA9IHUzO1xuICAgIHMxID0gZHggKiBheTtcbiAgICBjID0gc3BsaXR0ZXIgKiBkeDtcbiAgICBhaGkgPSBjIC0gKGMgLSBkeCk7XG4gICAgYWxvID0gZHggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYXk7XG4gICAgYmhpID0gYyAtIChjIC0gYXkpO1xuICAgIGJsbyA9IGF5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGF4ICogZHk7XG4gICAgYyA9IHNwbGl0dGVyICogYXg7XG4gICAgYWhpID0gYyAtIChjIC0gYXgpO1xuICAgIGFsbyA9IGF4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGR5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGR5KTtcbiAgICBibG8gPSBkeSAtIGJoaTtcbiAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2kgPSBzMCAtIHQwO1xuICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICBkYVswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIGRhWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgdTMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gdTMgLSBfajtcbiAgICBkYVsyXSA9IF9qIC0gKHUzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIGRhWzNdID0gdTM7XG4gICAgczEgPSBleCAqIGJ5O1xuICAgIGMgPSBzcGxpdHRlciAqIGV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGV4KTtcbiAgICBhbG8gPSBleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBieTtcbiAgICBiaGkgPSBjIC0gKGMgLSBieSk7XG4gICAgYmxvID0gYnkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gYnggKiBleTtcbiAgICBjID0gc3BsaXR0ZXIgKiBieDtcbiAgICBhaGkgPSBjIC0gKGMgLSBieCk7XG4gICAgYWxvID0gYnggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogZXk7XG4gICAgYmhpID0gYyAtIChjIC0gZXkpO1xuICAgIGJsbyA9IGV5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGViWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgZWJbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICB1MyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSB1MyAtIF9qO1xuICAgIGViWzJdID0gX2ogLSAodTMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgZWJbM10gPSB1MztcblxuICAgIGNvbnN0IGFiY2xlbiA9IHN1bV90aHJlZV9zY2FsZShhYiwgYmMsIGFjLCBjeiwgYXosIC1ieiwgYWJjKTtcbiAgICBjb25zdCBiY2RsZW4gPSBzdW1fdGhyZWVfc2NhbGUoYmMsIGNkLCBiZCwgZHosIGJ6LCAtY3osIGJjZCk7XG4gICAgY29uc3QgY2RlbGVuID0gc3VtX3RocmVlX3NjYWxlKGNkLCBkZSwgY2UsIGV6LCBjeiwgLWR6LCBjZGUpO1xuICAgIGNvbnN0IGRlYWxlbiA9IHN1bV90aHJlZV9zY2FsZShkZSwgZWEsIGRhLCBheiwgZHosIC1leiwgZGVhKTtcbiAgICBjb25zdCBlYWJsZW4gPSBzdW1fdGhyZWVfc2NhbGUoZWEsIGFiLCBlYiwgYnosIGV6LCAtYXosIGVhYik7XG4gICAgY29uc3QgYWJkbGVuID0gc3VtX3RocmVlX3NjYWxlKGFiLCBiZCwgZGEsIGR6LCBheiwgYnosIGFiZCk7XG4gICAgY29uc3QgYmNlbGVuID0gc3VtX3RocmVlX3NjYWxlKGJjLCBjZSwgZWIsIGV6LCBieiwgY3osIGJjZSk7XG4gICAgY29uc3QgY2RhbGVuID0gc3VtX3RocmVlX3NjYWxlKGNkLCBkYSwgYWMsIGF6LCBjeiwgZHosIGNkYSk7XG4gICAgY29uc3QgZGVibGVuID0gc3VtX3RocmVlX3NjYWxlKGRlLCBlYiwgYmQsIGJ6LCBkeiwgZXosIGRlYik7XG4gICAgY29uc3QgZWFjbGVuID0gc3VtX3RocmVlX3NjYWxlKGVhLCBhYywgY2UsIGN6LCBleiwgYXosIGVhYyk7XG5cbiAgICBjb25zdCBkZXRlcmxlbiA9IHN1bV90aHJlZShcbiAgICAgICAgbGlmdGV4YWN0KGNkZWxlbiwgY2RlLCBiY2VsZW4sIGJjZSwgZGVibGVuLCBkZWIsIGJjZGxlbiwgYmNkLCBheCwgYXksIGF6LCBhZGV0KSwgYWRldCxcbiAgICAgICAgbGlmdGV4YWN0KGRlYWxlbiwgZGVhLCBjZGFsZW4sIGNkYSwgZWFjbGVuLCBlYWMsIGNkZWxlbiwgY2RlLCBieCwgYnksIGJ6LCBiZGV0KSwgYmRldCxcbiAgICAgICAgc3VtX3RocmVlKFxuICAgICAgICAgICAgbGlmdGV4YWN0KGVhYmxlbiwgZWFiLCBkZWJsZW4sIGRlYiwgYWJkbGVuLCBhYmQsIGRlYWxlbiwgZGVhLCBjeCwgY3ksIGN6LCBjZGV0KSwgY2RldCxcbiAgICAgICAgICAgIGxpZnRleGFjdChhYmNsZW4sIGFiYywgZWFjbGVuLCBlYWMsIGJjZWxlbiwgYmNlLCBlYWJsZW4sIGVhYiwgZHgsIGR5LCBkeiwgZGRldCksIGRkZXQsXG4gICAgICAgICAgICBsaWZ0ZXhhY3QoYmNkbGVuLCBiY2QsIGFiZGxlbiwgYWJkLCBjZGFsZW4sIGNkYSwgYWJjbGVuLCBhYmMsIGV4LCBleSwgZXosIGVkZXQpLCBlZGV0LCBjZGRldCwgY2RlZGV0KSwgY2RlZGV0LCBhYmRldCwgZGV0ZXIpO1xuXG4gICAgcmV0dXJuIGRldGVyW2RldGVybGVuIC0gMV07XG59XG5cbmNvbnN0IHhkZXQgPSB2ZWMoOTYpO1xuY29uc3QgeWRldCA9IHZlYyg5Nik7XG5jb25zdCB6ZGV0ID0gdmVjKDk2KTtcbmNvbnN0IGZpbiA9IHZlYygxMTUyKTtcblxuZnVuY3Rpb24gbGlmdGFkYXB0KGEsIGIsIGMsIGF6LCBieiwgY3osIHgsIHksIHosIG91dCkge1xuICAgIGNvbnN0IGxlbiA9IHN1bV90aHJlZV9zY2FsZShhLCBiLCBjLCBheiwgYnosIGN6LCBfMjQpO1xuICAgIHJldHVybiBzdW1fdGhyZWUoXG4gICAgICAgIHNjYWxlKHNjYWxlKGxlbiwgXzI0LCB4LCBfNDgpLCBfNDgsIHgsIHhkZXQpLCB4ZGV0LFxuICAgICAgICBzY2FsZShzY2FsZShsZW4sIF8yNCwgeSwgXzQ4KSwgXzQ4LCB5LCB5ZGV0KSwgeWRldCxcbiAgICAgICAgc2NhbGUoc2NhbGUobGVuLCBfMjQsIHosIF80OCksIF80OCwgeiwgemRldCksIHpkZXQsIF8xOTIsIG91dCk7XG59XG5cbmZ1bmN0aW9uIGluc3BoZXJlYWRhcHQoYXgsIGF5LCBheiwgYngsIGJ5LCBieiwgY3gsIGN5LCBjeiwgZHgsIGR5LCBkeiwgZXgsIGV5LCBleiwgcGVybWFuZW50KSB7XG4gICAgbGV0IGFiMywgYmMzLCBjZDMsIGRhMywgYWMzLCBiZDM7XG5cbiAgICBsZXQgYWV4dGFpbCwgYmV4dGFpbCwgY2V4dGFpbCwgZGV4dGFpbDtcbiAgICBsZXQgYWV5dGFpbCwgYmV5dGFpbCwgY2V5dGFpbCwgZGV5dGFpbDtcbiAgICBsZXQgYWV6dGFpbCwgYmV6dGFpbCwgY2V6dGFpbCwgZGV6dGFpbDtcblxuICAgIGxldCBidmlydCwgYywgYWhpLCBhbG8sIGJoaSwgYmxvLCBfaSwgX2osIF8wLCBzMSwgczAsIHQxLCB0MDtcblxuICAgIGNvbnN0IGFleCA9IGF4IC0gZXg7XG4gICAgY29uc3QgYmV4ID0gYnggLSBleDtcbiAgICBjb25zdCBjZXggPSBjeCAtIGV4O1xuICAgIGNvbnN0IGRleCA9IGR4IC0gZXg7XG4gICAgY29uc3QgYWV5ID0gYXkgLSBleTtcbiAgICBjb25zdCBiZXkgPSBieSAtIGV5O1xuICAgIGNvbnN0IGNleSA9IGN5IC0gZXk7XG4gICAgY29uc3QgZGV5ID0gZHkgLSBleTtcbiAgICBjb25zdCBhZXogPSBheiAtIGV6O1xuICAgIGNvbnN0IGJleiA9IGJ6IC0gZXo7XG4gICAgY29uc3QgY2V6ID0gY3ogLSBlejtcbiAgICBjb25zdCBkZXogPSBkeiAtIGV6O1xuXG4gICAgczEgPSBhZXggKiBiZXk7XG4gICAgYyA9IHNwbGl0dGVyICogYWV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGFleCk7XG4gICAgYWxvID0gYWV4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGJleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBiZXkpO1xuICAgIGJsbyA9IGJleSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBiZXggKiBhZXk7XG4gICAgYyA9IHNwbGl0dGVyICogYmV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGJleCk7XG4gICAgYWxvID0gYmV4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGFleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBhZXkpO1xuICAgIGJsbyA9IGFleSAtIGJoaTtcbiAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2kgPSBzMCAtIHQwO1xuICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICBhYlswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIGFiWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgYWIzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IGFiMyAtIF9qO1xuICAgIGFiWzJdID0gX2ogLSAoYWIzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIGFiWzNdID0gYWIzO1xuICAgIHMxID0gYmV4ICogY2V5O1xuICAgIGMgPSBzcGxpdHRlciAqIGJleDtcbiAgICBhaGkgPSBjIC0gKGMgLSBiZXgpO1xuICAgIGFsbyA9IGJleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZXk7XG4gICAgYmhpID0gYyAtIChjIC0gY2V5KTtcbiAgICBibG8gPSBjZXkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gY2V4ICogYmV5O1xuICAgIGMgPSBzcGxpdHRlciAqIGNleDtcbiAgICBhaGkgPSBjIC0gKGMgLSBjZXgpO1xuICAgIGFsbyA9IGNleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZXk7XG4gICAgYmhpID0gYyAtIChjIC0gYmV5KTtcbiAgICBibG8gPSBiZXkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgYmNbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBiY1sxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIGJjMyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSBiYzMgLSBfajtcbiAgICBiY1syXSA9IF9qIC0gKGJjMyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBiY1szXSA9IGJjMztcbiAgICBzMSA9IGNleCAqIGRleTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZXg7XG4gICAgYWhpID0gYyAtIChjIC0gY2V4KTtcbiAgICBhbG8gPSBjZXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogZGV5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGRleSk7XG4gICAgYmxvID0gZGV5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGRleCAqIGNleTtcbiAgICBjID0gc3BsaXR0ZXIgKiBkZXg7XG4gICAgYWhpID0gYyAtIChjIC0gZGV4KTtcbiAgICBhbG8gPSBkZXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogY2V5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGNleSk7XG4gICAgYmxvID0gY2V5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGNkWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgY2RbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICBjZDMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gY2QzIC0gX2o7XG4gICAgY2RbMl0gPSBfaiAtIChjZDMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgY2RbM10gPSBjZDM7XG4gICAgczEgPSBkZXggKiBhZXk7XG4gICAgYyA9IHNwbGl0dGVyICogZGV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGRleCk7XG4gICAgYWxvID0gZGV4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGFleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBhZXkpO1xuICAgIGJsbyA9IGFleSAtIGJoaTtcbiAgICBzMCA9IGFsbyAqIGJsbyAtIChzMSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgdDEgPSBhZXggKiBkZXk7XG4gICAgYyA9IHNwbGl0dGVyICogYWV4O1xuICAgIGFoaSA9IGMgLSAoYyAtIGFleCk7XG4gICAgYWxvID0gYWV4IC0gYWhpO1xuICAgIGMgPSBzcGxpdHRlciAqIGRleTtcbiAgICBiaGkgPSBjIC0gKGMgLSBkZXkpO1xuICAgIGJsbyA9IGRleSAtIGJoaTtcbiAgICB0MCA9IGFsbyAqIGJsbyAtICh0MSAtIGFoaSAqIGJoaSAtIGFsbyAqIGJoaSAtIGFoaSAqIGJsbyk7XG4gICAgX2kgPSBzMCAtIHQwO1xuICAgIGJ2aXJ0ID0gczAgLSBfaTtcbiAgICBkYVswXSA9IHMwIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDApO1xuICAgIF9qID0gczEgKyBfaTtcbiAgICBidmlydCA9IF9qIC0gczE7XG4gICAgXzAgPSBzMSAtIChfaiAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBfaSA9IF8wIC0gdDE7XG4gICAgYnZpcnQgPSBfMCAtIF9pO1xuICAgIGRhWzFdID0gXzAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MSk7XG4gICAgZGEzID0gX2ogKyBfaTtcbiAgICBidmlydCA9IGRhMyAtIF9qO1xuICAgIGRhWzJdID0gX2ogLSAoZGEzIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIGRhWzNdID0gZGEzO1xuICAgIHMxID0gYWV4ICogY2V5O1xuICAgIGMgPSBzcGxpdHRlciAqIGFleDtcbiAgICBhaGkgPSBjIC0gKGMgLSBhZXgpO1xuICAgIGFsbyA9IGFleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBjZXk7XG4gICAgYmhpID0gYyAtIChjIC0gY2V5KTtcbiAgICBibG8gPSBjZXkgLSBiaGk7XG4gICAgczAgPSBhbG8gKiBibG8gLSAoczEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIHQxID0gY2V4ICogYWV5O1xuICAgIGMgPSBzcGxpdHRlciAqIGNleDtcbiAgICBhaGkgPSBjIC0gKGMgLSBjZXgpO1xuICAgIGFsbyA9IGNleCAtIGFoaTtcbiAgICBjID0gc3BsaXR0ZXIgKiBhZXk7XG4gICAgYmhpID0gYyAtIChjIC0gYWV5KTtcbiAgICBibG8gPSBhZXkgLSBiaGk7XG4gICAgdDAgPSBhbG8gKiBibG8gLSAodDEgLSBhaGkgKiBiaGkgLSBhbG8gKiBiaGkgLSBhaGkgKiBibG8pO1xuICAgIF9pID0gczAgLSB0MDtcbiAgICBidmlydCA9IHMwIC0gX2k7XG4gICAgYWNbMF0gPSBzMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQwKTtcbiAgICBfaiA9IHMxICsgX2k7XG4gICAgYnZpcnQgPSBfaiAtIHMxO1xuICAgIF8wID0gczEgLSAoX2ogLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgX2kgPSBfMCAtIHQxO1xuICAgIGJ2aXJ0ID0gXzAgLSBfaTtcbiAgICBhY1sxXSA9IF8wIC0gKF9pICsgYnZpcnQpICsgKGJ2aXJ0IC0gdDEpO1xuICAgIGFjMyA9IF9qICsgX2k7XG4gICAgYnZpcnQgPSBhYzMgLSBfajtcbiAgICBhY1syXSA9IF9qIC0gKGFjMyAtIGJ2aXJ0KSArIChfaSAtIGJ2aXJ0KTtcbiAgICBhY1szXSA9IGFjMztcbiAgICBzMSA9IGJleCAqIGRleTtcbiAgICBjID0gc3BsaXR0ZXIgKiBiZXg7XG4gICAgYWhpID0gYyAtIChjIC0gYmV4KTtcbiAgICBhbG8gPSBiZXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogZGV5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGRleSk7XG4gICAgYmxvID0gZGV5IC0gYmhpO1xuICAgIHMwID0gYWxvICogYmxvIC0gKHMxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICB0MSA9IGRleCAqIGJleTtcbiAgICBjID0gc3BsaXR0ZXIgKiBkZXg7XG4gICAgYWhpID0gYyAtIChjIC0gZGV4KTtcbiAgICBhbG8gPSBkZXggLSBhaGk7XG4gICAgYyA9IHNwbGl0dGVyICogYmV5O1xuICAgIGJoaSA9IGMgLSAoYyAtIGJleSk7XG4gICAgYmxvID0gYmV5IC0gYmhpO1xuICAgIHQwID0gYWxvICogYmxvIC0gKHQxIC0gYWhpICogYmhpIC0gYWxvICogYmhpIC0gYWhpICogYmxvKTtcbiAgICBfaSA9IHMwIC0gdDA7XG4gICAgYnZpcnQgPSBzMCAtIF9pO1xuICAgIGJkWzBdID0gczAgLSAoX2kgKyBidmlydCkgKyAoYnZpcnQgLSB0MCk7XG4gICAgX2ogPSBzMSArIF9pO1xuICAgIGJ2aXJ0ID0gX2ogLSBzMTtcbiAgICBfMCA9IHMxIC0gKF9qIC0gYnZpcnQpICsgKF9pIC0gYnZpcnQpO1xuICAgIF9pID0gXzAgLSB0MTtcbiAgICBidmlydCA9IF8wIC0gX2k7XG4gICAgYmRbMV0gPSBfMCAtIChfaSArIGJ2aXJ0KSArIChidmlydCAtIHQxKTtcbiAgICBiZDMgPSBfaiArIF9pO1xuICAgIGJ2aXJ0ID0gYmQzIC0gX2o7XG4gICAgYmRbMl0gPSBfaiAtIChiZDMgLSBidmlydCkgKyAoX2kgLSBidmlydCk7XG4gICAgYmRbM10gPSBiZDM7XG5cbiAgICBjb25zdCBmaW5sZW4gPSBzdW0oXG4gICAgICAgIHN1bShcbiAgICAgICAgICAgIG5lZ2F0ZShsaWZ0YWRhcHQoYmMsIGNkLCBiZCwgZGV6LCBiZXosIC1jZXosIGFleCwgYWV5LCBhZXosIGFkZXQpLCBhZGV0KSwgYWRldCxcbiAgICAgICAgICAgIGxpZnRhZGFwdChjZCwgZGEsIGFjLCBhZXosIGNleiwgZGV6LCBiZXgsIGJleSwgYmV6LCBiZGV0KSwgYmRldCwgYWJkZXQpLCBhYmRldCxcbiAgICAgICAgc3VtKFxuICAgICAgICAgICAgbmVnYXRlKGxpZnRhZGFwdChkYSwgYWIsIGJkLCBiZXosIGRleiwgYWV6LCBjZXgsIGNleSwgY2V6LCBjZGV0KSwgY2RldCksIGNkZXQsXG4gICAgICAgICAgICBsaWZ0YWRhcHQoYWIsIGJjLCBhYywgY2V6LCBhZXosIC1iZXosIGRleCwgZGV5LCBkZXosIGRkZXQpLCBkZGV0LCBjZGRldCksIGNkZGV0LCBmaW4pO1xuXG4gICAgbGV0IGRldCA9IGVzdGltYXRlKGZpbmxlbiwgZmluKTtcbiAgICBsZXQgZXJyYm91bmQgPSBpc3BlcnJib3VuZEIgKiBwZXJtYW5lbnQ7XG4gICAgaWYgKGRldCA+PSBlcnJib3VuZCB8fCAtZGV0ID49IGVycmJvdW5kKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgYnZpcnQgPSBheCAtIGFleDtcbiAgICBhZXh0YWlsID0gYXggLSAoYWV4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZXgpO1xuICAgIGJ2aXJ0ID0gYXkgLSBhZXk7XG4gICAgYWV5dGFpbCA9IGF5IC0gKGFleSArIGJ2aXJ0KSArIChidmlydCAtIGV5KTtcbiAgICBidmlydCA9IGF6IC0gYWV6O1xuICAgIGFlenRhaWwgPSBheiAtIChhZXogKyBidmlydCkgKyAoYnZpcnQgLSBleik7XG4gICAgYnZpcnQgPSBieCAtIGJleDtcbiAgICBiZXh0YWlsID0gYnggLSAoYmV4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZXgpO1xuICAgIGJ2aXJ0ID0gYnkgLSBiZXk7XG4gICAgYmV5dGFpbCA9IGJ5IC0gKGJleSArIGJ2aXJ0KSArIChidmlydCAtIGV5KTtcbiAgICBidmlydCA9IGJ6IC0gYmV6O1xuICAgIGJlenRhaWwgPSBieiAtIChiZXogKyBidmlydCkgKyAoYnZpcnQgLSBleik7XG4gICAgYnZpcnQgPSBjeCAtIGNleDtcbiAgICBjZXh0YWlsID0gY3ggLSAoY2V4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZXgpO1xuICAgIGJ2aXJ0ID0gY3kgLSBjZXk7XG4gICAgY2V5dGFpbCA9IGN5IC0gKGNleSArIGJ2aXJ0KSArIChidmlydCAtIGV5KTtcbiAgICBidmlydCA9IGN6IC0gY2V6O1xuICAgIGNlenRhaWwgPSBjeiAtIChjZXogKyBidmlydCkgKyAoYnZpcnQgLSBleik7XG4gICAgYnZpcnQgPSBkeCAtIGRleDtcbiAgICBkZXh0YWlsID0gZHggLSAoZGV4ICsgYnZpcnQpICsgKGJ2aXJ0IC0gZXgpO1xuICAgIGJ2aXJ0ID0gZHkgLSBkZXk7XG4gICAgZGV5dGFpbCA9IGR5IC0gKGRleSArIGJ2aXJ0KSArIChidmlydCAtIGV5KTtcbiAgICBidmlydCA9IGR6IC0gZGV6O1xuICAgIGRlenRhaWwgPSBkeiAtIChkZXogKyBidmlydCkgKyAoYnZpcnQgLSBleik7XG4gICAgaWYgKGFleHRhaWwgPT09IDAgJiYgYWV5dGFpbCA9PT0gMCAmJiBhZXp0YWlsID09PSAwICYmXG4gICAgICAgIGJleHRhaWwgPT09IDAgJiYgYmV5dGFpbCA9PT0gMCAmJiBiZXp0YWlsID09PSAwICYmXG4gICAgICAgIGNleHRhaWwgPT09IDAgJiYgY2V5dGFpbCA9PT0gMCAmJiBjZXp0YWlsID09PSAwICYmXG4gICAgICAgIGRleHRhaWwgPT09IDAgJiYgZGV5dGFpbCA9PT0gMCAmJiBkZXp0YWlsID09PSAwKSB7XG4gICAgICAgIHJldHVybiBkZXQ7XG4gICAgfVxuXG4gICAgZXJyYm91bmQgPSBpc3BlcnJib3VuZEMgKiBwZXJtYW5lbnQgKyByZXN1bHRlcnJib3VuZCAqIE1hdGguYWJzKGRldCk7XG5cbiAgICBjb25zdCBhYmVwcyA9IChhZXggKiBiZXl0YWlsICsgYmV5ICogYWV4dGFpbCkgLSAoYWV5ICogYmV4dGFpbCArIGJleCAqIGFleXRhaWwpO1xuICAgIGNvbnN0IGJjZXBzID0gKGJleCAqIGNleXRhaWwgKyBjZXkgKiBiZXh0YWlsKSAtIChiZXkgKiBjZXh0YWlsICsgY2V4ICogYmV5dGFpbCk7XG4gICAgY29uc3QgY2RlcHMgPSAoY2V4ICogZGV5dGFpbCArIGRleSAqIGNleHRhaWwpIC0gKGNleSAqIGRleHRhaWwgKyBkZXggKiBjZXl0YWlsKTtcbiAgICBjb25zdCBkYWVwcyA9IChkZXggKiBhZXl0YWlsICsgYWV5ICogZGV4dGFpbCkgLSAoZGV5ICogYWV4dGFpbCArIGFleCAqIGRleXRhaWwpO1xuICAgIGNvbnN0IGFjZXBzID0gKGFleCAqIGNleXRhaWwgKyBjZXkgKiBhZXh0YWlsKSAtIChhZXkgKiBjZXh0YWlsICsgY2V4ICogYWV5dGFpbCk7XG4gICAgY29uc3QgYmRlcHMgPSAoYmV4ICogZGV5dGFpbCArIGRleSAqIGJleHRhaWwpIC0gKGJleSAqIGRleHRhaWwgKyBkZXggKiBiZXl0YWlsKTtcbiAgICBkZXQgKz1cbiAgICAgICAgKCgoYmV4ICogYmV4ICsgYmV5ICogYmV5ICsgYmV6ICogYmV6KSAqICgoY2V6ICogZGFlcHMgKyBkZXogKiBhY2VwcyArIGFleiAqIGNkZXBzKSArXG4gICAgICAgIChjZXp0YWlsICogZGEzICsgZGV6dGFpbCAqIGFjMyArIGFlenRhaWwgKiBjZDMpKSArIChkZXggKiBkZXggKyBkZXkgKiBkZXkgKyBkZXogKiBkZXopICpcbiAgICAgICAgKChhZXogKiBiY2VwcyAtIGJleiAqIGFjZXBzICsgY2V6ICogYWJlcHMpICsgKGFlenRhaWwgKiBiYzMgLSBiZXp0YWlsICogYWMzICsgY2V6dGFpbCAqIGFiMykpKSAtXG4gICAgICAgICgoYWV4ICogYWV4ICsgYWV5ICogYWV5ICsgYWV6ICogYWV6KSAqICgoYmV6ICogY2RlcHMgLSBjZXogKiBiZGVwcyArIGRleiAqIGJjZXBzKSArXG4gICAgICAgIChiZXp0YWlsICogY2QzIC0gY2V6dGFpbCAqIGJkMyArIGRlenRhaWwgKiBiYzMpKSArIChjZXggKiBjZXggKyBjZXkgKiBjZXkgKyBjZXogKiBjZXopICpcbiAgICAgICAgKChkZXogKiBhYmVwcyArIGFleiAqIGJkZXBzICsgYmV6ICogZGFlcHMpICsgKGRlenRhaWwgKiBhYjMgKyBhZXp0YWlsICogYmQzICsgYmV6dGFpbCAqIGRhMykpKSkgK1xuICAgICAgICAyICogKCgoYmV4ICogYmV4dGFpbCArIGJleSAqIGJleXRhaWwgKyBiZXogKiBiZXp0YWlsKSAqIChjZXogKiBkYTMgKyBkZXogKiBhYzMgKyBhZXogKiBjZDMpICtcbiAgICAgICAgKGRleCAqIGRleHRhaWwgKyBkZXkgKiBkZXl0YWlsICsgZGV6ICogZGV6dGFpbCkgKiAoYWV6ICogYmMzIC0gYmV6ICogYWMzICsgY2V6ICogYWIzKSkgLVxuICAgICAgICAoKGFleCAqIGFleHRhaWwgKyBhZXkgKiBhZXl0YWlsICsgYWV6ICogYWV6dGFpbCkgKiAoYmV6ICogY2QzIC0gY2V6ICogYmQzICsgZGV6ICogYmMzKSArXG4gICAgICAgIChjZXggKiBjZXh0YWlsICsgY2V5ICogY2V5dGFpbCArIGNleiAqIGNlenRhaWwpICogKGRleiAqIGFiMyArIGFleiAqIGJkMyArIGJleiAqIGRhMykpKTtcblxuICAgIGlmIChkZXQgPj0gZXJyYm91bmQgfHwgLWRldCA+PSBlcnJib3VuZCkge1xuICAgICAgICByZXR1cm4gZGV0O1xuICAgIH1cblxuICAgIHJldHVybiBpbnNwaGVyZWV4YWN0KGF4LCBheSwgYXosIGJ4LCBieSwgYnosIGN4LCBjeSwgY3osIGR4LCBkeSwgZHosIGV4LCBleSwgZXopO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaW5zcGhlcmUoYXgsIGF5LCBheiwgYngsIGJ5LCBieiwgY3gsIGN5LCBjeiwgZHgsIGR5LCBkeiwgZXgsIGV5LCBleikge1xuICAgIGNvbnN0IGFleCA9IGF4IC0gZXg7XG4gICAgY29uc3QgYmV4ID0gYnggLSBleDtcbiAgICBjb25zdCBjZXggPSBjeCAtIGV4O1xuICAgIGNvbnN0IGRleCA9IGR4IC0gZXg7XG4gICAgY29uc3QgYWV5ID0gYXkgLSBleTtcbiAgICBjb25zdCBiZXkgPSBieSAtIGV5O1xuICAgIGNvbnN0IGNleSA9IGN5IC0gZXk7XG4gICAgY29uc3QgZGV5ID0gZHkgLSBleTtcbiAgICBjb25zdCBhZXogPSBheiAtIGV6O1xuICAgIGNvbnN0IGJleiA9IGJ6IC0gZXo7XG4gICAgY29uc3QgY2V6ID0gY3ogLSBlejtcbiAgICBjb25zdCBkZXogPSBkeiAtIGV6O1xuXG4gICAgY29uc3QgYWV4YmV5ID0gYWV4ICogYmV5O1xuICAgIGNvbnN0IGJleGFleSA9IGJleCAqIGFleTtcbiAgICBjb25zdCBhYiA9IGFleGJleSAtIGJleGFleTtcbiAgICBjb25zdCBiZXhjZXkgPSBiZXggKiBjZXk7XG4gICAgY29uc3QgY2V4YmV5ID0gY2V4ICogYmV5O1xuICAgIGNvbnN0IGJjID0gYmV4Y2V5IC0gY2V4YmV5O1xuICAgIGNvbnN0IGNleGRleSA9IGNleCAqIGRleTtcbiAgICBjb25zdCBkZXhjZXkgPSBkZXggKiBjZXk7XG4gICAgY29uc3QgY2QgPSBjZXhkZXkgLSBkZXhjZXk7XG4gICAgY29uc3QgZGV4YWV5ID0gZGV4ICogYWV5O1xuICAgIGNvbnN0IGFleGRleSA9IGFleCAqIGRleTtcbiAgICBjb25zdCBkYSA9IGRleGFleSAtIGFleGRleTtcbiAgICBjb25zdCBhZXhjZXkgPSBhZXggKiBjZXk7XG4gICAgY29uc3QgY2V4YWV5ID0gY2V4ICogYWV5O1xuICAgIGNvbnN0IGFjID0gYWV4Y2V5IC0gY2V4YWV5O1xuICAgIGNvbnN0IGJleGRleSA9IGJleCAqIGRleTtcbiAgICBjb25zdCBkZXhiZXkgPSBkZXggKiBiZXk7XG4gICAgY29uc3QgYmQgPSBiZXhkZXkgLSBkZXhiZXk7XG5cbiAgICBjb25zdCBhbGlmdCA9IGFleCAqIGFleCArIGFleSAqIGFleSArIGFleiAqIGFlejtcbiAgICBjb25zdCBibGlmdCA9IGJleCAqIGJleCArIGJleSAqIGJleSArIGJleiAqIGJlejtcbiAgICBjb25zdCBjbGlmdCA9IGNleCAqIGNleCArIGNleSAqIGNleSArIGNleiAqIGNlejtcbiAgICBjb25zdCBkbGlmdCA9IGRleCAqIGRleCArIGRleSAqIGRleSArIGRleiAqIGRlejtcblxuICAgIGNvbnN0IGRldCA9XG4gICAgICAgIChjbGlmdCAqIChkZXogKiBhYiArIGFleiAqIGJkICsgYmV6ICogZGEpIC0gZGxpZnQgKiAoYWV6ICogYmMgLSBiZXogKiBhYyArIGNleiAqIGFiKSkgK1xuICAgICAgICAoYWxpZnQgKiAoYmV6ICogY2QgLSBjZXogKiBiZCArIGRleiAqIGJjKSAtIGJsaWZ0ICogKGNleiAqIGRhICsgZGV6ICogYWMgKyBhZXogKiBjZCkpO1xuXG4gICAgY29uc3QgYWV6cGx1cyA9IE1hdGguYWJzKGFleik7XG4gICAgY29uc3QgYmV6cGx1cyA9IE1hdGguYWJzKGJleik7XG4gICAgY29uc3QgY2V6cGx1cyA9IE1hdGguYWJzKGNleik7XG4gICAgY29uc3QgZGV6cGx1cyA9IE1hdGguYWJzKGRleik7XG4gICAgY29uc3QgYWV4YmV5cGx1cyA9IE1hdGguYWJzKGFleGJleSkgKyBNYXRoLmFicyhiZXhhZXkpO1xuICAgIGNvbnN0IGJleGNleXBsdXMgPSBNYXRoLmFicyhiZXhjZXkpICsgTWF0aC5hYnMoY2V4YmV5KTtcbiAgICBjb25zdCBjZXhkZXlwbHVzID0gTWF0aC5hYnMoY2V4ZGV5KSArIE1hdGguYWJzKGRleGNleSk7XG4gICAgY29uc3QgZGV4YWV5cGx1cyA9IE1hdGguYWJzKGRleGFleSkgKyBNYXRoLmFicyhhZXhkZXkpO1xuICAgIGNvbnN0IGFleGNleXBsdXMgPSBNYXRoLmFicyhhZXhjZXkpICsgTWF0aC5hYnMoY2V4YWV5KTtcbiAgICBjb25zdCBiZXhkZXlwbHVzID0gTWF0aC5hYnMoYmV4ZGV5KSArIE1hdGguYWJzKGRleGJleSk7XG4gICAgY29uc3QgcGVybWFuZW50ID1cbiAgICAgICAgKGNleGRleXBsdXMgKiBiZXpwbHVzICsgYmV4ZGV5cGx1cyAqIGNlenBsdXMgKyBiZXhjZXlwbHVzICogZGV6cGx1cykgKiBhbGlmdCArXG4gICAgICAgIChkZXhhZXlwbHVzICogY2V6cGx1cyArIGFleGNleXBsdXMgKiBkZXpwbHVzICsgY2V4ZGV5cGx1cyAqIGFlenBsdXMpICogYmxpZnQgK1xuICAgICAgICAoYWV4YmV5cGx1cyAqIGRlenBsdXMgKyBiZXhkZXlwbHVzICogYWV6cGx1cyArIGRleGFleXBsdXMgKiBiZXpwbHVzKSAqIGNsaWZ0ICtcbiAgICAgICAgKGJleGNleXBsdXMgKiBhZXpwbHVzICsgYWV4Y2V5cGx1cyAqIGJlenBsdXMgKyBhZXhiZXlwbHVzICogY2V6cGx1cykgKiBkbGlmdDtcblxuICAgIGNvbnN0IGVycmJvdW5kID0gaXNwZXJyYm91bmRBICogcGVybWFuZW50O1xuICAgIGlmIChkZXQgPiBlcnJib3VuZCB8fCAtZGV0ID4gZXJyYm91bmQpIHtcbiAgICAgICAgcmV0dXJuIGRldDtcbiAgICB9XG4gICAgcmV0dXJuIC1pbnNwaGVyZWFkYXB0KGF4LCBheSwgYXosIGJ4LCBieSwgYnosIGN4LCBjeSwgY3osIGR4LCBkeSwgZHosIGV4LCBleSwgZXosIHBlcm1hbmVudCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbnNwaGVyZWZhc3QocGF4LCBwYXksIHBheiwgcGJ4LCBwYnksIHBieiwgcGN4LCBwY3ksIHBjeiwgcGR4LCBwZHksIHBkeiwgcGV4LCBwZXksIHBleikge1xuICAgIGNvbnN0IGFleCA9IHBheCAtIHBleDtcbiAgICBjb25zdCBiZXggPSBwYnggLSBwZXg7XG4gICAgY29uc3QgY2V4ID0gcGN4IC0gcGV4O1xuICAgIGNvbnN0IGRleCA9IHBkeCAtIHBleDtcbiAgICBjb25zdCBhZXkgPSBwYXkgLSBwZXk7XG4gICAgY29uc3QgYmV5ID0gcGJ5IC0gcGV5O1xuICAgIGNvbnN0IGNleSA9IHBjeSAtIHBleTtcbiAgICBjb25zdCBkZXkgPSBwZHkgLSBwZXk7XG4gICAgY29uc3QgYWV6ID0gcGF6IC0gcGV6O1xuICAgIGNvbnN0IGJleiA9IHBieiAtIHBlejtcbiAgICBjb25zdCBjZXogPSBwY3ogLSBwZXo7XG4gICAgY29uc3QgZGV6ID0gcGR6IC0gcGV6O1xuXG4gICAgY29uc3QgYWIgPSBhZXggKiBiZXkgLSBiZXggKiBhZXk7XG4gICAgY29uc3QgYmMgPSBiZXggKiBjZXkgLSBjZXggKiBiZXk7XG4gICAgY29uc3QgY2QgPSBjZXggKiBkZXkgLSBkZXggKiBjZXk7XG4gICAgY29uc3QgZGEgPSBkZXggKiBhZXkgLSBhZXggKiBkZXk7XG4gICAgY29uc3QgYWMgPSBhZXggKiBjZXkgLSBjZXggKiBhZXk7XG4gICAgY29uc3QgYmQgPSBiZXggKiBkZXkgLSBkZXggKiBiZXk7XG5cbiAgICBjb25zdCBhYmMgPSBhZXogKiBiYyAtIGJleiAqIGFjICsgY2V6ICogYWI7XG4gICAgY29uc3QgYmNkID0gYmV6ICogY2QgLSBjZXogKiBiZCArIGRleiAqIGJjO1xuICAgIGNvbnN0IGNkYSA9IGNleiAqIGRhICsgZGV6ICogYWMgKyBhZXogKiBjZDtcbiAgICBjb25zdCBkYWIgPSBkZXogKiBhYiArIGFleiAqIGJkICsgYmV6ICogZGE7XG5cbiAgICBjb25zdCBhbGlmdCA9IGFleCAqIGFleCArIGFleSAqIGFleSArIGFleiAqIGFlejtcbiAgICBjb25zdCBibGlmdCA9IGJleCAqIGJleCArIGJleSAqIGJleSArIGJleiAqIGJlejtcbiAgICBjb25zdCBjbGlmdCA9IGNleCAqIGNleCArIGNleSAqIGNleSArIGNleiAqIGNlejtcbiAgICBjb25zdCBkbGlmdCA9IGRleCAqIGRleCArIGRleSAqIGRleSArIGRleiAqIGRlejtcblxuICAgIHJldHVybiAoY2xpZnQgKiBkYWIgLSBkbGlmdCAqIGFiYykgKyAoYWxpZnQgKiBiY2QgLSBibGlmdCAqIGNkYSk7XG59XG4iLCJcbmV4cG9ydCB7b3JpZW50MmQsIG9yaWVudDJkZmFzdH0gZnJvbSAnLi9lc20vb3JpZW50MmQuanMnO1xuZXhwb3J0IHtvcmllbnQzZCwgb3JpZW50M2RmYXN0fSBmcm9tICcuL2VzbS9vcmllbnQzZC5qcyc7XG5leHBvcnQge2luY2lyY2xlLCBpbmNpcmNsZWZhc3R9IGZyb20gJy4vZXNtL2luY2lyY2xlLmpzJztcbmV4cG9ydCB7aW5zcGhlcmUsIGluc3BoZXJlZmFzdH0gZnJvbSAnLi9lc20vaW5zcGhlcmUuanMnO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9