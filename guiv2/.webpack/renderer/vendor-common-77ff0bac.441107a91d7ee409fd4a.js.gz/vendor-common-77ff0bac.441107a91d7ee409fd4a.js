"use strict";
(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[8522],{

/***/ 16072:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  ll: () => (/* reexport */ floating_ui_dom/* autoUpdate */.ll),
  UU: () => (/* reexport */ flip),
  vW: () => (/* binding */ inner),
  cY: () => (/* reexport */ offset),
  BN: () => (/* reexport */ shift),
  Ej: () => (/* reexport */ size),
  we: () => (/* binding */ floating_ui_react_useFloating),
  Zx: () => (/* binding */ useInnerOffset),
  bv: () => (/* binding */ useInteractions)
});

// UNUSED EXPORTS: Composite, CompositeItem, FloatingArrow, FloatingDelayGroup, FloatingFocusManager, FloatingList, FloatingNode, FloatingOverlay, FloatingPortal, FloatingTree, arrow, autoPlacement, computePosition, detectOverflow, getOverflowAncestors, hide, inline, limitShift, platform, safePolygon, useClick, useClientPoint, useDelayGroup, useDelayGroupContext, useDismiss, useFloatingNodeId, useFloatingParentNodeId, useFloatingPortalNode, useFloatingRootContext, useFloatingTree, useFocus, useHover, useId, useListItem, useListNavigation, useMergeRefs, useRole, useTransitionStatus, useTransitionStyles, useTypeahead

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
var react_namespaceObject = /*#__PURE__*/__webpack_require__.t(react, 2);
// EXTERNAL MODULE: ./node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
var floating_ui_utils_dom = __webpack_require__(86635);
;// ./node_modules/@floating-ui/react/dist/floating-ui.react.utils.mjs


function floating_ui_react_utils_activeElement(doc) {
  let activeElement = doc.activeElement;
  while (((_activeElement = activeElement) == null || (_activeElement = _activeElement.shadowRoot) == null ? void 0 : _activeElement.activeElement) != null) {
    var _activeElement;
    activeElement = activeElement.shadowRoot.activeElement;
  }
  return activeElement;
}
function floating_ui_react_utils_contains(parent, child) {
  if (!parent || !child) {
    return false;
  }
  const rootNode = child.getRootNode == null ? void 0 : child.getRootNode();

  // First, attempt with faster native method
  if (parent.contains(child)) {
    return true;
  }

  // then fallback to custom implementation with Shadow DOM support
  if (rootNode && isShadowRoot(rootNode)) {
    let next = child;
    while (next) {
      if (parent === next) {
        return true;
      }
      // @ts-ignore
      next = next.parentNode || next.host;
    }
  }

  // Give up, the result is false
  return false;
}
// Avoid Chrome DevTools blue warning.
function floating_ui_react_utils_getPlatform() {
  const uaData = navigator.userAgentData;
  if (uaData != null && uaData.platform) {
    return uaData.platform;
  }
  return navigator.platform;
}
function getUserAgent() {
  const uaData = navigator.userAgentData;
  if (uaData && Array.isArray(uaData.brands)) {
    return uaData.brands.map(_ref => {
      let {
        brand,
        version
      } = _ref;
      return brand + "/" + version;
    }).join(' ');
  }
  return navigator.userAgent;
}

// License: https://github.com/adobe/react-spectrum/blob/b35d5c02fe900badccd0cf1a8f23bb593419f238/packages/@react-aria/utils/src/isVirtualEvent.ts
function floating_ui_react_utils_isVirtualClick(event) {
  // FIXME: Firefox is now emitting a deprecation warning for `mozInputSource`.
  // Try to find a workaround for this. `react-aria` source still has the check.
  if (event.mozInputSource === 0 && event.isTrusted) {
    return true;
  }
  if (isAndroid() && event.pointerType) {
    return event.type === 'click' && event.buttons === 1;
  }
  return event.detail === 0 && !event.pointerType;
}
function floating_ui_react_utils_isVirtualPointerEvent(event) {
  if (isJSDOM()) return false;
  return !isAndroid() && event.width === 0 && event.height === 0 || isAndroid() && event.width === 1 && event.height === 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === 'mouse' ||
  // iOS VoiceOver returns 0.333• for width/height.
  event.width < 1 && event.height < 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === 'touch';
}
function floating_ui_react_utils_isSafari() {
  // Chrome DevTools does not complain about navigator.vendor
  return /apple/i.test(navigator.vendor);
}
function isAndroid() {
  const re = /android/i;
  return re.test(floating_ui_react_utils_getPlatform()) || re.test(getUserAgent());
}
function floating_ui_react_utils_isMac() {
  return floating_ui_react_utils_getPlatform().toLowerCase().startsWith('mac') && !navigator.maxTouchPoints;
}
function isJSDOM() {
  return getUserAgent().includes('jsdom/');
}
function floating_ui_react_utils_isMouseLikePointerType(pointerType, strict) {
  // On some Linux machines with Chromium, mouse inputs return a `pointerType`
  // of "pen": https://github.com/floating-ui/floating-ui/issues/2015
  const values = ['mouse', 'pen'];
  if (!strict) {
    values.push('', undefined);
  }
  return values.includes(pointerType);
}
function floating_ui_react_utils_isReactEvent(event) {
  return 'nativeEvent' in event;
}
function floating_ui_react_utils_isRootElement(element) {
  return element.matches('html,body');
}
function floating_ui_react_utils_getDocument(node) {
  return (node == null ? void 0 : node.ownerDocument) || document;
}
function floating_ui_react_utils_isEventTargetWithin(event, node) {
  if (node == null) {
    return false;
  }
  if ('composedPath' in event) {
    return event.composedPath().includes(node);
  }

  // TS thinks `event` is of type never as it assumes all browsers support composedPath, but browsers without shadow dom don't
  const e = event;
  return e.target != null && node.contains(e.target);
}
function floating_ui_react_utils_getTarget(event) {
  if ('composedPath' in event) {
    return event.composedPath()[0];
  }

  // TS thinks `event` is of type never as it assumes all browsers support
  // `composedPath()`, but browsers without shadow DOM don't.
  return event.target;
}
const TYPEABLE_SELECTOR = (/* unused pure expression or super */ null && ("input:not([type='hidden']):not([disabled])," + "[contenteditable]:not([contenteditable='false']),textarea:not([disabled])"));
function floating_ui_react_utils_isTypeableElement(element) {
  return isHTMLElement(element) && element.matches(TYPEABLE_SELECTOR);
}
function floating_ui_react_utils_stopEvent(event) {
  event.preventDefault();
  event.stopPropagation();
}
function floating_ui_react_utils_isTypeableCombobox(element) {
  if (!element) return false;
  return element.getAttribute('role') === 'combobox' && floating_ui_react_utils_isTypeableElement(element);
}



// EXTERNAL MODULE: ./node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var floating_ui_utils = __webpack_require__(97193);
// EXTERNAL MODULE: ./node_modules/tabbable/dist/index.esm.js
var index_esm = __webpack_require__(49054);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(40961);
// EXTERNAL MODULE: ./node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs + 1 modules
var floating_ui_dom = __webpack_require__(46885);
;// ./node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs






var isClient = typeof document !== 'undefined';

var noop = function noop() {};
var index = isClient ? react.useLayoutEffect : noop;

// Fork of `fast-deep-equal` that only does the comparisons we need and compares
// functions
function deepEqual(a, b) {
  if (a === b) {
    return true;
  }
  if (typeof a !== typeof b) {
    return false;
  }
  if (typeof a === 'function' && a.toString() === b.toString()) {
    return true;
  }
  let length;
  let i;
  let keys;
  if (a && b && typeof a === 'object') {
    if (Array.isArray(a)) {
      length = a.length;
      if (length !== b.length) return false;
      for (i = length; i-- !== 0;) {
        if (!deepEqual(a[i], b[i])) {
          return false;
        }
      }
      return true;
    }
    keys = Object.keys(a);
    length = keys.length;
    if (length !== Object.keys(b).length) {
      return false;
    }
    for (i = length; i-- !== 0;) {
      if (!{}.hasOwnProperty.call(b, keys[i])) {
        return false;
      }
    }
    for (i = length; i-- !== 0;) {
      const key = keys[i];
      if (key === '_owner' && a.$$typeof) {
        continue;
      }
      if (!deepEqual(a[key], b[key])) {
        return false;
      }
    }
    return true;
  }
  return a !== a && b !== b;
}

function getDPR(element) {
  if (typeof window === 'undefined') {
    return 1;
  }
  const win = element.ownerDocument.defaultView || window;
  return win.devicePixelRatio || 1;
}

function roundByDPR(element, value) {
  const dpr = getDPR(element);
  return Math.round(value * dpr) / dpr;
}

function useLatestRef(value) {
  const ref = react.useRef(value);
  index(() => {
    ref.current = value;
  });
  return ref;
}

/**
 * Provides data to position a floating element.
 * @see https://floating-ui.com/docs/useFloating
 */
function useFloating(options) {
  if (options === void 0) {
    options = {};
  }
  const {
    placement = 'bottom',
    strategy = 'absolute',
    middleware = [],
    platform,
    elements: {
      reference: externalReference,
      floating: externalFloating
    } = {},
    transform = true,
    whileElementsMounted,
    open
  } = options;
  const [data, setData] = react.useState({
    x: 0,
    y: 0,
    strategy,
    placement,
    middlewareData: {},
    isPositioned: false
  });
  const [latestMiddleware, setLatestMiddleware] = react.useState(middleware);
  if (!deepEqual(latestMiddleware, middleware)) {
    setLatestMiddleware(middleware);
  }
  const [_reference, _setReference] = react.useState(null);
  const [_floating, _setFloating] = react.useState(null);
  const setReference = react.useCallback(node => {
    if (node !== referenceRef.current) {
      referenceRef.current = node;
      _setReference(node);
    }
  }, []);
  const setFloating = react.useCallback(node => {
    if (node !== floatingRef.current) {
      floatingRef.current = node;
      _setFloating(node);
    }
  }, []);
  const referenceEl = externalReference || _reference;
  const floatingEl = externalFloating || _floating;
  const referenceRef = react.useRef(null);
  const floatingRef = react.useRef(null);
  const dataRef = react.useRef(data);
  const hasWhileElementsMounted = whileElementsMounted != null;
  const whileElementsMountedRef = useLatestRef(whileElementsMounted);
  const platformRef = useLatestRef(platform);
  const openRef = useLatestRef(open);
  const update = react.useCallback(() => {
    if (!referenceRef.current || !floatingRef.current) {
      return;
    }
    const config = {
      placement,
      strategy,
      middleware: latestMiddleware
    };
    if (platformRef.current) {
      config.platform = platformRef.current;
    }
    (0,floating_ui_dom/* computePosition */.rD)(referenceRef.current, floatingRef.current, config).then(data => {
      const fullData = {
        ...data,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: openRef.current !== false
      };
      if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
        dataRef.current = fullData;
        react_dom.flushSync(() => {
          setData(fullData);
        });
      }
    });
  }, [latestMiddleware, placement, strategy, platformRef, openRef]);
  index(() => {
    if (open === false && dataRef.current.isPositioned) {
      dataRef.current.isPositioned = false;
      setData(data => ({
        ...data,
        isPositioned: false
      }));
    }
  }, [open]);
  const isMountedRef = react.useRef(false);
  index(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  index(() => {
    if (referenceEl) referenceRef.current = referenceEl;
    if (floatingEl) floatingRef.current = floatingEl;
    if (referenceEl && floatingEl) {
      if (whileElementsMountedRef.current) {
        return whileElementsMountedRef.current(referenceEl, floatingEl, update);
      }
      update();
    }
  }, [referenceEl, floatingEl, update, whileElementsMountedRef, hasWhileElementsMounted]);
  const refs = react.useMemo(() => ({
    reference: referenceRef,
    floating: floatingRef,
    setReference,
    setFloating
  }), [setReference, setFloating]);
  const elements = react.useMemo(() => ({
    reference: referenceEl,
    floating: floatingEl
  }), [referenceEl, floatingEl]);
  const floatingStyles = react.useMemo(() => {
    const initialStyles = {
      position: strategy,
      left: 0,
      top: 0
    };
    if (!elements.floating) {
      return initialStyles;
    }
    const x = roundByDPR(elements.floating, data.x);
    const y = roundByDPR(elements.floating, data.y);
    if (transform) {
      return {
        ...initialStyles,
        transform: "translate(" + x + "px, " + y + "px)",
        ...(getDPR(elements.floating) >= 1.5 && {
          willChange: 'transform'
        })
      };
    }
    return {
      position: strategy,
      left: x,
      top: y
    };
  }, [strategy, transform, elements.floating, data.x, data.y]);
  return react.useMemo(() => ({
    ...data,
    update,
    refs,
    elements,
    floatingStyles
  }), [data, update, refs, elements, floatingStyles]);
}

/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * This wraps the core `arrow` middleware to allow React refs as the element.
 * @see https://floating-ui.com/docs/arrow
 */
const arrow$1 = options => {
  function isRef(value) {
    return {}.hasOwnProperty.call(value, 'current');
  }
  return {
    name: 'arrow',
    options,
    fn(state) {
      const {
        element,
        padding
      } = typeof options === 'function' ? options(state) : options;
      if (element && isRef(element)) {
        if (element.current != null) {
          return arrow$2({
            element: element.current,
            padding
          }).fn(state);
        }
        return {};
      }
      if (element) {
        return arrow$2({
          element,
          padding
        }).fn(state);
      }
      return {};
    }
  };
};

/**
 * Modifies the placement by translating the floating element along the
 * specified axes.
 * A number (shorthand for `mainAxis` or distance), or an axes configuration
 * object may be passed.
 * @see https://floating-ui.com/docs/offset
 */
const offset = (options, deps) => ({
  ...(0,floating_ui_dom/* offset */.cY)(options),
  options: [options, deps]
});

/**
 * Optimizes the visibility of the floating element by shifting it in order to
 * keep it in view when it will overflow the clipping boundary.
 * @see https://floating-ui.com/docs/shift
 */
const shift = (options, deps) => ({
  ...(0,floating_ui_dom/* shift */.BN)(options),
  options: [options, deps]
});

/**
 * Built-in `limiter` that will stop `shift()` at a certain point.
 */
const limitShift = (options, deps) => ({
  ...limitShift$1(options),
  options: [options, deps]
});

/**
 * Optimizes the visibility of the floating element by flipping the `placement`
 * in order to keep it in view when the preferred placement(s) will overflow the
 * clipping boundary. Alternative to `autoPlacement`.
 * @see https://floating-ui.com/docs/flip
 */
const flip = (options, deps) => ({
  ...(0,floating_ui_dom/* flip */.UU)(options),
  options: [options, deps]
});

/**
 * Provides data that allows you to change the size of the floating element —
 * for instance, prevent it from overflowing the clipping boundary or match the
 * width of the reference element.
 * @see https://floating-ui.com/docs/size
 */
const size = (options, deps) => ({
  ...(0,floating_ui_dom/* size */.Ej)(options),
  options: [options, deps]
});

/**
 * Optimizes the visibility of the floating element by choosing the placement
 * that has the most space available automatically, without needing to specify a
 * preferred placement. Alternative to `flip`.
 * @see https://floating-ui.com/docs/autoPlacement
 */
const autoPlacement = (options, deps) => ({
  ...autoPlacement$1(options),
  options: [options, deps]
});

/**
 * Provides data to hide the floating element in applicable situations, such as
 * when it is not in the same clipping context as the reference element.
 * @see https://floating-ui.com/docs/hide
 */
const hide = (options, deps) => ({
  ...hide$1(options),
  options: [options, deps]
});

/**
 * Provides improved positioning for inline reference elements that can span
 * over multiple lines, such as hyperlinks or range selections.
 * @see https://floating-ui.com/docs/inline
 */
const inline = (options, deps) => ({
  ...inline$1(options),
  options: [options, deps]
});

/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * This wraps the core `arrow` middleware to allow React refs as the element.
 * @see https://floating-ui.com/docs/arrow
 */
const arrow = (options, deps) => ({
  ...arrow$1(options),
  options: [options, deps]
});



;// ./node_modules/@floating-ui/react/dist/floating-ui.react.mjs










/**
 * Merges an array of refs into a single memoized callback ref or `null`.
 * @see https://floating-ui.com/docs/react-utils#usemergerefs
 */
function useMergeRefs(refs) {
  return React.useMemo(() => {
    if (refs.every(ref => ref == null)) {
      return null;
    }
    return value => {
      refs.forEach(ref => {
        if (typeof ref === 'function') {
          ref(value);
        } else if (ref != null) {
          ref.current = value;
        }
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, refs);
}

// https://github.com/mui/material-ui/issues/41190#issuecomment-2040873379
const SafeReact = {
  ...react_namespaceObject
};

const useInsertionEffect = SafeReact.useInsertionEffect;
const useSafeInsertionEffect = useInsertionEffect || (fn => fn());
function useEffectEvent(callback) {
  const ref = react.useRef(() => {
    if (true) {
      throw new Error('Cannot call an event handler while rendering.');
    }
  });
  useSafeInsertionEffect(() => {
    ref.current = callback;
  });
  return react.useCallback(function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return ref.current == null ? void 0 : ref.current(...args);
  }, []);
}

const ARROW_UP = 'ArrowUp';
const ARROW_DOWN = 'ArrowDown';
const ARROW_LEFT = 'ArrowLeft';
const ARROW_RIGHT = 'ArrowRight';
function isDifferentRow(index, cols, prevRow) {
  return Math.floor(index / cols) !== prevRow;
}
function isIndexOutOfBounds(listRef, index) {
  return index < 0 || index >= listRef.current.length;
}
function getMinIndex(listRef, disabledIndices) {
  return findNonDisabledIndex(listRef, {
    disabledIndices
  });
}
function getMaxIndex(listRef, disabledIndices) {
  return findNonDisabledIndex(listRef, {
    decrement: true,
    startingIndex: listRef.current.length,
    disabledIndices
  });
}
function findNonDisabledIndex(listRef, _temp) {
  let {
    startingIndex = -1,
    decrement = false,
    disabledIndices,
    amount = 1
  } = _temp === void 0 ? {} : _temp;
  const list = listRef.current;
  let index = startingIndex;
  do {
    index += decrement ? -amount : amount;
  } while (index >= 0 && index <= list.length - 1 && isDisabled(list, index, disabledIndices));
  return index;
}
function getGridNavigatedIndex(elementsRef, _ref) {
  let {
    event,
    orientation,
    loop,
    rtl,
    cols,
    disabledIndices,
    minIndex,
    maxIndex,
    prevIndex,
    stopEvent: stop = false
  } = _ref;
  let nextIndex = prevIndex;
  if (event.key === ARROW_UP) {
    stop && stopEvent(event);
    if (prevIndex === -1) {
      nextIndex = maxIndex;
    } else {
      nextIndex = findNonDisabledIndex(elementsRef, {
        startingIndex: nextIndex,
        amount: cols,
        decrement: true,
        disabledIndices
      });
      if (loop && (prevIndex - cols < minIndex || nextIndex < 0)) {
        const col = prevIndex % cols;
        const maxCol = maxIndex % cols;
        const offset = maxIndex - (maxCol - col);
        if (maxCol === col) {
          nextIndex = maxIndex;
        } else {
          nextIndex = maxCol > col ? offset : offset - cols;
        }
      }
    }
    if (isIndexOutOfBounds(elementsRef, nextIndex)) {
      nextIndex = prevIndex;
    }
  }
  if (event.key === ARROW_DOWN) {
    stop && stopEvent(event);
    if (prevIndex === -1) {
      nextIndex = minIndex;
    } else {
      nextIndex = findNonDisabledIndex(elementsRef, {
        startingIndex: prevIndex,
        amount: cols,
        disabledIndices
      });
      if (loop && prevIndex + cols > maxIndex) {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex % cols - cols,
          amount: cols,
          disabledIndices
        });
      }
    }
    if (isIndexOutOfBounds(elementsRef, nextIndex)) {
      nextIndex = prevIndex;
    }
  }

  // Remains on the same row/column.
  if (orientation === 'both') {
    const prevRow = floor(prevIndex / cols);
    if (event.key === (rtl ? ARROW_LEFT : ARROW_RIGHT)) {
      stop && stopEvent(event);
      if (prevIndex % cols !== cols - 1) {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex,
          disabledIndices
        });
        if (loop && isDifferentRow(nextIndex, cols, prevRow)) {
          nextIndex = findNonDisabledIndex(elementsRef, {
            startingIndex: prevIndex - prevIndex % cols - 1,
            disabledIndices
          });
        }
      } else if (loop) {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex - prevIndex % cols - 1,
          disabledIndices
        });
      }
      if (isDifferentRow(nextIndex, cols, prevRow)) {
        nextIndex = prevIndex;
      }
    }
    if (event.key === (rtl ? ARROW_RIGHT : ARROW_LEFT)) {
      stop && stopEvent(event);
      if (prevIndex % cols !== 0) {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex,
          decrement: true,
          disabledIndices
        });
        if (loop && isDifferentRow(nextIndex, cols, prevRow)) {
          nextIndex = findNonDisabledIndex(elementsRef, {
            startingIndex: prevIndex + (cols - prevIndex % cols),
            decrement: true,
            disabledIndices
          });
        }
      } else if (loop) {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex + (cols - prevIndex % cols),
          decrement: true,
          disabledIndices
        });
      }
      if (isDifferentRow(nextIndex, cols, prevRow)) {
        nextIndex = prevIndex;
      }
    }
    const lastRow = floor(maxIndex / cols) === prevRow;
    if (isIndexOutOfBounds(elementsRef, nextIndex)) {
      if (loop && lastRow) {
        nextIndex = event.key === (rtl ? ARROW_RIGHT : ARROW_LEFT) ? maxIndex : findNonDisabledIndex(elementsRef, {
          startingIndex: prevIndex - prevIndex % cols - 1,
          disabledIndices
        });
      } else {
        nextIndex = prevIndex;
      }
    }
  }
  return nextIndex;
}

/** For each cell index, gets the item index that occupies that cell */
function buildCellMap(sizes, cols, dense) {
  const cellMap = [];
  let startIndex = 0;
  sizes.forEach((_ref2, index) => {
    let {
      width,
      height
    } = _ref2;
    if (width > cols) {
      if (true) {
        throw new Error("[Floating UI]: Invalid grid - item width at index " + index + " is greater than grid columns");
      }
    }
    let itemPlaced = false;
    if (dense) {
      startIndex = 0;
    }
    while (!itemPlaced) {
      const targetCells = [];
      for (let i = 0; i < width; i++) {
        for (let j = 0; j < height; j++) {
          targetCells.push(startIndex + i + j * cols);
        }
      }
      if (startIndex % cols + width <= cols && targetCells.every(cell => cellMap[cell] == null)) {
        targetCells.forEach(cell => {
          cellMap[cell] = index;
        });
        itemPlaced = true;
      } else {
        startIndex++;
      }
    }
  });

  // convert into a non-sparse array
  return [...cellMap];
}

/** Gets cell index of an item's corner or -1 when index is -1. */
function getCellIndexOfCorner(index, sizes, cellMap, cols, corner) {
  if (index === -1) return -1;
  const firstCellIndex = cellMap.indexOf(index);
  const sizeItem = sizes[index];
  switch (corner) {
    case 'tl':
      return firstCellIndex;
    case 'tr':
      if (!sizeItem) {
        return firstCellIndex;
      }
      return firstCellIndex + sizeItem.width - 1;
    case 'bl':
      if (!sizeItem) {
        return firstCellIndex;
      }
      return firstCellIndex + (sizeItem.height - 1) * cols;
    case 'br':
      return cellMap.lastIndexOf(index);
  }
}

/** Gets all cell indices that correspond to the specified indices */
function getCellIndices(indices, cellMap) {
  return cellMap.flatMap((index, cellIndex) => indices.includes(index) ? [cellIndex] : []);
}
function isDisabled(list, index, disabledIndices) {
  if (disabledIndices) {
    return disabledIndices.includes(index);
  }
  const element = list[index];
  return element == null || element.hasAttribute('disabled') || element.getAttribute('aria-disabled') === 'true';
}

var floating_ui_react_index = typeof document !== 'undefined' ? react.useLayoutEffect : react.useEffect;

function sortByDocumentPosition(a, b) {
  const position = a.compareDocumentPosition(b);
  if (position & Node.DOCUMENT_POSITION_FOLLOWING || position & Node.DOCUMENT_POSITION_CONTAINED_BY) {
    return -1;
  }
  if (position & Node.DOCUMENT_POSITION_PRECEDING || position & Node.DOCUMENT_POSITION_CONTAINS) {
    return 1;
  }
  return 0;
}
function areMapsEqual(map1, map2) {
  if (map1.size !== map2.size) {
    return false;
  }
  for (const [key, value] of map1.entries()) {
    if (value !== map2.get(key)) {
      return false;
    }
  }
  return true;
}
const FloatingListContext = /*#__PURE__*/react.createContext({
  register: () => {},
  unregister: () => {},
  map: /*#__PURE__*/new Map(),
  elementsRef: {
    current: []
  }
});
/**
 * Provides context for a list of items within the floating element.
 * @see https://floating-ui.com/docs/FloatingList
 */
function FloatingList(props) {
  const {
    children,
    elementsRef,
    labelsRef
  } = props;
  const [map, setMap] = React.useState(() => new Map());
  const register = React.useCallback(node => {
    setMap(prevMap => new Map(prevMap).set(node, null));
  }, []);
  const unregister = React.useCallback(node => {
    setMap(prevMap => {
      const map = new Map(prevMap);
      map.delete(node);
      return map;
    });
  }, []);
  floating_ui_react_index(() => {
    const newMap = new Map(map);
    const nodes = Array.from(newMap.keys()).sort(sortByDocumentPosition);
    nodes.forEach((node, index) => {
      newMap.set(node, index);
    });
    if (!areMapsEqual(map, newMap)) {
      setMap(newMap);
    }
  }, [map]);
  return /*#__PURE__*/React.createElement(FloatingListContext.Provider, {
    value: React.useMemo(() => ({
      register,
      unregister,
      map,
      elementsRef,
      labelsRef
    }), [register, unregister, map, elementsRef, labelsRef])
  }, children);
}
/**
 * Used to register a list item and its index (DOM position) in the
 * `FloatingList`.
 * @see https://floating-ui.com/docs/FloatingList#uselistitem
 */
function useListItem(props) {
  if (props === void 0) {
    props = {};
  }
  const {
    label
  } = props;
  const {
    register,
    unregister,
    map,
    elementsRef,
    labelsRef
  } = React.useContext(FloatingListContext);
  const [index$1, setIndex] = React.useState(null);
  const componentRef = React.useRef(null);
  const ref = React.useCallback(node => {
    componentRef.current = node;
    if (index$1 !== null) {
      elementsRef.current[index$1] = node;
      if (labelsRef) {
        var _node$textContent;
        const isLabelDefined = label !== undefined;
        labelsRef.current[index$1] = isLabelDefined ? label : (_node$textContent = node == null ? void 0 : node.textContent) != null ? _node$textContent : null;
      }
    }
  }, [index$1, elementsRef, labelsRef, label]);
  floating_ui_react_index(() => {
    const node = componentRef.current;
    if (node) {
      register(node);
      return () => {
        unregister(node);
      };
    }
  }, [register, unregister]);
  floating_ui_react_index(() => {
    const index = componentRef.current ? map.get(componentRef.current) : null;
    if (index != null) {
      setIndex(index);
    }
  }, [map]);
  return React.useMemo(() => ({
    ref,
    index: index$1 == null ? -1 : index$1
  }), [index$1, ref]);
}

function renderJsx(render, computedProps) {
  if (typeof render === 'function') {
    return render(computedProps);
  }
  if (render) {
    return /*#__PURE__*/React.cloneElement(render, computedProps);
  }
  return /*#__PURE__*/React.createElement("div", computedProps);
}
const CompositeContext = /*#__PURE__*/react.createContext({
  activeIndex: 0,
  onNavigate: () => {}
});
const horizontalKeys = [ARROW_LEFT, ARROW_RIGHT];
const verticalKeys = [ARROW_UP, ARROW_DOWN];
const allKeys = [...horizontalKeys, ...verticalKeys];

/**
 * Creates a single tab stop whose items are navigated by arrow keys, which
 * provides list navigation outside of floating element contexts.
 *
 * This is useful to enable navigation of a list of items that aren’t part of a
 * floating element. A menubar is an example of a composite, with each reference
 * element being an item.
 * @see https://floating-ui.com/docs/Composite
 */
const Composite = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function Composite(props, forwardedRef) {
  const {
    render,
    orientation = 'both',
    loop = true,
    rtl = false,
    cols = 1,
    disabledIndices,
    activeIndex: externalActiveIndex,
    onNavigate: externalSetActiveIndex,
    itemSizes,
    dense = false,
    ...domProps
  } = props;
  const [internalActiveIndex, internalSetActiveIndex] = React.useState(0);
  const activeIndex = externalActiveIndex != null ? externalActiveIndex : internalActiveIndex;
  const onNavigate = useEffectEvent(externalSetActiveIndex != null ? externalSetActiveIndex : internalSetActiveIndex);
  const elementsRef = React.useRef([]);
  const renderElementProps = render && typeof render !== 'function' ? render.props : {};
  const contextValue = React.useMemo(() => ({
    activeIndex,
    onNavigate
  }), [activeIndex, onNavigate]);
  const isGrid = cols > 1;
  function handleKeyDown(event) {
    if (!allKeys.includes(event.key)) return;
    let nextIndex = activeIndex;
    const minIndex = getMinIndex(elementsRef, disabledIndices);
    const maxIndex = getMaxIndex(elementsRef, disabledIndices);
    const horizontalEndKey = rtl ? ARROW_LEFT : ARROW_RIGHT;
    const horizontalStartKey = rtl ? ARROW_RIGHT : ARROW_LEFT;
    if (isGrid) {
      const sizes = itemSizes || Array.from({
        length: elementsRef.current.length
      }, () => ({
        width: 1,
        height: 1
      }));
      // To calculate movements on the grid, we use hypothetical cell indices
      // as if every item was 1x1, then convert back to real indices.
      const cellMap = buildCellMap(sizes, cols, dense);
      const minGridIndex = cellMap.findIndex(index => index != null && !isDisabled(elementsRef.current, index, disabledIndices));
      // last enabled index
      const maxGridIndex = cellMap.reduce((foundIndex, index, cellIndex) => index != null && !isDisabled(elementsRef.current, index, disabledIndices) ? cellIndex : foundIndex, -1);
      const maybeNextIndex = cellMap[getGridNavigatedIndex({
        current: cellMap.map(itemIndex => itemIndex ? elementsRef.current[itemIndex] : null)
      }, {
        event,
        orientation,
        loop,
        rtl,
        cols,
        // treat undefined (empty grid spaces) as disabled indices so we
        // don't end up in them
        disabledIndices: getCellIndices([...(disabledIndices || elementsRef.current.map((_, index) => isDisabled(elementsRef.current, index) ? index : undefined)), undefined], cellMap),
        minIndex: minGridIndex,
        maxIndex: maxGridIndex,
        prevIndex: getCellIndexOfCorner(activeIndex > maxIndex ? minIndex : activeIndex, sizes, cellMap, cols,
        // use a corner matching the edge closest to the direction we're
        // moving in so we don't end up in the same item. Prefer
        // top/left over bottom/right.
        event.key === ARROW_DOWN ? 'bl' : event.key === horizontalEndKey ? 'tr' : 'tl')
      })];
      if (maybeNextIndex != null) {
        nextIndex = maybeNextIndex;
      }
    }
    const toEndKeys = {
      horizontal: [horizontalEndKey],
      vertical: [ARROW_DOWN],
      both: [horizontalEndKey, ARROW_DOWN]
    }[orientation];
    const toStartKeys = {
      horizontal: [horizontalStartKey],
      vertical: [ARROW_UP],
      both: [horizontalStartKey, ARROW_UP]
    }[orientation];
    const preventedKeys = isGrid ? allKeys : {
      horizontal: horizontalKeys,
      vertical: verticalKeys,
      both: allKeys
    }[orientation];
    if (nextIndex === activeIndex && [...toEndKeys, ...toStartKeys].includes(event.key)) {
      if (loop && nextIndex === maxIndex && toEndKeys.includes(event.key)) {
        nextIndex = minIndex;
      } else if (loop && nextIndex === minIndex && toStartKeys.includes(event.key)) {
        nextIndex = maxIndex;
      } else {
        nextIndex = findNonDisabledIndex(elementsRef, {
          startingIndex: nextIndex,
          decrement: toStartKeys.includes(event.key),
          disabledIndices
        });
      }
    }
    if (nextIndex !== activeIndex && !isIndexOutOfBounds(elementsRef, nextIndex)) {
      var _elementsRef$current$;
      event.stopPropagation();
      if (preventedKeys.includes(event.key)) {
        event.preventDefault();
      }
      onNavigate(nextIndex);
      (_elementsRef$current$ = elementsRef.current[nextIndex]) == null || _elementsRef$current$.focus();
    }
  }
  const computedProps = {
    ...domProps,
    ...renderElementProps,
    ref: forwardedRef,
    'aria-orientation': orientation === 'both' ? undefined : orientation,
    onKeyDown(e) {
      domProps.onKeyDown == null || domProps.onKeyDown(e);
      renderElementProps.onKeyDown == null || renderElementProps.onKeyDown(e);
      handleKeyDown(e);
    }
  };
  return /*#__PURE__*/React.createElement(CompositeContext.Provider, {
    value: contextValue
  }, /*#__PURE__*/React.createElement(FloatingList, {
    elementsRef: elementsRef
  }, renderJsx(render, computedProps)));
})));
/**
 * @see https://floating-ui.com/docs/Composite
 */
const CompositeItem = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function CompositeItem(props, forwardedRef) {
  const {
    render,
    ...domProps
  } = props;
  const renderElementProps = render && typeof render !== 'function' ? render.props : {};
  const {
    activeIndex,
    onNavigate
  } = React.useContext(CompositeContext);
  const {
    ref,
    index
  } = useListItem();
  const mergedRef = useMergeRefs([ref, forwardedRef, renderElementProps.ref]);
  const isActive = activeIndex === index;
  const computedProps = {
    ...domProps,
    ...renderElementProps,
    ref: mergedRef,
    tabIndex: isActive ? 0 : -1,
    'data-active': isActive ? '' : undefined,
    onFocus(e) {
      domProps.onFocus == null || domProps.onFocus(e);
      renderElementProps.onFocus == null || renderElementProps.onFocus(e);
      onNavigate(index);
    }
  };
  return renderJsx(render, computedProps);
})));

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}

let serverHandoffComplete = false;
let count = 0;
const genId = () => // Ensure the id is unique with multiple independent versions of Floating UI
// on <React 18
"floating-ui-" + Math.random().toString(36).slice(2, 6) + count++;
function useFloatingId() {
  const [id, setId] = react.useState(() => serverHandoffComplete ? genId() : undefined);
  floating_ui_react_index(() => {
    if (id == null) {
      setId(genId());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  react.useEffect(() => {
    serverHandoffComplete = true;
  }, []);
  return id;
}
const useReactId = SafeReact.useId;

/**
 * Uses React 18's built-in `useId()` when available, or falls back to a
 * slightly less performant (requiring a double render) implementation for
 * earlier React versions.
 * @see https://floating-ui.com/docs/react-utils#useid
 */
const useId = useReactId || useFloatingId;

let devMessageSet;
if (true) {
  devMessageSet = /*#__PURE__*/new Set();
}
function warn() {
  var _devMessageSet;
  for (var _len = arguments.length, messages = new Array(_len), _key = 0; _key < _len; _key++) {
    messages[_key] = arguments[_key];
  }
  const message = "Floating UI: " + messages.join(' ');
  if (!((_devMessageSet = devMessageSet) != null && _devMessageSet.has(message))) {
    var _devMessageSet2;
    (_devMessageSet2 = devMessageSet) == null || _devMessageSet2.add(message);
    console.warn(message);
  }
}
function error() {
  var _devMessageSet3;
  for (var _len2 = arguments.length, messages = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    messages[_key2] = arguments[_key2];
  }
  const message = "Floating UI: " + messages.join(' ');
  if (!((_devMessageSet3 = devMessageSet) != null && _devMessageSet3.has(message))) {
    var _devMessageSet4;
    (_devMessageSet4 = devMessageSet) == null || _devMessageSet4.add(message);
    console.error(message);
  }
}

/**
 * Renders a pointing arrow triangle.
 * @see https://floating-ui.com/docs/FloatingArrow
 */
const FloatingArrow = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function FloatingArrow(props, ref) {
  const {
    context: {
      placement,
      elements: {
        floating
      },
      middlewareData: {
        arrow,
        shift
      }
    },
    width = 14,
    height = 7,
    tipRadius = 0,
    strokeWidth = 0,
    staticOffset,
    stroke,
    d,
    style: {
      transform,
      ...restStyle
    } = {},
    ...rest
  } = props;
  if (true) {
    if (!ref) {
      warn('The `ref` prop is required for `FloatingArrow`.');
    }
  }
  const clipPathId = useId();
  const [isRTL, setIsRTL] = React.useState(false);

  // https://github.com/floating-ui/floating-ui/issues/2932
  floating_ui_react_index(() => {
    if (!floating) return;
    const isRTL = getComputedStyle(floating).direction === 'rtl';
    if (isRTL) {
      setIsRTL(true);
    }
  }, [floating]);
  if (!floating) {
    return null;
  }
  const [side, alignment] = placement.split('-');
  const isVerticalSide = side === 'top' || side === 'bottom';
  let computedStaticOffset = staticOffset;
  if (isVerticalSide && shift != null && shift.x || !isVerticalSide && shift != null && shift.y) {
    computedStaticOffset = null;
  }

  // Strokes must be double the border width, this ensures the stroke's width
  // works as you'd expect.
  const computedStrokeWidth = strokeWidth * 2;
  const halfStrokeWidth = computedStrokeWidth / 2;
  const svgX = width / 2 * (tipRadius / -8 + 1);
  const svgY = height / 2 * tipRadius / 4;
  const isCustomShape = !!d;
  const yOffsetProp = computedStaticOffset && alignment === 'end' ? 'bottom' : 'top';
  let xOffsetProp = computedStaticOffset && alignment === 'end' ? 'right' : 'left';
  if (computedStaticOffset && isRTL) {
    xOffsetProp = alignment === 'end' ? 'left' : 'right';
  }
  const arrowX = (arrow == null ? void 0 : arrow.x) != null ? computedStaticOffset || arrow.x : '';
  const arrowY = (arrow == null ? void 0 : arrow.y) != null ? computedStaticOffset || arrow.y : '';
  const dValue = d || 'M0,0' + (" H" + width) + (" L" + (width - svgX) + "," + (height - svgY)) + (" Q" + width / 2 + "," + height + " " + svgX + "," + (height - svgY)) + ' Z';
  const rotation = {
    top: isCustomShape ? 'rotate(180deg)' : '',
    left: isCustomShape ? 'rotate(90deg)' : 'rotate(-90deg)',
    bottom: isCustomShape ? '' : 'rotate(180deg)',
    right: isCustomShape ? 'rotate(-90deg)' : 'rotate(90deg)'
  }[side];
  return /*#__PURE__*/React.createElement("svg", _extends({}, rest, {
    "aria-hidden": true,
    ref: ref,
    width: isCustomShape ? width : width + computedStrokeWidth,
    height: width,
    viewBox: "0 0 " + width + " " + (height > width ? height : width),
    style: {
      position: 'absolute',
      pointerEvents: 'none',
      [xOffsetProp]: arrowX,
      [yOffsetProp]: arrowY,
      [side]: isVerticalSide || isCustomShape ? '100%' : "calc(100% - " + computedStrokeWidth / 2 + "px)",
      transform: [rotation, transform].filter(t => !!t).join(' '),
      ...restStyle
    }
  }), computedStrokeWidth > 0 && /*#__PURE__*/React.createElement("path", {
    clipPath: "url(#" + clipPathId + ")",
    fill: "none",
    stroke: stroke
    // Account for the stroke on the fill path rendered below.
    ,
    strokeWidth: computedStrokeWidth + (d ? 0 : 1),
    d: dValue
  }), /*#__PURE__*/React.createElement("path", {
    stroke: computedStrokeWidth && !d ? rest.fill : 'none',
    d: dValue
  }), /*#__PURE__*/React.createElement("clipPath", {
    id: clipPathId
  }, /*#__PURE__*/React.createElement("rect", {
    x: -halfStrokeWidth,
    y: halfStrokeWidth * (isCustomShape ? -1 : 1),
    width: width + computedStrokeWidth,
    height: width
  })));
})));

function createPubSub() {
  const map = new Map();
  return {
    emit(event, data) {
      var _map$get;
      (_map$get = map.get(event)) == null || _map$get.forEach(handler => handler(data));
    },
    on(event, listener) {
      map.set(event, [...(map.get(event) || []), listener]);
    },
    off(event, listener) {
      var _map$get2;
      map.set(event, ((_map$get2 = map.get(event)) == null ? void 0 : _map$get2.filter(l => l !== listener)) || []);
    }
  };
}

const FloatingNodeContext = /*#__PURE__*/react.createContext(null);
const FloatingTreeContext = /*#__PURE__*/react.createContext(null);

/**
 * Returns the parent node id for nested floating elements, if available.
 * Returns `null` for top-level floating elements.
 */
const useFloatingParentNodeId = () => {
  var _React$useContext;
  return ((_React$useContext = react.useContext(FloatingNodeContext)) == null ? void 0 : _React$useContext.id) || null;
};

/**
 * Returns the nearest floating tree context, if available.
 */
const useFloatingTree = () => react.useContext(FloatingTreeContext);

/**
 * Registers a node into the `FloatingTree`, returning its id.
 * @see https://floating-ui.com/docs/FloatingTree
 */
function useFloatingNodeId(customParentId) {
  const id = useId();
  const tree = useFloatingTree();
  const reactParentId = useFloatingParentNodeId();
  const parentId = customParentId || reactParentId;
  floating_ui_react_index(() => {
    const node = {
      id,
      parentId
    };
    tree == null || tree.addNode(node);
    return () => {
      tree == null || tree.removeNode(node);
    };
  }, [tree, id, parentId]);
  return id;
}
/**
 * Provides parent node context for nested floating elements.
 * @see https://floating-ui.com/docs/FloatingTree
 */
function FloatingNode(props) {
  const {
    children,
    id
  } = props;
  const parentId = useFloatingParentNodeId();
  return /*#__PURE__*/React.createElement(FloatingNodeContext.Provider, {
    value: React.useMemo(() => ({
      id,
      parentId
    }), [id, parentId])
  }, children);
}
/**
 * Provides context for nested floating elements when they are not children of
 * each other on the DOM.
 * This is not necessary in all cases, except when there must be explicit communication between parent and child floating elements. It is necessary for:
 * - The `bubbles` option in the `useDismiss()` Hook
 * - Nested virtual list navigation
 * - Nested floating elements that each open on hover
 * - Custom communication between parent and child floating elements
 * @see https://floating-ui.com/docs/FloatingTree
 */
function FloatingTree(props) {
  const {
    children
  } = props;
  const nodesRef = React.useRef([]);
  const addNode = React.useCallback(node => {
    nodesRef.current = [...nodesRef.current, node];
  }, []);
  const removeNode = React.useCallback(node => {
    nodesRef.current = nodesRef.current.filter(n => n !== node);
  }, []);
  const events = React.useState(() => createPubSub())[0];
  return /*#__PURE__*/React.createElement(FloatingTreeContext.Provider, {
    value: React.useMemo(() => ({
      nodesRef,
      addNode,
      removeNode,
      events
    }), [addNode, removeNode, events])
  }, children);
}

function createAttribute(name) {
  return "data-floating-ui-" + name;
}

function floating_ui_react_useLatestRef(value) {
  const ref = useRef(value);
  floating_ui_react_index(() => {
    ref.current = value;
  });
  return ref;
}

const safePolygonIdentifier = /*#__PURE__*/(/* unused pure expression or super */ null && (createAttribute('safe-polygon')));
function getDelay(value, prop, pointerType) {
  if (pointerType && !isMouseLikePointerType(pointerType)) {
    return 0;
  }
  if (typeof value === 'number') {
    return value;
  }
  return value == null ? void 0 : value[prop];
}
/**
 * Opens the floating element while hovering over the reference element, like
 * CSS `:hover`.
 * @see https://floating-ui.com/docs/useHover
 */
function useHover(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    onOpenChange,
    dataRef,
    events,
    elements
  } = context;
  const {
    enabled = true,
    delay = 0,
    handleClose = null,
    mouseOnly = false,
    restMs = 0,
    move = true
  } = props;
  const tree = useFloatingTree();
  const parentId = useFloatingParentNodeId();
  const handleCloseRef = floating_ui_react_useLatestRef(handleClose);
  const delayRef = floating_ui_react_useLatestRef(delay);
  const openRef = floating_ui_react_useLatestRef(open);
  const pointerTypeRef = React.useRef();
  const timeoutRef = React.useRef(-1);
  const handlerRef = React.useRef();
  const restTimeoutRef = React.useRef(-1);
  const blockMouseMoveRef = React.useRef(true);
  const performedPointerEventsMutationRef = React.useRef(false);
  const unbindMouseMoveRef = React.useRef(() => {});
  const restTimeoutPendingRef = React.useRef(false);
  const isHoverOpen = React.useCallback(() => {
    var _dataRef$current$open;
    const type = (_dataRef$current$open = dataRef.current.openEvent) == null ? void 0 : _dataRef$current$open.type;
    return (type == null ? void 0 : type.includes('mouse')) && type !== 'mousedown';
  }, [dataRef]);

  // When closing before opening, clear the delay timeouts to cancel it
  // from showing.
  React.useEffect(() => {
    if (!enabled) return;
    function onOpenChange(_ref) {
      let {
        open
      } = _ref;
      if (!open) {
        clearTimeout(timeoutRef.current);
        clearTimeout(restTimeoutRef.current);
        blockMouseMoveRef.current = true;
        restTimeoutPendingRef.current = false;
      }
    }
    events.on('openchange', onOpenChange);
    return () => {
      events.off('openchange', onOpenChange);
    };
  }, [enabled, events]);
  React.useEffect(() => {
    if (!enabled) return;
    if (!handleCloseRef.current) return;
    if (!open) return;
    function onLeave(event) {
      if (isHoverOpen()) {
        onOpenChange(false, event, 'hover');
      }
    }
    const html = getDocument(elements.floating).documentElement;
    html.addEventListener('mouseleave', onLeave);
    return () => {
      html.removeEventListener('mouseleave', onLeave);
    };
  }, [elements.floating, open, onOpenChange, enabled, handleCloseRef, isHoverOpen]);
  const closeWithDelay = React.useCallback(function (event, runElseBranch, reason) {
    if (runElseBranch === void 0) {
      runElseBranch = true;
    }
    if (reason === void 0) {
      reason = 'hover';
    }
    const closeDelay = getDelay(delayRef.current, 'close', pointerTypeRef.current);
    if (closeDelay && !handlerRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = window.setTimeout(() => onOpenChange(false, event, reason), closeDelay);
    } else if (runElseBranch) {
      clearTimeout(timeoutRef.current);
      onOpenChange(false, event, reason);
    }
  }, [delayRef, onOpenChange]);
  const cleanupMouseMoveHandler = useEffectEvent(() => {
    unbindMouseMoveRef.current();
    handlerRef.current = undefined;
  });
  const clearPointerEvents = useEffectEvent(() => {
    if (performedPointerEventsMutationRef.current) {
      const body = getDocument(elements.floating).body;
      body.style.pointerEvents = '';
      body.removeAttribute(safePolygonIdentifier);
      performedPointerEventsMutationRef.current = false;
    }
  });
  const isClickLikeOpenEvent = useEffectEvent(() => {
    return dataRef.current.openEvent ? ['click', 'mousedown'].includes(dataRef.current.openEvent.type) : false;
  });

  // Registering the mouse events on the reference directly to bypass React's
  // delegation system. If the cursor was on a disabled element and then entered
  // the reference (no gap), `mouseenter` doesn't fire in the delegation system.
  React.useEffect(() => {
    if (!enabled) return;
    function onMouseEnter(event) {
      clearTimeout(timeoutRef.current);
      blockMouseMoveRef.current = false;
      if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current) || restMs > 0 && !getDelay(delayRef.current, 'open')) {
        return;
      }
      const openDelay = getDelay(delayRef.current, 'open', pointerTypeRef.current);
      if (openDelay) {
        timeoutRef.current = window.setTimeout(() => {
          if (!openRef.current) {
            onOpenChange(true, event, 'hover');
          }
        }, openDelay);
      } else if (!open) {
        onOpenChange(true, event, 'hover');
      }
    }
    function onMouseLeave(event) {
      if (isClickLikeOpenEvent()) return;
      unbindMouseMoveRef.current();
      const doc = getDocument(elements.floating);
      clearTimeout(restTimeoutRef.current);
      restTimeoutPendingRef.current = false;
      if (handleCloseRef.current && dataRef.current.floatingContext) {
        // Prevent clearing `onScrollMouseLeave` timeout.
        if (!open) {
          clearTimeout(timeoutRef.current);
        }
        handlerRef.current = handleCloseRef.current({
          ...dataRef.current.floatingContext,
          tree,
          x: event.clientX,
          y: event.clientY,
          onClose() {
            clearPointerEvents();
            cleanupMouseMoveHandler();
            if (!isClickLikeOpenEvent()) {
              closeWithDelay(event, true, 'safe-polygon');
            }
          }
        });
        const handler = handlerRef.current;
        doc.addEventListener('mousemove', handler);
        unbindMouseMoveRef.current = () => {
          doc.removeEventListener('mousemove', handler);
        };
        return;
      }

      // Allow interactivity without `safePolygon` on touch devices. With a
      // pointer, a short close delay is an alternative, so it should work
      // consistently.
      const shouldClose = pointerTypeRef.current === 'touch' ? !contains(elements.floating, event.relatedTarget) : true;
      if (shouldClose) {
        closeWithDelay(event);
      }
    }

    // Ensure the floating element closes after scrolling even if the pointer
    // did not move.
    // https://github.com/floating-ui/floating-ui/discussions/1692
    function onScrollMouseLeave(event) {
      if (isClickLikeOpenEvent()) return;
      if (!dataRef.current.floatingContext) return;
      handleCloseRef.current == null || handleCloseRef.current({
        ...dataRef.current.floatingContext,
        tree,
        x: event.clientX,
        y: event.clientY,
        onClose() {
          clearPointerEvents();
          cleanupMouseMoveHandler();
          if (!isClickLikeOpenEvent()) {
            closeWithDelay(event);
          }
        }
      })(event);
    }
    if (isElement(elements.domReference)) {
      var _elements$floating;
      const ref = elements.domReference;
      open && ref.addEventListener('mouseleave', onScrollMouseLeave);
      (_elements$floating = elements.floating) == null || _elements$floating.addEventListener('mouseleave', onScrollMouseLeave);
      move && ref.addEventListener('mousemove', onMouseEnter, {
        once: true
      });
      ref.addEventListener('mouseenter', onMouseEnter);
      ref.addEventListener('mouseleave', onMouseLeave);
      return () => {
        var _elements$floating2;
        open && ref.removeEventListener('mouseleave', onScrollMouseLeave);
        (_elements$floating2 = elements.floating) == null || _elements$floating2.removeEventListener('mouseleave', onScrollMouseLeave);
        move && ref.removeEventListener('mousemove', onMouseEnter);
        ref.removeEventListener('mouseenter', onMouseEnter);
        ref.removeEventListener('mouseleave', onMouseLeave);
      };
    }
  }, [elements, enabled, context, mouseOnly, restMs, move, closeWithDelay, cleanupMouseMoveHandler, clearPointerEvents, onOpenChange, open, openRef, tree, delayRef, handleCloseRef, dataRef, isClickLikeOpenEvent]);

  // Block pointer-events of every element other than the reference and floating
  // while the floating element is open and has a `handleClose` handler. Also
  // handles nested floating elements.
  // https://github.com/floating-ui/floating-ui/issues/1722
  floating_ui_react_index(() => {
    var _handleCloseRef$curre;
    if (!enabled) return;
    if (open && (_handleCloseRef$curre = handleCloseRef.current) != null && _handleCloseRef$curre.__options.blockPointerEvents && isHoverOpen()) {
      performedPointerEventsMutationRef.current = true;
      const floatingEl = elements.floating;
      if (isElement(elements.domReference) && floatingEl) {
        var _tree$nodesRef$curren;
        const body = getDocument(elements.floating).body;
        body.setAttribute(safePolygonIdentifier, '');
        const ref = elements.domReference;
        const parentFloating = tree == null || (_tree$nodesRef$curren = tree.nodesRef.current.find(node => node.id === parentId)) == null || (_tree$nodesRef$curren = _tree$nodesRef$curren.context) == null ? void 0 : _tree$nodesRef$curren.elements.floating;
        if (parentFloating) {
          parentFloating.style.pointerEvents = '';
        }
        body.style.pointerEvents = 'none';
        ref.style.pointerEvents = 'auto';
        floatingEl.style.pointerEvents = 'auto';
        return () => {
          body.style.pointerEvents = '';
          ref.style.pointerEvents = '';
          floatingEl.style.pointerEvents = '';
        };
      }
    }
  }, [enabled, open, parentId, elements, tree, handleCloseRef, isHoverOpen]);
  floating_ui_react_index(() => {
    if (!open) {
      pointerTypeRef.current = undefined;
      restTimeoutPendingRef.current = false;
      cleanupMouseMoveHandler();
      clearPointerEvents();
    }
  }, [open, cleanupMouseMoveHandler, clearPointerEvents]);
  React.useEffect(() => {
    return () => {
      cleanupMouseMoveHandler();
      clearTimeout(timeoutRef.current);
      clearTimeout(restTimeoutRef.current);
      clearPointerEvents();
    };
  }, [enabled, elements.domReference, cleanupMouseMoveHandler, clearPointerEvents]);
  const reference = React.useMemo(() => {
    function setPointerRef(event) {
      pointerTypeRef.current = event.pointerType;
    }
    return {
      onPointerDown: setPointerRef,
      onPointerEnter: setPointerRef,
      onMouseMove(event) {
        const {
          nativeEvent
        } = event;
        function handleMouseMove() {
          if (!blockMouseMoveRef.current && !openRef.current) {
            onOpenChange(true, nativeEvent, 'hover');
          }
        }
        if (mouseOnly && !isMouseLikePointerType(pointerTypeRef.current)) {
          return;
        }
        if (open || restMs === 0) {
          return;
        }

        // Ignore insignificant movements to account for tremors.
        if (restTimeoutPendingRef.current && event.movementX ** 2 + event.movementY ** 2 < 2) {
          return;
        }
        clearTimeout(restTimeoutRef.current);
        if (pointerTypeRef.current === 'touch') {
          handleMouseMove();
        } else {
          restTimeoutPendingRef.current = true;
          restTimeoutRef.current = window.setTimeout(handleMouseMove, restMs);
        }
      }
    };
  }, [mouseOnly, onOpenChange, open, openRef, restMs]);
  const floating = React.useMemo(() => ({
    onMouseEnter() {
      clearTimeout(timeoutRef.current);
    },
    onMouseLeave(event) {
      if (!isClickLikeOpenEvent()) {
        closeWithDelay(event.nativeEvent, false);
      }
    }
  }), [closeWithDelay, isClickLikeOpenEvent]);
  return React.useMemo(() => enabled ? {
    reference,
    floating
  } : {}, [enabled, reference, floating]);
}

const NOOP = () => {};
const FloatingDelayGroupContext = /*#__PURE__*/react.createContext({
  delay: 0,
  initialDelay: 0,
  timeoutMs: 0,
  currentId: null,
  setCurrentId: NOOP,
  setState: NOOP,
  isInstantPhase: false
});

/**
 * @deprecated
 * Use the return value of `useDelayGroup()` instead.
 */
const useDelayGroupContext = () => React.useContext(FloatingDelayGroupContext);
/**
 * Provides context for a group of floating elements that should share a
 * `delay`.
 * @see https://floating-ui.com/docs/FloatingDelayGroup
 */
function FloatingDelayGroup(props) {
  const {
    children,
    delay,
    timeoutMs = 0
  } = props;
  const [state, setState] = React.useReducer((prev, next) => ({
    ...prev,
    ...next
  }), {
    delay,
    timeoutMs,
    initialDelay: delay,
    currentId: null,
    isInstantPhase: false
  });
  const initialCurrentIdRef = React.useRef(null);
  const setCurrentId = React.useCallback(currentId => {
    setState({
      currentId
    });
  }, []);
  floating_ui_react_index(() => {
    if (state.currentId) {
      if (initialCurrentIdRef.current === null) {
        initialCurrentIdRef.current = state.currentId;
      } else if (!state.isInstantPhase) {
        setState({
          isInstantPhase: true
        });
      }
    } else {
      if (state.isInstantPhase) {
        setState({
          isInstantPhase: false
        });
      }
      initialCurrentIdRef.current = null;
    }
  }, [state.currentId, state.isInstantPhase]);
  return /*#__PURE__*/React.createElement(FloatingDelayGroupContext.Provider, {
    value: React.useMemo(() => ({
      ...state,
      setState,
      setCurrentId
    }), [state, setCurrentId])
  }, children);
}
/**
 * Enables grouping when called inside a component that's a child of a
 * `FloatingDelayGroup`.
 * @see https://floating-ui.com/docs/FloatingDelayGroup
 */
function useDelayGroup(context, options) {
  if (options === void 0) {
    options = {};
  }
  const {
    open,
    onOpenChange,
    floatingId
  } = context;
  const {
    id: optionId,
    enabled = true
  } = options;
  const id = optionId != null ? optionId : floatingId;
  const groupContext = useDelayGroupContext();
  const {
    currentId,
    setCurrentId,
    initialDelay,
    setState,
    timeoutMs
  } = groupContext;
  floating_ui_react_index(() => {
    if (!enabled) return;
    if (!currentId) return;
    setState({
      delay: {
        open: 1,
        close: getDelay(initialDelay, 'close')
      }
    });
    if (currentId !== id) {
      onOpenChange(false);
    }
  }, [enabled, id, onOpenChange, setState, currentId, initialDelay]);
  floating_ui_react_index(() => {
    function unset() {
      onOpenChange(false);
      setState({
        delay: initialDelay,
        currentId: null
      });
    }
    if (!enabled) return;
    if (!currentId) return;
    if (!open && currentId === id) {
      if (timeoutMs) {
        const timeout = window.setTimeout(unset, timeoutMs);
        return () => {
          clearTimeout(timeout);
        };
      }
      unset();
    }
  }, [enabled, open, setState, currentId, id, onOpenChange, initialDelay, timeoutMs]);
  floating_ui_react_index(() => {
    if (!enabled) return;
    if (setCurrentId === NOOP || !open) return;
    setCurrentId(id);
  }, [enabled, open, setCurrentId, id]);
  return groupContext;
}

let rafId = 0;
function enqueueFocus(el, options) {
  if (options === void 0) {
    options = {};
  }
  const {
    preventScroll = false,
    cancelPrevious = true,
    sync = false
  } = options;
  cancelPrevious && cancelAnimationFrame(rafId);
  const exec = () => el == null ? void 0 : el.focus({
    preventScroll
  });
  if (sync) {
    exec();
  } else {
    rafId = requestAnimationFrame(exec);
  }
}

function getAncestors(nodes, id) {
  var _nodes$find;
  let allAncestors = [];
  let currentParentId = (_nodes$find = nodes.find(node => node.id === id)) == null ? void 0 : _nodes$find.parentId;
  while (currentParentId) {
    const currentNode = nodes.find(node => node.id === currentParentId);
    currentParentId = currentNode == null ? void 0 : currentNode.parentId;
    if (currentNode) {
      allAncestors = allAncestors.concat(currentNode);
    }
  }
  return allAncestors;
}

function getChildren(nodes, id) {
  let allChildren = nodes.filter(node => {
    var _node$context;
    return node.parentId === id && ((_node$context = node.context) == null ? void 0 : _node$context.open);
  });
  let currentChildren = allChildren;
  while (currentChildren.length) {
    currentChildren = nodes.filter(node => {
      var _currentChildren;
      return (_currentChildren = currentChildren) == null ? void 0 : _currentChildren.some(n => {
        var _node$context2;
        return node.parentId === n.id && ((_node$context2 = node.context) == null ? void 0 : _node$context2.open);
      });
    });
    allChildren = allChildren.concat(currentChildren);
  }
  return allChildren;
}
function getDeepestNode(nodes, id) {
  let deepestNodeId;
  let maxDepth = -1;
  function findDeepest(nodeId, depth) {
    if (depth > maxDepth) {
      deepestNodeId = nodeId;
      maxDepth = depth;
    }
    const children = getChildren(nodes, nodeId);
    children.forEach(child => {
      findDeepest(child.id, depth + 1);
    });
  }
  findDeepest(id, 0);
  return nodes.find(node => node.id === deepestNodeId);
}

// Modified to add conditional `aria-hidden` support:
// https://github.com/theKashey/aria-hidden/blob/9220c8f4a4fd35f63bee5510a9f41a37264382d4/src/index.ts
let counterMap = /*#__PURE__*/new WeakMap();
let uncontrolledElementsSet = /*#__PURE__*/new WeakSet();
let markerMap = {};
let lockCount$1 = 0;
const supportsInert = () => typeof HTMLElement !== 'undefined' && 'inert' in HTMLElement.prototype;
const unwrapHost = node => node && (node.host || unwrapHost(node.parentNode));
const correctElements = (parent, targets) => targets.map(target => {
  if (parent.contains(target)) {
    return target;
  }
  const correctedTarget = unwrapHost(target);
  if (parent.contains(correctedTarget)) {
    return correctedTarget;
  }
  return null;
}).filter(x => x != null);
function applyAttributeToOthers(uncorrectedAvoidElements, body, ariaHidden, inert) {
  const markerName = 'data-floating-ui-inert';
  const controlAttribute = inert ? 'inert' : ariaHidden ? 'aria-hidden' : null;
  const avoidElements = correctElements(body, uncorrectedAvoidElements);
  const elementsToKeep = new Set();
  const elementsToStop = new Set(avoidElements);
  const hiddenElements = [];
  if (!markerMap[markerName]) {
    markerMap[markerName] = new WeakMap();
  }
  const markerCounter = markerMap[markerName];
  avoidElements.forEach(keep);
  deep(body);
  elementsToKeep.clear();
  function keep(el) {
    if (!el || elementsToKeep.has(el)) {
      return;
    }
    elementsToKeep.add(el);
    el.parentNode && keep(el.parentNode);
  }
  function deep(parent) {
    if (!parent || elementsToStop.has(parent)) {
      return;
    }
    [].forEach.call(parent.children, node => {
      if (getNodeName(node) === 'script') return;
      if (elementsToKeep.has(node)) {
        deep(node);
      } else {
        const attr = controlAttribute ? node.getAttribute(controlAttribute) : null;
        const alreadyHidden = attr !== null && attr !== 'false';
        const counterValue = (counterMap.get(node) || 0) + 1;
        const markerValue = (markerCounter.get(node) || 0) + 1;
        counterMap.set(node, counterValue);
        markerCounter.set(node, markerValue);
        hiddenElements.push(node);
        if (counterValue === 1 && alreadyHidden) {
          uncontrolledElementsSet.add(node);
        }
        if (markerValue === 1) {
          node.setAttribute(markerName, '');
        }
        if (!alreadyHidden && controlAttribute) {
          node.setAttribute(controlAttribute, 'true');
        }
      }
    });
  }
  lockCount$1++;
  return () => {
    hiddenElements.forEach(element => {
      const counterValue = (counterMap.get(element) || 0) - 1;
      const markerValue = (markerCounter.get(element) || 0) - 1;
      counterMap.set(element, counterValue);
      markerCounter.set(element, markerValue);
      if (!counterValue) {
        if (!uncontrolledElementsSet.has(element) && controlAttribute) {
          element.removeAttribute(controlAttribute);
        }
        uncontrolledElementsSet.delete(element);
      }
      if (!markerValue) {
        element.removeAttribute(markerName);
      }
    });
    lockCount$1--;
    if (!lockCount$1) {
      counterMap = new WeakMap();
      counterMap = new WeakMap();
      uncontrolledElementsSet = new WeakSet();
      markerMap = {};
    }
  };
}
function markOthers(avoidElements, ariaHidden, inert) {
  if (ariaHidden === void 0) {
    ariaHidden = false;
  }
  if (inert === void 0) {
    inert = false;
  }
  const body = getDocument(avoidElements[0]).body;
  return applyAttributeToOthers(avoidElements.concat(Array.from(body.querySelectorAll('[aria-live]'))), body, ariaHidden, inert);
}

const getTabbableOptions = () => ({
  getShadowRoot: true,
  displayCheck:
  // JSDOM does not support the `tabbable` library. To solve this we can
  // check if `ResizeObserver` is a real function (not polyfilled), which
  // determines if the current environment is JSDOM-like.
  typeof ResizeObserver === 'function' && ResizeObserver.toString().includes('[native code]') ? 'full' : 'none'
});
function getTabbableIn(container, direction) {
  const allTabbable = tabbable(container, getTabbableOptions());
  if (direction === 'prev') {
    allTabbable.reverse();
  }
  const activeIndex = allTabbable.indexOf(activeElement(getDocument(container)));
  const nextTabbableElements = allTabbable.slice(activeIndex + 1);
  return nextTabbableElements[0];
}
function getNextTabbable() {
  return getTabbableIn(document.body, 'next');
}
function getPreviousTabbable() {
  return getTabbableIn(document.body, 'prev');
}
function isOutsideEvent(event, container) {
  const containerElement = container || event.currentTarget;
  const relatedTarget = event.relatedTarget;
  return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
  const tabbableElements = tabbable(container, getTabbableOptions());
  tabbableElements.forEach(element => {
    element.dataset.tabindex = element.getAttribute('tabindex') || '';
    element.setAttribute('tabindex', '-1');
  });
}
function enableFocusInside(container) {
  const elements = container.querySelectorAll('[data-tabindex]');
  elements.forEach(element => {
    const tabindex = element.dataset.tabindex;
    delete element.dataset.tabindex;
    if (tabindex) {
      element.setAttribute('tabindex', tabindex);
    } else {
      element.removeAttribute('tabindex');
    }
  });
}

// See Diego Haz's Sandbox for making this logic work well on Safari/iOS:
// https://codesandbox.io/s/tabbable-portal-f4tng?file=/src/FocusTrap.tsx

const HIDDEN_STYLES = {
  border: 0,
  clip: 'rect(0 0 0 0)',
  height: '1px',
  margin: '-1px',
  overflow: 'hidden',
  padding: 0,
  position: 'fixed',
  whiteSpace: 'nowrap',
  width: '1px',
  top: 0,
  left: 0
};
let timeoutId;
function setActiveElementOnTab(event) {
  if (event.key === 'Tab') {
    event.target;
    clearTimeout(timeoutId);
  }
}
const FocusGuard = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function FocusGuard(props, ref) {
  const [role, setRole] = React.useState();
  floating_ui_react_index(() => {
    if (isSafari()) {
      // Unlike other screen readers such as NVDA and JAWS, the virtual cursor
      // on VoiceOver does trigger the onFocus event, so we can use the focus
      // trap element. On Safari, only buttons trigger the onFocus event.
      // NB: "group" role in the Sandbox no longer appears to work, must be a
      // button role.
      setRole('button');
    }
    document.addEventListener('keydown', setActiveElementOnTab);
    return () => {
      document.removeEventListener('keydown', setActiveElementOnTab);
    };
  }, []);
  const restProps = {
    ref,
    tabIndex: 0,
    // Role is only for VoiceOver
    role,
    'aria-hidden': role ? undefined : true,
    [createAttribute('focus-guard')]: '',
    style: HIDDEN_STYLES
  };
  return /*#__PURE__*/React.createElement("span", _extends({}, props, restProps));
})));

const PortalContext = /*#__PURE__*/(/* unused pure expression or super */ null && (React.createContext(null)));
const attr = /*#__PURE__*/(/* unused pure expression or super */ null && (createAttribute('portal')));
/**
 * @see https://floating-ui.com/docs/FloatingPortal#usefloatingportalnode
 */
function useFloatingPortalNode(props) {
  if (props === void 0) {
    props = {};
  }
  const {
    id,
    root
  } = props;
  const uniqueId = useId();
  const portalContext = usePortalContext();
  const [portalNode, setPortalNode] = React.useState(null);
  const portalNodeRef = React.useRef(null);
  floating_ui_react_index(() => {
    return () => {
      portalNode == null || portalNode.remove();
      // Allow the subsequent layout effects to create a new node on updates.
      // The portal node will still be cleaned up on unmount.
      // https://github.com/floating-ui/floating-ui/issues/2454
      queueMicrotask(() => {
        portalNodeRef.current = null;
      });
    };
  }, [portalNode]);
  floating_ui_react_index(() => {
    // Wait for the uniqueId to be generated before creating the portal node in
    // React <18 (using `useFloatingId` instead of the native `useId`).
    // https://github.com/floating-ui/floating-ui/issues/2778
    if (!uniqueId) return;
    if (portalNodeRef.current) return;
    const existingIdRoot = id ? document.getElementById(id) : null;
    if (!existingIdRoot) return;
    const subRoot = document.createElement('div');
    subRoot.id = uniqueId;
    subRoot.setAttribute(attr, '');
    existingIdRoot.appendChild(subRoot);
    portalNodeRef.current = subRoot;
    setPortalNode(subRoot);
  }, [id, uniqueId]);
  floating_ui_react_index(() => {
    // Wait for the root to exist before creating the portal node. The root must
    // be stored in state, not a ref, for this to work reactively.
    if (root === null) return;
    if (!uniqueId) return;
    if (portalNodeRef.current) return;
    let container = root || (portalContext == null ? void 0 : portalContext.portalNode);
    if (container && !isElement(container)) container = container.current;
    container = container || document.body;
    let idWrapper = null;
    if (id) {
      idWrapper = document.createElement('div');
      idWrapper.id = id;
      container.appendChild(idWrapper);
    }
    const subRoot = document.createElement('div');
    subRoot.id = uniqueId;
    subRoot.setAttribute(attr, '');
    container = idWrapper || container;
    container.appendChild(subRoot);
    portalNodeRef.current = subRoot;
    setPortalNode(subRoot);
  }, [id, root, uniqueId, portalContext]);
  return portalNode;
}
/**
 * Portals the floating element into a given container element — by default,
 * outside of the app root and into the body.
 * This is necessary to ensure the floating element can appear outside any
 * potential parent containers that cause clipping (such as `overflow: hidden`),
 * while retaining its location in the React tree.
 * @see https://floating-ui.com/docs/FloatingPortal
 */
function FloatingPortal(props) {
  const {
    children,
    id,
    root,
    preserveTabOrder = true
  } = props;
  const portalNode = useFloatingPortalNode({
    id,
    root
  });
  const [focusManagerState, setFocusManagerState] = React.useState(null);
  const beforeOutsideRef = React.useRef(null);
  const afterOutsideRef = React.useRef(null);
  const beforeInsideRef = React.useRef(null);
  const afterInsideRef = React.useRef(null);
  const modal = focusManagerState == null ? void 0 : focusManagerState.modal;
  const open = focusManagerState == null ? void 0 : focusManagerState.open;
  const shouldRenderGuards =
  // The FocusManager and therefore floating element are currently open/
  // rendered.
  !!focusManagerState &&
  // Guards are only for non-modal focus management.
  !focusManagerState.modal &&
  // Don't render if unmount is transitioning.
  focusManagerState.open && preserveTabOrder && !!(root || portalNode);

  // https://codesandbox.io/s/tabbable-portal-f4tng?file=/src/TabbablePortal.tsx
  React.useEffect(() => {
    if (!portalNode || !preserveTabOrder || modal) {
      return;
    }

    // Make sure elements inside the portal element are tabbable only when the
    // portal has already been focused, either by tabbing into a focus trap
    // element outside or using the mouse.
    function onFocus(event) {
      if (portalNode && isOutsideEvent(event)) {
        const focusing = event.type === 'focusin';
        const manageFocus = focusing ? enableFocusInside : disableFocusInside;
        manageFocus(portalNode);
      }
    }
    // Listen to the event on the capture phase so they run before the focus
    // trap elements onFocus prop is called.
    portalNode.addEventListener('focusin', onFocus, true);
    portalNode.addEventListener('focusout', onFocus, true);
    return () => {
      portalNode.removeEventListener('focusin', onFocus, true);
      portalNode.removeEventListener('focusout', onFocus, true);
    };
  }, [portalNode, preserveTabOrder, modal]);
  React.useEffect(() => {
    if (!portalNode) return;
    if (open) return;
    enableFocusInside(portalNode);
  }, [open, portalNode]);
  return /*#__PURE__*/React.createElement(PortalContext.Provider, {
    value: React.useMemo(() => ({
      preserveTabOrder,
      beforeOutsideRef,
      afterOutsideRef,
      beforeInsideRef,
      afterInsideRef,
      portalNode,
      setFocusManagerState
    }), [preserveTabOrder, portalNode])
  }, shouldRenderGuards && portalNode && /*#__PURE__*/React.createElement(FocusGuard, {
    "data-type": "outside",
    ref: beforeOutsideRef,
    onFocus: event => {
      if (isOutsideEvent(event, portalNode)) {
        var _beforeInsideRef$curr;
        (_beforeInsideRef$curr = beforeInsideRef.current) == null || _beforeInsideRef$curr.focus();
      } else {
        const prevTabbable = getPreviousTabbable() || (focusManagerState == null ? void 0 : focusManagerState.refs.domReference.current);
        prevTabbable == null || prevTabbable.focus();
      }
    }
  }), shouldRenderGuards && portalNode && /*#__PURE__*/React.createElement("span", {
    "aria-owns": portalNode.id,
    style: HIDDEN_STYLES
  }), portalNode && /*#__PURE__*/ReactDOM.createPortal(children, portalNode), shouldRenderGuards && portalNode && /*#__PURE__*/React.createElement(FocusGuard, {
    "data-type": "outside",
    ref: afterOutsideRef,
    onFocus: event => {
      if (isOutsideEvent(event, portalNode)) {
        var _afterInsideRef$curre;
        (_afterInsideRef$curre = afterInsideRef.current) == null || _afterInsideRef$curre.focus();
      } else {
        const nextTabbable = getNextTabbable() || (focusManagerState == null ? void 0 : focusManagerState.refs.domReference.current);
        nextTabbable == null || nextTabbable.focus();
        (focusManagerState == null ? void 0 : focusManagerState.closeOnFocusOut) && (focusManagerState == null ? void 0 : focusManagerState.onOpenChange(false, event.nativeEvent, 'focus-out'));
      }
    }
  }));
}
const usePortalContext = () => React.useContext(PortalContext);

const FOCUSABLE_ATTRIBUTE = 'data-floating-ui-focusable';
function getFloatingFocusElement(floatingElement) {
  if (!floatingElement) {
    return null;
  }
  // Try to find the element that has `{...getFloatingProps()}` spread on it.
  // This indicates the floating element is acting as a positioning wrapper, and
  // so focus should be managed on the child element with the event handlers and
  // aria props.
  return floatingElement.hasAttribute(FOCUSABLE_ATTRIBUTE) ? floatingElement : floatingElement.querySelector("[" + FOCUSABLE_ATTRIBUTE + "]") || floatingElement;
}

const LIST_LIMIT = 20;
let previouslyFocusedElements = (/* unused pure expression or super */ null && ([]));
function addPreviouslyFocusedElement(element) {
  previouslyFocusedElements = previouslyFocusedElements.filter(el => el.isConnected);
  let tabbableEl = element;
  if (!tabbableEl || getNodeName(tabbableEl) === 'body') return;
  if (!isTabbable(tabbableEl, getTabbableOptions())) {
    const tabbableChild = tabbable(tabbableEl, getTabbableOptions())[0];
    if (tabbableChild) {
      tabbableEl = tabbableChild;
    }
  }
  previouslyFocusedElements.push(tabbableEl);
  if (previouslyFocusedElements.length > LIST_LIMIT) {
    previouslyFocusedElements = previouslyFocusedElements.slice(-LIST_LIMIT);
  }
}
function getPreviouslyFocusedElement() {
  return previouslyFocusedElements.slice().reverse().find(el => el.isConnected);
}
const VisuallyHiddenDismiss = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function VisuallyHiddenDismiss(props, ref) {
  return /*#__PURE__*/React.createElement("button", _extends({}, props, {
    type: "button",
    ref: ref,
    tabIndex: -1,
    style: HIDDEN_STYLES
  }));
})));
/**
 * Provides focus management for the floating element.
 * @see https://floating-ui.com/docs/FloatingFocusManager
 */
function FloatingFocusManager(props) {
  const {
    context,
    children,
    disabled = false,
    order = ['content'],
    guards: _guards = true,
    initialFocus = 0,
    returnFocus = true,
    restoreFocus = false,
    modal = true,
    visuallyHiddenDismiss = false,
    closeOnFocusOut = true
  } = props;
  const {
    open,
    refs,
    nodeId,
    onOpenChange,
    events,
    dataRef,
    floatingId,
    elements: {
      domReference,
      floating
    }
  } = context;
  const ignoreInitialFocus = typeof initialFocus === 'number' && initialFocus < 0;
  // If the reference is a combobox and is typeable (e.g. input/textarea),
  // there are different focus semantics. The guards should not be rendered, but
  // aria-hidden should be applied to all nodes still. Further, the visually
  // hidden dismiss button should only appear at the end of the list, not the
  // start.
  const isUntrappedTypeableCombobox = isTypeableCombobox(domReference) && ignoreInitialFocus;

  // Force the guards to be rendered if the `inert` attribute is not supported.
  const guards = supportsInert() ? _guards : true;
  const orderRef = floating_ui_react_useLatestRef(order);
  const initialFocusRef = floating_ui_react_useLatestRef(initialFocus);
  const returnFocusRef = floating_ui_react_useLatestRef(returnFocus);
  const tree = useFloatingTree();
  const portalContext = usePortalContext();
  const startDismissButtonRef = React.useRef(null);
  const endDismissButtonRef = React.useRef(null);
  const preventReturnFocusRef = React.useRef(false);
  const isPointerDownRef = React.useRef(false);
  const tabbableIndexRef = React.useRef(-1);
  const isInsidePortal = portalContext != null;
  const floatingFocusElement = getFloatingFocusElement(floating);
  const getTabbableContent = useEffectEvent(function (container) {
    if (container === void 0) {
      container = floatingFocusElement;
    }
    return container ? tabbable(container, getTabbableOptions()) : [];
  });
  const getTabbableElements = useEffectEvent(container => {
    const content = getTabbableContent(container);
    return orderRef.current.map(type => {
      if (domReference && type === 'reference') {
        return domReference;
      }
      if (floatingFocusElement && type === 'floating') {
        return floatingFocusElement;
      }
      return content;
    }).filter(Boolean).flat();
  });
  React.useEffect(() => {
    if (disabled) return;
    if (!modal) return;
    function onKeyDown(event) {
      if (event.key === 'Tab') {
        // The focus guards have nothing to focus, so we need to stop the event.
        if (contains(floatingFocusElement, activeElement(getDocument(floatingFocusElement))) && getTabbableContent().length === 0 && !isUntrappedTypeableCombobox) {
          stopEvent(event);
        }
        const els = getTabbableElements();
        const target = getTarget(event);
        if (orderRef.current[0] === 'reference' && target === domReference) {
          stopEvent(event);
          if (event.shiftKey) {
            enqueueFocus(els[els.length - 1]);
          } else {
            enqueueFocus(els[1]);
          }
        }
        if (orderRef.current[1] === 'floating' && target === floatingFocusElement && event.shiftKey) {
          stopEvent(event);
          enqueueFocus(els[0]);
        }
      }
    }
    const doc = getDocument(floatingFocusElement);
    doc.addEventListener('keydown', onKeyDown);
    return () => {
      doc.removeEventListener('keydown', onKeyDown);
    };
  }, [disabled, domReference, floatingFocusElement, modal, orderRef, isUntrappedTypeableCombobox, getTabbableContent, getTabbableElements]);
  React.useEffect(() => {
    if (disabled) return;
    if (!floating) return;
    function handleFocusIn(event) {
      const target = getTarget(event);
      const tabbableContent = getTabbableContent();
      const tabbableIndex = tabbableContent.indexOf(target);
      if (tabbableIndex !== -1) {
        tabbableIndexRef.current = tabbableIndex;
      }
    }
    floating.addEventListener('focusin', handleFocusIn);
    return () => {
      floating.removeEventListener('focusin', handleFocusIn);
    };
  }, [disabled, floating, getTabbableContent]);
  React.useEffect(() => {
    if (disabled) return;
    if (!closeOnFocusOut) return;

    // In Safari, buttons lose focus when pressing them.
    function handlePointerDown() {
      isPointerDownRef.current = true;
      setTimeout(() => {
        isPointerDownRef.current = false;
      });
    }
    function handleFocusOutside(event) {
      const relatedTarget = event.relatedTarget;
      queueMicrotask(() => {
        const movedToUnrelatedNode = !(contains(domReference, relatedTarget) || contains(floating, relatedTarget) || contains(relatedTarget, floating) || contains(portalContext == null ? void 0 : portalContext.portalNode, relatedTarget) || relatedTarget != null && relatedTarget.hasAttribute(createAttribute('focus-guard')) || tree && (getChildren(tree.nodesRef.current, nodeId).find(node => {
          var _node$context, _node$context2;
          return contains((_node$context = node.context) == null ? void 0 : _node$context.elements.floating, relatedTarget) || contains((_node$context2 = node.context) == null ? void 0 : _node$context2.elements.domReference, relatedTarget);
        }) || getAncestors(tree.nodesRef.current, nodeId).find(node => {
          var _node$context3, _node$context4;
          return ((_node$context3 = node.context) == null ? void 0 : _node$context3.elements.floating) === relatedTarget || ((_node$context4 = node.context) == null ? void 0 : _node$context4.elements.domReference) === relatedTarget;
        })));

        // Restore focus to the previous tabbable element index to prevent
        // focus from being lost outside the floating tree.
        if (restoreFocus && movedToUnrelatedNode && activeElement(getDocument(floatingFocusElement)) === getDocument(floatingFocusElement).body) {
          // Let `FloatingPortal` effect knows that focus is still inside the
          // floating tree.
          if (isHTMLElement(floatingFocusElement)) {
            floatingFocusElement.focus();
          }
          const prevTabbableIndex = tabbableIndexRef.current;
          const tabbableContent = getTabbableContent();
          const nodeToFocus = tabbableContent[prevTabbableIndex] || tabbableContent[tabbableContent.length - 1] || floatingFocusElement;
          if (isHTMLElement(nodeToFocus)) {
            nodeToFocus.focus();
          }
        }

        // Focus did not move inside the floating tree, and there are no tabbable
        // portal guards to handle closing.
        if ((isUntrappedTypeableCombobox ? true : !modal) && relatedTarget && movedToUnrelatedNode && !isPointerDownRef.current &&
        // Fix React 18 Strict Mode returnFocus due to double rendering.
        relatedTarget !== getPreviouslyFocusedElement()) {
          preventReturnFocusRef.current = true;
          onOpenChange(false, event, 'focus-out');
        }
      });
    }
    if (floating && isHTMLElement(domReference)) {
      domReference.addEventListener('focusout', handleFocusOutside);
      domReference.addEventListener('pointerdown', handlePointerDown);
      floating.addEventListener('focusout', handleFocusOutside);
      return () => {
        domReference.removeEventListener('focusout', handleFocusOutside);
        domReference.removeEventListener('pointerdown', handlePointerDown);
        floating.removeEventListener('focusout', handleFocusOutside);
      };
    }
  }, [disabled, domReference, floating, floatingFocusElement, modal, nodeId, tree, portalContext, onOpenChange, closeOnFocusOut, restoreFocus, getTabbableContent, isUntrappedTypeableCombobox]);
  React.useEffect(() => {
    var _portalContext$portal;
    if (disabled) return;

    // Don't hide portals nested within the parent portal.
    const portalNodes = Array.from((portalContext == null || (_portalContext$portal = portalContext.portalNode) == null ? void 0 : _portalContext$portal.querySelectorAll("[" + createAttribute('portal') + "]")) || []);
    if (floating) {
      const insideElements = [floating, ...portalNodes, startDismissButtonRef.current, endDismissButtonRef.current, orderRef.current.includes('reference') || isUntrappedTypeableCombobox ? domReference : null].filter(x => x != null);
      const cleanup = modal || isUntrappedTypeableCombobox ? markOthers(insideElements, guards, !guards) : markOthers(insideElements);
      return () => {
        cleanup();
      };
    }
  }, [disabled, domReference, floating, modal, orderRef, portalContext, isUntrappedTypeableCombobox, guards]);
  floating_ui_react_index(() => {
    if (disabled || !isHTMLElement(floatingFocusElement)) return;
    const doc = getDocument(floatingFocusElement);
    const previouslyFocusedElement = activeElement(doc);

    // Wait for any layout effect state setters to execute to set `tabIndex`.
    queueMicrotask(() => {
      const focusableElements = getTabbableElements(floatingFocusElement);
      const initialFocusValue = initialFocusRef.current;
      const elToFocus = (typeof initialFocusValue === 'number' ? focusableElements[initialFocusValue] : initialFocusValue.current) || floatingFocusElement;
      const focusAlreadyInsideFloatingEl = contains(floatingFocusElement, previouslyFocusedElement);
      if (!ignoreInitialFocus && !focusAlreadyInsideFloatingEl && open) {
        enqueueFocus(elToFocus, {
          preventScroll: elToFocus === floatingFocusElement
        });
      }
    });
  }, [disabled, open, floatingFocusElement, ignoreInitialFocus, getTabbableElements, initialFocusRef]);
  floating_ui_react_index(() => {
    if (disabled || !floatingFocusElement) return;
    let preventReturnFocusScroll = false;
    const doc = getDocument(floatingFocusElement);
    const previouslyFocusedElement = activeElement(doc);
    const contextData = dataRef.current;
    let openEvent = contextData.openEvent;
    addPreviouslyFocusedElement(previouslyFocusedElement);

    // Dismissing via outside press should always ignore `returnFocus` to
    // prevent unwanted scrolling.
    function onOpenChange(_ref) {
      let {
        open,
        reason,
        event,
        nested
      } = _ref;
      if (open) {
        openEvent = event;
      }
      if (reason === 'escape-key' && refs.domReference.current) {
        addPreviouslyFocusedElement(refs.domReference.current);
      }
      if (reason === 'hover' && event.type === 'mouseleave') {
        preventReturnFocusRef.current = true;
      }
      if (reason !== 'outside-press') return;
      if (nested) {
        preventReturnFocusRef.current = false;
        preventReturnFocusScroll = true;
      } else {
        preventReturnFocusRef.current = !(isVirtualClick(event) || isVirtualPointerEvent(event));
      }
    }
    events.on('openchange', onOpenChange);
    const fallbackEl = doc.createElement('span');
    fallbackEl.setAttribute('tabindex', '-1');
    fallbackEl.setAttribute('aria-hidden', 'true');
    Object.assign(fallbackEl.style, HIDDEN_STYLES);
    if (isInsidePortal && domReference) {
      domReference.insertAdjacentElement('afterend', fallbackEl);
    }
    function getReturnElement() {
      if (typeof returnFocusRef.current === 'boolean') {
        return getPreviouslyFocusedElement() || fallbackEl;
      }
      return returnFocusRef.current.current || fallbackEl;
    }
    return () => {
      events.off('openchange', onOpenChange);
      const activeEl = activeElement(doc);
      const isFocusInsideFloatingTree = contains(floating, activeEl) || tree && getChildren(tree.nodesRef.current, nodeId).some(node => {
        var _node$context5;
        return contains((_node$context5 = node.context) == null ? void 0 : _node$context5.elements.floating, activeEl);
      });
      const shouldFocusReference = isFocusInsideFloatingTree || openEvent && ['click', 'mousedown'].includes(openEvent.type);
      if (shouldFocusReference && refs.domReference.current) {
        addPreviouslyFocusedElement(refs.domReference.current);
      }
      const returnElement = getReturnElement();
      queueMicrotask(() => {
        if (
        // eslint-disable-next-line react-hooks/exhaustive-deps
        returnFocusRef.current && !preventReturnFocusRef.current && isHTMLElement(returnElement) && (
        // If the focus moved somewhere else after mount, avoid returning focus
        // since it likely entered a different element which should be
        // respected: https://github.com/floating-ui/floating-ui/issues/2607
        returnElement !== activeEl && activeEl !== doc.body ? isFocusInsideFloatingTree : true)) {
          returnElement.focus({
            preventScroll: preventReturnFocusScroll
          });
        }
        fallbackEl.remove();
      });
    };
  }, [disabled, floating, floatingFocusElement, returnFocusRef, dataRef, refs, events, tree, nodeId, isInsidePortal, domReference]);
  React.useEffect(() => {
    // The `returnFocus` cleanup behavior is inside a microtask; ensure we
    // wait for it to complete before resetting the flag.
    queueMicrotask(() => {
      preventReturnFocusRef.current = false;
    });
  }, [disabled]);

  // Synchronize the `context` & `modal` value to the FloatingPortal context.
  // It will decide whether or not it needs to render its own guards.
  floating_ui_react_index(() => {
    if (disabled) return;
    if (!portalContext) return;
    portalContext.setFocusManagerState({
      modal,
      closeOnFocusOut,
      open,
      onOpenChange,
      refs
    });
    return () => {
      portalContext.setFocusManagerState(null);
    };
  }, [disabled, portalContext, modal, open, onOpenChange, refs, closeOnFocusOut]);
  floating_ui_react_index(() => {
    if (disabled) return;
    if (!floatingFocusElement) return;
    if (typeof MutationObserver !== 'function') return;
    if (ignoreInitialFocus) return;
    const handleMutation = () => {
      const tabIndex = floatingFocusElement.getAttribute('tabindex');
      const tabbableContent = getTabbableContent();
      const activeEl = activeElement(getDocument(floating));
      const tabbableIndex = tabbableContent.indexOf(activeEl);
      if (tabbableIndex !== -1) {
        tabbableIndexRef.current = tabbableIndex;
      }
      if (orderRef.current.includes('floating') || activeEl !== refs.domReference.current && tabbableContent.length === 0) {
        if (tabIndex !== '0') {
          floatingFocusElement.setAttribute('tabindex', '0');
        }
      } else if (tabIndex !== '-1') {
        floatingFocusElement.setAttribute('tabindex', '-1');
      }
    };
    handleMutation();
    const observer = new MutationObserver(handleMutation);
    observer.observe(floatingFocusElement, {
      childList: true,
      subtree: true,
      attributes: true
    });
    return () => {
      observer.disconnect();
    };
  }, [disabled, floating, floatingFocusElement, refs, orderRef, getTabbableContent, ignoreInitialFocus]);
  function renderDismissButton(location) {
    if (disabled || !visuallyHiddenDismiss || !modal) {
      return null;
    }
    return /*#__PURE__*/React.createElement(VisuallyHiddenDismiss, {
      ref: location === 'start' ? startDismissButtonRef : endDismissButtonRef,
      onClick: event => onOpenChange(false, event.nativeEvent)
    }, typeof visuallyHiddenDismiss === 'string' ? visuallyHiddenDismiss : 'Dismiss');
  }
  const shouldRenderGuards = !disabled && guards && (modal ? !isUntrappedTypeableCombobox : true) && (isInsidePortal || modal);
  return /*#__PURE__*/React.createElement(React.Fragment, null, shouldRenderGuards && /*#__PURE__*/React.createElement(FocusGuard, {
    "data-type": "inside",
    ref: portalContext == null ? void 0 : portalContext.beforeInsideRef,
    onFocus: event => {
      if (modal) {
        const els = getTabbableElements();
        enqueueFocus(order[0] === 'reference' ? els[0] : els[els.length - 1]);
      } else if (portalContext != null && portalContext.preserveTabOrder && portalContext.portalNode) {
        preventReturnFocusRef.current = false;
        if (isOutsideEvent(event, portalContext.portalNode)) {
          const nextTabbable = getNextTabbable() || domReference;
          nextTabbable == null || nextTabbable.focus();
        } else {
          var _portalContext$before;
          (_portalContext$before = portalContext.beforeOutsideRef.current) == null || _portalContext$before.focus();
        }
      }
    }
  }), !isUntrappedTypeableCombobox && renderDismissButton('start'), children, renderDismissButton('end'), shouldRenderGuards && /*#__PURE__*/React.createElement(FocusGuard, {
    "data-type": "inside",
    ref: portalContext == null ? void 0 : portalContext.afterInsideRef,
    onFocus: event => {
      if (modal) {
        enqueueFocus(getTabbableElements()[0]);
      } else if (portalContext != null && portalContext.preserveTabOrder && portalContext.portalNode) {
        if (closeOnFocusOut) {
          preventReturnFocusRef.current = true;
        }
        if (isOutsideEvent(event, portalContext.portalNode)) {
          const prevTabbable = getPreviousTabbable() || domReference;
          prevTabbable == null || prevTabbable.focus();
        } else {
          var _portalContext$afterO;
          (_portalContext$afterO = portalContext.afterOutsideRef.current) == null || _portalContext$afterO.focus();
        }
      }
    }
  }));
}

let lockCount = 0;
function enableScrollLock() {
  const isIOS = /iP(hone|ad|od)|iOS/.test(getPlatform());
  const bodyStyle = document.body.style;
  // RTL <body> scrollbar
  const scrollbarX = Math.round(document.documentElement.getBoundingClientRect().left) + document.documentElement.scrollLeft;
  const paddingProp = scrollbarX ? 'paddingLeft' : 'paddingRight';
  const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
  const scrollX = bodyStyle.left ? parseFloat(bodyStyle.left) : window.scrollX;
  const scrollY = bodyStyle.top ? parseFloat(bodyStyle.top) : window.scrollY;
  bodyStyle.overflow = 'hidden';
  if (scrollbarWidth) {
    bodyStyle[paddingProp] = scrollbarWidth + "px";
  }

  // Only iOS doesn't respect `overflow: hidden` on document.body, and this
  // technique has fewer side effects.
  if (isIOS) {
    var _window$visualViewpor, _window$visualViewpor2;
    // iOS 12 does not support `visualViewport`.
    const offsetLeft = ((_window$visualViewpor = window.visualViewport) == null ? void 0 : _window$visualViewpor.offsetLeft) || 0;
    const offsetTop = ((_window$visualViewpor2 = window.visualViewport) == null ? void 0 : _window$visualViewpor2.offsetTop) || 0;
    Object.assign(bodyStyle, {
      position: 'fixed',
      top: -(scrollY - Math.floor(offsetTop)) + "px",
      left: -(scrollX - Math.floor(offsetLeft)) + "px",
      right: '0'
    });
  }
  return () => {
    Object.assign(bodyStyle, {
      overflow: '',
      [paddingProp]: ''
    });
    if (isIOS) {
      Object.assign(bodyStyle, {
        position: '',
        top: '',
        left: '',
        right: ''
      });
      window.scrollTo(scrollX, scrollY);
    }
  };
}
let cleanup = () => {};

/**
 * Provides base styling for a fixed overlay element to dim content or block
 * pointer events behind a floating element.
 * It's a regular `<div>`, so it can be styled via any CSS solution you prefer.
 * @see https://floating-ui.com/docs/FloatingOverlay
 */
const FloatingOverlay = /*#__PURE__*/(/* unused pure expression or super */ null && (React.forwardRef(function FloatingOverlay(props, ref) {
  const {
    lockScroll = false,
    ...rest
  } = props;
  floating_ui_react_index(() => {
    if (!lockScroll) return;
    lockCount++;
    if (lockCount === 1) {
      cleanup = enableScrollLock();
    }
    return () => {
      lockCount--;
      if (lockCount === 0) {
        cleanup();
      }
    };
  }, [lockScroll]);
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: ref
  }, rest, {
    style: {
      position: 'fixed',
      overflow: 'auto',
      top: 0,
      right: 0,
      bottom: 0,
      left: 0,
      ...rest.style
    }
  }));
})));

function isButtonTarget(event) {
  return isHTMLElement(event.target) && event.target.tagName === 'BUTTON';
}
function isSpaceIgnored(element) {
  return isTypeableElement(element);
}
/**
 * Opens or closes the floating element when clicking the reference element.
 * @see https://floating-ui.com/docs/useClick
 */
function useClick(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    onOpenChange,
    dataRef,
    elements: {
      domReference
    }
  } = context;
  const {
    enabled = true,
    event: eventOption = 'click',
    toggle = true,
    ignoreMouse = false,
    keyboardHandlers = true,
    stickIfOpen = true
  } = props;
  const pointerTypeRef = React.useRef();
  const didKeyDownRef = React.useRef(false);
  const reference = React.useMemo(() => ({
    onPointerDown(event) {
      pointerTypeRef.current = event.pointerType;
    },
    onMouseDown(event) {
      const pointerType = pointerTypeRef.current;

      // Ignore all buttons except for the "main" button.
      // https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/button
      if (event.button !== 0) return;
      if (eventOption === 'click') return;
      if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
      if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === 'mousedown' : true)) {
        onOpenChange(false, event.nativeEvent, 'click');
      } else {
        // Prevent stealing focus from the floating element
        event.preventDefault();
        onOpenChange(true, event.nativeEvent, 'click');
      }
    },
    onClick(event) {
      const pointerType = pointerTypeRef.current;
      if (eventOption === 'mousedown' && pointerTypeRef.current) {
        pointerTypeRef.current = undefined;
        return;
      }
      if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
      if (open && toggle && (dataRef.current.openEvent && stickIfOpen ? dataRef.current.openEvent.type === 'click' : true)) {
        onOpenChange(false, event.nativeEvent, 'click');
      } else {
        onOpenChange(true, event.nativeEvent, 'click');
      }
    },
    onKeyDown(event) {
      pointerTypeRef.current = undefined;
      if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event)) {
        return;
      }
      if (event.key === ' ' && !isSpaceIgnored(domReference)) {
        // Prevent scrolling
        event.preventDefault();
        didKeyDownRef.current = true;
      }
      if (event.key === 'Enter') {
        if (open && toggle) {
          onOpenChange(false, event.nativeEvent, 'click');
        } else {
          onOpenChange(true, event.nativeEvent, 'click');
        }
      }
    },
    onKeyUp(event) {
      if (event.defaultPrevented || !keyboardHandlers || isButtonTarget(event) || isSpaceIgnored(domReference)) {
        return;
      }
      if (event.key === ' ' && didKeyDownRef.current) {
        didKeyDownRef.current = false;
        if (open && toggle) {
          onOpenChange(false, event.nativeEvent, 'click');
        } else {
          onOpenChange(true, event.nativeEvent, 'click');
        }
      }
    }
  }), [dataRef, domReference, eventOption, ignoreMouse, keyboardHandlers, onOpenChange, open, stickIfOpen, toggle]);
  return React.useMemo(() => enabled ? {
    reference
  } : {}, [enabled, reference]);
}

function createVirtualElement(domElement, data) {
  let offsetX = null;
  let offsetY = null;
  let isAutoUpdateEvent = false;
  return {
    contextElement: domElement || undefined,
    getBoundingClientRect() {
      var _data$dataRef$current;
      const domRect = (domElement == null ? void 0 : domElement.getBoundingClientRect()) || {
        width: 0,
        height: 0,
        x: 0,
        y: 0
      };
      const isXAxis = data.axis === 'x' || data.axis === 'both';
      const isYAxis = data.axis === 'y' || data.axis === 'both';
      const canTrackCursorOnAutoUpdate = ['mouseenter', 'mousemove'].includes(((_data$dataRef$current = data.dataRef.current.openEvent) == null ? void 0 : _data$dataRef$current.type) || '') && data.pointerType !== 'touch';
      let width = domRect.width;
      let height = domRect.height;
      let x = domRect.x;
      let y = domRect.y;
      if (offsetX == null && data.x && isXAxis) {
        offsetX = domRect.x - data.x;
      }
      if (offsetY == null && data.y && isYAxis) {
        offsetY = domRect.y - data.y;
      }
      x -= offsetX || 0;
      y -= offsetY || 0;
      width = 0;
      height = 0;
      if (!isAutoUpdateEvent || canTrackCursorOnAutoUpdate) {
        width = data.axis === 'y' ? domRect.width : 0;
        height = data.axis === 'x' ? domRect.height : 0;
        x = isXAxis && data.x != null ? data.x : x;
        y = isYAxis && data.y != null ? data.y : y;
      } else if (isAutoUpdateEvent && !canTrackCursorOnAutoUpdate) {
        height = data.axis === 'x' ? domRect.height : height;
        width = data.axis === 'y' ? domRect.width : width;
      }
      isAutoUpdateEvent = true;
      return {
        width,
        height,
        x,
        y,
        top: y,
        right: x + width,
        bottom: y + height,
        left: x
      };
    }
  };
}
function isMouseBasedEvent(event) {
  return event != null && event.clientX != null;
}
/**
 * Positions the floating element relative to a client point (in the viewport),
 * such as the mouse position. By default, it follows the mouse cursor.
 * @see https://floating-ui.com/docs/useClientPoint
 */
function useClientPoint(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    dataRef,
    elements: {
      floating,
      domReference
    },
    refs
  } = context;
  const {
    enabled = true,
    axis = 'both',
    x = null,
    y = null
  } = props;
  const initialRef = React.useRef(false);
  const cleanupListenerRef = React.useRef(null);
  const [pointerType, setPointerType] = React.useState();
  const [reactive, setReactive] = React.useState([]);
  const setReference = useEffectEvent((x, y) => {
    if (initialRef.current) return;

    // Prevent setting if the open event was not a mouse-like one
    // (e.g. focus to open, then hover over the reference element).
    // Only apply if the event exists.
    if (dataRef.current.openEvent && !isMouseBasedEvent(dataRef.current.openEvent)) {
      return;
    }
    refs.setPositionReference(createVirtualElement(domReference, {
      x,
      y,
      axis,
      dataRef,
      pointerType
    }));
  });
  const handleReferenceEnterOrMove = useEffectEvent(event => {
    if (x != null || y != null) return;
    if (!open) {
      setReference(event.clientX, event.clientY);
    } else if (!cleanupListenerRef.current) {
      // If there's no cleanup, there's no listener, but we want to ensure
      // we add the listener if the cursor landed on the floating element and
      // then back on the reference (i.e. it's interactive).
      setReactive([]);
    }
  });

  // If the pointer is a mouse-like pointer, we want to continue following the
  // mouse even if the floating element is transitioning out. On touch
  // devices, this is undesirable because the floating element will move to
  // the dismissal touch point.
  const openCheck = isMouseLikePointerType(pointerType) ? floating : open;
  const addListener = React.useCallback(() => {
    // Explicitly specified `x`/`y` coordinates shouldn't add a listener.
    if (!openCheck || !enabled || x != null || y != null) return;
    const win = getWindow(floating);
    function handleMouseMove(event) {
      const target = getTarget(event);
      if (!contains(floating, target)) {
        setReference(event.clientX, event.clientY);
      } else {
        win.removeEventListener('mousemove', handleMouseMove);
        cleanupListenerRef.current = null;
      }
    }
    if (!dataRef.current.openEvent || isMouseBasedEvent(dataRef.current.openEvent)) {
      win.addEventListener('mousemove', handleMouseMove);
      const cleanup = () => {
        win.removeEventListener('mousemove', handleMouseMove);
        cleanupListenerRef.current = null;
      };
      cleanupListenerRef.current = cleanup;
      return cleanup;
    }
    refs.setPositionReference(domReference);
  }, [openCheck, enabled, x, y, floating, dataRef, refs, domReference, setReference]);
  React.useEffect(() => {
    return addListener();
  }, [addListener, reactive]);
  React.useEffect(() => {
    if (enabled && !floating) {
      initialRef.current = false;
    }
  }, [enabled, floating]);
  React.useEffect(() => {
    if (!enabled && open) {
      initialRef.current = true;
    }
  }, [enabled, open]);
  floating_ui_react_index(() => {
    if (enabled && (x != null || y != null)) {
      initialRef.current = false;
      setReference(x, y);
    }
  }, [enabled, x, y, setReference]);
  const reference = React.useMemo(() => {
    function setPointerTypeRef(_ref) {
      let {
        pointerType
      } = _ref;
      setPointerType(pointerType);
    }
    return {
      onPointerDown: setPointerTypeRef,
      onPointerEnter: setPointerTypeRef,
      onMouseMove: handleReferenceEnterOrMove,
      onMouseEnter: handleReferenceEnterOrMove
    };
  }, [handleReferenceEnterOrMove]);
  return React.useMemo(() => enabled ? {
    reference
  } : {}, [enabled, reference]);
}

const bubbleHandlerKeys = {
  pointerdown: 'onPointerDown',
  mousedown: 'onMouseDown',
  click: 'onClick'
};
const captureHandlerKeys = {
  pointerdown: 'onPointerDownCapture',
  mousedown: 'onMouseDownCapture',
  click: 'onClickCapture'
};
const normalizeProp = normalizable => {
  var _normalizable$escapeK, _normalizable$outside;
  return {
    escapeKey: typeof normalizable === 'boolean' ? normalizable : (_normalizable$escapeK = normalizable == null ? void 0 : normalizable.escapeKey) != null ? _normalizable$escapeK : false,
    outsidePress: typeof normalizable === 'boolean' ? normalizable : (_normalizable$outside = normalizable == null ? void 0 : normalizable.outsidePress) != null ? _normalizable$outside : true
  };
};
/**
 * Closes the floating element when a dismissal is requested — by default, when
 * the user presses the `escape` key or outside of the floating element.
 * @see https://floating-ui.com/docs/useDismiss
 */
function useDismiss(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    onOpenChange,
    elements,
    dataRef
  } = context;
  const {
    enabled = true,
    escapeKey = true,
    outsidePress: unstable_outsidePress = true,
    outsidePressEvent = 'pointerdown',
    referencePress = false,
    referencePressEvent = 'pointerdown',
    ancestorScroll = false,
    bubbles,
    capture
  } = props;
  const tree = useFloatingTree();
  const outsidePressFn = useEffectEvent(typeof unstable_outsidePress === 'function' ? unstable_outsidePress : () => false);
  const outsidePress = typeof unstable_outsidePress === 'function' ? outsidePressFn : unstable_outsidePress;
  const insideReactTreeRef = React.useRef(false);
  const endedOrStartedInsideRef = React.useRef(false);
  const {
    escapeKey: escapeKeyBubbles,
    outsidePress: outsidePressBubbles
  } = normalizeProp(bubbles);
  const {
    escapeKey: escapeKeyCapture,
    outsidePress: outsidePressCapture
  } = normalizeProp(capture);
  const isComposingRef = React.useRef(false);
  const closeOnEscapeKeyDown = useEffectEvent(event => {
    var _dataRef$current$floa;
    if (!open || !enabled || !escapeKey || event.key !== 'Escape') {
      return;
    }

    // Wait until IME is settled. Pressing `Escape` while composing should
    // close the compose menu, but not the floating element.
    if (isComposingRef.current) {
      return;
    }
    const nodeId = (_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.nodeId;
    const children = tree ? getChildren(tree.nodesRef.current, nodeId) : [];
    if (!escapeKeyBubbles) {
      event.stopPropagation();
      if (children.length > 0) {
        let shouldDismiss = true;
        children.forEach(child => {
          var _child$context;
          if ((_child$context = child.context) != null && _child$context.open && !child.context.dataRef.current.__escapeKeyBubbles) {
            shouldDismiss = false;
            return;
          }
        });
        if (!shouldDismiss) {
          return;
        }
      }
    }
    onOpenChange(false, isReactEvent(event) ? event.nativeEvent : event, 'escape-key');
  });
  const closeOnEscapeKeyDownCapture = useEffectEvent(event => {
    var _getTarget2;
    const callback = () => {
      var _getTarget;
      closeOnEscapeKeyDown(event);
      (_getTarget = getTarget(event)) == null || _getTarget.removeEventListener('keydown', callback);
    };
    (_getTarget2 = getTarget(event)) == null || _getTarget2.addEventListener('keydown', callback);
  });
  const closeOnPressOutside = useEffectEvent(event => {
    var _dataRef$current$floa2;
    // Given developers can stop the propagation of the synthetic event,
    // we can only be confident with a positive value.
    const insideReactTree = insideReactTreeRef.current;
    insideReactTreeRef.current = false;

    // When click outside is lazy (`click` event), handle dragging.
    // Don't close if:
    // - The click started inside the floating element.
    // - The click ended inside the floating element.
    const endedOrStartedInside = endedOrStartedInsideRef.current;
    endedOrStartedInsideRef.current = false;
    if (outsidePressEvent === 'click' && endedOrStartedInside) {
      return;
    }
    if (insideReactTree) {
      return;
    }
    if (typeof outsidePress === 'function' && !outsidePress(event)) {
      return;
    }
    const target = getTarget(event);
    const inertSelector = "[" + createAttribute('inert') + "]";
    const markers = getDocument(elements.floating).querySelectorAll(inertSelector);
    let targetRootAncestor = isElement(target) ? target : null;
    while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
      const nextParent = getParentNode(targetRootAncestor);
      if (isLastTraversableNode(nextParent) || !isElement(nextParent)) {
        break;
      }
      targetRootAncestor = nextParent;
    }

    // Check if the click occurred on a third-party element injected after the
    // floating element rendered.
    if (markers.length && isElement(target) && !isRootElement(target) &&
    // Clicked on a direct ancestor (e.g. FloatingOverlay).
    !contains(target, elements.floating) &&
    // If the target root element contains none of the markers, then the
    // element was injected after the floating element rendered.
    Array.from(markers).every(marker => !contains(targetRootAncestor, marker))) {
      return;
    }

    // Check if the click occurred on the scrollbar
    if (isHTMLElement(target) && floating) {
      // In Firefox, `target.scrollWidth > target.clientWidth` for inline
      // elements.
      const canScrollX = target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
      const canScrollY = target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
      let xCond = canScrollY && event.offsetX > target.clientWidth;

      // In some browsers it is possible to change the <body> (or window)
      // scrollbar to the left side, but is very rare and is difficult to
      // check for. Plus, for modal dialogs with backdrops, it is more
      // important that the backdrop is checked but not so much the window.
      if (canScrollY) {
        const isRTL = getComputedStyle(target).direction === 'rtl';
        if (isRTL) {
          xCond = event.offsetX <= target.offsetWidth - target.clientWidth;
        }
      }
      if (xCond || canScrollX && event.offsetY > target.clientHeight) {
        return;
      }
    }
    const nodeId = (_dataRef$current$floa2 = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa2.nodeId;
    const targetIsInsideChildren = tree && getChildren(tree.nodesRef.current, nodeId).some(node => {
      var _node$context;
      return isEventTargetWithin(event, (_node$context = node.context) == null ? void 0 : _node$context.elements.floating);
    });
    if (isEventTargetWithin(event, elements.floating) || isEventTargetWithin(event, elements.domReference) || targetIsInsideChildren) {
      return;
    }
    const children = tree ? getChildren(tree.nodesRef.current, nodeId) : [];
    if (children.length > 0) {
      let shouldDismiss = true;
      children.forEach(child => {
        var _child$context2;
        if ((_child$context2 = child.context) != null && _child$context2.open && !child.context.dataRef.current.__outsidePressBubbles) {
          shouldDismiss = false;
          return;
        }
      });
      if (!shouldDismiss) {
        return;
      }
    }
    onOpenChange(false, event, 'outside-press');
  });
  const closeOnPressOutsideCapture = useEffectEvent(event => {
    var _getTarget4;
    const callback = () => {
      var _getTarget3;
      closeOnPressOutside(event);
      (_getTarget3 = getTarget(event)) == null || _getTarget3.removeEventListener(outsidePressEvent, callback);
    };
    (_getTarget4 = getTarget(event)) == null || _getTarget4.addEventListener(outsidePressEvent, callback);
  });
  React.useEffect(() => {
    if (!open || !enabled) {
      return;
    }
    dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
    dataRef.current.__outsidePressBubbles = outsidePressBubbles;
    let compositionTimeout = -1;
    function onScroll(event) {
      onOpenChange(false, event, 'ancestor-scroll');
    }
    function handleCompositionStart() {
      window.clearTimeout(compositionTimeout);
      isComposingRef.current = true;
    }
    function handleCompositionEnd() {
      // Safari fires `compositionend` before `keydown`, so we need to wait
      // until the next tick to set `isComposing` to `false`.
      // https://bugs.webkit.org/show_bug.cgi?id=165004
      compositionTimeout = window.setTimeout(() => {
        isComposingRef.current = false;
      },
      // 0ms or 1ms don't work in Safari. 5ms appears to consistently work.
      // Only apply to WebKit for the test to remain 0ms.
      isWebKit() ? 5 : 0);
    }
    const doc = getDocument(elements.floating);
    if (escapeKey) {
      doc.addEventListener('keydown', escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
      doc.addEventListener('compositionstart', handleCompositionStart);
      doc.addEventListener('compositionend', handleCompositionEnd);
    }
    outsidePress && doc.addEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
    let ancestors = [];
    if (ancestorScroll) {
      if (isElement(elements.domReference)) {
        ancestors = getOverflowAncestors(elements.domReference);
      }
      if (isElement(elements.floating)) {
        ancestors = ancestors.concat(getOverflowAncestors(elements.floating));
      }
      if (!isElement(elements.reference) && elements.reference && elements.reference.contextElement) {
        ancestors = ancestors.concat(getOverflowAncestors(elements.reference.contextElement));
      }
    }

    // Ignore the visual viewport for scrolling dismissal (allow pinch-zoom)
    ancestors = ancestors.filter(ancestor => {
      var _doc$defaultView;
      return ancestor !== ((_doc$defaultView = doc.defaultView) == null ? void 0 : _doc$defaultView.visualViewport);
    });
    ancestors.forEach(ancestor => {
      ancestor.addEventListener('scroll', onScroll, {
        passive: true
      });
    });
    return () => {
      if (escapeKey) {
        doc.removeEventListener('keydown', escapeKeyCapture ? closeOnEscapeKeyDownCapture : closeOnEscapeKeyDown, escapeKeyCapture);
        doc.removeEventListener('compositionstart', handleCompositionStart);
        doc.removeEventListener('compositionend', handleCompositionEnd);
      }
      outsidePress && doc.removeEventListener(outsidePressEvent, outsidePressCapture ? closeOnPressOutsideCapture : closeOnPressOutside, outsidePressCapture);
      ancestors.forEach(ancestor => {
        ancestor.removeEventListener('scroll', onScroll);
      });
      window.clearTimeout(compositionTimeout);
    };
  }, [dataRef, elements, escapeKey, outsidePress, outsidePressEvent, open, onOpenChange, ancestorScroll, enabled, escapeKeyBubbles, outsidePressBubbles, closeOnEscapeKeyDown, escapeKeyCapture, closeOnEscapeKeyDownCapture, closeOnPressOutside, outsidePressCapture, closeOnPressOutsideCapture]);
  React.useEffect(() => {
    insideReactTreeRef.current = false;
  }, [outsidePress, outsidePressEvent]);
  const reference = React.useMemo(() => ({
    onKeyDown: closeOnEscapeKeyDown,
    [bubbleHandlerKeys[referencePressEvent]]: event => {
      if (referencePress) {
        onOpenChange(false, event.nativeEvent, 'reference-press');
      }
    }
  }), [closeOnEscapeKeyDown, onOpenChange, referencePress, referencePressEvent]);
  const floating = React.useMemo(() => ({
    onKeyDown: closeOnEscapeKeyDown,
    onMouseDown() {
      endedOrStartedInsideRef.current = true;
    },
    onMouseUp() {
      endedOrStartedInsideRef.current = true;
    },
    [captureHandlerKeys[outsidePressEvent]]: () => {
      insideReactTreeRef.current = true;
    }
  }), [closeOnEscapeKeyDown, outsidePressEvent]);
  return React.useMemo(() => enabled ? {
    reference,
    floating
  } : {}, [enabled, reference, floating]);
}

function useFloatingRootContext(options) {
  const {
    open = false,
    onOpenChange: onOpenChangeProp,
    elements: elementsProp
  } = options;
  const floatingId = useId();
  const dataRef = react.useRef({});
  const [events] = react.useState(() => createPubSub());
  const nested = useFloatingParentNodeId() != null;
  if (true) {
    const optionDomReference = elementsProp.reference;
    if (optionDomReference && !(0,floating_ui_utils_dom/* isElement */.vq)(optionDomReference)) {
      error('Cannot pass a virtual element to the `elements.reference` option,', 'as it must be a real DOM element. Use `refs.setPositionReference()`', 'instead.');
    }
  }
  const [positionReference, setPositionReference] = react.useState(elementsProp.reference);
  const onOpenChange = useEffectEvent((open, event, reason) => {
    dataRef.current.openEvent = open ? event : undefined;
    events.emit('openchange', {
      open,
      event,
      reason,
      nested
    });
    onOpenChangeProp == null || onOpenChangeProp(open, event, reason);
  });
  const refs = react.useMemo(() => ({
    setPositionReference
  }), []);
  const elements = react.useMemo(() => ({
    reference: positionReference || elementsProp.reference || null,
    floating: elementsProp.floating || null,
    domReference: elementsProp.reference
  }), [positionReference, elementsProp.reference, elementsProp.floating]);
  return react.useMemo(() => ({
    dataRef,
    open,
    onOpenChange,
    elements,
    events,
    floatingId,
    refs
  }), [open, onOpenChange, elements, events, floatingId, refs]);
}

/**
 * Provides data to position a floating element and context to add interactions.
 * @see https://floating-ui.com/docs/useFloating
 */
function floating_ui_react_useFloating(options) {
  if (options === void 0) {
    options = {};
  }
  const {
    nodeId
  } = options;
  const internalRootContext = useFloatingRootContext({
    ...options,
    elements: {
      reference: null,
      floating: null,
      ...options.elements
    }
  });
  const rootContext = options.rootContext || internalRootContext;
  const computedElements = rootContext.elements;
  const [_domReference, setDomReference] = react.useState(null);
  const [positionReference, _setPositionReference] = react.useState(null);
  const optionDomReference = computedElements == null ? void 0 : computedElements.domReference;
  const domReference = optionDomReference || _domReference;
  const domReferenceRef = react.useRef(null);
  const tree = useFloatingTree();
  floating_ui_react_index(() => {
    if (domReference) {
      domReferenceRef.current = domReference;
    }
  }, [domReference]);
  const position = useFloating({
    ...options,
    elements: {
      ...computedElements,
      ...(positionReference && {
        reference: positionReference
      })
    }
  });
  const setPositionReference = react.useCallback(node => {
    const computedPositionReference = (0,floating_ui_utils_dom/* isElement */.vq)(node) ? {
      getBoundingClientRect: () => node.getBoundingClientRect(),
      contextElement: node
    } : node;
    // Store the positionReference in state if the DOM reference is specified externally via the
    // `elements.reference` option. This ensures that it won't be overridden on future renders.
    _setPositionReference(computedPositionReference);
    position.refs.setReference(computedPositionReference);
  }, [position.refs]);
  const setReference = react.useCallback(node => {
    if ((0,floating_ui_utils_dom/* isElement */.vq)(node) || node === null) {
      domReferenceRef.current = node;
      setDomReference(node);
    }

    // Backwards-compatibility for passing a virtual element to `reference`
    // after it has set the DOM reference.
    if ((0,floating_ui_utils_dom/* isElement */.vq)(position.refs.reference.current) || position.refs.reference.current === null ||
    // Don't allow setting virtual elements using the old technique back to
    // `null` to support `positionReference` + an unstable `reference`
    // callback ref.
    node !== null && !(0,floating_ui_utils_dom/* isElement */.vq)(node)) {
      position.refs.setReference(node);
    }
  }, [position.refs]);
  const refs = react.useMemo(() => ({
    ...position.refs,
    setReference,
    setPositionReference,
    domReference: domReferenceRef
  }), [position.refs, setReference, setPositionReference]);
  const elements = react.useMemo(() => ({
    ...position.elements,
    domReference: domReference
  }), [position.elements, domReference]);
  const context = react.useMemo(() => ({
    ...position,
    ...rootContext,
    refs,
    elements,
    nodeId
  }), [position, refs, elements, nodeId, rootContext]);
  floating_ui_react_index(() => {
    rootContext.dataRef.current.floatingContext = context;
    const node = tree == null ? void 0 : tree.nodesRef.current.find(node => node.id === nodeId);
    if (node) {
      node.context = context;
    }
  });
  return react.useMemo(() => ({
    ...position,
    context,
    refs,
    elements
  }), [position, refs, elements, context]);
}

/**
 * Opens the floating element while the reference element has focus, like CSS
 * `:focus`.
 * @see https://floating-ui.com/docs/useFocus
 */
function useFocus(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    onOpenChange,
    events,
    dataRef,
    elements
  } = context;
  const {
    enabled = true,
    visibleOnly = true
  } = props;
  const blockFocusRef = React.useRef(false);
  const timeoutRef = React.useRef();
  const keyboardModalityRef = React.useRef(true);
  React.useEffect(() => {
    if (!enabled) return;
    const win = getWindow(elements.domReference);

    // If the reference was focused and the user left the tab/window, and the
    // floating element was not open, the focus should be blocked when they
    // return to the tab/window.
    function onBlur() {
      if (!open && isHTMLElement(elements.domReference) && elements.domReference === activeElement(getDocument(elements.domReference))) {
        blockFocusRef.current = true;
      }
    }
    function onKeyDown() {
      keyboardModalityRef.current = true;
    }
    win.addEventListener('blur', onBlur);
    win.addEventListener('keydown', onKeyDown, true);
    return () => {
      win.removeEventListener('blur', onBlur);
      win.removeEventListener('keydown', onKeyDown, true);
    };
  }, [elements.domReference, open, enabled]);
  React.useEffect(() => {
    if (!enabled) return;
    function onOpenChange(_ref) {
      let {
        reason
      } = _ref;
      if (reason === 'reference-press' || reason === 'escape-key') {
        blockFocusRef.current = true;
      }
    }
    events.on('openchange', onOpenChange);
    return () => {
      events.off('openchange', onOpenChange);
    };
  }, [events, enabled]);
  React.useEffect(() => {
    return () => {
      clearTimeout(timeoutRef.current);
    };
  }, []);
  const reference = React.useMemo(() => ({
    onPointerDown(event) {
      if (isVirtualPointerEvent(event.nativeEvent)) return;
      keyboardModalityRef.current = false;
    },
    onMouseLeave() {
      blockFocusRef.current = false;
    },
    onFocus(event) {
      if (blockFocusRef.current) return;
      const target = getTarget(event.nativeEvent);
      if (visibleOnly && isElement(target)) {
        try {
          // Mac Safari unreliably matches `:focus-visible` on the reference
          // if focus was outside the page initially - use the fallback
          // instead.
          if (isSafari() && isMac()) throw Error();
          if (!target.matches(':focus-visible')) return;
        } catch (e) {
          // Old browsers will throw an error when using `:focus-visible`.
          if (!keyboardModalityRef.current && !isTypeableElement(target)) {
            return;
          }
        }
      }
      onOpenChange(true, event.nativeEvent, 'focus');
    },
    onBlur(event) {
      blockFocusRef.current = false;
      const relatedTarget = event.relatedTarget;
      const nativeEvent = event.nativeEvent;

      // Hit the non-modal focus management portal guard. Focus will be
      // moved into the floating element immediately after.
      const movedToFocusGuard = isElement(relatedTarget) && relatedTarget.hasAttribute(createAttribute('focus-guard')) && relatedTarget.getAttribute('data-type') === 'outside';

      // Wait for the window blur listener to fire.
      timeoutRef.current = window.setTimeout(() => {
        var _dataRef$current$floa;
        const activeEl = activeElement(elements.domReference ? elements.domReference.ownerDocument : document);

        // Focus left the page, keep it open.
        if (!relatedTarget && activeEl === elements.domReference) return;

        // When focusing the reference element (e.g. regular click), then
        // clicking into the floating element, prevent it from hiding.
        // Note: it must be focusable, e.g. `tabindex="-1"`.
        // We can not rely on relatedTarget to point to the correct element
        // as it will only point to the shadow host of the newly focused element
        // and not the element that actually has received focus if it is located
        // inside a shadow root.
        if (contains((_dataRef$current$floa = dataRef.current.floatingContext) == null ? void 0 : _dataRef$current$floa.refs.floating.current, activeEl) || contains(elements.domReference, activeEl) || movedToFocusGuard) {
          return;
        }
        onOpenChange(false, nativeEvent, 'focus');
      });
    }
  }), [dataRef, elements.domReference, onOpenChange, visibleOnly]);
  return React.useMemo(() => enabled ? {
    reference
  } : {}, [enabled, reference]);
}

const ACTIVE_KEY = 'active';
const SELECTED_KEY = 'selected';
function mergeProps(userProps, propsList, elementKey) {
  const map = new Map();
  const isItem = elementKey === 'item';
  let domUserProps = userProps;
  if (isItem && userProps) {
    const {
      [ACTIVE_KEY]: _,
      [SELECTED_KEY]: __,
      ...validProps
    } = userProps;
    domUserProps = validProps;
  }
  return {
    ...(elementKey === 'floating' && {
      tabIndex: -1,
      [FOCUSABLE_ATTRIBUTE]: ''
    }),
    ...domUserProps,
    ...propsList.map(value => {
      const propsOrGetProps = value ? value[elementKey] : null;
      if (typeof propsOrGetProps === 'function') {
        return userProps ? propsOrGetProps(userProps) : null;
      }
      return propsOrGetProps;
    }).concat(userProps).reduce((acc, props) => {
      if (!props) {
        return acc;
      }
      Object.entries(props).forEach(_ref => {
        let [key, value] = _ref;
        if (isItem && [ACTIVE_KEY, SELECTED_KEY].includes(key)) {
          return;
        }
        if (key.indexOf('on') === 0) {
          if (!map.has(key)) {
            map.set(key, []);
          }
          if (typeof value === 'function') {
            var _map$get;
            (_map$get = map.get(key)) == null || _map$get.push(value);
            acc[key] = function () {
              var _map$get2;
              for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                args[_key] = arguments[_key];
              }
              return (_map$get2 = map.get(key)) == null ? void 0 : _map$get2.map(fn => fn(...args)).find(val => val !== undefined);
            };
          }
        } else {
          acc[key] = value;
        }
      });
      return acc;
    }, {})
  };
}
/**
 * Merges an array of interaction hooks' props into prop getters, allowing
 * event handler functions to be composed together without overwriting one
 * another.
 * @see https://floating-ui.com/docs/useInteractions
 */
function useInteractions(propsList) {
  if (propsList === void 0) {
    propsList = [];
  }
  const referenceDeps = propsList.map(key => key == null ? void 0 : key.reference);
  const floatingDeps = propsList.map(key => key == null ? void 0 : key.floating);
  const itemDeps = propsList.map(key => key == null ? void 0 : key.item);
  const getReferenceProps = react.useCallback(userProps => mergeProps(userProps, propsList, 'reference'),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  referenceDeps);
  const getFloatingProps = react.useCallback(userProps => mergeProps(userProps, propsList, 'floating'),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  floatingDeps);
  const getItemProps = react.useCallback(userProps => mergeProps(userProps, propsList, 'item'),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  itemDeps);
  return react.useMemo(() => ({
    getReferenceProps,
    getFloatingProps,
    getItemProps
  }), [getReferenceProps, getFloatingProps, getItemProps]);
}

let isPreventScrollSupported = false;
function doSwitch(orientation, vertical, horizontal) {
  switch (orientation) {
    case 'vertical':
      return vertical;
    case 'horizontal':
      return horizontal;
    default:
      return vertical || horizontal;
  }
}
function isMainOrientationKey(key, orientation) {
  const vertical = key === ARROW_UP || key === ARROW_DOWN;
  const horizontal = key === ARROW_LEFT || key === ARROW_RIGHT;
  return doSwitch(orientation, vertical, horizontal);
}
function isMainOrientationToEndKey(key, orientation, rtl) {
  const vertical = key === ARROW_DOWN;
  const horizontal = rtl ? key === ARROW_LEFT : key === ARROW_RIGHT;
  return doSwitch(orientation, vertical, horizontal) || key === 'Enter' || key === ' ' || key === '';
}
function isCrossOrientationOpenKey(key, orientation, rtl) {
  const vertical = rtl ? key === ARROW_LEFT : key === ARROW_RIGHT;
  const horizontal = key === ARROW_DOWN;
  return doSwitch(orientation, vertical, horizontal);
}
function isCrossOrientationCloseKey(key, orientation, rtl) {
  const vertical = rtl ? key === ARROW_RIGHT : key === ARROW_LEFT;
  const horizontal = key === ARROW_UP;
  return doSwitch(orientation, vertical, horizontal);
}
/**
 * Adds arrow key-based navigation of a list of items, either using real DOM
 * focus or virtual focus.
 * @see https://floating-ui.com/docs/useListNavigation
 */
function useListNavigation(context, props) {
  const {
    open,
    onOpenChange,
    elements
  } = context;
  const {
    listRef,
    activeIndex,
    onNavigate: unstable_onNavigate = () => {},
    enabled = true,
    selectedIndex = null,
    allowEscape = false,
    loop = false,
    nested = false,
    rtl = false,
    virtual = false,
    focusItemOnOpen = 'auto',
    focusItemOnHover = true,
    openOnArrowKeyDown = true,
    disabledIndices = undefined,
    orientation = 'vertical',
    cols = 1,
    scrollItemIntoView = true,
    virtualItemRef,
    itemSizes,
    dense = false
  } = props;
  if (true) {
    if (allowEscape) {
      if (!loop) {
        warn('`useListNavigation` looping must be enabled to allow escaping.');
      }
      if (!virtual) {
        warn('`useListNavigation` must be virtual to allow escaping.');
      }
    }
    if (orientation === 'vertical' && cols > 1) {
      warn('In grid list navigation mode (`cols` > 1), the `orientation` should', 'be either "horizontal" or "both".');
    }
  }
  const floatingFocusElement = getFloatingFocusElement(elements.floating);
  const floatingFocusElementRef = floating_ui_react_useLatestRef(floatingFocusElement);
  const parentId = useFloatingParentNodeId();
  const tree = useFloatingTree();
  const onNavigate = useEffectEvent(unstable_onNavigate);
  const typeableComboboxReference = isTypeableCombobox(elements.domReference);
  const focusItemOnOpenRef = React.useRef(focusItemOnOpen);
  const indexRef = React.useRef(selectedIndex != null ? selectedIndex : -1);
  const keyRef = React.useRef(null);
  const isPointerModalityRef = React.useRef(true);
  const previousOnNavigateRef = React.useRef(onNavigate);
  const previousMountedRef = React.useRef(!!elements.floating);
  const previousOpenRef = React.useRef(open);
  const forceSyncFocus = React.useRef(false);
  const forceScrollIntoViewRef = React.useRef(false);
  const disabledIndicesRef = floating_ui_react_useLatestRef(disabledIndices);
  const latestOpenRef = floating_ui_react_useLatestRef(open);
  const scrollItemIntoViewRef = floating_ui_react_useLatestRef(scrollItemIntoView);
  const selectedIndexRef = floating_ui_react_useLatestRef(selectedIndex);
  const [activeId, setActiveId] = React.useState();
  const [virtualId, setVirtualId] = React.useState();
  const focusItem = useEffectEvent(function (listRef, indexRef, forceScrollIntoView) {
    if (forceScrollIntoView === void 0) {
      forceScrollIntoView = false;
    }
    function runFocus(item) {
      if (virtual) {
        setActiveId(item.id);
        tree == null || tree.events.emit('virtualfocus', item);
        if (virtualItemRef) {
          virtualItemRef.current = item;
        }
      } else {
        enqueueFocus(item, {
          preventScroll: true,
          // Mac Safari does not move the virtual cursor unless the focus call
          // is sync. However, for the very first focus call, we need to wait
          // for the position to be ready in order to prevent unwanted
          // scrolling. This means the virtual cursor will not move to the first
          // item when first opening the floating element, but will on
          // subsequent calls. `preventScroll` is supported in modern Safari,
          // so we can use that instead.
          // iOS Safari must be async or the first item will not be focused.
          sync: isMac() && isSafari() ? isPreventScrollSupported || forceSyncFocus.current : false
        });
      }
    }
    const initialItem = listRef.current[indexRef.current];
    if (initialItem) {
      runFocus(initialItem);
    }
    requestAnimationFrame(() => {
      const waitedItem = listRef.current[indexRef.current] || initialItem;
      if (!waitedItem) return;
      if (!initialItem) {
        runFocus(waitedItem);
      }
      const scrollIntoViewOptions = scrollItemIntoViewRef.current;
      const shouldScrollIntoView = scrollIntoViewOptions && item && (forceScrollIntoView || !isPointerModalityRef.current);
      if (shouldScrollIntoView) {
        // JSDOM doesn't support `.scrollIntoView()` but it's widely supported
        // by all browsers.
        waitedItem.scrollIntoView == null || waitedItem.scrollIntoView(typeof scrollIntoViewOptions === 'boolean' ? {
          block: 'nearest',
          inline: 'nearest'
        } : scrollIntoViewOptions);
      }
    });
  });
  floating_ui_react_index(() => {
    document.createElement('div').focus({
      get preventScroll() {
        isPreventScrollSupported = true;
        return false;
      }
    });
  }, []);

  // Sync `selectedIndex` to be the `activeIndex` upon opening the floating
  // element. Also, reset `activeIndex` upon closing the floating element.
  floating_ui_react_index(() => {
    if (!enabled) return;
    if (open && elements.floating) {
      if (focusItemOnOpenRef.current && selectedIndex != null) {
        // Regardless of the pointer modality, we want to ensure the selected
        // item comes into view when the floating element is opened.
        forceScrollIntoViewRef.current = true;
        indexRef.current = selectedIndex;
        onNavigate(selectedIndex);
      }
    } else if (previousMountedRef.current) {
      // Since the user can specify `onNavigate` conditionally
      // (onNavigate: open ? setActiveIndex : setSelectedIndex),
      // we store and call the previous function.
      indexRef.current = -1;
      previousOnNavigateRef.current(null);
    }
  }, [enabled, open, elements.floating, selectedIndex, onNavigate]);

  // Sync `activeIndex` to be the focused item while the floating element is
  // open.
  floating_ui_react_index(() => {
    if (!enabled) return;
    if (open && elements.floating) {
      if (activeIndex == null) {
        forceSyncFocus.current = false;
        if (selectedIndexRef.current != null) {
          return;
        }

        // Reset while the floating element was open (e.g. the list changed).
        if (previousMountedRef.current) {
          indexRef.current = -1;
          focusItem(listRef, indexRef);
        }

        // Initial sync.
        if ((!previousOpenRef.current || !previousMountedRef.current) && focusItemOnOpenRef.current && (keyRef.current != null || focusItemOnOpenRef.current === true && keyRef.current == null)) {
          let runs = 0;
          const waitForListPopulated = () => {
            if (listRef.current[0] == null) {
              // Avoid letting the browser paint if possible on the first try,
              // otherwise use rAF. Don't try more than twice, since something
              // is wrong otherwise.
              if (runs < 2) {
                const scheduler = runs ? requestAnimationFrame : queueMicrotask;
                scheduler(waitForListPopulated);
              }
              runs++;
            } else {
              indexRef.current = keyRef.current == null || isMainOrientationToEndKey(keyRef.current, orientation, rtl) || nested ? getMinIndex(listRef, disabledIndicesRef.current) : getMaxIndex(listRef, disabledIndicesRef.current);
              keyRef.current = null;
              onNavigate(indexRef.current);
            }
          };
          waitForListPopulated();
        }
      } else if (!isIndexOutOfBounds(listRef, activeIndex)) {
        indexRef.current = activeIndex;
        focusItem(listRef, indexRef, forceScrollIntoViewRef.current);
        forceScrollIntoViewRef.current = false;
      }
    }
  }, [enabled, open, elements.floating, activeIndex, selectedIndexRef, nested, listRef, orientation, rtl, onNavigate, focusItem, disabledIndicesRef]);

  // Ensure the parent floating element has focus when a nested child closes
  // to allow arrow key navigation to work after the pointer leaves the child.
  floating_ui_react_index(() => {
    var _nodes$find;
    if (!enabled || elements.floating || !tree || virtual || !previousMountedRef.current) {
      return;
    }
    const nodes = tree.nodesRef.current;
    const parent = (_nodes$find = nodes.find(node => node.id === parentId)) == null || (_nodes$find = _nodes$find.context) == null ? void 0 : _nodes$find.elements.floating;
    const activeEl = activeElement(getDocument(elements.floating));
    const treeContainsActiveEl = nodes.some(node => node.context && contains(node.context.elements.floating, activeEl));
    if (parent && !treeContainsActiveEl && isPointerModalityRef.current) {
      parent.focus({
        preventScroll: true
      });
    }
  }, [enabled, elements.floating, tree, parentId, virtual]);
  floating_ui_react_index(() => {
    if (!enabled) return;
    if (!tree) return;
    if (!virtual) return;
    if (parentId) return;
    function handleVirtualFocus(item) {
      setVirtualId(item.id);
      if (virtualItemRef) {
        virtualItemRef.current = item;
      }
    }
    tree.events.on('virtualfocus', handleVirtualFocus);
    return () => {
      tree.events.off('virtualfocus', handleVirtualFocus);
    };
  }, [enabled, tree, virtual, parentId, virtualItemRef]);
  floating_ui_react_index(() => {
    previousOnNavigateRef.current = onNavigate;
    previousMountedRef.current = !!elements.floating;
  });
  floating_ui_react_index(() => {
    if (!open) {
      keyRef.current = null;
    }
  }, [open]);
  floating_ui_react_index(() => {
    previousOpenRef.current = open;
  }, [open]);
  const hasActiveIndex = activeIndex != null;
  const item = React.useMemo(() => {
    function syncCurrentTarget(currentTarget) {
      if (!open) return;
      const index = listRef.current.indexOf(currentTarget);
      if (index !== -1) {
        onNavigate(index);
      }
    }
    const props = {
      onFocus(_ref) {
        let {
          currentTarget
        } = _ref;
        syncCurrentTarget(currentTarget);
      },
      onClick: _ref2 => {
        let {
          currentTarget
        } = _ref2;
        return currentTarget.focus({
          preventScroll: true
        });
      },
      // Safari
      ...(focusItemOnHover && {
        onMouseMove(_ref3) {
          let {
            currentTarget
          } = _ref3;
          syncCurrentTarget(currentTarget);
        },
        onPointerLeave(_ref4) {
          let {
            pointerType
          } = _ref4;
          if (!isPointerModalityRef.current || pointerType === 'touch') {
            return;
          }
          indexRef.current = -1;
          focusItem(listRef, indexRef);
          onNavigate(null);
          if (!virtual) {
            enqueueFocus(floatingFocusElementRef.current, {
              preventScroll: true
            });
          }
        }
      })
    };
    return props;
  }, [open, floatingFocusElementRef, focusItem, focusItemOnHover, listRef, onNavigate, virtual]);
  const commonOnKeyDown = useEffectEvent(event => {
    isPointerModalityRef.current = false;
    forceSyncFocus.current = true;

    // When composing a character, Chrome fires ArrowDown twice. Firefox/Safari
    // don't appear to suffer from this. `event.isComposing` is avoided due to
    // Safari not supporting it properly (although it's not needed in the first
    // place for Safari, just avoiding any possible issues).
    if (event.which === 229) {
      return;
    }

    // If the floating element is animating out, ignore navigation. Otherwise,
    // the `activeIndex` gets set to 0 despite not being open so the next time
    // the user ArrowDowns, the first item won't be focused.
    if (!latestOpenRef.current && event.currentTarget === floatingFocusElementRef.current) {
      return;
    }
    if (nested && isCrossOrientationCloseKey(event.key, orientation, rtl)) {
      stopEvent(event);
      onOpenChange(false, event.nativeEvent, 'list-navigation');
      if (isHTMLElement(elements.domReference)) {
        if (virtual) {
          tree == null || tree.events.emit('virtualfocus', elements.domReference);
        } else {
          elements.domReference.focus();
        }
      }
      return;
    }
    const currentIndex = indexRef.current;
    const minIndex = getMinIndex(listRef, disabledIndices);
    const maxIndex = getMaxIndex(listRef, disabledIndices);
    if (!typeableComboboxReference) {
      if (event.key === 'Home') {
        stopEvent(event);
        indexRef.current = minIndex;
        onNavigate(indexRef.current);
      }
      if (event.key === 'End') {
        stopEvent(event);
        indexRef.current = maxIndex;
        onNavigate(indexRef.current);
      }
    }

    // Grid navigation.
    if (cols > 1) {
      const sizes = itemSizes || Array.from({
        length: listRef.current.length
      }, () => ({
        width: 1,
        height: 1
      }));
      // To calculate movements on the grid, we use hypothetical cell indices
      // as if every item was 1x1, then convert back to real indices.
      const cellMap = buildCellMap(sizes, cols, dense);
      const minGridIndex = cellMap.findIndex(index => index != null && !isDisabled(listRef.current, index, disabledIndices));
      // last enabled index
      const maxGridIndex = cellMap.reduce((foundIndex, index, cellIndex) => index != null && !isDisabled(listRef.current, index, disabledIndices) ? cellIndex : foundIndex, -1);
      const index = cellMap[getGridNavigatedIndex({
        current: cellMap.map(itemIndex => itemIndex != null ? listRef.current[itemIndex] : null)
      }, {
        event,
        orientation,
        loop,
        rtl,
        cols,
        // treat undefined (empty grid spaces) as disabled indices so we
        // don't end up in them
        disabledIndices: getCellIndices([...(disabledIndices || listRef.current.map((_, index) => isDisabled(listRef.current, index) ? index : undefined)), undefined], cellMap),
        minIndex: minGridIndex,
        maxIndex: maxGridIndex,
        prevIndex: getCellIndexOfCorner(indexRef.current > maxIndex ? minIndex : indexRef.current, sizes, cellMap, cols,
        // use a corner matching the edge closest to the direction
        // we're moving in so we don't end up in the same item. Prefer
        // top/left over bottom/right.
        event.key === ARROW_DOWN ? 'bl' : event.key === (rtl ? ARROW_LEFT : ARROW_RIGHT) ? 'tr' : 'tl'),
        stopEvent: true
      })];
      if (index != null) {
        indexRef.current = index;
        onNavigate(indexRef.current);
      }
      if (orientation === 'both') {
        return;
      }
    }
    if (isMainOrientationKey(event.key, orientation)) {
      stopEvent(event);

      // Reset the index if no item is focused.
      if (open && !virtual && activeElement(event.currentTarget.ownerDocument) === event.currentTarget) {
        indexRef.current = isMainOrientationToEndKey(event.key, orientation, rtl) ? minIndex : maxIndex;
        onNavigate(indexRef.current);
        return;
      }
      if (isMainOrientationToEndKey(event.key, orientation, rtl)) {
        if (loop) {
          indexRef.current = currentIndex >= maxIndex ? allowEscape && currentIndex !== listRef.current.length ? -1 : minIndex : findNonDisabledIndex(listRef, {
            startingIndex: currentIndex,
            disabledIndices
          });
        } else {
          indexRef.current = Math.min(maxIndex, findNonDisabledIndex(listRef, {
            startingIndex: currentIndex,
            disabledIndices
          }));
        }
      } else {
        if (loop) {
          indexRef.current = currentIndex <= minIndex ? allowEscape && currentIndex !== -1 ? listRef.current.length : maxIndex : findNonDisabledIndex(listRef, {
            startingIndex: currentIndex,
            decrement: true,
            disabledIndices
          });
        } else {
          indexRef.current = Math.max(minIndex, findNonDisabledIndex(listRef, {
            startingIndex: currentIndex,
            decrement: true,
            disabledIndices
          }));
        }
      }
      if (isIndexOutOfBounds(listRef, indexRef.current)) {
        onNavigate(null);
      } else {
        onNavigate(indexRef.current);
      }
    }
  });
  const ariaActiveDescendantProp = React.useMemo(() => {
    return virtual && open && hasActiveIndex && {
      'aria-activedescendant': virtualId || activeId
    };
  }, [virtual, open, hasActiveIndex, virtualId, activeId]);
  const floating = React.useMemo(() => {
    return {
      'aria-orientation': orientation === 'both' ? undefined : orientation,
      ...(!isTypeableCombobox(elements.domReference) && ariaActiveDescendantProp),
      onKeyDown: commonOnKeyDown,
      onPointerMove() {
        isPointerModalityRef.current = true;
      }
    };
  }, [ariaActiveDescendantProp, commonOnKeyDown, elements.domReference, orientation]);
  const reference = React.useMemo(() => {
    function checkVirtualMouse(event) {
      if (focusItemOnOpen === 'auto' && isVirtualClick(event.nativeEvent)) {
        focusItemOnOpenRef.current = true;
      }
    }
    function checkVirtualPointer(event) {
      // `pointerdown` fires first, reset the state then perform the checks.
      focusItemOnOpenRef.current = focusItemOnOpen;
      if (focusItemOnOpen === 'auto' && isVirtualPointerEvent(event.nativeEvent)) {
        focusItemOnOpenRef.current = true;
      }
    }
    return {
      ...ariaActiveDescendantProp,
      onKeyDown(event) {
        isPointerModalityRef.current = false;
        const isArrowKey = event.key.startsWith('Arrow');
        const isHomeOrEndKey = ['Home', 'End'].includes(event.key);
        const isMoveKey = isArrowKey || isHomeOrEndKey;
        const isCrossOpenKey = isCrossOrientationOpenKey(event.key, orientation, rtl);
        const isCrossCloseKey = isCrossOrientationCloseKey(event.key, orientation, rtl);
        const isMainKey = isMainOrientationKey(event.key, orientation);
        const isNavigationKey = (nested ? isCrossOpenKey : isMainKey) || event.key === 'Enter' || event.key.trim() === '';
        if (virtual && open) {
          const rootNode = tree == null ? void 0 : tree.nodesRef.current.find(node => node.parentId == null);
          const deepestNode = tree && rootNode ? getDeepestNode(tree.nodesRef.current, rootNode.id) : null;
          if (isMoveKey && deepestNode && virtualItemRef) {
            const eventObject = new KeyboardEvent('keydown', {
              key: event.key,
              bubbles: true
            });
            if (isCrossOpenKey || isCrossCloseKey) {
              var _deepestNode$context, _deepestNode$context2;
              const isCurrentTarget = ((_deepestNode$context = deepestNode.context) == null ? void 0 : _deepestNode$context.elements.domReference) === event.currentTarget;
              const dispatchItem = isCrossCloseKey && !isCurrentTarget ? (_deepestNode$context2 = deepestNode.context) == null ? void 0 : _deepestNode$context2.elements.domReference : isCrossOpenKey ? listRef.current.find(item => (item == null ? void 0 : item.id) === activeId) : null;
              if (dispatchItem) {
                stopEvent(event);
                dispatchItem.dispatchEvent(eventObject);
                setVirtualId(undefined);
              }
            }
            if ((isMainKey || isHomeOrEndKey) && deepestNode.context) {
              if (deepestNode.context.open && deepestNode.parentId && event.currentTarget !== deepestNode.context.elements.domReference) {
                var _deepestNode$context$;
                stopEvent(event);
                (_deepestNode$context$ = deepestNode.context.elements.domReference) == null || _deepestNode$context$.dispatchEvent(eventObject);
                return;
              }
            }
          }
          return commonOnKeyDown(event);
        }

        // If a floating element should not open on arrow key down, avoid
        // setting `activeIndex` while it's closed.
        if (!open && !openOnArrowKeyDown && isArrowKey) {
          return;
        }
        if (isNavigationKey) {
          keyRef.current = nested && isMainKey ? null : event.key;
        }
        if (nested) {
          if (isCrossOpenKey) {
            stopEvent(event);
            if (open) {
              indexRef.current = getMinIndex(listRef, disabledIndicesRef.current);
              onNavigate(indexRef.current);
            } else {
              onOpenChange(true, event.nativeEvent, 'list-navigation');
            }
          }
          return;
        }
        if (isMainKey) {
          if (selectedIndex != null) {
            indexRef.current = selectedIndex;
          }
          stopEvent(event);
          if (!open && openOnArrowKeyDown) {
            onOpenChange(true, event.nativeEvent, 'list-navigation');
          } else {
            commonOnKeyDown(event);
          }
          if (open) {
            onNavigate(indexRef.current);
          }
        }
      },
      onFocus() {
        if (open && !virtual) {
          onNavigate(null);
        }
      },
      onPointerDown: checkVirtualPointer,
      onMouseDown: checkVirtualMouse,
      onClick: checkVirtualMouse
    };
  }, [activeId, ariaActiveDescendantProp, commonOnKeyDown, disabledIndicesRef, focusItemOnOpen, listRef, nested, onNavigate, onOpenChange, open, openOnArrowKeyDown, orientation, rtl, selectedIndex, tree, virtual, virtualItemRef]);
  return React.useMemo(() => enabled ? {
    reference,
    floating,
    item
  } : {}, [enabled, reference, floating, item]);
}

const componentRoleToAriaRoleMap = /*#__PURE__*/new Map([['select', 'listbox'], ['combobox', 'listbox'], ['label', false]]);

/**
 * Adds base screen reader props to the reference and floating elements for a
 * given floating element `role`.
 * @see https://floating-ui.com/docs/useRole
 */
function useRole(context, props) {
  var _componentRoleToAriaR;
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    floatingId
  } = context;
  const {
    enabled = true,
    role = 'dialog'
  } = props;
  const ariaRole = (_componentRoleToAriaR = componentRoleToAriaRoleMap.get(role)) != null ? _componentRoleToAriaR : role;
  const referenceId = useId();
  const parentId = useFloatingParentNodeId();
  const isNested = parentId != null;
  const reference = React.useMemo(() => {
    if (ariaRole === 'tooltip' || role === 'label') {
      return {
        ["aria-" + (role === 'label' ? 'labelledby' : 'describedby')]: open ? floatingId : undefined
      };
    }
    return {
      'aria-expanded': open ? 'true' : 'false',
      'aria-haspopup': ariaRole === 'alertdialog' ? 'dialog' : ariaRole,
      'aria-controls': open ? floatingId : undefined,
      ...(ariaRole === 'listbox' && {
        role: 'combobox'
      }),
      ...(ariaRole === 'menu' && {
        id: referenceId
      }),
      ...(ariaRole === 'menu' && isNested && {
        role: 'menuitem'
      }),
      ...(role === 'select' && {
        'aria-autocomplete': 'none'
      }),
      ...(role === 'combobox' && {
        'aria-autocomplete': 'list'
      })
    };
  }, [ariaRole, floatingId, isNested, open, referenceId, role]);
  const floating = React.useMemo(() => {
    const floatingProps = {
      id: floatingId,
      ...(ariaRole && {
        role: ariaRole
      })
    };
    if (ariaRole === 'tooltip' || role === 'label') {
      return floatingProps;
    }
    return {
      ...floatingProps,
      ...(ariaRole === 'menu' && {
        'aria-labelledby': referenceId
      })
    };
  }, [ariaRole, floatingId, referenceId, role]);
  const item = React.useCallback(_ref => {
    let {
      active,
      selected
    } = _ref;
    const commonProps = {
      role: 'option',
      ...(active && {
        id: floatingId + "-option"
      })
    };

    // For `menu`, we are unable to tell if the item is a `menuitemradio`
    // or `menuitemcheckbox`. For backwards-compatibility reasons, also
    // avoid defaulting to `menuitem` as it may overwrite custom role props.
    switch (role) {
      case 'select':
        return {
          ...commonProps,
          'aria-selected': active && selected
        };
      case 'combobox':
        {
          return {
            ...commonProps,
            ...(active && {
              'aria-selected': true
            })
          };
        }
    }
    return {};
  }, [floatingId, role]);
  return React.useMemo(() => enabled ? {
    reference,
    floating,
    item
  } : {}, [enabled, reference, floating, item]);
}

// Converts a JS style key like `backgroundColor` to a CSS transition-property
// like `background-color`.
const camelCaseToKebabCase = str => str.replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? '-' : '') + $.toLowerCase());
function execWithArgsOrReturn(valueOrFn, args) {
  return typeof valueOrFn === 'function' ? valueOrFn(args) : valueOrFn;
}
function useDelayUnmount(open, durationMs) {
  const [isMounted, setIsMounted] = React.useState(open);
  if (open && !isMounted) {
    setIsMounted(true);
  }
  React.useEffect(() => {
    if (!open && isMounted) {
      const timeout = setTimeout(() => setIsMounted(false), durationMs);
      return () => clearTimeout(timeout);
    }
  }, [open, isMounted, durationMs]);
  return isMounted;
}
/**
 * Provides a status string to apply CSS transitions to a floating element,
 * correctly handling placement-aware transitions.
 * @see https://floating-ui.com/docs/useTransition#usetransitionstatus
 */
function useTransitionStatus(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    open,
    elements: {
      floating
    }
  } = context;
  const {
    duration = 250
  } = props;
  const isNumberDuration = typeof duration === 'number';
  const closeDuration = (isNumberDuration ? duration : duration.close) || 0;
  const [status, setStatus] = React.useState('unmounted');
  const isMounted = useDelayUnmount(open, closeDuration);
  if (!isMounted && status === 'close') {
    setStatus('unmounted');
  }
  floating_ui_react_index(() => {
    if (!floating) return;
    if (open) {
      setStatus('initial');
      const frame = requestAnimationFrame(() => {
        setStatus('open');
      });
      return () => {
        cancelAnimationFrame(frame);
      };
    }
    setStatus('close');
  }, [open, floating]);
  return {
    isMounted,
    status
  };
}
/**
 * Provides styles to apply CSS transitions to a floating element, correctly
 * handling placement-aware transitions. Wrapper around `useTransitionStatus`.
 * @see https://floating-ui.com/docs/useTransition#usetransitionstyles
 */
function useTransitionStyles(context, props) {
  if (props === void 0) {
    props = {};
  }
  const {
    initial: unstable_initial = {
      opacity: 0
    },
    open: unstable_open,
    close: unstable_close,
    common: unstable_common,
    duration = 250
  } = props;
  const placement = context.placement;
  const side = placement.split('-')[0];
  const fnArgs = React.useMemo(() => ({
    side,
    placement
  }), [side, placement]);
  const isNumberDuration = typeof duration === 'number';
  const openDuration = (isNumberDuration ? duration : duration.open) || 0;
  const closeDuration = (isNumberDuration ? duration : duration.close) || 0;
  const [styles, setStyles] = React.useState(() => ({
    ...execWithArgsOrReturn(unstable_common, fnArgs),
    ...execWithArgsOrReturn(unstable_initial, fnArgs)
  }));
  const {
    isMounted,
    status
  } = useTransitionStatus(context, {
    duration
  });
  const initialRef = floating_ui_react_useLatestRef(unstable_initial);
  const openRef = floating_ui_react_useLatestRef(unstable_open);
  const closeRef = floating_ui_react_useLatestRef(unstable_close);
  const commonRef = floating_ui_react_useLatestRef(unstable_common);
  floating_ui_react_index(() => {
    const initialStyles = execWithArgsOrReturn(initialRef.current, fnArgs);
    const closeStyles = execWithArgsOrReturn(closeRef.current, fnArgs);
    const commonStyles = execWithArgsOrReturn(commonRef.current, fnArgs);
    const openStyles = execWithArgsOrReturn(openRef.current, fnArgs) || Object.keys(initialStyles).reduce((acc, key) => {
      acc[key] = '';
      return acc;
    }, {});
    if (status === 'initial') {
      setStyles(styles => ({
        transitionProperty: styles.transitionProperty,
        ...commonStyles,
        ...initialStyles
      }));
    }
    if (status === 'open') {
      setStyles({
        transitionProperty: Object.keys(openStyles).map(camelCaseToKebabCase).join(','),
        transitionDuration: openDuration + "ms",
        ...commonStyles,
        ...openStyles
      });
    }
    if (status === 'close') {
      const styles = closeStyles || initialStyles;
      setStyles({
        transitionProperty: Object.keys(styles).map(camelCaseToKebabCase).join(','),
        transitionDuration: closeDuration + "ms",
        ...commonStyles,
        ...styles
      });
    }
  }, [closeDuration, closeRef, initialRef, openRef, commonRef, openDuration, status, fnArgs]);
  return {
    isMounted,
    styles
  };
}

/**
 * Provides a matching callback that can be used to focus an item as the user
 * types, often used in tandem with `useListNavigation()`.
 * @see https://floating-ui.com/docs/useTypeahead
 */
function useTypeahead(context, props) {
  var _ref;
  const {
    open,
    dataRef
  } = context;
  const {
    listRef,
    activeIndex,
    onMatch: unstable_onMatch,
    onTypingChange: unstable_onTypingChange,
    enabled = true,
    findMatch = null,
    resetMs = 750,
    ignoreKeys = [],
    selectedIndex = null
  } = props;
  const timeoutIdRef = React.useRef();
  const stringRef = React.useRef('');
  const prevIndexRef = React.useRef((_ref = selectedIndex != null ? selectedIndex : activeIndex) != null ? _ref : -1);
  const matchIndexRef = React.useRef(null);
  const onMatch = useEffectEvent(unstable_onMatch);
  const onTypingChange = useEffectEvent(unstable_onTypingChange);
  const findMatchRef = floating_ui_react_useLatestRef(findMatch);
  const ignoreKeysRef = floating_ui_react_useLatestRef(ignoreKeys);
  floating_ui_react_index(() => {
    if (open) {
      clearTimeout(timeoutIdRef.current);
      matchIndexRef.current = null;
      stringRef.current = '';
    }
  }, [open]);
  floating_ui_react_index(() => {
    // Sync arrow key navigation but not typeahead navigation.
    if (open && stringRef.current === '') {
      var _ref2;
      prevIndexRef.current = (_ref2 = selectedIndex != null ? selectedIndex : activeIndex) != null ? _ref2 : -1;
    }
  }, [open, selectedIndex, activeIndex]);
  const setTypingChange = useEffectEvent(value => {
    if (value) {
      if (!dataRef.current.typing) {
        dataRef.current.typing = value;
        onTypingChange(value);
      }
    } else {
      if (dataRef.current.typing) {
        dataRef.current.typing = value;
        onTypingChange(value);
      }
    }
  });
  const onKeyDown = useEffectEvent(event => {
    function getMatchingIndex(list, orderedList, string) {
      const str = findMatchRef.current ? findMatchRef.current(orderedList, string) : orderedList.find(text => (text == null ? void 0 : text.toLocaleLowerCase().indexOf(string.toLocaleLowerCase())) === 0);
      return str ? list.indexOf(str) : -1;
    }
    const listContent = listRef.current;
    if (stringRef.current.length > 0 && stringRef.current[0] !== ' ') {
      if (getMatchingIndex(listContent, listContent, stringRef.current) === -1) {
        setTypingChange(false);
      } else if (event.key === ' ') {
        stopEvent(event);
      }
    }
    if (listContent == null || ignoreKeysRef.current.includes(event.key) ||
    // Character key.
    event.key.length !== 1 ||
    // Modifier key.
    event.ctrlKey || event.metaKey || event.altKey) {
      return;
    }
    if (open && event.key !== ' ') {
      stopEvent(event);
      setTypingChange(true);
    }

    // Bail out if the list contains a word like "llama" or "aaron". TODO:
    // allow it in this case, too.
    const allowRapidSuccessionOfFirstLetter = listContent.every(text => {
      var _text$, _text$2;
      return text ? ((_text$ = text[0]) == null ? void 0 : _text$.toLocaleLowerCase()) !== ((_text$2 = text[1]) == null ? void 0 : _text$2.toLocaleLowerCase()) : true;
    });

    // Allows the user to cycle through items that start with the same letter
    // in rapid succession.
    if (allowRapidSuccessionOfFirstLetter && stringRef.current === event.key) {
      stringRef.current = '';
      prevIndexRef.current = matchIndexRef.current;
    }
    stringRef.current += event.key;
    clearTimeout(timeoutIdRef.current);
    timeoutIdRef.current = setTimeout(() => {
      stringRef.current = '';
      prevIndexRef.current = matchIndexRef.current;
      setTypingChange(false);
    }, resetMs);
    const prevIndex = prevIndexRef.current;
    const index = getMatchingIndex(listContent, [...listContent.slice((prevIndex || 0) + 1), ...listContent.slice(0, (prevIndex || 0) + 1)], stringRef.current);
    if (index !== -1) {
      onMatch(index);
      matchIndexRef.current = index;
    } else if (event.key !== ' ') {
      stringRef.current = '';
      setTypingChange(false);
    }
  });
  const reference = React.useMemo(() => ({
    onKeyDown
  }), [onKeyDown]);
  const floating = React.useMemo(() => {
    return {
      onKeyDown,
      onKeyUp(event) {
        if (event.key === ' ') {
          setTypingChange(false);
        }
      }
    };
  }, [onKeyDown, setTypingChange]);
  return React.useMemo(() => enabled ? {
    reference,
    floating
  } : {}, [enabled, reference, floating]);
}

function getArgsWithCustomFloatingHeight(state, height) {
  return {
    ...state,
    rects: {
      ...state.rects,
      floating: {
        ...state.rects.floating,
        height
      }
    }
  };
}
/**
 * Positions the floating element such that an inner element inside of it is
 * anchored to the reference element.
 * @see https://floating-ui.com/docs/inner
 */
const inner = props => ({
  name: 'inner',
  options: props,
  async fn(state) {
    const {
      listRef,
      overflowRef,
      onFallbackChange,
      offset: innerOffset = 0,
      index = 0,
      minItemsVisible = 4,
      referenceOverflowThreshold = 0,
      scrollRef,
      ...detectOverflowOptions
    } = (0,floating_ui_utils/* evaluate */._3)(props, state);
    const {
      rects,
      elements: {
        floating
      }
    } = state;
    const item = listRef.current[index];
    const scrollEl = (scrollRef == null ? void 0 : scrollRef.current) || floating;

    // Valid combinations:
    // 1. Floating element is the scrollRef and has a border (default)
    // 2. Floating element is not the scrollRef, floating element has a border
    // 3. Floating element is not the scrollRef, scrollRef has a border
    // Floating > {...getFloatingProps()} wrapper > scrollRef > items is not
    // allowed as VoiceOver doesn't work.
    const clientTop = floating.clientTop || scrollEl.clientTop;
    const floatingIsBordered = floating.clientTop !== 0;
    const scrollElIsBordered = scrollEl.clientTop !== 0;
    const floatingIsScrollEl = floating === scrollEl;
    if (true) {
      if (!state.placement.startsWith('bottom')) {
        warn('`placement` side must be "bottom" when using the `inner`', 'middleware.');
      }
    }
    if (!item) {
      return {};
    }
    const nextArgs = {
      ...state,
      ...(await offset(-item.offsetTop - floating.clientTop - rects.reference.height / 2 - item.offsetHeight / 2 - innerOffset).fn(state))
    };
    const overflow = await (0,floating_ui_dom/* detectOverflow */.__)(getArgsWithCustomFloatingHeight(nextArgs, scrollEl.scrollHeight + clientTop + floating.clientTop), detectOverflowOptions);
    const refOverflow = await (0,floating_ui_dom/* detectOverflow */.__)(nextArgs, {
      ...detectOverflowOptions,
      elementContext: 'reference'
    });
    const diffY = (0,floating_ui_utils/* max */.T9)(0, overflow.top);
    const nextY = nextArgs.y + diffY;
    const isScrollable = scrollEl.scrollHeight > scrollEl.clientHeight;
    const rounder = isScrollable ? v => v : floating_ui_utils/* round */.LI;
    const maxHeight = rounder((0,floating_ui_utils/* max */.T9)(0, scrollEl.scrollHeight + (floatingIsBordered && floatingIsScrollEl || scrollElIsBordered ? clientTop * 2 : 0) - diffY - (0,floating_ui_utils/* max */.T9)(0, overflow.bottom)));
    scrollEl.style.maxHeight = maxHeight + "px";
    scrollEl.scrollTop = diffY;

    // There is not enough space, fallback to standard anchored positioning
    if (onFallbackChange) {
      const shouldFallback = scrollEl.offsetHeight < item.offsetHeight * (0,floating_ui_utils/* min */.jk)(minItemsVisible, listRef.current.length) - 1 || refOverflow.top >= -referenceOverflowThreshold || refOverflow.bottom >= -referenceOverflowThreshold;
      react_dom.flushSync(() => onFallbackChange(shouldFallback));
    }
    if (overflowRef) {
      overflowRef.current = await (0,floating_ui_dom/* detectOverflow */.__)(getArgsWithCustomFloatingHeight({
        ...nextArgs,
        y: nextY
      }, scrollEl.offsetHeight + clientTop + floating.clientTop), detectOverflowOptions);
    }
    return {
      y: nextY
    };
  }
});
/**
 * Changes the `inner` middleware's `offset` upon a `wheel` event to
 * expand the floating element's height, revealing more list items.
 * @see https://floating-ui.com/docs/inner
 */
function useInnerOffset(context, props) {
  const {
    open,
    elements
  } = context;
  const {
    enabled = true,
    overflowRef,
    scrollRef,
    onChange: unstable_onChange
  } = props;
  const onChange = useEffectEvent(unstable_onChange);
  const controlledScrollingRef = react.useRef(false);
  const prevScrollTopRef = react.useRef(null);
  const initialOverflowRef = react.useRef(null);
  react.useEffect(() => {
    if (!enabled) return;
    function onWheel(e) {
      if (e.ctrlKey || !el || overflowRef.current == null) {
        return;
      }
      const dY = e.deltaY;
      const isAtTop = overflowRef.current.top >= -0.5;
      const isAtBottom = overflowRef.current.bottom >= -0.5;
      const remainingScroll = el.scrollHeight - el.clientHeight;
      const sign = dY < 0 ? -1 : 1;
      const method = dY < 0 ? 'max' : 'min';
      if (el.scrollHeight <= el.clientHeight) {
        return;
      }
      if (!isAtTop && dY > 0 || !isAtBottom && dY < 0) {
        e.preventDefault();
        react_dom.flushSync(() => {
          onChange(d => d + Math[method](dY, remainingScroll * sign));
        });
      } else if (/firefox/i.test(getUserAgent())) {
        // Needed to propagate scrolling during momentum scrolling phase once
        // it gets limited by the boundary. UX improvement, not critical.
        el.scrollTop += dY;
      }
    }
    const el = (scrollRef == null ? void 0 : scrollRef.current) || elements.floating;
    if (open && el) {
      el.addEventListener('wheel', onWheel);

      // Wait for the position to be ready.
      requestAnimationFrame(() => {
        prevScrollTopRef.current = el.scrollTop;
        if (overflowRef.current != null) {
          initialOverflowRef.current = {
            ...overflowRef.current
          };
        }
      });
      return () => {
        prevScrollTopRef.current = null;
        initialOverflowRef.current = null;
        el.removeEventListener('wheel', onWheel);
      };
    }
  }, [enabled, open, elements.floating, overflowRef, scrollRef, onChange]);
  const floating = react.useMemo(() => ({
    onKeyDown() {
      controlledScrollingRef.current = true;
    },
    onWheel() {
      controlledScrollingRef.current = false;
    },
    onPointerMove() {
      controlledScrollingRef.current = false;
    },
    onScroll() {
      const el = (scrollRef == null ? void 0 : scrollRef.current) || elements.floating;
      if (!overflowRef.current || !el || !controlledScrollingRef.current) {
        return;
      }
      if (prevScrollTopRef.current !== null) {
        const scrollDiff = el.scrollTop - prevScrollTopRef.current;
        if (overflowRef.current.bottom < -0.5 && scrollDiff < -1 || overflowRef.current.top < -0.5 && scrollDiff > 1) {
          react_dom.flushSync(() => onChange(d => d + scrollDiff));
        }
      }

      // [Firefox] Wait for the height change to have been applied.
      requestAnimationFrame(() => {
        prevScrollTopRef.current = el.scrollTop;
      });
    }
  }), [elements.floating, onChange, overflowRef, scrollRef]);
  return react.useMemo(() => enabled ? {
    floating
  } : {}, [enabled, floating]);
}

function isPointInPolygon(point, polygon) {
  const [x, y] = point;
  let isInside = false;
  const length = polygon.length;
  for (let i = 0, j = length - 1; i < length; j = i++) {
    const [xi, yi] = polygon[i] || [0, 0];
    const [xj, yj] = polygon[j] || [0, 0];
    const intersect = yi >= y !== yj >= y && x <= (xj - xi) * (y - yi) / (yj - yi) + xi;
    if (intersect) {
      isInside = !isInside;
    }
  }
  return isInside;
}
function isInside(point, rect) {
  return point[0] >= rect.x && point[0] <= rect.x + rect.width && point[1] >= rect.y && point[1] <= rect.y + rect.height;
}
/**
 * Generates a safe polygon area that the user can traverse without closing the
 * floating element once leaving the reference element.
 * @see https://floating-ui.com/docs/useHover#safepolygon
 */
function safePolygon(options) {
  if (options === void 0) {
    options = {};
  }
  const {
    buffer = 0.5,
    blockPointerEvents = false,
    requireIntent = true
  } = options;
  let timeoutId;
  let hasLanded = false;
  let lastX = null;
  let lastY = null;
  let lastCursorTime = performance.now();
  function getCursorSpeed(x, y) {
    const currentTime = performance.now();
    const elapsedTime = currentTime - lastCursorTime;
    if (lastX === null || lastY === null || elapsedTime === 0) {
      lastX = x;
      lastY = y;
      lastCursorTime = currentTime;
      return null;
    }
    const deltaX = x - lastX;
    const deltaY = y - lastY;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const speed = distance / elapsedTime; // px / ms

    lastX = x;
    lastY = y;
    lastCursorTime = currentTime;
    return speed;
  }
  const fn = _ref => {
    let {
      x,
      y,
      placement,
      elements,
      onClose,
      nodeId,
      tree
    } = _ref;
    return function onMouseMove(event) {
      function close() {
        clearTimeout(timeoutId);
        onClose();
      }
      clearTimeout(timeoutId);
      if (!elements.domReference || !elements.floating || placement == null || x == null || y == null) {
        return;
      }
      const {
        clientX,
        clientY
      } = event;
      const clientPoint = [clientX, clientY];
      const target = getTarget(event);
      const isLeave = event.type === 'mouseleave';
      const isOverFloatingEl = contains(elements.floating, target);
      const isOverReferenceEl = contains(elements.domReference, target);
      const refRect = elements.domReference.getBoundingClientRect();
      const rect = elements.floating.getBoundingClientRect();
      const side = placement.split('-')[0];
      const cursorLeaveFromRight = x > rect.right - rect.width / 2;
      const cursorLeaveFromBottom = y > rect.bottom - rect.height / 2;
      const isOverReferenceRect = isInside(clientPoint, refRect);
      const isFloatingWider = rect.width > refRect.width;
      const isFloatingTaller = rect.height > refRect.height;
      const left = (isFloatingWider ? refRect : rect).left;
      const right = (isFloatingWider ? refRect : rect).right;
      const top = (isFloatingTaller ? refRect : rect).top;
      const bottom = (isFloatingTaller ? refRect : rect).bottom;
      if (isOverFloatingEl) {
        hasLanded = true;
        if (!isLeave) {
          return;
        }
      }
      if (isOverReferenceEl) {
        hasLanded = false;
      }
      if (isOverReferenceEl && !isLeave) {
        hasLanded = true;
        return;
      }

      // Prevent overlapping floating element from being stuck in an open-close
      // loop: https://github.com/floating-ui/floating-ui/issues/1910
      if (isLeave && isElement(event.relatedTarget) && contains(elements.floating, event.relatedTarget)) {
        return;
      }

      // If any nested child is open, abort.
      if (tree && getChildren(tree.nodesRef.current, nodeId).some(_ref2 => {
        let {
          context
        } = _ref2;
        return context == null ? void 0 : context.open;
      })) {
        return;
      }

      // If the pointer is leaving from the opposite side, the "buffer" logic
      // creates a point where the floating element remains open, but should be
      // ignored.
      // A constant of 1 handles floating point rounding errors.
      if (side === 'top' && y >= refRect.bottom - 1 || side === 'bottom' && y <= refRect.top + 1 || side === 'left' && x >= refRect.right - 1 || side === 'right' && x <= refRect.left + 1) {
        return close();
      }

      // Ignore when the cursor is within the rectangular trough between the
      // two elements. Since the triangle is created from the cursor point,
      // which can start beyond the ref element's edge, traversing back and
      // forth from the ref to the floating element can cause it to close. This
      // ensures it always remains open in that case.
      let rectPoly = [];
      switch (side) {
        case 'top':
          rectPoly = [[left, refRect.top + 1], [left, rect.bottom - 1], [right, rect.bottom - 1], [right, refRect.top + 1]];
          break;
        case 'bottom':
          rectPoly = [[left, rect.top + 1], [left, refRect.bottom - 1], [right, refRect.bottom - 1], [right, rect.top + 1]];
          break;
        case 'left':
          rectPoly = [[rect.right - 1, bottom], [rect.right - 1, top], [refRect.left + 1, top], [refRect.left + 1, bottom]];
          break;
        case 'right':
          rectPoly = [[refRect.right - 1, bottom], [refRect.right - 1, top], [rect.left + 1, top], [rect.left + 1, bottom]];
          break;
      }
      function getPolygon(_ref3) {
        let [x, y] = _ref3;
        switch (side) {
          case 'top':
            {
              const cursorPointOne = [isFloatingWider ? x + buffer / 2 : cursorLeaveFromRight ? x + buffer * 4 : x - buffer * 4, y + buffer + 1];
              const cursorPointTwo = [isFloatingWider ? x - buffer / 2 : cursorLeaveFromRight ? x + buffer * 4 : x - buffer * 4, y + buffer + 1];
              const commonPoints = [[rect.left, cursorLeaveFromRight ? rect.bottom - buffer : isFloatingWider ? rect.bottom - buffer : rect.top], [rect.right, cursorLeaveFromRight ? isFloatingWider ? rect.bottom - buffer : rect.top : rect.bottom - buffer]];
              return [cursorPointOne, cursorPointTwo, ...commonPoints];
            }
          case 'bottom':
            {
              const cursorPointOne = [isFloatingWider ? x + buffer / 2 : cursorLeaveFromRight ? x + buffer * 4 : x - buffer * 4, y - buffer];
              const cursorPointTwo = [isFloatingWider ? x - buffer / 2 : cursorLeaveFromRight ? x + buffer * 4 : x - buffer * 4, y - buffer];
              const commonPoints = [[rect.left, cursorLeaveFromRight ? rect.top + buffer : isFloatingWider ? rect.top + buffer : rect.bottom], [rect.right, cursorLeaveFromRight ? isFloatingWider ? rect.top + buffer : rect.bottom : rect.top + buffer]];
              return [cursorPointOne, cursorPointTwo, ...commonPoints];
            }
          case 'left':
            {
              const cursorPointOne = [x + buffer + 1, isFloatingTaller ? y + buffer / 2 : cursorLeaveFromBottom ? y + buffer * 4 : y - buffer * 4];
              const cursorPointTwo = [x + buffer + 1, isFloatingTaller ? y - buffer / 2 : cursorLeaveFromBottom ? y + buffer * 4 : y - buffer * 4];
              const commonPoints = [[cursorLeaveFromBottom ? rect.right - buffer : isFloatingTaller ? rect.right - buffer : rect.left, rect.top], [cursorLeaveFromBottom ? isFloatingTaller ? rect.right - buffer : rect.left : rect.right - buffer, rect.bottom]];
              return [...commonPoints, cursorPointOne, cursorPointTwo];
            }
          case 'right':
            {
              const cursorPointOne = [x - buffer, isFloatingTaller ? y + buffer / 2 : cursorLeaveFromBottom ? y + buffer * 4 : y - buffer * 4];
              const cursorPointTwo = [x - buffer, isFloatingTaller ? y - buffer / 2 : cursorLeaveFromBottom ? y + buffer * 4 : y - buffer * 4];
              const commonPoints = [[cursorLeaveFromBottom ? rect.left + buffer : isFloatingTaller ? rect.left + buffer : rect.right, rect.top], [cursorLeaveFromBottom ? isFloatingTaller ? rect.left + buffer : rect.right : rect.left + buffer, rect.bottom]];
              return [cursorPointOne, cursorPointTwo, ...commonPoints];
            }
        }
      }
      if (isPointInPolygon([clientX, clientY], rectPoly)) {
        return;
      }
      if (hasLanded && !isOverReferenceRect) {
        return close();
      }
      if (!isLeave && requireIntent) {
        const cursorSpeed = getCursorSpeed(event.clientX, event.clientY);
        const cursorSpeedThreshold = 0.1;
        if (cursorSpeed !== null && cursorSpeed < cursorSpeedThreshold) {
          return close();
        }
      }
      if (!isPointInPolygon([clientX, clientY], getPolygon([x, y]))) {
        close();
      } else if (!hasLanded && requireIntent) {
        timeoutId = window.setTimeout(close, 40);
      }
    };
  };
  fn.__options = {
    blockPointerEvents
  };
  return fn;
}




/***/ }),

/***/ 86635:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $4: () => (/* binding */ getParentNode),
/* harmony export */   CP: () => (/* binding */ getNodeScroll),
/* harmony export */   L9: () => (/* binding */ getComputedStyle),
/* harmony export */   Lv: () => (/* binding */ isTableElement),
/* harmony export */   Tc: () => (/* binding */ isWebKit),
/* harmony export */   Tf: () => (/* binding */ isTopLayer),
/* harmony export */   ZU: () => (/* binding */ isOverflowElement),
/* harmony export */   _m: () => (/* binding */ getFrameElement),
/* harmony export */   ep: () => (/* binding */ getDocumentElement),
/* harmony export */   eu: () => (/* binding */ isLastTraversableNode),
/* harmony export */   gJ: () => (/* binding */ getContainingBlock),
/* harmony export */   mq: () => (/* binding */ getNodeName),
/* harmony export */   sQ: () => (/* binding */ isContainingBlock),
/* harmony export */   sb: () => (/* binding */ isHTMLElement),
/* harmony export */   v9: () => (/* binding */ getOverflowAncestors),
/* harmony export */   vq: () => (/* binding */ isElement),
/* harmony export */   zk: () => (/* binding */ getWindow)
/* harmony export */ });
/* unused harmony exports getNearestOverflowAncestor, isNode, isShadowRoot */
function hasWindow() {
  return typeof window !== 'undefined';
}
function getNodeName(node) {
  if (isNode(node)) {
    return (node.nodeName || '').toLowerCase();
  }
  // Mocked nodes in testing environments may not be instances of Node. By
  // returning `#document` an infinite loop won't occur.
  // https://github.com/floating-ui/floating-ui/issues/2317
  return '#document';
}
function getWindow(node) {
  var _node$ownerDocument;
  return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
  var _ref;
  return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
  if (!hasWindow()) {
    return false;
  }
  return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
  if (!hasWindow() || typeof ShadowRoot === 'undefined') {
    return false;
  }
  return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
const invalidOverflowDisplayValues = /*#__PURE__*/new Set(['inline', 'contents']);
function isOverflowElement(element) {
  const {
    overflow,
    overflowX,
    overflowY,
    display
  } = getComputedStyle(element);
  return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && !invalidOverflowDisplayValues.has(display);
}
const tableElements = /*#__PURE__*/new Set(['table', 'td', 'th']);
function isTableElement(element) {
  return tableElements.has(getNodeName(element));
}
const topLayerSelectors = [':popover-open', ':modal'];
function isTopLayer(element) {
  return topLayerSelectors.some(selector => {
    try {
      return element.matches(selector);
    } catch (_e) {
      return false;
    }
  });
}
const transformProperties = ['transform', 'translate', 'scale', 'rotate', 'perspective'];
const willChangeValues = ['transform', 'translate', 'scale', 'rotate', 'perspective', 'filter'];
const containValues = ['paint', 'layout', 'strict', 'content'];
function isContainingBlock(elementOrCss) {
  const webkit = isWebKit();
  const css = isElement(elementOrCss) ? getComputedStyle(elementOrCss) : elementOrCss;

  // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
  // https://drafts.csswg.org/css-transforms-2/#individual-transforms
  return transformProperties.some(value => css[value] ? css[value] !== 'none' : false) || (css.containerType ? css.containerType !== 'normal' : false) || !webkit && (css.backdropFilter ? css.backdropFilter !== 'none' : false) || !webkit && (css.filter ? css.filter !== 'none' : false) || willChangeValues.some(value => (css.willChange || '').includes(value)) || containValues.some(value => (css.contain || '').includes(value));
}
function getContainingBlock(element) {
  let currentNode = getParentNode(element);
  while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
    if (isContainingBlock(currentNode)) {
      return currentNode;
    } else if (isTopLayer(currentNode)) {
      return null;
    }
    currentNode = getParentNode(currentNode);
  }
  return null;
}
function isWebKit() {
  if (typeof CSS === 'undefined' || !CSS.supports) return false;
  return CSS.supports('-webkit-backdrop-filter', 'none');
}
const lastTraversableNodeNames = /*#__PURE__*/new Set(['html', 'body', '#document']);
function isLastTraversableNode(node) {
  return lastTraversableNodeNames.has(getNodeName(node));
}
function getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
  if (isElement(element)) {
    return {
      scrollLeft: element.scrollLeft,
      scrollTop: element.scrollTop
    };
  }
  return {
    scrollLeft: element.scrollX,
    scrollTop: element.scrollY
  };
}
function getParentNode(node) {
  if (getNodeName(node) === 'html') {
    return node;
  }
  const result =
  // Step into the shadow DOM of the parent of a slotted node.
  node.assignedSlot ||
  // DOM Element detected.
  node.parentNode ||
  // ShadowRoot detected.
  isShadowRoot(node) && node.host ||
  // Fallback.
  getDocumentElement(node);
  return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
  const parentNode = getParentNode(node);
  if (isLastTraversableNode(parentNode)) {
    return node.ownerDocument ? node.ownerDocument.body : node.body;
  }
  if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
    return parentNode;
  }
  return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
  var _node$ownerDocument2;
  if (list === void 0) {
    list = [];
  }
  if (traverseIframes === void 0) {
    traverseIframes = true;
  }
  const scrollableAncestor = getNearestOverflowAncestor(node);
  const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
  const win = getWindow(scrollableAncestor);
  if (isBody) {
    const frameElement = getFrameElement(win);
    return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
  }
  return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
  return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}




/***/ }),

/***/ 97193:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B1: () => (/* binding */ rectToClientRect),
/* harmony export */   C0: () => (/* binding */ getSide),
/* harmony export */   Dz: () => (/* binding */ getAlignmentAxis),
/* harmony export */   Jx: () => (/* binding */ createCoords),
/* harmony export */   LI: () => (/* binding */ round),
/* harmony export */   PG: () => (/* binding */ getOppositeAxis),
/* harmony export */   RI: () => (/* binding */ floor),
/* harmony export */   Sg: () => (/* binding */ getAlignment),
/* harmony export */   T9: () => (/* binding */ max),
/* harmony export */   TV: () => (/* binding */ getSideAxis),
/* harmony export */   WJ: () => (/* binding */ getExpandedPlacements),
/* harmony export */   _3: () => (/* binding */ evaluate),
/* harmony export */   bV: () => (/* binding */ getOppositePlacement),
/* harmony export */   jk: () => (/* binding */ min),
/* harmony export */   lP: () => (/* binding */ getOppositeAxisPlacements),
/* harmony export */   nI: () => (/* binding */ getPaddingObject),
/* harmony export */   qE: () => (/* binding */ clamp),
/* harmony export */   sq: () => (/* binding */ getAxisLength),
/* harmony export */   w7: () => (/* binding */ getAlignmentSides)
/* harmony export */ });
/* unused harmony exports alignments, expandPaddingObject, getOppositeAlignmentPlacement, placements, sides */
/**
 * Custom positioning reference element.
 * @see https://floating-ui.com/docs/virtual-elements
 */

const sides = (/* unused pure expression or super */ null && (['top', 'right', 'bottom', 'left']));
const alignments = (/* unused pure expression or super */ null && (['start', 'end']));
const placements = /*#__PURE__*/(/* unused pure expression or super */ null && (sides.reduce((acc, side) => acc.concat(side, side + "-" + alignments[0], side + "-" + alignments[1]), [])));
const min = Math.min;
const max = Math.max;
const round = Math.round;
const floor = Math.floor;
const createCoords = v => ({
  x: v,
  y: v
});
const oppositeSideMap = {
  left: 'right',
  right: 'left',
  bottom: 'top',
  top: 'bottom'
};
const oppositeAlignmentMap = {
  start: 'end',
  end: 'start'
};
function clamp(start, value, end) {
  return max(start, min(value, end));
}
function evaluate(value, param) {
  return typeof value === 'function' ? value(param) : value;
}
function getSide(placement) {
  return placement.split('-')[0];
}
function getAlignment(placement) {
  return placement.split('-')[1];
}
function getOppositeAxis(axis) {
  return axis === 'x' ? 'y' : 'x';
}
function getAxisLength(axis) {
  return axis === 'y' ? 'height' : 'width';
}
const yAxisSides = /*#__PURE__*/new Set(['top', 'bottom']);
function getSideAxis(placement) {
  return yAxisSides.has(getSide(placement)) ? 'y' : 'x';
}
function getAlignmentAxis(placement) {
  return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
  if (rtl === void 0) {
    rtl = false;
  }
  const alignment = getAlignment(placement);
  const alignmentAxis = getAlignmentAxis(placement);
  const length = getAxisLength(alignmentAxis);
  let mainAlignmentSide = alignmentAxis === 'x' ? alignment === (rtl ? 'end' : 'start') ? 'right' : 'left' : alignment === 'start' ? 'bottom' : 'top';
  if (rects.reference[length] > rects.floating[length]) {
    mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
  }
  return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
  const oppositePlacement = getOppositePlacement(placement);
  return [getOppositeAlignmentPlacement(placement), oppositePlacement, getOppositeAlignmentPlacement(oppositePlacement)];
}
function getOppositeAlignmentPlacement(placement) {
  return placement.replace(/start|end/g, alignment => oppositeAlignmentMap[alignment]);
}
const lrPlacement = ['left', 'right'];
const rlPlacement = ['right', 'left'];
const tbPlacement = ['top', 'bottom'];
const btPlacement = ['bottom', 'top'];
function getSideList(side, isStart, rtl) {
  switch (side) {
    case 'top':
    case 'bottom':
      if (rtl) return isStart ? rlPlacement : lrPlacement;
      return isStart ? lrPlacement : rlPlacement;
    case 'left':
    case 'right':
      return isStart ? tbPlacement : btPlacement;
    default:
      return [];
  }
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
  const alignment = getAlignment(placement);
  let list = getSideList(getSide(placement), direction === 'start', rtl);
  if (alignment) {
    list = list.map(side => side + "-" + alignment);
    if (flipAlignment) {
      list = list.concat(list.map(getOppositeAlignmentPlacement));
    }
  }
  return list;
}
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, side => oppositeSideMap[side]);
}
function expandPaddingObject(padding) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...padding
  };
}
function getPaddingObject(padding) {
  return typeof padding !== 'number' ? expandPaddingObject(padding) : {
    top: padding,
    right: padding,
    bottom: padding,
    left: padding
  };
}
function rectToClientRect(rect) {
  const {
    x,
    y,
    width,
    height
  } = rect;
  return {
    width,
    height,
    top: y,
    left: x,
    right: x + width,
    bottom: y + height,
    x,
    y
  };
}




/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi03N2ZmMGJhYy5mMmZkMWVmYTc1NWVkYWI3MGMzNi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXFFOztBQUVyRSxTQUFTLHFDQUFhO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxnQ0FBUTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxtQ0FBVztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLHNDQUFjO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyw2Q0FBcUI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsZ0NBQVE7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixtQ0FBVztBQUM1QjtBQUNBLFNBQVMsNkJBQUs7QUFDZCxTQUFTLG1DQUFXO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyw4Q0FBc0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsb0NBQVk7QUFDckI7QUFDQTtBQUNBLFNBQVMscUNBQWE7QUFDdEI7QUFDQTtBQUNBLFNBQVMsbUNBQVc7QUFDcEI7QUFDQTtBQUNBLFNBQVMsMkNBQW1CO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsaUNBQVM7QUFDbEI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLDJLQUEySDtBQUNySixTQUFTLHlDQUFpQjtBQUMxQjtBQUNBO0FBQ0EsU0FBUyxpQ0FBUztBQUNsQjtBQUNBO0FBQ0E7QUFDQSxTQUFTLDBDQUFrQjtBQUMzQjtBQUNBLHdEQUF3RCx5Q0FBaUI7QUFDekU7O0FBRWlUOzs7Ozs7Ozs7OztBQzlJcEU7QUFDOUg7QUFDaEY7QUFDUztBQUNGOztBQUV0Qzs7QUFFQTtBQUNBLHVCQUF1QixxQkFBZTs7QUFFdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsVUFBVTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLFVBQVU7QUFDL0IsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixVQUFVO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGNBQWMsWUFBWTtBQUMxQjtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLElBQUk7QUFDVjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osMEJBQTBCLGNBQWM7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQSxHQUFHO0FBQ0gsa0RBQWtELGNBQWM7QUFDaEU7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLGNBQWM7QUFDcEQsb0NBQW9DLGNBQWM7QUFDbEQsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxzQkFBc0IsaUJBQWlCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSx1QkFBdUIsWUFBWTtBQUNuQyxzQkFBc0IsWUFBWTtBQUNsQyxrQkFBa0IsWUFBWTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixpQkFBaUI7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksMkNBQWU7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLG1CQUFrQjtBQUMxQjtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNILHVCQUF1QixZQUFZO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILGVBQWUsYUFBYTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxtQkFBbUIsYUFBYTtBQUNoQztBQUNBO0FBQ0EsR0FBRztBQUNILHlCQUF5QixhQUFhO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILFNBQVMsYUFBYTtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssa0NBQVE7QUFDYjtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxpQ0FBTztBQUNaO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxnQ0FBTTtBQUNYO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssZ0NBQU07QUFDWDtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVpRzs7O0FDbFhuRTtBQUM0QjtBQUMrTztBQUNwTztBQUNzRjtBQUM1RztBQUNWO0FBQzhFO0FBQzRFOztBQUVoTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBLEtBQUsscUJBQUs7QUFDVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLFlBQVk7QUFDMUIsUUFBUSxJQUFxQztBQUM3QztBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsU0FBUyxpQkFBaUI7QUFDMUIsd0VBQXdFLGFBQWE7QUFDckY7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksd0JBQXdCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLFVBQVUsSUFBcUM7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLFdBQVc7QUFDakMsd0JBQXdCLFlBQVk7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBSSx1QkFBSyxxQ0FBcUMscUJBQWUsR0FBRyxlQUFTOztBQUV6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsbUJBQW1CO0FBQzVELG9CQUFvQjtBQUNwQixzQkFBc0I7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsbUJBQW1CO0FBQ3pEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0gsQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DO0FBQ25DO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQSxvQkFBb0Isc0JBQXNCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGNBQWM7QUFDcEMsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsZUFBZTtBQUNqQjtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxJQUFJLElBQXFDO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEVBQTBFLGFBQWE7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZFQUE2RSxlQUFlO0FBQzVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxJQUFJO0FBQ1Y7QUFDQSxJQUFJO0FBQ0osTUFBTSxJQUFxQztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEseUNBQXlDLG1CQUFtQjtBQUM1RCx5Q0FBeUMsbUJBQW1COztBQUU1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsZ0JBQWdCO0FBQy9DOztBQUVBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixnQkFBZ0I7O0FBRTlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTLDhCQUFZO0FBQ3JCO0FBQ0EsRUFBRSx1QkFBSztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUEsMkNBQTJDLCtFQUErQjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLHlCQUF5Qiw4QkFBWTtBQUNyQyxtQkFBbUIsOEJBQVk7QUFDL0Isa0JBQWtCLDhCQUFZO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtEQUFrRDtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsSUFBSSxJQUFJO0FBQ1I7O0FBRUE7QUFDQSwrQ0FBK0MsbUJBQW1CO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0M7QUFDaEM7QUFDQSxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RDtBQUM3RCxDQUFDLENBQUM7O0FBRUYsbUNBQW1DLHlFQUF5QjtBQUM1RCwwQkFBMEIseUVBQXlCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNILEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0Msc0JBQXNCO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxnQ0FBZ0Msa0RBQUU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDO0FBQzNDLCtEQUErRDtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLENBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsbUJBQW1CLDhCQUFZO0FBQy9CLDBCQUEwQiw4QkFBWTtBQUN0Qyx5QkFBeUIsOEJBQVk7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTOztBQUVUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0gsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSDtBQUNBLGlFQUFpRTtBQUNqRTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRzs7QUFFSDtBQUNBO0FBQ0EsRUFBRSx1QkFBSztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsSUFBSSxJQUFJO0FBQ1I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0Esa0JBQWtCLFlBQVksR0FBRztBQUNqQyxtQkFBbUIsY0FBYztBQUNqQztBQUNBLE1BQU0sSUFBcUM7QUFDM0M7QUFDQSwrQkFBK0IsMkNBQVM7QUFDeEM7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELGNBQWM7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxHQUFHO0FBQ0gsZUFBZSxhQUFhO0FBQzVCO0FBQ0EsR0FBRztBQUNILG1CQUFtQixhQUFhO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxTQUFTLGFBQWE7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLDZCQUFXO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLDJDQUEyQyxjQUFjO0FBQ3pELHFEQUFxRCxjQUFjO0FBQ25FO0FBQ0E7QUFDQSwwQkFBMEIsWUFBWTtBQUN0QztBQUNBLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsbUJBQW1CLFdBQWE7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSCwrQkFBK0IsaUJBQWlCO0FBQ2hELHNDQUFzQywyQ0FBUztBQUMvQztBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILHVCQUF1QixpQkFBaUI7QUFDeEMsUUFBUSwyQ0FBUztBQUNqQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFFBQVEsMkNBQVM7QUFDakI7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLDJDQUFTO0FBQy9CO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsZUFBZSxhQUFhO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILG1CQUFtQixhQUFhO0FBQ2hDO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsa0JBQWtCLGFBQWE7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxTQUFTLGFBQWE7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0ZBQWtGLGFBQWE7QUFDL0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsS0FBSyxJQUFJO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLGlCQUFpQjtBQUM3QztBQUNBO0FBQ0EsMkJBQTJCLGlCQUFpQjtBQUM1QztBQUNBO0FBQ0EsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBO0FBQ0EsU0FBUyxhQUFhO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QztBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLE1BQU0sSUFBcUM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsOEJBQVk7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsOEJBQVk7QUFDekMsd0JBQXdCLDhCQUFZO0FBQ3BDLGdDQUFnQyw4QkFBWTtBQUM1QywyQkFBMkIsOEJBQVk7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHOztBQUVIO0FBQ0E7QUFDQSxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQSxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVCQUFLO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsdUJBQUs7QUFDUDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxJQUFJO0FBQ1I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSxHQUFHO0FBQ0gscUJBQXFCLDhCQUFZO0FBQ2pDLGtCQUFrQiw4QkFBWTtBQUM5QixtQkFBbUIsOEJBQVk7QUFDL0Isb0JBQW9CLDhCQUFZO0FBQ2hDLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLElBQUk7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsOEJBQVk7QUFDbkMsd0JBQXdCLDhCQUFZO0FBQ3BDLEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsdUJBQUs7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLOztBQUVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sRUFBRSxzQ0FBUTtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsdUJBQXVCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLElBQXFDO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixNQUFNO0FBQ3RCO0FBQ0EsMkJBQTJCLDBDQUFjO0FBQ3pDLDhCQUE4QiwwQ0FBYztBQUM1QztBQUNBO0FBQ0EsS0FBSztBQUNMLGtCQUFrQixpQ0FBRztBQUNyQjtBQUNBO0FBQ0EsNENBQTRDLCtCQUFLO0FBQ2pELDhCQUE4QixpQ0FBRywySEFBMkgsaUNBQUc7QUFDL0o7QUFDQTs7QUFFQTtBQUNBO0FBQ0EseUVBQXlFLGlDQUFHO0FBQzVFLE1BQU0sbUJBQWtCO0FBQ3hCO0FBQ0E7QUFDQSxrQ0FBa0MsMENBQWM7QUFDaEQ7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsaUNBQWlDLFlBQVk7QUFDN0MsMkJBQTJCLFlBQVk7QUFDdkMsNkJBQTZCLFlBQVk7QUFDekMsRUFBRSxlQUFlO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxtQkFBa0I7QUFDMUI7QUFDQSxTQUFTO0FBQ1QsUUFBUSx5QkFBeUIsWUFBWTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILG1CQUFtQixhQUFhO0FBQ2hDO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLG1CQUFrQjtBQUM1QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSCxTQUFTLGFBQWE7QUFDdEI7QUFDQSxJQUFJLElBQUk7QUFDUjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxZQUFZO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEM7O0FBRTFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0EsT0FBTztBQUNQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRTJpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlnSjNpQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVnVjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEtoVjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxjQUFjLGtGQUFrQztBQUNoRCxtQkFBbUIsZ0VBQWdCO0FBQ25DLGdDQUFnQyx5SkFBeUc7QUFDekk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFeVciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9AZmxvYXRpbmctdWkvcmVhY3QvZGlzdC9mbG9hdGluZy11aS5yZWFjdC51dGlscy5tanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGZsb2F0aW5nLXVpL3JlYWN0LWRvbS9kaXN0L2Zsb2F0aW5nLXVpLnJlYWN0LWRvbS5tanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGZsb2F0aW5nLXVpL3JlYWN0L2Rpc3QvZmxvYXRpbmctdWkucmVhY3QubWpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL0BmbG9hdGluZy11aS91dGlscy9kaXN0L2Zsb2F0aW5nLXVpLnV0aWxzLmRvbS5tanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGZsb2F0aW5nLXVpL3V0aWxzL2Rpc3QvZmxvYXRpbmctdWkudXRpbHMubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzU2hhZG93Um9vdCwgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuXG5mdW5jdGlvbiBhY3RpdmVFbGVtZW50KGRvYykge1xuICBsZXQgYWN0aXZlRWxlbWVudCA9IGRvYy5hY3RpdmVFbGVtZW50O1xuICB3aGlsZSAoKChfYWN0aXZlRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQpID09IG51bGwgfHwgKF9hY3RpdmVFbGVtZW50ID0gX2FjdGl2ZUVsZW1lbnQuc2hhZG93Um9vdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hY3RpdmVFbGVtZW50LmFjdGl2ZUVsZW1lbnQpICE9IG51bGwpIHtcbiAgICB2YXIgX2FjdGl2ZUVsZW1lbnQ7XG4gICAgYWN0aXZlRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQuc2hhZG93Um9vdC5hY3RpdmVFbGVtZW50O1xuICB9XG4gIHJldHVybiBhY3RpdmVFbGVtZW50O1xufVxuZnVuY3Rpb24gY29udGFpbnMocGFyZW50LCBjaGlsZCkge1xuICBpZiAoIXBhcmVudCB8fCAhY2hpbGQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3Qgcm9vdE5vZGUgPSBjaGlsZC5nZXRSb290Tm9kZSA9PSBudWxsID8gdm9pZCAwIDogY2hpbGQuZ2V0Um9vdE5vZGUoKTtcblxuICAvLyBGaXJzdCwgYXR0ZW1wdCB3aXRoIGZhc3RlciBuYXRpdmUgbWV0aG9kXG4gIGlmIChwYXJlbnQuY29udGFpbnMoY2hpbGQpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICAvLyB0aGVuIGZhbGxiYWNrIHRvIGN1c3RvbSBpbXBsZW1lbnRhdGlvbiB3aXRoIFNoYWRvdyBET00gc3VwcG9ydFxuICBpZiAocm9vdE5vZGUgJiYgaXNTaGFkb3dSb290KHJvb3ROb2RlKSkge1xuICAgIGxldCBuZXh0ID0gY2hpbGQ7XG4gICAgd2hpbGUgKG5leHQpIHtcbiAgICAgIGlmIChwYXJlbnQgPT09IG5leHQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBuZXh0ID0gbmV4dC5wYXJlbnROb2RlIHx8IG5leHQuaG9zdDtcbiAgICB9XG4gIH1cblxuICAvLyBHaXZlIHVwLCB0aGUgcmVzdWx0IGlzIGZhbHNlXG4gIHJldHVybiBmYWxzZTtcbn1cbi8vIEF2b2lkIENocm9tZSBEZXZUb29scyBibHVlIHdhcm5pbmcuXG5mdW5jdGlvbiBnZXRQbGF0Zm9ybSgpIHtcbiAgY29uc3QgdWFEYXRhID0gbmF2aWdhdG9yLnVzZXJBZ2VudERhdGE7XG4gIGlmICh1YURhdGEgIT0gbnVsbCAmJiB1YURhdGEucGxhdGZvcm0pIHtcbiAgICByZXR1cm4gdWFEYXRhLnBsYXRmb3JtO1xuICB9XG4gIHJldHVybiBuYXZpZ2F0b3IucGxhdGZvcm07XG59XG5mdW5jdGlvbiBnZXRVc2VyQWdlbnQoKSB7XG4gIGNvbnN0IHVhRGF0YSA9IG5hdmlnYXRvci51c2VyQWdlbnREYXRhO1xuICBpZiAodWFEYXRhICYmIEFycmF5LmlzQXJyYXkodWFEYXRhLmJyYW5kcykpIHtcbiAgICByZXR1cm4gdWFEYXRhLmJyYW5kcy5tYXAoX3JlZiA9PiB7XG4gICAgICBsZXQge1xuICAgICAgICBicmFuZCxcbiAgICAgICAgdmVyc2lvblxuICAgICAgfSA9IF9yZWY7XG4gICAgICByZXR1cm4gYnJhbmQgKyBcIi9cIiArIHZlcnNpb247XG4gICAgfSkuam9pbignICcpO1xuICB9XG4gIHJldHVybiBuYXZpZ2F0b3IudXNlckFnZW50O1xufVxuXG4vLyBMaWNlbnNlOiBodHRwczovL2dpdGh1Yi5jb20vYWRvYmUvcmVhY3Qtc3BlY3RydW0vYmxvYi9iMzVkNWMwMmZlOTAwYmFkY2NkMGNmMWE4ZjIzYmI1OTM0MTlmMjM4L3BhY2thZ2VzL0ByZWFjdC1hcmlhL3V0aWxzL3NyYy9pc1ZpcnR1YWxFdmVudC50c1xuZnVuY3Rpb24gaXNWaXJ0dWFsQ2xpY2soZXZlbnQpIHtcbiAgLy8gRklYTUU6IEZpcmVmb3ggaXMgbm93IGVtaXR0aW5nIGEgZGVwcmVjYXRpb24gd2FybmluZyBmb3IgYG1veklucHV0U291cmNlYC5cbiAgLy8gVHJ5IHRvIGZpbmQgYSB3b3JrYXJvdW5kIGZvciB0aGlzLiBgcmVhY3QtYXJpYWAgc291cmNlIHN0aWxsIGhhcyB0aGUgY2hlY2suXG4gIGlmIChldmVudC5tb3pJbnB1dFNvdXJjZSA9PT0gMCAmJiBldmVudC5pc1RydXN0ZWQpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNBbmRyb2lkKCkgJiYgZXZlbnQucG9pbnRlclR5cGUpIHtcbiAgICByZXR1cm4gZXZlbnQudHlwZSA9PT0gJ2NsaWNrJyAmJiBldmVudC5idXR0b25zID09PSAxO1xuICB9XG4gIHJldHVybiBldmVudC5kZXRhaWwgPT09IDAgJiYgIWV2ZW50LnBvaW50ZXJUeXBlO1xufVxuZnVuY3Rpb24gaXNWaXJ0dWFsUG9pbnRlckV2ZW50KGV2ZW50KSB7XG4gIGlmIChpc0pTRE9NKCkpIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuICFpc0FuZHJvaWQoKSAmJiBldmVudC53aWR0aCA9PT0gMCAmJiBldmVudC5oZWlnaHQgPT09IDAgfHwgaXNBbmRyb2lkKCkgJiYgZXZlbnQud2lkdGggPT09IDEgJiYgZXZlbnQuaGVpZ2h0ID09PSAxICYmIGV2ZW50LnByZXNzdXJlID09PSAwICYmIGV2ZW50LmRldGFpbCA9PT0gMCAmJiBldmVudC5wb2ludGVyVHlwZSA9PT0gJ21vdXNlJyB8fFxuICAvLyBpT1MgVm9pY2VPdmVyIHJldHVybnMgMC4zMzPigKIgZm9yIHdpZHRoL2hlaWdodC5cbiAgZXZlbnQud2lkdGggPCAxICYmIGV2ZW50LmhlaWdodCA8IDEgJiYgZXZlbnQucHJlc3N1cmUgPT09IDAgJiYgZXZlbnQuZGV0YWlsID09PSAwICYmIGV2ZW50LnBvaW50ZXJUeXBlID09PSAndG91Y2gnO1xufVxuZnVuY3Rpb24gaXNTYWZhcmkoKSB7XG4gIC8vIENocm9tZSBEZXZUb29scyBkb2VzIG5vdCBjb21wbGFpbiBhYm91dCBuYXZpZ2F0b3IudmVuZG9yXG4gIHJldHVybiAvYXBwbGUvaS50ZXN0KG5hdmlnYXRvci52ZW5kb3IpO1xufVxuZnVuY3Rpb24gaXNBbmRyb2lkKCkge1xuICBjb25zdCByZSA9IC9hbmRyb2lkL2k7XG4gIHJldHVybiByZS50ZXN0KGdldFBsYXRmb3JtKCkpIHx8IHJlLnRlc3QoZ2V0VXNlckFnZW50KCkpO1xufVxuZnVuY3Rpb24gaXNNYWMoKSB7XG4gIHJldHVybiBnZXRQbGF0Zm9ybSgpLnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aCgnbWFjJykgJiYgIW5hdmlnYXRvci5tYXhUb3VjaFBvaW50cztcbn1cbmZ1bmN0aW9uIGlzSlNET00oKSB7XG4gIHJldHVybiBnZXRVc2VyQWdlbnQoKS5pbmNsdWRlcygnanNkb20vJyk7XG59XG5mdW5jdGlvbiBpc01vdXNlTGlrZVBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlLCBzdHJpY3QpIHtcbiAgLy8gT24gc29tZSBMaW51eCBtYWNoaW5lcyB3aXRoIENocm9taXVtLCBtb3VzZSBpbnB1dHMgcmV0dXJuIGEgYHBvaW50ZXJUeXBlYFxuICAvLyBvZiBcInBlblwiOiBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzIwMTVcbiAgY29uc3QgdmFsdWVzID0gWydtb3VzZScsICdwZW4nXTtcbiAgaWYgKCFzdHJpY3QpIHtcbiAgICB2YWx1ZXMucHVzaCgnJywgdW5kZWZpbmVkKTtcbiAgfVxuICByZXR1cm4gdmFsdWVzLmluY2x1ZGVzKHBvaW50ZXJUeXBlKTtcbn1cbmZ1bmN0aW9uIGlzUmVhY3RFdmVudChldmVudCkge1xuICByZXR1cm4gJ25hdGl2ZUV2ZW50JyBpbiBldmVudDtcbn1cbmZ1bmN0aW9uIGlzUm9vdEVsZW1lbnQoZWxlbWVudCkge1xuICByZXR1cm4gZWxlbWVudC5tYXRjaGVzKCdodG1sLGJvZHknKTtcbn1cbmZ1bmN0aW9uIGdldERvY3VtZW50KG5vZGUpIHtcbiAgcmV0dXJuIChub2RlID09IG51bGwgPyB2b2lkIDAgOiBub2RlLm93bmVyRG9jdW1lbnQpIHx8IGRvY3VtZW50O1xufVxuZnVuY3Rpb24gaXNFdmVudFRhcmdldFdpdGhpbihldmVudCwgbm9kZSkge1xuICBpZiAobm9kZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICgnY29tcG9zZWRQYXRoJyBpbiBldmVudCkge1xuICAgIHJldHVybiBldmVudC5jb21wb3NlZFBhdGgoKS5pbmNsdWRlcyhub2RlKTtcbiAgfVxuXG4gIC8vIFRTIHRoaW5rcyBgZXZlbnRgIGlzIG9mIHR5cGUgbmV2ZXIgYXMgaXQgYXNzdW1lcyBhbGwgYnJvd3NlcnMgc3VwcG9ydCBjb21wb3NlZFBhdGgsIGJ1dCBicm93c2VycyB3aXRob3V0IHNoYWRvdyBkb20gZG9uJ3RcbiAgY29uc3QgZSA9IGV2ZW50O1xuICByZXR1cm4gZS50YXJnZXQgIT0gbnVsbCAmJiBub2RlLmNvbnRhaW5zKGUudGFyZ2V0KTtcbn1cbmZ1bmN0aW9uIGdldFRhcmdldChldmVudCkge1xuICBpZiAoJ2NvbXBvc2VkUGF0aCcgaW4gZXZlbnQpIHtcbiAgICByZXR1cm4gZXZlbnQuY29tcG9zZWRQYXRoKClbMF07XG4gIH1cblxuICAvLyBUUyB0aGlua3MgYGV2ZW50YCBpcyBvZiB0eXBlIG5ldmVyIGFzIGl0IGFzc3VtZXMgYWxsIGJyb3dzZXJzIHN1cHBvcnRcbiAgLy8gYGNvbXBvc2VkUGF0aCgpYCwgYnV0IGJyb3dzZXJzIHdpdGhvdXQgc2hhZG93IERPTSBkb24ndC5cbiAgcmV0dXJuIGV2ZW50LnRhcmdldDtcbn1cbmNvbnN0IFRZUEVBQkxFX1NFTEVDVE9SID0gXCJpbnB1dDpub3QoW3R5cGU9J2hpZGRlbiddKTpub3QoW2Rpc2FibGVkXSksXCIgKyBcIltjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPSdmYWxzZSddKSx0ZXh0YXJlYTpub3QoW2Rpc2FibGVkXSlcIjtcbmZ1bmN0aW9uIGlzVHlwZWFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzSFRNTEVsZW1lbnQoZWxlbWVudCkgJiYgZWxlbWVudC5tYXRjaGVzKFRZUEVBQkxFX1NFTEVDVE9SKTtcbn1cbmZ1bmN0aW9uIHN0b3BFdmVudChldmVudCkge1xuICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbn1cbmZ1bmN0aW9uIGlzVHlwZWFibGVDb21ib2JveChlbGVtZW50KSB7XG4gIGlmICghZWxlbWVudCkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gZWxlbWVudC5nZXRBdHRyaWJ1dGUoJ3JvbGUnKSA9PT0gJ2NvbWJvYm94JyAmJiBpc1R5cGVhYmxlRWxlbWVudChlbGVtZW50KTtcbn1cblxuZXhwb3J0IHsgVFlQRUFCTEVfU0VMRUNUT1IsIGFjdGl2ZUVsZW1lbnQsIGNvbnRhaW5zLCBnZXREb2N1bWVudCwgZ2V0UGxhdGZvcm0sIGdldFRhcmdldCwgZ2V0VXNlckFnZW50LCBpc0FuZHJvaWQsIGlzRXZlbnRUYXJnZXRXaXRoaW4sIGlzSlNET00sIGlzTWFjLCBpc01vdXNlTGlrZVBvaW50ZXJUeXBlLCBpc1JlYWN0RXZlbnQsIGlzUm9vdEVsZW1lbnQsIGlzU2FmYXJpLCBpc1R5cGVhYmxlQ29tYm9ib3gsIGlzVHlwZWFibGVFbGVtZW50LCBpc1ZpcnR1YWxDbGljaywgaXNWaXJ0dWFsUG9pbnRlckV2ZW50LCBzdG9wRXZlbnQgfTtcbiIsImltcG9ydCB7IGNvbXB1dGVQb3NpdGlvbiwgYXJyb3cgYXMgYXJyb3ckMiwgYXV0b1BsYWNlbWVudCBhcyBhdXRvUGxhY2VtZW50JDEsIGZsaXAgYXMgZmxpcCQxLCBoaWRlIGFzIGhpZGUkMSwgaW5saW5lIGFzIGlubGluZSQxLCBsaW1pdFNoaWZ0IGFzIGxpbWl0U2hpZnQkMSwgb2Zmc2V0IGFzIG9mZnNldCQxLCBzaGlmdCBhcyBzaGlmdCQxLCBzaXplIGFzIHNpemUkMSB9IGZyb20gJ0BmbG9hdGluZy11aS9kb20nO1xuZXhwb3J0IHsgYXV0b1VwZGF0ZSwgY29tcHV0ZVBvc2l0aW9uLCBkZXRlY3RPdmVyZmxvdywgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIHBsYXRmb3JtIH0gZnJvbSAnQGZsb2F0aW5nLXVpL2RvbSc7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgKiBhcyBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuXG52YXIgaXNDbGllbnQgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG52YXIgbm9vcCA9IGZ1bmN0aW9uIG5vb3AoKSB7fTtcbnZhciBpbmRleCA9IGlzQ2xpZW50ID8gdXNlTGF5b3V0RWZmZWN0IDogbm9vcDtcblxuLy8gRm9yayBvZiBgZmFzdC1kZWVwLWVxdWFsYCB0aGF0IG9ubHkgZG9lcyB0aGUgY29tcGFyaXNvbnMgd2UgbmVlZCBhbmQgY29tcGFyZXNcbi8vIGZ1bmN0aW9uc1xuZnVuY3Rpb24gZGVlcEVxdWFsKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh0eXBlb2YgYSA9PT0gJ2Z1bmN0aW9uJyAmJiBhLnRvU3RyaW5nKCkgPT09IGIudG9TdHJpbmcoKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGxldCBsZW5ndGg7XG4gIGxldCBpO1xuICBsZXQga2V5cztcbiAgaWYgKGEgJiYgYiAmJiB0eXBlb2YgYSA9PT0gJ29iamVjdCcpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShhKSkge1xuICAgICAgbGVuZ3RoID0gYS5sZW5ndGg7XG4gICAgICBpZiAobGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuICAgICAgZm9yIChpID0gbGVuZ3RoOyBpLS0gIT09IDA7KSB7XG4gICAgICAgIGlmICghZGVlcEVxdWFsKGFbaV0sIGJbaV0pKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAga2V5cyA9IE9iamVjdC5rZXlzKGEpO1xuICAgIGxlbmd0aCA9IGtleXMubGVuZ3RoO1xuICAgIGlmIChsZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBmb3IgKGkgPSBsZW5ndGg7IGktLSAhPT0gMDspIHtcbiAgICAgIGlmICghe30uaGFzT3duUHJvcGVydHkuY2FsbChiLCBrZXlzW2ldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoaSA9IGxlbmd0aDsgaS0tICE9PSAwOykge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGlmIChrZXkgPT09ICdfb3duZXInICYmIGEuJCR0eXBlb2YpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoIWRlZXBFcXVhbChhW2tleV0sIGJba2V5XSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gYSAhPT0gYSAmJiBiICE9PSBiO1xufVxuXG5mdW5jdGlvbiBnZXREUFIoZWxlbWVudCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gMTtcbiAgfVxuICBjb25zdCB3aW4gPSBlbGVtZW50Lm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXcgfHwgd2luZG93O1xuICByZXR1cm4gd2luLmRldmljZVBpeGVsUmF0aW8gfHwgMTtcbn1cblxuZnVuY3Rpb24gcm91bmRCeURQUihlbGVtZW50LCB2YWx1ZSkge1xuICBjb25zdCBkcHIgPSBnZXREUFIoZWxlbWVudCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogZHByKSAvIGRwcjtcbn1cblxuZnVuY3Rpb24gdXNlTGF0ZXN0UmVmKHZhbHVlKSB7XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICB9KTtcbiAgcmV0dXJuIHJlZjtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGEgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VGbG9hdGluZ1xuICovXG5mdW5jdGlvbiB1c2VGbG9hdGluZyhvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIHBsYWNlbWVudCA9ICdib3R0b20nLFxuICAgIHN0cmF0ZWd5ID0gJ2Fic29sdXRlJyxcbiAgICBtaWRkbGV3YXJlID0gW10sXG4gICAgcGxhdGZvcm0sXG4gICAgZWxlbWVudHM6IHtcbiAgICAgIHJlZmVyZW5jZTogZXh0ZXJuYWxSZWZlcmVuY2UsXG4gICAgICBmbG9hdGluZzogZXh0ZXJuYWxGbG9hdGluZ1xuICAgIH0gPSB7fSxcbiAgICB0cmFuc2Zvcm0gPSB0cnVlLFxuICAgIHdoaWxlRWxlbWVudHNNb3VudGVkLFxuICAgIG9wZW5cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc3RyYXRlZ3ksXG4gICAgcGxhY2VtZW50LFxuICAgIG1pZGRsZXdhcmVEYXRhOiB7fSxcbiAgICBpc1Bvc2l0aW9uZWQ6IGZhbHNlXG4gIH0pO1xuICBjb25zdCBbbGF0ZXN0TWlkZGxld2FyZSwgc2V0TGF0ZXN0TWlkZGxld2FyZV0gPSBSZWFjdC51c2VTdGF0ZShtaWRkbGV3YXJlKTtcbiAgaWYgKCFkZWVwRXF1YWwobGF0ZXN0TWlkZGxld2FyZSwgbWlkZGxld2FyZSkpIHtcbiAgICBzZXRMYXRlc3RNaWRkbGV3YXJlKG1pZGRsZXdhcmUpO1xuICB9XG4gIGNvbnN0IFtfcmVmZXJlbmNlLCBfc2V0UmVmZXJlbmNlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbX2Zsb2F0aW5nLCBfc2V0RmxvYXRpbmddID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IHNldFJlZmVyZW5jZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmIChub2RlICE9PSByZWZlcmVuY2VSZWYuY3VycmVudCkge1xuICAgICAgcmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBub2RlO1xuICAgICAgX3NldFJlZmVyZW5jZShub2RlKTtcbiAgICB9XG4gIH0sIFtdKTtcbiAgY29uc3Qgc2V0RmxvYXRpbmcgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBpZiAobm9kZSAhPT0gZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgZmxvYXRpbmdSZWYuY3VycmVudCA9IG5vZGU7XG4gICAgICBfc2V0RmxvYXRpbmcobm9kZSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGNvbnN0IHJlZmVyZW5jZUVsID0gZXh0ZXJuYWxSZWZlcmVuY2UgfHwgX3JlZmVyZW5jZTtcbiAgY29uc3QgZmxvYXRpbmdFbCA9IGV4dGVybmFsRmxvYXRpbmcgfHwgX2Zsb2F0aW5nO1xuICBjb25zdCByZWZlcmVuY2VSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGZsb2F0aW5nUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBkYXRhUmVmID0gUmVhY3QudXNlUmVmKGRhdGEpO1xuICBjb25zdCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZCA9IHdoaWxlRWxlbWVudHNNb3VudGVkICE9IG51bGw7XG4gIGNvbnN0IHdoaWxlRWxlbWVudHNNb3VudGVkUmVmID0gdXNlTGF0ZXN0UmVmKHdoaWxlRWxlbWVudHNNb3VudGVkKTtcbiAgY29uc3QgcGxhdGZvcm1SZWYgPSB1c2VMYXRlc3RSZWYocGxhdGZvcm0pO1xuICBjb25zdCBvcGVuUmVmID0gdXNlTGF0ZXN0UmVmKG9wZW4pO1xuICBjb25zdCB1cGRhdGUgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFyZWZlcmVuY2VSZWYuY3VycmVudCB8fCAhZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICBwbGFjZW1lbnQsXG4gICAgICBzdHJhdGVneSxcbiAgICAgIG1pZGRsZXdhcmU6IGxhdGVzdE1pZGRsZXdhcmVcbiAgICB9O1xuICAgIGlmIChwbGF0Zm9ybVJlZi5jdXJyZW50KSB7XG4gICAgICBjb25maWcucGxhdGZvcm0gPSBwbGF0Zm9ybVJlZi5jdXJyZW50O1xuICAgIH1cbiAgICBjb21wdXRlUG9zaXRpb24ocmVmZXJlbmNlUmVmLmN1cnJlbnQsIGZsb2F0aW5nUmVmLmN1cnJlbnQsIGNvbmZpZykudGhlbihkYXRhID0+IHtcbiAgICAgIGNvbnN0IGZ1bGxEYXRhID0ge1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICAvLyBUaGUgZmxvYXRpbmcgZWxlbWVudCdzIHBvc2l0aW9uIG1heSBiZSByZWNvbXB1dGVkIHdoaWxlIGl0J3MgY2xvc2VkXG4gICAgICAgIC8vIGJ1dCBzdGlsbCBtb3VudGVkIChzdWNoIGFzIHdoZW4gdHJhbnNpdGlvbmluZyBvdXQpLiBUbyBlbnN1cmVcbiAgICAgICAgLy8gYGlzUG9zaXRpb25lZGAgd2lsbCBiZSBgZmFsc2VgIGluaXRpYWxseSBvbiB0aGUgbmV4dCBvcGVuLCBhdm9pZFxuICAgICAgICAvLyBzZXR0aW5nIGl0IHRvIGB0cnVlYCB3aGVuIGBvcGVuID09PSBmYWxzZWAgKG11c3QgYmUgc3BlY2lmaWVkKS5cbiAgICAgICAgaXNQb3NpdGlvbmVkOiBvcGVuUmVmLmN1cnJlbnQgIT09IGZhbHNlXG4gICAgICB9O1xuICAgICAgaWYgKGlzTW91bnRlZFJlZi5jdXJyZW50ICYmICFkZWVwRXF1YWwoZGF0YVJlZi5jdXJyZW50LCBmdWxsRGF0YSkpIHtcbiAgICAgICAgZGF0YVJlZi5jdXJyZW50ID0gZnVsbERhdGE7XG4gICAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiB7XG4gICAgICAgICAgc2V0RGF0YShmdWxsRGF0YSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9LCBbbGF0ZXN0TWlkZGxld2FyZSwgcGxhY2VtZW50LCBzdHJhdGVneSwgcGxhdGZvcm1SZWYsIG9wZW5SZWZdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChvcGVuID09PSBmYWxzZSAmJiBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkKSB7XG4gICAgICBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkID0gZmFsc2U7XG4gICAgICBzZXREYXRhKGRhdGEgPT4gKHtcbiAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgaXNQb3NpdGlvbmVkOiBmYWxzZVxuICAgICAgfSkpO1xuICAgIH1cbiAgfSwgW29wZW5dKTtcbiAgY29uc3QgaXNNb3VudGVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlzTW91bnRlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNNb3VudGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBpZiAocmVmZXJlbmNlRWwpIHJlZmVyZW5jZVJlZi5jdXJyZW50ID0gcmVmZXJlbmNlRWw7XG4gICAgaWYgKGZsb2F0aW5nRWwpIGZsb2F0aW5nUmVmLmN1cnJlbnQgPSBmbG9hdGluZ0VsO1xuICAgIGlmIChyZWZlcmVuY2VFbCAmJiBmbG9hdGluZ0VsKSB7XG4gICAgICBpZiAod2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gd2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudChyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbCwgdXBkYXRlKTtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgpO1xuICAgIH1cbiAgfSwgW3JlZmVyZW5jZUVsLCBmbG9hdGluZ0VsLCB1cGRhdGUsIHdoaWxlRWxlbWVudHNNb3VudGVkUmVmLCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZF0pO1xuICBjb25zdCByZWZzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlUmVmLFxuICAgIGZsb2F0aW5nOiBmbG9hdGluZ1JlZixcbiAgICBzZXRSZWZlcmVuY2UsXG4gICAgc2V0RmxvYXRpbmdcbiAgfSksIFtzZXRSZWZlcmVuY2UsIHNldEZsb2F0aW5nXSk7XG4gIGNvbnN0IGVsZW1lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlRWwsXG4gICAgZmxvYXRpbmc6IGZsb2F0aW5nRWxcbiAgfSksIFtyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbF0pO1xuICBjb25zdCBmbG9hdGluZ1N0eWxlcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IGluaXRpYWxTdHlsZXMgPSB7XG4gICAgICBwb3NpdGlvbjogc3RyYXRlZ3ksXG4gICAgICBsZWZ0OiAwLFxuICAgICAgdG9wOiAwXG4gICAgfTtcbiAgICBpZiAoIWVsZW1lbnRzLmZsb2F0aW5nKSB7XG4gICAgICByZXR1cm4gaW5pdGlhbFN0eWxlcztcbiAgICB9XG4gICAgY29uc3QgeCA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueCk7XG4gICAgY29uc3QgeSA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueSk7XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uaW5pdGlhbFN0eWxlcyxcbiAgICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZShcIiArIHggKyBcInB4LCBcIiArIHkgKyBcInB4KVwiLFxuICAgICAgICAuLi4oZ2V0RFBSKGVsZW1lbnRzLmZsb2F0aW5nKSA+PSAxLjUgJiYge1xuICAgICAgICAgIHdpbGxDaGFuZ2U6ICd0cmFuc2Zvcm0nXG4gICAgICAgIH0pXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgcG9zaXRpb246IHN0cmF0ZWd5LFxuICAgICAgbGVmdDogeCxcbiAgICAgIHRvcDogeVxuICAgIH07XG4gIH0sIFtzdHJhdGVneSwgdHJhbnNmb3JtLCBlbGVtZW50cy5mbG9hdGluZywgZGF0YS54LCBkYXRhLnldKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAuLi5kYXRhLFxuICAgIHVwZGF0ZSxcbiAgICByZWZzLFxuICAgIGVsZW1lbnRzLFxuICAgIGZsb2F0aW5nU3R5bGVzXG4gIH0pLCBbZGF0YSwgdXBkYXRlLCByZWZzLCBlbGVtZW50cywgZmxvYXRpbmdTdHlsZXNdKTtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBUaGlzIHdyYXBzIHRoZSBjb3JlIGBhcnJvd2AgbWlkZGxld2FyZSB0byBhbGxvdyBSZWFjdCByZWZzIGFzIHRoZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmNvbnN0IGFycm93JDEgPSBvcHRpb25zID0+IHtcbiAgZnVuY3Rpb24gaXNSZWYodmFsdWUpIHtcbiAgICByZXR1cm4ge30uaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgJ2N1cnJlbnQnKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdhcnJvdycsXG4gICAgb3B0aW9ucyxcbiAgICBmbihzdGF0ZSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBlbGVtZW50LFxuICAgICAgICBwYWRkaW5nXG4gICAgICB9ID0gdHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicgPyBvcHRpb25zKHN0YXRlKSA6IG9wdGlvbnM7XG4gICAgICBpZiAoZWxlbWVudCAmJiBpc1JlZihlbGVtZW50KSkge1xuICAgICAgICBpZiAoZWxlbWVudC5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gYXJyb3ckMih7XG4gICAgICAgICAgICBlbGVtZW50OiBlbGVtZW50LmN1cnJlbnQsXG4gICAgICAgICAgICBwYWRkaW5nXG4gICAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBhcnJvdyQyKHtcbiAgICAgICAgICBlbGVtZW50LFxuICAgICAgICAgIHBhZGRpbmdcbiAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogTW9kaWZpZXMgdGhlIHBsYWNlbWVudCBieSB0cmFuc2xhdGluZyB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbG9uZyB0aGVcbiAqIHNwZWNpZmllZCBheGVzLlxuICogQSBudW1iZXIgKHNob3J0aGFuZCBmb3IgYG1haW5BeGlzYCBvciBkaXN0YW5jZSksIG9yIGFuIGF4ZXMgY29uZmlndXJhdGlvblxuICogb2JqZWN0IG1heSBiZSBwYXNzZWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvb2Zmc2V0XG4gKi9cbmNvbnN0IG9mZnNldCA9IChvcHRpb25zLCBkZXBzKSA9PiAoe1xuICAuLi5vZmZzZXQkMShvcHRpb25zKSxcbiAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG59KTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgc2hpZnRpbmcgaXQgaW4gb3JkZXIgdG9cbiAqIGtlZXAgaXQgaW4gdmlldyB3aGVuIGl0IHdpbGwgb3ZlcmZsb3cgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NoaWZ0XG4gKi9cbmNvbnN0IHNoaWZ0ID0gKG9wdGlvbnMsIGRlcHMpID0+ICh7XG4gIC4uLnNoaWZ0JDEob3B0aW9ucyksXG4gIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxufSk7XG5cbi8qKlxuICogQnVpbHQtaW4gYGxpbWl0ZXJgIHRoYXQgd2lsbCBzdG9wIGBzaGlmdCgpYCBhdCBhIGNlcnRhaW4gcG9pbnQuXG4gKi9cbmNvbnN0IGxpbWl0U2hpZnQgPSAob3B0aW9ucywgZGVwcykgPT4gKHtcbiAgLi4ubGltaXRTaGlmdCQxKG9wdGlvbnMpLFxuICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbn0pO1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBmbGlwcGluZyB0aGUgYHBsYWNlbWVudGBcbiAqIGluIG9yZGVyIHRvIGtlZXAgaXQgaW4gdmlldyB3aGVuIHRoZSBwcmVmZXJyZWQgcGxhY2VtZW50KHMpIHdpbGwgb3ZlcmZsb3cgdGhlXG4gKiBjbGlwcGluZyBib3VuZGFyeS4gQWx0ZXJuYXRpdmUgdG8gYGF1dG9QbGFjZW1lbnRgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2ZsaXBcbiAqL1xuY29uc3QgZmxpcCA9IChvcHRpb25zLCBkZXBzKSA9PiAoe1xuICAuLi5mbGlwJDEob3B0aW9ucyksXG4gIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxufSk7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0aGF0IGFsbG93cyB5b3UgdG8gY2hhbmdlIHRoZSBzaXplIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IOKAlFxuICogZm9yIGluc3RhbmNlLCBwcmV2ZW50IGl0IGZyb20gb3ZlcmZsb3dpbmcgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5IG9yIG1hdGNoIHRoZVxuICogd2lkdGggb2YgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NpemVcbiAqL1xuY29uc3Qgc2l6ZSA9IChvcHRpb25zLCBkZXBzKSA9PiAoe1xuICAuLi5zaXplJDEob3B0aW9ucyksXG4gIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxufSk7XG5cbi8qKlxuICogT3B0aW1pemVzIHRoZSB2aXNpYmlsaXR5IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IGJ5IGNob29zaW5nIHRoZSBwbGFjZW1lbnRcbiAqIHRoYXQgaGFzIHRoZSBtb3N0IHNwYWNlIGF2YWlsYWJsZSBhdXRvbWF0aWNhbGx5LCB3aXRob3V0IG5lZWRpbmcgdG8gc3BlY2lmeSBhXG4gKiBwcmVmZXJyZWQgcGxhY2VtZW50LiBBbHRlcm5hdGl2ZSB0byBgZmxpcGAuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXV0b1BsYWNlbWVudFxuICovXG5jb25zdCBhdXRvUGxhY2VtZW50ID0gKG9wdGlvbnMsIGRlcHMpID0+ICh7XG4gIC4uLmF1dG9QbGFjZW1lbnQkMShvcHRpb25zKSxcbiAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG59KTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIGhpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW4gYXBwbGljYWJsZSBzaXR1YXRpb25zLCBzdWNoIGFzXG4gKiB3aGVuIGl0IGlzIG5vdCBpbiB0aGUgc2FtZSBjbGlwcGluZyBjb250ZXh0IGFzIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9oaWRlXG4gKi9cbmNvbnN0IGhpZGUgPSAob3B0aW9ucywgZGVwcykgPT4gKHtcbiAgLi4uaGlkZSQxKG9wdGlvbnMpLFxuICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbn0pO1xuXG4vKipcbiAqIFByb3ZpZGVzIGltcHJvdmVkIHBvc2l0aW9uaW5nIGZvciBpbmxpbmUgcmVmZXJlbmNlIGVsZW1lbnRzIHRoYXQgY2FuIHNwYW5cbiAqIG92ZXIgbXVsdGlwbGUgbGluZXMsIHN1Y2ggYXMgaHlwZXJsaW5rcyBvciByYW5nZSBzZWxlY3Rpb25zLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2lubGluZVxuICovXG5jb25zdCBpbmxpbmUgPSAob3B0aW9ucywgZGVwcykgPT4gKHtcbiAgLi4uaW5saW5lJDEob3B0aW9ucyksXG4gIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxufSk7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBwb3NpdGlvbiBhbiBpbm5lciBlbGVtZW50IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IHNvIHRoYXQgaXRcbiAqIGFwcGVhcnMgY2VudGVyZWQgdG8gdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogVGhpcyB3cmFwcyB0aGUgY29yZSBgYXJyb3dgIG1pZGRsZXdhcmUgdG8gYWxsb3cgUmVhY3QgcmVmcyBhcyB0aGUgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9hcnJvd1xuICovXG5jb25zdCBhcnJvdyA9IChvcHRpb25zLCBkZXBzKSA9PiAoe1xuICAuLi5hcnJvdyQxKG9wdGlvbnMpLFxuICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbn0pO1xuXG5leHBvcnQgeyBhcnJvdywgYXV0b1BsYWNlbWVudCwgZmxpcCwgaGlkZSwgaW5saW5lLCBsaW1pdFNoaWZ0LCBvZmZzZXQsIHNoaWZ0LCBzaXplLCB1c2VGbG9hdGluZyB9O1xuIiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0LCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHN0b3BFdmVudCwgZ2V0RG9jdW1lbnQsIGlzTW91c2VMaWtlUG9pbnRlclR5cGUsIGNvbnRhaW5zLCBhY3RpdmVFbGVtZW50LCBpc1NhZmFyaSwgaXNUeXBlYWJsZUNvbWJvYm94LCBpc1ZpcnR1YWxDbGljaywgaXNWaXJ0dWFsUG9pbnRlckV2ZW50LCBnZXRUYXJnZXQsIGdldFBsYXRmb3JtLCBpc1R5cGVhYmxlRWxlbWVudCwgaXNSZWFjdEV2ZW50LCBpc1Jvb3RFbGVtZW50LCBpc0V2ZW50VGFyZ2V0V2l0aGluLCBpc01hYywgZ2V0VXNlckFnZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3JlYWN0L3V0aWxzJztcbmltcG9ydCB7IGZsb29yLCBldmFsdWF0ZSwgbWF4LCBtaW4sIHJvdW5kIH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcbmltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGlzRWxlbWVudCwgZ2V0Tm9kZU5hbWUsIGlzSFRNTEVsZW1lbnQsIGdldFdpbmRvdywgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBnZXRQYXJlbnROb2RlLCBpc1dlYktpdCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgdGFiYmFibGUsIGlzVGFiYmFibGUgfSBmcm9tICd0YWJiYWJsZSc7XG5pbXBvcnQgKiBhcyBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0IHsgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIHVzZUZsb2F0aW5nIGFzIHVzZUZsb2F0aW5nJDEsIG9mZnNldCwgZGV0ZWN0T3ZlcmZsb3cgfSBmcm9tICdAZmxvYXRpbmctdWkvcmVhY3QtZG9tJztcbmV4cG9ydCB7IGFycm93LCBhdXRvUGxhY2VtZW50LCBhdXRvVXBkYXRlLCBjb21wdXRlUG9zaXRpb24sIGRldGVjdE92ZXJmbG93LCBmbGlwLCBnZXRPdmVyZmxvd0FuY2VzdG9ycywgaGlkZSwgaW5saW5lLCBsaW1pdFNoaWZ0LCBvZmZzZXQsIHBsYXRmb3JtLCBzaGlmdCwgc2l6ZSB9IGZyb20gJ0BmbG9hdGluZy11aS9yZWFjdC1kb20nO1xuXG4vKipcbiAqIE1lcmdlcyBhbiBhcnJheSBvZiByZWZzIGludG8gYSBzaW5nbGUgbWVtb2l6ZWQgY2FsbGJhY2sgcmVmIG9yIGBudWxsYC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9yZWFjdC11dGlscyN1c2VtZXJnZXJlZnNcbiAqL1xuZnVuY3Rpb24gdXNlTWVyZ2VSZWZzKHJlZnMpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChyZWZzLmV2ZXJ5KHJlZiA9PiByZWYgPT0gbnVsbCkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWUgPT4ge1xuICAgICAgcmVmcy5mb3JFYWNoKHJlZiA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgcmVmID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgcmVmKHZhbHVlKTtcbiAgICAgICAgfSBlbHNlIGlmIChyZWYgIT0gbnVsbCkge1xuICAgICAgICAgIHJlZi5jdXJyZW50ID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH07XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCByZWZzKTtcbn1cblxuLy8gaHR0cHM6Ly9naXRodWIuY29tL211aS9tYXRlcmlhbC11aS9pc3N1ZXMvNDExOTAjaXNzdWVjb21tZW50LTIwNDA4NzMzNzlcbmNvbnN0IFNhZmVSZWFjdCA9IHtcbiAgLi4uUmVhY3Rcbn07XG5cbmNvbnN0IHVzZUluc2VydGlvbkVmZmVjdCA9IFNhZmVSZWFjdC51c2VJbnNlcnRpb25FZmZlY3Q7XG5jb25zdCB1c2VTYWZlSW5zZXJ0aW9uRWZmZWN0ID0gdXNlSW5zZXJ0aW9uRWZmZWN0IHx8IChmbiA9PiBmbigpKTtcbmZ1bmN0aW9uIHVzZUVmZmVjdEV2ZW50KGNhbGxiYWNrKSB7XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZigoKSA9PiB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgY2FsbCBhbiBldmVudCBoYW5kbGVyIHdoaWxlIHJlbmRlcmluZy4nKTtcbiAgICB9XG4gIH0pO1xuICB1c2VTYWZlSW5zZXJ0aW9uRWZmZWN0KCgpID0+IHtcbiAgICByZWYuY3VycmVudCA9IGNhbGxiYWNrO1xuICB9KTtcbiAgcmV0dXJuIFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uICgpIHtcbiAgICBmb3IgKHZhciBfbGVuID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgfVxuICAgIHJldHVybiByZWYuY3VycmVudCA9PSBudWxsID8gdm9pZCAwIDogcmVmLmN1cnJlbnQoLi4uYXJncyk7XG4gIH0sIFtdKTtcbn1cblxuY29uc3QgQVJST1dfVVAgPSAnQXJyb3dVcCc7XG5jb25zdCBBUlJPV19ET1dOID0gJ0Fycm93RG93bic7XG5jb25zdCBBUlJPV19MRUZUID0gJ0Fycm93TGVmdCc7XG5jb25zdCBBUlJPV19SSUdIVCA9ICdBcnJvd1JpZ2h0JztcbmZ1bmN0aW9uIGlzRGlmZmVyZW50Um93KGluZGV4LCBjb2xzLCBwcmV2Um93KSB7XG4gIHJldHVybiBNYXRoLmZsb29yKGluZGV4IC8gY29scykgIT09IHByZXZSb3c7XG59XG5mdW5jdGlvbiBpc0luZGV4T3V0T2ZCb3VuZHMobGlzdFJlZiwgaW5kZXgpIHtcbiAgcmV0dXJuIGluZGV4IDwgMCB8fCBpbmRleCA+PSBsaXN0UmVmLmN1cnJlbnQubGVuZ3RoO1xufVxuZnVuY3Rpb24gZ2V0TWluSW5kZXgobGlzdFJlZiwgZGlzYWJsZWRJbmRpY2VzKSB7XG4gIHJldHVybiBmaW5kTm9uRGlzYWJsZWRJbmRleChsaXN0UmVmLCB7XG4gICAgZGlzYWJsZWRJbmRpY2VzXG4gIH0pO1xufVxuZnVuY3Rpb24gZ2V0TWF4SW5kZXgobGlzdFJlZiwgZGlzYWJsZWRJbmRpY2VzKSB7XG4gIHJldHVybiBmaW5kTm9uRGlzYWJsZWRJbmRleChsaXN0UmVmLCB7XG4gICAgZGVjcmVtZW50OiB0cnVlLFxuICAgIHN0YXJ0aW5nSW5kZXg6IGxpc3RSZWYuY3VycmVudC5sZW5ndGgsXG4gICAgZGlzYWJsZWRJbmRpY2VzXG4gIH0pO1xufVxuZnVuY3Rpb24gZmluZE5vbkRpc2FibGVkSW5kZXgobGlzdFJlZiwgX3RlbXApIHtcbiAgbGV0IHtcbiAgICBzdGFydGluZ0luZGV4ID0gLTEsXG4gICAgZGVjcmVtZW50ID0gZmFsc2UsXG4gICAgZGlzYWJsZWRJbmRpY2VzLFxuICAgIGFtb3VudCA9IDFcbiAgfSA9IF90ZW1wID09PSB2b2lkIDAgPyB7fSA6IF90ZW1wO1xuICBjb25zdCBsaXN0ID0gbGlzdFJlZi5jdXJyZW50O1xuICBsZXQgaW5kZXggPSBzdGFydGluZ0luZGV4O1xuICBkbyB7XG4gICAgaW5kZXggKz0gZGVjcmVtZW50ID8gLWFtb3VudCA6IGFtb3VudDtcbiAgfSB3aGlsZSAoaW5kZXggPj0gMCAmJiBpbmRleCA8PSBsaXN0Lmxlbmd0aCAtIDEgJiYgaXNEaXNhYmxlZChsaXN0LCBpbmRleCwgZGlzYWJsZWRJbmRpY2VzKSk7XG4gIHJldHVybiBpbmRleDtcbn1cbmZ1bmN0aW9uIGdldEdyaWROYXZpZ2F0ZWRJbmRleChlbGVtZW50c1JlZiwgX3JlZikge1xuICBsZXQge1xuICAgIGV2ZW50LFxuICAgIG9yaWVudGF0aW9uLFxuICAgIGxvb3AsXG4gICAgcnRsLFxuICAgIGNvbHMsXG4gICAgZGlzYWJsZWRJbmRpY2VzLFxuICAgIG1pbkluZGV4LFxuICAgIG1heEluZGV4LFxuICAgIHByZXZJbmRleCxcbiAgICBzdG9wRXZlbnQ6IHN0b3AgPSBmYWxzZVxuICB9ID0gX3JlZjtcbiAgbGV0IG5leHRJbmRleCA9IHByZXZJbmRleDtcbiAgaWYgKGV2ZW50LmtleSA9PT0gQVJST1dfVVApIHtcbiAgICBzdG9wICYmIHN0b3BFdmVudChldmVudCk7XG4gICAgaWYgKHByZXZJbmRleCA9PT0gLTEpIHtcbiAgICAgIG5leHRJbmRleCA9IG1heEluZGV4O1xuICAgIH0gZWxzZSB7XG4gICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRJbmRleChlbGVtZW50c1JlZiwge1xuICAgICAgICBzdGFydGluZ0luZGV4OiBuZXh0SW5kZXgsXG4gICAgICAgIGFtb3VudDogY29scyxcbiAgICAgICAgZGVjcmVtZW50OiB0cnVlLFxuICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgIH0pO1xuICAgICAgaWYgKGxvb3AgJiYgKHByZXZJbmRleCAtIGNvbHMgPCBtaW5JbmRleCB8fCBuZXh0SW5kZXggPCAwKSkge1xuICAgICAgICBjb25zdCBjb2wgPSBwcmV2SW5kZXggJSBjb2xzO1xuICAgICAgICBjb25zdCBtYXhDb2wgPSBtYXhJbmRleCAlIGNvbHM7XG4gICAgICAgIGNvbnN0IG9mZnNldCA9IG1heEluZGV4IC0gKG1heENvbCAtIGNvbCk7XG4gICAgICAgIGlmIChtYXhDb2wgPT09IGNvbCkge1xuICAgICAgICAgIG5leHRJbmRleCA9IG1heEluZGV4O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5leHRJbmRleCA9IG1heENvbCA+IGNvbCA/IG9mZnNldCA6IG9mZnNldCAtIGNvbHM7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzSW5kZXhPdXRPZkJvdW5kcyhlbGVtZW50c1JlZiwgbmV4dEluZGV4KSkge1xuICAgICAgbmV4dEluZGV4ID0gcHJldkluZGV4O1xuICAgIH1cbiAgfVxuICBpZiAoZXZlbnQua2V5ID09PSBBUlJPV19ET1dOKSB7XG4gICAgc3RvcCAmJiBzdG9wRXZlbnQoZXZlbnQpO1xuICAgIGlmIChwcmV2SW5kZXggPT09IC0xKSB7XG4gICAgICBuZXh0SW5kZXggPSBtaW5JbmRleDtcbiAgICB9IGVsc2Uge1xuICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkSW5kZXgoZWxlbWVudHNSZWYsIHtcbiAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4LFxuICAgICAgICBhbW91bnQ6IGNvbHMsXG4gICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgfSk7XG4gICAgICBpZiAobG9vcCAmJiBwcmV2SW5kZXggKyBjb2xzID4gbWF4SW5kZXgpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkSW5kZXgoZWxlbWVudHNSZWYsIHtcbiAgICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXggJSBjb2xzIC0gY29scyxcbiAgICAgICAgICBhbW91bnQ6IGNvbHMsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaXNJbmRleE91dE9mQm91bmRzKGVsZW1lbnRzUmVmLCBuZXh0SW5kZXgpKSB7XG4gICAgICBuZXh0SW5kZXggPSBwcmV2SW5kZXg7XG4gICAgfVxuICB9XG5cbiAgLy8gUmVtYWlucyBvbiB0aGUgc2FtZSByb3cvY29sdW1uLlxuICBpZiAob3JpZW50YXRpb24gPT09ICdib3RoJykge1xuICAgIGNvbnN0IHByZXZSb3cgPSBmbG9vcihwcmV2SW5kZXggLyBjb2xzKTtcbiAgICBpZiAoZXZlbnQua2V5ID09PSAocnRsID8gQVJST1dfTEVGVCA6IEFSUk9XX1JJR0hUKSkge1xuICAgICAgc3RvcCAmJiBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgaWYgKHByZXZJbmRleCAlIGNvbHMgIT09IGNvbHMgLSAxKSB7XG4gICAgICAgIG5leHRJbmRleCA9IGZpbmROb25EaXNhYmxlZEluZGV4KGVsZW1lbnRzUmVmLCB7XG4gICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4LFxuICAgICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGxvb3AgJiYgaXNEaWZmZXJlbnRSb3cobmV4dEluZGV4LCBjb2xzLCBwcmV2Um93KSkge1xuICAgICAgICAgIG5leHRJbmRleCA9IGZpbmROb25EaXNhYmxlZEluZGV4KGVsZW1lbnRzUmVmLCB7XG4gICAgICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXggLSBwcmV2SW5kZXggJSBjb2xzIC0gMSxcbiAgICAgICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGxvb3ApIHtcbiAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkSW5kZXgoZWxlbWVudHNSZWYsIHtcbiAgICAgICAgICBzdGFydGluZ0luZGV4OiBwcmV2SW5kZXggLSBwcmV2SW5kZXggJSBjb2xzIC0gMSxcbiAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAoaXNEaWZmZXJlbnRSb3cobmV4dEluZGV4LCBjb2xzLCBwcmV2Um93KSkge1xuICAgICAgICBuZXh0SW5kZXggPSBwcmV2SW5kZXg7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChldmVudC5rZXkgPT09IChydGwgPyBBUlJPV19SSUdIVCA6IEFSUk9XX0xFRlQpKSB7XG4gICAgICBzdG9wICYmIHN0b3BFdmVudChldmVudCk7XG4gICAgICBpZiAocHJldkluZGV4ICUgY29scyAhPT0gMCkge1xuICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRJbmRleChlbGVtZW50c1JlZiwge1xuICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IHByZXZJbmRleCxcbiAgICAgICAgICBkZWNyZW1lbnQ6IHRydWUsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAobG9vcCAmJiBpc0RpZmZlcmVudFJvdyhuZXh0SW5kZXgsIGNvbHMsIHByZXZSb3cpKSB7XG4gICAgICAgICAgbmV4dEluZGV4ID0gZmluZE5vbkRpc2FibGVkSW5kZXgoZWxlbWVudHNSZWYsIHtcbiAgICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IHByZXZJbmRleCArIChjb2xzIC0gcHJldkluZGV4ICUgY29scyksXG4gICAgICAgICAgICBkZWNyZW1lbnQ6IHRydWUsXG4gICAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChsb29wKSB7XG4gICAgICAgIG5leHRJbmRleCA9IGZpbmROb25EaXNhYmxlZEluZGV4KGVsZW1lbnRzUmVmLCB7XG4gICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4ICsgKGNvbHMgLSBwcmV2SW5kZXggJSBjb2xzKSxcbiAgICAgICAgICBkZWNyZW1lbnQ6IHRydWUsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKGlzRGlmZmVyZW50Um93KG5leHRJbmRleCwgY29scywgcHJldlJvdykpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gcHJldkluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBsYXN0Um93ID0gZmxvb3IobWF4SW5kZXggLyBjb2xzKSA9PT0gcHJldlJvdztcbiAgICBpZiAoaXNJbmRleE91dE9mQm91bmRzKGVsZW1lbnRzUmVmLCBuZXh0SW5kZXgpKSB7XG4gICAgICBpZiAobG9vcCAmJiBsYXN0Um93KSB7XG4gICAgICAgIG5leHRJbmRleCA9IGV2ZW50LmtleSA9PT0gKHJ0bCA/IEFSUk9XX1JJR0hUIDogQVJST1dfTEVGVCkgPyBtYXhJbmRleCA6IGZpbmROb25EaXNhYmxlZEluZGV4KGVsZW1lbnRzUmVmLCB7XG4gICAgICAgICAgc3RhcnRpbmdJbmRleDogcHJldkluZGV4IC0gcHJldkluZGV4ICUgY29scyAtIDEsXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV4dEluZGV4ID0gcHJldkluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gbmV4dEluZGV4O1xufVxuXG4vKiogRm9yIGVhY2ggY2VsbCBpbmRleCwgZ2V0cyB0aGUgaXRlbSBpbmRleCB0aGF0IG9jY3VwaWVzIHRoYXQgY2VsbCAqL1xuZnVuY3Rpb24gYnVpbGRDZWxsTWFwKHNpemVzLCBjb2xzLCBkZW5zZSkge1xuICBjb25zdCBjZWxsTWFwID0gW107XG4gIGxldCBzdGFydEluZGV4ID0gMDtcbiAgc2l6ZXMuZm9yRWFjaCgoX3JlZjIsIGluZGV4KSA9PiB7XG4gICAgbGV0IHtcbiAgICAgIHdpZHRoLFxuICAgICAgaGVpZ2h0XG4gICAgfSA9IF9yZWYyO1xuICAgIGlmICh3aWR0aCA+IGNvbHMpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiW0Zsb2F0aW5nIFVJXTogSW52YWxpZCBncmlkIC0gaXRlbSB3aWR0aCBhdCBpbmRleCBcIiArIGluZGV4ICsgXCIgaXMgZ3JlYXRlciB0aGFuIGdyaWQgY29sdW1uc1wiKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IGl0ZW1QbGFjZWQgPSBmYWxzZTtcbiAgICBpZiAoZGVuc2UpIHtcbiAgICAgIHN0YXJ0SW5kZXggPSAwO1xuICAgIH1cbiAgICB3aGlsZSAoIWl0ZW1QbGFjZWQpIHtcbiAgICAgIGNvbnN0IHRhcmdldENlbGxzID0gW107XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdpZHRoOyBpKyspIHtcbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBoZWlnaHQ7IGorKykge1xuICAgICAgICAgIHRhcmdldENlbGxzLnB1c2goc3RhcnRJbmRleCArIGkgKyBqICogY29scyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzdGFydEluZGV4ICUgY29scyArIHdpZHRoIDw9IGNvbHMgJiYgdGFyZ2V0Q2VsbHMuZXZlcnkoY2VsbCA9PiBjZWxsTWFwW2NlbGxdID09IG51bGwpKSB7XG4gICAgICAgIHRhcmdldENlbGxzLmZvckVhY2goY2VsbCA9PiB7XG4gICAgICAgICAgY2VsbE1hcFtjZWxsXSA9IGluZGV4O1xuICAgICAgICB9KTtcbiAgICAgICAgaXRlbVBsYWNlZCA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdGFydEluZGV4Kys7XG4gICAgICB9XG4gICAgfVxuICB9KTtcblxuICAvLyBjb252ZXJ0IGludG8gYSBub24tc3BhcnNlIGFycmF5XG4gIHJldHVybiBbLi4uY2VsbE1hcF07XG59XG5cbi8qKiBHZXRzIGNlbGwgaW5kZXggb2YgYW4gaXRlbSdzIGNvcm5lciBvciAtMSB3aGVuIGluZGV4IGlzIC0xLiAqL1xuZnVuY3Rpb24gZ2V0Q2VsbEluZGV4T2ZDb3JuZXIoaW5kZXgsIHNpemVzLCBjZWxsTWFwLCBjb2xzLCBjb3JuZXIpIHtcbiAgaWYgKGluZGV4ID09PSAtMSkgcmV0dXJuIC0xO1xuICBjb25zdCBmaXJzdENlbGxJbmRleCA9IGNlbGxNYXAuaW5kZXhPZihpbmRleCk7XG4gIGNvbnN0IHNpemVJdGVtID0gc2l6ZXNbaW5kZXhdO1xuICBzd2l0Y2ggKGNvcm5lcikge1xuICAgIGNhc2UgJ3RsJzpcbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICBjYXNlICd0cic6XG4gICAgICBpZiAoIXNpemVJdGVtKSB7XG4gICAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleCArIHNpemVJdGVtLndpZHRoIC0gMTtcbiAgICBjYXNlICdibCc6XG4gICAgICBpZiAoIXNpemVJdGVtKSB7XG4gICAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaXJzdENlbGxJbmRleCArIChzaXplSXRlbS5oZWlnaHQgLSAxKSAqIGNvbHM7XG4gICAgY2FzZSAnYnInOlxuICAgICAgcmV0dXJuIGNlbGxNYXAubGFzdEluZGV4T2YoaW5kZXgpO1xuICB9XG59XG5cbi8qKiBHZXRzIGFsbCBjZWxsIGluZGljZXMgdGhhdCBjb3JyZXNwb25kIHRvIHRoZSBzcGVjaWZpZWQgaW5kaWNlcyAqL1xuZnVuY3Rpb24gZ2V0Q2VsbEluZGljZXMoaW5kaWNlcywgY2VsbE1hcCkge1xuICByZXR1cm4gY2VsbE1hcC5mbGF0TWFwKChpbmRleCwgY2VsbEluZGV4KSA9PiBpbmRpY2VzLmluY2x1ZGVzKGluZGV4KSA/IFtjZWxsSW5kZXhdIDogW10pO1xufVxuZnVuY3Rpb24gaXNEaXNhYmxlZChsaXN0LCBpbmRleCwgZGlzYWJsZWRJbmRpY2VzKSB7XG4gIGlmIChkaXNhYmxlZEluZGljZXMpIHtcbiAgICByZXR1cm4gZGlzYWJsZWRJbmRpY2VzLmluY2x1ZGVzKGluZGV4KTtcbiAgfVxuICBjb25zdCBlbGVtZW50ID0gbGlzdFtpbmRleF07XG4gIHJldHVybiBlbGVtZW50ID09IG51bGwgfHwgZWxlbWVudC5oYXNBdHRyaWJ1dGUoJ2Rpc2FibGVkJykgfHwgZWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2FyaWEtZGlzYWJsZWQnKSA9PT0gJ3RydWUnO1xufVxuXG52YXIgaW5kZXggPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnID8gdXNlTGF5b3V0RWZmZWN0IDogdXNlRWZmZWN0O1xuXG5mdW5jdGlvbiBzb3J0QnlEb2N1bWVudFBvc2l0aW9uKGEsIGIpIHtcbiAgY29uc3QgcG9zaXRpb24gPSBhLmNvbXBhcmVEb2N1bWVudFBvc2l0aW9uKGIpO1xuICBpZiAocG9zaXRpb24gJiBOb2RlLkRPQ1VNRU5UX1BPU0lUSU9OX0ZPTExPV0lORyB8fCBwb3NpdGlvbiAmIE5vZGUuRE9DVU1FTlRfUE9TSVRJT05fQ09OVEFJTkVEX0JZKSB7XG4gICAgcmV0dXJuIC0xO1xuICB9XG4gIGlmIChwb3NpdGlvbiAmIE5vZGUuRE9DVU1FTlRfUE9TSVRJT05fUFJFQ0VESU5HIHx8IHBvc2l0aW9uICYgTm9kZS5ET0NVTUVOVF9QT1NJVElPTl9DT05UQUlOUykge1xuICAgIHJldHVybiAxO1xuICB9XG4gIHJldHVybiAwO1xufVxuZnVuY3Rpb24gYXJlTWFwc0VxdWFsKG1hcDEsIG1hcDIpIHtcbiAgaWYgKG1hcDEuc2l6ZSAhPT0gbWFwMi5zaXplKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIG1hcDEuZW50cmllcygpKSB7XG4gICAgaWYgKHZhbHVlICE9PSBtYXAyLmdldChrZXkpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuY29uc3QgRmxvYXRpbmdMaXN0Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgcmVnaXN0ZXI6ICgpID0+IHt9LFxuICB1bnJlZ2lzdGVyOiAoKSA9PiB7fSxcbiAgbWFwOiAvKiNfX1BVUkVfXyovbmV3IE1hcCgpLFxuICBlbGVtZW50c1JlZjoge1xuICAgIGN1cnJlbnQ6IFtdXG4gIH1cbn0pO1xuLyoqXG4gKiBQcm92aWRlcyBjb250ZXh0IGZvciBhIGxpc3Qgb2YgaXRlbXMgd2l0aGluIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nTGlzdFxuICovXG5mdW5jdGlvbiBGbG9hdGluZ0xpc3QocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIGVsZW1lbnRzUmVmLFxuICAgIGxhYmVsc1JlZlxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IFttYXAsIHNldE1hcF0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgTWFwKCkpO1xuICBjb25zdCByZWdpc3RlciA9IFJlYWN0LnVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIHNldE1hcChwcmV2TWFwID0+IG5ldyBNYXAocHJldk1hcCkuc2V0KG5vZGUsIG51bGwpKTtcbiAgfSwgW10pO1xuICBjb25zdCB1bnJlZ2lzdGVyID0gUmVhY3QudXNlQ2FsbGJhY2sobm9kZSA9PiB7XG4gICAgc2V0TWFwKHByZXZNYXAgPT4ge1xuICAgICAgY29uc3QgbWFwID0gbmV3IE1hcChwcmV2TWFwKTtcbiAgICAgIG1hcC5kZWxldGUobm9kZSk7XG4gICAgICByZXR1cm4gbWFwO1xuICAgIH0pO1xuICB9LCBbXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBjb25zdCBuZXdNYXAgPSBuZXcgTWFwKG1hcCk7XG4gICAgY29uc3Qgbm9kZXMgPSBBcnJheS5mcm9tKG5ld01hcC5rZXlzKCkpLnNvcnQoc29ydEJ5RG9jdW1lbnRQb3NpdGlvbik7XG4gICAgbm9kZXMuZm9yRWFjaCgobm9kZSwgaW5kZXgpID0+IHtcbiAgICAgIG5ld01hcC5zZXQobm9kZSwgaW5kZXgpO1xuICAgIH0pO1xuICAgIGlmICghYXJlTWFwc0VxdWFsKG1hcCwgbmV3TWFwKSkge1xuICAgICAgc2V0TWFwKG5ld01hcCk7XG4gICAgfVxuICB9LCBbbWFwXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGbG9hdGluZ0xpc3RDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgIHJlZ2lzdGVyLFxuICAgICAgdW5yZWdpc3RlcixcbiAgICAgIG1hcCxcbiAgICAgIGVsZW1lbnRzUmVmLFxuICAgICAgbGFiZWxzUmVmXG4gICAgfSksIFtyZWdpc3RlciwgdW5yZWdpc3RlciwgbWFwLCBlbGVtZW50c1JlZiwgbGFiZWxzUmVmXSlcbiAgfSwgY2hpbGRyZW4pO1xufVxuLyoqXG4gKiBVc2VkIHRvIHJlZ2lzdGVyIGEgbGlzdCBpdGVtIGFuZCBpdHMgaW5kZXggKERPTSBwb3NpdGlvbikgaW4gdGhlXG4gKiBgRmxvYXRpbmdMaXN0YC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ0xpc3QjdXNlbGlzdGl0ZW1cbiAqL1xuZnVuY3Rpb24gdXNlTGlzdEl0ZW0ocHJvcHMpIHtcbiAgaWYgKHByb3BzID09PSB2b2lkIDApIHtcbiAgICBwcm9wcyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBsYWJlbFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICB1bnJlZ2lzdGVyLFxuICAgIG1hcCxcbiAgICBlbGVtZW50c1JlZixcbiAgICBsYWJlbHNSZWZcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoRmxvYXRpbmdMaXN0Q29udGV4dCk7XG4gIGNvbnN0IFtpbmRleCQxLCBzZXRJbmRleF0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgY29tcG9uZW50UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCByZWYgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBjb21wb25lbnRSZWYuY3VycmVudCA9IG5vZGU7XG4gICAgaWYgKGluZGV4JDEgIT09IG51bGwpIHtcbiAgICAgIGVsZW1lbnRzUmVmLmN1cnJlbnRbaW5kZXgkMV0gPSBub2RlO1xuICAgICAgaWYgKGxhYmVsc1JlZikge1xuICAgICAgICB2YXIgX25vZGUkdGV4dENvbnRlbnQ7XG4gICAgICAgIGNvbnN0IGlzTGFiZWxEZWZpbmVkID0gbGFiZWwgIT09IHVuZGVmaW5lZDtcbiAgICAgICAgbGFiZWxzUmVmLmN1cnJlbnRbaW5kZXgkMV0gPSBpc0xhYmVsRGVmaW5lZCA/IGxhYmVsIDogKF9ub2RlJHRleHRDb250ZW50ID0gbm9kZSA9PSBudWxsID8gdm9pZCAwIDogbm9kZS50ZXh0Q29udGVudCkgIT0gbnVsbCA/IF9ub2RlJHRleHRDb250ZW50IDogbnVsbDtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtpbmRleCQxLCBlbGVtZW50c1JlZiwgbGFiZWxzUmVmLCBsYWJlbF0pO1xuICBpbmRleCgoKSA9PiB7XG4gICAgY29uc3Qgbm9kZSA9IGNvbXBvbmVudFJlZi5jdXJyZW50O1xuICAgIGlmIChub2RlKSB7XG4gICAgICByZWdpc3Rlcihub2RlKTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIHVucmVnaXN0ZXIobm9kZSk7XG4gICAgICB9O1xuICAgIH1cbiAgfSwgW3JlZ2lzdGVyLCB1bnJlZ2lzdGVyXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBjb25zdCBpbmRleCA9IGNvbXBvbmVudFJlZi5jdXJyZW50ID8gbWFwLmdldChjb21wb25lbnRSZWYuY3VycmVudCkgOiBudWxsO1xuICAgIGlmIChpbmRleCAhPSBudWxsKSB7XG4gICAgICBzZXRJbmRleChpbmRleCk7XG4gICAgfVxuICB9LCBbbWFwXSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgcmVmLFxuICAgIGluZGV4OiBpbmRleCQxID09IG51bGwgPyAtMSA6IGluZGV4JDFcbiAgfSksIFtpbmRleCQxLCByZWZdKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVySnN4KHJlbmRlciwgY29tcHV0ZWRQcm9wcykge1xuICBpZiAodHlwZW9mIHJlbmRlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiByZW5kZXIoY29tcHV0ZWRQcm9wcyk7XG4gIH1cbiAgaWYgKHJlbmRlcikge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY2xvbmVFbGVtZW50KHJlbmRlciwgY29tcHV0ZWRQcm9wcyk7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIGNvbXB1dGVkUHJvcHMpO1xufVxuY29uc3QgQ29tcG9zaXRlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgYWN0aXZlSW5kZXg6IDAsXG4gIG9uTmF2aWdhdGU6ICgpID0+IHt9XG59KTtcbmNvbnN0IGhvcml6b250YWxLZXlzID0gW0FSUk9XX0xFRlQsIEFSUk9XX1JJR0hUXTtcbmNvbnN0IHZlcnRpY2FsS2V5cyA9IFtBUlJPV19VUCwgQVJST1dfRE9XTl07XG5jb25zdCBhbGxLZXlzID0gWy4uLmhvcml6b250YWxLZXlzLCAuLi52ZXJ0aWNhbEtleXNdO1xuXG4vKipcbiAqIENyZWF0ZXMgYSBzaW5nbGUgdGFiIHN0b3Agd2hvc2UgaXRlbXMgYXJlIG5hdmlnYXRlZCBieSBhcnJvdyBrZXlzLCB3aGljaFxuICogcHJvdmlkZXMgbGlzdCBuYXZpZ2F0aW9uIG91dHNpZGUgb2YgZmxvYXRpbmcgZWxlbWVudCBjb250ZXh0cy5cbiAqXG4gKiBUaGlzIGlzIHVzZWZ1bCB0byBlbmFibGUgbmF2aWdhdGlvbiBvZiBhIGxpc3Qgb2YgaXRlbXMgdGhhdCBhcmVu4oCZdCBwYXJ0IG9mIGFcbiAqIGZsb2F0aW5nIGVsZW1lbnQuIEEgbWVudWJhciBpcyBhbiBleGFtcGxlIG9mIGEgY29tcG9zaXRlLCB3aXRoIGVhY2ggcmVmZXJlbmNlXG4gKiBlbGVtZW50IGJlaW5nIGFuIGl0ZW0uXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvQ29tcG9zaXRlXG4gKi9cbmNvbnN0IENvbXBvc2l0ZSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIENvbXBvc2l0ZShwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgb3JpZW50YXRpb24gPSAnYm90aCcsXG4gICAgbG9vcCA9IHRydWUsXG4gICAgcnRsID0gZmFsc2UsXG4gICAgY29scyA9IDEsXG4gICAgZGlzYWJsZWRJbmRpY2VzLFxuICAgIGFjdGl2ZUluZGV4OiBleHRlcm5hbEFjdGl2ZUluZGV4LFxuICAgIG9uTmF2aWdhdGU6IGV4dGVybmFsU2V0QWN0aXZlSW5kZXgsXG4gICAgaXRlbVNpemVzLFxuICAgIGRlbnNlID0gZmFsc2UsXG4gICAgLi4uZG9tUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBbaW50ZXJuYWxBY3RpdmVJbmRleCwgaW50ZXJuYWxTZXRBY3RpdmVJbmRleF0gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgYWN0aXZlSW5kZXggPSBleHRlcm5hbEFjdGl2ZUluZGV4ICE9IG51bGwgPyBleHRlcm5hbEFjdGl2ZUluZGV4IDogaW50ZXJuYWxBY3RpdmVJbmRleDtcbiAgY29uc3Qgb25OYXZpZ2F0ZSA9IHVzZUVmZmVjdEV2ZW50KGV4dGVybmFsU2V0QWN0aXZlSW5kZXggIT0gbnVsbCA/IGV4dGVybmFsU2V0QWN0aXZlSW5kZXggOiBpbnRlcm5hbFNldEFjdGl2ZUluZGV4KTtcbiAgY29uc3QgZWxlbWVudHNSZWYgPSBSZWFjdC51c2VSZWYoW10pO1xuICBjb25zdCByZW5kZXJFbGVtZW50UHJvcHMgPSByZW5kZXIgJiYgdHlwZW9mIHJlbmRlciAhPT0gJ2Z1bmN0aW9uJyA/IHJlbmRlci5wcm9wcyA6IHt9O1xuICBjb25zdCBjb250ZXh0VmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgYWN0aXZlSW5kZXgsXG4gICAgb25OYXZpZ2F0ZVxuICB9KSwgW2FjdGl2ZUluZGV4LCBvbk5hdmlnYXRlXSk7XG4gIGNvbnN0IGlzR3JpZCA9IGNvbHMgPiAxO1xuICBmdW5jdGlvbiBoYW5kbGVLZXlEb3duKGV2ZW50KSB7XG4gICAgaWYgKCFhbGxLZXlzLmluY2x1ZGVzKGV2ZW50LmtleSkpIHJldHVybjtcbiAgICBsZXQgbmV4dEluZGV4ID0gYWN0aXZlSW5kZXg7XG4gICAgY29uc3QgbWluSW5kZXggPSBnZXRNaW5JbmRleChlbGVtZW50c1JlZiwgZGlzYWJsZWRJbmRpY2VzKTtcbiAgICBjb25zdCBtYXhJbmRleCA9IGdldE1heEluZGV4KGVsZW1lbnRzUmVmLCBkaXNhYmxlZEluZGljZXMpO1xuICAgIGNvbnN0IGhvcml6b250YWxFbmRLZXkgPSBydGwgPyBBUlJPV19MRUZUIDogQVJST1dfUklHSFQ7XG4gICAgY29uc3QgaG9yaXpvbnRhbFN0YXJ0S2V5ID0gcnRsID8gQVJST1dfUklHSFQgOiBBUlJPV19MRUZUO1xuICAgIGlmIChpc0dyaWQpIHtcbiAgICAgIGNvbnN0IHNpemVzID0gaXRlbVNpemVzIHx8IEFycmF5LmZyb20oe1xuICAgICAgICBsZW5ndGg6IGVsZW1lbnRzUmVmLmN1cnJlbnQubGVuZ3RoXG4gICAgICB9LCAoKSA9PiAoe1xuICAgICAgICB3aWR0aDogMSxcbiAgICAgICAgaGVpZ2h0OiAxXG4gICAgICB9KSk7XG4gICAgICAvLyBUbyBjYWxjdWxhdGUgbW92ZW1lbnRzIG9uIHRoZSBncmlkLCB3ZSB1c2UgaHlwb3RoZXRpY2FsIGNlbGwgaW5kaWNlc1xuICAgICAgLy8gYXMgaWYgZXZlcnkgaXRlbSB3YXMgMXgxLCB0aGVuIGNvbnZlcnQgYmFjayB0byByZWFsIGluZGljZXMuXG4gICAgICBjb25zdCBjZWxsTWFwID0gYnVpbGRDZWxsTWFwKHNpemVzLCBjb2xzLCBkZW5zZSk7XG4gICAgICBjb25zdCBtaW5HcmlkSW5kZXggPSBjZWxsTWFwLmZpbmRJbmRleChpbmRleCA9PiBpbmRleCAhPSBudWxsICYmICFpc0Rpc2FibGVkKGVsZW1lbnRzUmVmLmN1cnJlbnQsIGluZGV4LCBkaXNhYmxlZEluZGljZXMpKTtcbiAgICAgIC8vIGxhc3QgZW5hYmxlZCBpbmRleFxuICAgICAgY29uc3QgbWF4R3JpZEluZGV4ID0gY2VsbE1hcC5yZWR1Y2UoKGZvdW5kSW5kZXgsIGluZGV4LCBjZWxsSW5kZXgpID0+IGluZGV4ICE9IG51bGwgJiYgIWlzRGlzYWJsZWQoZWxlbWVudHNSZWYuY3VycmVudCwgaW5kZXgsIGRpc2FibGVkSW5kaWNlcykgPyBjZWxsSW5kZXggOiBmb3VuZEluZGV4LCAtMSk7XG4gICAgICBjb25zdCBtYXliZU5leHRJbmRleCA9IGNlbGxNYXBbZ2V0R3JpZE5hdmlnYXRlZEluZGV4KHtcbiAgICAgICAgY3VycmVudDogY2VsbE1hcC5tYXAoaXRlbUluZGV4ID0+IGl0ZW1JbmRleCA/IGVsZW1lbnRzUmVmLmN1cnJlbnRbaXRlbUluZGV4XSA6IG51bGwpXG4gICAgICB9LCB7XG4gICAgICAgIGV2ZW50LFxuICAgICAgICBvcmllbnRhdGlvbixcbiAgICAgICAgbG9vcCxcbiAgICAgICAgcnRsLFxuICAgICAgICBjb2xzLFxuICAgICAgICAvLyB0cmVhdCB1bmRlZmluZWQgKGVtcHR5IGdyaWQgc3BhY2VzKSBhcyBkaXNhYmxlZCBpbmRpY2VzIHNvIHdlXG4gICAgICAgIC8vIGRvbid0IGVuZCB1cCBpbiB0aGVtXG4gICAgICAgIGRpc2FibGVkSW5kaWNlczogZ2V0Q2VsbEluZGljZXMoWy4uLihkaXNhYmxlZEluZGljZXMgfHwgZWxlbWVudHNSZWYuY3VycmVudC5tYXAoKF8sIGluZGV4KSA9PiBpc0Rpc2FibGVkKGVsZW1lbnRzUmVmLmN1cnJlbnQsIGluZGV4KSA/IGluZGV4IDogdW5kZWZpbmVkKSksIHVuZGVmaW5lZF0sIGNlbGxNYXApLFxuICAgICAgICBtaW5JbmRleDogbWluR3JpZEluZGV4LFxuICAgICAgICBtYXhJbmRleDogbWF4R3JpZEluZGV4LFxuICAgICAgICBwcmV2SW5kZXg6IGdldENlbGxJbmRleE9mQ29ybmVyKGFjdGl2ZUluZGV4ID4gbWF4SW5kZXggPyBtaW5JbmRleCA6IGFjdGl2ZUluZGV4LCBzaXplcywgY2VsbE1hcCwgY29scyxcbiAgICAgICAgLy8gdXNlIGEgY29ybmVyIG1hdGNoaW5nIHRoZSBlZGdlIGNsb3Nlc3QgdG8gdGhlIGRpcmVjdGlvbiB3ZSdyZVxuICAgICAgICAvLyBtb3ZpbmcgaW4gc28gd2UgZG9uJ3QgZW5kIHVwIGluIHRoZSBzYW1lIGl0ZW0uIFByZWZlclxuICAgICAgICAvLyB0b3AvbGVmdCBvdmVyIGJvdHRvbS9yaWdodC5cbiAgICAgICAgZXZlbnQua2V5ID09PSBBUlJPV19ET1dOID8gJ2JsJyA6IGV2ZW50LmtleSA9PT0gaG9yaXpvbnRhbEVuZEtleSA/ICd0cicgOiAndGwnKVxuICAgICAgfSldO1xuICAgICAgaWYgKG1heWJlTmV4dEluZGV4ICE9IG51bGwpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gbWF5YmVOZXh0SW5kZXg7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHRvRW5kS2V5cyA9IHtcbiAgICAgIGhvcml6b250YWw6IFtob3Jpem9udGFsRW5kS2V5XSxcbiAgICAgIHZlcnRpY2FsOiBbQVJST1dfRE9XTl0sXG4gICAgICBib3RoOiBbaG9yaXpvbnRhbEVuZEtleSwgQVJST1dfRE9XTl1cbiAgICB9W29yaWVudGF0aW9uXTtcbiAgICBjb25zdCB0b1N0YXJ0S2V5cyA9IHtcbiAgICAgIGhvcml6b250YWw6IFtob3Jpem9udGFsU3RhcnRLZXldLFxuICAgICAgdmVydGljYWw6IFtBUlJPV19VUF0sXG4gICAgICBib3RoOiBbaG9yaXpvbnRhbFN0YXJ0S2V5LCBBUlJPV19VUF1cbiAgICB9W29yaWVudGF0aW9uXTtcbiAgICBjb25zdCBwcmV2ZW50ZWRLZXlzID0gaXNHcmlkID8gYWxsS2V5cyA6IHtcbiAgICAgIGhvcml6b250YWw6IGhvcml6b250YWxLZXlzLFxuICAgICAgdmVydGljYWw6IHZlcnRpY2FsS2V5cyxcbiAgICAgIGJvdGg6IGFsbEtleXNcbiAgICB9W29yaWVudGF0aW9uXTtcbiAgICBpZiAobmV4dEluZGV4ID09PSBhY3RpdmVJbmRleCAmJiBbLi4udG9FbmRLZXlzLCAuLi50b1N0YXJ0S2V5c10uaW5jbHVkZXMoZXZlbnQua2V5KSkge1xuICAgICAgaWYgKGxvb3AgJiYgbmV4dEluZGV4ID09PSBtYXhJbmRleCAmJiB0b0VuZEtleXMuaW5jbHVkZXMoZXZlbnQua2V5KSkge1xuICAgICAgICBuZXh0SW5kZXggPSBtaW5JbmRleDtcbiAgICAgIH0gZWxzZSBpZiAobG9vcCAmJiBuZXh0SW5kZXggPT09IG1pbkluZGV4ICYmIHRvU3RhcnRLZXlzLmluY2x1ZGVzKGV2ZW50LmtleSkpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gbWF4SW5kZXg7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRJbmRleChlbGVtZW50c1JlZiwge1xuICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IG5leHRJbmRleCxcbiAgICAgICAgICBkZWNyZW1lbnQ6IHRvU3RhcnRLZXlzLmluY2x1ZGVzKGV2ZW50LmtleSksXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobmV4dEluZGV4ICE9PSBhY3RpdmVJbmRleCAmJiAhaXNJbmRleE91dE9mQm91bmRzKGVsZW1lbnRzUmVmLCBuZXh0SW5kZXgpKSB7XG4gICAgICB2YXIgX2VsZW1lbnRzUmVmJGN1cnJlbnQkO1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBpZiAocHJldmVudGVkS2V5cy5pbmNsdWRlcyhldmVudC5rZXkpKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9XG4gICAgICBvbk5hdmlnYXRlKG5leHRJbmRleCk7XG4gICAgICAoX2VsZW1lbnRzUmVmJGN1cnJlbnQkID0gZWxlbWVudHNSZWYuY3VycmVudFtuZXh0SW5kZXhdKSA9PSBudWxsIHx8IF9lbGVtZW50c1JlZiRjdXJyZW50JC5mb2N1cygpO1xuICAgIH1cbiAgfVxuICBjb25zdCBjb21wdXRlZFByb3BzID0ge1xuICAgIC4uLmRvbVByb3BzLFxuICAgIC4uLnJlbmRlckVsZW1lbnRQcm9wcyxcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAnYXJpYS1vcmllbnRhdGlvbic6IG9yaWVudGF0aW9uID09PSAnYm90aCcgPyB1bmRlZmluZWQgOiBvcmllbnRhdGlvbixcbiAgICBvbktleURvd24oZSkge1xuICAgICAgZG9tUHJvcHMub25LZXlEb3duID09IG51bGwgfHwgZG9tUHJvcHMub25LZXlEb3duKGUpO1xuICAgICAgcmVuZGVyRWxlbWVudFByb3BzLm9uS2V5RG93biA9PSBudWxsIHx8IHJlbmRlckVsZW1lbnRQcm9wcy5vbktleURvd24oZSk7XG4gICAgICBoYW5kbGVLZXlEb3duKGUpO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KENvbXBvc2l0ZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogY29udGV4dFZhbHVlXG4gIH0sIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEZsb2F0aW5nTGlzdCwge1xuICAgIGVsZW1lbnRzUmVmOiBlbGVtZW50c1JlZlxuICB9LCByZW5kZXJKc3gocmVuZGVyLCBjb21wdXRlZFByb3BzKSkpO1xufSk7XG4vKipcbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9Db21wb3NpdGVcbiAqL1xuY29uc3QgQ29tcG9zaXRlSXRlbSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIENvbXBvc2l0ZUl0ZW0ocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIC4uLmRvbVByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgcmVuZGVyRWxlbWVudFByb3BzID0gcmVuZGVyICYmIHR5cGVvZiByZW5kZXIgIT09ICdmdW5jdGlvbicgPyByZW5kZXIucHJvcHMgOiB7fTtcbiAgY29uc3Qge1xuICAgIGFjdGl2ZUluZGV4LFxuICAgIG9uTmF2aWdhdGVcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoQ29tcG9zaXRlQ29udGV4dCk7XG4gIGNvbnN0IHtcbiAgICByZWYsXG4gICAgaW5kZXhcbiAgfSA9IHVzZUxpc3RJdGVtKCk7XG4gIGNvbnN0IG1lcmdlZFJlZiA9IHVzZU1lcmdlUmVmcyhbcmVmLCBmb3J3YXJkZWRSZWYsIHJlbmRlckVsZW1lbnRQcm9wcy5yZWZdKTtcbiAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVJbmRleCA9PT0gaW5kZXg7XG4gIGNvbnN0IGNvbXB1dGVkUHJvcHMgPSB7XG4gICAgLi4uZG9tUHJvcHMsXG4gICAgLi4ucmVuZGVyRWxlbWVudFByb3BzLFxuICAgIHJlZjogbWVyZ2VkUmVmLFxuICAgIHRhYkluZGV4OiBpc0FjdGl2ZSA/IDAgOiAtMSxcbiAgICAnZGF0YS1hY3RpdmUnOiBpc0FjdGl2ZSA/ICcnIDogdW5kZWZpbmVkLFxuICAgIG9uRm9jdXMoZSkge1xuICAgICAgZG9tUHJvcHMub25Gb2N1cyA9PSBudWxsIHx8IGRvbVByb3BzLm9uRm9jdXMoZSk7XG4gICAgICByZW5kZXJFbGVtZW50UHJvcHMub25Gb2N1cyA9PSBudWxsIHx8IHJlbmRlckVsZW1lbnRQcm9wcy5vbkZvY3VzKGUpO1xuICAgICAgb25OYXZpZ2F0ZShpbmRleCk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gcmVuZGVySnN4KHJlbmRlciwgY29tcHV0ZWRQcm9wcyk7XG59KTtcblxuZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIF9leHRlbmRzID0gT2JqZWN0LmFzc2lnbiA/IE9iamVjdC5hc3NpZ24uYmluZCgpIDogZnVuY3Rpb24gKHRhcmdldCkge1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldO1xuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfTtcbiAgcmV0dXJuIF9leHRlbmRzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbmxldCBzZXJ2ZXJIYW5kb2ZmQ29tcGxldGUgPSBmYWxzZTtcbmxldCBjb3VudCA9IDA7XG5jb25zdCBnZW5JZCA9ICgpID0+IC8vIEVuc3VyZSB0aGUgaWQgaXMgdW5pcXVlIHdpdGggbXVsdGlwbGUgaW5kZXBlbmRlbnQgdmVyc2lvbnMgb2YgRmxvYXRpbmcgVUlcbi8vIG9uIDxSZWFjdCAxOFxuXCJmbG9hdGluZy11aS1cIiArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIsIDYpICsgY291bnQrKztcbmZ1bmN0aW9uIHVzZUZsb2F0aW5nSWQoKSB7XG4gIGNvbnN0IFtpZCwgc2V0SWRdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gc2VydmVySGFuZG9mZkNvbXBsZXRlID8gZ2VuSWQoKSA6IHVuZGVmaW5lZCk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBpZiAoaWQgPT0gbnVsbCkge1xuICAgICAgc2V0SWQoZ2VuSWQoKSk7XG4gICAgfVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNlcnZlckhhbmRvZmZDb21wbGV0ZSA9IHRydWU7XG4gIH0sIFtdKTtcbiAgcmV0dXJuIGlkO1xufVxuY29uc3QgdXNlUmVhY3RJZCA9IFNhZmVSZWFjdC51c2VJZDtcblxuLyoqXG4gKiBVc2VzIFJlYWN0IDE4J3MgYnVpbHQtaW4gYHVzZUlkKClgIHdoZW4gYXZhaWxhYmxlLCBvciBmYWxscyBiYWNrIHRvIGFcbiAqIHNsaWdodGx5IGxlc3MgcGVyZm9ybWFudCAocmVxdWlyaW5nIGEgZG91YmxlIHJlbmRlcikgaW1wbGVtZW50YXRpb24gZm9yXG4gKiBlYXJsaWVyIFJlYWN0IHZlcnNpb25zLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3JlYWN0LXV0aWxzI3VzZWlkXG4gKi9cbmNvbnN0IHVzZUlkID0gdXNlUmVhY3RJZCB8fCB1c2VGbG9hdGluZ0lkO1xuXG5sZXQgZGV2TWVzc2FnZVNldDtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgZGV2TWVzc2FnZVNldCA9IC8qI19fUFVSRV9fKi9uZXcgU2V0KCk7XG59XG5mdW5jdGlvbiB3YXJuKCkge1xuICB2YXIgX2Rldk1lc3NhZ2VTZXQ7XG4gIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBtZXNzYWdlcyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICBtZXNzYWdlc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgfVxuICBjb25zdCBtZXNzYWdlID0gXCJGbG9hdGluZyBVSTogXCIgKyBtZXNzYWdlcy5qb2luKCcgJyk7XG4gIGlmICghKChfZGV2TWVzc2FnZVNldCA9IGRldk1lc3NhZ2VTZXQpICE9IG51bGwgJiYgX2Rldk1lc3NhZ2VTZXQuaGFzKG1lc3NhZ2UpKSkge1xuICAgIHZhciBfZGV2TWVzc2FnZVNldDI7XG4gICAgKF9kZXZNZXNzYWdlU2V0MiA9IGRldk1lc3NhZ2VTZXQpID09IG51bGwgfHwgX2Rldk1lc3NhZ2VTZXQyLmFkZChtZXNzYWdlKTtcbiAgICBjb25zb2xlLndhcm4obWVzc2FnZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGVycm9yKCkge1xuICB2YXIgX2Rldk1lc3NhZ2VTZXQzO1xuICBmb3IgKHZhciBfbGVuMiA9IGFyZ3VtZW50cy5sZW5ndGgsIG1lc3NhZ2VzID0gbmV3IEFycmF5KF9sZW4yKSwgX2tleTIgPSAwOyBfa2V5MiA8IF9sZW4yOyBfa2V5MisrKSB7XG4gICAgbWVzc2FnZXNbX2tleTJdID0gYXJndW1lbnRzW19rZXkyXTtcbiAgfVxuICBjb25zdCBtZXNzYWdlID0gXCJGbG9hdGluZyBVSTogXCIgKyBtZXNzYWdlcy5qb2luKCcgJyk7XG4gIGlmICghKChfZGV2TWVzc2FnZVNldDMgPSBkZXZNZXNzYWdlU2V0KSAhPSBudWxsICYmIF9kZXZNZXNzYWdlU2V0My5oYXMobWVzc2FnZSkpKSB7XG4gICAgdmFyIF9kZXZNZXNzYWdlU2V0NDtcbiAgICAoX2Rldk1lc3NhZ2VTZXQ0ID0gZGV2TWVzc2FnZVNldCkgPT0gbnVsbCB8fCBfZGV2TWVzc2FnZVNldDQuYWRkKG1lc3NhZ2UpO1xuICAgIGNvbnNvbGUuZXJyb3IobWVzc2FnZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZW5kZXJzIGEgcG9pbnRpbmcgYXJyb3cgdHJpYW5nbGUuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdBcnJvd1xuICovXG5jb25zdCBGbG9hdGluZ0Fycm93ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRmxvYXRpbmdBcnJvdyhwcm9wcywgcmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjb250ZXh0OiB7XG4gICAgICBwbGFjZW1lbnQsXG4gICAgICBlbGVtZW50czoge1xuICAgICAgICBmbG9hdGluZ1xuICAgICAgfSxcbiAgICAgIG1pZGRsZXdhcmVEYXRhOiB7XG4gICAgICAgIGFycm93LFxuICAgICAgICBzaGlmdFxuICAgICAgfVxuICAgIH0sXG4gICAgd2lkdGggPSAxNCxcbiAgICBoZWlnaHQgPSA3LFxuICAgIHRpcFJhZGl1cyA9IDAsXG4gICAgc3Ryb2tlV2lkdGggPSAwLFxuICAgIHN0YXRpY09mZnNldCxcbiAgICBzdHJva2UsXG4gICAgZCxcbiAgICBzdHlsZToge1xuICAgICAgdHJhbnNmb3JtLFxuICAgICAgLi4ucmVzdFN0eWxlXG4gICAgfSA9IHt9LFxuICAgIC4uLnJlc3RcbiAgfSA9IHByb3BzO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKCFyZWYpIHtcbiAgICAgIHdhcm4oJ1RoZSBgcmVmYCBwcm9wIGlzIHJlcXVpcmVkIGZvciBgRmxvYXRpbmdBcnJvd2AuJyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGNsaXBQYXRoSWQgPSB1c2VJZCgpO1xuICBjb25zdCBbaXNSVEwsIHNldElzUlRMXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzI5MzJcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmICghZmxvYXRpbmcpIHJldHVybjtcbiAgICBjb25zdCBpc1JUTCA9IGdldENvbXB1dGVkU3R5bGUoZmxvYXRpbmcpLmRpcmVjdGlvbiA9PT0gJ3J0bCc7XG4gICAgaWYgKGlzUlRMKSB7XG4gICAgICBzZXRJc1JUTCh0cnVlKTtcbiAgICB9XG4gIH0sIFtmbG9hdGluZ10pO1xuICBpZiAoIWZsb2F0aW5nKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgW3NpZGUsIGFsaWdubWVudF0gPSBwbGFjZW1lbnQuc3BsaXQoJy0nKTtcbiAgY29uc3QgaXNWZXJ0aWNhbFNpZGUgPSBzaWRlID09PSAndG9wJyB8fCBzaWRlID09PSAnYm90dG9tJztcbiAgbGV0IGNvbXB1dGVkU3RhdGljT2Zmc2V0ID0gc3RhdGljT2Zmc2V0O1xuICBpZiAoaXNWZXJ0aWNhbFNpZGUgJiYgc2hpZnQgIT0gbnVsbCAmJiBzaGlmdC54IHx8ICFpc1ZlcnRpY2FsU2lkZSAmJiBzaGlmdCAhPSBudWxsICYmIHNoaWZ0LnkpIHtcbiAgICBjb21wdXRlZFN0YXRpY09mZnNldCA9IG51bGw7XG4gIH1cblxuICAvLyBTdHJva2VzIG11c3QgYmUgZG91YmxlIHRoZSBib3JkZXIgd2lkdGgsIHRoaXMgZW5zdXJlcyB0aGUgc3Ryb2tlJ3Mgd2lkdGhcbiAgLy8gd29ya3MgYXMgeW91J2QgZXhwZWN0LlxuICBjb25zdCBjb21wdXRlZFN0cm9rZVdpZHRoID0gc3Ryb2tlV2lkdGggKiAyO1xuICBjb25zdCBoYWxmU3Ryb2tlV2lkdGggPSBjb21wdXRlZFN0cm9rZVdpZHRoIC8gMjtcbiAgY29uc3Qgc3ZnWCA9IHdpZHRoIC8gMiAqICh0aXBSYWRpdXMgLyAtOCArIDEpO1xuICBjb25zdCBzdmdZID0gaGVpZ2h0IC8gMiAqIHRpcFJhZGl1cyAvIDQ7XG4gIGNvbnN0IGlzQ3VzdG9tU2hhcGUgPSAhIWQ7XG4gIGNvbnN0IHlPZmZzZXRQcm9wID0gY29tcHV0ZWRTdGF0aWNPZmZzZXQgJiYgYWxpZ25tZW50ID09PSAnZW5kJyA/ICdib3R0b20nIDogJ3RvcCc7XG4gIGxldCB4T2Zmc2V0UHJvcCA9IGNvbXB1dGVkU3RhdGljT2Zmc2V0ICYmIGFsaWdubWVudCA9PT0gJ2VuZCcgPyAncmlnaHQnIDogJ2xlZnQnO1xuICBpZiAoY29tcHV0ZWRTdGF0aWNPZmZzZXQgJiYgaXNSVEwpIHtcbiAgICB4T2Zmc2V0UHJvcCA9IGFsaWdubWVudCA9PT0gJ2VuZCcgPyAnbGVmdCcgOiAncmlnaHQnO1xuICB9XG4gIGNvbnN0IGFycm93WCA9IChhcnJvdyA9PSBudWxsID8gdm9pZCAwIDogYXJyb3cueCkgIT0gbnVsbCA/IGNvbXB1dGVkU3RhdGljT2Zmc2V0IHx8IGFycm93LnggOiAnJztcbiAgY29uc3QgYXJyb3dZID0gKGFycm93ID09IG51bGwgPyB2b2lkIDAgOiBhcnJvdy55KSAhPSBudWxsID8gY29tcHV0ZWRTdGF0aWNPZmZzZXQgfHwgYXJyb3cueSA6ICcnO1xuICBjb25zdCBkVmFsdWUgPSBkIHx8ICdNMCwwJyArIChcIiBIXCIgKyB3aWR0aCkgKyAoXCIgTFwiICsgKHdpZHRoIC0gc3ZnWCkgKyBcIixcIiArIChoZWlnaHQgLSBzdmdZKSkgKyAoXCIgUVwiICsgd2lkdGggLyAyICsgXCIsXCIgKyBoZWlnaHQgKyBcIiBcIiArIHN2Z1ggKyBcIixcIiArIChoZWlnaHQgLSBzdmdZKSkgKyAnIFonO1xuICBjb25zdCByb3RhdGlvbiA9IHtcbiAgICB0b3A6IGlzQ3VzdG9tU2hhcGUgPyAncm90YXRlKDE4MGRlZyknIDogJycsXG4gICAgbGVmdDogaXNDdXN0b21TaGFwZSA/ICdyb3RhdGUoOTBkZWcpJyA6ICdyb3RhdGUoLTkwZGVnKScsXG4gICAgYm90dG9tOiBpc0N1c3RvbVNoYXBlID8gJycgOiAncm90YXRlKDE4MGRlZyknLFxuICAgIHJpZ2h0OiBpc0N1c3RvbVNoYXBlID8gJ3JvdGF0ZSgtOTBkZWcpJyA6ICdyb3RhdGUoOTBkZWcpJ1xuICB9W3NpZGVdO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzdmdcIiwgX2V4dGVuZHMoe30sIHJlc3QsIHtcbiAgICBcImFyaWEtaGlkZGVuXCI6IHRydWUsXG4gICAgcmVmOiByZWYsXG4gICAgd2lkdGg6IGlzQ3VzdG9tU2hhcGUgPyB3aWR0aCA6IHdpZHRoICsgY29tcHV0ZWRTdHJva2VXaWR0aCxcbiAgICBoZWlnaHQ6IHdpZHRoLFxuICAgIHZpZXdCb3g6IFwiMCAwIFwiICsgd2lkdGggKyBcIiBcIiArIChoZWlnaHQgPiB3aWR0aCA/IGhlaWdodCA6IHdpZHRoKSxcbiAgICBzdHlsZToge1xuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICBwb2ludGVyRXZlbnRzOiAnbm9uZScsXG4gICAgICBbeE9mZnNldFByb3BdOiBhcnJvd1gsXG4gICAgICBbeU9mZnNldFByb3BdOiBhcnJvd1ksXG4gICAgICBbc2lkZV06IGlzVmVydGljYWxTaWRlIHx8IGlzQ3VzdG9tU2hhcGUgPyAnMTAwJScgOiBcImNhbGMoMTAwJSAtIFwiICsgY29tcHV0ZWRTdHJva2VXaWR0aCAvIDIgKyBcInB4KVwiLFxuICAgICAgdHJhbnNmb3JtOiBbcm90YXRpb24sIHRyYW5zZm9ybV0uZmlsdGVyKHQgPT4gISF0KS5qb2luKCcgJyksXG4gICAgICAuLi5yZXN0U3R5bGVcbiAgICB9XG4gIH0pLCBjb21wdXRlZFN0cm9rZVdpZHRoID4gMCAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuICAgIGNsaXBQYXRoOiBcInVybCgjXCIgKyBjbGlwUGF0aElkICsgXCIpXCIsXG4gICAgZmlsbDogXCJub25lXCIsXG4gICAgc3Ryb2tlOiBzdHJva2VcbiAgICAvLyBBY2NvdW50IGZvciB0aGUgc3Ryb2tlIG9uIHRoZSBmaWxsIHBhdGggcmVuZGVyZWQgYmVsb3cuXG4gICAgLFxuICAgIHN0cm9rZVdpZHRoOiBjb21wdXRlZFN0cm9rZVdpZHRoICsgKGQgPyAwIDogMSksXG4gICAgZDogZFZhbHVlXG4gIH0pLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInBhdGhcIiwge1xuICAgIHN0cm9rZTogY29tcHV0ZWRTdHJva2VXaWR0aCAmJiAhZCA/IHJlc3QuZmlsbCA6ICdub25lJyxcbiAgICBkOiBkVmFsdWVcbiAgfSksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiY2xpcFBhdGhcIiwge1xuICAgIGlkOiBjbGlwUGF0aElkXG4gIH0sIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwicmVjdFwiLCB7XG4gICAgeDogLWhhbGZTdHJva2VXaWR0aCxcbiAgICB5OiBoYWxmU3Ryb2tlV2lkdGggKiAoaXNDdXN0b21TaGFwZSA/IC0xIDogMSksXG4gICAgd2lkdGg6IHdpZHRoICsgY29tcHV0ZWRTdHJva2VXaWR0aCxcbiAgICBoZWlnaHQ6IHdpZHRoXG4gIH0pKSk7XG59KTtcblxuZnVuY3Rpb24gY3JlYXRlUHViU3ViKCkge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gIHJldHVybiB7XG4gICAgZW1pdChldmVudCwgZGF0YSkge1xuICAgICAgdmFyIF9tYXAkZ2V0O1xuICAgICAgKF9tYXAkZ2V0ID0gbWFwLmdldChldmVudCkpID09IG51bGwgfHwgX21hcCRnZXQuZm9yRWFjaChoYW5kbGVyID0+IGhhbmRsZXIoZGF0YSkpO1xuICAgIH0sXG4gICAgb24oZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgICBtYXAuc2V0KGV2ZW50LCBbLi4uKG1hcC5nZXQoZXZlbnQpIHx8IFtdKSwgbGlzdGVuZXJdKTtcbiAgICB9LFxuICAgIG9mZihldmVudCwgbGlzdGVuZXIpIHtcbiAgICAgIHZhciBfbWFwJGdldDI7XG4gICAgICBtYXAuc2V0KGV2ZW50LCAoKF9tYXAkZ2V0MiA9IG1hcC5nZXQoZXZlbnQpKSA9PSBudWxsID8gdm9pZCAwIDogX21hcCRnZXQyLmZpbHRlcihsID0+IGwgIT09IGxpc3RlbmVyKSkgfHwgW10pO1xuICAgIH1cbiAgfTtcbn1cblxuY29uc3QgRmxvYXRpbmdOb2RlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuY29uc3QgRmxvYXRpbmdUcmVlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuXG4vKipcbiAqIFJldHVybnMgdGhlIHBhcmVudCBub2RlIGlkIGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMsIGlmIGF2YWlsYWJsZS5cbiAqIFJldHVybnMgYG51bGxgIGZvciB0b3AtbGV2ZWwgZmxvYXRpbmcgZWxlbWVudHMuXG4gKi9cbmNvbnN0IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkID0gKCkgPT4ge1xuICB2YXIgX1JlYWN0JHVzZUNvbnRleHQ7XG4gIHJldHVybiAoKF9SZWFjdCR1c2VDb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChGbG9hdGluZ05vZGVDb250ZXh0KSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9SZWFjdCR1c2VDb250ZXh0LmlkKSB8fCBudWxsO1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBuZWFyZXN0IGZsb2F0aW5nIHRyZWUgY29udGV4dCwgaWYgYXZhaWxhYmxlLlxuICovXG5jb25zdCB1c2VGbG9hdGluZ1RyZWUgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KEZsb2F0aW5nVHJlZUNvbnRleHQpO1xuXG4vKipcbiAqIFJlZ2lzdGVycyBhIG5vZGUgaW50byB0aGUgYEZsb2F0aW5nVHJlZWAsIHJldHVybmluZyBpdHMgaWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdUcmVlXG4gKi9cbmZ1bmN0aW9uIHVzZUZsb2F0aW5nTm9kZUlkKGN1c3RvbVBhcmVudElkKSB7XG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZSgpO1xuICBjb25zdCByZWFjdFBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgY29uc3QgcGFyZW50SWQgPSBjdXN0b21QYXJlbnRJZCB8fCByZWFjdFBhcmVudElkO1xuICBpbmRleCgoKSA9PiB7XG4gICAgY29uc3Qgbm9kZSA9IHtcbiAgICAgIGlkLFxuICAgICAgcGFyZW50SWRcbiAgICB9O1xuICAgIHRyZWUgPT0gbnVsbCB8fCB0cmVlLmFkZE5vZGUobm9kZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRyZWUgPT0gbnVsbCB8fCB0cmVlLnJlbW92ZU5vZGUobm9kZSk7XG4gICAgfTtcbiAgfSwgW3RyZWUsIGlkLCBwYXJlbnRJZF0pO1xuICByZXR1cm4gaWQ7XG59XG4vKipcbiAqIFByb3ZpZGVzIHBhcmVudCBub2RlIGNvbnRleHQgZm9yIG5lc3RlZCBmbG9hdGluZyBlbGVtZW50cy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1RyZWVcbiAqL1xuZnVuY3Rpb24gRmxvYXRpbmdOb2RlKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICBpZFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEZsb2F0aW5nTm9kZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgaWQsXG4gICAgICBwYXJlbnRJZFxuICAgIH0pLCBbaWQsIHBhcmVudElkXSlcbiAgfSwgY2hpbGRyZW4pO1xufVxuLyoqXG4gKiBQcm92aWRlcyBjb250ZXh0IGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgd2hlbiB0aGV5IGFyZSBub3QgY2hpbGRyZW4gb2ZcbiAqIGVhY2ggb3RoZXIgb24gdGhlIERPTS5cbiAqIFRoaXMgaXMgbm90IG5lY2Vzc2FyeSBpbiBhbGwgY2FzZXMsIGV4Y2VwdCB3aGVuIHRoZXJlIG11c3QgYmUgZXhwbGljaXQgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHBhcmVudCBhbmQgY2hpbGQgZmxvYXRpbmcgZWxlbWVudHMuIEl0IGlzIG5lY2Vzc2FyeSBmb3I6XG4gKiAtIFRoZSBgYnViYmxlc2Agb3B0aW9uIGluIHRoZSBgdXNlRGlzbWlzcygpYCBIb29rXG4gKiAtIE5lc3RlZCB2aXJ0dWFsIGxpc3QgbmF2aWdhdGlvblxuICogLSBOZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgdGhhdCBlYWNoIG9wZW4gb24gaG92ZXJcbiAqIC0gQ3VzdG9tIGNvbW11bmljYXRpb24gYmV0d2VlbiBwYXJlbnQgYW5kIGNoaWxkIGZsb2F0aW5nIGVsZW1lbnRzXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdUcmVlXG4gKi9cbmZ1bmN0aW9uIEZsb2F0aW5nVHJlZShwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW5cbiAgfSA9IHByb3BzO1xuICBjb25zdCBub2Rlc1JlZiA9IFJlYWN0LnVzZVJlZihbXSk7XG4gIGNvbnN0IGFkZE5vZGUgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBub2Rlc1JlZi5jdXJyZW50ID0gWy4uLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVdO1xuICB9LCBbXSk7XG4gIGNvbnN0IHJlbW92ZU5vZGUgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBub2Rlc1JlZi5jdXJyZW50ID0gbm9kZXNSZWYuY3VycmVudC5maWx0ZXIobiA9PiBuICE9PSBub2RlKTtcbiAgfSwgW10pO1xuICBjb25zdCBldmVudHMgPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBjcmVhdGVQdWJTdWIoKSlbMF07XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGbG9hdGluZ1RyZWVDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgIG5vZGVzUmVmLFxuICAgICAgYWRkTm9kZSxcbiAgICAgIHJlbW92ZU5vZGUsXG4gICAgICBldmVudHNcbiAgICB9KSwgW2FkZE5vZGUsIHJlbW92ZU5vZGUsIGV2ZW50c10pXG4gIH0sIGNoaWxkcmVuKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlQXR0cmlidXRlKG5hbWUpIHtcbiAgcmV0dXJuIFwiZGF0YS1mbG9hdGluZy11aS1cIiArIG5hbWU7XG59XG5cbmZ1bmN0aW9uIHVzZUxhdGVzdFJlZih2YWx1ZSkge1xuICBjb25zdCByZWYgPSB1c2VSZWYodmFsdWUpO1xuICBpbmRleCgoKSA9PiB7XG4gICAgcmVmLmN1cnJlbnQgPSB2YWx1ZTtcbiAgfSk7XG4gIHJldHVybiByZWY7XG59XG5cbmNvbnN0IHNhZmVQb2x5Z29uSWRlbnRpZmllciA9IC8qI19fUFVSRV9fKi9jcmVhdGVBdHRyaWJ1dGUoJ3NhZmUtcG9seWdvbicpO1xuZnVuY3Rpb24gZ2V0RGVsYXkodmFsdWUsIHByb3AsIHBvaW50ZXJUeXBlKSB7XG4gIGlmIChwb2ludGVyVHlwZSAmJiAhaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSkpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgPT0gbnVsbCA/IHZvaWQgMCA6IHZhbHVlW3Byb3BdO1xufVxuLyoqXG4gKiBPcGVucyB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGlsZSBob3ZlcmluZyBvdmVyIHRoZSByZWZlcmVuY2UgZWxlbWVudCwgbGlrZVxuICogQ1NTIGA6aG92ZXJgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3VzZUhvdmVyXG4gKi9cbmZ1bmN0aW9uIHVzZUhvdmVyKGNvbnRleHQsIHByb3BzKSB7XG4gIGlmIChwcm9wcyA9PT0gdm9pZCAwKSB7XG4gICAgcHJvcHMgPSB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgb3BlbixcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgZGF0YVJlZixcbiAgICBldmVudHMsXG4gICAgZWxlbWVudHNcbiAgfSA9IGNvbnRleHQ7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBkZWxheSA9IDAsXG4gICAgaGFuZGxlQ2xvc2UgPSBudWxsLFxuICAgIG1vdXNlT25seSA9IGZhbHNlLFxuICAgIHJlc3RNcyA9IDAsXG4gICAgbW92ZSA9IHRydWVcbiAgfSA9IHByb3BzO1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKCk7XG4gIGNvbnN0IHBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgY29uc3QgaGFuZGxlQ2xvc2VSZWYgPSB1c2VMYXRlc3RSZWYoaGFuZGxlQ2xvc2UpO1xuICBjb25zdCBkZWxheVJlZiA9IHVzZUxhdGVzdFJlZihkZWxheSk7XG4gIGNvbnN0IG9wZW5SZWYgPSB1c2VMYXRlc3RSZWYob3Blbik7XG4gIGNvbnN0IHBvaW50ZXJUeXBlUmVmID0gUmVhY3QudXNlUmVmKCk7XG4gIGNvbnN0IHRpbWVvdXRSZWYgPSBSZWFjdC51c2VSZWYoLTEpO1xuICBjb25zdCBoYW5kbGVyUmVmID0gUmVhY3QudXNlUmVmKCk7XG4gIGNvbnN0IHJlc3RUaW1lb3V0UmVmID0gUmVhY3QudXNlUmVmKC0xKTtcbiAgY29uc3QgYmxvY2tNb3VzZU1vdmVSZWYgPSBSZWFjdC51c2VSZWYodHJ1ZSk7XG4gIGNvbnN0IHBlcmZvcm1lZFBvaW50ZXJFdmVudHNNdXRhdGlvblJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHVuYmluZE1vdXNlTW92ZVJlZiA9IFJlYWN0LnVzZVJlZigoKSA9PiB7fSk7XG4gIGNvbnN0IHJlc3RUaW1lb3V0UGVuZGluZ1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGlzSG92ZXJPcGVuID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHZhciBfZGF0YVJlZiRjdXJyZW50JG9wZW47XG4gICAgY29uc3QgdHlwZSA9IChfZGF0YVJlZiRjdXJyZW50JG9wZW4gPSBkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50KSA9PSBudWxsID8gdm9pZCAwIDogX2RhdGFSZWYkY3VycmVudCRvcGVuLnR5cGU7XG4gICAgcmV0dXJuICh0eXBlID09IG51bGwgPyB2b2lkIDAgOiB0eXBlLmluY2x1ZGVzKCdtb3VzZScpKSAmJiB0eXBlICE9PSAnbW91c2Vkb3duJztcbiAgfSwgW2RhdGFSZWZdKTtcblxuICAvLyBXaGVuIGNsb3NpbmcgYmVmb3JlIG9wZW5pbmcsIGNsZWFyIHRoZSBkZWxheSB0aW1lb3V0cyB0byBjYW5jZWwgaXRcbiAgLy8gZnJvbSBzaG93aW5nLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGZ1bmN0aW9uIG9uT3BlbkNoYW5nZShfcmVmKSB7XG4gICAgICBsZXQge1xuICAgICAgICBvcGVuXG4gICAgICB9ID0gX3JlZjtcbiAgICAgIGlmICghb3Blbikge1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dFJlZi5jdXJyZW50KTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHJlc3RUaW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgICBibG9ja01vdXNlTW92ZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgcmVzdFRpbWVvdXRQZW5kaW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgZXZlbnRzLm9uKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRzLm9mZignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZSk7XG4gICAgfTtcbiAgfSwgW2VuYWJsZWQsIGV2ZW50c10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGlmICghaGFuZGxlQ2xvc2VSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGlmICghb3BlbikgcmV0dXJuO1xuICAgIGZ1bmN0aW9uIG9uTGVhdmUoZXZlbnQpIHtcbiAgICAgIGlmIChpc0hvdmVyT3BlbigpKSB7XG4gICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQsICdob3ZlcicpO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBodG1sID0gZ2V0RG9jdW1lbnQoZWxlbWVudHMuZmxvYXRpbmcpLmRvY3VtZW50RWxlbWVudDtcbiAgICBodG1sLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvbkxlYXZlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaHRtbC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWxlYXZlJywgb25MZWF2ZSk7XG4gICAgfTtcbiAgfSwgW2VsZW1lbnRzLmZsb2F0aW5nLCBvcGVuLCBvbk9wZW5DaGFuZ2UsIGVuYWJsZWQsIGhhbmRsZUNsb3NlUmVmLCBpc0hvdmVyT3Blbl0pO1xuICBjb25zdCBjbG9zZVdpdGhEZWxheSA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uIChldmVudCwgcnVuRWxzZUJyYW5jaCwgcmVhc29uKSB7XG4gICAgaWYgKHJ1bkVsc2VCcmFuY2ggPT09IHZvaWQgMCkge1xuICAgICAgcnVuRWxzZUJyYW5jaCA9IHRydWU7XG4gICAgfVxuICAgIGlmIChyZWFzb24gPT09IHZvaWQgMCkge1xuICAgICAgcmVhc29uID0gJ2hvdmVyJztcbiAgICB9XG4gICAgY29uc3QgY2xvc2VEZWxheSA9IGdldERlbGF5KGRlbGF5UmVmLmN1cnJlbnQsICdjbG9zZScsIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQpO1xuICAgIGlmIChjbG9zZURlbGF5ICYmICFoYW5kbGVyUmVmLmN1cnJlbnQpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgdGltZW91dFJlZi5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gb25PcGVuQ2hhbmdlKGZhbHNlLCBldmVudCwgcmVhc29uKSwgY2xvc2VEZWxheSk7XG4gICAgfSBlbHNlIGlmIChydW5FbHNlQnJhbmNoKSB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dFJlZi5jdXJyZW50KTtcbiAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQsIHJlYXNvbik7XG4gICAgfVxuICB9LCBbZGVsYXlSZWYsIG9uT3BlbkNoYW5nZV0pO1xuICBjb25zdCBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlciA9IHVzZUVmZmVjdEV2ZW50KCgpID0+IHtcbiAgICB1bmJpbmRNb3VzZU1vdmVSZWYuY3VycmVudCgpO1xuICAgIGhhbmRsZXJSZWYuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgfSk7XG4gIGNvbnN0IGNsZWFyUG9pbnRlckV2ZW50cyA9IHVzZUVmZmVjdEV2ZW50KCgpID0+IHtcbiAgICBpZiAocGVyZm9ybWVkUG9pbnRlckV2ZW50c011dGF0aW9uUmVmLmN1cnJlbnQpIHtcbiAgICAgIGNvbnN0IGJvZHkgPSBnZXREb2N1bWVudChlbGVtZW50cy5mbG9hdGluZykuYm9keTtcbiAgICAgIGJvZHkuc3R5bGUucG9pbnRlckV2ZW50cyA9ICcnO1xuICAgICAgYm9keS5yZW1vdmVBdHRyaWJ1dGUoc2FmZVBvbHlnb25JZGVudGlmaWVyKTtcbiAgICAgIHBlcmZvcm1lZFBvaW50ZXJFdmVudHNNdXRhdGlvblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgaXNDbGlja0xpa2VPcGVuRXZlbnQgPSB1c2VFZmZlY3RFdmVudCgoKSA9PiB7XG4gICAgcmV0dXJuIGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQgPyBbJ2NsaWNrJywgJ21vdXNlZG93biddLmluY2x1ZGVzKGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQudHlwZSkgOiBmYWxzZTtcbiAgfSk7XG5cbiAgLy8gUmVnaXN0ZXJpbmcgdGhlIG1vdXNlIGV2ZW50cyBvbiB0aGUgcmVmZXJlbmNlIGRpcmVjdGx5IHRvIGJ5cGFzcyBSZWFjdCdzXG4gIC8vIGRlbGVnYXRpb24gc3lzdGVtLiBJZiB0aGUgY3Vyc29yIHdhcyBvbiBhIGRpc2FibGVkIGVsZW1lbnQgYW5kIHRoZW4gZW50ZXJlZFxuICAvLyB0aGUgcmVmZXJlbmNlIChubyBnYXApLCBgbW91c2VlbnRlcmAgZG9lc24ndCBmaXJlIGluIHRoZSBkZWxlZ2F0aW9uIHN5c3RlbS5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHJldHVybjtcbiAgICBmdW5jdGlvbiBvbk1vdXNlRW50ZXIoZXZlbnQpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgYmxvY2tNb3VzZU1vdmVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgaWYgKG1vdXNlT25seSAmJiAhaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZVJlZi5jdXJyZW50KSB8fCByZXN0TXMgPiAwICYmICFnZXREZWxheShkZWxheVJlZi5jdXJyZW50LCAnb3BlbicpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG9wZW5EZWxheSA9IGdldERlbGF5KGRlbGF5UmVmLmN1cnJlbnQsICdvcGVuJywgcG9pbnRlclR5cGVSZWYuY3VycmVudCk7XG4gICAgICBpZiAob3BlbkRlbGF5KSB7XG4gICAgICAgIHRpbWVvdXRSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBpZiAoIW9wZW5SZWYuY3VycmVudCkge1xuICAgICAgICAgICAgb25PcGVuQ2hhbmdlKHRydWUsIGV2ZW50LCAnaG92ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIG9wZW5EZWxheSk7XG4gICAgICB9IGVsc2UgaWYgKCFvcGVuKSB7XG4gICAgICAgIG9uT3BlbkNoYW5nZSh0cnVlLCBldmVudCwgJ2hvdmVyJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uTW91c2VMZWF2ZShldmVudCkge1xuICAgICAgaWYgKGlzQ2xpY2tMaWtlT3BlbkV2ZW50KCkpIHJldHVybjtcbiAgICAgIHVuYmluZE1vdXNlTW92ZVJlZi5jdXJyZW50KCk7XG4gICAgICBjb25zdCBkb2MgPSBnZXREb2N1bWVudChlbGVtZW50cy5mbG9hdGluZyk7XG4gICAgICBjbGVhclRpbWVvdXQocmVzdFRpbWVvdXRSZWYuY3VycmVudCk7XG4gICAgICByZXN0VGltZW91dFBlbmRpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgaWYgKGhhbmRsZUNsb3NlUmVmLmN1cnJlbnQgJiYgZGF0YVJlZi5jdXJyZW50LmZsb2F0aW5nQ29udGV4dCkge1xuICAgICAgICAvLyBQcmV2ZW50IGNsZWFyaW5nIGBvblNjcm9sbE1vdXNlTGVhdmVgIHRpbWVvdXQuXG4gICAgICAgIGlmICghb3Blbikge1xuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgICB9XG4gICAgICAgIGhhbmRsZXJSZWYuY3VycmVudCA9IGhhbmRsZUNsb3NlUmVmLmN1cnJlbnQoe1xuICAgICAgICAgIC4uLmRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQsXG4gICAgICAgICAgdHJlZSxcbiAgICAgICAgICB4OiBldmVudC5jbGllbnRYLFxuICAgICAgICAgIHk6IGV2ZW50LmNsaWVudFksXG4gICAgICAgICAgb25DbG9zZSgpIHtcbiAgICAgICAgICAgIGNsZWFyUG9pbnRlckV2ZW50cygpO1xuICAgICAgICAgICAgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIoKTtcbiAgICAgICAgICAgIGlmICghaXNDbGlja0xpa2VPcGVuRXZlbnQoKSkge1xuICAgICAgICAgICAgICBjbG9zZVdpdGhEZWxheShldmVudCwgdHJ1ZSwgJ3NhZmUtcG9seWdvbicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSBoYW5kbGVyUmVmLmN1cnJlbnQ7XG4gICAgICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBoYW5kbGVyKTtcbiAgICAgICAgdW5iaW5kTW91c2VNb3ZlUmVmLmN1cnJlbnQgPSAoKSA9PiB7XG4gICAgICAgICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIGhhbmRsZXIpO1xuICAgICAgICB9O1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIEFsbG93IGludGVyYWN0aXZpdHkgd2l0aG91dCBgc2FmZVBvbHlnb25gIG9uIHRvdWNoIGRldmljZXMuIFdpdGggYVxuICAgICAgLy8gcG9pbnRlciwgYSBzaG9ydCBjbG9zZSBkZWxheSBpcyBhbiBhbHRlcm5hdGl2ZSwgc28gaXQgc2hvdWxkIHdvcmtcbiAgICAgIC8vIGNvbnNpc3RlbnRseS5cbiAgICAgIGNvbnN0IHNob3VsZENsb3NlID0gcG9pbnRlclR5cGVSZWYuY3VycmVudCA9PT0gJ3RvdWNoJyA/ICFjb250YWlucyhlbGVtZW50cy5mbG9hdGluZywgZXZlbnQucmVsYXRlZFRhcmdldCkgOiB0cnVlO1xuICAgICAgaWYgKHNob3VsZENsb3NlKSB7XG4gICAgICAgIGNsb3NlV2l0aERlbGF5KGV2ZW50KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBFbnN1cmUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgY2xvc2VzIGFmdGVyIHNjcm9sbGluZyBldmVuIGlmIHRoZSBwb2ludGVyXG4gICAgLy8gZGlkIG5vdCBtb3ZlLlxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9kaXNjdXNzaW9ucy8xNjkyXG4gICAgZnVuY3Rpb24gb25TY3JvbGxNb3VzZUxlYXZlKGV2ZW50KSB7XG4gICAgICBpZiAoaXNDbGlja0xpa2VPcGVuRXZlbnQoKSkgcmV0dXJuO1xuICAgICAgaWYgKCFkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0KSByZXR1cm47XG4gICAgICBoYW5kbGVDbG9zZVJlZi5jdXJyZW50ID09IG51bGwgfHwgaGFuZGxlQ2xvc2VSZWYuY3VycmVudCh7XG4gICAgICAgIC4uLmRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQsXG4gICAgICAgIHRyZWUsXG4gICAgICAgIHg6IGV2ZW50LmNsaWVudFgsXG4gICAgICAgIHk6IGV2ZW50LmNsaWVudFksXG4gICAgICAgIG9uQ2xvc2UoKSB7XG4gICAgICAgICAgY2xlYXJQb2ludGVyRXZlbnRzKCk7XG4gICAgICAgICAgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIoKTtcbiAgICAgICAgICBpZiAoIWlzQ2xpY2tMaWtlT3BlbkV2ZW50KCkpIHtcbiAgICAgICAgICAgIGNsb3NlV2l0aERlbGF5KGV2ZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pKGV2ZW50KTtcbiAgICB9XG4gICAgaWYgKGlzRWxlbWVudChlbGVtZW50cy5kb21SZWZlcmVuY2UpKSB7XG4gICAgICB2YXIgX2VsZW1lbnRzJGZsb2F0aW5nO1xuICAgICAgY29uc3QgcmVmID0gZWxlbWVudHMuZG9tUmVmZXJlbmNlO1xuICAgICAgb3BlbiAmJiByZWYuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VsZWF2ZScsIG9uU2Nyb2xsTW91c2VMZWF2ZSk7XG4gICAgICAoX2VsZW1lbnRzJGZsb2F0aW5nID0gZWxlbWVudHMuZmxvYXRpbmcpID09IG51bGwgfHwgX2VsZW1lbnRzJGZsb2F0aW5nLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvblNjcm9sbE1vdXNlTGVhdmUpO1xuICAgICAgbW92ZSAmJiByZWYuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZUVudGVyLCB7XG4gICAgICAgIG9uY2U6IHRydWVcbiAgICAgIH0pO1xuICAgICAgcmVmLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZW50ZXInLCBvbk1vdXNlRW50ZXIpO1xuICAgICAgcmVmLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvbk1vdXNlTGVhdmUpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgdmFyIF9lbGVtZW50cyRmbG9hdGluZzI7XG4gICAgICAgIG9wZW4gJiYgcmVmLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvblNjcm9sbE1vdXNlTGVhdmUpO1xuICAgICAgICAoX2VsZW1lbnRzJGZsb2F0aW5nMiA9IGVsZW1lbnRzLmZsb2F0aW5nKSA9PSBudWxsIHx8IF9lbGVtZW50cyRmbG9hdGluZzIucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2VsZWF2ZScsIG9uU2Nyb2xsTW91c2VMZWF2ZSk7XG4gICAgICAgIG1vdmUgJiYgcmVmLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VFbnRlcik7XG4gICAgICAgIHJlZi5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWVudGVyJywgb25Nb3VzZUVudGVyKTtcbiAgICAgICAgcmVmLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbGVhdmUnLCBvbk1vdXNlTGVhdmUpO1xuICAgICAgfTtcbiAgICB9XG4gIH0sIFtlbGVtZW50cywgZW5hYmxlZCwgY29udGV4dCwgbW91c2VPbmx5LCByZXN0TXMsIG1vdmUsIGNsb3NlV2l0aERlbGF5LCBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlciwgY2xlYXJQb2ludGVyRXZlbnRzLCBvbk9wZW5DaGFuZ2UsIG9wZW4sIG9wZW5SZWYsIHRyZWUsIGRlbGF5UmVmLCBoYW5kbGVDbG9zZVJlZiwgZGF0YVJlZiwgaXNDbGlja0xpa2VPcGVuRXZlbnRdKTtcblxuICAvLyBCbG9jayBwb2ludGVyLWV2ZW50cyBvZiBldmVyeSBlbGVtZW50IG90aGVyIHRoYW4gdGhlIHJlZmVyZW5jZSBhbmQgZmxvYXRpbmdcbiAgLy8gd2hpbGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgb3BlbiBhbmQgaGFzIGEgYGhhbmRsZUNsb3NlYCBoYW5kbGVyLiBBbHNvXG4gIC8vIGhhbmRsZXMgbmVzdGVkIGZsb2F0aW5nIGVsZW1lbnRzLlxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzE3MjJcbiAgaW5kZXgoKCkgPT4ge1xuICAgIHZhciBfaGFuZGxlQ2xvc2VSZWYkY3VycmU7XG4gICAgaWYgKCFlbmFibGVkKSByZXR1cm47XG4gICAgaWYgKG9wZW4gJiYgKF9oYW5kbGVDbG9zZVJlZiRjdXJyZSA9IGhhbmRsZUNsb3NlUmVmLmN1cnJlbnQpICE9IG51bGwgJiYgX2hhbmRsZUNsb3NlUmVmJGN1cnJlLl9fb3B0aW9ucy5ibG9ja1BvaW50ZXJFdmVudHMgJiYgaXNIb3Zlck9wZW4oKSkge1xuICAgICAgcGVyZm9ybWVkUG9pbnRlckV2ZW50c011dGF0aW9uUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgY29uc3QgZmxvYXRpbmdFbCA9IGVsZW1lbnRzLmZsb2F0aW5nO1xuICAgICAgaWYgKGlzRWxlbWVudChlbGVtZW50cy5kb21SZWZlcmVuY2UpICYmIGZsb2F0aW5nRWwpIHtcbiAgICAgICAgdmFyIF90cmVlJG5vZGVzUmVmJGN1cnJlbjtcbiAgICAgICAgY29uc3QgYm9keSA9IGdldERvY3VtZW50KGVsZW1lbnRzLmZsb2F0aW5nKS5ib2R5O1xuICAgICAgICBib2R5LnNldEF0dHJpYnV0ZShzYWZlUG9seWdvbklkZW50aWZpZXIsICcnKTtcbiAgICAgICAgY29uc3QgcmVmID0gZWxlbWVudHMuZG9tUmVmZXJlbmNlO1xuICAgICAgICBjb25zdCBwYXJlbnRGbG9hdGluZyA9IHRyZWUgPT0gbnVsbCB8fCAoX3RyZWUkbm9kZXNSZWYkY3VycmVuID0gdHJlZS5ub2Rlc1JlZi5jdXJyZW50LmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBwYXJlbnRJZCkpID09IG51bGwgfHwgKF90cmVlJG5vZGVzUmVmJGN1cnJlbiA9IF90cmVlJG5vZGVzUmVmJGN1cnJlbi5jb250ZXh0KSA9PSBudWxsID8gdm9pZCAwIDogX3RyZWUkbm9kZXNSZWYkY3VycmVuLmVsZW1lbnRzLmZsb2F0aW5nO1xuICAgICAgICBpZiAocGFyZW50RmxvYXRpbmcpIHtcbiAgICAgICAgICBwYXJlbnRGbG9hdGluZy5zdHlsZS5wb2ludGVyRXZlbnRzID0gJyc7XG4gICAgICAgIH1cbiAgICAgICAgYm9keS5zdHlsZS5wb2ludGVyRXZlbnRzID0gJ25vbmUnO1xuICAgICAgICByZWYuc3R5bGUucG9pbnRlckV2ZW50cyA9ICdhdXRvJztcbiAgICAgICAgZmxvYXRpbmdFbC5zdHlsZS5wb2ludGVyRXZlbnRzID0gJ2F1dG8nO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGJvZHkuc3R5bGUucG9pbnRlckV2ZW50cyA9ICcnO1xuICAgICAgICAgIHJlZi5zdHlsZS5wb2ludGVyRXZlbnRzID0gJyc7XG4gICAgICAgICAgZmxvYXRpbmdFbC5zdHlsZS5wb2ludGVyRXZlbnRzID0gJyc7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgcGFyZW50SWQsIGVsZW1lbnRzLCB0cmVlLCBoYW5kbGVDbG9zZVJlZiwgaXNIb3Zlck9wZW5dKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAgcG9pbnRlclR5cGVSZWYuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICAgIHJlc3RUaW1lb3V0UGVuZGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlcigpO1xuICAgICAgY2xlYXJQb2ludGVyRXZlbnRzKCk7XG4gICAgfVxuICB9LCBbb3BlbiwgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIsIGNsZWFyUG9pbnRlckV2ZW50c10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlcigpO1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRSZWYuY3VycmVudCk7XG4gICAgICBjbGVhclRpbWVvdXQocmVzdFRpbWVvdXRSZWYuY3VycmVudCk7XG4gICAgICBjbGVhclBvaW50ZXJFdmVudHMoKTtcbiAgICB9O1xuICB9LCBbZW5hYmxlZCwgZWxlbWVudHMuZG9tUmVmZXJlbmNlLCBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlciwgY2xlYXJQb2ludGVyRXZlbnRzXSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHNldFBvaW50ZXJSZWYoZXZlbnQpIHtcbiAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uUG9pbnRlckRvd246IHNldFBvaW50ZXJSZWYsXG4gICAgICBvblBvaW50ZXJFbnRlcjogc2V0UG9pbnRlclJlZixcbiAgICAgIG9uTW91c2VNb3ZlKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBuYXRpdmVFdmVudFxuICAgICAgICB9ID0gZXZlbnQ7XG4gICAgICAgIGZ1bmN0aW9uIGhhbmRsZU1vdXNlTW92ZSgpIHtcbiAgICAgICAgICBpZiAoIWJsb2NrTW91c2VNb3ZlUmVmLmN1cnJlbnQgJiYgIW9wZW5SZWYuY3VycmVudCkge1xuICAgICAgICAgICAgb25PcGVuQ2hhbmdlKHRydWUsIG5hdGl2ZUV2ZW50LCAnaG92ZXInKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1vdXNlT25seSAmJiAhaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZVJlZi5jdXJyZW50KSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3BlbiB8fCByZXN0TXMgPT09IDApIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZ25vcmUgaW5zaWduaWZpY2FudCBtb3ZlbWVudHMgdG8gYWNjb3VudCBmb3IgdHJlbW9ycy5cbiAgICAgICAgaWYgKHJlc3RUaW1lb3V0UGVuZGluZ1JlZi5jdXJyZW50ICYmIGV2ZW50Lm1vdmVtZW50WCAqKiAyICsgZXZlbnQubW92ZW1lbnRZICoqIDIgPCAyKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNsZWFyVGltZW91dChyZXN0VGltZW91dFJlZi5jdXJyZW50KTtcbiAgICAgICAgaWYgKHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPT09ICd0b3VjaCcpIHtcbiAgICAgICAgICBoYW5kbGVNb3VzZU1vdmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXN0VGltZW91dFBlbmRpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgcmVzdFRpbWVvdXRSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KGhhbmRsZU1vdXNlTW92ZSwgcmVzdE1zKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gIH0sIFttb3VzZU9ubHksIG9uT3BlbkNoYW5nZSwgb3Blbiwgb3BlblJlZiwgcmVzdE1zXSk7XG4gIGNvbnN0IGZsb2F0aW5nID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uTW91c2VFbnRlcigpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgIH0sXG4gICAgb25Nb3VzZUxlYXZlKGV2ZW50KSB7XG4gICAgICBpZiAoIWlzQ2xpY2tMaWtlT3BlbkV2ZW50KCkpIHtcbiAgICAgICAgY2xvc2VXaXRoRGVsYXkoZXZlbnQubmF0aXZlRXZlbnQsIGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pLCBbY2xvc2VXaXRoRGVsYXksIGlzQ2xpY2tMaWtlT3BlbkV2ZW50XSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlLFxuICAgIGZsb2F0aW5nXG4gIH0gOiB7fSwgW2VuYWJsZWQsIHJlZmVyZW5jZSwgZmxvYXRpbmddKTtcbn1cblxuY29uc3QgTk9PUCA9ICgpID0+IHt9O1xuY29uc3QgRmxvYXRpbmdEZWxheUdyb3VwQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgZGVsYXk6IDAsXG4gIGluaXRpYWxEZWxheTogMCxcbiAgdGltZW91dE1zOiAwLFxuICBjdXJyZW50SWQ6IG51bGwsXG4gIHNldEN1cnJlbnRJZDogTk9PUCxcbiAgc2V0U3RhdGU6IE5PT1AsXG4gIGlzSW5zdGFudFBoYXNlOiBmYWxzZVxufSk7XG5cbi8qKlxuICogQGRlcHJlY2F0ZWRcbiAqIFVzZSB0aGUgcmV0dXJuIHZhbHVlIG9mIGB1c2VEZWxheUdyb3VwKClgIGluc3RlYWQuXG4gKi9cbmNvbnN0IHVzZURlbGF5R3JvdXBDb250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChGbG9hdGluZ0RlbGF5R3JvdXBDb250ZXh0KTtcbi8qKlxuICogUHJvdmlkZXMgY29udGV4dCBmb3IgYSBncm91cCBvZiBmbG9hdGluZyBlbGVtZW50cyB0aGF0IHNob3VsZCBzaGFyZSBhXG4gKiBgZGVsYXlgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nRGVsYXlHcm91cFxuICovXG5mdW5jdGlvbiBGbG9hdGluZ0RlbGF5R3JvdXAocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIGRlbGF5LFxuICAgIHRpbWVvdXRNcyA9IDBcbiAgfSA9IHByb3BzO1xuICBjb25zdCBbc3RhdGUsIHNldFN0YXRlXSA9IFJlYWN0LnVzZVJlZHVjZXIoKHByZXYsIG5leHQpID0+ICh7XG4gICAgLi4ucHJldixcbiAgICAuLi5uZXh0XG4gIH0pLCB7XG4gICAgZGVsYXksXG4gICAgdGltZW91dE1zLFxuICAgIGluaXRpYWxEZWxheTogZGVsYXksXG4gICAgY3VycmVudElkOiBudWxsLFxuICAgIGlzSW5zdGFudFBoYXNlOiBmYWxzZVxuICB9KTtcbiAgY29uc3QgaW5pdGlhbEN1cnJlbnRJZFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2V0Q3VycmVudElkID0gUmVhY3QudXNlQ2FsbGJhY2soY3VycmVudElkID0+IHtcbiAgICBzZXRTdGF0ZSh7XG4gICAgICBjdXJyZW50SWRcbiAgICB9KTtcbiAgfSwgW10pO1xuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKHN0YXRlLmN1cnJlbnRJZCkge1xuICAgICAgaWYgKGluaXRpYWxDdXJyZW50SWRSZWYuY3VycmVudCA9PT0gbnVsbCkge1xuICAgICAgICBpbml0aWFsQ3VycmVudElkUmVmLmN1cnJlbnQgPSBzdGF0ZS5jdXJyZW50SWQ7XG4gICAgICB9IGVsc2UgaWYgKCFzdGF0ZS5pc0luc3RhbnRQaGFzZSkge1xuICAgICAgICBzZXRTdGF0ZSh7XG4gICAgICAgICAgaXNJbnN0YW50UGhhc2U6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChzdGF0ZS5pc0luc3RhbnRQaGFzZSkge1xuICAgICAgICBzZXRTdGF0ZSh7XG4gICAgICAgICAgaXNJbnN0YW50UGhhc2U6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaW5pdGlhbEN1cnJlbnRJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gIH0sIFtzdGF0ZS5jdXJyZW50SWQsIHN0YXRlLmlzSW5zdGFudFBoYXNlXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGbG9hdGluZ0RlbGF5R3JvdXBDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgIC4uLnN0YXRlLFxuICAgICAgc2V0U3RhdGUsXG4gICAgICBzZXRDdXJyZW50SWRcbiAgICB9KSwgW3N0YXRlLCBzZXRDdXJyZW50SWRdKVxuICB9LCBjaGlsZHJlbik7XG59XG4vKipcbiAqIEVuYWJsZXMgZ3JvdXBpbmcgd2hlbiBjYWxsZWQgaW5zaWRlIGEgY29tcG9uZW50IHRoYXQncyBhIGNoaWxkIG9mIGFcbiAqIGBGbG9hdGluZ0RlbGF5R3JvdXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nRGVsYXlHcm91cFxuICovXG5mdW5jdGlvbiB1c2VEZWxheUdyb3VwKGNvbnRleHQsIG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgb3BlbixcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgZmxvYXRpbmdJZFxuICB9ID0gY29udGV4dDtcbiAgY29uc3Qge1xuICAgIGlkOiBvcHRpb25JZCxcbiAgICBlbmFibGVkID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaWQgPSBvcHRpb25JZCAhPSBudWxsID8gb3B0aW9uSWQgOiBmbG9hdGluZ0lkO1xuICBjb25zdCBncm91cENvbnRleHQgPSB1c2VEZWxheUdyb3VwQ29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgY3VycmVudElkLFxuICAgIHNldEN1cnJlbnRJZCxcbiAgICBpbml0aWFsRGVsYXksXG4gICAgc2V0U3RhdGUsXG4gICAgdGltZW91dE1zXG4gIH0gPSBncm91cENvbnRleHQ7XG4gIGluZGV4KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHJldHVybjtcbiAgICBpZiAoIWN1cnJlbnRJZCkgcmV0dXJuO1xuICAgIHNldFN0YXRlKHtcbiAgICAgIGRlbGF5OiB7XG4gICAgICAgIG9wZW46IDEsXG4gICAgICAgIGNsb3NlOiBnZXREZWxheShpbml0aWFsRGVsYXksICdjbG9zZScpXG4gICAgICB9XG4gICAgfSk7XG4gICAgaWYgKGN1cnJlbnRJZCAhPT0gaWQpIHtcbiAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgaWQsIG9uT3BlbkNoYW5nZSwgc2V0U3RhdGUsIGN1cnJlbnRJZCwgaW5pdGlhbERlbGF5XSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBmdW5jdGlvbiB1bnNldCgpIHtcbiAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgICBzZXRTdGF0ZSh7XG4gICAgICAgIGRlbGF5OiBpbml0aWFsRGVsYXksXG4gICAgICAgIGN1cnJlbnRJZDogbnVsbFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGlmICghY3VycmVudElkKSByZXR1cm47XG4gICAgaWYgKCFvcGVuICYmIGN1cnJlbnRJZCA9PT0gaWQpIHtcbiAgICAgIGlmICh0aW1lb3V0TXMpIHtcbiAgICAgICAgY29uc3QgdGltZW91dCA9IHdpbmRvdy5zZXRUaW1lb3V0KHVuc2V0LCB0aW1lb3V0TXMpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHVuc2V0KCk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3Blbiwgc2V0U3RhdGUsIGN1cnJlbnRJZCwgaWQsIG9uT3BlbkNoYW5nZSwgaW5pdGlhbERlbGF5LCB0aW1lb3V0TXNdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGlmIChzZXRDdXJyZW50SWQgPT09IE5PT1AgfHwgIW9wZW4pIHJldHVybjtcbiAgICBzZXRDdXJyZW50SWQoaWQpO1xuICB9LCBbZW5hYmxlZCwgb3Blbiwgc2V0Q3VycmVudElkLCBpZF0pO1xuICByZXR1cm4gZ3JvdXBDb250ZXh0O1xufVxuXG5sZXQgcmFmSWQgPSAwO1xuZnVuY3Rpb24gZW5xdWV1ZUZvY3VzKGVsLCBvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIHByZXZlbnRTY3JvbGwgPSBmYWxzZSxcbiAgICBjYW5jZWxQcmV2aW91cyA9IHRydWUsXG4gICAgc3luYyA9IGZhbHNlXG4gIH0gPSBvcHRpb25zO1xuICBjYW5jZWxQcmV2aW91cyAmJiBjYW5jZWxBbmltYXRpb25GcmFtZShyYWZJZCk7XG4gIGNvbnN0IGV4ZWMgPSAoKSA9PiBlbCA9PSBudWxsID8gdm9pZCAwIDogZWwuZm9jdXMoe1xuICAgIHByZXZlbnRTY3JvbGxcbiAgfSk7XG4gIGlmIChzeW5jKSB7XG4gICAgZXhlYygpO1xuICB9IGVsc2Uge1xuICAgIHJhZklkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGV4ZWMpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGdldEFuY2VzdG9ycyhub2RlcywgaWQpIHtcbiAgdmFyIF9ub2RlcyRmaW5kO1xuICBsZXQgYWxsQW5jZXN0b3JzID0gW107XG4gIGxldCBjdXJyZW50UGFyZW50SWQgPSAoX25vZGVzJGZpbmQgPSBub2Rlcy5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gaWQpKSA9PSBudWxsID8gdm9pZCAwIDogX25vZGVzJGZpbmQucGFyZW50SWQ7XG4gIHdoaWxlIChjdXJyZW50UGFyZW50SWQpIHtcbiAgICBjb25zdCBjdXJyZW50Tm9kZSA9IG5vZGVzLmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBjdXJyZW50UGFyZW50SWQpO1xuICAgIGN1cnJlbnRQYXJlbnRJZCA9IGN1cnJlbnROb2RlID09IG51bGwgPyB2b2lkIDAgOiBjdXJyZW50Tm9kZS5wYXJlbnRJZDtcbiAgICBpZiAoY3VycmVudE5vZGUpIHtcbiAgICAgIGFsbEFuY2VzdG9ycyA9IGFsbEFuY2VzdG9ycy5jb25jYXQoY3VycmVudE5vZGUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYWxsQW5jZXN0b3JzO1xufVxuXG5mdW5jdGlvbiBnZXRDaGlsZHJlbihub2RlcywgaWQpIHtcbiAgbGV0IGFsbENoaWxkcmVuID0gbm9kZXMuZmlsdGVyKG5vZGUgPT4ge1xuICAgIHZhciBfbm9kZSRjb250ZXh0O1xuICAgIHJldHVybiBub2RlLnBhcmVudElkID09PSBpZCAmJiAoKF9ub2RlJGNvbnRleHQgPSBub2RlLmNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRjb250ZXh0Lm9wZW4pO1xuICB9KTtcbiAgbGV0IGN1cnJlbnRDaGlsZHJlbiA9IGFsbENoaWxkcmVuO1xuICB3aGlsZSAoY3VycmVudENoaWxkcmVuLmxlbmd0aCkge1xuICAgIGN1cnJlbnRDaGlsZHJlbiA9IG5vZGVzLmZpbHRlcihub2RlID0+IHtcbiAgICAgIHZhciBfY3VycmVudENoaWxkcmVuO1xuICAgICAgcmV0dXJuIChfY3VycmVudENoaWxkcmVuID0gY3VycmVudENoaWxkcmVuKSA9PSBudWxsID8gdm9pZCAwIDogX2N1cnJlbnRDaGlsZHJlbi5zb21lKG4gPT4ge1xuICAgICAgICB2YXIgX25vZGUkY29udGV4dDI7XG4gICAgICAgIHJldHVybiBub2RlLnBhcmVudElkID09PSBuLmlkICYmICgoX25vZGUkY29udGV4dDIgPSBub2RlLmNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRjb250ZXh0Mi5vcGVuKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGFsbENoaWxkcmVuID0gYWxsQ2hpbGRyZW4uY29uY2F0KGN1cnJlbnRDaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuIGFsbENoaWxkcmVuO1xufVxuZnVuY3Rpb24gZ2V0RGVlcGVzdE5vZGUobm9kZXMsIGlkKSB7XG4gIGxldCBkZWVwZXN0Tm9kZUlkO1xuICBsZXQgbWF4RGVwdGggPSAtMTtcbiAgZnVuY3Rpb24gZmluZERlZXBlc3Qobm9kZUlkLCBkZXB0aCkge1xuICAgIGlmIChkZXB0aCA+IG1heERlcHRoKSB7XG4gICAgICBkZWVwZXN0Tm9kZUlkID0gbm9kZUlkO1xuICAgICAgbWF4RGVwdGggPSBkZXB0aDtcbiAgICB9XG4gICAgY29uc3QgY2hpbGRyZW4gPSBnZXRDaGlsZHJlbihub2Rlcywgbm9kZUlkKTtcbiAgICBjaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICAgIGZpbmREZWVwZXN0KGNoaWxkLmlkLCBkZXB0aCArIDEpO1xuICAgIH0pO1xuICB9XG4gIGZpbmREZWVwZXN0KGlkLCAwKTtcbiAgcmV0dXJuIG5vZGVzLmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBkZWVwZXN0Tm9kZUlkKTtcbn1cblxuLy8gTW9kaWZpZWQgdG8gYWRkIGNvbmRpdGlvbmFsIGBhcmlhLWhpZGRlbmAgc3VwcG9ydDpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS90aGVLYXNoZXkvYXJpYS1oaWRkZW4vYmxvYi85MjIwYzhmNGE0ZmQzNWY2M2JlZTU1MTBhOWY0MWEzNzI2NDM4MmQ0L3NyYy9pbmRleC50c1xubGV0IGNvdW50ZXJNYXAgPSAvKiNfX1BVUkVfXyovbmV3IFdlYWtNYXAoKTtcbmxldCB1bmNvbnRyb2xsZWRFbGVtZW50c1NldCA9IC8qI19fUFVSRV9fKi9uZXcgV2Vha1NldCgpO1xubGV0IG1hcmtlck1hcCA9IHt9O1xubGV0IGxvY2tDb3VudCQxID0gMDtcbmNvbnN0IHN1cHBvcnRzSW5lcnQgPSAoKSA9PiB0eXBlb2YgSFRNTEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmICdpbmVydCcgaW4gSFRNTEVsZW1lbnQucHJvdG90eXBlO1xuY29uc3QgdW53cmFwSG9zdCA9IG5vZGUgPT4gbm9kZSAmJiAobm9kZS5ob3N0IHx8IHVud3JhcEhvc3Qobm9kZS5wYXJlbnROb2RlKSk7XG5jb25zdCBjb3JyZWN0RWxlbWVudHMgPSAocGFyZW50LCB0YXJnZXRzKSA9PiB0YXJnZXRzLm1hcCh0YXJnZXQgPT4ge1xuICBpZiAocGFyZW50LmNvbnRhaW5zKHRhcmdldCkpIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGNvbnN0IGNvcnJlY3RlZFRhcmdldCA9IHVud3JhcEhvc3QodGFyZ2V0KTtcbiAgaWYgKHBhcmVudC5jb250YWlucyhjb3JyZWN0ZWRUYXJnZXQpKSB7XG4gICAgcmV0dXJuIGNvcnJlY3RlZFRhcmdldDtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn0pLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG5mdW5jdGlvbiBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzKHVuY29ycmVjdGVkQXZvaWRFbGVtZW50cywgYm9keSwgYXJpYUhpZGRlbiwgaW5lcnQpIHtcbiAgY29uc3QgbWFya2VyTmFtZSA9ICdkYXRhLWZsb2F0aW5nLXVpLWluZXJ0JztcbiAgY29uc3QgY29udHJvbEF0dHJpYnV0ZSA9IGluZXJ0ID8gJ2luZXJ0JyA6IGFyaWFIaWRkZW4gPyAnYXJpYS1oaWRkZW4nIDogbnVsbDtcbiAgY29uc3QgYXZvaWRFbGVtZW50cyA9IGNvcnJlY3RFbGVtZW50cyhib2R5LCB1bmNvcnJlY3RlZEF2b2lkRWxlbWVudHMpO1xuICBjb25zdCBlbGVtZW50c1RvS2VlcCA9IG5ldyBTZXQoKTtcbiAgY29uc3QgZWxlbWVudHNUb1N0b3AgPSBuZXcgU2V0KGF2b2lkRWxlbWVudHMpO1xuICBjb25zdCBoaWRkZW5FbGVtZW50cyA9IFtdO1xuICBpZiAoIW1hcmtlck1hcFttYXJrZXJOYW1lXSkge1xuICAgIG1hcmtlck1hcFttYXJrZXJOYW1lXSA9IG5ldyBXZWFrTWFwKCk7XG4gIH1cbiAgY29uc3QgbWFya2VyQ291bnRlciA9IG1hcmtlck1hcFttYXJrZXJOYW1lXTtcbiAgYXZvaWRFbGVtZW50cy5mb3JFYWNoKGtlZXApO1xuICBkZWVwKGJvZHkpO1xuICBlbGVtZW50c1RvS2VlcC5jbGVhcigpO1xuICBmdW5jdGlvbiBrZWVwKGVsKSB7XG4gICAgaWYgKCFlbCB8fCBlbGVtZW50c1RvS2VlcC5oYXMoZWwpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGVsZW1lbnRzVG9LZWVwLmFkZChlbCk7XG4gICAgZWwucGFyZW50Tm9kZSAmJiBrZWVwKGVsLnBhcmVudE5vZGUpO1xuICB9XG4gIGZ1bmN0aW9uIGRlZXAocGFyZW50KSB7XG4gICAgaWYgKCFwYXJlbnQgfHwgZWxlbWVudHNUb1N0b3AuaGFzKHBhcmVudCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgW10uZm9yRWFjaC5jYWxsKHBhcmVudC5jaGlsZHJlbiwgbm9kZSA9PiB7XG4gICAgICBpZiAoZ2V0Tm9kZU5hbWUobm9kZSkgPT09ICdzY3JpcHQnKSByZXR1cm47XG4gICAgICBpZiAoZWxlbWVudHNUb0tlZXAuaGFzKG5vZGUpKSB7XG4gICAgICAgIGRlZXAobm9kZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBhdHRyID0gY29udHJvbEF0dHJpYnV0ZSA/IG5vZGUuZ2V0QXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUpIDogbnVsbDtcbiAgICAgICAgY29uc3QgYWxyZWFkeUhpZGRlbiA9IGF0dHIgIT09IG51bGwgJiYgYXR0ciAhPT0gJ2ZhbHNlJztcbiAgICAgICAgY29uc3QgY291bnRlclZhbHVlID0gKGNvdW50ZXJNYXAuZ2V0KG5vZGUpIHx8IDApICsgMTtcbiAgICAgICAgY29uc3QgbWFya2VyVmFsdWUgPSAobWFya2VyQ291bnRlci5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgICBjb3VudGVyTWFwLnNldChub2RlLCBjb3VudGVyVmFsdWUpO1xuICAgICAgICBtYXJrZXJDb3VudGVyLnNldChub2RlLCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgIGhpZGRlbkVsZW1lbnRzLnB1c2gobm9kZSk7XG4gICAgICAgIGlmIChjb3VudGVyVmFsdWUgPT09IDEgJiYgYWxyZWFkeUhpZGRlbikge1xuICAgICAgICAgIHVuY29udHJvbGxlZEVsZW1lbnRzU2V0LmFkZChub2RlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobWFya2VyVmFsdWUgPT09IDEpIHtcbiAgICAgICAgICBub2RlLnNldEF0dHJpYnV0ZShtYXJrZXJOYW1lLCAnJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFhbHJlYWR5SGlkZGVuICYmIGNvbnRyb2xBdHRyaWJ1dGUpIHtcbiAgICAgICAgICBub2RlLnNldEF0dHJpYnV0ZShjb250cm9sQXR0cmlidXRlLCAndHJ1ZScpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgbG9ja0NvdW50JDErKztcbiAgcmV0dXJuICgpID0+IHtcbiAgICBoaWRkZW5FbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgICAgY29uc3QgY291bnRlclZhbHVlID0gKGNvdW50ZXJNYXAuZ2V0KGVsZW1lbnQpIHx8IDApIC0gMTtcbiAgICAgIGNvbnN0IG1hcmtlclZhbHVlID0gKG1hcmtlckNvdW50ZXIuZ2V0KGVsZW1lbnQpIHx8IDApIC0gMTtcbiAgICAgIGNvdW50ZXJNYXAuc2V0KGVsZW1lbnQsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICBtYXJrZXJDb3VudGVyLnNldChlbGVtZW50LCBtYXJrZXJWYWx1ZSk7XG4gICAgICBpZiAoIWNvdW50ZXJWYWx1ZSkge1xuICAgICAgICBpZiAoIXVuY29udHJvbGxlZEVsZW1lbnRzU2V0LmhhcyhlbGVtZW50KSAmJiBjb250cm9sQXR0cmlidXRlKSB7XG4gICAgICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoY29udHJvbEF0dHJpYnV0ZSk7XG4gICAgICAgIH1cbiAgICAgICAgdW5jb250cm9sbGVkRWxlbWVudHNTZXQuZGVsZXRlKGVsZW1lbnQpO1xuICAgICAgfVxuICAgICAgaWYgKCFtYXJrZXJWYWx1ZSkge1xuICAgICAgICBlbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShtYXJrZXJOYW1lKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBsb2NrQ291bnQkMS0tO1xuICAgIGlmICghbG9ja0NvdW50JDEpIHtcbiAgICAgIGNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgY291bnRlck1hcCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldCA9IG5ldyBXZWFrU2V0KCk7XG4gICAgICBtYXJrZXJNYXAgPSB7fTtcbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBtYXJrT3RoZXJzKGF2b2lkRWxlbWVudHMsIGFyaWFIaWRkZW4sIGluZXJ0KSB7XG4gIGlmIChhcmlhSGlkZGVuID09PSB2b2lkIDApIHtcbiAgICBhcmlhSGlkZGVuID0gZmFsc2U7XG4gIH1cbiAgaWYgKGluZXJ0ID09PSB2b2lkIDApIHtcbiAgICBpbmVydCA9IGZhbHNlO1xuICB9XG4gIGNvbnN0IGJvZHkgPSBnZXREb2N1bWVudChhdm9pZEVsZW1lbnRzWzBdKS5ib2R5O1xuICByZXR1cm4gYXBwbHlBdHRyaWJ1dGVUb090aGVycyhhdm9pZEVsZW1lbnRzLmNvbmNhdChBcnJheS5mcm9tKGJvZHkucXVlcnlTZWxlY3RvckFsbCgnW2FyaWEtbGl2ZV0nKSkpLCBib2R5LCBhcmlhSGlkZGVuLCBpbmVydCk7XG59XG5cbmNvbnN0IGdldFRhYmJhYmxlT3B0aW9ucyA9ICgpID0+ICh7XG4gIGdldFNoYWRvd1Jvb3Q6IHRydWUsXG4gIGRpc3BsYXlDaGVjazpcbiAgLy8gSlNET00gZG9lcyBub3Qgc3VwcG9ydCB0aGUgYHRhYmJhYmxlYCBsaWJyYXJ5LiBUbyBzb2x2ZSB0aGlzIHdlIGNhblxuICAvLyBjaGVjayBpZiBgUmVzaXplT2JzZXJ2ZXJgIGlzIGEgcmVhbCBmdW5jdGlvbiAobm90IHBvbHlmaWxsZWQpLCB3aGljaFxuICAvLyBkZXRlcm1pbmVzIGlmIHRoZSBjdXJyZW50IGVudmlyb25tZW50IGlzIEpTRE9NLWxpa2UuXG4gIHR5cGVvZiBSZXNpemVPYnNlcnZlciA9PT0gJ2Z1bmN0aW9uJyAmJiBSZXNpemVPYnNlcnZlci50b1N0cmluZygpLmluY2x1ZGVzKCdbbmF0aXZlIGNvZGVdJykgPyAnZnVsbCcgOiAnbm9uZSdcbn0pO1xuZnVuY3Rpb24gZ2V0VGFiYmFibGVJbihjb250YWluZXIsIGRpcmVjdGlvbikge1xuICBjb25zdCBhbGxUYWJiYWJsZSA9IHRhYmJhYmxlKGNvbnRhaW5lciwgZ2V0VGFiYmFibGVPcHRpb25zKCkpO1xuICBpZiAoZGlyZWN0aW9uID09PSAncHJldicpIHtcbiAgICBhbGxUYWJiYWJsZS5yZXZlcnNlKCk7XG4gIH1cbiAgY29uc3QgYWN0aXZlSW5kZXggPSBhbGxUYWJiYWJsZS5pbmRleE9mKGFjdGl2ZUVsZW1lbnQoZ2V0RG9jdW1lbnQoY29udGFpbmVyKSkpO1xuICBjb25zdCBuZXh0VGFiYmFibGVFbGVtZW50cyA9IGFsbFRhYmJhYmxlLnNsaWNlKGFjdGl2ZUluZGV4ICsgMSk7XG4gIHJldHVybiBuZXh0VGFiYmFibGVFbGVtZW50c1swXTtcbn1cbmZ1bmN0aW9uIGdldE5leHRUYWJiYWJsZSgpIHtcbiAgcmV0dXJuIGdldFRhYmJhYmxlSW4oZG9jdW1lbnQuYm9keSwgJ25leHQnKTtcbn1cbmZ1bmN0aW9uIGdldFByZXZpb3VzVGFiYmFibGUoKSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZUluKGRvY3VtZW50LmJvZHksICdwcmV2Jyk7XG59XG5mdW5jdGlvbiBpc091dHNpZGVFdmVudChldmVudCwgY29udGFpbmVyKSB7XG4gIGNvbnN0IGNvbnRhaW5lckVsZW1lbnQgPSBjb250YWluZXIgfHwgZXZlbnQuY3VycmVudFRhcmdldDtcbiAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gIHJldHVybiAhcmVsYXRlZFRhcmdldCB8fCAhY29udGFpbnMoY29udGFpbmVyRWxlbWVudCwgcmVsYXRlZFRhcmdldCk7XG59XG5mdW5jdGlvbiBkaXNhYmxlRm9jdXNJbnNpZGUoY29udGFpbmVyKSB7XG4gIGNvbnN0IHRhYmJhYmxlRWxlbWVudHMgPSB0YWJiYWJsZShjb250YWluZXIsIGdldFRhYmJhYmxlT3B0aW9ucygpKTtcbiAgdGFiYmFibGVFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCd0YWJpbmRleCcpIHx8ICcnO1xuICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGVuYWJsZUZvY3VzSW5zaWRlKGNvbnRhaW5lcikge1xuICBjb25zdCBlbGVtZW50cyA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10YWJpbmRleF0nKTtcbiAgZWxlbWVudHMuZm9yRWFjaChlbGVtZW50ID0+IHtcbiAgICBjb25zdCB0YWJpbmRleCA9IGVsZW1lbnQuZGF0YXNldC50YWJpbmRleDtcbiAgICBkZWxldGUgZWxlbWVudC5kYXRhc2V0LnRhYmluZGV4O1xuICAgIGlmICh0YWJpbmRleCkge1xuICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoJ3RhYmluZGV4JywgdGFiaW5kZXgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgndGFiaW5kZXgnKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBTZWUgRGllZ28gSGF6J3MgU2FuZGJveCBmb3IgbWFraW5nIHRoaXMgbG9naWMgd29yayB3ZWxsIG9uIFNhZmFyaS9pT1M6XG4vLyBodHRwczovL2NvZGVzYW5kYm94LmlvL3MvdGFiYmFibGUtcG9ydGFsLWY0dG5nP2ZpbGU9L3NyYy9Gb2N1c1RyYXAudHN4XG5cbmNvbnN0IEhJRERFTl9TVFlMRVMgPSB7XG4gIGJvcmRlcjogMCxcbiAgY2xpcDogJ3JlY3QoMCAwIDAgMCknLFxuICBoZWlnaHQ6ICcxcHgnLFxuICBtYXJnaW46ICctMXB4JyxcbiAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICBwYWRkaW5nOiAwLFxuICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXG4gIHdpZHRoOiAnMXB4JyxcbiAgdG9wOiAwLFxuICBsZWZ0OiAwXG59O1xubGV0IHRpbWVvdXRJZDtcbmZ1bmN0aW9uIHNldEFjdGl2ZUVsZW1lbnRPblRhYihldmVudCkge1xuICBpZiAoZXZlbnQua2V5ID09PSAnVGFiJykge1xuICAgIGV2ZW50LnRhcmdldDtcbiAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgfVxufVxuY29uc3QgRm9jdXNHdWFyZCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZvY3VzR3VhcmQocHJvcHMsIHJlZikge1xuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKGlzU2FmYXJpKCkpIHtcbiAgICAgIC8vIFVubGlrZSBvdGhlciBzY3JlZW4gcmVhZGVycyBzdWNoIGFzIE5WREEgYW5kIEpBV1MsIHRoZSB2aXJ0dWFsIGN1cnNvclxuICAgICAgLy8gb24gVm9pY2VPdmVyIGRvZXMgdHJpZ2dlciB0aGUgb25Gb2N1cyBldmVudCwgc28gd2UgY2FuIHVzZSB0aGUgZm9jdXNcbiAgICAgIC8vIHRyYXAgZWxlbWVudC4gT24gU2FmYXJpLCBvbmx5IGJ1dHRvbnMgdHJpZ2dlciB0aGUgb25Gb2N1cyBldmVudC5cbiAgICAgIC8vIE5COiBcImdyb3VwXCIgcm9sZSBpbiB0aGUgU2FuZGJveCBubyBsb25nZXIgYXBwZWFycyB0byB3b3JrLCBtdXN0IGJlIGFcbiAgICAgIC8vIGJ1dHRvbiByb2xlLlxuICAgICAgc2V0Um9sZSgnYnV0dG9uJyk7XG4gICAgfVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBzZXRBY3RpdmVFbGVtZW50T25UYWIpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgc2V0QWN0aXZlRWxlbWVudE9uVGFiKTtcbiAgICB9O1xuICB9LCBbXSk7XG4gIGNvbnN0IHJlc3RQcm9wcyA9IHtcbiAgICByZWYsXG4gICAgdGFiSW5kZXg6IDAsXG4gICAgLy8gUm9sZSBpcyBvbmx5IGZvciBWb2ljZU92ZXJcbiAgICByb2xlLFxuICAgICdhcmlhLWhpZGRlbic6IHJvbGUgPyB1bmRlZmluZWQgOiB0cnVlLFxuICAgIFtjcmVhdGVBdHRyaWJ1dGUoJ2ZvY3VzLWd1YXJkJyldOiAnJyxcbiAgICBzdHlsZTogSElEREVOX1NUWUxFU1xuICB9O1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIsIF9leHRlbmRzKHt9LCBwcm9wcywgcmVzdFByb3BzKSk7XG59KTtcblxuY29uc3QgUG9ydGFsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuY29uc3QgYXR0ciA9IC8qI19fUFVSRV9fKi9jcmVhdGVBdHRyaWJ1dGUoJ3BvcnRhbCcpO1xuLyoqXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdQb3J0YWwjdXNlZmxvYXRpbmdwb3J0YWxub2RlXG4gKi9cbmZ1bmN0aW9uIHVzZUZsb2F0aW5nUG9ydGFsTm9kZShwcm9wcykge1xuICBpZiAocHJvcHMgPT09IHZvaWQgMCkge1xuICAgIHByb3BzID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIGlkLFxuICAgIHJvb3RcbiAgfSA9IHByb3BzO1xuICBjb25zdCB1bmlxdWVJZCA9IHVzZUlkKCk7XG4gIGNvbnN0IHBvcnRhbENvbnRleHQgPSB1c2VQb3J0YWxDb250ZXh0KCk7XG4gIGNvbnN0IFtwb3J0YWxOb2RlLCBzZXRQb3J0YWxOb2RlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBwb3J0YWxOb2RlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBpbmRleCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHBvcnRhbE5vZGUgPT0gbnVsbCB8fCBwb3J0YWxOb2RlLnJlbW92ZSgpO1xuICAgICAgLy8gQWxsb3cgdGhlIHN1YnNlcXVlbnQgbGF5b3V0IGVmZmVjdHMgdG8gY3JlYXRlIGEgbmV3IG5vZGUgb24gdXBkYXRlcy5cbiAgICAgIC8vIFRoZSBwb3J0YWwgbm9kZSB3aWxsIHN0aWxsIGJlIGNsZWFuZWQgdXAgb24gdW5tb3VudC5cbiAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjQ1NFxuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBwb3J0YWxOb2RlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfSk7XG4gICAgfTtcbiAgfSwgW3BvcnRhbE5vZGVdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIC8vIFdhaXQgZm9yIHRoZSB1bmlxdWVJZCB0byBiZSBnZW5lcmF0ZWQgYmVmb3JlIGNyZWF0aW5nIHRoZSBwb3J0YWwgbm9kZSBpblxuICAgIC8vIFJlYWN0IDwxOCAodXNpbmcgYHVzZUZsb2F0aW5nSWRgIGluc3RlYWQgb2YgdGhlIG5hdGl2ZSBgdXNlSWRgKS5cbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzI3NzhcbiAgICBpZiAoIXVuaXF1ZUlkKSByZXR1cm47XG4gICAgaWYgKHBvcnRhbE5vZGVSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGNvbnN0IGV4aXN0aW5nSWRSb290ID0gaWQgPyBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCkgOiBudWxsO1xuICAgIGlmICghZXhpc3RpbmdJZFJvb3QpIHJldHVybjtcbiAgICBjb25zdCBzdWJSb290ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgc3ViUm9vdC5pZCA9IHVuaXF1ZUlkO1xuICAgIHN1YlJvb3Quc2V0QXR0cmlidXRlKGF0dHIsICcnKTtcbiAgICBleGlzdGluZ0lkUm9vdC5hcHBlbmRDaGlsZChzdWJSb290KTtcbiAgICBwb3J0YWxOb2RlUmVmLmN1cnJlbnQgPSBzdWJSb290O1xuICAgIHNldFBvcnRhbE5vZGUoc3ViUm9vdCk7XG4gIH0sIFtpZCwgdW5pcXVlSWRdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIC8vIFdhaXQgZm9yIHRoZSByb290IHRvIGV4aXN0IGJlZm9yZSBjcmVhdGluZyB0aGUgcG9ydGFsIG5vZGUuIFRoZSByb290IG11c3RcbiAgICAvLyBiZSBzdG9yZWQgaW4gc3RhdGUsIG5vdCBhIHJlZiwgZm9yIHRoaXMgdG8gd29yayByZWFjdGl2ZWx5LlxuICAgIGlmIChyb290ID09PSBudWxsKSByZXR1cm47XG4gICAgaWYgKCF1bmlxdWVJZCkgcmV0dXJuO1xuICAgIGlmIChwb3J0YWxOb2RlUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBsZXQgY29udGFpbmVyID0gcm9vdCB8fCAocG9ydGFsQ29udGV4dCA9PSBudWxsID8gdm9pZCAwIDogcG9ydGFsQ29udGV4dC5wb3J0YWxOb2RlKTtcbiAgICBpZiAoY29udGFpbmVyICYmICFpc0VsZW1lbnQoY29udGFpbmVyKSkgY29udGFpbmVyID0gY29udGFpbmVyLmN1cnJlbnQ7XG4gICAgY29udGFpbmVyID0gY29udGFpbmVyIHx8IGRvY3VtZW50LmJvZHk7XG4gICAgbGV0IGlkV3JhcHBlciA9IG51bGw7XG4gICAgaWYgKGlkKSB7XG4gICAgICBpZFdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGlkV3JhcHBlci5pZCA9IGlkO1xuICAgICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGlkV3JhcHBlcik7XG4gICAgfVxuICAgIGNvbnN0IHN1YlJvb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBzdWJSb290LmlkID0gdW5pcXVlSWQ7XG4gICAgc3ViUm9vdC5zZXRBdHRyaWJ1dGUoYXR0ciwgJycpO1xuICAgIGNvbnRhaW5lciA9IGlkV3JhcHBlciB8fCBjb250YWluZXI7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHN1YlJvb3QpO1xuICAgIHBvcnRhbE5vZGVSZWYuY3VycmVudCA9IHN1YlJvb3Q7XG4gICAgc2V0UG9ydGFsTm9kZShzdWJSb290KTtcbiAgfSwgW2lkLCByb290LCB1bmlxdWVJZCwgcG9ydGFsQ29udGV4dF0pO1xuICByZXR1cm4gcG9ydGFsTm9kZTtcbn1cbi8qKlxuICogUG9ydGFscyB0aGUgZmxvYXRpbmcgZWxlbWVudCBpbnRvIGEgZ2l2ZW4gY29udGFpbmVyIGVsZW1lbnQg4oCUIGJ5IGRlZmF1bHQsXG4gKiBvdXRzaWRlIG9mIHRoZSBhcHAgcm9vdCBhbmQgaW50byB0aGUgYm9keS5cbiAqIFRoaXMgaXMgbmVjZXNzYXJ5IHRvIGVuc3VyZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBjYW4gYXBwZWFyIG91dHNpZGUgYW55XG4gKiBwb3RlbnRpYWwgcGFyZW50IGNvbnRhaW5lcnMgdGhhdCBjYXVzZSBjbGlwcGluZyAoc3VjaCBhcyBgb3ZlcmZsb3c6IGhpZGRlbmApLFxuICogd2hpbGUgcmV0YWluaW5nIGl0cyBsb2NhdGlvbiBpbiB0aGUgUmVhY3QgdHJlZS5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1BvcnRhbFxuICovXG5mdW5jdGlvbiBGbG9hdGluZ1BvcnRhbChwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgaWQsXG4gICAgcm9vdCxcbiAgICBwcmVzZXJ2ZVRhYk9yZGVyID0gdHJ1ZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHBvcnRhbE5vZGUgPSB1c2VGbG9hdGluZ1BvcnRhbE5vZGUoe1xuICAgIGlkLFxuICAgIHJvb3RcbiAgfSk7XG4gIGNvbnN0IFtmb2N1c01hbmFnZXJTdGF0ZSwgc2V0Rm9jdXNNYW5hZ2VyU3RhdGVdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IGJlZm9yZU91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGFmdGVyT3V0c2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYmVmb3JlSW5zaWRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBhZnRlckluc2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgbW9kYWwgPSBmb2N1c01hbmFnZXJTdGF0ZSA9PSBudWxsID8gdm9pZCAwIDogZm9jdXNNYW5hZ2VyU3RhdGUubW9kYWw7XG4gIGNvbnN0IG9wZW4gPSBmb2N1c01hbmFnZXJTdGF0ZSA9PSBudWxsID8gdm9pZCAwIDogZm9jdXNNYW5hZ2VyU3RhdGUub3BlbjtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyR3VhcmRzID1cbiAgLy8gVGhlIEZvY3VzTWFuYWdlciBhbmQgdGhlcmVmb3JlIGZsb2F0aW5nIGVsZW1lbnQgYXJlIGN1cnJlbnRseSBvcGVuL1xuICAvLyByZW5kZXJlZC5cbiAgISFmb2N1c01hbmFnZXJTdGF0ZSAmJlxuICAvLyBHdWFyZHMgYXJlIG9ubHkgZm9yIG5vbi1tb2RhbCBmb2N1cyBtYW5hZ2VtZW50LlxuICAhZm9jdXNNYW5hZ2VyU3RhdGUubW9kYWwgJiZcbiAgLy8gRG9uJ3QgcmVuZGVyIGlmIHVubW91bnQgaXMgdHJhbnNpdGlvbmluZy5cbiAgZm9jdXNNYW5hZ2VyU3RhdGUub3BlbiAmJiBwcmVzZXJ2ZVRhYk9yZGVyICYmICEhKHJvb3QgfHwgcG9ydGFsTm9kZSk7XG5cbiAgLy8gaHR0cHM6Ly9jb2Rlc2FuZGJveC5pby9zL3RhYmJhYmxlLXBvcnRhbC1mNHRuZz9maWxlPS9zcmMvVGFiYmFibGVQb3J0YWwudHN4XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwb3J0YWxOb2RlIHx8ICFwcmVzZXJ2ZVRhYk9yZGVyIHx8IG1vZGFsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gTWFrZSBzdXJlIGVsZW1lbnRzIGluc2lkZSB0aGUgcG9ydGFsIGVsZW1lbnQgYXJlIHRhYmJhYmxlIG9ubHkgd2hlbiB0aGVcbiAgICAvLyBwb3J0YWwgaGFzIGFscmVhZHkgYmVlbiBmb2N1c2VkLCBlaXRoZXIgYnkgdGFiYmluZyBpbnRvIGEgZm9jdXMgdHJhcFxuICAgIC8vIGVsZW1lbnQgb3V0c2lkZSBvciB1c2luZyB0aGUgbW91c2UuXG4gICAgZnVuY3Rpb24gb25Gb2N1cyhldmVudCkge1xuICAgICAgaWYgKHBvcnRhbE5vZGUgJiYgaXNPdXRzaWRlRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIGNvbnN0IGZvY3VzaW5nID0gZXZlbnQudHlwZSA9PT0gJ2ZvY3VzaW4nO1xuICAgICAgICBjb25zdCBtYW5hZ2VGb2N1cyA9IGZvY3VzaW5nID8gZW5hYmxlRm9jdXNJbnNpZGUgOiBkaXNhYmxlRm9jdXNJbnNpZGU7XG4gICAgICAgIG1hbmFnZUZvY3VzKHBvcnRhbE5vZGUpO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBMaXN0ZW4gdG8gdGhlIGV2ZW50IG9uIHRoZSBjYXB0dXJlIHBoYXNlIHNvIHRoZXkgcnVuIGJlZm9yZSB0aGUgZm9jdXNcbiAgICAvLyB0cmFwIGVsZW1lbnRzIG9uRm9jdXMgcHJvcCBpcyBjYWxsZWQuXG4gICAgcG9ydGFsTm9kZS5hZGRFdmVudExpc3RlbmVyKCdmb2N1c2luJywgb25Gb2N1cywgdHJ1ZSk7XG4gICAgcG9ydGFsTm9kZS5hZGRFdmVudExpc3RlbmVyKCdmb2N1c291dCcsIG9uRm9jdXMsIHRydWUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBwb3J0YWxOb2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2ZvY3VzaW4nLCBvbkZvY3VzLCB0cnVlKTtcbiAgICAgIHBvcnRhbE5vZGUucmVtb3ZlRXZlbnRMaXN0ZW5lcignZm9jdXNvdXQnLCBvbkZvY3VzLCB0cnVlKTtcbiAgICB9O1xuICB9LCBbcG9ydGFsTm9kZSwgcHJlc2VydmVUYWJPcmRlciwgbW9kYWxdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBvcnRhbE5vZGUpIHJldHVybjtcbiAgICBpZiAob3BlbikgcmV0dXJuO1xuICAgIGVuYWJsZUZvY3VzSW5zaWRlKHBvcnRhbE5vZGUpO1xuICB9LCBbb3BlbiwgcG9ydGFsTm9kZV0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUG9ydGFsQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICBwcmVzZXJ2ZVRhYk9yZGVyLFxuICAgICAgYmVmb3JlT3V0c2lkZVJlZixcbiAgICAgIGFmdGVyT3V0c2lkZVJlZixcbiAgICAgIGJlZm9yZUluc2lkZVJlZixcbiAgICAgIGFmdGVySW5zaWRlUmVmLFxuICAgICAgcG9ydGFsTm9kZSxcbiAgICAgIHNldEZvY3VzTWFuYWdlclN0YXRlXG4gICAgfSksIFtwcmVzZXJ2ZVRhYk9yZGVyLCBwb3J0YWxOb2RlXSlcbiAgfSwgc2hvdWxkUmVuZGVyR3VhcmRzICYmIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoRm9jdXNHdWFyZCwge1xuICAgIFwiZGF0YS10eXBlXCI6IFwib3V0c2lkZVwiLFxuICAgIHJlZjogYmVmb3JlT3V0c2lkZVJlZixcbiAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICBpZiAoaXNPdXRzaWRlRXZlbnQoZXZlbnQsIHBvcnRhbE5vZGUpKSB7XG4gICAgICAgIHZhciBfYmVmb3JlSW5zaWRlUmVmJGN1cnI7XG4gICAgICAgIChfYmVmb3JlSW5zaWRlUmVmJGN1cnIgPSBiZWZvcmVJbnNpZGVSZWYuY3VycmVudCkgPT0gbnVsbCB8fCBfYmVmb3JlSW5zaWRlUmVmJGN1cnIuZm9jdXMoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHByZXZUYWJiYWJsZSA9IGdldFByZXZpb3VzVGFiYmFibGUoKSB8fCAoZm9jdXNNYW5hZ2VyU3RhdGUgPT0gbnVsbCA/IHZvaWQgMCA6IGZvY3VzTWFuYWdlclN0YXRlLnJlZnMuZG9tUmVmZXJlbmNlLmN1cnJlbnQpO1xuICAgICAgICBwcmV2VGFiYmFibGUgPT0gbnVsbCB8fCBwcmV2VGFiYmFibGUuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pLCBzaG91bGRSZW5kZXJHdWFyZHMgJiYgcG9ydGFsTm9kZSAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInNwYW5cIiwge1xuICAgIFwiYXJpYS1vd25zXCI6IHBvcnRhbE5vZGUuaWQsXG4gICAgc3R5bGU6IEhJRERFTl9TVFlMRVNcbiAgfSksIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL1JlYWN0RE9NLmNyZWF0ZVBvcnRhbChjaGlsZHJlbiwgcG9ydGFsTm9kZSksIHNob3VsZFJlbmRlckd1YXJkcyAmJiBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEZvY3VzR3VhcmQsIHtcbiAgICBcImRhdGEtdHlwZVwiOiBcIm91dHNpZGVcIixcbiAgICByZWY6IGFmdGVyT3V0c2lkZVJlZixcbiAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICBpZiAoaXNPdXRzaWRlRXZlbnQoZXZlbnQsIHBvcnRhbE5vZGUpKSB7XG4gICAgICAgIHZhciBfYWZ0ZXJJbnNpZGVSZWYkY3VycmU7XG4gICAgICAgIChfYWZ0ZXJJbnNpZGVSZWYkY3VycmUgPSBhZnRlckluc2lkZVJlZi5jdXJyZW50KSA9PSBudWxsIHx8IF9hZnRlckluc2lkZVJlZiRjdXJyZS5mb2N1cygpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKCkgfHwgKGZvY3VzTWFuYWdlclN0YXRlID09IG51bGwgPyB2b2lkIDAgOiBmb2N1c01hbmFnZXJTdGF0ZS5yZWZzLmRvbVJlZmVyZW5jZS5jdXJyZW50KTtcbiAgICAgICAgbmV4dFRhYmJhYmxlID09IG51bGwgfHwgbmV4dFRhYmJhYmxlLmZvY3VzKCk7XG4gICAgICAgIChmb2N1c01hbmFnZXJTdGF0ZSA9PSBudWxsID8gdm9pZCAwIDogZm9jdXNNYW5hZ2VyU3RhdGUuY2xvc2VPbkZvY3VzT3V0KSAmJiAoZm9jdXNNYW5hZ2VyU3RhdGUgPT0gbnVsbCA/IHZvaWQgMCA6IGZvY3VzTWFuYWdlclN0YXRlLm9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQubmF0aXZlRXZlbnQsICdmb2N1cy1vdXQnKSk7XG4gICAgICB9XG4gICAgfVxuICB9KSk7XG59XG5jb25zdCB1c2VQb3J0YWxDb250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChQb3J0YWxDb250ZXh0KTtcblxuY29uc3QgRk9DVVNBQkxFX0FUVFJJQlVURSA9ICdkYXRhLWZsb2F0aW5nLXVpLWZvY3VzYWJsZSc7XG5mdW5jdGlvbiBnZXRGbG9hdGluZ0ZvY3VzRWxlbWVudChmbG9hdGluZ0VsZW1lbnQpIHtcbiAgaWYgKCFmbG9hdGluZ0VsZW1lbnQpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICAvLyBUcnkgdG8gZmluZCB0aGUgZWxlbWVudCB0aGF0IGhhcyBgey4uLmdldEZsb2F0aW5nUHJvcHMoKX1gIHNwcmVhZCBvbiBpdC5cbiAgLy8gVGhpcyBpbmRpY2F0ZXMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgYWN0aW5nIGFzIGEgcG9zaXRpb25pbmcgd3JhcHBlciwgYW5kXG4gIC8vIHNvIGZvY3VzIHNob3VsZCBiZSBtYW5hZ2VkIG9uIHRoZSBjaGlsZCBlbGVtZW50IHdpdGggdGhlIGV2ZW50IGhhbmRsZXJzIGFuZFxuICAvLyBhcmlhIHByb3BzLlxuICByZXR1cm4gZmxvYXRpbmdFbGVtZW50Lmhhc0F0dHJpYnV0ZShGT0NVU0FCTEVfQVRUUklCVVRFKSA/IGZsb2F0aW5nRWxlbWVudCA6IGZsb2F0aW5nRWxlbWVudC5xdWVyeVNlbGVjdG9yKFwiW1wiICsgRk9DVVNBQkxFX0FUVFJJQlVURSArIFwiXVwiKSB8fCBmbG9hdGluZ0VsZW1lbnQ7XG59XG5cbmNvbnN0IExJU1RfTElNSVQgPSAyMDtcbmxldCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzID0gW107XG5mdW5jdGlvbiBhZGRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoZWxlbWVudCkge1xuICBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzID0gcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5maWx0ZXIoZWwgPT4gZWwuaXNDb25uZWN0ZWQpO1xuICBsZXQgdGFiYmFibGVFbCA9IGVsZW1lbnQ7XG4gIGlmICghdGFiYmFibGVFbCB8fCBnZXROb2RlTmFtZSh0YWJiYWJsZUVsKSA9PT0gJ2JvZHknKSByZXR1cm47XG4gIGlmICghaXNUYWJiYWJsZSh0YWJiYWJsZUVsLCBnZXRUYWJiYWJsZU9wdGlvbnMoKSkpIHtcbiAgICBjb25zdCB0YWJiYWJsZUNoaWxkID0gdGFiYmFibGUodGFiYmFibGVFbCwgZ2V0VGFiYmFibGVPcHRpb25zKCkpWzBdO1xuICAgIGlmICh0YWJiYWJsZUNoaWxkKSB7XG4gICAgICB0YWJiYWJsZUVsID0gdGFiYmFibGVDaGlsZDtcbiAgICB9XG4gIH1cbiAgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5wdXNoKHRhYmJhYmxlRWwpO1xuICBpZiAocHJldmlvdXNseUZvY3VzZWRFbGVtZW50cy5sZW5ndGggPiBMSVNUX0xJTUlUKSB7XG4gICAgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cyA9IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMuc2xpY2UoLUxJU1RfTElNSVQpO1xuICB9XG59XG5mdW5jdGlvbiBnZXRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoKSB7XG4gIHJldHVybiBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLnNsaWNlKCkucmV2ZXJzZSgpLmZpbmQoZWwgPT4gZWwuaXNDb25uZWN0ZWQpO1xufVxuY29uc3QgVmlzdWFsbHlIaWRkZW5EaXNtaXNzID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gVmlzdWFsbHlIaWRkZW5EaXNtaXNzKHByb3BzLCByZWYpIHtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIsIF9leHRlbmRzKHt9LCBwcm9wcywge1xuICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgcmVmOiByZWYsXG4gICAgdGFiSW5kZXg6IC0xLFxuICAgIHN0eWxlOiBISURERU5fU1RZTEVTXG4gIH0pKTtcbn0pO1xuLyoqXG4gKiBQcm92aWRlcyBmb2N1cyBtYW5hZ2VtZW50IGZvciB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ0ZvY3VzTWFuYWdlclxuICovXG5mdW5jdGlvbiBGbG9hdGluZ0ZvY3VzTWFuYWdlcihwcm9wcykge1xuICBjb25zdCB7XG4gICAgY29udGV4dCxcbiAgICBjaGlsZHJlbixcbiAgICBkaXNhYmxlZCA9IGZhbHNlLFxuICAgIG9yZGVyID0gWydjb250ZW50J10sXG4gICAgZ3VhcmRzOiBfZ3VhcmRzID0gdHJ1ZSxcbiAgICBpbml0aWFsRm9jdXMgPSAwLFxuICAgIHJldHVybkZvY3VzID0gdHJ1ZSxcbiAgICByZXN0b3JlRm9jdXMgPSBmYWxzZSxcbiAgICBtb2RhbCA9IHRydWUsXG4gICAgdmlzdWFsbHlIaWRkZW5EaXNtaXNzID0gZmFsc2UsXG4gICAgY2xvc2VPbkZvY3VzT3V0ID0gdHJ1ZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHtcbiAgICBvcGVuLFxuICAgIHJlZnMsXG4gICAgbm9kZUlkLFxuICAgIG9uT3BlbkNoYW5nZSxcbiAgICBldmVudHMsXG4gICAgZGF0YVJlZixcbiAgICBmbG9hdGluZ0lkLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICBkb21SZWZlcmVuY2UsXG4gICAgICBmbG9hdGluZ1xuICAgIH1cbiAgfSA9IGNvbnRleHQ7XG4gIGNvbnN0IGlnbm9yZUluaXRpYWxGb2N1cyA9IHR5cGVvZiBpbml0aWFsRm9jdXMgPT09ICdudW1iZXInICYmIGluaXRpYWxGb2N1cyA8IDA7XG4gIC8vIElmIHRoZSByZWZlcmVuY2UgaXMgYSBjb21ib2JveCBhbmQgaXMgdHlwZWFibGUgKGUuZy4gaW5wdXQvdGV4dGFyZWEpLFxuICAvLyB0aGVyZSBhcmUgZGlmZmVyZW50IGZvY3VzIHNlbWFudGljcy4gVGhlIGd1YXJkcyBzaG91bGQgbm90IGJlIHJlbmRlcmVkLCBidXRcbiAgLy8gYXJpYS1oaWRkZW4gc2hvdWxkIGJlIGFwcGxpZWQgdG8gYWxsIG5vZGVzIHN0aWxsLiBGdXJ0aGVyLCB0aGUgdmlzdWFsbHlcbiAgLy8gaGlkZGVuIGRpc21pc3MgYnV0dG9uIHNob3VsZCBvbmx5IGFwcGVhciBhdCB0aGUgZW5kIG9mIHRoZSBsaXN0LCBub3QgdGhlXG4gIC8vIHN0YXJ0LlxuICBjb25zdCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggPSBpc1R5cGVhYmxlQ29tYm9ib3goZG9tUmVmZXJlbmNlKSAmJiBpZ25vcmVJbml0aWFsRm9jdXM7XG5cbiAgLy8gRm9yY2UgdGhlIGd1YXJkcyB0byBiZSByZW5kZXJlZCBpZiB0aGUgYGluZXJ0YCBhdHRyaWJ1dGUgaXMgbm90IHN1cHBvcnRlZC5cbiAgY29uc3QgZ3VhcmRzID0gc3VwcG9ydHNJbmVydCgpID8gX2d1YXJkcyA6IHRydWU7XG4gIGNvbnN0IG9yZGVyUmVmID0gdXNlTGF0ZXN0UmVmKG9yZGVyKTtcbiAgY29uc3QgaW5pdGlhbEZvY3VzUmVmID0gdXNlTGF0ZXN0UmVmKGluaXRpYWxGb2N1cyk7XG4gIGNvbnN0IHJldHVybkZvY3VzUmVmID0gdXNlTGF0ZXN0UmVmKHJldHVybkZvY3VzKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZSgpO1xuICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBzdGFydERpc21pc3NCdXR0b25SZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGVuZERpc21pc3NCdXR0b25SZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHByZXZlbnRSZXR1cm5Gb2N1c1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGlzUG9pbnRlckRvd25SZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCB0YWJiYWJsZUluZGV4UmVmID0gUmVhY3QudXNlUmVmKC0xKTtcbiAgY29uc3QgaXNJbnNpZGVQb3J0YWwgPSBwb3J0YWxDb250ZXh0ICE9IG51bGw7XG4gIGNvbnN0IGZsb2F0aW5nRm9jdXNFbGVtZW50ID0gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmcpO1xuICBjb25zdCBnZXRUYWJiYWJsZUNvbnRlbnQgPSB1c2VFZmZlY3RFdmVudChmdW5jdGlvbiAoY29udGFpbmVyKSB7XG4gICAgaWYgKGNvbnRhaW5lciA9PT0gdm9pZCAwKSB7XG4gICAgICBjb250YWluZXIgPSBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRhaW5lciA/IHRhYmJhYmxlKGNvbnRhaW5lciwgZ2V0VGFiYmFibGVPcHRpb25zKCkpIDogW107XG4gIH0pO1xuICBjb25zdCBnZXRUYWJiYWJsZUVsZW1lbnRzID0gdXNlRWZmZWN0RXZlbnQoY29udGFpbmVyID0+IHtcbiAgICBjb25zdCBjb250ZW50ID0gZ2V0VGFiYmFibGVDb250ZW50KGNvbnRhaW5lcik7XG4gICAgcmV0dXJuIG9yZGVyUmVmLmN1cnJlbnQubWFwKHR5cGUgPT4ge1xuICAgICAgaWYgKGRvbVJlZmVyZW5jZSAmJiB0eXBlID09PSAncmVmZXJlbmNlJykge1xuICAgICAgICByZXR1cm4gZG9tUmVmZXJlbmNlO1xuICAgICAgfVxuICAgICAgaWYgKGZsb2F0aW5nRm9jdXNFbGVtZW50ICYmIHR5cGUgPT09ICdmbG9hdGluZycpIHtcbiAgICAgICAgcmV0dXJuIGZsb2F0aW5nRm9jdXNFbGVtZW50O1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNvbnRlbnQ7XG4gICAgfSkuZmlsdGVyKEJvb2xlYW4pLmZsYXQoKTtcbiAgfSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkKSByZXR1cm47XG4gICAgaWYgKCFtb2RhbCkgcmV0dXJuO1xuICAgIGZ1bmN0aW9uIG9uS2V5RG93bihldmVudCkge1xuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ1RhYicpIHtcbiAgICAgICAgLy8gVGhlIGZvY3VzIGd1YXJkcyBoYXZlIG5vdGhpbmcgdG8gZm9jdXMsIHNvIHdlIG5lZWQgdG8gc3RvcCB0aGUgZXZlbnQuXG4gICAgICAgIGlmIChjb250YWlucyhmbG9hdGluZ0ZvY3VzRWxlbWVudCwgYWN0aXZlRWxlbWVudChnZXREb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpKSAmJiBnZXRUYWJiYWJsZUNvbnRlbnQoKS5sZW5ndGggPT09IDAgJiYgIWlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCkge1xuICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZWxzID0gZ2V0VGFiYmFibGVFbGVtZW50cygpO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgICBpZiAob3JkZXJSZWYuY3VycmVudFswXSA9PT0gJ3JlZmVyZW5jZScgJiYgdGFyZ2V0ID09PSBkb21SZWZlcmVuY2UpIHtcbiAgICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICAgIGlmIChldmVudC5zaGlmdEtleSkge1xuICAgICAgICAgICAgZW5xdWV1ZUZvY3VzKGVsc1tlbHMubGVuZ3RoIC0gMV0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlbnF1ZXVlRm9jdXMoZWxzWzFdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9yZGVyUmVmLmN1cnJlbnRbMV0gPT09ICdmbG9hdGluZycgJiYgdGFyZ2V0ID09PSBmbG9hdGluZ0ZvY3VzRWxlbWVudCAmJiBldmVudC5zaGlmdEtleSkge1xuICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgICAgZW5xdWV1ZUZvY3VzKGVsc1swXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZG9jID0gZ2V0RG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24pO1xuICAgIH07XG4gIH0sIFtkaXNhYmxlZCwgZG9tUmVmZXJlbmNlLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgbW9kYWwsIG9yZGVyUmVmLCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsIGdldFRhYmJhYmxlQ29udGVudCwgZ2V0VGFiYmFibGVFbGVtZW50c10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCkgcmV0dXJuO1xuICAgIGlmICghZmxvYXRpbmcpIHJldHVybjtcbiAgICBmdW5jdGlvbiBoYW5kbGVGb2N1c0luKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgY29uc3QgdGFiYmFibGVDb250ZW50ID0gZ2V0VGFiYmFibGVDb250ZW50KCk7XG4gICAgICBjb25zdCB0YWJiYWJsZUluZGV4ID0gdGFiYmFibGVDb250ZW50LmluZGV4T2YodGFyZ2V0KTtcbiAgICAgIGlmICh0YWJiYWJsZUluZGV4ICE9PSAtMSkge1xuICAgICAgICB0YWJiYWJsZUluZGV4UmVmLmN1cnJlbnQgPSB0YWJiYWJsZUluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgICBmbG9hdGluZy5hZGRFdmVudExpc3RlbmVyKCdmb2N1c2luJywgaGFuZGxlRm9jdXNJbik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZsb2F0aW5nLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2ZvY3VzaW4nLCBoYW5kbGVGb2N1c0luKTtcbiAgICB9O1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nLCBnZXRUYWJiYWJsZUNvbnRlbnRdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQpIHJldHVybjtcbiAgICBpZiAoIWNsb3NlT25Gb2N1c091dCkgcmV0dXJuO1xuXG4gICAgLy8gSW4gU2FmYXJpLCBidXR0b25zIGxvc2UgZm9jdXMgd2hlbiBwcmVzc2luZyB0aGVtLlxuICAgIGZ1bmN0aW9uIGhhbmRsZVBvaW50ZXJEb3duKCkge1xuICAgICAgaXNQb2ludGVyRG93blJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVGb2N1c091dHNpZGUoZXZlbnQpIHtcbiAgICAgIGNvbnN0IHJlbGF0ZWRUYXJnZXQgPSBldmVudC5yZWxhdGVkVGFyZ2V0O1xuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBjb25zdCBtb3ZlZFRvVW5yZWxhdGVkTm9kZSA9ICEoY29udGFpbnMoZG9tUmVmZXJlbmNlLCByZWxhdGVkVGFyZ2V0KSB8fCBjb250YWlucyhmbG9hdGluZywgcmVsYXRlZFRhcmdldCkgfHwgY29udGFpbnMocmVsYXRlZFRhcmdldCwgZmxvYXRpbmcpIHx8IGNvbnRhaW5zKHBvcnRhbENvbnRleHQgPT0gbnVsbCA/IHZvaWQgMCA6IHBvcnRhbENvbnRleHQucG9ydGFsTm9kZSwgcmVsYXRlZFRhcmdldCkgfHwgcmVsYXRlZFRhcmdldCAhPSBudWxsICYmIHJlbGF0ZWRUYXJnZXQuaGFzQXR0cmlidXRlKGNyZWF0ZUF0dHJpYnV0ZSgnZm9jdXMtZ3VhcmQnKSkgfHwgdHJlZSAmJiAoZ2V0Q2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpLmZpbmQobm9kZSA9PiB7XG4gICAgICAgICAgdmFyIF9ub2RlJGNvbnRleHQsIF9ub2RlJGNvbnRleHQyO1xuICAgICAgICAgIHJldHVybiBjb250YWlucygoX25vZGUkY29udGV4dCA9IG5vZGUuY29udGV4dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJGNvbnRleHQuZWxlbWVudHMuZmxvYXRpbmcsIHJlbGF0ZWRUYXJnZXQpIHx8IGNvbnRhaW5zKChfbm9kZSRjb250ZXh0MiA9IG5vZGUuY29udGV4dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJGNvbnRleHQyLmVsZW1lbnRzLmRvbVJlZmVyZW5jZSwgcmVsYXRlZFRhcmdldCk7XG4gICAgICAgIH0pIHx8IGdldEFuY2VzdG9ycyh0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuZmluZChub2RlID0+IHtcbiAgICAgICAgICB2YXIgX25vZGUkY29udGV4dDMsIF9ub2RlJGNvbnRleHQ0O1xuICAgICAgICAgIHJldHVybiAoKF9ub2RlJGNvbnRleHQzID0gbm9kZS5jb250ZXh0KSA9PSBudWxsID8gdm9pZCAwIDogX25vZGUkY29udGV4dDMuZWxlbWVudHMuZmxvYXRpbmcpID09PSByZWxhdGVkVGFyZ2V0IHx8ICgoX25vZGUkY29udGV4dDQgPSBub2RlLmNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRjb250ZXh0NC5lbGVtZW50cy5kb21SZWZlcmVuY2UpID09PSByZWxhdGVkVGFyZ2V0O1xuICAgICAgICB9KSkpO1xuXG4gICAgICAgIC8vIFJlc3RvcmUgZm9jdXMgdG8gdGhlIHByZXZpb3VzIHRhYmJhYmxlIGVsZW1lbnQgaW5kZXggdG8gcHJldmVudFxuICAgICAgICAvLyBmb2N1cyBmcm9tIGJlaW5nIGxvc3Qgb3V0c2lkZSB0aGUgZmxvYXRpbmcgdHJlZS5cbiAgICAgICAgaWYgKHJlc3RvcmVGb2N1cyAmJiBtb3ZlZFRvVW5yZWxhdGVkTm9kZSAmJiBhY3RpdmVFbGVtZW50KGdldERvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KSkgPT09IGdldERvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KS5ib2R5KSB7XG4gICAgICAgICAgLy8gTGV0IGBGbG9hdGluZ1BvcnRhbGAgZWZmZWN0IGtub3dzIHRoYXQgZm9jdXMgaXMgc3RpbGwgaW5zaWRlIHRoZVxuICAgICAgICAgIC8vIGZsb2F0aW5nIHRyZWUuXG4gICAgICAgICAgaWYgKGlzSFRNTEVsZW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpKSB7XG4gICAgICAgICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGVJbmRleCA9IHRhYmJhYmxlSW5kZXhSZWYuY3VycmVudDtcbiAgICAgICAgICBjb25zdCB0YWJiYWJsZUNvbnRlbnQgPSBnZXRUYWJiYWJsZUNvbnRlbnQoKTtcbiAgICAgICAgICBjb25zdCBub2RlVG9Gb2N1cyA9IHRhYmJhYmxlQ29udGVudFtwcmV2VGFiYmFibGVJbmRleF0gfHwgdGFiYmFibGVDb250ZW50W3RhYmJhYmxlQ29udGVudC5sZW5ndGggLSAxXSB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICAgICAgICBpZiAoaXNIVE1MRWxlbWVudChub2RlVG9Gb2N1cykpIHtcbiAgICAgICAgICAgIG5vZGVUb0ZvY3VzLmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gRm9jdXMgZGlkIG5vdCBtb3ZlIGluc2lkZSB0aGUgZmxvYXRpbmcgdHJlZSwgYW5kIHRoZXJlIGFyZSBubyB0YWJiYWJsZVxuICAgICAgICAvLyBwb3J0YWwgZ3VhcmRzIHRvIGhhbmRsZSBjbG9zaW5nLlxuICAgICAgICBpZiAoKGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCA/IHRydWUgOiAhbW9kYWwpICYmIHJlbGF0ZWRUYXJnZXQgJiYgbW92ZWRUb1VucmVsYXRlZE5vZGUgJiYgIWlzUG9pbnRlckRvd25SZWYuY3VycmVudCAmJlxuICAgICAgICAvLyBGaXggUmVhY3QgMTggU3RyaWN0IE1vZGUgcmV0dXJuRm9jdXMgZHVlIHRvIGRvdWJsZSByZW5kZXJpbmcuXG4gICAgICAgIHJlbGF0ZWRUYXJnZXQgIT09IGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpKSB7XG4gICAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQsICdmb2N1cy1vdXQnKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChmbG9hdGluZyAmJiBpc0hUTUxFbGVtZW50KGRvbVJlZmVyZW5jZSkpIHtcbiAgICAgIGRvbVJlZmVyZW5jZS5hZGRFdmVudExpc3RlbmVyKCdmb2N1c291dCcsIGhhbmRsZUZvY3VzT3V0c2lkZSk7XG4gICAgICBkb21SZWZlcmVuY2UuYWRkRXZlbnRMaXN0ZW5lcigncG9pbnRlcmRvd24nLCBoYW5kbGVQb2ludGVyRG93bik7XG4gICAgICBmbG9hdGluZy5hZGRFdmVudExpc3RlbmVyKCdmb2N1c291dCcsIGhhbmRsZUZvY3VzT3V0c2lkZSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBkb21SZWZlcmVuY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcignZm9jdXNvdXQnLCBoYW5kbGVGb2N1c091dHNpZGUpO1xuICAgICAgICBkb21SZWZlcmVuY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcmRvd24nLCBoYW5kbGVQb2ludGVyRG93bik7XG4gICAgICAgIGZsb2F0aW5nLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2ZvY3Vzb3V0JywgaGFuZGxlRm9jdXNPdXRzaWRlKTtcbiAgICAgIH07XG4gICAgfVxuICB9LCBbZGlzYWJsZWQsIGRvbVJlZmVyZW5jZSwgZmxvYXRpbmcsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCBtb2RhbCwgbm9kZUlkLCB0cmVlLCBwb3J0YWxDb250ZXh0LCBvbk9wZW5DaGFuZ2UsIGNsb3NlT25Gb2N1c091dCwgcmVzdG9yZUZvY3VzLCBnZXRUYWJiYWJsZUNvbnRlbnQsIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveF0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZhciBfcG9ydGFsQ29udGV4dCRwb3J0YWw7XG4gICAgaWYgKGRpc2FibGVkKSByZXR1cm47XG5cbiAgICAvLyBEb24ndCBoaWRlIHBvcnRhbHMgbmVzdGVkIHdpdGhpbiB0aGUgcGFyZW50IHBvcnRhbC5cbiAgICBjb25zdCBwb3J0YWxOb2RlcyA9IEFycmF5LmZyb20oKHBvcnRhbENvbnRleHQgPT0gbnVsbCB8fCAoX3BvcnRhbENvbnRleHQkcG9ydGFsID0gcG9ydGFsQ29udGV4dC5wb3J0YWxOb2RlKSA9PSBudWxsID8gdm9pZCAwIDogX3BvcnRhbENvbnRleHQkcG9ydGFsLnF1ZXJ5U2VsZWN0b3JBbGwoXCJbXCIgKyBjcmVhdGVBdHRyaWJ1dGUoJ3BvcnRhbCcpICsgXCJdXCIpKSB8fCBbXSk7XG4gICAgaWYgKGZsb2F0aW5nKSB7XG4gICAgICBjb25zdCBpbnNpZGVFbGVtZW50cyA9IFtmbG9hdGluZywgLi4ucG9ydGFsTm9kZXMsIHN0YXJ0RGlzbWlzc0J1dHRvblJlZi5jdXJyZW50LCBlbmREaXNtaXNzQnV0dG9uUmVmLmN1cnJlbnQsIG9yZGVyUmVmLmN1cnJlbnQuaW5jbHVkZXMoJ3JlZmVyZW5jZScpIHx8IGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCA/IGRvbVJlZmVyZW5jZSA6IG51bGxdLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG4gICAgICBjb25zdCBjbGVhbnVwID0gbW9kYWwgfHwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94ID8gbWFya090aGVycyhpbnNpZGVFbGVtZW50cywgZ3VhcmRzLCAhZ3VhcmRzKSA6IG1hcmtPdGhlcnMoaW5zaWRlRWxlbWVudHMpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgfTtcbiAgICB9XG4gIH0sIFtkaXNhYmxlZCwgZG9tUmVmZXJlbmNlLCBmbG9hdGluZywgbW9kYWwsIG9yZGVyUmVmLCBwb3J0YWxDb250ZXh0LCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsIGd1YXJkc10pO1xuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkIHx8ICFpc0hUTUxFbGVtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KSkgcmV0dXJuO1xuICAgIGNvbnN0IGRvYyA9IGdldERvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICBjb25zdCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQgPSBhY3RpdmVFbGVtZW50KGRvYyk7XG5cbiAgICAvLyBXYWl0IGZvciBhbnkgbGF5b3V0IGVmZmVjdCBzdGF0ZSBzZXR0ZXJzIHRvIGV4ZWN1dGUgdG8gc2V0IGB0YWJJbmRleGAuXG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgY29uc3QgZm9jdXNhYmxlRWxlbWVudHMgPSBnZXRUYWJiYWJsZUVsZW1lbnRzKGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICAgIGNvbnN0IGluaXRpYWxGb2N1c1ZhbHVlID0gaW5pdGlhbEZvY3VzUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCBlbFRvRm9jdXMgPSAodHlwZW9mIGluaXRpYWxGb2N1c1ZhbHVlID09PSAnbnVtYmVyJyA/IGZvY3VzYWJsZUVsZW1lbnRzW2luaXRpYWxGb2N1c1ZhbHVlXSA6IGluaXRpYWxGb2N1c1ZhbHVlLmN1cnJlbnQpIHx8IGZsb2F0aW5nRm9jdXNFbGVtZW50O1xuICAgICAgY29uc3QgZm9jdXNBbHJlYWR5SW5zaWRlRmxvYXRpbmdFbCA9IGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpO1xuICAgICAgaWYgKCFpZ25vcmVJbml0aWFsRm9jdXMgJiYgIWZvY3VzQWxyZWFkeUluc2lkZUZsb2F0aW5nRWwgJiYgb3Blbikge1xuICAgICAgICBlbnF1ZXVlRm9jdXMoZWxUb0ZvY3VzLCB7XG4gICAgICAgICAgcHJldmVudFNjcm9sbDogZWxUb0ZvY3VzID09PSBmbG9hdGluZ0ZvY3VzRWxlbWVudFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW2Rpc2FibGVkLCBvcGVuLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgaWdub3JlSW5pdGlhbEZvY3VzLCBnZXRUYWJiYWJsZUVsZW1lbnRzLCBpbml0aWFsRm9jdXNSZWZdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHJldHVybjtcbiAgICBsZXQgcHJldmVudFJldHVybkZvY3VzU2Nyb2xsID0gZmFsc2U7XG4gICAgY29uc3QgZG9jID0gZ2V0RG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICBjb25zdCBjb250ZXh0RGF0YSA9IGRhdGFSZWYuY3VycmVudDtcbiAgICBsZXQgb3BlbkV2ZW50ID0gY29udGV4dERhdGEub3BlbkV2ZW50O1xuICAgIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudChwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpO1xuXG4gICAgLy8gRGlzbWlzc2luZyB2aWEgb3V0c2lkZSBwcmVzcyBzaG91bGQgYWx3YXlzIGlnbm9yZSBgcmV0dXJuRm9jdXNgIHRvXG4gICAgLy8gcHJldmVudCB1bndhbnRlZCBzY3JvbGxpbmcuXG4gICAgZnVuY3Rpb24gb25PcGVuQ2hhbmdlKF9yZWYpIHtcbiAgICAgIGxldCB7XG4gICAgICAgIG9wZW4sXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgZXZlbnQsXG4gICAgICAgIG5lc3RlZFxuICAgICAgfSA9IF9yZWY7XG4gICAgICBpZiAob3Blbikge1xuICAgICAgICBvcGVuRXZlbnQgPSBldmVudDtcbiAgICAgIH1cbiAgICAgIGlmIChyZWFzb24gPT09ICdlc2NhcGUta2V5JyAmJiByZWZzLmRvbVJlZmVyZW5jZS5jdXJyZW50KSB7XG4gICAgICAgIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudChyZWZzLmRvbVJlZmVyZW5jZS5jdXJyZW50KTtcbiAgICAgIH1cbiAgICAgIGlmIChyZWFzb24gPT09ICdob3ZlcicgJiYgZXZlbnQudHlwZSA9PT0gJ21vdXNlbGVhdmUnKSB7XG4gICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChyZWFzb24gIT09ICdvdXRzaWRlLXByZXNzJykgcmV0dXJuO1xuICAgICAgaWYgKG5lc3RlZCkge1xuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNTY3JvbGwgPSB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSAhKGlzVmlydHVhbENsaWNrKGV2ZW50KSB8fCBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZXZlbnRzLm9uKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlKTtcbiAgICBjb25zdCBmYWxsYmFja0VsID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBmYWxsYmFja0VsLnNldEF0dHJpYnV0ZSgndGFiaW5kZXgnLCAnLTEnKTtcbiAgICBmYWxsYmFja0VsLnNldEF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nLCAndHJ1ZScpO1xuICAgIE9iamVjdC5hc3NpZ24oZmFsbGJhY2tFbC5zdHlsZSwgSElEREVOX1NUWUxFUyk7XG4gICAgaWYgKGlzSW5zaWRlUG9ydGFsICYmIGRvbVJlZmVyZW5jZSkge1xuICAgICAgZG9tUmVmZXJlbmNlLmluc2VydEFkamFjZW50RWxlbWVudCgnYWZ0ZXJlbmQnLCBmYWxsYmFja0VsKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0UmV0dXJuRWxlbWVudCgpIHtcbiAgICAgIGlmICh0eXBlb2YgcmV0dXJuRm9jdXNSZWYuY3VycmVudCA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiBnZXRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoKSB8fCBmYWxsYmFja0VsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJldHVybkZvY3VzUmVmLmN1cnJlbnQuY3VycmVudCB8fCBmYWxsYmFja0VsO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRzLm9mZignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZSk7XG4gICAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICAgIGNvbnN0IGlzRm9jdXNJbnNpZGVGbG9hdGluZ1RyZWUgPSBjb250YWlucyhmbG9hdGluZywgYWN0aXZlRWwpIHx8IHRyZWUgJiYgZ2V0Q2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpLnNvbWUobm9kZSA9PiB7XG4gICAgICAgIHZhciBfbm9kZSRjb250ZXh0NTtcbiAgICAgICAgcmV0dXJuIGNvbnRhaW5zKChfbm9kZSRjb250ZXh0NSA9IG5vZGUuY29udGV4dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJGNvbnRleHQ1LmVsZW1lbnRzLmZsb2F0aW5nLCBhY3RpdmVFbCk7XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHNob3VsZEZvY3VzUmVmZXJlbmNlID0gaXNGb2N1c0luc2lkZUZsb2F0aW5nVHJlZSB8fCBvcGVuRXZlbnQgJiYgWydjbGljaycsICdtb3VzZWRvd24nXS5pbmNsdWRlcyhvcGVuRXZlbnQudHlwZSk7XG4gICAgICBpZiAoc2hvdWxkRm9jdXNSZWZlcmVuY2UgJiYgcmVmcy5kb21SZWZlcmVuY2UuY3VycmVudCkge1xuICAgICAgICBhZGRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQocmVmcy5kb21SZWZlcmVuY2UuY3VycmVudCk7XG4gICAgICB9XG4gICAgICBjb25zdCByZXR1cm5FbGVtZW50ID0gZ2V0UmV0dXJuRWxlbWVudCgpO1xuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBpZiAoXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICAgICAgcmV0dXJuRm9jdXNSZWYuY3VycmVudCAmJiAhcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgJiYgaXNIVE1MRWxlbWVudChyZXR1cm5FbGVtZW50KSAmJiAoXG4gICAgICAgIC8vIElmIHRoZSBmb2N1cyBtb3ZlZCBzb21ld2hlcmUgZWxzZSBhZnRlciBtb3VudCwgYXZvaWQgcmV0dXJuaW5nIGZvY3VzXG4gICAgICAgIC8vIHNpbmNlIGl0IGxpa2VseSBlbnRlcmVkIGEgZGlmZmVyZW50IGVsZW1lbnQgd2hpY2ggc2hvdWxkIGJlXG4gICAgICAgIC8vIHJlc3BlY3RlZDogaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8yNjA3XG4gICAgICAgIHJldHVybkVsZW1lbnQgIT09IGFjdGl2ZUVsICYmIGFjdGl2ZUVsICE9PSBkb2MuYm9keSA/IGlzRm9jdXNJbnNpZGVGbG9hdGluZ1RyZWUgOiB0cnVlKSkge1xuICAgICAgICAgIHJldHVybkVsZW1lbnQuZm9jdXMoe1xuICAgICAgICAgICAgcHJldmVudFNjcm9sbDogcHJldmVudFJldHVybkZvY3VzU2Nyb2xsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZmFsbGJhY2tFbC5yZW1vdmUoKTtcbiAgICAgIH0pO1xuICAgIH07XG4gIH0sIFtkaXNhYmxlZCwgZmxvYXRpbmcsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCByZXR1cm5Gb2N1c1JlZiwgZGF0YVJlZiwgcmVmcywgZXZlbnRzLCB0cmVlLCBub2RlSWQsIGlzSW5zaWRlUG9ydGFsLCBkb21SZWZlcmVuY2VdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBUaGUgYHJldHVybkZvY3VzYCBjbGVhbnVwIGJlaGF2aW9yIGlzIGluc2lkZSBhIG1pY3JvdGFzazsgZW5zdXJlIHdlXG4gICAgLy8gd2FpdCBmb3IgaXQgdG8gY29tcGxldGUgYmVmb3JlIHJlc2V0dGluZyB0aGUgZmxhZy5cbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH0pO1xuICB9LCBbZGlzYWJsZWRdKTtcblxuICAvLyBTeW5jaHJvbml6ZSB0aGUgYGNvbnRleHRgICYgYG1vZGFsYCB2YWx1ZSB0byB0aGUgRmxvYXRpbmdQb3J0YWwgY29udGV4dC5cbiAgLy8gSXQgd2lsbCBkZWNpZGUgd2hldGhlciBvciBub3QgaXQgbmVlZHMgdG8gcmVuZGVyIGl0cyBvd24gZ3VhcmRzLlxuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkKSByZXR1cm47XG4gICAgaWYgKCFwb3J0YWxDb250ZXh0KSByZXR1cm47XG4gICAgcG9ydGFsQ29udGV4dC5zZXRGb2N1c01hbmFnZXJTdGF0ZSh7XG4gICAgICBtb2RhbCxcbiAgICAgIGNsb3NlT25Gb2N1c091dCxcbiAgICAgIG9wZW4sXG4gICAgICBvbk9wZW5DaGFuZ2UsXG4gICAgICByZWZzXG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHBvcnRhbENvbnRleHQuc2V0Rm9jdXNNYW5hZ2VyU3RhdGUobnVsbCk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBwb3J0YWxDb250ZXh0LCBtb2RhbCwgb3Blbiwgb25PcGVuQ2hhbmdlLCByZWZzLCBjbG9zZU9uRm9jdXNPdXRdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCkgcmV0dXJuO1xuICAgIGlmICghZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHJldHVybjtcbiAgICBpZiAodHlwZW9mIE11dGF0aW9uT2JzZXJ2ZXIgIT09ICdmdW5jdGlvbicpIHJldHVybjtcbiAgICBpZiAoaWdub3JlSW5pdGlhbEZvY3VzKSByZXR1cm47XG4gICAgY29uc3QgaGFuZGxlTXV0YXRpb24gPSAoKSA9PiB7XG4gICAgICBjb25zdCB0YWJJbmRleCA9IGZsb2F0aW5nRm9jdXNFbGVtZW50LmdldEF0dHJpYnV0ZSgndGFiaW5kZXgnKTtcbiAgICAgIGNvbnN0IHRhYmJhYmxlQ29udGVudCA9IGdldFRhYmJhYmxlQ29udGVudCgpO1xuICAgICAgY29uc3QgYWN0aXZlRWwgPSBhY3RpdmVFbGVtZW50KGdldERvY3VtZW50KGZsb2F0aW5nKSk7XG4gICAgICBjb25zdCB0YWJiYWJsZUluZGV4ID0gdGFiYmFibGVDb250ZW50LmluZGV4T2YoYWN0aXZlRWwpO1xuICAgICAgaWYgKHRhYmJhYmxlSW5kZXggIT09IC0xKSB7XG4gICAgICAgIHRhYmJhYmxlSW5kZXhSZWYuY3VycmVudCA9IHRhYmJhYmxlSW5kZXg7XG4gICAgICB9XG4gICAgICBpZiAob3JkZXJSZWYuY3VycmVudC5pbmNsdWRlcygnZmxvYXRpbmcnKSB8fCBhY3RpdmVFbCAhPT0gcmVmcy5kb21SZWZlcmVuY2UuY3VycmVudCAmJiB0YWJiYWJsZUNvbnRlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGlmICh0YWJJbmRleCAhPT0gJzAnKSB7XG4gICAgICAgICAgZmxvYXRpbmdGb2N1c0VsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICcwJyk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAodGFiSW5kZXggIT09ICctMScpIHtcbiAgICAgICAgZmxvYXRpbmdGb2N1c0VsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICAgICAgfVxuICAgIH07XG4gICAgaGFuZGxlTXV0YXRpb24oKTtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGhhbmRsZU11dGF0aW9uKTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKGZsb2F0aW5nRm9jdXNFbGVtZW50LCB7XG4gICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICBzdWJ0cmVlOiB0cnVlLFxuICAgICAgYXR0cmlidXRlczogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBmbG9hdGluZywgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIHJlZnMsIG9yZGVyUmVmLCBnZXRUYWJiYWJsZUNvbnRlbnQsIGlnbm9yZUluaXRpYWxGb2N1c10pO1xuICBmdW5jdGlvbiByZW5kZXJEaXNtaXNzQnV0dG9uKGxvY2F0aW9uKSB7XG4gICAgaWYgKGRpc2FibGVkIHx8ICF2aXN1YWxseUhpZGRlbkRpc21pc3MgfHwgIW1vZGFsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFZpc3VhbGx5SGlkZGVuRGlzbWlzcywge1xuICAgICAgcmVmOiBsb2NhdGlvbiA9PT0gJ3N0YXJ0JyA/IHN0YXJ0RGlzbWlzc0J1dHRvblJlZiA6IGVuZERpc21pc3NCdXR0b25SZWYsXG4gICAgICBvbkNsaWNrOiBldmVudCA9PiBvbk9wZW5DaGFuZ2UoZmFsc2UsIGV2ZW50Lm5hdGl2ZUV2ZW50KVxuICAgIH0sIHR5cGVvZiB2aXN1YWxseUhpZGRlbkRpc21pc3MgPT09ICdzdHJpbmcnID8gdmlzdWFsbHlIaWRkZW5EaXNtaXNzIDogJ0Rpc21pc3MnKTtcbiAgfVxuICBjb25zdCBzaG91bGRSZW5kZXJHdWFyZHMgPSAhZGlzYWJsZWQgJiYgZ3VhcmRzICYmIChtb2RhbCA/ICFpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggOiB0cnVlKSAmJiAoaXNJbnNpZGVQb3J0YWwgfHwgbW9kYWwpO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIHNob3VsZFJlbmRlckd1YXJkcyAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGb2N1c0d1YXJkLCB7XG4gICAgXCJkYXRhLXR5cGVcIjogXCJpbnNpZGVcIixcbiAgICByZWY6IHBvcnRhbENvbnRleHQgPT0gbnVsbCA/IHZvaWQgMCA6IHBvcnRhbENvbnRleHQuYmVmb3JlSW5zaWRlUmVmLFxuICAgIG9uRm9jdXM6IGV2ZW50ID0+IHtcbiAgICAgIGlmIChtb2RhbCkge1xuICAgICAgICBjb25zdCBlbHMgPSBnZXRUYWJiYWJsZUVsZW1lbnRzKCk7XG4gICAgICAgIGVucXVldWVGb2N1cyhvcmRlclswXSA9PT0gJ3JlZmVyZW5jZScgPyBlbHNbMF0gOiBlbHNbZWxzLmxlbmd0aCAtIDFdKTtcbiAgICAgIH0gZWxzZSBpZiAocG9ydGFsQ29udGV4dCAhPSBudWxsICYmIHBvcnRhbENvbnRleHQucHJlc2VydmVUYWJPcmRlciAmJiBwb3J0YWxDb250ZXh0LnBvcnRhbE5vZGUpIHtcbiAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxDb250ZXh0LnBvcnRhbE5vZGUpKSB7XG4gICAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKCkgfHwgZG9tUmVmZXJlbmNlO1xuICAgICAgICAgIG5leHRUYWJiYWJsZSA9PSBudWxsIHx8IG5leHRUYWJiYWJsZS5mb2N1cygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhciBfcG9ydGFsQ29udGV4dCRiZWZvcmU7XG4gICAgICAgICAgKF9wb3J0YWxDb250ZXh0JGJlZm9yZSA9IHBvcnRhbENvbnRleHQuYmVmb3JlT3V0c2lkZVJlZi5jdXJyZW50KSA9PSBudWxsIHx8IF9wb3J0YWxDb250ZXh0JGJlZm9yZS5mb2N1cygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9KSwgIWlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCAmJiByZW5kZXJEaXNtaXNzQnV0dG9uKCdzdGFydCcpLCBjaGlsZHJlbiwgcmVuZGVyRGlzbWlzc0J1dHRvbignZW5kJyksIHNob3VsZFJlbmRlckd1YXJkcyAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGb2N1c0d1YXJkLCB7XG4gICAgXCJkYXRhLXR5cGVcIjogXCJpbnNpZGVcIixcbiAgICByZWY6IHBvcnRhbENvbnRleHQgPT0gbnVsbCA/IHZvaWQgMCA6IHBvcnRhbENvbnRleHQuYWZ0ZXJJbnNpZGVSZWYsXG4gICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgaWYgKG1vZGFsKSB7XG4gICAgICAgIGVucXVldWVGb2N1cyhnZXRUYWJiYWJsZUVsZW1lbnRzKClbMF0pO1xuICAgICAgfSBlbHNlIGlmIChwb3J0YWxDb250ZXh0ICE9IG51bGwgJiYgcG9ydGFsQ29udGV4dC5wcmVzZXJ2ZVRhYk9yZGVyICYmIHBvcnRhbENvbnRleHQucG9ydGFsTm9kZSkge1xuICAgICAgICBpZiAoY2xvc2VPbkZvY3VzT3V0KSB7XG4gICAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc091dHNpZGVFdmVudChldmVudCwgcG9ydGFsQ29udGV4dC5wb3J0YWxOb2RlKSkge1xuICAgICAgICAgIGNvbnN0IHByZXZUYWJiYWJsZSA9IGdldFByZXZpb3VzVGFiYmFibGUoKSB8fCBkb21SZWZlcmVuY2U7XG4gICAgICAgICAgcHJldlRhYmJhYmxlID09IG51bGwgfHwgcHJldlRhYmJhYmxlLmZvY3VzKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdmFyIF9wb3J0YWxDb250ZXh0JGFmdGVyTztcbiAgICAgICAgICAoX3BvcnRhbENvbnRleHQkYWZ0ZXJPID0gcG9ydGFsQ29udGV4dC5hZnRlck91dHNpZGVSZWYuY3VycmVudCkgPT0gbnVsbCB8fCBfcG9ydGFsQ29udGV4dCRhZnRlck8uZm9jdXMoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSkpO1xufVxuXG5sZXQgbG9ja0NvdW50ID0gMDtcbmZ1bmN0aW9uIGVuYWJsZVNjcm9sbExvY2soKSB7XG4gIGNvbnN0IGlzSU9TID0gL2lQKGhvbmV8YWR8b2QpfGlPUy8udGVzdChnZXRQbGF0Zm9ybSgpKTtcbiAgY29uc3QgYm9keVN0eWxlID0gZG9jdW1lbnQuYm9keS5zdHlsZTtcbiAgLy8gUlRMIDxib2R5PiBzY3JvbGxiYXJcbiAgY29uc3Qgc2Nyb2xsYmFyWCA9IE1hdGgucm91bmQoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQpICsgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbExlZnQ7XG4gIGNvbnN0IHBhZGRpbmdQcm9wID0gc2Nyb2xsYmFyWCA/ICdwYWRkaW5nTGVmdCcgOiAncGFkZGluZ1JpZ2h0JztcbiAgY29uc3Qgc2Nyb2xsYmFyV2lkdGggPSB3aW5kb3cuaW5uZXJXaWR0aCAtIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtcbiAgY29uc3Qgc2Nyb2xsWCA9IGJvZHlTdHlsZS5sZWZ0ID8gcGFyc2VGbG9hdChib2R5U3R5bGUubGVmdCkgOiB3aW5kb3cuc2Nyb2xsWDtcbiAgY29uc3Qgc2Nyb2xsWSA9IGJvZHlTdHlsZS50b3AgPyBwYXJzZUZsb2F0KGJvZHlTdHlsZS50b3ApIDogd2luZG93LnNjcm9sbFk7XG4gIGJvZHlTdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICBpZiAoc2Nyb2xsYmFyV2lkdGgpIHtcbiAgICBib2R5U3R5bGVbcGFkZGluZ1Byb3BdID0gc2Nyb2xsYmFyV2lkdGggKyBcInB4XCI7XG4gIH1cblxuICAvLyBPbmx5IGlPUyBkb2Vzbid0IHJlc3BlY3QgYG92ZXJmbG93OiBoaWRkZW5gIG9uIGRvY3VtZW50LmJvZHksIGFuZCB0aGlzXG4gIC8vIHRlY2huaXF1ZSBoYXMgZmV3ZXIgc2lkZSBlZmZlY3RzLlxuICBpZiAoaXNJT1MpIHtcbiAgICB2YXIgX3dpbmRvdyR2aXN1YWxWaWV3cG9yLCBfd2luZG93JHZpc3VhbFZpZXdwb3IyO1xuICAgIC8vIGlPUyAxMiBkb2VzIG5vdCBzdXBwb3J0IGB2aXN1YWxWaWV3cG9ydGAuXG4gICAgY29uc3Qgb2Zmc2V0TGVmdCA9ICgoX3dpbmRvdyR2aXN1YWxWaWV3cG9yID0gd2luZG93LnZpc3VhbFZpZXdwb3J0KSA9PSBudWxsID8gdm9pZCAwIDogX3dpbmRvdyR2aXN1YWxWaWV3cG9yLm9mZnNldExlZnQpIHx8IDA7XG4gICAgY29uc3Qgb2Zmc2V0VG9wID0gKChfd2luZG93JHZpc3VhbFZpZXdwb3IyID0gd2luZG93LnZpc3VhbFZpZXdwb3J0KSA9PSBudWxsID8gdm9pZCAwIDogX3dpbmRvdyR2aXN1YWxWaWV3cG9yMi5vZmZzZXRUb3ApIHx8IDA7XG4gICAgT2JqZWN0LmFzc2lnbihib2R5U3R5bGUsIHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgdG9wOiAtKHNjcm9sbFkgLSBNYXRoLmZsb29yKG9mZnNldFRvcCkpICsgXCJweFwiLFxuICAgICAgbGVmdDogLShzY3JvbGxYIC0gTWF0aC5mbG9vcihvZmZzZXRMZWZ0KSkgKyBcInB4XCIsXG4gICAgICByaWdodDogJzAnXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuICgpID0+IHtcbiAgICBPYmplY3QuYXNzaWduKGJvZHlTdHlsZSwge1xuICAgICAgb3ZlcmZsb3c6ICcnLFxuICAgICAgW3BhZGRpbmdQcm9wXTogJydcbiAgICB9KTtcbiAgICBpZiAoaXNJT1MpIHtcbiAgICAgIE9iamVjdC5hc3NpZ24oYm9keVN0eWxlLCB7XG4gICAgICAgIHBvc2l0aW9uOiAnJyxcbiAgICAgICAgdG9wOiAnJyxcbiAgICAgICAgbGVmdDogJycsXG4gICAgICAgIHJpZ2h0OiAnJ1xuICAgICAgfSk7XG4gICAgICB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsWCwgc2Nyb2xsWSk7XG4gICAgfVxuICB9O1xufVxubGV0IGNsZWFudXAgPSAoKSA9PiB7fTtcblxuLyoqXG4gKiBQcm92aWRlcyBiYXNlIHN0eWxpbmcgZm9yIGEgZml4ZWQgb3ZlcmxheSBlbGVtZW50IHRvIGRpbSBjb250ZW50IG9yIGJsb2NrXG4gKiBwb2ludGVyIGV2ZW50cyBiZWhpbmQgYSBmbG9hdGluZyBlbGVtZW50LlxuICogSXQncyBhIHJlZ3VsYXIgYDxkaXY+YCwgc28gaXQgY2FuIGJlIHN0eWxlZCB2aWEgYW55IENTUyBzb2x1dGlvbiB5b3UgcHJlZmVyLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nT3ZlcmxheVxuICovXG5jb25zdCBGbG9hdGluZ092ZXJsYXkgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBGbG9hdGluZ092ZXJsYXkocHJvcHMsIHJlZikge1xuICBjb25zdCB7XG4gICAgbG9ja1Njcm9sbCA9IGZhbHNlLFxuICAgIC4uLnJlc3RcbiAgfSA9IHByb3BzO1xuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKCFsb2NrU2Nyb2xsKSByZXR1cm47XG4gICAgbG9ja0NvdW50Kys7XG4gICAgaWYgKGxvY2tDb3VudCA9PT0gMSkge1xuICAgICAgY2xlYW51cCA9IGVuYWJsZVNjcm9sbExvY2soKTtcbiAgICB9XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGxvY2tDb3VudC0tO1xuICAgICAgaWYgKGxvY2tDb3VudCA9PT0gMCkge1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2xvY2tTY3JvbGxdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIF9leHRlbmRzKHtcbiAgICByZWY6IHJlZlxuICB9LCByZXN0LCB7XG4gICAgc3R5bGU6IHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgb3ZlcmZsb3c6ICdhdXRvJyxcbiAgICAgIHRvcDogMCxcbiAgICAgIHJpZ2h0OiAwLFxuICAgICAgYm90dG9tOiAwLFxuICAgICAgbGVmdDogMCxcbiAgICAgIC4uLnJlc3Quc3R5bGVcbiAgICB9XG4gIH0pKTtcbn0pO1xuXG5mdW5jdGlvbiBpc0J1dHRvblRhcmdldChldmVudCkge1xuICByZXR1cm4gaXNIVE1MRWxlbWVudChldmVudC50YXJnZXQpICYmIGV2ZW50LnRhcmdldC50YWdOYW1lID09PSAnQlVUVE9OJztcbn1cbmZ1bmN0aW9uIGlzU3BhY2VJZ25vcmVkKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzVHlwZWFibGVFbGVtZW50KGVsZW1lbnQpO1xufVxuLyoqXG4gKiBPcGVucyBvciBjbG9zZXMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2hlbiBjbGlja2luZyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlQ2xpY2tcbiAqL1xuZnVuY3Rpb24gdXNlQ2xpY2soY29udGV4dCwgcHJvcHMpIHtcbiAgaWYgKHByb3BzID09PSB2b2lkIDApIHtcbiAgICBwcm9wcyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBvcGVuLFxuICAgIG9uT3BlbkNoYW5nZSxcbiAgICBkYXRhUmVmLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICBkb21SZWZlcmVuY2VcbiAgICB9XG4gIH0gPSBjb250ZXh0O1xuICBjb25zdCB7XG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgZXZlbnQ6IGV2ZW50T3B0aW9uID0gJ2NsaWNrJyxcbiAgICB0b2dnbGUgPSB0cnVlLFxuICAgIGlnbm9yZU1vdXNlID0gZmFsc2UsXG4gICAga2V5Ym9hcmRIYW5kbGVycyA9IHRydWUsXG4gICAgc3RpY2tJZk9wZW4gPSB0cnVlXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgcG9pbnRlclR5cGVSZWYgPSBSZWFjdC51c2VSZWYoKTtcbiAgY29uc3QgZGlkS2V5RG93blJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGU7XG4gICAgfSxcbiAgICBvbk1vdXNlRG93bihldmVudCkge1xuICAgICAgY29uc3QgcG9pbnRlclR5cGUgPSBwb2ludGVyVHlwZVJlZi5jdXJyZW50O1xuXG4gICAgICAvLyBJZ25vcmUgYWxsIGJ1dHRvbnMgZXhjZXB0IGZvciB0aGUgXCJtYWluXCIgYnV0dG9uLlxuICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL01vdXNlRXZlbnQvYnV0dG9uXG4gICAgICBpZiAoZXZlbnQuYnV0dG9uICE9PSAwKSByZXR1cm47XG4gICAgICBpZiAoZXZlbnRPcHRpb24gPT09ICdjbGljaycpIHJldHVybjtcbiAgICAgIGlmIChpc01vdXNlTGlrZVBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlLCB0cnVlKSAmJiBpZ25vcmVNb3VzZSkgcmV0dXJuO1xuICAgICAgaWYgKG9wZW4gJiYgdG9nZ2xlICYmIChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50ICYmIHN0aWNrSWZPcGVuID8gZGF0YVJlZi5jdXJyZW50Lm9wZW5FdmVudC50eXBlID09PSAnbW91c2Vkb3duJyA6IHRydWUpKSB7XG4gICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQubmF0aXZlRXZlbnQsICdjbGljaycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUHJldmVudCBzdGVhbGluZyBmb2N1cyBmcm9tIHRoZSBmbG9hdGluZyBlbGVtZW50XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIG9uT3BlbkNoYW5nZSh0cnVlLCBldmVudC5uYXRpdmVFdmVudCwgJ2NsaWNrJyk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICBjb25zdCBwb2ludGVyVHlwZSA9IHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoZXZlbnRPcHRpb24gPT09ICdtb3VzZWRvd24nICYmIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcG9pbnRlclR5cGVSZWYuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzTW91c2VMaWtlUG9pbnRlclR5cGUocG9pbnRlclR5cGUsIHRydWUpICYmIGlnbm9yZU1vdXNlKSByZXR1cm47XG4gICAgICBpZiAob3BlbiAmJiB0b2dnbGUgJiYgKGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQgJiYgc3RpY2tJZk9wZW4gPyBkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50LnR5cGUgPT09ICdjbGljaycgOiB0cnVlKSkge1xuICAgICAgICBvbk9wZW5DaGFuZ2UoZmFsc2UsIGV2ZW50Lm5hdGl2ZUV2ZW50LCAnY2xpY2snKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9uT3BlbkNoYW5nZSh0cnVlLCBldmVudC5uYXRpdmVFdmVudCwgJ2NsaWNrJyk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSB1bmRlZmluZWQ7XG4gICAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCB8fCAha2V5Ym9hcmRIYW5kbGVycyB8fCBpc0J1dHRvblRhcmdldChldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJyAnICYmICFpc1NwYWNlSWdub3JlZChkb21SZWZlcmVuY2UpKSB7XG4gICAgICAgIC8vIFByZXZlbnQgc2Nyb2xsaW5nXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGRpZEtleURvd25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgIGlmIChvcGVuICYmIHRvZ2dsZSkge1xuICAgICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQubmF0aXZlRXZlbnQsICdjbGljaycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9uT3BlbkNoYW5nZSh0cnVlLCBldmVudC5uYXRpdmVFdmVudCwgJ2NsaWNrJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIG9uS2V5VXAoZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkIHx8ICFrZXlib2FyZEhhbmRsZXJzIHx8IGlzQnV0dG9uVGFyZ2V0KGV2ZW50KSB8fCBpc1NwYWNlSWdub3JlZChkb21SZWZlcmVuY2UpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC5rZXkgPT09ICcgJyAmJiBkaWRLZXlEb3duUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgZGlkS2V5RG93blJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIGlmIChvcGVuICYmIHRvZ2dsZSkge1xuICAgICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQubmF0aXZlRXZlbnQsICdjbGljaycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9uT3BlbkNoYW5nZSh0cnVlLCBldmVudC5uYXRpdmVFdmVudCwgJ2NsaWNrJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0pLCBbZGF0YVJlZiwgZG9tUmVmZXJlbmNlLCBldmVudE9wdGlvbiwgaWdub3JlTW91c2UsIGtleWJvYXJkSGFuZGxlcnMsIG9uT3BlbkNoYW5nZSwgb3Blbiwgc3RpY2tJZk9wZW4sIHRvZ2dsZV0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZVxuICB9IDoge30sIFtlbmFibGVkLCByZWZlcmVuY2VdKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlVmlydHVhbEVsZW1lbnQoZG9tRWxlbWVudCwgZGF0YSkge1xuICBsZXQgb2Zmc2V0WCA9IG51bGw7XG4gIGxldCBvZmZzZXRZID0gbnVsbDtcbiAgbGV0IGlzQXV0b1VwZGF0ZUV2ZW50ID0gZmFsc2U7XG4gIHJldHVybiB7XG4gICAgY29udGV4dEVsZW1lbnQ6IGRvbUVsZW1lbnQgfHwgdW5kZWZpbmVkLFxuICAgIGdldEJvdW5kaW5nQ2xpZW50UmVjdCgpIHtcbiAgICAgIHZhciBfZGF0YSRkYXRhUmVmJGN1cnJlbnQ7XG4gICAgICBjb25zdCBkb21SZWN0ID0gKGRvbUVsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvbUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkpIHx8IHtcbiAgICAgICAgd2lkdGg6IDAsXG4gICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgeDogMCxcbiAgICAgICAgeTogMFxuICAgICAgfTtcbiAgICAgIGNvbnN0IGlzWEF4aXMgPSBkYXRhLmF4aXMgPT09ICd4JyB8fCBkYXRhLmF4aXMgPT09ICdib3RoJztcbiAgICAgIGNvbnN0IGlzWUF4aXMgPSBkYXRhLmF4aXMgPT09ICd5JyB8fCBkYXRhLmF4aXMgPT09ICdib3RoJztcbiAgICAgIGNvbnN0IGNhblRyYWNrQ3Vyc29yT25BdXRvVXBkYXRlID0gWydtb3VzZWVudGVyJywgJ21vdXNlbW92ZSddLmluY2x1ZGVzKCgoX2RhdGEkZGF0YVJlZiRjdXJyZW50ID0gZGF0YS5kYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50KSA9PSBudWxsID8gdm9pZCAwIDogX2RhdGEkZGF0YVJlZiRjdXJyZW50LnR5cGUpIHx8ICcnKSAmJiBkYXRhLnBvaW50ZXJUeXBlICE9PSAndG91Y2gnO1xuICAgICAgbGV0IHdpZHRoID0gZG9tUmVjdC53aWR0aDtcbiAgICAgIGxldCBoZWlnaHQgPSBkb21SZWN0LmhlaWdodDtcbiAgICAgIGxldCB4ID0gZG9tUmVjdC54O1xuICAgICAgbGV0IHkgPSBkb21SZWN0Lnk7XG4gICAgICBpZiAob2Zmc2V0WCA9PSBudWxsICYmIGRhdGEueCAmJiBpc1hBeGlzKSB7XG4gICAgICAgIG9mZnNldFggPSBkb21SZWN0LnggLSBkYXRhLng7XG4gICAgICB9XG4gICAgICBpZiAob2Zmc2V0WSA9PSBudWxsICYmIGRhdGEueSAmJiBpc1lBeGlzKSB7XG4gICAgICAgIG9mZnNldFkgPSBkb21SZWN0LnkgLSBkYXRhLnk7XG4gICAgICB9XG4gICAgICB4IC09IG9mZnNldFggfHwgMDtcbiAgICAgIHkgLT0gb2Zmc2V0WSB8fCAwO1xuICAgICAgd2lkdGggPSAwO1xuICAgICAgaGVpZ2h0ID0gMDtcbiAgICAgIGlmICghaXNBdXRvVXBkYXRlRXZlbnQgfHwgY2FuVHJhY2tDdXJzb3JPbkF1dG9VcGRhdGUpIHtcbiAgICAgICAgd2lkdGggPSBkYXRhLmF4aXMgPT09ICd5JyA/IGRvbVJlY3Qud2lkdGggOiAwO1xuICAgICAgICBoZWlnaHQgPSBkYXRhLmF4aXMgPT09ICd4JyA/IGRvbVJlY3QuaGVpZ2h0IDogMDtcbiAgICAgICAgeCA9IGlzWEF4aXMgJiYgZGF0YS54ICE9IG51bGwgPyBkYXRhLnggOiB4O1xuICAgICAgICB5ID0gaXNZQXhpcyAmJiBkYXRhLnkgIT0gbnVsbCA/IGRhdGEueSA6IHk7XG4gICAgICB9IGVsc2UgaWYgKGlzQXV0b1VwZGF0ZUV2ZW50ICYmICFjYW5UcmFja0N1cnNvck9uQXV0b1VwZGF0ZSkge1xuICAgICAgICBoZWlnaHQgPSBkYXRhLmF4aXMgPT09ICd4JyA/IGRvbVJlY3QuaGVpZ2h0IDogaGVpZ2h0O1xuICAgICAgICB3aWR0aCA9IGRhdGEuYXhpcyA9PT0gJ3knID8gZG9tUmVjdC53aWR0aCA6IHdpZHRoO1xuICAgICAgfVxuICAgICAgaXNBdXRvVXBkYXRlRXZlbnQgPSB0cnVlO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgd2lkdGgsXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgeCxcbiAgICAgICAgeSxcbiAgICAgICAgdG9wOiB5LFxuICAgICAgICByaWdodDogeCArIHdpZHRoLFxuICAgICAgICBib3R0b206IHkgKyBoZWlnaHQsXG4gICAgICAgIGxlZnQ6IHhcbiAgICAgIH07XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gaXNNb3VzZUJhc2VkRXZlbnQoZXZlbnQpIHtcbiAgcmV0dXJuIGV2ZW50ICE9IG51bGwgJiYgZXZlbnQuY2xpZW50WCAhPSBudWxsO1xufVxuLyoqXG4gKiBQb3NpdGlvbnMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgcmVsYXRpdmUgdG8gYSBjbGllbnQgcG9pbnQgKGluIHRoZSB2aWV3cG9ydCksXG4gKiBzdWNoIGFzIHRoZSBtb3VzZSBwb3NpdGlvbi4gQnkgZGVmYXVsdCwgaXQgZm9sbG93cyB0aGUgbW91c2UgY3Vyc29yLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3VzZUNsaWVudFBvaW50XG4gKi9cbmZ1bmN0aW9uIHVzZUNsaWVudFBvaW50KGNvbnRleHQsIHByb3BzKSB7XG4gIGlmIChwcm9wcyA9PT0gdm9pZCAwKSB7XG4gICAgcHJvcHMgPSB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgb3BlbixcbiAgICBkYXRhUmVmLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICBmbG9hdGluZyxcbiAgICAgIGRvbVJlZmVyZW5jZVxuICAgIH0sXG4gICAgcmVmc1xuICB9ID0gY29udGV4dDtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIGF4aXMgPSAnYm90aCcsXG4gICAgeCA9IG51bGwsXG4gICAgeSA9IG51bGxcbiAgfSA9IHByb3BzO1xuICBjb25zdCBpbml0aWFsUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgY2xlYW51cExpc3RlbmVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBbcG9pbnRlclR5cGUsIHNldFBvaW50ZXJUeXBlXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGNvbnN0IFtyZWFjdGl2ZSwgc2V0UmVhY3RpdmVdID0gUmVhY3QudXNlU3RhdGUoW10pO1xuICBjb25zdCBzZXRSZWZlcmVuY2UgPSB1c2VFZmZlY3RFdmVudCgoeCwgeSkgPT4ge1xuICAgIGlmIChpbml0aWFsUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIC8vIFByZXZlbnQgc2V0dGluZyBpZiB0aGUgb3BlbiBldmVudCB3YXMgbm90IGEgbW91c2UtbGlrZSBvbmVcbiAgICAvLyAoZS5nLiBmb2N1cyB0byBvcGVuLCB0aGVuIGhvdmVyIG92ZXIgdGhlIHJlZmVyZW5jZSBlbGVtZW50KS5cbiAgICAvLyBPbmx5IGFwcGx5IGlmIHRoZSBldmVudCBleGlzdHMuXG4gICAgaWYgKGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQgJiYgIWlzTW91c2VCYXNlZEV2ZW50KGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJlZnMuc2V0UG9zaXRpb25SZWZlcmVuY2UoY3JlYXRlVmlydHVhbEVsZW1lbnQoZG9tUmVmZXJlbmNlLCB7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIGF4aXMsXG4gICAgICBkYXRhUmVmLFxuICAgICAgcG9pbnRlclR5cGVcbiAgICB9KSk7XG4gIH0pO1xuICBjb25zdCBoYW5kbGVSZWZlcmVuY2VFbnRlck9yTW92ZSA9IHVzZUVmZmVjdEV2ZW50KGV2ZW50ID0+IHtcbiAgICBpZiAoeCAhPSBudWxsIHx8IHkgIT0gbnVsbCkgcmV0dXJuO1xuICAgIGlmICghb3Blbikge1xuICAgICAgc2V0UmVmZXJlbmNlKGV2ZW50LmNsaWVudFgsIGV2ZW50LmNsaWVudFkpO1xuICAgIH0gZWxzZSBpZiAoIWNsZWFudXBMaXN0ZW5lclJlZi5jdXJyZW50KSB7XG4gICAgICAvLyBJZiB0aGVyZSdzIG5vIGNsZWFudXAsIHRoZXJlJ3Mgbm8gbGlzdGVuZXIsIGJ1dCB3ZSB3YW50IHRvIGVuc3VyZVxuICAgICAgLy8gd2UgYWRkIHRoZSBsaXN0ZW5lciBpZiB0aGUgY3Vyc29yIGxhbmRlZCBvbiB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbmRcbiAgICAgIC8vIHRoZW4gYmFjayBvbiB0aGUgcmVmZXJlbmNlIChpLmUuIGl0J3MgaW50ZXJhY3RpdmUpLlxuICAgICAgc2V0UmVhY3RpdmUoW10pO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gSWYgdGhlIHBvaW50ZXIgaXMgYSBtb3VzZS1saWtlIHBvaW50ZXIsIHdlIHdhbnQgdG8gY29udGludWUgZm9sbG93aW5nIHRoZVxuICAvLyBtb3VzZSBldmVuIGlmIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIHRyYW5zaXRpb25pbmcgb3V0LiBPbiB0b3VjaFxuICAvLyBkZXZpY2VzLCB0aGlzIGlzIHVuZGVzaXJhYmxlIGJlY2F1c2UgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2lsbCBtb3ZlIHRvXG4gIC8vIHRoZSBkaXNtaXNzYWwgdG91Y2ggcG9pbnQuXG4gIGNvbnN0IG9wZW5DaGVjayA9IGlzTW91c2VMaWtlUG9pbnRlclR5cGUocG9pbnRlclR5cGUpID8gZmxvYXRpbmcgOiBvcGVuO1xuICBjb25zdCBhZGRMaXN0ZW5lciA9IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICAvLyBFeHBsaWNpdGx5IHNwZWNpZmllZCBgeGAvYHlgIGNvb3JkaW5hdGVzIHNob3VsZG4ndCBhZGQgYSBsaXN0ZW5lci5cbiAgICBpZiAoIW9wZW5DaGVjayB8fCAhZW5hYmxlZCB8fCB4ICE9IG51bGwgfHwgeSAhPSBudWxsKSByZXR1cm47XG4gICAgY29uc3Qgd2luID0gZ2V0V2luZG93KGZsb2F0aW5nKTtcbiAgICBmdW5jdGlvbiBoYW5kbGVNb3VzZU1vdmUoZXZlbnQpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBpZiAoIWNvbnRhaW5zKGZsb2F0aW5nLCB0YXJnZXQpKSB7XG4gICAgICAgIHNldFJlZmVyZW5jZShldmVudC5jbGllbnRYLCBldmVudC5jbGllbnRZKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBoYW5kbGVNb3VzZU1vdmUpO1xuICAgICAgICBjbGVhbnVwTGlzdGVuZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghZGF0YVJlZi5jdXJyZW50Lm9wZW5FdmVudCB8fCBpc01vdXNlQmFzZWRFdmVudChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50KSkge1xuICAgICAgd2luLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIGhhbmRsZU1vdXNlTW92ZSk7XG4gICAgICBjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuICAgICAgICB3aW4ucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgaGFuZGxlTW91c2VNb3ZlKTtcbiAgICAgICAgY2xlYW51cExpc3RlbmVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfTtcbiAgICAgIGNsZWFudXBMaXN0ZW5lclJlZi5jdXJyZW50ID0gY2xlYW51cDtcbiAgICAgIHJldHVybiBjbGVhbnVwO1xuICAgIH1cbiAgICByZWZzLnNldFBvc2l0aW9uUmVmZXJlbmNlKGRvbVJlZmVyZW5jZSk7XG4gIH0sIFtvcGVuQ2hlY2ssIGVuYWJsZWQsIHgsIHksIGZsb2F0aW5nLCBkYXRhUmVmLCByZWZzLCBkb21SZWZlcmVuY2UsIHNldFJlZmVyZW5jZV0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiBhZGRMaXN0ZW5lcigpO1xuICB9LCBbYWRkTGlzdGVuZXIsIHJlYWN0aXZlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGVuYWJsZWQgJiYgIWZsb2F0aW5nKSB7XG4gICAgICBpbml0aWFsUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG4gIH0sIFtlbmFibGVkLCBmbG9hdGluZ10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCAmJiBvcGVuKSB7XG4gICAgICBpbml0aWFsUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgfSwgW2VuYWJsZWQsIG9wZW5dKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChlbmFibGVkICYmICh4ICE9IG51bGwgfHwgeSAhPSBudWxsKSkge1xuICAgICAgaW5pdGlhbFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBzZXRSZWZlcmVuY2UoeCwgeSk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgeCwgeSwgc2V0UmVmZXJlbmNlXSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHNldFBvaW50ZXJUeXBlUmVmKF9yZWYpIHtcbiAgICAgIGxldCB7XG4gICAgICAgIHBvaW50ZXJUeXBlXG4gICAgICB9ID0gX3JlZjtcbiAgICAgIHNldFBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uUG9pbnRlckRvd246IHNldFBvaW50ZXJUeXBlUmVmLFxuICAgICAgb25Qb2ludGVyRW50ZXI6IHNldFBvaW50ZXJUeXBlUmVmLFxuICAgICAgb25Nb3VzZU1vdmU6IGhhbmRsZVJlZmVyZW5jZUVudGVyT3JNb3ZlLFxuICAgICAgb25Nb3VzZUVudGVyOiBoYW5kbGVSZWZlcmVuY2VFbnRlck9yTW92ZVxuICAgIH07XG4gIH0sIFtoYW5kbGVSZWZlcmVuY2VFbnRlck9yTW92ZV0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZVxuICB9IDoge30sIFtlbmFibGVkLCByZWZlcmVuY2VdKTtcbn1cblxuY29uc3QgYnViYmxlSGFuZGxlcktleXMgPSB7XG4gIHBvaW50ZXJkb3duOiAnb25Qb2ludGVyRG93bicsXG4gIG1vdXNlZG93bjogJ29uTW91c2VEb3duJyxcbiAgY2xpY2s6ICdvbkNsaWNrJ1xufTtcbmNvbnN0IGNhcHR1cmVIYW5kbGVyS2V5cyA9IHtcbiAgcG9pbnRlcmRvd246ICdvblBvaW50ZXJEb3duQ2FwdHVyZScsXG4gIG1vdXNlZG93bjogJ29uTW91c2VEb3duQ2FwdHVyZScsXG4gIGNsaWNrOiAnb25DbGlja0NhcHR1cmUnXG59O1xuY29uc3Qgbm9ybWFsaXplUHJvcCA9IG5vcm1hbGl6YWJsZSA9PiB7XG4gIHZhciBfbm9ybWFsaXphYmxlJGVzY2FwZUssIF9ub3JtYWxpemFibGUkb3V0c2lkZTtcbiAgcmV0dXJuIHtcbiAgICBlc2NhcGVLZXk6IHR5cGVvZiBub3JtYWxpemFibGUgPT09ICdib29sZWFuJyA/IG5vcm1hbGl6YWJsZSA6IChfbm9ybWFsaXphYmxlJGVzY2FwZUsgPSBub3JtYWxpemFibGUgPT0gbnVsbCA/IHZvaWQgMCA6IG5vcm1hbGl6YWJsZS5lc2NhcGVLZXkpICE9IG51bGwgPyBfbm9ybWFsaXphYmxlJGVzY2FwZUsgOiBmYWxzZSxcbiAgICBvdXRzaWRlUHJlc3M6IHR5cGVvZiBub3JtYWxpemFibGUgPT09ICdib29sZWFuJyA/IG5vcm1hbGl6YWJsZSA6IChfbm9ybWFsaXphYmxlJG91dHNpZGUgPSBub3JtYWxpemFibGUgPT0gbnVsbCA/IHZvaWQgMCA6IG5vcm1hbGl6YWJsZS5vdXRzaWRlUHJlc3MpICE9IG51bGwgPyBfbm9ybWFsaXphYmxlJG91dHNpZGUgOiB0cnVlXG4gIH07XG59O1xuLyoqXG4gKiBDbG9zZXMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2hlbiBhIGRpc21pc3NhbCBpcyByZXF1ZXN0ZWQg4oCUIGJ5IGRlZmF1bHQsIHdoZW5cbiAqIHRoZSB1c2VyIHByZXNzZXMgdGhlIGBlc2NhcGVgIGtleSBvciBvdXRzaWRlIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3VzZURpc21pc3NcbiAqL1xuZnVuY3Rpb24gdXNlRGlzbWlzcyhjb250ZXh0LCBwcm9wcykge1xuICBpZiAocHJvcHMgPT09IHZvaWQgMCkge1xuICAgIHByb3BzID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIGVsZW1lbnRzLFxuICAgIGRhdGFSZWZcbiAgfSA9IGNvbnRleHQ7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBlc2NhcGVLZXkgPSB0cnVlLFxuICAgIG91dHNpZGVQcmVzczogdW5zdGFibGVfb3V0c2lkZVByZXNzID0gdHJ1ZSxcbiAgICBvdXRzaWRlUHJlc3NFdmVudCA9ICdwb2ludGVyZG93bicsXG4gICAgcmVmZXJlbmNlUHJlc3MgPSBmYWxzZSxcbiAgICByZWZlcmVuY2VQcmVzc0V2ZW50ID0gJ3BvaW50ZXJkb3duJyxcbiAgICBhbmNlc3RvclNjcm9sbCA9IGZhbHNlLFxuICAgIGJ1YmJsZXMsXG4gICAgY2FwdHVyZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoKTtcbiAgY29uc3Qgb3V0c2lkZVByZXNzRm4gPSB1c2VFZmZlY3RFdmVudCh0eXBlb2YgdW5zdGFibGVfb3V0c2lkZVByZXNzID09PSAnZnVuY3Rpb24nID8gdW5zdGFibGVfb3V0c2lkZVByZXNzIDogKCkgPT4gZmFsc2UpO1xuICBjb25zdCBvdXRzaWRlUHJlc3MgPSB0eXBlb2YgdW5zdGFibGVfb3V0c2lkZVByZXNzID09PSAnZnVuY3Rpb24nID8gb3V0c2lkZVByZXNzRm4gOiB1bnN0YWJsZV9vdXRzaWRlUHJlc3M7XG4gIGNvbnN0IGluc2lkZVJlYWN0VHJlZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGVuZGVkT3JTdGFydGVkSW5zaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3Qge1xuICAgIGVzY2FwZUtleTogZXNjYXBlS2V5QnViYmxlcyxcbiAgICBvdXRzaWRlUHJlc3M6IG91dHNpZGVQcmVzc0J1YmJsZXNcbiAgfSA9IG5vcm1hbGl6ZVByb3AoYnViYmxlcyk7XG4gIGNvbnN0IHtcbiAgICBlc2NhcGVLZXk6IGVzY2FwZUtleUNhcHR1cmUsXG4gICAgb3V0c2lkZVByZXNzOiBvdXRzaWRlUHJlc3NDYXB0dXJlXG4gIH0gPSBub3JtYWxpemVQcm9wKGNhcHR1cmUpO1xuICBjb25zdCBpc0NvbXBvc2luZ1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGNsb3NlT25Fc2NhcGVLZXlEb3duID0gdXNlRWZmZWN0RXZlbnQoZXZlbnQgPT4ge1xuICAgIHZhciBfZGF0YVJlZiRjdXJyZW50JGZsb2E7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkIHx8ICFlc2NhcGVLZXkgfHwgZXZlbnQua2V5ICE9PSAnRXNjYXBlJykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFdhaXQgdW50aWwgSU1FIGlzIHNldHRsZWQuIFByZXNzaW5nIGBFc2NhcGVgIHdoaWxlIGNvbXBvc2luZyBzaG91bGRcbiAgICAvLyBjbG9zZSB0aGUgY29tcG9zZSBtZW51LCBidXQgbm90IHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICAgIGlmIChpc0NvbXBvc2luZ1JlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5vZGVJZCA9IChfZGF0YVJlZiRjdXJyZW50JGZsb2EgPSBkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0KSA9PSBudWxsID8gdm9pZCAwIDogX2RhdGFSZWYkY3VycmVudCRmbG9hLm5vZGVJZDtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRyZWUgPyBnZXRDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkgOiBbXTtcbiAgICBpZiAoIWVzY2FwZUtleUJ1YmJsZXMpIHtcbiAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgaWYgKGNoaWxkcmVuLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbGV0IHNob3VsZERpc21pc3MgPSB0cnVlO1xuICAgICAgICBjaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICAgICAgICB2YXIgX2NoaWxkJGNvbnRleHQ7XG4gICAgICAgICAgaWYgKChfY2hpbGQkY29udGV4dCA9IGNoaWxkLmNvbnRleHQpICE9IG51bGwgJiYgX2NoaWxkJGNvbnRleHQub3BlbiAmJiAhY2hpbGQuY29udGV4dC5kYXRhUmVmLmN1cnJlbnQuX19lc2NhcGVLZXlCdWJibGVzKSB7XG4gICAgICAgICAgICBzaG91bGREaXNtaXNzID0gZmFsc2U7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFzaG91bGREaXNtaXNzKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgaXNSZWFjdEV2ZW50KGV2ZW50KSA/IGV2ZW50Lm5hdGl2ZUV2ZW50IDogZXZlbnQsICdlc2NhcGUta2V5Jyk7XG4gIH0pO1xuICBjb25zdCBjbG9zZU9uRXNjYXBlS2V5RG93bkNhcHR1cmUgPSB1c2VFZmZlY3RFdmVudChldmVudCA9PiB7XG4gICAgdmFyIF9nZXRUYXJnZXQyO1xuICAgIGNvbnN0IGNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgdmFyIF9nZXRUYXJnZXQ7XG4gICAgICBjbG9zZU9uRXNjYXBlS2V5RG93bihldmVudCk7XG4gICAgICAoX2dldFRhcmdldCA9IGdldFRhcmdldChldmVudCkpID09IG51bGwgfHwgX2dldFRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgY2FsbGJhY2spO1xuICAgIH07XG4gICAgKF9nZXRUYXJnZXQyID0gZ2V0VGFyZ2V0KGV2ZW50KSkgPT0gbnVsbCB8fCBfZ2V0VGFyZ2V0Mi5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgY2FsbGJhY2spO1xuICB9KTtcbiAgY29uc3QgY2xvc2VPblByZXNzT3V0c2lkZSA9IHVzZUVmZmVjdEV2ZW50KGV2ZW50ID0+IHtcbiAgICB2YXIgX2RhdGFSZWYkY3VycmVudCRmbG9hMjtcbiAgICAvLyBHaXZlbiBkZXZlbG9wZXJzIGNhbiBzdG9wIHRoZSBwcm9wYWdhdGlvbiBvZiB0aGUgc3ludGhldGljIGV2ZW50LFxuICAgIC8vIHdlIGNhbiBvbmx5IGJlIGNvbmZpZGVudCB3aXRoIGEgcG9zaXRpdmUgdmFsdWUuXG4gICAgY29uc3QgaW5zaWRlUmVhY3RUcmVlID0gaW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQ7XG4gICAgaW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQgPSBmYWxzZTtcblxuICAgIC8vIFdoZW4gY2xpY2sgb3V0c2lkZSBpcyBsYXp5IChgY2xpY2tgIGV2ZW50KSwgaGFuZGxlIGRyYWdnaW5nLlxuICAgIC8vIERvbid0IGNsb3NlIGlmOlxuICAgIC8vIC0gVGhlIGNsaWNrIHN0YXJ0ZWQgaW5zaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICAgIC8vIC0gVGhlIGNsaWNrIGVuZGVkIGluc2lkZSB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAgICBjb25zdCBlbmRlZE9yU3RhcnRlZEluc2lkZSA9IGVuZGVkT3JTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQ7XG4gICAgZW5kZWRPclN0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIGlmIChvdXRzaWRlUHJlc3NFdmVudCA9PT0gJ2NsaWNrJyAmJiBlbmRlZE9yU3RhcnRlZEluc2lkZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoaW5zaWRlUmVhY3RUcmVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygb3V0c2lkZVByZXNzID09PSAnZnVuY3Rpb24nICYmICFvdXRzaWRlUHJlc3MoZXZlbnQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgY29uc3QgaW5lcnRTZWxlY3RvciA9IFwiW1wiICsgY3JlYXRlQXR0cmlidXRlKCdpbmVydCcpICsgXCJdXCI7XG4gICAgY29uc3QgbWFya2VycyA9IGdldERvY3VtZW50KGVsZW1lbnRzLmZsb2F0aW5nKS5xdWVyeVNlbGVjdG9yQWxsKGluZXJ0U2VsZWN0b3IpO1xuICAgIGxldCB0YXJnZXRSb290QW5jZXN0b3IgPSBpc0VsZW1lbnQodGFyZ2V0KSA/IHRhcmdldCA6IG51bGw7XG4gICAgd2hpbGUgKHRhcmdldFJvb3RBbmNlc3RvciAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKHRhcmdldFJvb3RBbmNlc3RvcikpIHtcbiAgICAgIGNvbnN0IG5leHRQYXJlbnQgPSBnZXRQYXJlbnROb2RlKHRhcmdldFJvb3RBbmNlc3Rvcik7XG4gICAgICBpZiAoaXNMYXN0VHJhdmVyc2FibGVOb2RlKG5leHRQYXJlbnQpIHx8ICFpc0VsZW1lbnQobmV4dFBhcmVudCkpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICB0YXJnZXRSb290QW5jZXN0b3IgPSBuZXh0UGFyZW50O1xuICAgIH1cblxuICAgIC8vIENoZWNrIGlmIHRoZSBjbGljayBvY2N1cnJlZCBvbiBhIHRoaXJkLXBhcnR5IGVsZW1lbnQgaW5qZWN0ZWQgYWZ0ZXIgdGhlXG4gICAgLy8gZmxvYXRpbmcgZWxlbWVudCByZW5kZXJlZC5cbiAgICBpZiAobWFya2Vycy5sZW5ndGggJiYgaXNFbGVtZW50KHRhcmdldCkgJiYgIWlzUm9vdEVsZW1lbnQodGFyZ2V0KSAmJlxuICAgIC8vIENsaWNrZWQgb24gYSBkaXJlY3QgYW5jZXN0b3IgKGUuZy4gRmxvYXRpbmdPdmVybGF5KS5cbiAgICAhY29udGFpbnModGFyZ2V0LCBlbGVtZW50cy5mbG9hdGluZykgJiZcbiAgICAvLyBJZiB0aGUgdGFyZ2V0IHJvb3QgZWxlbWVudCBjb250YWlucyBub25lIG9mIHRoZSBtYXJrZXJzLCB0aGVuIHRoZVxuICAgIC8vIGVsZW1lbnQgd2FzIGluamVjdGVkIGFmdGVyIHRoZSBmbG9hdGluZyBlbGVtZW50IHJlbmRlcmVkLlxuICAgIEFycmF5LmZyb20obWFya2VycykuZXZlcnkobWFya2VyID0+ICFjb250YWlucyh0YXJnZXRSb290QW5jZXN0b3IsIG1hcmtlcikpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgdGhlIGNsaWNrIG9jY3VycmVkIG9uIHRoZSBzY3JvbGxiYXJcbiAgICBpZiAoaXNIVE1MRWxlbWVudCh0YXJnZXQpICYmIGZsb2F0aW5nKSB7XG4gICAgICAvLyBJbiBGaXJlZm94LCBgdGFyZ2V0LnNjcm9sbFdpZHRoID4gdGFyZ2V0LmNsaWVudFdpZHRoYCBmb3IgaW5saW5lXG4gICAgICAvLyBlbGVtZW50cy5cbiAgICAgIGNvbnN0IGNhblNjcm9sbFggPSB0YXJnZXQuY2xpZW50V2lkdGggPiAwICYmIHRhcmdldC5zY3JvbGxXaWR0aCA+IHRhcmdldC5jbGllbnRXaWR0aDtcbiAgICAgIGNvbnN0IGNhblNjcm9sbFkgPSB0YXJnZXQuY2xpZW50SGVpZ2h0ID4gMCAmJiB0YXJnZXQuc2Nyb2xsSGVpZ2h0ID4gdGFyZ2V0LmNsaWVudEhlaWdodDtcbiAgICAgIGxldCB4Q29uZCA9IGNhblNjcm9sbFkgJiYgZXZlbnQub2Zmc2V0WCA+IHRhcmdldC5jbGllbnRXaWR0aDtcblxuICAgICAgLy8gSW4gc29tZSBicm93c2VycyBpdCBpcyBwb3NzaWJsZSB0byBjaGFuZ2UgdGhlIDxib2R5PiAob3Igd2luZG93KVxuICAgICAgLy8gc2Nyb2xsYmFyIHRvIHRoZSBsZWZ0IHNpZGUsIGJ1dCBpcyB2ZXJ5IHJhcmUgYW5kIGlzIGRpZmZpY3VsdCB0b1xuICAgICAgLy8gY2hlY2sgZm9yLiBQbHVzLCBmb3IgbW9kYWwgZGlhbG9ncyB3aXRoIGJhY2tkcm9wcywgaXQgaXMgbW9yZVxuICAgICAgLy8gaW1wb3J0YW50IHRoYXQgdGhlIGJhY2tkcm9wIGlzIGNoZWNrZWQgYnV0IG5vdCBzbyBtdWNoIHRoZSB3aW5kb3cuXG4gICAgICBpZiAoY2FuU2Nyb2xsWSkge1xuICAgICAgICBjb25zdCBpc1JUTCA9IGdldENvbXB1dGVkU3R5bGUodGFyZ2V0KS5kaXJlY3Rpb24gPT09ICdydGwnO1xuICAgICAgICBpZiAoaXNSVEwpIHtcbiAgICAgICAgICB4Q29uZCA9IGV2ZW50Lm9mZnNldFggPD0gdGFyZ2V0Lm9mZnNldFdpZHRoIC0gdGFyZ2V0LmNsaWVudFdpZHRoO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoeENvbmQgfHwgY2FuU2Nyb2xsWCAmJiBldmVudC5vZmZzZXRZID4gdGFyZ2V0LmNsaWVudEhlaWdodCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IG5vZGVJZCA9IChfZGF0YVJlZiRjdXJyZW50JGZsb2EyID0gZGF0YVJlZi5jdXJyZW50LmZsb2F0aW5nQ29udGV4dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9kYXRhUmVmJGN1cnJlbnQkZmxvYTIubm9kZUlkO1xuICAgIGNvbnN0IHRhcmdldElzSW5zaWRlQ2hpbGRyZW4gPSB0cmVlICYmIGdldENoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgbm9kZUlkKS5zb21lKG5vZGUgPT4ge1xuICAgICAgdmFyIF9ub2RlJGNvbnRleHQ7XG4gICAgICByZXR1cm4gaXNFdmVudFRhcmdldFdpdGhpbihldmVudCwgKF9ub2RlJGNvbnRleHQgPSBub2RlLmNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRjb250ZXh0LmVsZW1lbnRzLmZsb2F0aW5nKTtcbiAgICB9KTtcbiAgICBpZiAoaXNFdmVudFRhcmdldFdpdGhpbihldmVudCwgZWxlbWVudHMuZmxvYXRpbmcpIHx8IGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIGVsZW1lbnRzLmRvbVJlZmVyZW5jZSkgfHwgdGFyZ2V0SXNJbnNpZGVDaGlsZHJlbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZHJlbiA9IHRyZWUgPyBnZXRDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkgOiBbXTtcbiAgICBpZiAoY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgbGV0IHNob3VsZERpc21pc3MgPSB0cnVlO1xuICAgICAgY2hpbGRyZW4uZm9yRWFjaChjaGlsZCA9PiB7XG4gICAgICAgIHZhciBfY2hpbGQkY29udGV4dDI7XG4gICAgICAgIGlmICgoX2NoaWxkJGNvbnRleHQyID0gY2hpbGQuY29udGV4dCkgIT0gbnVsbCAmJiBfY2hpbGQkY29udGV4dDIub3BlbiAmJiAhY2hpbGQuY29udGV4dC5kYXRhUmVmLmN1cnJlbnQuX19vdXRzaWRlUHJlc3NCdWJibGVzKSB7XG4gICAgICAgICAgc2hvdWxkRGlzbWlzcyA9IGZhbHNlO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoIXNob3VsZERpc21pc3MpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICBvbk9wZW5DaGFuZ2UoZmFsc2UsIGV2ZW50LCAnb3V0c2lkZS1wcmVzcycpO1xuICB9KTtcbiAgY29uc3QgY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUgPSB1c2VFZmZlY3RFdmVudChldmVudCA9PiB7XG4gICAgdmFyIF9nZXRUYXJnZXQ0O1xuICAgIGNvbnN0IGNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgdmFyIF9nZXRUYXJnZXQzO1xuICAgICAgY2xvc2VPblByZXNzT3V0c2lkZShldmVudCk7XG4gICAgICAoX2dldFRhcmdldDMgPSBnZXRUYXJnZXQoZXZlbnQpKSA9PSBudWxsIHx8IF9nZXRUYXJnZXQzLnJlbW92ZUV2ZW50TGlzdGVuZXIob3V0c2lkZVByZXNzRXZlbnQsIGNhbGxiYWNrKTtcbiAgICB9O1xuICAgIChfZ2V0VGFyZ2V0NCA9IGdldFRhcmdldChldmVudCkpID09IG51bGwgfHwgX2dldFRhcmdldDQuYWRkRXZlbnRMaXN0ZW5lcihvdXRzaWRlUHJlc3NFdmVudCwgY2FsbGJhY2spO1xuICB9KTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZGF0YVJlZi5jdXJyZW50Ll9fZXNjYXBlS2V5QnViYmxlcyA9IGVzY2FwZUtleUJ1YmJsZXM7XG4gICAgZGF0YVJlZi5jdXJyZW50Ll9fb3V0c2lkZVByZXNzQnViYmxlcyA9IG91dHNpZGVQcmVzc0J1YmJsZXM7XG4gICAgbGV0IGNvbXBvc2l0aW9uVGltZW91dCA9IC0xO1xuICAgIGZ1bmN0aW9uIG9uU2Nyb2xsKGV2ZW50KSB7XG4gICAgICBvbk9wZW5DaGFuZ2UoZmFsc2UsIGV2ZW50LCAnYW5jZXN0b3Itc2Nyb2xsJyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZUNvbXBvc2l0aW9uU3RhcnQoKSB7XG4gICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KGNvbXBvc2l0aW9uVGltZW91dCk7XG4gICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlQ29tcG9zaXRpb25FbmQoKSB7XG4gICAgICAvLyBTYWZhcmkgZmlyZXMgYGNvbXBvc2l0aW9uZW5kYCBiZWZvcmUgYGtleWRvd25gLCBzbyB3ZSBuZWVkIHRvIHdhaXRcbiAgICAgIC8vIHVudGlsIHRoZSBuZXh0IHRpY2sgdG8gc2V0IGBpc0NvbXBvc2luZ2AgdG8gYGZhbHNlYC5cbiAgICAgIC8vIGh0dHBzOi8vYnVncy53ZWJraXQub3JnL3Nob3dfYnVnLmNnaT9pZD0xNjUwMDRcbiAgICAgIGNvbXBvc2l0aW9uVGltZW91dCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgaXNDb21wb3NpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSxcbiAgICAgIC8vIDBtcyBvciAxbXMgZG9uJ3Qgd29yayBpbiBTYWZhcmkuIDVtcyBhcHBlYXJzIHRvIGNvbnNpc3RlbnRseSB3b3JrLlxuICAgICAgLy8gT25seSBhcHBseSB0byBXZWJLaXQgZm9yIHRoZSB0ZXN0IHRvIHJlbWFpbiAwbXMuXG4gICAgICBpc1dlYktpdCgpID8gNSA6IDApO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBnZXREb2N1bWVudChlbGVtZW50cy5mbG9hdGluZyk7XG4gICAgaWYgKGVzY2FwZUtleSkge1xuICAgICAgZG9jLmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBlc2NhcGVLZXlDYXB0dXJlID8gY2xvc2VPbkVzY2FwZUtleURvd25DYXB0dXJlIDogY2xvc2VPbkVzY2FwZUtleURvd24sIGVzY2FwZUtleUNhcHR1cmUpO1xuICAgICAgZG9jLmFkZEV2ZW50TGlzdGVuZXIoJ2NvbXBvc2l0aW9uc3RhcnQnLCBoYW5kbGVDb21wb3NpdGlvblN0YXJ0KTtcbiAgICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdjb21wb3NpdGlvbmVuZCcsIGhhbmRsZUNvbXBvc2l0aW9uRW5kKTtcbiAgICB9XG4gICAgb3V0c2lkZVByZXNzICYmIGRvYy5hZGRFdmVudExpc3RlbmVyKG91dHNpZGVQcmVzc0V2ZW50LCBvdXRzaWRlUHJlc3NDYXB0dXJlID8gY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUgOiBjbG9zZU9uUHJlc3NPdXRzaWRlLCBvdXRzaWRlUHJlc3NDYXB0dXJlKTtcbiAgICBsZXQgYW5jZXN0b3JzID0gW107XG4gICAgaWYgKGFuY2VzdG9yU2Nyb2xsKSB7XG4gICAgICBpZiAoaXNFbGVtZW50KGVsZW1lbnRzLmRvbVJlZmVyZW5jZSkpIHtcbiAgICAgICAgYW5jZXN0b3JzID0gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZWxlbWVudHMuZG9tUmVmZXJlbmNlKTtcbiAgICAgIH1cbiAgICAgIGlmIChpc0VsZW1lbnQoZWxlbWVudHMuZmxvYXRpbmcpKSB7XG4gICAgICAgIGFuY2VzdG9ycyA9IGFuY2VzdG9ycy5jb25jYXQoZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNFbGVtZW50KGVsZW1lbnRzLnJlZmVyZW5jZSkgJiYgZWxlbWVudHMucmVmZXJlbmNlICYmIGVsZW1lbnRzLnJlZmVyZW5jZS5jb250ZXh0RWxlbWVudCkge1xuICAgICAgICBhbmNlc3RvcnMgPSBhbmNlc3RvcnMuY29uY2F0KGdldE92ZXJmbG93QW5jZXN0b3JzKGVsZW1lbnRzLnJlZmVyZW5jZS5jb250ZXh0RWxlbWVudCkpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElnbm9yZSB0aGUgdmlzdWFsIHZpZXdwb3J0IGZvciBzY3JvbGxpbmcgZGlzbWlzc2FsIChhbGxvdyBwaW5jaC16b29tKVxuICAgIGFuY2VzdG9ycyA9IGFuY2VzdG9ycy5maWx0ZXIoYW5jZXN0b3IgPT4ge1xuICAgICAgdmFyIF9kb2MkZGVmYXVsdFZpZXc7XG4gICAgICByZXR1cm4gYW5jZXN0b3IgIT09ICgoX2RvYyRkZWZhdWx0VmlldyA9IGRvYy5kZWZhdWx0VmlldykgPT0gbnVsbCA/IHZvaWQgMCA6IF9kb2MkZGVmYXVsdFZpZXcudmlzdWFsVmlld3BvcnQpO1xuICAgIH0pO1xuICAgIGFuY2VzdG9ycy5mb3JFYWNoKGFuY2VzdG9yID0+IHtcbiAgICAgIGFuY2VzdG9yLmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uU2Nyb2xsLCB7XG4gICAgICAgIHBhc3NpdmU6IHRydWVcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoZXNjYXBlS2V5KSB7XG4gICAgICAgIGRvYy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgZXNjYXBlS2V5Q2FwdHVyZSA/IGNsb3NlT25Fc2NhcGVLZXlEb3duQ2FwdHVyZSA6IGNsb3NlT25Fc2NhcGVLZXlEb3duLCBlc2NhcGVLZXlDYXB0dXJlKTtcbiAgICAgICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbXBvc2l0aW9uc3RhcnQnLCBoYW5kbGVDb21wb3NpdGlvblN0YXJ0KTtcbiAgICAgICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbXBvc2l0aW9uZW5kJywgaGFuZGxlQ29tcG9zaXRpb25FbmQpO1xuICAgICAgfVxuICAgICAgb3V0c2lkZVByZXNzICYmIGRvYy5yZW1vdmVFdmVudExpc3RlbmVyKG91dHNpZGVQcmVzc0V2ZW50LCBvdXRzaWRlUHJlc3NDYXB0dXJlID8gY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUgOiBjbG9zZU9uUHJlc3NPdXRzaWRlLCBvdXRzaWRlUHJlc3NDYXB0dXJlKTtcbiAgICAgIGFuY2VzdG9ycy5mb3JFYWNoKGFuY2VzdG9yID0+IHtcbiAgICAgICAgYW5jZXN0b3IucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgb25TY3JvbGwpO1xuICAgICAgfSk7XG4gICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KGNvbXBvc2l0aW9uVGltZW91dCk7XG4gICAgfTtcbiAgfSwgW2RhdGFSZWYsIGVsZW1lbnRzLCBlc2NhcGVLZXksIG91dHNpZGVQcmVzcywgb3V0c2lkZVByZXNzRXZlbnQsIG9wZW4sIG9uT3BlbkNoYW5nZSwgYW5jZXN0b3JTY3JvbGwsIGVuYWJsZWQsIGVzY2FwZUtleUJ1YmJsZXMsIG91dHNpZGVQcmVzc0J1YmJsZXMsIGNsb3NlT25Fc2NhcGVLZXlEb3duLCBlc2NhcGVLZXlDYXB0dXJlLCBjbG9zZU9uRXNjYXBlS2V5RG93bkNhcHR1cmUsIGNsb3NlT25QcmVzc091dHNpZGUsIG91dHNpZGVQcmVzc0NhcHR1cmUsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgfSwgW291dHNpZGVQcmVzcywgb3V0c2lkZVByZXNzRXZlbnRdKTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uS2V5RG93bjogY2xvc2VPbkVzY2FwZUtleURvd24sXG4gICAgW2J1YmJsZUhhbmRsZXJLZXlzW3JlZmVyZW5jZVByZXNzRXZlbnRdXTogZXZlbnQgPT4ge1xuICAgICAgaWYgKHJlZmVyZW5jZVByZXNzKSB7XG4gICAgICAgIG9uT3BlbkNoYW5nZShmYWxzZSwgZXZlbnQubmF0aXZlRXZlbnQsICdyZWZlcmVuY2UtcHJlc3MnKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pLCBbY2xvc2VPbkVzY2FwZUtleURvd24sIG9uT3BlbkNoYW5nZSwgcmVmZXJlbmNlUHJlc3MsIHJlZmVyZW5jZVByZXNzRXZlbnRdKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb25LZXlEb3duOiBjbG9zZU9uRXNjYXBlS2V5RG93bixcbiAgICBvbk1vdXNlRG93bigpIHtcbiAgICAgIGVuZGVkT3JTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH0sXG4gICAgb25Nb3VzZVVwKCkge1xuICAgICAgZW5kZWRPclN0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfSxcbiAgICBbY2FwdHVyZUhhbmRsZXJLZXlzW291dHNpZGVQcmVzc0V2ZW50XV06ICgpID0+IHtcbiAgICAgIGluc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9XG4gIH0pLCBbY2xvc2VPbkVzY2FwZUtleURvd24sIG91dHNpZGVQcmVzc0V2ZW50XSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlLFxuICAgIGZsb2F0aW5nXG4gIH0gOiB7fSwgW2VuYWJsZWQsIHJlZmVyZW5jZSwgZmxvYXRpbmddKTtcbn1cblxuZnVuY3Rpb24gdXNlRmxvYXRpbmdSb290Q29udGV4dChvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBvcGVuID0gZmFsc2UsXG4gICAgb25PcGVuQ2hhbmdlOiBvbk9wZW5DaGFuZ2VQcm9wLFxuICAgIGVsZW1lbnRzOiBlbGVtZW50c1Byb3BcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZsb2F0aW5nSWQgPSB1c2VJZCgpO1xuICBjb25zdCBkYXRhUmVmID0gUmVhY3QudXNlUmVmKHt9KTtcbiAgY29uc3QgW2V2ZW50c10gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBjcmVhdGVQdWJTdWIoKSk7XG4gIGNvbnN0IG5lc3RlZCA9IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkKCkgIT0gbnVsbDtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGNvbnN0IG9wdGlvbkRvbVJlZmVyZW5jZSA9IGVsZW1lbnRzUHJvcC5yZWZlcmVuY2U7XG4gICAgaWYgKG9wdGlvbkRvbVJlZmVyZW5jZSAmJiAhaXNFbGVtZW50KG9wdGlvbkRvbVJlZmVyZW5jZSkpIHtcbiAgICAgIGVycm9yKCdDYW5ub3QgcGFzcyBhIHZpcnR1YWwgZWxlbWVudCB0byB0aGUgYGVsZW1lbnRzLnJlZmVyZW5jZWAgb3B0aW9uLCcsICdhcyBpdCBtdXN0IGJlIGEgcmVhbCBET00gZWxlbWVudC4gVXNlIGByZWZzLnNldFBvc2l0aW9uUmVmZXJlbmNlKClgJywgJ2luc3RlYWQuJyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IFtwb3NpdGlvblJlZmVyZW5jZSwgc2V0UG9zaXRpb25SZWZlcmVuY2VdID0gUmVhY3QudXNlU3RhdGUoZWxlbWVudHNQcm9wLnJlZmVyZW5jZSk7XG4gIGNvbnN0IG9uT3BlbkNoYW5nZSA9IHVzZUVmZmVjdEV2ZW50KChvcGVuLCBldmVudCwgcmVhc29uKSA9PiB7XG4gICAgZGF0YVJlZi5jdXJyZW50Lm9wZW5FdmVudCA9IG9wZW4gPyBldmVudCA6IHVuZGVmaW5lZDtcbiAgICBldmVudHMuZW1pdCgnb3BlbmNoYW5nZScsIHtcbiAgICAgIG9wZW4sXG4gICAgICBldmVudCxcbiAgICAgIHJlYXNvbixcbiAgICAgIG5lc3RlZFxuICAgIH0pO1xuICAgIG9uT3BlbkNoYW5nZVByb3AgPT0gbnVsbCB8fCBvbk9wZW5DaGFuZ2VQcm9wKG9wZW4sIGV2ZW50LCByZWFzb24pO1xuICB9KTtcbiAgY29uc3QgcmVmcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBzZXRQb3NpdGlvblJlZmVyZW5jZVxuICB9KSwgW10pO1xuICBjb25zdCBlbGVtZW50cyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByZWZlcmVuY2U6IHBvc2l0aW9uUmVmZXJlbmNlIHx8IGVsZW1lbnRzUHJvcC5yZWZlcmVuY2UgfHwgbnVsbCxcbiAgICBmbG9hdGluZzogZWxlbWVudHNQcm9wLmZsb2F0aW5nIHx8IG51bGwsXG4gICAgZG9tUmVmZXJlbmNlOiBlbGVtZW50c1Byb3AucmVmZXJlbmNlXG4gIH0pLCBbcG9zaXRpb25SZWZlcmVuY2UsIGVsZW1lbnRzUHJvcC5yZWZlcmVuY2UsIGVsZW1lbnRzUHJvcC5mbG9hdGluZ10pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGRhdGFSZWYsXG4gICAgb3BlbixcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgZWxlbWVudHMsXG4gICAgZXZlbnRzLFxuICAgIGZsb2F0aW5nSWQsXG4gICAgcmVmc1xuICB9KSwgW29wZW4sIG9uT3BlbkNoYW5nZSwgZWxlbWVudHMsIGV2ZW50cywgZmxvYXRpbmdJZCwgcmVmc10pO1xufVxuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gcG9zaXRpb24gYSBmbG9hdGluZyBlbGVtZW50IGFuZCBjb250ZXh0IHRvIGFkZCBpbnRlcmFjdGlvbnMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlRmxvYXRpbmdcbiAqL1xuZnVuY3Rpb24gdXNlRmxvYXRpbmcob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBub2RlSWRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGludGVybmFsUm9vdENvbnRleHQgPSB1c2VGbG9hdGluZ1Jvb3RDb250ZXh0KHtcbiAgICAuLi5vcHRpb25zLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICByZWZlcmVuY2U6IG51bGwsXG4gICAgICBmbG9hdGluZzogbnVsbCxcbiAgICAgIC4uLm9wdGlvbnMuZWxlbWVudHNcbiAgICB9XG4gIH0pO1xuICBjb25zdCByb290Q29udGV4dCA9IG9wdGlvbnMucm9vdENvbnRleHQgfHwgaW50ZXJuYWxSb290Q29udGV4dDtcbiAgY29uc3QgY29tcHV0ZWRFbGVtZW50cyA9IHJvb3RDb250ZXh0LmVsZW1lbnRzO1xuICBjb25zdCBbX2RvbVJlZmVyZW5jZSwgc2V0RG9tUmVmZXJlbmNlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbcG9zaXRpb25SZWZlcmVuY2UsIF9zZXRQb3NpdGlvblJlZmVyZW5jZV0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3Qgb3B0aW9uRG9tUmVmZXJlbmNlID0gY29tcHV0ZWRFbGVtZW50cyA9PSBudWxsID8gdm9pZCAwIDogY29tcHV0ZWRFbGVtZW50cy5kb21SZWZlcmVuY2U7XG4gIGNvbnN0IGRvbVJlZmVyZW5jZSA9IG9wdGlvbkRvbVJlZmVyZW5jZSB8fCBfZG9tUmVmZXJlbmNlO1xuICBjb25zdCBkb21SZWZlcmVuY2VSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChkb21SZWZlcmVuY2UpIHtcbiAgICAgIGRvbVJlZmVyZW5jZVJlZi5jdXJyZW50ID0gZG9tUmVmZXJlbmNlO1xuICAgIH1cbiAgfSwgW2RvbVJlZmVyZW5jZV0pO1xuICBjb25zdCBwb3NpdGlvbiA9IHVzZUZsb2F0aW5nJDEoe1xuICAgIC4uLm9wdGlvbnMsXG4gICAgZWxlbWVudHM6IHtcbiAgICAgIC4uLmNvbXB1dGVkRWxlbWVudHMsXG4gICAgICAuLi4ocG9zaXRpb25SZWZlcmVuY2UgJiYge1xuICAgICAgICByZWZlcmVuY2U6IHBvc2l0aW9uUmVmZXJlbmNlXG4gICAgICB9KVxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHNldFBvc2l0aW9uUmVmZXJlbmNlID0gUmVhY3QudXNlQ2FsbGJhY2sobm9kZSA9PiB7XG4gICAgY29uc3QgY29tcHV0ZWRQb3NpdGlvblJlZmVyZW5jZSA9IGlzRWxlbWVudChub2RlKSA/IHtcbiAgICAgIGdldEJvdW5kaW5nQ2xpZW50UmVjdDogKCkgPT4gbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIGNvbnRleHRFbGVtZW50OiBub2RlXG4gICAgfSA6IG5vZGU7XG4gICAgLy8gU3RvcmUgdGhlIHBvc2l0aW9uUmVmZXJlbmNlIGluIHN0YXRlIGlmIHRoZSBET00gcmVmZXJlbmNlIGlzIHNwZWNpZmllZCBleHRlcm5hbGx5IHZpYSB0aGVcbiAgICAvLyBgZWxlbWVudHMucmVmZXJlbmNlYCBvcHRpb24uIFRoaXMgZW5zdXJlcyB0aGF0IGl0IHdvbid0IGJlIG92ZXJyaWRkZW4gb24gZnV0dXJlIHJlbmRlcnMuXG4gICAgX3NldFBvc2l0aW9uUmVmZXJlbmNlKGNvbXB1dGVkUG9zaXRpb25SZWZlcmVuY2UpO1xuICAgIHBvc2l0aW9uLnJlZnMuc2V0UmVmZXJlbmNlKGNvbXB1dGVkUG9zaXRpb25SZWZlcmVuY2UpO1xuICB9LCBbcG9zaXRpb24ucmVmc10pO1xuICBjb25zdCBzZXRSZWZlcmVuY2UgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBpZiAoaXNFbGVtZW50KG5vZGUpIHx8IG5vZGUgPT09IG51bGwpIHtcbiAgICAgIGRvbVJlZmVyZW5jZVJlZi5jdXJyZW50ID0gbm9kZTtcbiAgICAgIHNldERvbVJlZmVyZW5jZShub2RlKTtcbiAgICB9XG5cbiAgICAvLyBCYWNrd2FyZHMtY29tcGF0aWJpbGl0eSBmb3IgcGFzc2luZyBhIHZpcnR1YWwgZWxlbWVudCB0byBgcmVmZXJlbmNlYFxuICAgIC8vIGFmdGVyIGl0IGhhcyBzZXQgdGhlIERPTSByZWZlcmVuY2UuXG4gICAgaWYgKGlzRWxlbWVudChwb3NpdGlvbi5yZWZzLnJlZmVyZW5jZS5jdXJyZW50KSB8fCBwb3NpdGlvbi5yZWZzLnJlZmVyZW5jZS5jdXJyZW50ID09PSBudWxsIHx8XG4gICAgLy8gRG9uJ3QgYWxsb3cgc2V0dGluZyB2aXJ0dWFsIGVsZW1lbnRzIHVzaW5nIHRoZSBvbGQgdGVjaG5pcXVlIGJhY2sgdG9cbiAgICAvLyBgbnVsbGAgdG8gc3VwcG9ydCBgcG9zaXRpb25SZWZlcmVuY2VgICsgYW4gdW5zdGFibGUgYHJlZmVyZW5jZWBcbiAgICAvLyBjYWxsYmFjayByZWYuXG4gICAgbm9kZSAhPT0gbnVsbCAmJiAhaXNFbGVtZW50KG5vZGUpKSB7XG4gICAgICBwb3NpdGlvbi5yZWZzLnNldFJlZmVyZW5jZShub2RlKTtcbiAgICB9XG4gIH0sIFtwb3NpdGlvbi5yZWZzXSk7XG4gIGNvbnN0IHJlZnMgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4ucG9zaXRpb24ucmVmcyxcbiAgICBzZXRSZWZlcmVuY2UsXG4gICAgc2V0UG9zaXRpb25SZWZlcmVuY2UsXG4gICAgZG9tUmVmZXJlbmNlOiBkb21SZWZlcmVuY2VSZWZcbiAgfSksIFtwb3NpdGlvbi5yZWZzLCBzZXRSZWZlcmVuY2UsIHNldFBvc2l0aW9uUmVmZXJlbmNlXSk7XG4gIGNvbnN0IGVsZW1lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIC4uLnBvc2l0aW9uLmVsZW1lbnRzLFxuICAgIGRvbVJlZmVyZW5jZTogZG9tUmVmZXJlbmNlXG4gIH0pLCBbcG9zaXRpb24uZWxlbWVudHMsIGRvbVJlZmVyZW5jZV0pO1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIC4uLnBvc2l0aW9uLFxuICAgIC4uLnJvb3RDb250ZXh0LFxuICAgIHJlZnMsXG4gICAgZWxlbWVudHMsXG4gICAgbm9kZUlkXG4gIH0pLCBbcG9zaXRpb24sIHJlZnMsIGVsZW1lbnRzLCBub2RlSWQsIHJvb3RDb250ZXh0XSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICByb290Q29udGV4dC5kYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0ID0gY29udGV4dDtcbiAgICBjb25zdCBub2RlID0gdHJlZSA9PSBudWxsID8gdm9pZCAwIDogdHJlZS5ub2Rlc1JlZi5jdXJyZW50LmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBub2RlSWQpO1xuICAgIGlmIChub2RlKSB7XG4gICAgICBub2RlLmNvbnRleHQgPSBjb250ZXh0O1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4ucG9zaXRpb24sXG4gICAgY29udGV4dCxcbiAgICByZWZzLFxuICAgIGVsZW1lbnRzXG4gIH0pLCBbcG9zaXRpb24sIHJlZnMsIGVsZW1lbnRzLCBjb250ZXh0XSk7XG59XG5cbi8qKlxuICogT3BlbnMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2hpbGUgdGhlIHJlZmVyZW5jZSBlbGVtZW50IGhhcyBmb2N1cywgbGlrZSBDU1NcbiAqIGA6Zm9jdXNgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3VzZUZvY3VzXG4gKi9cbmZ1bmN0aW9uIHVzZUZvY3VzKGNvbnRleHQsIHByb3BzKSB7XG4gIGlmIChwcm9wcyA9PT0gdm9pZCAwKSB7XG4gICAgcHJvcHMgPSB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgb3BlbixcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgZXZlbnRzLFxuICAgIGRhdGFSZWYsXG4gICAgZWxlbWVudHNcbiAgfSA9IGNvbnRleHQ7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICB2aXNpYmxlT25seSA9IHRydWVcbiAgfSA9IHByb3BzO1xuICBjb25zdCBibG9ja0ZvY3VzUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgdGltZW91dFJlZiA9IFJlYWN0LnVzZVJlZigpO1xuICBjb25zdCBrZXlib2FyZE1vZGFsaXR5UmVmID0gUmVhY3QudXNlUmVmKHRydWUpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGNvbnN0IHdpbiA9IGdldFdpbmRvdyhlbGVtZW50cy5kb21SZWZlcmVuY2UpO1xuXG4gICAgLy8gSWYgdGhlIHJlZmVyZW5jZSB3YXMgZm9jdXNlZCBhbmQgdGhlIHVzZXIgbGVmdCB0aGUgdGFiL3dpbmRvdywgYW5kIHRoZVxuICAgIC8vIGZsb2F0aW5nIGVsZW1lbnQgd2FzIG5vdCBvcGVuLCB0aGUgZm9jdXMgc2hvdWxkIGJlIGJsb2NrZWQgd2hlbiB0aGV5XG4gICAgLy8gcmV0dXJuIHRvIHRoZSB0YWIvd2luZG93LlxuICAgIGZ1bmN0aW9uIG9uQmx1cigpIHtcbiAgICAgIGlmICghb3BlbiAmJiBpc0hUTUxFbGVtZW50KGVsZW1lbnRzLmRvbVJlZmVyZW5jZSkgJiYgZWxlbWVudHMuZG9tUmVmZXJlbmNlID09PSBhY3RpdmVFbGVtZW50KGdldERvY3VtZW50KGVsZW1lbnRzLmRvbVJlZmVyZW5jZSkpKSB7XG4gICAgICAgIGJsb2NrRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uS2V5RG93bigpIHtcbiAgICAgIGtleWJvYXJkTW9kYWxpdHlSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfVxuICAgIHdpbi5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgb25CbHVyKTtcbiAgICB3aW4uYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93biwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKCdibHVyJywgb25CbHVyKTtcbiAgICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duLCB0cnVlKTtcbiAgICB9O1xuICB9LCBbZWxlbWVudHMuZG9tUmVmZXJlbmNlLCBvcGVuLCBlbmFibGVkXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSByZXR1cm47XG4gICAgZnVuY3Rpb24gb25PcGVuQ2hhbmdlKF9yZWYpIHtcbiAgICAgIGxldCB7XG4gICAgICAgIHJlYXNvblxuICAgICAgfSA9IF9yZWY7XG4gICAgICBpZiAocmVhc29uID09PSAncmVmZXJlbmNlLXByZXNzJyB8fCByZWFzb24gPT09ICdlc2NhcGUta2V5Jykge1xuICAgICAgICBibG9ja0ZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBldmVudHMub24oJ29wZW5jaGFuZ2UnLCBvbk9wZW5DaGFuZ2UpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBldmVudHMub2ZmKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlKTtcbiAgICB9O1xuICB9LCBbZXZlbnRzLCBlbmFibGVkXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgIH07XG4gIH0sIFtdKTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uUG9pbnRlckRvd24oZXZlbnQpIHtcbiAgICAgIGlmIChpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQubmF0aXZlRXZlbnQpKSByZXR1cm47XG4gICAgICBrZXlib2FyZE1vZGFsaXR5UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9LFxuICAgIG9uTW91c2VMZWF2ZSgpIHtcbiAgICAgIGJsb2NrRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH0sXG4gICAgb25Gb2N1cyhldmVudCkge1xuICAgICAgaWYgKGJsb2NrRm9jdXNSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgIGlmICh2aXNpYmxlT25seSAmJiBpc0VsZW1lbnQodGFyZ2V0KSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIC8vIE1hYyBTYWZhcmkgdW5yZWxpYWJseSBtYXRjaGVzIGA6Zm9jdXMtdmlzaWJsZWAgb24gdGhlIHJlZmVyZW5jZVxuICAgICAgICAgIC8vIGlmIGZvY3VzIHdhcyBvdXRzaWRlIHRoZSBwYWdlIGluaXRpYWxseSAtIHVzZSB0aGUgZmFsbGJhY2tcbiAgICAgICAgICAvLyBpbnN0ZWFkLlxuICAgICAgICAgIGlmIChpc1NhZmFyaSgpICYmIGlzTWFjKCkpIHRocm93IEVycm9yKCk7XG4gICAgICAgICAgaWYgKCF0YXJnZXQubWF0Y2hlcygnOmZvY3VzLXZpc2libGUnKSkgcmV0dXJuO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gT2xkIGJyb3dzZXJzIHdpbGwgdGhyb3cgYW4gZXJyb3Igd2hlbiB1c2luZyBgOmZvY3VzLXZpc2libGVgLlxuICAgICAgICAgIGlmICgha2V5Ym9hcmRNb2RhbGl0eVJlZi5jdXJyZW50ICYmICFpc1R5cGVhYmxlRWxlbWVudCh0YXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBvbk9wZW5DaGFuZ2UodHJ1ZSwgZXZlbnQubmF0aXZlRXZlbnQsICdmb2N1cycpO1xuICAgIH0sXG4gICAgb25CbHVyKGV2ZW50KSB7XG4gICAgICBibG9ja0ZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIGNvbnN0IHJlbGF0ZWRUYXJnZXQgPSBldmVudC5yZWxhdGVkVGFyZ2V0O1xuICAgICAgY29uc3QgbmF0aXZlRXZlbnQgPSBldmVudC5uYXRpdmVFdmVudDtcblxuICAgICAgLy8gSGl0IHRoZSBub24tbW9kYWwgZm9jdXMgbWFuYWdlbWVudCBwb3J0YWwgZ3VhcmQuIEZvY3VzIHdpbGwgYmVcbiAgICAgIC8vIG1vdmVkIGludG8gdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW1tZWRpYXRlbHkgYWZ0ZXIuXG4gICAgICBjb25zdCBtb3ZlZFRvRm9jdXNHdWFyZCA9IGlzRWxlbWVudChyZWxhdGVkVGFyZ2V0KSAmJiByZWxhdGVkVGFyZ2V0Lmhhc0F0dHJpYnV0ZShjcmVhdGVBdHRyaWJ1dGUoJ2ZvY3VzLWd1YXJkJykpICYmIHJlbGF0ZWRUYXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXR5cGUnKSA9PT0gJ291dHNpZGUnO1xuXG4gICAgICAvLyBXYWl0IGZvciB0aGUgd2luZG93IGJsdXIgbGlzdGVuZXIgdG8gZmlyZS5cbiAgICAgIHRpbWVvdXRSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdmFyIF9kYXRhUmVmJGN1cnJlbnQkZmxvYTtcbiAgICAgICAgY29uc3QgYWN0aXZlRWwgPSBhY3RpdmVFbGVtZW50KGVsZW1lbnRzLmRvbVJlZmVyZW5jZSA/IGVsZW1lbnRzLmRvbVJlZmVyZW5jZS5vd25lckRvY3VtZW50IDogZG9jdW1lbnQpO1xuXG4gICAgICAgIC8vIEZvY3VzIGxlZnQgdGhlIHBhZ2UsIGtlZXAgaXQgb3Blbi5cbiAgICAgICAgaWYgKCFyZWxhdGVkVGFyZ2V0ICYmIGFjdGl2ZUVsID09PSBlbGVtZW50cy5kb21SZWZlcmVuY2UpIHJldHVybjtcblxuICAgICAgICAvLyBXaGVuIGZvY3VzaW5nIHRoZSByZWZlcmVuY2UgZWxlbWVudCAoZS5nLiByZWd1bGFyIGNsaWNrKSwgdGhlblxuICAgICAgICAvLyBjbGlja2luZyBpbnRvIHRoZSBmbG9hdGluZyBlbGVtZW50LCBwcmV2ZW50IGl0IGZyb20gaGlkaW5nLlxuICAgICAgICAvLyBOb3RlOiBpdCBtdXN0IGJlIGZvY3VzYWJsZSwgZS5nLiBgdGFiaW5kZXg9XCItMVwiYC5cbiAgICAgICAgLy8gV2UgY2FuIG5vdCByZWx5IG9uIHJlbGF0ZWRUYXJnZXQgdG8gcG9pbnQgdG8gdGhlIGNvcnJlY3QgZWxlbWVudFxuICAgICAgICAvLyBhcyBpdCB3aWxsIG9ubHkgcG9pbnQgdG8gdGhlIHNoYWRvdyBob3N0IG9mIHRoZSBuZXdseSBmb2N1c2VkIGVsZW1lbnRcbiAgICAgICAgLy8gYW5kIG5vdCB0aGUgZWxlbWVudCB0aGF0IGFjdHVhbGx5IGhhcyByZWNlaXZlZCBmb2N1cyBpZiBpdCBpcyBsb2NhdGVkXG4gICAgICAgIC8vIGluc2lkZSBhIHNoYWRvdyByb290LlxuICAgICAgICBpZiAoY29udGFpbnMoKF9kYXRhUmVmJGN1cnJlbnQkZmxvYSA9IGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfZGF0YVJlZiRjdXJyZW50JGZsb2EucmVmcy5mbG9hdGluZy5jdXJyZW50LCBhY3RpdmVFbCkgfHwgY29udGFpbnMoZWxlbWVudHMuZG9tUmVmZXJlbmNlLCBhY3RpdmVFbCkgfHwgbW92ZWRUb0ZvY3VzR3VhcmQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb25PcGVuQ2hhbmdlKGZhbHNlLCBuYXRpdmVFdmVudCwgJ2ZvY3VzJyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pLCBbZGF0YVJlZiwgZWxlbWVudHMuZG9tUmVmZXJlbmNlLCBvbk9wZW5DaGFuZ2UsIHZpc2libGVPbmx5XSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlXG4gIH0gOiB7fSwgW2VuYWJsZWQsIHJlZmVyZW5jZV0pO1xufVxuXG5jb25zdCBBQ1RJVkVfS0VZID0gJ2FjdGl2ZSc7XG5jb25zdCBTRUxFQ1RFRF9LRVkgPSAnc2VsZWN0ZWQnO1xuZnVuY3Rpb24gbWVyZ2VQcm9wcyh1c2VyUHJvcHMsIHByb3BzTGlzdCwgZWxlbWVudEtleSkge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gIGNvbnN0IGlzSXRlbSA9IGVsZW1lbnRLZXkgPT09ICdpdGVtJztcbiAgbGV0IGRvbVVzZXJQcm9wcyA9IHVzZXJQcm9wcztcbiAgaWYgKGlzSXRlbSAmJiB1c2VyUHJvcHMpIHtcbiAgICBjb25zdCB7XG4gICAgICBbQUNUSVZFX0tFWV06IF8sXG4gICAgICBbU0VMRUNURURfS0VZXTogX18sXG4gICAgICAuLi52YWxpZFByb3BzXG4gICAgfSA9IHVzZXJQcm9wcztcbiAgICBkb21Vc2VyUHJvcHMgPSB2YWxpZFByb3BzO1xuICB9XG4gIHJldHVybiB7XG4gICAgLi4uKGVsZW1lbnRLZXkgPT09ICdmbG9hdGluZycgJiYge1xuICAgICAgdGFiSW5kZXg6IC0xLFxuICAgICAgW0ZPQ1VTQUJMRV9BVFRSSUJVVEVdOiAnJ1xuICAgIH0pLFxuICAgIC4uLmRvbVVzZXJQcm9wcyxcbiAgICAuLi5wcm9wc0xpc3QubWFwKHZhbHVlID0+IHtcbiAgICAgIGNvbnN0IHByb3BzT3JHZXRQcm9wcyA9IHZhbHVlID8gdmFsdWVbZWxlbWVudEtleV0gOiBudWxsO1xuICAgICAgaWYgKHR5cGVvZiBwcm9wc09yR2V0UHJvcHMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIHVzZXJQcm9wcyA/IHByb3BzT3JHZXRQcm9wcyh1c2VyUHJvcHMpIDogbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwcm9wc09yR2V0UHJvcHM7XG4gICAgfSkuY29uY2F0KHVzZXJQcm9wcykucmVkdWNlKChhY2MsIHByb3BzKSA9PiB7XG4gICAgICBpZiAoIXByb3BzKSB7XG4gICAgICAgIHJldHVybiBhY2M7XG4gICAgICB9XG4gICAgICBPYmplY3QuZW50cmllcyhwcm9wcykuZm9yRWFjaChfcmVmID0+IHtcbiAgICAgICAgbGV0IFtrZXksIHZhbHVlXSA9IF9yZWY7XG4gICAgICAgIGlmIChpc0l0ZW0gJiYgW0FDVElWRV9LRVksIFNFTEVDVEVEX0tFWV0uaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoa2V5LmluZGV4T2YoJ29uJykgPT09IDApIHtcbiAgICAgICAgICBpZiAoIW1hcC5oYXMoa2V5KSkge1xuICAgICAgICAgICAgbWFwLnNldChrZXksIFtdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdmFyIF9tYXAkZ2V0O1xuICAgICAgICAgICAgKF9tYXAkZ2V0ID0gbWFwLmdldChrZXkpKSA9PSBudWxsIHx8IF9tYXAkZ2V0LnB1c2godmFsdWUpO1xuICAgICAgICAgICAgYWNjW2tleV0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHZhciBfbWFwJGdldDI7XG4gICAgICAgICAgICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgICAgICAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIChfbWFwJGdldDIgPSBtYXAuZ2V0KGtleSkpID09IG51bGwgPyB2b2lkIDAgOiBfbWFwJGdldDIubWFwKGZuID0+IGZuKC4uLmFyZ3MpKS5maW5kKHZhbCA9PiB2YWwgIT09IHVuZGVmaW5lZCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBhY2Nba2V5XSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBhY2M7XG4gICAgfSwge30pXG4gIH07XG59XG4vKipcbiAqIE1lcmdlcyBhbiBhcnJheSBvZiBpbnRlcmFjdGlvbiBob29rcycgcHJvcHMgaW50byBwcm9wIGdldHRlcnMsIGFsbG93aW5nXG4gKiBldmVudCBoYW5kbGVyIGZ1bmN0aW9ucyB0byBiZSBjb21wb3NlZCB0b2dldGhlciB3aXRob3V0IG92ZXJ3cml0aW5nIG9uZVxuICogYW5vdGhlci5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VJbnRlcmFjdGlvbnNcbiAqL1xuZnVuY3Rpb24gdXNlSW50ZXJhY3Rpb25zKHByb3BzTGlzdCkge1xuICBpZiAocHJvcHNMaXN0ID09PSB2b2lkIDApIHtcbiAgICBwcm9wc0xpc3QgPSBbXTtcbiAgfVxuICBjb25zdCByZWZlcmVuY2VEZXBzID0gcHJvcHNMaXN0Lm1hcChrZXkgPT4ga2V5ID09IG51bGwgPyB2b2lkIDAgOiBrZXkucmVmZXJlbmNlKTtcbiAgY29uc3QgZmxvYXRpbmdEZXBzID0gcHJvcHNMaXN0Lm1hcChrZXkgPT4ga2V5ID09IG51bGwgPyB2b2lkIDAgOiBrZXkuZmxvYXRpbmcpO1xuICBjb25zdCBpdGVtRGVwcyA9IHByb3BzTGlzdC5tYXAoa2V5ID0+IGtleSA9PSBudWxsID8gdm9pZCAwIDoga2V5Lml0ZW0pO1xuICBjb25zdCBnZXRSZWZlcmVuY2VQcm9wcyA9IFJlYWN0LnVzZUNhbGxiYWNrKHVzZXJQcm9wcyA9PiBtZXJnZVByb3BzKHVzZXJQcm9wcywgcHJvcHNMaXN0LCAncmVmZXJlbmNlJyksXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgcmVmZXJlbmNlRGVwcyk7XG4gIGNvbnN0IGdldEZsb2F0aW5nUHJvcHMgPSBSZWFjdC51c2VDYWxsYmFjayh1c2VyUHJvcHMgPT4gbWVyZ2VQcm9wcyh1c2VyUHJvcHMsIHByb3BzTGlzdCwgJ2Zsb2F0aW5nJyksXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgZmxvYXRpbmdEZXBzKTtcbiAgY29uc3QgZ2V0SXRlbVByb3BzID0gUmVhY3QudXNlQ2FsbGJhY2sodXNlclByb3BzID0+IG1lcmdlUHJvcHModXNlclByb3BzLCBwcm9wc0xpc3QsICdpdGVtJyksXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgaXRlbURlcHMpO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGdldFJlZmVyZW5jZVByb3BzLFxuICAgIGdldEZsb2F0aW5nUHJvcHMsXG4gICAgZ2V0SXRlbVByb3BzXG4gIH0pLCBbZ2V0UmVmZXJlbmNlUHJvcHMsIGdldEZsb2F0aW5nUHJvcHMsIGdldEl0ZW1Qcm9wc10pO1xufVxuXG5sZXQgaXNQcmV2ZW50U2Nyb2xsU3VwcG9ydGVkID0gZmFsc2U7XG5mdW5jdGlvbiBkb1N3aXRjaChvcmllbnRhdGlvbiwgdmVydGljYWwsIGhvcml6b250YWwpIHtcbiAgc3dpdGNoIChvcmllbnRhdGlvbikge1xuICAgIGNhc2UgJ3ZlcnRpY2FsJzpcbiAgICAgIHJldHVybiB2ZXJ0aWNhbDtcbiAgICBjYXNlICdob3Jpem9udGFsJzpcbiAgICAgIHJldHVybiBob3Jpem9udGFsO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdmVydGljYWwgfHwgaG9yaXpvbnRhbDtcbiAgfVxufVxuZnVuY3Rpb24gaXNNYWluT3JpZW50YXRpb25LZXkoa2V5LCBvcmllbnRhdGlvbikge1xuICBjb25zdCB2ZXJ0aWNhbCA9IGtleSA9PT0gQVJST1dfVVAgfHwga2V5ID09PSBBUlJPV19ET1dOO1xuICBjb25zdCBob3Jpem9udGFsID0ga2V5ID09PSBBUlJPV19MRUZUIHx8IGtleSA9PT0gQVJST1dfUklHSFQ7XG4gIHJldHVybiBkb1N3aXRjaChvcmllbnRhdGlvbiwgdmVydGljYWwsIGhvcml6b250YWwpO1xufVxuZnVuY3Rpb24gaXNNYWluT3JpZW50YXRpb25Ub0VuZEtleShrZXksIG9yaWVudGF0aW9uLCBydGwpIHtcbiAgY29uc3QgdmVydGljYWwgPSBrZXkgPT09IEFSUk9XX0RPV047XG4gIGNvbnN0IGhvcml6b250YWwgPSBydGwgPyBrZXkgPT09IEFSUk9XX0xFRlQgOiBrZXkgPT09IEFSUk9XX1JJR0hUO1xuICByZXR1cm4gZG9Td2l0Y2gob3JpZW50YXRpb24sIHZlcnRpY2FsLCBob3Jpem9udGFsKSB8fCBrZXkgPT09ICdFbnRlcicgfHwga2V5ID09PSAnICcgfHwga2V5ID09PSAnJztcbn1cbmZ1bmN0aW9uIGlzQ3Jvc3NPcmllbnRhdGlvbk9wZW5LZXkoa2V5LCBvcmllbnRhdGlvbiwgcnRsKSB7XG4gIGNvbnN0IHZlcnRpY2FsID0gcnRsID8ga2V5ID09PSBBUlJPV19MRUZUIDoga2V5ID09PSBBUlJPV19SSUdIVDtcbiAgY29uc3QgaG9yaXpvbnRhbCA9IGtleSA9PT0gQVJST1dfRE9XTjtcbiAgcmV0dXJuIGRvU3dpdGNoKG9yaWVudGF0aW9uLCB2ZXJ0aWNhbCwgaG9yaXpvbnRhbCk7XG59XG5mdW5jdGlvbiBpc0Nyb3NzT3JpZW50YXRpb25DbG9zZUtleShrZXksIG9yaWVudGF0aW9uLCBydGwpIHtcbiAgY29uc3QgdmVydGljYWwgPSBydGwgPyBrZXkgPT09IEFSUk9XX1JJR0hUIDoga2V5ID09PSBBUlJPV19MRUZUO1xuICBjb25zdCBob3Jpem9udGFsID0ga2V5ID09PSBBUlJPV19VUDtcbiAgcmV0dXJuIGRvU3dpdGNoKG9yaWVudGF0aW9uLCB2ZXJ0aWNhbCwgaG9yaXpvbnRhbCk7XG59XG4vKipcbiAqIEFkZHMgYXJyb3cga2V5LWJhc2VkIG5hdmlnYXRpb24gb2YgYSBsaXN0IG9mIGl0ZW1zLCBlaXRoZXIgdXNpbmcgcmVhbCBET01cbiAqIGZvY3VzIG9yIHZpcnR1YWwgZm9jdXMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlTGlzdE5hdmlnYXRpb25cbiAqL1xuZnVuY3Rpb24gdXNlTGlzdE5hdmlnYXRpb24oY29udGV4dCwgcHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIGVsZW1lbnRzXG4gIH0gPSBjb250ZXh0O1xuICBjb25zdCB7XG4gICAgbGlzdFJlZixcbiAgICBhY3RpdmVJbmRleCxcbiAgICBvbk5hdmlnYXRlOiB1bnN0YWJsZV9vbk5hdmlnYXRlID0gKCkgPT4ge30sXG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgc2VsZWN0ZWRJbmRleCA9IG51bGwsXG4gICAgYWxsb3dFc2NhcGUgPSBmYWxzZSxcbiAgICBsb29wID0gZmFsc2UsXG4gICAgbmVzdGVkID0gZmFsc2UsXG4gICAgcnRsID0gZmFsc2UsXG4gICAgdmlydHVhbCA9IGZhbHNlLFxuICAgIGZvY3VzSXRlbU9uT3BlbiA9ICdhdXRvJyxcbiAgICBmb2N1c0l0ZW1PbkhvdmVyID0gdHJ1ZSxcbiAgICBvcGVuT25BcnJvd0tleURvd24gPSB0cnVlLFxuICAgIGRpc2FibGVkSW5kaWNlcyA9IHVuZGVmaW5lZCxcbiAgICBvcmllbnRhdGlvbiA9ICd2ZXJ0aWNhbCcsXG4gICAgY29scyA9IDEsXG4gICAgc2Nyb2xsSXRlbUludG9WaWV3ID0gdHJ1ZSxcbiAgICB2aXJ0dWFsSXRlbVJlZixcbiAgICBpdGVtU2l6ZXMsXG4gICAgZGVuc2UgPSBmYWxzZVxuICB9ID0gcHJvcHM7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICBpZiAoYWxsb3dFc2NhcGUpIHtcbiAgICAgIGlmICghbG9vcCkge1xuICAgICAgICB3YXJuKCdgdXNlTGlzdE5hdmlnYXRpb25gIGxvb3BpbmcgbXVzdCBiZSBlbmFibGVkIHRvIGFsbG93IGVzY2FwaW5nLicpO1xuICAgICAgfVxuICAgICAgaWYgKCF2aXJ0dWFsKSB7XG4gICAgICAgIHdhcm4oJ2B1c2VMaXN0TmF2aWdhdGlvbmAgbXVzdCBiZSB2aXJ0dWFsIHRvIGFsbG93IGVzY2FwaW5nLicpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAob3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcgJiYgY29scyA+IDEpIHtcbiAgICAgIHdhcm4oJ0luIGdyaWQgbGlzdCBuYXZpZ2F0aW9uIG1vZGUgKGBjb2xzYCA+IDEpLCB0aGUgYG9yaWVudGF0aW9uYCBzaG91bGQnLCAnYmUgZWl0aGVyIFwiaG9yaXpvbnRhbFwiIG9yIFwiYm90aFwiLicpO1xuICAgIH1cbiAgfVxuICBjb25zdCBmbG9hdGluZ0ZvY3VzRWxlbWVudCA9IGdldEZsb2F0aW5nRm9jdXNFbGVtZW50KGVsZW1lbnRzLmZsb2F0aW5nKTtcbiAgY29uc3QgZmxvYXRpbmdGb2N1c0VsZW1lbnRSZWYgPSB1c2VMYXRlc3RSZWYoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICBjb25zdCBwYXJlbnRJZCA9IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkKCk7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoKTtcbiAgY29uc3Qgb25OYXZpZ2F0ZSA9IHVzZUVmZmVjdEV2ZW50KHVuc3RhYmxlX29uTmF2aWdhdGUpO1xuICBjb25zdCB0eXBlYWJsZUNvbWJvYm94UmVmZXJlbmNlID0gaXNUeXBlYWJsZUNvbWJvYm94KGVsZW1lbnRzLmRvbVJlZmVyZW5jZSk7XG4gIGNvbnN0IGZvY3VzSXRlbU9uT3BlblJlZiA9IFJlYWN0LnVzZVJlZihmb2N1c0l0ZW1Pbk9wZW4pO1xuICBjb25zdCBpbmRleFJlZiA9IFJlYWN0LnVzZVJlZihzZWxlY3RlZEluZGV4ICE9IG51bGwgPyBzZWxlY3RlZEluZGV4IDogLTEpO1xuICBjb25zdCBrZXlSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGlzUG9pbnRlck1vZGFsaXR5UmVmID0gUmVhY3QudXNlUmVmKHRydWUpO1xuICBjb25zdCBwcmV2aW91c09uTmF2aWdhdGVSZWYgPSBSZWFjdC51c2VSZWYob25OYXZpZ2F0ZSk7XG4gIGNvbnN0IHByZXZpb3VzTW91bnRlZFJlZiA9IFJlYWN0LnVzZVJlZighIWVsZW1lbnRzLmZsb2F0aW5nKTtcbiAgY29uc3QgcHJldmlvdXNPcGVuUmVmID0gUmVhY3QudXNlUmVmKG9wZW4pO1xuICBjb25zdCBmb3JjZVN5bmNGb2N1cyA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGZvcmNlU2Nyb2xsSW50b1ZpZXdSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBkaXNhYmxlZEluZGljZXNSZWYgPSB1c2VMYXRlc3RSZWYoZGlzYWJsZWRJbmRpY2VzKTtcbiAgY29uc3QgbGF0ZXN0T3BlblJlZiA9IHVzZUxhdGVzdFJlZihvcGVuKTtcbiAgY29uc3Qgc2Nyb2xsSXRlbUludG9WaWV3UmVmID0gdXNlTGF0ZXN0UmVmKHNjcm9sbEl0ZW1JbnRvVmlldyk7XG4gIGNvbnN0IHNlbGVjdGVkSW5kZXhSZWYgPSB1c2VMYXRlc3RSZWYoc2VsZWN0ZWRJbmRleCk7XG4gIGNvbnN0IFthY3RpdmVJZCwgc2V0QWN0aXZlSWRdID0gUmVhY3QudXNlU3RhdGUoKTtcbiAgY29uc3QgW3ZpcnR1YWxJZCwgc2V0VmlydHVhbElkXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGNvbnN0IGZvY3VzSXRlbSA9IHVzZUVmZmVjdEV2ZW50KGZ1bmN0aW9uIChsaXN0UmVmLCBpbmRleFJlZiwgZm9yY2VTY3JvbGxJbnRvVmlldykge1xuICAgIGlmIChmb3JjZVNjcm9sbEludG9WaWV3ID09PSB2b2lkIDApIHtcbiAgICAgIGZvcmNlU2Nyb2xsSW50b1ZpZXcgPSBmYWxzZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcnVuRm9jdXMoaXRlbSkge1xuICAgICAgaWYgKHZpcnR1YWwpIHtcbiAgICAgICAgc2V0QWN0aXZlSWQoaXRlbS5pZCk7XG4gICAgICAgIHRyZWUgPT0gbnVsbCB8fCB0cmVlLmV2ZW50cy5lbWl0KCd2aXJ0dWFsZm9jdXMnLCBpdGVtKTtcbiAgICAgICAgaWYgKHZpcnR1YWxJdGVtUmVmKSB7XG4gICAgICAgICAgdmlydHVhbEl0ZW1SZWYuY3VycmVudCA9IGl0ZW07XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVucXVldWVGb2N1cyhpdGVtLCB7XG4gICAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZSxcbiAgICAgICAgICAvLyBNYWMgU2FmYXJpIGRvZXMgbm90IG1vdmUgdGhlIHZpcnR1YWwgY3Vyc29yIHVubGVzcyB0aGUgZm9jdXMgY2FsbFxuICAgICAgICAgIC8vIGlzIHN5bmMuIEhvd2V2ZXIsIGZvciB0aGUgdmVyeSBmaXJzdCBmb2N1cyBjYWxsLCB3ZSBuZWVkIHRvIHdhaXRcbiAgICAgICAgICAvLyBmb3IgdGhlIHBvc2l0aW9uIHRvIGJlIHJlYWR5IGluIG9yZGVyIHRvIHByZXZlbnQgdW53YW50ZWRcbiAgICAgICAgICAvLyBzY3JvbGxpbmcuIFRoaXMgbWVhbnMgdGhlIHZpcnR1YWwgY3Vyc29yIHdpbGwgbm90IG1vdmUgdG8gdGhlIGZpcnN0XG4gICAgICAgICAgLy8gaXRlbSB3aGVuIGZpcnN0IG9wZW5pbmcgdGhlIGZsb2F0aW5nIGVsZW1lbnQsIGJ1dCB3aWxsIG9uXG4gICAgICAgICAgLy8gc3Vic2VxdWVudCBjYWxscy4gYHByZXZlbnRTY3JvbGxgIGlzIHN1cHBvcnRlZCBpbiBtb2Rlcm4gU2FmYXJpLFxuICAgICAgICAgIC8vIHNvIHdlIGNhbiB1c2UgdGhhdCBpbnN0ZWFkLlxuICAgICAgICAgIC8vIGlPUyBTYWZhcmkgbXVzdCBiZSBhc3luYyBvciB0aGUgZmlyc3QgaXRlbSB3aWxsIG5vdCBiZSBmb2N1c2VkLlxuICAgICAgICAgIHN5bmM6IGlzTWFjKCkgJiYgaXNTYWZhcmkoKSA/IGlzUHJldmVudFNjcm9sbFN1cHBvcnRlZCB8fCBmb3JjZVN5bmNGb2N1cy5jdXJyZW50IDogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGluaXRpYWxJdGVtID0gbGlzdFJlZi5jdXJyZW50W2luZGV4UmVmLmN1cnJlbnRdO1xuICAgIGlmIChpbml0aWFsSXRlbSkge1xuICAgICAgcnVuRm9jdXMoaW5pdGlhbEl0ZW0pO1xuICAgIH1cbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgY29uc3Qgd2FpdGVkSXRlbSA9IGxpc3RSZWYuY3VycmVudFtpbmRleFJlZi5jdXJyZW50XSB8fCBpbml0aWFsSXRlbTtcbiAgICAgIGlmICghd2FpdGVkSXRlbSkgcmV0dXJuO1xuICAgICAgaWYgKCFpbml0aWFsSXRlbSkge1xuICAgICAgICBydW5Gb2N1cyh3YWl0ZWRJdGVtKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNjcm9sbEludG9WaWV3T3B0aW9ucyA9IHNjcm9sbEl0ZW1JbnRvVmlld1JlZi5jdXJyZW50O1xuICAgICAgY29uc3Qgc2hvdWxkU2Nyb2xsSW50b1ZpZXcgPSBzY3JvbGxJbnRvVmlld09wdGlvbnMgJiYgaXRlbSAmJiAoZm9yY2VTY3JvbGxJbnRvVmlldyB8fCAhaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCk7XG4gICAgICBpZiAoc2hvdWxkU2Nyb2xsSW50b1ZpZXcpIHtcbiAgICAgICAgLy8gSlNET00gZG9lc24ndCBzdXBwb3J0IGAuc2Nyb2xsSW50b1ZpZXcoKWAgYnV0IGl0J3Mgd2lkZWx5IHN1cHBvcnRlZFxuICAgICAgICAvLyBieSBhbGwgYnJvd3NlcnMuXG4gICAgICAgIHdhaXRlZEl0ZW0uc2Nyb2xsSW50b1ZpZXcgPT0gbnVsbCB8fCB3YWl0ZWRJdGVtLnNjcm9sbEludG9WaWV3KHR5cGVvZiBzY3JvbGxJbnRvVmlld09wdGlvbnMgPT09ICdib29sZWFuJyA/IHtcbiAgICAgICAgICBibG9jazogJ25lYXJlc3QnLFxuICAgICAgICAgIGlubGluZTogJ25lYXJlc3QnXG4gICAgICAgIH0gOiBzY3JvbGxJbnRvVmlld09wdGlvbnMpO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpLmZvY3VzKHtcbiAgICAgIGdldCBwcmV2ZW50U2Nyb2xsKCkge1xuICAgICAgICBpc1ByZXZlbnRTY3JvbGxTdXBwb3J0ZWQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyBTeW5jIGBzZWxlY3RlZEluZGV4YCB0byBiZSB0aGUgYGFjdGl2ZUluZGV4YCB1cG9uIG9wZW5pbmcgdGhlIGZsb2F0aW5nXG4gIC8vIGVsZW1lbnQuIEFsc28sIHJlc2V0IGBhY3RpdmVJbmRleGAgdXBvbiBjbG9zaW5nIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSByZXR1cm47XG4gICAgaWYgKG9wZW4gJiYgZWxlbWVudHMuZmxvYXRpbmcpIHtcbiAgICAgIGlmIChmb2N1c0l0ZW1Pbk9wZW5SZWYuY3VycmVudCAmJiBzZWxlY3RlZEluZGV4ICE9IG51bGwpIHtcbiAgICAgICAgLy8gUmVnYXJkbGVzcyBvZiB0aGUgcG9pbnRlciBtb2RhbGl0eSwgd2Ugd2FudCB0byBlbnN1cmUgdGhlIHNlbGVjdGVkXG4gICAgICAgIC8vIGl0ZW0gY29tZXMgaW50byB2aWV3IHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgb3BlbmVkLlxuICAgICAgICBmb3JjZVNjcm9sbEludG9WaWV3UmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gc2VsZWN0ZWRJbmRleDtcbiAgICAgICAgb25OYXZpZ2F0ZShzZWxlY3RlZEluZGV4KTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHByZXZpb3VzTW91bnRlZFJlZi5jdXJyZW50KSB7XG4gICAgICAvLyBTaW5jZSB0aGUgdXNlciBjYW4gc3BlY2lmeSBgb25OYXZpZ2F0ZWAgY29uZGl0aW9uYWxseVxuICAgICAgLy8gKG9uTmF2aWdhdGU6IG9wZW4gPyBzZXRBY3RpdmVJbmRleCA6IHNldFNlbGVjdGVkSW5kZXgpLFxuICAgICAgLy8gd2Ugc3RvcmUgYW5kIGNhbGwgdGhlIHByZXZpb3VzIGZ1bmN0aW9uLlxuICAgICAgaW5kZXhSZWYuY3VycmVudCA9IC0xO1xuICAgICAgcHJldmlvdXNPbk5hdmlnYXRlUmVmLmN1cnJlbnQobnVsbCk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgZWxlbWVudHMuZmxvYXRpbmcsIHNlbGVjdGVkSW5kZXgsIG9uTmF2aWdhdGVdKTtcblxuICAvLyBTeW5jIGBhY3RpdmVJbmRleGAgdG8gYmUgdGhlIGZvY3VzZWQgaXRlbSB3aGlsZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBpc1xuICAvLyBvcGVuLlxuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSByZXR1cm47XG4gICAgaWYgKG9wZW4gJiYgZWxlbWVudHMuZmxvYXRpbmcpIHtcbiAgICAgIGlmIChhY3RpdmVJbmRleCA9PSBudWxsKSB7XG4gICAgICAgIGZvcmNlU3luY0ZvY3VzLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgaWYgKHNlbGVjdGVkSW5kZXhSZWYuY3VycmVudCAhPSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUmVzZXQgd2hpbGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2FzIG9wZW4gKGUuZy4gdGhlIGxpc3QgY2hhbmdlZCkuXG4gICAgICAgIGlmIChwcmV2aW91c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSAtMTtcbiAgICAgICAgICBmb2N1c0l0ZW0obGlzdFJlZiwgaW5kZXhSZWYpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW5pdGlhbCBzeW5jLlxuICAgICAgICBpZiAoKCFwcmV2aW91c09wZW5SZWYuY3VycmVudCB8fCAhcHJldmlvdXNNb3VudGVkUmVmLmN1cnJlbnQpICYmIGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ICYmIChrZXlSZWYuY3VycmVudCAhPSBudWxsIHx8IGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ID09PSB0cnVlICYmIGtleVJlZi5jdXJyZW50ID09IG51bGwpKSB7XG4gICAgICAgICAgbGV0IHJ1bnMgPSAwO1xuICAgICAgICAgIGNvbnN0IHdhaXRGb3JMaXN0UG9wdWxhdGVkID0gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGxpc3RSZWYuY3VycmVudFswXSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgIC8vIEF2b2lkIGxldHRpbmcgdGhlIGJyb3dzZXIgcGFpbnQgaWYgcG9zc2libGUgb24gdGhlIGZpcnN0IHRyeSxcbiAgICAgICAgICAgICAgLy8gb3RoZXJ3aXNlIHVzZSByQUYuIERvbid0IHRyeSBtb3JlIHRoYW4gdHdpY2UsIHNpbmNlIHNvbWV0aGluZ1xuICAgICAgICAgICAgICAvLyBpcyB3cm9uZyBvdGhlcndpc2UuXG4gICAgICAgICAgICAgIGlmIChydW5zIDwgMikge1xuICAgICAgICAgICAgICAgIGNvbnN0IHNjaGVkdWxlciA9IHJ1bnMgPyByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgOiBxdWV1ZU1pY3JvdGFzaztcbiAgICAgICAgICAgICAgICBzY2hlZHVsZXIod2FpdEZvckxpc3RQb3B1bGF0ZWQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJ1bnMrKztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBrZXlSZWYuY3VycmVudCA9PSBudWxsIHx8IGlzTWFpbk9yaWVudGF0aW9uVG9FbmRLZXkoa2V5UmVmLmN1cnJlbnQsIG9yaWVudGF0aW9uLCBydGwpIHx8IG5lc3RlZCA/IGdldE1pbkluZGV4KGxpc3RSZWYsIGRpc2FibGVkSW5kaWNlc1JlZi5jdXJyZW50KSA6IGdldE1heEluZGV4KGxpc3RSZWYsIGRpc2FibGVkSW5kaWNlc1JlZi5jdXJyZW50KTtcbiAgICAgICAgICAgICAga2V5UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICAgICAgICBvbk5hdmlnYXRlKGluZGV4UmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgd2FpdEZvckxpc3RQb3B1bGF0ZWQoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghaXNJbmRleE91dE9mQm91bmRzKGxpc3RSZWYsIGFjdGl2ZUluZGV4KSkge1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gYWN0aXZlSW5kZXg7XG4gICAgICAgIGZvY3VzSXRlbShsaXN0UmVmLCBpbmRleFJlZiwgZm9yY2VTY3JvbGxJbnRvVmlld1JlZi5jdXJyZW50KTtcbiAgICAgICAgZm9yY2VTY3JvbGxJbnRvVmlld1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgZWxlbWVudHMuZmxvYXRpbmcsIGFjdGl2ZUluZGV4LCBzZWxlY3RlZEluZGV4UmVmLCBuZXN0ZWQsIGxpc3RSZWYsIG9yaWVudGF0aW9uLCBydGwsIG9uTmF2aWdhdGUsIGZvY3VzSXRlbSwgZGlzYWJsZWRJbmRpY2VzUmVmXSk7XG5cbiAgLy8gRW5zdXJlIHRoZSBwYXJlbnQgZmxvYXRpbmcgZWxlbWVudCBoYXMgZm9jdXMgd2hlbiBhIG5lc3RlZCBjaGlsZCBjbG9zZXNcbiAgLy8gdG8gYWxsb3cgYXJyb3cga2V5IG5hdmlnYXRpb24gdG8gd29yayBhZnRlciB0aGUgcG9pbnRlciBsZWF2ZXMgdGhlIGNoaWxkLlxuICBpbmRleCgoKSA9PiB7XG4gICAgdmFyIF9ub2RlcyRmaW5kO1xuICAgIGlmICghZW5hYmxlZCB8fCBlbGVtZW50cy5mbG9hdGluZyB8fCAhdHJlZSB8fCB2aXJ0dWFsIHx8ICFwcmV2aW91c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBub2RlcyA9IHRyZWUubm9kZXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBwYXJlbnQgPSAoX25vZGVzJGZpbmQgPSBub2Rlcy5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gcGFyZW50SWQpKSA9PSBudWxsIHx8IChfbm9kZXMkZmluZCA9IF9ub2RlcyRmaW5kLmNvbnRleHQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZXMkZmluZC5lbGVtZW50cy5mbG9hdGluZztcbiAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQoZ2V0RG9jdW1lbnQoZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgICBjb25zdCB0cmVlQ29udGFpbnNBY3RpdmVFbCA9IG5vZGVzLnNvbWUobm9kZSA9PiBub2RlLmNvbnRleHQgJiYgY29udGFpbnMobm9kZS5jb250ZXh0LmVsZW1lbnRzLmZsb2F0aW5nLCBhY3RpdmVFbCkpO1xuICAgIGlmIChwYXJlbnQgJiYgIXRyZWVDb250YWluc0FjdGl2ZUVsICYmIGlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQpIHtcbiAgICAgIHBhcmVudC5mb2N1cyh7XG4gICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2VuYWJsZWQsIGVsZW1lbnRzLmZsb2F0aW5nLCB0cmVlLCBwYXJlbnRJZCwgdmlydHVhbF0pO1xuICBpbmRleCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSByZXR1cm47XG4gICAgaWYgKCF0cmVlKSByZXR1cm47XG4gICAgaWYgKCF2aXJ0dWFsKSByZXR1cm47XG4gICAgaWYgKHBhcmVudElkKSByZXR1cm47XG4gICAgZnVuY3Rpb24gaGFuZGxlVmlydHVhbEZvY3VzKGl0ZW0pIHtcbiAgICAgIHNldFZpcnR1YWxJZChpdGVtLmlkKTtcbiAgICAgIGlmICh2aXJ0dWFsSXRlbVJlZikge1xuICAgICAgICB2aXJ0dWFsSXRlbVJlZi5jdXJyZW50ID0gaXRlbTtcbiAgICAgIH1cbiAgICB9XG4gICAgdHJlZS5ldmVudHMub24oJ3ZpcnR1YWxmb2N1cycsIGhhbmRsZVZpcnR1YWxGb2N1cyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRyZWUuZXZlbnRzLm9mZigndmlydHVhbGZvY3VzJywgaGFuZGxlVmlydHVhbEZvY3VzKTtcbiAgICB9O1xuICB9LCBbZW5hYmxlZCwgdHJlZSwgdmlydHVhbCwgcGFyZW50SWQsIHZpcnR1YWxJdGVtUmVmXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBwcmV2aW91c09uTmF2aWdhdGVSZWYuY3VycmVudCA9IG9uTmF2aWdhdGU7XG4gICAgcHJldmlvdXNNb3VudGVkUmVmLmN1cnJlbnQgPSAhIWVsZW1lbnRzLmZsb2F0aW5nO1xuICB9KTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAga2V5UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgfSwgW29wZW5dKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIHByZXZpb3VzT3BlblJlZi5jdXJyZW50ID0gb3BlbjtcbiAgfSwgW29wZW5dKTtcbiAgY29uc3QgaGFzQWN0aXZlSW5kZXggPSBhY3RpdmVJbmRleCAhPSBudWxsO1xuICBjb25zdCBpdGVtID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgZnVuY3Rpb24gc3luY0N1cnJlbnRUYXJnZXQoY3VycmVudFRhcmdldCkge1xuICAgICAgaWYgKCFvcGVuKSByZXR1cm47XG4gICAgICBjb25zdCBpbmRleCA9IGxpc3RSZWYuY3VycmVudC5pbmRleE9mKGN1cnJlbnRUYXJnZXQpO1xuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICBvbk5hdmlnYXRlKGluZGV4KTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcHJvcHMgPSB7XG4gICAgICBvbkZvY3VzKF9yZWYpIHtcbiAgICAgICAgbGV0IHtcbiAgICAgICAgICBjdXJyZW50VGFyZ2V0XG4gICAgICAgIH0gPSBfcmVmO1xuICAgICAgICBzeW5jQ3VycmVudFRhcmdldChjdXJyZW50VGFyZ2V0KTtcbiAgICAgIH0sXG4gICAgICBvbkNsaWNrOiBfcmVmMiA9PiB7XG4gICAgICAgIGxldCB7XG4gICAgICAgICAgY3VycmVudFRhcmdldFxuICAgICAgICB9ID0gX3JlZjI7XG4gICAgICAgIHJldHVybiBjdXJyZW50VGFyZ2V0LmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIC8vIFNhZmFyaVxuICAgICAgLi4uKGZvY3VzSXRlbU9uSG92ZXIgJiYge1xuICAgICAgICBvbk1vdXNlTW92ZShfcmVmMykge1xuICAgICAgICAgIGxldCB7XG4gICAgICAgICAgICBjdXJyZW50VGFyZ2V0XG4gICAgICAgICAgfSA9IF9yZWYzO1xuICAgICAgICAgIHN5bmNDdXJyZW50VGFyZ2V0KGN1cnJlbnRUYXJnZXQpO1xuICAgICAgICB9LFxuICAgICAgICBvblBvaW50ZXJMZWF2ZShfcmVmNCkge1xuICAgICAgICAgIGxldCB7XG4gICAgICAgICAgICBwb2ludGVyVHlwZVxuICAgICAgICAgIH0gPSBfcmVmNDtcbiAgICAgICAgICBpZiAoIWlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQgfHwgcG9pbnRlclR5cGUgPT09ICd0b3VjaCcpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IC0xO1xuICAgICAgICAgIGZvY3VzSXRlbShsaXN0UmVmLCBpbmRleFJlZik7XG4gICAgICAgICAgb25OYXZpZ2F0ZShudWxsKTtcbiAgICAgICAgICBpZiAoIXZpcnR1YWwpIHtcbiAgICAgICAgICAgIGVucXVldWVGb2N1cyhmbG9hdGluZ0ZvY3VzRWxlbWVudFJlZi5jdXJyZW50LCB7XG4gICAgICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9O1xuICAgIHJldHVybiBwcm9wcztcbiAgfSwgW29wZW4sIGZsb2F0aW5nRm9jdXNFbGVtZW50UmVmLCBmb2N1c0l0ZW0sIGZvY3VzSXRlbU9uSG92ZXIsIGxpc3RSZWYsIG9uTmF2aWdhdGUsIHZpcnR1YWxdKTtcbiAgY29uc3QgY29tbW9uT25LZXlEb3duID0gdXNlRWZmZWN0RXZlbnQoZXZlbnQgPT4ge1xuICAgIGlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICBmb3JjZVN5bmNGb2N1cy5jdXJyZW50ID0gdHJ1ZTtcblxuICAgIC8vIFdoZW4gY29tcG9zaW5nIGEgY2hhcmFjdGVyLCBDaHJvbWUgZmlyZXMgQXJyb3dEb3duIHR3aWNlLiBGaXJlZm94L1NhZmFyaVxuICAgIC8vIGRvbid0IGFwcGVhciB0byBzdWZmZXIgZnJvbSB0aGlzLiBgZXZlbnQuaXNDb21wb3NpbmdgIGlzIGF2b2lkZWQgZHVlIHRvXG4gICAgLy8gU2FmYXJpIG5vdCBzdXBwb3J0aW5nIGl0IHByb3Blcmx5IChhbHRob3VnaCBpdCdzIG5vdCBuZWVkZWQgaW4gdGhlIGZpcnN0XG4gICAgLy8gcGxhY2UgZm9yIFNhZmFyaSwganVzdCBhdm9pZGluZyBhbnkgcG9zc2libGUgaXNzdWVzKS5cbiAgICBpZiAoZXZlbnQud2hpY2ggPT09IDIyOSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIElmIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIGFuaW1hdGluZyBvdXQsIGlnbm9yZSBuYXZpZ2F0aW9uLiBPdGhlcndpc2UsXG4gICAgLy8gdGhlIGBhY3RpdmVJbmRleGAgZ2V0cyBzZXQgdG8gMCBkZXNwaXRlIG5vdCBiZWluZyBvcGVuIHNvIHRoZSBuZXh0IHRpbWVcbiAgICAvLyB0aGUgdXNlciBBcnJvd0Rvd25zLCB0aGUgZmlyc3QgaXRlbSB3b24ndCBiZSBmb2N1c2VkLlxuICAgIGlmICghbGF0ZXN0T3BlblJlZi5jdXJyZW50ICYmIGV2ZW50LmN1cnJlbnRUYXJnZXQgPT09IGZsb2F0aW5nRm9jdXNFbGVtZW50UmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG5lc3RlZCAmJiBpc0Nyb3NzT3JpZW50YXRpb25DbG9zZUtleShldmVudC5rZXksIG9yaWVudGF0aW9uLCBydGwpKSB7XG4gICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgb25PcGVuQ2hhbmdlKGZhbHNlLCBldmVudC5uYXRpdmVFdmVudCwgJ2xpc3QtbmF2aWdhdGlvbicpO1xuICAgICAgaWYgKGlzSFRNTEVsZW1lbnQoZWxlbWVudHMuZG9tUmVmZXJlbmNlKSkge1xuICAgICAgICBpZiAodmlydHVhbCkge1xuICAgICAgICAgIHRyZWUgPT0gbnVsbCB8fCB0cmVlLmV2ZW50cy5lbWl0KCd2aXJ0dWFsZm9jdXMnLCBlbGVtZW50cy5kb21SZWZlcmVuY2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVsZW1lbnRzLmRvbVJlZmVyZW5jZS5mb2N1cygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGN1cnJlbnRJbmRleCA9IGluZGV4UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgbWluSW5kZXggPSBnZXRNaW5JbmRleChsaXN0UmVmLCBkaXNhYmxlZEluZGljZXMpO1xuICAgIGNvbnN0IG1heEluZGV4ID0gZ2V0TWF4SW5kZXgobGlzdFJlZiwgZGlzYWJsZWRJbmRpY2VzKTtcbiAgICBpZiAoIXR5cGVhYmxlQ29tYm9ib3hSZWZlcmVuY2UpIHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdIb21lJykge1xuICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gbWluSW5kZXg7XG4gICAgICAgIG9uTmF2aWdhdGUoaW5kZXhSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnRW5kJykge1xuICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gbWF4SW5kZXg7XG4gICAgICAgIG9uTmF2aWdhdGUoaW5kZXhSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gR3JpZCBuYXZpZ2F0aW9uLlxuICAgIGlmIChjb2xzID4gMSkge1xuICAgICAgY29uc3Qgc2l6ZXMgPSBpdGVtU2l6ZXMgfHwgQXJyYXkuZnJvbSh7XG4gICAgICAgIGxlbmd0aDogbGlzdFJlZi5jdXJyZW50Lmxlbmd0aFxuICAgICAgfSwgKCkgPT4gKHtcbiAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgIGhlaWdodDogMVxuICAgICAgfSkpO1xuICAgICAgLy8gVG8gY2FsY3VsYXRlIG1vdmVtZW50cyBvbiB0aGUgZ3JpZCwgd2UgdXNlIGh5cG90aGV0aWNhbCBjZWxsIGluZGljZXNcbiAgICAgIC8vIGFzIGlmIGV2ZXJ5IGl0ZW0gd2FzIDF4MSwgdGhlbiBjb252ZXJ0IGJhY2sgdG8gcmVhbCBpbmRpY2VzLlxuICAgICAgY29uc3QgY2VsbE1hcCA9IGJ1aWxkQ2VsbE1hcChzaXplcywgY29scywgZGVuc2UpO1xuICAgICAgY29uc3QgbWluR3JpZEluZGV4ID0gY2VsbE1hcC5maW5kSW5kZXgoaW5kZXggPT4gaW5kZXggIT0gbnVsbCAmJiAhaXNEaXNhYmxlZChsaXN0UmVmLmN1cnJlbnQsIGluZGV4LCBkaXNhYmxlZEluZGljZXMpKTtcbiAgICAgIC8vIGxhc3QgZW5hYmxlZCBpbmRleFxuICAgICAgY29uc3QgbWF4R3JpZEluZGV4ID0gY2VsbE1hcC5yZWR1Y2UoKGZvdW5kSW5kZXgsIGluZGV4LCBjZWxsSW5kZXgpID0+IGluZGV4ICE9IG51bGwgJiYgIWlzRGlzYWJsZWQobGlzdFJlZi5jdXJyZW50LCBpbmRleCwgZGlzYWJsZWRJbmRpY2VzKSA/IGNlbGxJbmRleCA6IGZvdW5kSW5kZXgsIC0xKTtcbiAgICAgIGNvbnN0IGluZGV4ID0gY2VsbE1hcFtnZXRHcmlkTmF2aWdhdGVkSW5kZXgoe1xuICAgICAgICBjdXJyZW50OiBjZWxsTWFwLm1hcChpdGVtSW5kZXggPT4gaXRlbUluZGV4ICE9IG51bGwgPyBsaXN0UmVmLmN1cnJlbnRbaXRlbUluZGV4XSA6IG51bGwpXG4gICAgICB9LCB7XG4gICAgICAgIGV2ZW50LFxuICAgICAgICBvcmllbnRhdGlvbixcbiAgICAgICAgbG9vcCxcbiAgICAgICAgcnRsLFxuICAgICAgICBjb2xzLFxuICAgICAgICAvLyB0cmVhdCB1bmRlZmluZWQgKGVtcHR5IGdyaWQgc3BhY2VzKSBhcyBkaXNhYmxlZCBpbmRpY2VzIHNvIHdlXG4gICAgICAgIC8vIGRvbid0IGVuZCB1cCBpbiB0aGVtXG4gICAgICAgIGRpc2FibGVkSW5kaWNlczogZ2V0Q2VsbEluZGljZXMoWy4uLihkaXNhYmxlZEluZGljZXMgfHwgbGlzdFJlZi5jdXJyZW50Lm1hcCgoXywgaW5kZXgpID0+IGlzRGlzYWJsZWQobGlzdFJlZi5jdXJyZW50LCBpbmRleCkgPyBpbmRleCA6IHVuZGVmaW5lZCkpLCB1bmRlZmluZWRdLCBjZWxsTWFwKSxcbiAgICAgICAgbWluSW5kZXg6IG1pbkdyaWRJbmRleCxcbiAgICAgICAgbWF4SW5kZXg6IG1heEdyaWRJbmRleCxcbiAgICAgICAgcHJldkluZGV4OiBnZXRDZWxsSW5kZXhPZkNvcm5lcihpbmRleFJlZi5jdXJyZW50ID4gbWF4SW5kZXggPyBtaW5JbmRleCA6IGluZGV4UmVmLmN1cnJlbnQsIHNpemVzLCBjZWxsTWFwLCBjb2xzLFxuICAgICAgICAvLyB1c2UgYSBjb3JuZXIgbWF0Y2hpbmcgdGhlIGVkZ2UgY2xvc2VzdCB0byB0aGUgZGlyZWN0aW9uXG4gICAgICAgIC8vIHdlJ3JlIG1vdmluZyBpbiBzbyB3ZSBkb24ndCBlbmQgdXAgaW4gdGhlIHNhbWUgaXRlbS4gUHJlZmVyXG4gICAgICAgIC8vIHRvcC9sZWZ0IG92ZXIgYm90dG9tL3JpZ2h0LlxuICAgICAgICBldmVudC5rZXkgPT09IEFSUk9XX0RPV04gPyAnYmwnIDogZXZlbnQua2V5ID09PSAocnRsID8gQVJST1dfTEVGVCA6IEFSUk9XX1JJR0hUKSA/ICd0cicgOiAndGwnKSxcbiAgICAgICAgc3RvcEV2ZW50OiB0cnVlXG4gICAgICB9KV07XG4gICAgICBpZiAoaW5kZXggIT0gbnVsbCkge1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gaW5kZXg7XG4gICAgICAgIG9uTmF2aWdhdGUoaW5kZXhSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgICBpZiAob3JpZW50YXRpb24gPT09ICdib3RoJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIG9yaWVudGF0aW9uKSkge1xuICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcblxuICAgICAgLy8gUmVzZXQgdGhlIGluZGV4IGlmIG5vIGl0ZW0gaXMgZm9jdXNlZC5cbiAgICAgIGlmIChvcGVuICYmICF2aXJ0dWFsICYmIGFjdGl2ZUVsZW1lbnQoZXZlbnQuY3VycmVudFRhcmdldC5vd25lckRvY3VtZW50KSA9PT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gaXNNYWluT3JpZW50YXRpb25Ub0VuZEtleShldmVudC5rZXksIG9yaWVudGF0aW9uLCBydGwpID8gbWluSW5kZXggOiBtYXhJbmRleDtcbiAgICAgICAgb25OYXZpZ2F0ZShpbmRleFJlZi5jdXJyZW50KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzTWFpbk9yaWVudGF0aW9uVG9FbmRLZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbiwgcnRsKSkge1xuICAgICAgICBpZiAobG9vcCkge1xuICAgICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBjdXJyZW50SW5kZXggPj0gbWF4SW5kZXggPyBhbGxvd0VzY2FwZSAmJiBjdXJyZW50SW5kZXggIT09IGxpc3RSZWYuY3VycmVudC5sZW5ndGggPyAtMSA6IG1pbkluZGV4IDogZmluZE5vbkRpc2FibGVkSW5kZXgobGlzdFJlZiwge1xuICAgICAgICAgICAgc3RhcnRpbmdJbmRleDogY3VycmVudEluZGV4LFxuICAgICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IE1hdGgubWluKG1heEluZGV4LCBmaW5kTm9uRGlzYWJsZWRJbmRleChsaXN0UmVmLCB7XG4gICAgICAgICAgICBzdGFydGluZ0luZGV4OiBjdXJyZW50SW5kZXgsXG4gICAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChsb29wKSB7XG4gICAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IGN1cnJlbnRJbmRleCA8PSBtaW5JbmRleCA/IGFsbG93RXNjYXBlICYmIGN1cnJlbnRJbmRleCAhPT0gLTEgPyBsaXN0UmVmLmN1cnJlbnQubGVuZ3RoIDogbWF4SW5kZXggOiBmaW5kTm9uRGlzYWJsZWRJbmRleChsaXN0UmVmLCB7XG4gICAgICAgICAgICBzdGFydGluZ0luZGV4OiBjdXJyZW50SW5kZXgsXG4gICAgICAgICAgICBkZWNyZW1lbnQ6IHRydWUsXG4gICAgICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gTWF0aC5tYXgobWluSW5kZXgsIGZpbmROb25EaXNhYmxlZEluZGV4KGxpc3RSZWYsIHtcbiAgICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IGN1cnJlbnRJbmRleCxcbiAgICAgICAgICAgIGRlY3JlbWVudDogdHJ1ZSxcbiAgICAgICAgICAgIGRpc2FibGVkSW5kaWNlc1xuICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlzSW5kZXhPdXRPZkJvdW5kcyhsaXN0UmVmLCBpbmRleFJlZi5jdXJyZW50KSkge1xuICAgICAgICBvbk5hdmlnYXRlKG51bGwpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb25OYXZpZ2F0ZShpbmRleFJlZi5jdXJyZW50KTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjb25zdCBhcmlhQWN0aXZlRGVzY2VuZGFudFByb3AgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gdmlydHVhbCAmJiBvcGVuICYmIGhhc0FjdGl2ZUluZGV4ICYmIHtcbiAgICAgICdhcmlhLWFjdGl2ZWRlc2NlbmRhbnQnOiB2aXJ0dWFsSWQgfHwgYWN0aXZlSWRcbiAgICB9O1xuICB9LCBbdmlydHVhbCwgb3BlbiwgaGFzQWN0aXZlSW5kZXgsIHZpcnR1YWxJZCwgYWN0aXZlSWRdKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgJ2FyaWEtb3JpZW50YXRpb24nOiBvcmllbnRhdGlvbiA9PT0gJ2JvdGgnID8gdW5kZWZpbmVkIDogb3JpZW50YXRpb24sXG4gICAgICAuLi4oIWlzVHlwZWFibGVDb21ib2JveChlbGVtZW50cy5kb21SZWZlcmVuY2UpICYmIGFyaWFBY3RpdmVEZXNjZW5kYW50UHJvcCksXG4gICAgICBvbktleURvd246IGNvbW1vbk9uS2V5RG93bixcbiAgICAgIG9uUG9pbnRlck1vdmUoKSB7XG4gICAgICAgIGlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFthcmlhQWN0aXZlRGVzY2VuZGFudFByb3AsIGNvbW1vbk9uS2V5RG93biwgZWxlbWVudHMuZG9tUmVmZXJlbmNlLCBvcmllbnRhdGlvbl0pO1xuICBjb25zdCByZWZlcmVuY2UgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBmdW5jdGlvbiBjaGVja1ZpcnR1YWxNb3VzZShldmVudCkge1xuICAgICAgaWYgKGZvY3VzSXRlbU9uT3BlbiA9PT0gJ2F1dG8nICYmIGlzVmlydHVhbENsaWNrKGV2ZW50Lm5hdGl2ZUV2ZW50KSkge1xuICAgICAgICBmb2N1c0l0ZW1Pbk9wZW5SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNoZWNrVmlydHVhbFBvaW50ZXIoZXZlbnQpIHtcbiAgICAgIC8vIGBwb2ludGVyZG93bmAgZmlyZXMgZmlyc3QsIHJlc2V0IHRoZSBzdGF0ZSB0aGVuIHBlcmZvcm0gdGhlIGNoZWNrcy5cbiAgICAgIGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ID0gZm9jdXNJdGVtT25PcGVuO1xuICAgICAgaWYgKGZvY3VzSXRlbU9uT3BlbiA9PT0gJ2F1dG8nICYmIGlzVmlydHVhbFBvaW50ZXJFdmVudChldmVudC5uYXRpdmVFdmVudCkpIHtcbiAgICAgICAgZm9jdXNJdGVtT25PcGVuUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgLi4uYXJpYUFjdGl2ZURlc2NlbmRhbnRQcm9wLFxuICAgICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICAgIGlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgY29uc3QgaXNBcnJvd0tleSA9IGV2ZW50LmtleS5zdGFydHNXaXRoKCdBcnJvdycpO1xuICAgICAgICBjb25zdCBpc0hvbWVPckVuZEtleSA9IFsnSG9tZScsICdFbmQnXS5pbmNsdWRlcyhldmVudC5rZXkpO1xuICAgICAgICBjb25zdCBpc01vdmVLZXkgPSBpc0Fycm93S2V5IHx8IGlzSG9tZU9yRW5kS2V5O1xuICAgICAgICBjb25zdCBpc0Nyb3NzT3BlbktleSA9IGlzQ3Jvc3NPcmllbnRhdGlvbk9wZW5LZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbiwgcnRsKTtcbiAgICAgICAgY29uc3QgaXNDcm9zc0Nsb3NlS2V5ID0gaXNDcm9zc09yaWVudGF0aW9uQ2xvc2VLZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbiwgcnRsKTtcbiAgICAgICAgY29uc3QgaXNNYWluS2V5ID0gaXNNYWluT3JpZW50YXRpb25LZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbik7XG4gICAgICAgIGNvbnN0IGlzTmF2aWdhdGlvbktleSA9IChuZXN0ZWQgPyBpc0Nyb3NzT3BlbktleSA6IGlzTWFpbktleSkgfHwgZXZlbnQua2V5ID09PSAnRW50ZXInIHx8IGV2ZW50LmtleS50cmltKCkgPT09ICcnO1xuICAgICAgICBpZiAodmlydHVhbCAmJiBvcGVuKSB7XG4gICAgICAgICAgY29uc3Qgcm9vdE5vZGUgPSB0cmVlID09IG51bGwgPyB2b2lkIDAgOiB0cmVlLm5vZGVzUmVmLmN1cnJlbnQuZmluZChub2RlID0+IG5vZGUucGFyZW50SWQgPT0gbnVsbCk7XG4gICAgICAgICAgY29uc3QgZGVlcGVzdE5vZGUgPSB0cmVlICYmIHJvb3ROb2RlID8gZ2V0RGVlcGVzdE5vZGUodHJlZS5ub2Rlc1JlZi5jdXJyZW50LCByb290Tm9kZS5pZCkgOiBudWxsO1xuICAgICAgICAgIGlmIChpc01vdmVLZXkgJiYgZGVlcGVzdE5vZGUgJiYgdmlydHVhbEl0ZW1SZWYpIHtcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50T2JqZWN0ID0gbmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCB7XG4gICAgICAgICAgICAgIGtleTogZXZlbnQua2V5LFxuICAgICAgICAgICAgICBidWJibGVzOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChpc0Nyb3NzT3BlbktleSB8fCBpc0Nyb3NzQ2xvc2VLZXkpIHtcbiAgICAgICAgICAgICAgdmFyIF9kZWVwZXN0Tm9kZSRjb250ZXh0LCBfZGVlcGVzdE5vZGUkY29udGV4dDI7XG4gICAgICAgICAgICAgIGNvbnN0IGlzQ3VycmVudFRhcmdldCA9ICgoX2RlZXBlc3ROb2RlJGNvbnRleHQgPSBkZWVwZXN0Tm9kZS5jb250ZXh0KSA9PSBudWxsID8gdm9pZCAwIDogX2RlZXBlc3ROb2RlJGNvbnRleHQuZWxlbWVudHMuZG9tUmVmZXJlbmNlKSA9PT0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgICAgICAgY29uc3QgZGlzcGF0Y2hJdGVtID0gaXNDcm9zc0Nsb3NlS2V5ICYmICFpc0N1cnJlbnRUYXJnZXQgPyAoX2RlZXBlc3ROb2RlJGNvbnRleHQyID0gZGVlcGVzdE5vZGUuY29udGV4dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9kZWVwZXN0Tm9kZSRjb250ZXh0Mi5lbGVtZW50cy5kb21SZWZlcmVuY2UgOiBpc0Nyb3NzT3BlbktleSA/IGxpc3RSZWYuY3VycmVudC5maW5kKGl0ZW0gPT4gKGl0ZW0gPT0gbnVsbCA/IHZvaWQgMCA6IGl0ZW0uaWQpID09PSBhY3RpdmVJZCkgOiBudWxsO1xuICAgICAgICAgICAgICBpZiAoZGlzcGF0Y2hJdGVtKSB7XG4gICAgICAgICAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgICAgICAgICAgICBkaXNwYXRjaEl0ZW0uZGlzcGF0Y2hFdmVudChldmVudE9iamVjdCk7XG4gICAgICAgICAgICAgICAgc2V0VmlydHVhbElkKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICgoaXNNYWluS2V5IHx8IGlzSG9tZU9yRW5kS2V5KSAmJiBkZWVwZXN0Tm9kZS5jb250ZXh0KSB7XG4gICAgICAgICAgICAgIGlmIChkZWVwZXN0Tm9kZS5jb250ZXh0Lm9wZW4gJiYgZGVlcGVzdE5vZGUucGFyZW50SWQgJiYgZXZlbnQuY3VycmVudFRhcmdldCAhPT0gZGVlcGVzdE5vZGUuY29udGV4dC5lbGVtZW50cy5kb21SZWZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICB2YXIgX2RlZXBlc3ROb2RlJGNvbnRleHQkO1xuICAgICAgICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgICAgICAgICAgKF9kZWVwZXN0Tm9kZSRjb250ZXh0JCA9IGRlZXBlc3ROb2RlLmNvbnRleHQuZWxlbWVudHMuZG9tUmVmZXJlbmNlKSA9PSBudWxsIHx8IF9kZWVwZXN0Tm9kZSRjb250ZXh0JC5kaXNwYXRjaEV2ZW50KGV2ZW50T2JqZWN0KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGNvbW1vbk9uS2V5RG93bihldmVudCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZiBhIGZsb2F0aW5nIGVsZW1lbnQgc2hvdWxkIG5vdCBvcGVuIG9uIGFycm93IGtleSBkb3duLCBhdm9pZFxuICAgICAgICAvLyBzZXR0aW5nIGBhY3RpdmVJbmRleGAgd2hpbGUgaXQncyBjbG9zZWQuXG4gICAgICAgIGlmICghb3BlbiAmJiAhb3Blbk9uQXJyb3dLZXlEb3duICYmIGlzQXJyb3dLZXkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzTmF2aWdhdGlvbktleSkge1xuICAgICAgICAgIGtleVJlZi5jdXJyZW50ID0gbmVzdGVkICYmIGlzTWFpbktleSA/IG51bGwgOiBldmVudC5rZXk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5lc3RlZCkge1xuICAgICAgICAgIGlmIChpc0Nyb3NzT3BlbktleSkge1xuICAgICAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgICAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBnZXRNaW5JbmRleChsaXN0UmVmLCBkaXNhYmxlZEluZGljZXNSZWYuY3VycmVudCk7XG4gICAgICAgICAgICAgIG9uTmF2aWdhdGUoaW5kZXhSZWYuY3VycmVudCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBvbk9wZW5DaGFuZ2UodHJ1ZSwgZXZlbnQubmF0aXZlRXZlbnQsICdsaXN0LW5hdmlnYXRpb24nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc01haW5LZXkpIHtcbiAgICAgICAgICBpZiAoc2VsZWN0ZWRJbmRleCAhPSBudWxsKSB7XG4gICAgICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gc2VsZWN0ZWRJbmRleDtcbiAgICAgICAgICB9XG4gICAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgICAgICBpZiAoIW9wZW4gJiYgb3Blbk9uQXJyb3dLZXlEb3duKSB7XG4gICAgICAgICAgICBvbk9wZW5DaGFuZ2UodHJ1ZSwgZXZlbnQubmF0aXZlRXZlbnQsICdsaXN0LW5hdmlnYXRpb24nKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29tbW9uT25LZXlEb3duKGV2ZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgICAgIG9uTmF2aWdhdGUoaW5kZXhSZWYuY3VycmVudCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25Gb2N1cygpIHtcbiAgICAgICAgaWYgKG9wZW4gJiYgIXZpcnR1YWwpIHtcbiAgICAgICAgICBvbk5hdmlnYXRlKG51bGwpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25Qb2ludGVyRG93bjogY2hlY2tWaXJ0dWFsUG9pbnRlcixcbiAgICAgIG9uTW91c2VEb3duOiBjaGVja1ZpcnR1YWxNb3VzZSxcbiAgICAgIG9uQ2xpY2s6IGNoZWNrVmlydHVhbE1vdXNlXG4gICAgfTtcbiAgfSwgW2FjdGl2ZUlkLCBhcmlhQWN0aXZlRGVzY2VuZGFudFByb3AsIGNvbW1vbk9uS2V5RG93biwgZGlzYWJsZWRJbmRpY2VzUmVmLCBmb2N1c0l0ZW1Pbk9wZW4sIGxpc3RSZWYsIG5lc3RlZCwgb25OYXZpZ2F0ZSwgb25PcGVuQ2hhbmdlLCBvcGVuLCBvcGVuT25BcnJvd0tleURvd24sIG9yaWVudGF0aW9uLCBydGwsIHNlbGVjdGVkSW5kZXgsIHRyZWUsIHZpcnR1YWwsIHZpcnR1YWxJdGVtUmVmXSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlLFxuICAgIGZsb2F0aW5nLFxuICAgIGl0ZW1cbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlLCBmbG9hdGluZywgaXRlbV0pO1xufVxuXG5jb25zdCBjb21wb25lbnRSb2xlVG9BcmlhUm9sZU1hcCA9IC8qI19fUFVSRV9fKi9uZXcgTWFwKFtbJ3NlbGVjdCcsICdsaXN0Ym94J10sIFsnY29tYm9ib3gnLCAnbGlzdGJveCddLCBbJ2xhYmVsJywgZmFsc2VdXSk7XG5cbi8qKlxuICogQWRkcyBiYXNlIHNjcmVlbiByZWFkZXIgcHJvcHMgdG8gdGhlIHJlZmVyZW5jZSBhbmQgZmxvYXRpbmcgZWxlbWVudHMgZm9yIGFcbiAqIGdpdmVuIGZsb2F0aW5nIGVsZW1lbnQgYHJvbGVgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3VzZVJvbGVcbiAqL1xuZnVuY3Rpb24gdXNlUm9sZShjb250ZXh0LCBwcm9wcykge1xuICB2YXIgX2NvbXBvbmVudFJvbGVUb0FyaWFSO1xuICBpZiAocHJvcHMgPT09IHZvaWQgMCkge1xuICAgIHByb3BzID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgZmxvYXRpbmdJZFxuICB9ID0gY29udGV4dDtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIHJvbGUgPSAnZGlhbG9nJ1xuICB9ID0gcHJvcHM7XG4gIGNvbnN0IGFyaWFSb2xlID0gKF9jb21wb25lbnRSb2xlVG9BcmlhUiA9IGNvbXBvbmVudFJvbGVUb0FyaWFSb2xlTWFwLmdldChyb2xlKSkgIT0gbnVsbCA/IF9jb21wb25lbnRSb2xlVG9BcmlhUiA6IHJvbGU7XG4gIGNvbnN0IHJlZmVyZW5jZUlkID0gdXNlSWQoKTtcbiAgY29uc3QgcGFyZW50SWQgPSB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCgpO1xuICBjb25zdCBpc05lc3RlZCA9IHBhcmVudElkICE9IG51bGw7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChhcmlhUm9sZSA9PT0gJ3Rvb2x0aXAnIHx8IHJvbGUgPT09ICdsYWJlbCcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIFtcImFyaWEtXCIgKyAocm9sZSA9PT0gJ2xhYmVsJyA/ICdsYWJlbGxlZGJ5JyA6ICdkZXNjcmliZWRieScpXTogb3BlbiA/IGZsb2F0aW5nSWQgOiB1bmRlZmluZWRcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAnYXJpYS1leHBhbmRlZCc6IG9wZW4gPyAndHJ1ZScgOiAnZmFsc2UnLFxuICAgICAgJ2FyaWEtaGFzcG9wdXAnOiBhcmlhUm9sZSA9PT0gJ2FsZXJ0ZGlhbG9nJyA/ICdkaWFsb2cnIDogYXJpYVJvbGUsXG4gICAgICAnYXJpYS1jb250cm9scyc6IG9wZW4gPyBmbG9hdGluZ0lkIDogdW5kZWZpbmVkLFxuICAgICAgLi4uKGFyaWFSb2xlID09PSAnbGlzdGJveCcgJiYge1xuICAgICAgICByb2xlOiAnY29tYm9ib3gnXG4gICAgICB9KSxcbiAgICAgIC4uLihhcmlhUm9sZSA9PT0gJ21lbnUnICYmIHtcbiAgICAgICAgaWQ6IHJlZmVyZW5jZUlkXG4gICAgICB9KSxcbiAgICAgIC4uLihhcmlhUm9sZSA9PT0gJ21lbnUnICYmIGlzTmVzdGVkICYmIHtcbiAgICAgICAgcm9sZTogJ21lbnVpdGVtJ1xuICAgICAgfSksXG4gICAgICAuLi4ocm9sZSA9PT0gJ3NlbGVjdCcgJiYge1xuICAgICAgICAnYXJpYS1hdXRvY29tcGxldGUnOiAnbm9uZSdcbiAgICAgIH0pLFxuICAgICAgLi4uKHJvbGUgPT09ICdjb21ib2JveCcgJiYge1xuICAgICAgICAnYXJpYS1hdXRvY29tcGxldGUnOiAnbGlzdCdcbiAgICAgIH0pXG4gICAgfTtcbiAgfSwgW2FyaWFSb2xlLCBmbG9hdGluZ0lkLCBpc05lc3RlZCwgb3BlbiwgcmVmZXJlbmNlSWQsIHJvbGVdKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBmbG9hdGluZ1Byb3BzID0ge1xuICAgICAgaWQ6IGZsb2F0aW5nSWQsXG4gICAgICAuLi4oYXJpYVJvbGUgJiYge1xuICAgICAgICByb2xlOiBhcmlhUm9sZVxuICAgICAgfSlcbiAgICB9O1xuICAgIGlmIChhcmlhUm9sZSA9PT0gJ3Rvb2x0aXAnIHx8IHJvbGUgPT09ICdsYWJlbCcpIHtcbiAgICAgIHJldHVybiBmbG9hdGluZ1Byb3BzO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgLi4uZmxvYXRpbmdQcm9wcyxcbiAgICAgIC4uLihhcmlhUm9sZSA9PT0gJ21lbnUnICYmIHtcbiAgICAgICAgJ2FyaWEtbGFiZWxsZWRieSc6IHJlZmVyZW5jZUlkXG4gICAgICB9KVxuICAgIH07XG4gIH0sIFthcmlhUm9sZSwgZmxvYXRpbmdJZCwgcmVmZXJlbmNlSWQsIHJvbGVdKTtcbiAgY29uc3QgaXRlbSA9IFJlYWN0LnVzZUNhbGxiYWNrKF9yZWYgPT4ge1xuICAgIGxldCB7XG4gICAgICBhY3RpdmUsXG4gICAgICBzZWxlY3RlZFxuICAgIH0gPSBfcmVmO1xuICAgIGNvbnN0IGNvbW1vblByb3BzID0ge1xuICAgICAgcm9sZTogJ29wdGlvbicsXG4gICAgICAuLi4oYWN0aXZlICYmIHtcbiAgICAgICAgaWQ6IGZsb2F0aW5nSWQgKyBcIi1vcHRpb25cIlxuICAgICAgfSlcbiAgICB9O1xuXG4gICAgLy8gRm9yIGBtZW51YCwgd2UgYXJlIHVuYWJsZSB0byB0ZWxsIGlmIHRoZSBpdGVtIGlzIGEgYG1lbnVpdGVtcmFkaW9gXG4gICAgLy8gb3IgYG1lbnVpdGVtY2hlY2tib3hgLiBGb3IgYmFja3dhcmRzLWNvbXBhdGliaWxpdHkgcmVhc29ucywgYWxzb1xuICAgIC8vIGF2b2lkIGRlZmF1bHRpbmcgdG8gYG1lbnVpdGVtYCBhcyBpdCBtYXkgb3ZlcndyaXRlIGN1c3RvbSByb2xlIHByb3BzLlxuICAgIHN3aXRjaCAocm9sZSkge1xuICAgICAgY2FzZSAnc2VsZWN0JzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5jb21tb25Qcm9wcyxcbiAgICAgICAgICAnYXJpYS1zZWxlY3RlZCc6IGFjdGl2ZSAmJiBzZWxlY3RlZFxuICAgICAgICB9O1xuICAgICAgY2FzZSAnY29tYm9ib3gnOlxuICAgICAgICB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmNvbW1vblByb3BzLFxuICAgICAgICAgICAgLi4uKGFjdGl2ZSAmJiB7XG4gICAgICAgICAgICAgICdhcmlhLXNlbGVjdGVkJzogdHJ1ZVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7fTtcbiAgfSwgW2Zsb2F0aW5nSWQsIHJvbGVdKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZW5hYmxlZCA/IHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmcsXG4gICAgaXRlbVxuICB9IDoge30sIFtlbmFibGVkLCByZWZlcmVuY2UsIGZsb2F0aW5nLCBpdGVtXSk7XG59XG5cbi8vIENvbnZlcnRzIGEgSlMgc3R5bGUga2V5IGxpa2UgYGJhY2tncm91bmRDb2xvcmAgdG8gYSBDU1MgdHJhbnNpdGlvbi1wcm9wZXJ0eVxuLy8gbGlrZSBgYmFja2dyb3VuZC1jb2xvcmAuXG5jb25zdCBjYW1lbENhc2VUb0tlYmFiQ2FzZSA9IHN0ciA9PiBzdHIucmVwbGFjZSgvW0EtWl0rKD8hW2Etel0pfFtBLVpdL2csICgkLCBvZnMpID0+IChvZnMgPyAnLScgOiAnJykgKyAkLnRvTG93ZXJDYXNlKCkpO1xuZnVuY3Rpb24gZXhlY1dpdGhBcmdzT3JSZXR1cm4odmFsdWVPckZuLCBhcmdzKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWVPckZuID09PSAnZnVuY3Rpb24nID8gdmFsdWVPckZuKGFyZ3MpIDogdmFsdWVPckZuO1xufVxuZnVuY3Rpb24gdXNlRGVsYXlVbm1vdW50KG9wZW4sIGR1cmF0aW9uTXMpIHtcbiAgY29uc3QgW2lzTW91bnRlZCwgc2V0SXNNb3VudGVkXSA9IFJlYWN0LnVzZVN0YXRlKG9wZW4pO1xuICBpZiAob3BlbiAmJiAhaXNNb3VudGVkKSB7XG4gICAgc2V0SXNNb3VudGVkKHRydWUpO1xuICB9XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuICYmIGlzTW91bnRlZCkge1xuICAgICAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4gc2V0SXNNb3VudGVkKGZhbHNlKSwgZHVyYXRpb25Ncyk7XG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgIH1cbiAgfSwgW29wZW4sIGlzTW91bnRlZCwgZHVyYXRpb25Nc10pO1xuICByZXR1cm4gaXNNb3VudGVkO1xufVxuLyoqXG4gKiBQcm92aWRlcyBhIHN0YXR1cyBzdHJpbmcgdG8gYXBwbHkgQ1NTIHRyYW5zaXRpb25zIHRvIGEgZmxvYXRpbmcgZWxlbWVudCxcbiAqIGNvcnJlY3RseSBoYW5kbGluZyBwbGFjZW1lbnQtYXdhcmUgdHJhbnNpdGlvbnMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlVHJhbnNpdGlvbiN1c2V0cmFuc2l0aW9uc3RhdHVzXG4gKi9cbmZ1bmN0aW9uIHVzZVRyYW5zaXRpb25TdGF0dXMoY29udGV4dCwgcHJvcHMpIHtcbiAgaWYgKHByb3BzID09PSB2b2lkIDApIHtcbiAgICBwcm9wcyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBvcGVuLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICBmbG9hdGluZ1xuICAgIH1cbiAgfSA9IGNvbnRleHQ7XG4gIGNvbnN0IHtcbiAgICBkdXJhdGlvbiA9IDI1MFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IGlzTnVtYmVyRHVyYXRpb24gPSB0eXBlb2YgZHVyYXRpb24gPT09ICdudW1iZXInO1xuICBjb25zdCBjbG9zZUR1cmF0aW9uID0gKGlzTnVtYmVyRHVyYXRpb24gPyBkdXJhdGlvbiA6IGR1cmF0aW9uLmNsb3NlKSB8fCAwO1xuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gUmVhY3QudXNlU3RhdGUoJ3VubW91bnRlZCcpO1xuICBjb25zdCBpc01vdW50ZWQgPSB1c2VEZWxheVVubW91bnQob3BlbiwgY2xvc2VEdXJhdGlvbik7XG4gIGlmICghaXNNb3VudGVkICYmIHN0YXR1cyA9PT0gJ2Nsb3NlJykge1xuICAgIHNldFN0YXR1cygndW5tb3VudGVkJyk7XG4gIH1cbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmICghZmxvYXRpbmcpIHJldHVybjtcbiAgICBpZiAob3Blbikge1xuICAgICAgc2V0U3RhdHVzKCdpbml0aWFsJyk7XG4gICAgICBjb25zdCBmcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgIHNldFN0YXR1cygnb3BlbicpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZSk7XG4gICAgICB9O1xuICAgIH1cbiAgICBzZXRTdGF0dXMoJ2Nsb3NlJyk7XG4gIH0sIFtvcGVuLCBmbG9hdGluZ10pO1xuICByZXR1cm4ge1xuICAgIGlzTW91bnRlZCxcbiAgICBzdGF0dXNcbiAgfTtcbn1cbi8qKlxuICogUHJvdmlkZXMgc3R5bGVzIHRvIGFwcGx5IENTUyB0cmFuc2l0aW9ucyB0byBhIGZsb2F0aW5nIGVsZW1lbnQsIGNvcnJlY3RseVxuICogaGFuZGxpbmcgcGxhY2VtZW50LWF3YXJlIHRyYW5zaXRpb25zLiBXcmFwcGVyIGFyb3VuZCBgdXNlVHJhbnNpdGlvblN0YXR1c2AuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlVHJhbnNpdGlvbiN1c2V0cmFuc2l0aW9uc3R5bGVzXG4gKi9cbmZ1bmN0aW9uIHVzZVRyYW5zaXRpb25TdHlsZXMoY29udGV4dCwgcHJvcHMpIHtcbiAgaWYgKHByb3BzID09PSB2b2lkIDApIHtcbiAgICBwcm9wcyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBpbml0aWFsOiB1bnN0YWJsZV9pbml0aWFsID0ge1xuICAgICAgb3BhY2l0eTogMFxuICAgIH0sXG4gICAgb3BlbjogdW5zdGFibGVfb3BlbixcbiAgICBjbG9zZTogdW5zdGFibGVfY2xvc2UsXG4gICAgY29tbW9uOiB1bnN0YWJsZV9jb21tb24sXG4gICAgZHVyYXRpb24gPSAyNTBcbiAgfSA9IHByb3BzO1xuICBjb25zdCBwbGFjZW1lbnQgPSBjb250ZXh0LnBsYWNlbWVudDtcbiAgY29uc3Qgc2lkZSA9IHBsYWNlbWVudC5zcGxpdCgnLScpWzBdO1xuICBjb25zdCBmbkFyZ3MgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgc2lkZSxcbiAgICBwbGFjZW1lbnRcbiAgfSksIFtzaWRlLCBwbGFjZW1lbnRdKTtcbiAgY29uc3QgaXNOdW1iZXJEdXJhdGlvbiA9IHR5cGVvZiBkdXJhdGlvbiA9PT0gJ251bWJlcic7XG4gIGNvbnN0IG9wZW5EdXJhdGlvbiA9IChpc051bWJlckR1cmF0aW9uID8gZHVyYXRpb24gOiBkdXJhdGlvbi5vcGVuKSB8fCAwO1xuICBjb25zdCBjbG9zZUR1cmF0aW9uID0gKGlzTnVtYmVyRHVyYXRpb24gPyBkdXJhdGlvbiA6IGR1cmF0aW9uLmNsb3NlKSB8fCAwO1xuICBjb25zdCBbc3R5bGVzLCBzZXRTdHlsZXNdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gKHtcbiAgICAuLi5leGVjV2l0aEFyZ3NPclJldHVybih1bnN0YWJsZV9jb21tb24sIGZuQXJncyksXG4gICAgLi4uZXhlY1dpdGhBcmdzT3JSZXR1cm4odW5zdGFibGVfaW5pdGlhbCwgZm5BcmdzKVxuICB9KSk7XG4gIGNvbnN0IHtcbiAgICBpc01vdW50ZWQsXG4gICAgc3RhdHVzXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKGNvbnRleHQsIHtcbiAgICBkdXJhdGlvblxuICB9KTtcbiAgY29uc3QgaW5pdGlhbFJlZiA9IHVzZUxhdGVzdFJlZih1bnN0YWJsZV9pbml0aWFsKTtcbiAgY29uc3Qgb3BlblJlZiA9IHVzZUxhdGVzdFJlZih1bnN0YWJsZV9vcGVuKTtcbiAgY29uc3QgY2xvc2VSZWYgPSB1c2VMYXRlc3RSZWYodW5zdGFibGVfY2xvc2UpO1xuICBjb25zdCBjb21tb25SZWYgPSB1c2VMYXRlc3RSZWYodW5zdGFibGVfY29tbW9uKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGNvbnN0IGluaXRpYWxTdHlsZXMgPSBleGVjV2l0aEFyZ3NPclJldHVybihpbml0aWFsUmVmLmN1cnJlbnQsIGZuQXJncyk7XG4gICAgY29uc3QgY2xvc2VTdHlsZXMgPSBleGVjV2l0aEFyZ3NPclJldHVybihjbG9zZVJlZi5jdXJyZW50LCBmbkFyZ3MpO1xuICAgIGNvbnN0IGNvbW1vblN0eWxlcyA9IGV4ZWNXaXRoQXJnc09yUmV0dXJuKGNvbW1vblJlZi5jdXJyZW50LCBmbkFyZ3MpO1xuICAgIGNvbnN0IG9wZW5TdHlsZXMgPSBleGVjV2l0aEFyZ3NPclJldHVybihvcGVuUmVmLmN1cnJlbnQsIGZuQXJncykgfHwgT2JqZWN0LmtleXMoaW5pdGlhbFN0eWxlcykucmVkdWNlKChhY2MsIGtleSkgPT4ge1xuICAgICAgYWNjW2tleV0gPSAnJztcbiAgICAgIHJldHVybiBhY2M7XG4gICAgfSwge30pO1xuICAgIGlmIChzdGF0dXMgPT09ICdpbml0aWFsJykge1xuICAgICAgc2V0U3R5bGVzKHN0eWxlcyA9PiAoe1xuICAgICAgICB0cmFuc2l0aW9uUHJvcGVydHk6IHN0eWxlcy50cmFuc2l0aW9uUHJvcGVydHksXG4gICAgICAgIC4uLmNvbW1vblN0eWxlcyxcbiAgICAgICAgLi4uaW5pdGlhbFN0eWxlc1xuICAgICAgfSkpO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzID09PSAnb3BlbicpIHtcbiAgICAgIHNldFN0eWxlcyh7XG4gICAgICAgIHRyYW5zaXRpb25Qcm9wZXJ0eTogT2JqZWN0LmtleXMob3BlblN0eWxlcykubWFwKGNhbWVsQ2FzZVRvS2ViYWJDYXNlKS5qb2luKCcsJyksXG4gICAgICAgIHRyYW5zaXRpb25EdXJhdGlvbjogb3BlbkR1cmF0aW9uICsgXCJtc1wiLFxuICAgICAgICAuLi5jb21tb25TdHlsZXMsXG4gICAgICAgIC4uLm9wZW5TdHlsZXNcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzID09PSAnY2xvc2UnKSB7XG4gICAgICBjb25zdCBzdHlsZXMgPSBjbG9zZVN0eWxlcyB8fCBpbml0aWFsU3R5bGVzO1xuICAgICAgc2V0U3R5bGVzKHtcbiAgICAgICAgdHJhbnNpdGlvblByb3BlcnR5OiBPYmplY3Qua2V5cyhzdHlsZXMpLm1hcChjYW1lbENhc2VUb0tlYmFiQ2FzZSkuam9pbignLCcpLFxuICAgICAgICB0cmFuc2l0aW9uRHVyYXRpb246IGNsb3NlRHVyYXRpb24gKyBcIm1zXCIsXG4gICAgICAgIC4uLmNvbW1vblN0eWxlcyxcbiAgICAgICAgLi4uc3R5bGVzXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFtjbG9zZUR1cmF0aW9uLCBjbG9zZVJlZiwgaW5pdGlhbFJlZiwgb3BlblJlZiwgY29tbW9uUmVmLCBvcGVuRHVyYXRpb24sIHN0YXR1cywgZm5BcmdzXSk7XG4gIHJldHVybiB7XG4gICAgaXNNb3VudGVkLFxuICAgIHN0eWxlc1xuICB9O1xufVxuXG4vKipcbiAqIFByb3ZpZGVzIGEgbWF0Y2hpbmcgY2FsbGJhY2sgdGhhdCBjYW4gYmUgdXNlZCB0byBmb2N1cyBhbiBpdGVtIGFzIHRoZSB1c2VyXG4gKiB0eXBlcywgb2Z0ZW4gdXNlZCBpbiB0YW5kZW0gd2l0aCBgdXNlTGlzdE5hdmlnYXRpb24oKWAuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlVHlwZWFoZWFkXG4gKi9cbmZ1bmN0aW9uIHVzZVR5cGVhaGVhZChjb250ZXh0LCBwcm9wcykge1xuICB2YXIgX3JlZjtcbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgZGF0YVJlZlxuICB9ID0gY29udGV4dDtcbiAgY29uc3Qge1xuICAgIGxpc3RSZWYsXG4gICAgYWN0aXZlSW5kZXgsXG4gICAgb25NYXRjaDogdW5zdGFibGVfb25NYXRjaCxcbiAgICBvblR5cGluZ0NoYW5nZTogdW5zdGFibGVfb25UeXBpbmdDaGFuZ2UsXG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgZmluZE1hdGNoID0gbnVsbCxcbiAgICByZXNldE1zID0gNzUwLFxuICAgIGlnbm9yZUtleXMgPSBbXSxcbiAgICBzZWxlY3RlZEluZGV4ID0gbnVsbFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHRpbWVvdXRJZFJlZiA9IFJlYWN0LnVzZVJlZigpO1xuICBjb25zdCBzdHJpbmdSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCBwcmV2SW5kZXhSZWYgPSBSZWFjdC51c2VSZWYoKF9yZWYgPSBzZWxlY3RlZEluZGV4ICE9IG51bGwgPyBzZWxlY3RlZEluZGV4IDogYWN0aXZlSW5kZXgpICE9IG51bGwgPyBfcmVmIDogLTEpO1xuICBjb25zdCBtYXRjaEluZGV4UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBvbk1hdGNoID0gdXNlRWZmZWN0RXZlbnQodW5zdGFibGVfb25NYXRjaCk7XG4gIGNvbnN0IG9uVHlwaW5nQ2hhbmdlID0gdXNlRWZmZWN0RXZlbnQodW5zdGFibGVfb25UeXBpbmdDaGFuZ2UpO1xuICBjb25zdCBmaW5kTWF0Y2hSZWYgPSB1c2VMYXRlc3RSZWYoZmluZE1hdGNoKTtcbiAgY29uc3QgaWdub3JlS2V5c1JlZiA9IHVzZUxhdGVzdFJlZihpZ25vcmVLZXlzKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkUmVmLmN1cnJlbnQpO1xuICAgICAgbWF0Y2hJbmRleFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHN0cmluZ1JlZi5jdXJyZW50ID0gJyc7XG4gICAgfVxuICB9LCBbb3Blbl0pO1xuICBpbmRleCgoKSA9PiB7XG4gICAgLy8gU3luYyBhcnJvdyBrZXkgbmF2aWdhdGlvbiBidXQgbm90IHR5cGVhaGVhZCBuYXZpZ2F0aW9uLlxuICAgIGlmIChvcGVuICYmIHN0cmluZ1JlZi5jdXJyZW50ID09PSAnJykge1xuICAgICAgdmFyIF9yZWYyO1xuICAgICAgcHJldkluZGV4UmVmLmN1cnJlbnQgPSAoX3JlZjIgPSBzZWxlY3RlZEluZGV4ICE9IG51bGwgPyBzZWxlY3RlZEluZGV4IDogYWN0aXZlSW5kZXgpICE9IG51bGwgPyBfcmVmMiA6IC0xO1xuICAgIH1cbiAgfSwgW29wZW4sIHNlbGVjdGVkSW5kZXgsIGFjdGl2ZUluZGV4XSk7XG4gIGNvbnN0IHNldFR5cGluZ0NoYW5nZSA9IHVzZUVmZmVjdEV2ZW50KHZhbHVlID0+IHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIGlmICghZGF0YVJlZi5jdXJyZW50LnR5cGluZykge1xuICAgICAgICBkYXRhUmVmLmN1cnJlbnQudHlwaW5nID0gdmFsdWU7XG4gICAgICAgIG9uVHlwaW5nQ2hhbmdlKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGRhdGFSZWYuY3VycmVudC50eXBpbmcpIHtcbiAgICAgICAgZGF0YVJlZi5jdXJyZW50LnR5cGluZyA9IHZhbHVlO1xuICAgICAgICBvblR5cGluZ0NoYW5nZSh2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgY29uc3Qgb25LZXlEb3duID0gdXNlRWZmZWN0RXZlbnQoZXZlbnQgPT4ge1xuICAgIGZ1bmN0aW9uIGdldE1hdGNoaW5nSW5kZXgobGlzdCwgb3JkZXJlZExpc3QsIHN0cmluZykge1xuICAgICAgY29uc3Qgc3RyID0gZmluZE1hdGNoUmVmLmN1cnJlbnQgPyBmaW5kTWF0Y2hSZWYuY3VycmVudChvcmRlcmVkTGlzdCwgc3RyaW5nKSA6IG9yZGVyZWRMaXN0LmZpbmQodGV4dCA9PiAodGV4dCA9PSBudWxsID8gdm9pZCAwIDogdGV4dC50b0xvY2FsZUxvd2VyQ2FzZSgpLmluZGV4T2Yoc3RyaW5nLnRvTG9jYWxlTG93ZXJDYXNlKCkpKSA9PT0gMCk7XG4gICAgICByZXR1cm4gc3RyID8gbGlzdC5pbmRleE9mKHN0cikgOiAtMTtcbiAgICB9XG4gICAgY29uc3QgbGlzdENvbnRlbnQgPSBsaXN0UmVmLmN1cnJlbnQ7XG4gICAgaWYgKHN0cmluZ1JlZi5jdXJyZW50Lmxlbmd0aCA+IDAgJiYgc3RyaW5nUmVmLmN1cnJlbnRbMF0gIT09ICcgJykge1xuICAgICAgaWYgKGdldE1hdGNoaW5nSW5kZXgobGlzdENvbnRlbnQsIGxpc3RDb250ZW50LCBzdHJpbmdSZWYuY3VycmVudCkgPT09IC0xKSB7XG4gICAgICAgIHNldFR5cGluZ0NoYW5nZShmYWxzZSk7XG4gICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleSA9PT0gJyAnKSB7XG4gICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChsaXN0Q29udGVudCA9PSBudWxsIHx8IGlnbm9yZUtleXNSZWYuY3VycmVudC5pbmNsdWRlcyhldmVudC5rZXkpIHx8XG4gICAgLy8gQ2hhcmFjdGVyIGtleS5cbiAgICBldmVudC5rZXkubGVuZ3RoICE9PSAxIHx8XG4gICAgLy8gTW9kaWZpZXIga2V5LlxuICAgIGV2ZW50LmN0cmxLZXkgfHwgZXZlbnQubWV0YUtleSB8fCBldmVudC5hbHRLZXkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG9wZW4gJiYgZXZlbnQua2V5ICE9PSAnICcpIHtcbiAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICBzZXRUeXBpbmdDaGFuZ2UodHJ1ZSk7XG4gICAgfVxuXG4gICAgLy8gQmFpbCBvdXQgaWYgdGhlIGxpc3QgY29udGFpbnMgYSB3b3JkIGxpa2UgXCJsbGFtYVwiIG9yIFwiYWFyb25cIi4gVE9ETzpcbiAgICAvLyBhbGxvdyBpdCBpbiB0aGlzIGNhc2UsIHRvby5cbiAgICBjb25zdCBhbGxvd1JhcGlkU3VjY2Vzc2lvbk9mRmlyc3RMZXR0ZXIgPSBsaXN0Q29udGVudC5ldmVyeSh0ZXh0ID0+IHtcbiAgICAgIHZhciBfdGV4dCQsIF90ZXh0JDI7XG4gICAgICByZXR1cm4gdGV4dCA/ICgoX3RleHQkID0gdGV4dFswXSkgPT0gbnVsbCA/IHZvaWQgMCA6IF90ZXh0JC50b0xvY2FsZUxvd2VyQ2FzZSgpKSAhPT0gKChfdGV4dCQyID0gdGV4dFsxXSkgPT0gbnVsbCA/IHZvaWQgMCA6IF90ZXh0JDIudG9Mb2NhbGVMb3dlckNhc2UoKSkgOiB0cnVlO1xuICAgIH0pO1xuXG4gICAgLy8gQWxsb3dzIHRoZSB1c2VyIHRvIGN5Y2xlIHRocm91Z2ggaXRlbXMgdGhhdCBzdGFydCB3aXRoIHRoZSBzYW1lIGxldHRlclxuICAgIC8vIGluIHJhcGlkIHN1Y2Nlc3Npb24uXG4gICAgaWYgKGFsbG93UmFwaWRTdWNjZXNzaW9uT2ZGaXJzdExldHRlciAmJiBzdHJpbmdSZWYuY3VycmVudCA9PT0gZXZlbnQua2V5KSB7XG4gICAgICBzdHJpbmdSZWYuY3VycmVudCA9ICcnO1xuICAgICAgcHJldkluZGV4UmVmLmN1cnJlbnQgPSBtYXRjaEluZGV4UmVmLmN1cnJlbnQ7XG4gICAgfVxuICAgIHN0cmluZ1JlZi5jdXJyZW50ICs9IGV2ZW50LmtleTtcbiAgICBjbGVhclRpbWVvdXQodGltZW91dElkUmVmLmN1cnJlbnQpO1xuICAgIHRpbWVvdXRJZFJlZi5jdXJyZW50ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzdHJpbmdSZWYuY3VycmVudCA9ICcnO1xuICAgICAgcHJldkluZGV4UmVmLmN1cnJlbnQgPSBtYXRjaEluZGV4UmVmLmN1cnJlbnQ7XG4gICAgICBzZXRUeXBpbmdDaGFuZ2UoZmFsc2UpO1xuICAgIH0sIHJlc2V0TXMpO1xuICAgIGNvbnN0IHByZXZJbmRleCA9IHByZXZJbmRleFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGluZGV4ID0gZ2V0TWF0Y2hpbmdJbmRleChsaXN0Q29udGVudCwgWy4uLmxpc3RDb250ZW50LnNsaWNlKChwcmV2SW5kZXggfHwgMCkgKyAxKSwgLi4ubGlzdENvbnRlbnQuc2xpY2UoMCwgKHByZXZJbmRleCB8fCAwKSArIDEpXSwgc3RyaW5nUmVmLmN1cnJlbnQpO1xuICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgIG9uTWF0Y2goaW5kZXgpO1xuICAgICAgbWF0Y2hJbmRleFJlZi5jdXJyZW50ID0gaW5kZXg7XG4gICAgfSBlbHNlIGlmIChldmVudC5rZXkgIT09ICcgJykge1xuICAgICAgc3RyaW5nUmVmLmN1cnJlbnQgPSAnJztcbiAgICAgIHNldFR5cGluZ0NoYW5nZShmYWxzZSk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uS2V5RG93blxuICB9KSwgW29uS2V5RG93bl0pO1xuICBjb25zdCBmbG9hdGluZyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICBvbktleURvd24sXG4gICAgICBvbktleVVwKGV2ZW50KSB7XG4gICAgICAgIGlmIChldmVudC5rZXkgPT09ICcgJykge1xuICAgICAgICAgIHNldFR5cGluZ0NoYW5nZShmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICB9LCBbb25LZXlEb3duLCBzZXRUeXBpbmdDaGFuZ2VdKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZW5hYmxlZCA/IHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmdcbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlLCBmbG9hdGluZ10pO1xufVxuXG5mdW5jdGlvbiBnZXRBcmdzV2l0aEN1c3RvbUZsb2F0aW5nSGVpZ2h0KHN0YXRlLCBoZWlnaHQpIHtcbiAgcmV0dXJuIHtcbiAgICAuLi5zdGF0ZSxcbiAgICByZWN0czoge1xuICAgICAgLi4uc3RhdGUucmVjdHMsXG4gICAgICBmbG9hdGluZzoge1xuICAgICAgICAuLi5zdGF0ZS5yZWN0cy5mbG9hdGluZyxcbiAgICAgICAgaGVpZ2h0XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuLyoqXG4gKiBQb3NpdGlvbnMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc3VjaCB0aGF0IGFuIGlubmVyIGVsZW1lbnQgaW5zaWRlIG9mIGl0IGlzXG4gKiBhbmNob3JlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaW5uZXJcbiAqL1xuY29uc3QgaW5uZXIgPSBwcm9wcyA9PiAoe1xuICBuYW1lOiAnaW5uZXInLFxuICBvcHRpb25zOiBwcm9wcyxcbiAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICBjb25zdCB7XG4gICAgICBsaXN0UmVmLFxuICAgICAgb3ZlcmZsb3dSZWYsXG4gICAgICBvbkZhbGxiYWNrQ2hhbmdlLFxuICAgICAgb2Zmc2V0OiBpbm5lck9mZnNldCA9IDAsXG4gICAgICBpbmRleCA9IDAsXG4gICAgICBtaW5JdGVtc1Zpc2libGUgPSA0LFxuICAgICAgcmVmZXJlbmNlT3ZlcmZsb3dUaHJlc2hvbGQgPSAwLFxuICAgICAgc2Nyb2xsUmVmLFxuICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgfSA9IGV2YWx1YXRlKHByb3BzLCBzdGF0ZSk7XG4gICAgY29uc3Qge1xuICAgICAgcmVjdHMsXG4gICAgICBlbGVtZW50czoge1xuICAgICAgICBmbG9hdGluZ1xuICAgICAgfVxuICAgIH0gPSBzdGF0ZTtcbiAgICBjb25zdCBpdGVtID0gbGlzdFJlZi5jdXJyZW50W2luZGV4XTtcbiAgICBjb25zdCBzY3JvbGxFbCA9IChzY3JvbGxSZWYgPT0gbnVsbCA/IHZvaWQgMCA6IHNjcm9sbFJlZi5jdXJyZW50KSB8fCBmbG9hdGluZztcblxuICAgIC8vIFZhbGlkIGNvbWJpbmF0aW9uczpcbiAgICAvLyAxLiBGbG9hdGluZyBlbGVtZW50IGlzIHRoZSBzY3JvbGxSZWYgYW5kIGhhcyBhIGJvcmRlciAoZGVmYXVsdClcbiAgICAvLyAyLiBGbG9hdGluZyBlbGVtZW50IGlzIG5vdCB0aGUgc2Nyb2xsUmVmLCBmbG9hdGluZyBlbGVtZW50IGhhcyBhIGJvcmRlclxuICAgIC8vIDMuIEZsb2F0aW5nIGVsZW1lbnQgaXMgbm90IHRoZSBzY3JvbGxSZWYsIHNjcm9sbFJlZiBoYXMgYSBib3JkZXJcbiAgICAvLyBGbG9hdGluZyA+IHsuLi5nZXRGbG9hdGluZ1Byb3BzKCl9IHdyYXBwZXIgPiBzY3JvbGxSZWYgPiBpdGVtcyBpcyBub3RcbiAgICAvLyBhbGxvd2VkIGFzIFZvaWNlT3ZlciBkb2Vzbid0IHdvcmsuXG4gICAgY29uc3QgY2xpZW50VG9wID0gZmxvYXRpbmcuY2xpZW50VG9wIHx8IHNjcm9sbEVsLmNsaWVudFRvcDtcbiAgICBjb25zdCBmbG9hdGluZ0lzQm9yZGVyZWQgPSBmbG9hdGluZy5jbGllbnRUb3AgIT09IDA7XG4gICAgY29uc3Qgc2Nyb2xsRWxJc0JvcmRlcmVkID0gc2Nyb2xsRWwuY2xpZW50VG9wICE9PSAwO1xuICAgIGNvbnN0IGZsb2F0aW5nSXNTY3JvbGxFbCA9IGZsb2F0aW5nID09PSBzY3JvbGxFbDtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBpZiAoIXN0YXRlLnBsYWNlbWVudC5zdGFydHNXaXRoKCdib3R0b20nKSkge1xuICAgICAgICB3YXJuKCdgcGxhY2VtZW50YCBzaWRlIG11c3QgYmUgXCJib3R0b21cIiB3aGVuIHVzaW5nIHRoZSBgaW5uZXJgJywgJ21pZGRsZXdhcmUuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghaXRlbSkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBuZXh0QXJncyA9IHtcbiAgICAgIC4uLnN0YXRlLFxuICAgICAgLi4uKGF3YWl0IG9mZnNldCgtaXRlbS5vZmZzZXRUb3AgLSBmbG9hdGluZy5jbGllbnRUb3AgLSByZWN0cy5yZWZlcmVuY2UuaGVpZ2h0IC8gMiAtIGl0ZW0ub2Zmc2V0SGVpZ2h0IC8gMiAtIGlubmVyT2Zmc2V0KS5mbihzdGF0ZSkpXG4gICAgfTtcbiAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IGRldGVjdE92ZXJmbG93KGdldEFyZ3NXaXRoQ3VzdG9tRmxvYXRpbmdIZWlnaHQobmV4dEFyZ3MsIHNjcm9sbEVsLnNjcm9sbEhlaWdodCArIGNsaWVudFRvcCArIGZsb2F0aW5nLmNsaWVudFRvcCksIGRldGVjdE92ZXJmbG93T3B0aW9ucyk7XG4gICAgY29uc3QgcmVmT3ZlcmZsb3cgPSBhd2FpdCBkZXRlY3RPdmVyZmxvdyhuZXh0QXJncywge1xuICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zLFxuICAgICAgZWxlbWVudENvbnRleHQ6ICdyZWZlcmVuY2UnXG4gICAgfSk7XG4gICAgY29uc3QgZGlmZlkgPSBtYXgoMCwgb3ZlcmZsb3cudG9wKTtcbiAgICBjb25zdCBuZXh0WSA9IG5leHRBcmdzLnkgKyBkaWZmWTtcbiAgICBjb25zdCBpc1Njcm9sbGFibGUgPSBzY3JvbGxFbC5zY3JvbGxIZWlnaHQgPiBzY3JvbGxFbC5jbGllbnRIZWlnaHQ7XG4gICAgY29uc3Qgcm91bmRlciA9IGlzU2Nyb2xsYWJsZSA/IHYgPT4gdiA6IHJvdW5kO1xuICAgIGNvbnN0IG1heEhlaWdodCA9IHJvdW5kZXIobWF4KDAsIHNjcm9sbEVsLnNjcm9sbEhlaWdodCArIChmbG9hdGluZ0lzQm9yZGVyZWQgJiYgZmxvYXRpbmdJc1Njcm9sbEVsIHx8IHNjcm9sbEVsSXNCb3JkZXJlZCA/IGNsaWVudFRvcCAqIDIgOiAwKSAtIGRpZmZZIC0gbWF4KDAsIG92ZXJmbG93LmJvdHRvbSkpKTtcbiAgICBzY3JvbGxFbC5zdHlsZS5tYXhIZWlnaHQgPSBtYXhIZWlnaHQgKyBcInB4XCI7XG4gICAgc2Nyb2xsRWwuc2Nyb2xsVG9wID0gZGlmZlk7XG5cbiAgICAvLyBUaGVyZSBpcyBub3QgZW5vdWdoIHNwYWNlLCBmYWxsYmFjayB0byBzdGFuZGFyZCBhbmNob3JlZCBwb3NpdGlvbmluZ1xuICAgIGlmIChvbkZhbGxiYWNrQ2hhbmdlKSB7XG4gICAgICBjb25zdCBzaG91bGRGYWxsYmFjayA9IHNjcm9sbEVsLm9mZnNldEhlaWdodCA8IGl0ZW0ub2Zmc2V0SGVpZ2h0ICogbWluKG1pbkl0ZW1zVmlzaWJsZSwgbGlzdFJlZi5jdXJyZW50Lmxlbmd0aCkgLSAxIHx8IHJlZk92ZXJmbG93LnRvcCA+PSAtcmVmZXJlbmNlT3ZlcmZsb3dUaHJlc2hvbGQgfHwgcmVmT3ZlcmZsb3cuYm90dG9tID49IC1yZWZlcmVuY2VPdmVyZmxvd1RocmVzaG9sZDtcbiAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiBvbkZhbGxiYWNrQ2hhbmdlKHNob3VsZEZhbGxiYWNrKSk7XG4gICAgfVxuICAgIGlmIChvdmVyZmxvd1JlZikge1xuICAgICAgb3ZlcmZsb3dSZWYuY3VycmVudCA9IGF3YWl0IGRldGVjdE92ZXJmbG93KGdldEFyZ3NXaXRoQ3VzdG9tRmxvYXRpbmdIZWlnaHQoe1xuICAgICAgICAuLi5uZXh0QXJncyxcbiAgICAgICAgeTogbmV4dFlcbiAgICAgIH0sIHNjcm9sbEVsLm9mZnNldEhlaWdodCArIGNsaWVudFRvcCArIGZsb2F0aW5nLmNsaWVudFRvcCksIGRldGVjdE92ZXJmbG93T3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICB5OiBuZXh0WVxuICAgIH07XG4gIH1cbn0pO1xuLyoqXG4gKiBDaGFuZ2VzIHRoZSBgaW5uZXJgIG1pZGRsZXdhcmUncyBgb2Zmc2V0YCB1cG9uIGEgYHdoZWVsYCBldmVudCB0b1xuICogZXhwYW5kIHRoZSBmbG9hdGluZyBlbGVtZW50J3MgaGVpZ2h0LCByZXZlYWxpbmcgbW9yZSBsaXN0IGl0ZW1zLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2lubmVyXG4gKi9cbmZ1bmN0aW9uIHVzZUlubmVyT2Zmc2V0KGNvbnRleHQsIHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBvcGVuLFxuICAgIGVsZW1lbnRzXG4gIH0gPSBjb250ZXh0O1xuICBjb25zdCB7XG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgb3ZlcmZsb3dSZWYsXG4gICAgc2Nyb2xsUmVmLFxuICAgIG9uQ2hhbmdlOiB1bnN0YWJsZV9vbkNoYW5nZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IG9uQ2hhbmdlID0gdXNlRWZmZWN0RXZlbnQodW5zdGFibGVfb25DaGFuZ2UpO1xuICBjb25zdCBjb250cm9sbGVkU2Nyb2xsaW5nUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgcHJldlNjcm9sbFRvcFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgaW5pdGlhbE92ZXJmbG93UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkgcmV0dXJuO1xuICAgIGZ1bmN0aW9uIG9uV2hlZWwoZSkge1xuICAgICAgaWYgKGUuY3RybEtleSB8fCAhZWwgfHwgb3ZlcmZsb3dSZWYuY3VycmVudCA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRZID0gZS5kZWx0YVk7XG4gICAgICBjb25zdCBpc0F0VG9wID0gb3ZlcmZsb3dSZWYuY3VycmVudC50b3AgPj0gLTAuNTtcbiAgICAgIGNvbnN0IGlzQXRCb3R0b20gPSBvdmVyZmxvd1JlZi5jdXJyZW50LmJvdHRvbSA+PSAtMC41O1xuICAgICAgY29uc3QgcmVtYWluaW5nU2Nyb2xsID0gZWwuc2Nyb2xsSGVpZ2h0IC0gZWwuY2xpZW50SGVpZ2h0O1xuICAgICAgY29uc3Qgc2lnbiA9IGRZIDwgMCA/IC0xIDogMTtcbiAgICAgIGNvbnN0IG1ldGhvZCA9IGRZIDwgMCA/ICdtYXgnIDogJ21pbic7XG4gICAgICBpZiAoZWwuc2Nyb2xsSGVpZ2h0IDw9IGVsLmNsaWVudEhlaWdodCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIWlzQXRUb3AgJiYgZFkgPiAwIHx8ICFpc0F0Qm90dG9tICYmIGRZIDwgMCkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiB7XG4gICAgICAgICAgb25DaGFuZ2UoZCA9PiBkICsgTWF0aFttZXRob2RdKGRZLCByZW1haW5pbmdTY3JvbGwgKiBzaWduKSk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmICgvZmlyZWZveC9pLnRlc3QoZ2V0VXNlckFnZW50KCkpKSB7XG4gICAgICAgIC8vIE5lZWRlZCB0byBwcm9wYWdhdGUgc2Nyb2xsaW5nIGR1cmluZyBtb21lbnR1bSBzY3JvbGxpbmcgcGhhc2Ugb25jZVxuICAgICAgICAvLyBpdCBnZXRzIGxpbWl0ZWQgYnkgdGhlIGJvdW5kYXJ5LiBVWCBpbXByb3ZlbWVudCwgbm90IGNyaXRpY2FsLlxuICAgICAgICBlbC5zY3JvbGxUb3AgKz0gZFk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGVsID0gKHNjcm9sbFJlZiA9PSBudWxsID8gdm9pZCAwIDogc2Nyb2xsUmVmLmN1cnJlbnQpIHx8IGVsZW1lbnRzLmZsb2F0aW5nO1xuICAgIGlmIChvcGVuICYmIGVsKSB7XG4gICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCd3aGVlbCcsIG9uV2hlZWwpO1xuXG4gICAgICAvLyBXYWl0IGZvciB0aGUgcG9zaXRpb24gdG8gYmUgcmVhZHkuXG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgICBwcmV2U2Nyb2xsVG9wUmVmLmN1cnJlbnQgPSBlbC5zY3JvbGxUb3A7XG4gICAgICAgIGlmIChvdmVyZmxvd1JlZi5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgICAgICBpbml0aWFsT3ZlcmZsb3dSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICAgIC4uLm92ZXJmbG93UmVmLmN1cnJlbnRcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIHByZXZTY3JvbGxUb3BSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIGluaXRpYWxPdmVyZmxvd1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgZWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBvbldoZWVsKTtcbiAgICAgIH07XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgZWxlbWVudHMuZmxvYXRpbmcsIG92ZXJmbG93UmVmLCBzY3JvbGxSZWYsIG9uQ2hhbmdlXSk7XG4gIGNvbnN0IGZsb2F0aW5nID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uS2V5RG93bigpIHtcbiAgICAgIGNvbnRyb2xsZWRTY3JvbGxpbmdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfSxcbiAgICBvbldoZWVsKCkge1xuICAgICAgY29udHJvbGxlZFNjcm9sbGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfSxcbiAgICBvblBvaW50ZXJNb3ZlKCkge1xuICAgICAgY29udHJvbGxlZFNjcm9sbGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfSxcbiAgICBvblNjcm9sbCgpIHtcbiAgICAgIGNvbnN0IGVsID0gKHNjcm9sbFJlZiA9PSBudWxsID8gdm9pZCAwIDogc2Nyb2xsUmVmLmN1cnJlbnQpIHx8IGVsZW1lbnRzLmZsb2F0aW5nO1xuICAgICAgaWYgKCFvdmVyZmxvd1JlZi5jdXJyZW50IHx8ICFlbCB8fCAhY29udHJvbGxlZFNjcm9sbGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChwcmV2U2Nyb2xsVG9wUmVmLmN1cnJlbnQgIT09IG51bGwpIHtcbiAgICAgICAgY29uc3Qgc2Nyb2xsRGlmZiA9IGVsLnNjcm9sbFRvcCAtIHByZXZTY3JvbGxUb3BSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKG92ZXJmbG93UmVmLmN1cnJlbnQuYm90dG9tIDwgLTAuNSAmJiBzY3JvbGxEaWZmIDwgLTEgfHwgb3ZlcmZsb3dSZWYuY3VycmVudC50b3AgPCAtMC41ICYmIHNjcm9sbERpZmYgPiAxKSB7XG4gICAgICAgICAgUmVhY3RET00uZmx1c2hTeW5jKCgpID0+IG9uQ2hhbmdlKGQgPT4gZCArIHNjcm9sbERpZmYpKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBbRmlyZWZveF0gV2FpdCBmb3IgdGhlIGhlaWdodCBjaGFuZ2UgdG8gaGF2ZSBiZWVuIGFwcGxpZWQuXG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgICBwcmV2U2Nyb2xsVG9wUmVmLmN1cnJlbnQgPSBlbC5zY3JvbGxUb3A7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pLCBbZWxlbWVudHMuZmxvYXRpbmcsIG9uQ2hhbmdlLCBvdmVyZmxvd1JlZiwgc2Nyb2xsUmVmXSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgZmxvYXRpbmdcbiAgfSA6IHt9LCBbZW5hYmxlZCwgZmxvYXRpbmddKTtcbn1cblxuZnVuY3Rpb24gaXNQb2ludEluUG9seWdvbihwb2ludCwgcG9seWdvbikge1xuICBjb25zdCBbeCwgeV0gPSBwb2ludDtcbiAgbGV0IGlzSW5zaWRlID0gZmFsc2U7XG4gIGNvbnN0IGxlbmd0aCA9IHBvbHlnb24ubGVuZ3RoO1xuICBmb3IgKGxldCBpID0gMCwgaiA9IGxlbmd0aCAtIDE7IGkgPCBsZW5ndGg7IGogPSBpKyspIHtcbiAgICBjb25zdCBbeGksIHlpXSA9IHBvbHlnb25baV0gfHwgWzAsIDBdO1xuICAgIGNvbnN0IFt4aiwgeWpdID0gcG9seWdvbltqXSB8fCBbMCwgMF07XG4gICAgY29uc3QgaW50ZXJzZWN0ID0geWkgPj0geSAhPT0geWogPj0geSAmJiB4IDw9ICh4aiAtIHhpKSAqICh5IC0geWkpIC8gKHlqIC0geWkpICsgeGk7XG4gICAgaWYgKGludGVyc2VjdCkge1xuICAgICAgaXNJbnNpZGUgPSAhaXNJbnNpZGU7XG4gICAgfVxuICB9XG4gIHJldHVybiBpc0luc2lkZTtcbn1cbmZ1bmN0aW9uIGlzSW5zaWRlKHBvaW50LCByZWN0KSB7XG4gIHJldHVybiBwb2ludFswXSA+PSByZWN0LnggJiYgcG9pbnRbMF0gPD0gcmVjdC54ICsgcmVjdC53aWR0aCAmJiBwb2ludFsxXSA+PSByZWN0LnkgJiYgcG9pbnRbMV0gPD0gcmVjdC55ICsgcmVjdC5oZWlnaHQ7XG59XG4vKipcbiAqIEdlbmVyYXRlcyBhIHNhZmUgcG9seWdvbiBhcmVhIHRoYXQgdGhlIHVzZXIgY2FuIHRyYXZlcnNlIHdpdGhvdXQgY2xvc2luZyB0aGVcbiAqIGZsb2F0aW5nIGVsZW1lbnQgb25jZSBsZWF2aW5nIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VIb3ZlciNzYWZlcG9seWdvblxuICovXG5mdW5jdGlvbiBzYWZlUG9seWdvbihvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIGJ1ZmZlciA9IDAuNSxcbiAgICBibG9ja1BvaW50ZXJFdmVudHMgPSBmYWxzZSxcbiAgICByZXF1aXJlSW50ZW50ID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgbGV0IHRpbWVvdXRJZDtcbiAgbGV0IGhhc0xhbmRlZCA9IGZhbHNlO1xuICBsZXQgbGFzdFggPSBudWxsO1xuICBsZXQgbGFzdFkgPSBudWxsO1xuICBsZXQgbGFzdEN1cnNvclRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgZnVuY3Rpb24gZ2V0Q3Vyc29yU3BlZWQoeCwgeSkge1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgY29uc3QgZWxhcHNlZFRpbWUgPSBjdXJyZW50VGltZSAtIGxhc3RDdXJzb3JUaW1lO1xuICAgIGlmIChsYXN0WCA9PT0gbnVsbCB8fCBsYXN0WSA9PT0gbnVsbCB8fCBlbGFwc2VkVGltZSA9PT0gMCkge1xuICAgICAgbGFzdFggPSB4O1xuICAgICAgbGFzdFkgPSB5O1xuICAgICAgbGFzdEN1cnNvclRpbWUgPSBjdXJyZW50VGltZTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBkZWx0YVggPSB4IC0gbGFzdFg7XG4gICAgY29uc3QgZGVsdGFZID0geSAtIGxhc3RZO1xuICAgIGNvbnN0IGRpc3RhbmNlID0gTWF0aC5zcXJ0KGRlbHRhWCAqIGRlbHRhWCArIGRlbHRhWSAqIGRlbHRhWSk7XG4gICAgY29uc3Qgc3BlZWQgPSBkaXN0YW5jZSAvIGVsYXBzZWRUaW1lOyAvLyBweCAvIG1zXG5cbiAgICBsYXN0WCA9IHg7XG4gICAgbGFzdFkgPSB5O1xuICAgIGxhc3RDdXJzb3JUaW1lID0gY3VycmVudFRpbWU7XG4gICAgcmV0dXJuIHNwZWVkO1xuICB9XG4gIGNvbnN0IGZuID0gX3JlZiA9PiB7XG4gICAgbGV0IHtcbiAgICAgIHgsXG4gICAgICB5LFxuICAgICAgcGxhY2VtZW50LFxuICAgICAgZWxlbWVudHMsXG4gICAgICBvbkNsb3NlLFxuICAgICAgbm9kZUlkLFxuICAgICAgdHJlZVxuICAgIH0gPSBfcmVmO1xuICAgIHJldHVybiBmdW5jdGlvbiBvbk1vdXNlTW92ZShldmVudCkge1xuICAgICAgZnVuY3Rpb24gY2xvc2UoKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICBvbkNsb3NlKCk7XG4gICAgICB9XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICAgIGlmICghZWxlbWVudHMuZG9tUmVmZXJlbmNlIHx8ICFlbGVtZW50cy5mbG9hdGluZyB8fCBwbGFjZW1lbnQgPT0gbnVsbCB8fCB4ID09IG51bGwgfHwgeSA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHtcbiAgICAgICAgY2xpZW50WCxcbiAgICAgICAgY2xpZW50WVxuICAgICAgfSA9IGV2ZW50O1xuICAgICAgY29uc3QgY2xpZW50UG9pbnQgPSBbY2xpZW50WCwgY2xpZW50WV07XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgY29uc3QgaXNMZWF2ZSA9IGV2ZW50LnR5cGUgPT09ICdtb3VzZWxlYXZlJztcbiAgICAgIGNvbnN0IGlzT3ZlckZsb2F0aW5nRWwgPSBjb250YWlucyhlbGVtZW50cy5mbG9hdGluZywgdGFyZ2V0KTtcbiAgICAgIGNvbnN0IGlzT3ZlclJlZmVyZW5jZUVsID0gY29udGFpbnMoZWxlbWVudHMuZG9tUmVmZXJlbmNlLCB0YXJnZXQpO1xuICAgICAgY29uc3QgcmVmUmVjdCA9IGVsZW1lbnRzLmRvbVJlZmVyZW5jZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGNvbnN0IHJlY3QgPSBlbGVtZW50cy5mbG9hdGluZy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGNvbnN0IHNpZGUgPSBwbGFjZW1lbnQuc3BsaXQoJy0nKVswXTtcbiAgICAgIGNvbnN0IGN1cnNvckxlYXZlRnJvbVJpZ2h0ID0geCA+IHJlY3QucmlnaHQgLSByZWN0LndpZHRoIC8gMjtcbiAgICAgIGNvbnN0IGN1cnNvckxlYXZlRnJvbUJvdHRvbSA9IHkgPiByZWN0LmJvdHRvbSAtIHJlY3QuaGVpZ2h0IC8gMjtcbiAgICAgIGNvbnN0IGlzT3ZlclJlZmVyZW5jZVJlY3QgPSBpc0luc2lkZShjbGllbnRQb2ludCwgcmVmUmVjdCk7XG4gICAgICBjb25zdCBpc0Zsb2F0aW5nV2lkZXIgPSByZWN0LndpZHRoID4gcmVmUmVjdC53aWR0aDtcbiAgICAgIGNvbnN0IGlzRmxvYXRpbmdUYWxsZXIgPSByZWN0LmhlaWdodCA+IHJlZlJlY3QuaGVpZ2h0O1xuICAgICAgY29uc3QgbGVmdCA9IChpc0Zsb2F0aW5nV2lkZXIgPyByZWZSZWN0IDogcmVjdCkubGVmdDtcbiAgICAgIGNvbnN0IHJpZ2h0ID0gKGlzRmxvYXRpbmdXaWRlciA/IHJlZlJlY3QgOiByZWN0KS5yaWdodDtcbiAgICAgIGNvbnN0IHRvcCA9IChpc0Zsb2F0aW5nVGFsbGVyID8gcmVmUmVjdCA6IHJlY3QpLnRvcDtcbiAgICAgIGNvbnN0IGJvdHRvbSA9IChpc0Zsb2F0aW5nVGFsbGVyID8gcmVmUmVjdCA6IHJlY3QpLmJvdHRvbTtcbiAgICAgIGlmIChpc092ZXJGbG9hdGluZ0VsKSB7XG4gICAgICAgIGhhc0xhbmRlZCA9IHRydWU7XG4gICAgICAgIGlmICghaXNMZWF2ZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlzT3ZlclJlZmVyZW5jZUVsKSB7XG4gICAgICAgIGhhc0xhbmRlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKGlzT3ZlclJlZmVyZW5jZUVsICYmICFpc0xlYXZlKSB7XG4gICAgICAgIGhhc0xhbmRlZCA9IHRydWU7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gUHJldmVudCBvdmVybGFwcGluZyBmbG9hdGluZyBlbGVtZW50IGZyb20gYmVpbmcgc3R1Y2sgaW4gYW4gb3Blbi1jbG9zZVxuICAgICAgLy8gbG9vcDogaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8xOTEwXG4gICAgICBpZiAoaXNMZWF2ZSAmJiBpc0VsZW1lbnQoZXZlbnQucmVsYXRlZFRhcmdldCkgJiYgY29udGFpbnMoZWxlbWVudHMuZmxvYXRpbmcsIGV2ZW50LnJlbGF0ZWRUYXJnZXQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSWYgYW55IG5lc3RlZCBjaGlsZCBpcyBvcGVuLCBhYm9ydC5cbiAgICAgIGlmICh0cmVlICYmIGdldENoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgbm9kZUlkKS5zb21lKF9yZWYyID0+IHtcbiAgICAgICAgbGV0IHtcbiAgICAgICAgICBjb250ZXh0XG4gICAgICAgIH0gPSBfcmVmMjtcbiAgICAgICAgcmV0dXJuIGNvbnRleHQgPT0gbnVsbCA/IHZvaWQgMCA6IGNvbnRleHQub3BlbjtcbiAgICAgIH0pKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSWYgdGhlIHBvaW50ZXIgaXMgbGVhdmluZyBmcm9tIHRoZSBvcHBvc2l0ZSBzaWRlLCB0aGUgXCJidWZmZXJcIiBsb2dpY1xuICAgICAgLy8gY3JlYXRlcyBhIHBvaW50IHdoZXJlIHRoZSBmbG9hdGluZyBlbGVtZW50IHJlbWFpbnMgb3BlbiwgYnV0IHNob3VsZCBiZVxuICAgICAgLy8gaWdub3JlZC5cbiAgICAgIC8vIEEgY29uc3RhbnQgb2YgMSBoYW5kbGVzIGZsb2F0aW5nIHBvaW50IHJvdW5kaW5nIGVycm9ycy5cbiAgICAgIGlmIChzaWRlID09PSAndG9wJyAmJiB5ID49IHJlZlJlY3QuYm90dG9tIC0gMSB8fCBzaWRlID09PSAnYm90dG9tJyAmJiB5IDw9IHJlZlJlY3QudG9wICsgMSB8fCBzaWRlID09PSAnbGVmdCcgJiYgeCA+PSByZWZSZWN0LnJpZ2h0IC0gMSB8fCBzaWRlID09PSAncmlnaHQnICYmIHggPD0gcmVmUmVjdC5sZWZ0ICsgMSkge1xuICAgICAgICByZXR1cm4gY2xvc2UoKTtcbiAgICAgIH1cblxuICAgICAgLy8gSWdub3JlIHdoZW4gdGhlIGN1cnNvciBpcyB3aXRoaW4gdGhlIHJlY3Rhbmd1bGFyIHRyb3VnaCBiZXR3ZWVuIHRoZVxuICAgICAgLy8gdHdvIGVsZW1lbnRzLiBTaW5jZSB0aGUgdHJpYW5nbGUgaXMgY3JlYXRlZCBmcm9tIHRoZSBjdXJzb3IgcG9pbnQsXG4gICAgICAvLyB3aGljaCBjYW4gc3RhcnQgYmV5b25kIHRoZSByZWYgZWxlbWVudCdzIGVkZ2UsIHRyYXZlcnNpbmcgYmFjayBhbmRcbiAgICAgIC8vIGZvcnRoIGZyb20gdGhlIHJlZiB0byB0aGUgZmxvYXRpbmcgZWxlbWVudCBjYW4gY2F1c2UgaXQgdG8gY2xvc2UuIFRoaXNcbiAgICAgIC8vIGVuc3VyZXMgaXQgYWx3YXlzIHJlbWFpbnMgb3BlbiBpbiB0aGF0IGNhc2UuXG4gICAgICBsZXQgcmVjdFBvbHkgPSBbXTtcbiAgICAgIHN3aXRjaCAoc2lkZSkge1xuICAgICAgICBjYXNlICd0b3AnOlxuICAgICAgICAgIHJlY3RQb2x5ID0gW1tsZWZ0LCByZWZSZWN0LnRvcCArIDFdLCBbbGVmdCwgcmVjdC5ib3R0b20gLSAxXSwgW3JpZ2h0LCByZWN0LmJvdHRvbSAtIDFdLCBbcmlnaHQsIHJlZlJlY3QudG9wICsgMV1dO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdib3R0b20nOlxuICAgICAgICAgIHJlY3RQb2x5ID0gW1tsZWZ0LCByZWN0LnRvcCArIDFdLCBbbGVmdCwgcmVmUmVjdC5ib3R0b20gLSAxXSwgW3JpZ2h0LCByZWZSZWN0LmJvdHRvbSAtIDFdLCBbcmlnaHQsIHJlY3QudG9wICsgMV1dO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdsZWZ0JzpcbiAgICAgICAgICByZWN0UG9seSA9IFtbcmVjdC5yaWdodCAtIDEsIGJvdHRvbV0sIFtyZWN0LnJpZ2h0IC0gMSwgdG9wXSwgW3JlZlJlY3QubGVmdCArIDEsIHRvcF0sIFtyZWZSZWN0LmxlZnQgKyAxLCBib3R0b21dXTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAncmlnaHQnOlxuICAgICAgICAgIHJlY3RQb2x5ID0gW1tyZWZSZWN0LnJpZ2h0IC0gMSwgYm90dG9tXSwgW3JlZlJlY3QucmlnaHQgLSAxLCB0b3BdLCBbcmVjdC5sZWZ0ICsgMSwgdG9wXSwgW3JlY3QubGVmdCArIDEsIGJvdHRvbV1dO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZnVuY3Rpb24gZ2V0UG9seWdvbihfcmVmMykge1xuICAgICAgICBsZXQgW3gsIHldID0gX3JlZjM7XG4gICAgICAgIHN3aXRjaCAoc2lkZSkge1xuICAgICAgICAgIGNhc2UgJ3RvcCc6XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50T25lID0gW2lzRmxvYXRpbmdXaWRlciA/IHggKyBidWZmZXIgLyAyIDogY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyB4ICsgYnVmZmVyICogNCA6IHggLSBidWZmZXIgKiA0LCB5ICsgYnVmZmVyICsgMV07XG4gICAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50VHdvID0gW2lzRmxvYXRpbmdXaWRlciA/IHggLSBidWZmZXIgLyAyIDogY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyB4ICsgYnVmZmVyICogNCA6IHggLSBidWZmZXIgKiA0LCB5ICsgYnVmZmVyICsgMV07XG4gICAgICAgICAgICAgIGNvbnN0IGNvbW1vblBvaW50cyA9IFtbcmVjdC5sZWZ0LCBjdXJzb3JMZWF2ZUZyb21SaWdodCA/IHJlY3QuYm90dG9tIC0gYnVmZmVyIDogaXNGbG9hdGluZ1dpZGVyID8gcmVjdC5ib3R0b20gLSBidWZmZXIgOiByZWN0LnRvcF0sIFtyZWN0LnJpZ2h0LCBjdXJzb3JMZWF2ZUZyb21SaWdodCA/IGlzRmxvYXRpbmdXaWRlciA/IHJlY3QuYm90dG9tIC0gYnVmZmVyIDogcmVjdC50b3AgOiByZWN0LmJvdHRvbSAtIGJ1ZmZlcl1dO1xuICAgICAgICAgICAgICByZXR1cm4gW2N1cnNvclBvaW50T25lLCBjdXJzb3JQb2ludFR3bywgLi4uY29tbW9uUG9pbnRzXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICBjYXNlICdib3R0b20nOlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludE9uZSA9IFtpc0Zsb2F0aW5nV2lkZXIgPyB4ICsgYnVmZmVyIC8gMiA6IGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8geCArIGJ1ZmZlciAqIDQgOiB4IC0gYnVmZmVyICogNCwgeSAtIGJ1ZmZlcl07XG4gICAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50VHdvID0gW2lzRmxvYXRpbmdXaWRlciA/IHggLSBidWZmZXIgLyAyIDogY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyB4ICsgYnVmZmVyICogNCA6IHggLSBidWZmZXIgKiA0LCB5IC0gYnVmZmVyXTtcbiAgICAgICAgICAgICAgY29uc3QgY29tbW9uUG9pbnRzID0gW1tyZWN0LmxlZnQsIGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8gcmVjdC50b3AgKyBidWZmZXIgOiBpc0Zsb2F0aW5nV2lkZXIgPyByZWN0LnRvcCArIGJ1ZmZlciA6IHJlY3QuYm90dG9tXSwgW3JlY3QucmlnaHQsIGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8gaXNGbG9hdGluZ1dpZGVyID8gcmVjdC50b3AgKyBidWZmZXIgOiByZWN0LmJvdHRvbSA6IHJlY3QudG9wICsgYnVmZmVyXV07XG4gICAgICAgICAgICAgIHJldHVybiBbY3Vyc29yUG9pbnRPbmUsIGN1cnNvclBvaW50VHdvLCAuLi5jb21tb25Qb2ludHNdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIGNhc2UgJ2xlZnQnOlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludE9uZSA9IFt4ICsgYnVmZmVyICsgMSwgaXNGbG9hdGluZ1RhbGxlciA/IHkgKyBidWZmZXIgLyAyIDogY3Vyc29yTGVhdmVGcm9tQm90dG9tID8geSArIGJ1ZmZlciAqIDQgOiB5IC0gYnVmZmVyICogNF07XG4gICAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50VHdvID0gW3ggKyBidWZmZXIgKyAxLCBpc0Zsb2F0aW5nVGFsbGVyID8geSAtIGJ1ZmZlciAvIDIgOiBjdXJzb3JMZWF2ZUZyb21Cb3R0b20gPyB5ICsgYnVmZmVyICogNCA6IHkgLSBidWZmZXIgKiA0XTtcbiAgICAgICAgICAgICAgY29uc3QgY29tbW9uUG9pbnRzID0gW1tjdXJzb3JMZWF2ZUZyb21Cb3R0b20gPyByZWN0LnJpZ2h0IC0gYnVmZmVyIDogaXNGbG9hdGluZ1RhbGxlciA/IHJlY3QucmlnaHQgLSBidWZmZXIgOiByZWN0LmxlZnQsIHJlY3QudG9wXSwgW2N1cnNvckxlYXZlRnJvbUJvdHRvbSA/IGlzRmxvYXRpbmdUYWxsZXIgPyByZWN0LnJpZ2h0IC0gYnVmZmVyIDogcmVjdC5sZWZ0IDogcmVjdC5yaWdodCAtIGJ1ZmZlciwgcmVjdC5ib3R0b21dXTtcbiAgICAgICAgICAgICAgcmV0dXJuIFsuLi5jb21tb25Qb2ludHMsIGN1cnNvclBvaW50T25lLCBjdXJzb3JQb2ludFR3b107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgY2FzZSAncmlnaHQnOlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludE9uZSA9IFt4IC0gYnVmZmVyLCBpc0Zsb2F0aW5nVGFsbGVyID8geSArIGJ1ZmZlciAvIDIgOiBjdXJzb3JMZWF2ZUZyb21Cb3R0b20gPyB5ICsgYnVmZmVyICogNCA6IHkgLSBidWZmZXIgKiA0XTtcbiAgICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9pbnRUd28gPSBbeCAtIGJ1ZmZlciwgaXNGbG9hdGluZ1RhbGxlciA/IHkgLSBidWZmZXIgLyAyIDogY3Vyc29yTGVhdmVGcm9tQm90dG9tID8geSArIGJ1ZmZlciAqIDQgOiB5IC0gYnVmZmVyICogNF07XG4gICAgICAgICAgICAgIGNvbnN0IGNvbW1vblBvaW50cyA9IFtbY3Vyc29yTGVhdmVGcm9tQm90dG9tID8gcmVjdC5sZWZ0ICsgYnVmZmVyIDogaXNGbG9hdGluZ1RhbGxlciA/IHJlY3QubGVmdCArIGJ1ZmZlciA6IHJlY3QucmlnaHQsIHJlY3QudG9wXSwgW2N1cnNvckxlYXZlRnJvbUJvdHRvbSA/IGlzRmxvYXRpbmdUYWxsZXIgPyByZWN0LmxlZnQgKyBidWZmZXIgOiByZWN0LnJpZ2h0IDogcmVjdC5sZWZ0ICsgYnVmZmVyLCByZWN0LmJvdHRvbV1dO1xuICAgICAgICAgICAgICByZXR1cm4gW2N1cnNvclBvaW50T25lLCBjdXJzb3JQb2ludFR3bywgLi4uY29tbW9uUG9pbnRzXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlzUG9pbnRJblBvbHlnb24oW2NsaWVudFgsIGNsaWVudFldLCByZWN0UG9seSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGhhc0xhbmRlZCAmJiAhaXNPdmVyUmVmZXJlbmNlUmVjdCkge1xuICAgICAgICByZXR1cm4gY2xvc2UoKTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNMZWF2ZSAmJiByZXF1aXJlSW50ZW50KSB7XG4gICAgICAgIGNvbnN0IGN1cnNvclNwZWVkID0gZ2V0Q3Vyc29yU3BlZWQoZXZlbnQuY2xpZW50WCwgZXZlbnQuY2xpZW50WSk7XG4gICAgICAgIGNvbnN0IGN1cnNvclNwZWVkVGhyZXNob2xkID0gMC4xO1xuICAgICAgICBpZiAoY3Vyc29yU3BlZWQgIT09IG51bGwgJiYgY3Vyc29yU3BlZWQgPCBjdXJzb3JTcGVlZFRocmVzaG9sZCkge1xuICAgICAgICAgIHJldHVybiBjbG9zZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoIWlzUG9pbnRJblBvbHlnb24oW2NsaWVudFgsIGNsaWVudFldLCBnZXRQb2x5Z29uKFt4LCB5XSkpKSB7XG4gICAgICAgIGNsb3NlKCk7XG4gICAgICB9IGVsc2UgaWYgKCFoYXNMYW5kZWQgJiYgcmVxdWlyZUludGVudCkge1xuICAgICAgICB0aW1lb3V0SWQgPSB3aW5kb3cuc2V0VGltZW91dChjbG9zZSwgNDApO1xuICAgICAgfVxuICAgIH07XG4gIH07XG4gIGZuLl9fb3B0aW9ucyA9IHtcbiAgICBibG9ja1BvaW50ZXJFdmVudHNcbiAgfTtcbiAgcmV0dXJuIGZuO1xufVxuXG5leHBvcnQgeyBDb21wb3NpdGUsIENvbXBvc2l0ZUl0ZW0sIEZsb2F0aW5nQXJyb3csIEZsb2F0aW5nRGVsYXlHcm91cCwgRmxvYXRpbmdGb2N1c01hbmFnZXIsIEZsb2F0aW5nTGlzdCwgRmxvYXRpbmdOb2RlLCBGbG9hdGluZ092ZXJsYXksIEZsb2F0aW5nUG9ydGFsLCBGbG9hdGluZ1RyZWUsIGlubmVyLCBzYWZlUG9seWdvbiwgdXNlQ2xpY2ssIHVzZUNsaWVudFBvaW50LCB1c2VEZWxheUdyb3VwLCB1c2VEZWxheUdyb3VwQ29udGV4dCwgdXNlRGlzbWlzcywgdXNlRmxvYXRpbmcsIHVzZUZsb2F0aW5nTm9kZUlkLCB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCwgdXNlRmxvYXRpbmdQb3J0YWxOb2RlLCB1c2VGbG9hdGluZ1Jvb3RDb250ZXh0LCB1c2VGbG9hdGluZ1RyZWUsIHVzZUZvY3VzLCB1c2VIb3ZlciwgdXNlSWQsIHVzZUlubmVyT2Zmc2V0LCB1c2VJbnRlcmFjdGlvbnMsIHVzZUxpc3RJdGVtLCB1c2VMaXN0TmF2aWdhdGlvbiwgdXNlTWVyZ2VSZWZzLCB1c2VSb2xlLCB1c2VUcmFuc2l0aW9uU3RhdHVzLCB1c2VUcmFuc2l0aW9uU3R5bGVzLCB1c2VUeXBlYWhlYWQgfTtcbiIsImZ1bmN0aW9uIGhhc1dpbmRvdygpIHtcbiAgcmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnO1xufVxuZnVuY3Rpb24gZ2V0Tm9kZU5hbWUobm9kZSkge1xuICBpZiAoaXNOb2RlKG5vZGUpKSB7XG4gICAgcmV0dXJuIChub2RlLm5vZGVOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpO1xuICB9XG4gIC8vIE1vY2tlZCBub2RlcyBpbiB0ZXN0aW5nIGVudmlyb25tZW50cyBtYXkgbm90IGJlIGluc3RhbmNlcyBvZiBOb2RlLiBCeVxuICAvLyByZXR1cm5pbmcgYCNkb2N1bWVudGAgYW4gaW5maW5pdGUgbG9vcCB3b24ndCBvY2N1ci5cbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8yMzE3XG4gIHJldHVybiAnI2RvY3VtZW50Jztcbn1cbmZ1bmN0aW9uIGdldFdpbmRvdyhub2RlKSB7XG4gIHZhciBfbm9kZSRvd25lckRvY3VtZW50O1xuICByZXR1cm4gKG5vZGUgPT0gbnVsbCB8fCAoX25vZGUkb3duZXJEb2N1bWVudCA9IG5vZGUub3duZXJEb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJG93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXcpIHx8IHdpbmRvdztcbn1cbmZ1bmN0aW9uIGdldERvY3VtZW50RWxlbWVudChub2RlKSB7XG4gIHZhciBfcmVmO1xuICByZXR1cm4gKF9yZWYgPSAoaXNOb2RlKG5vZGUpID8gbm9kZS5vd25lckRvY3VtZW50IDogbm9kZS5kb2N1bWVudCkgfHwgd2luZG93LmRvY3VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX3JlZi5kb2N1bWVudEVsZW1lbnQ7XG59XG5mdW5jdGlvbiBpc05vZGUodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBOb2RlIHx8IHZhbHVlIGluc3RhbmNlb2YgZ2V0V2luZG93KHZhbHVlKS5Ob2RlO1xufVxuZnVuY3Rpb24gaXNFbGVtZW50KHZhbHVlKSB7XG4gIGlmICghaGFzV2luZG93KCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRWxlbWVudCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuRWxlbWVudDtcbn1cbmZ1bmN0aW9uIGlzSFRNTEVsZW1lbnQodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuSFRNTEVsZW1lbnQ7XG59XG5mdW5jdGlvbiBpc1NoYWRvd1Jvb3QodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSB8fCB0eXBlb2YgU2hhZG93Um9vdCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgU2hhZG93Um9vdCB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuU2hhZG93Um9vdDtcbn1cbmNvbnN0IGludmFsaWRPdmVyZmxvd0Rpc3BsYXlWYWx1ZXMgPSAvKiNfX1BVUkVfXyovbmV3IFNldChbJ2lubGluZScsICdjb250ZW50cyddKTtcbmZ1bmN0aW9uIGlzT3ZlcmZsb3dFbGVtZW50KGVsZW1lbnQpIHtcbiAgY29uc3Qge1xuICAgIG92ZXJmbG93LFxuICAgIG92ZXJmbG93WCxcbiAgICBvdmVyZmxvd1ksXG4gICAgZGlzcGxheVxuICB9ID0gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgcmV0dXJuIC9hdXRvfHNjcm9sbHxvdmVybGF5fGhpZGRlbnxjbGlwLy50ZXN0KG92ZXJmbG93ICsgb3ZlcmZsb3dZICsgb3ZlcmZsb3dYKSAmJiAhaW52YWxpZE92ZXJmbG93RGlzcGxheVZhbHVlcy5oYXMoZGlzcGxheSk7XG59XG5jb25zdCB0YWJsZUVsZW1lbnRzID0gLyojX19QVVJFX18qL25ldyBTZXQoWyd0YWJsZScsICd0ZCcsICd0aCddKTtcbmZ1bmN0aW9uIGlzVGFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIHRhYmxlRWxlbWVudHMuaGFzKGdldE5vZGVOYW1lKGVsZW1lbnQpKTtcbn1cbmNvbnN0IHRvcExheWVyU2VsZWN0b3JzID0gWyc6cG9wb3Zlci1vcGVuJywgJzptb2RhbCddO1xuZnVuY3Rpb24gaXNUb3BMYXllcihlbGVtZW50KSB7XG4gIHJldHVybiB0b3BMYXllclNlbGVjdG9ycy5zb21lKHNlbGVjdG9yID0+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGVsZW1lbnQubWF0Y2hlcyhzZWxlY3Rvcik7XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH0pO1xufVxuY29uc3QgdHJhbnNmb3JtUHJvcGVydGllcyA9IFsndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZScsICdzY2FsZScsICdyb3RhdGUnLCAncGVyc3BlY3RpdmUnXTtcbmNvbnN0IHdpbGxDaGFuZ2VWYWx1ZXMgPSBbJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUnLCAnc2NhbGUnLCAncm90YXRlJywgJ3BlcnNwZWN0aXZlJywgJ2ZpbHRlciddO1xuY29uc3QgY29udGFpblZhbHVlcyA9IFsncGFpbnQnLCAnbGF5b3V0JywgJ3N0cmljdCcsICdjb250ZW50J107XG5mdW5jdGlvbiBpc0NvbnRhaW5pbmdCbG9jayhlbGVtZW50T3JDc3MpIHtcbiAgY29uc3Qgd2Via2l0ID0gaXNXZWJLaXQoKTtcbiAgY29uc3QgY3NzID0gaXNFbGVtZW50KGVsZW1lbnRPckNzcykgPyBnZXRDb21wdXRlZFN0eWxlKGVsZW1lbnRPckNzcykgOiBlbGVtZW50T3JDc3M7XG5cbiAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQ1NTL0NvbnRhaW5pbmdfYmxvY2sjaWRlbnRpZnlpbmdfdGhlX2NvbnRhaW5pbmdfYmxvY2tcbiAgLy8gaHR0cHM6Ly9kcmFmdHMuY3Nzd2cub3JnL2Nzcy10cmFuc2Zvcm1zLTIvI2luZGl2aWR1YWwtdHJhbnNmb3Jtc1xuICByZXR1cm4gdHJhbnNmb3JtUHJvcGVydGllcy5zb21lKHZhbHVlID0+IGNzc1t2YWx1ZV0gPyBjc3NbdmFsdWVdICE9PSAnbm9uZScgOiBmYWxzZSkgfHwgKGNzcy5jb250YWluZXJUeXBlID8gY3NzLmNvbnRhaW5lclR5cGUgIT09ICdub3JtYWwnIDogZmFsc2UpIHx8ICF3ZWJraXQgJiYgKGNzcy5iYWNrZHJvcEZpbHRlciA/IGNzcy5iYWNrZHJvcEZpbHRlciAhPT0gJ25vbmUnIDogZmFsc2UpIHx8ICF3ZWJraXQgJiYgKGNzcy5maWx0ZXIgPyBjc3MuZmlsdGVyICE9PSAnbm9uZScgOiBmYWxzZSkgfHwgd2lsbENoYW5nZVZhbHVlcy5zb21lKHZhbHVlID0+IChjc3Mud2lsbENoYW5nZSB8fCAnJykuaW5jbHVkZXModmFsdWUpKSB8fCBjb250YWluVmFsdWVzLnNvbWUodmFsdWUgPT4gKGNzcy5jb250YWluIHx8ICcnKS5pbmNsdWRlcyh2YWx1ZSkpO1xufVxuZnVuY3Rpb24gZ2V0Q29udGFpbmluZ0Jsb2NrKGVsZW1lbnQpIHtcbiAgbGV0IGN1cnJlbnROb2RlID0gZ2V0UGFyZW50Tm9kZShlbGVtZW50KTtcbiAgd2hpbGUgKGlzSFRNTEVsZW1lbnQoY3VycmVudE5vZGUpICYmICFpc0xhc3RUcmF2ZXJzYWJsZU5vZGUoY3VycmVudE5vZGUpKSB7XG4gICAgaWYgKGlzQ29udGFpbmluZ0Jsb2NrKGN1cnJlbnROb2RlKSkge1xuICAgICAgcmV0dXJuIGN1cnJlbnROb2RlO1xuICAgIH0gZWxzZSBpZiAoaXNUb3BMYXllcihjdXJyZW50Tm9kZSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjdXJyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUoY3VycmVudE5vZGUpO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gaXNXZWJLaXQoKSB7XG4gIGlmICh0eXBlb2YgQ1NTID09PSAndW5kZWZpbmVkJyB8fCAhQ1NTLnN1cHBvcnRzKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBDU1Muc3VwcG9ydHMoJy13ZWJraXQtYmFja2Ryb3AtZmlsdGVyJywgJ25vbmUnKTtcbn1cbmNvbnN0IGxhc3RUcmF2ZXJzYWJsZU5vZGVOYW1lcyA9IC8qI19fUFVSRV9fKi9uZXcgU2V0KFsnaHRtbCcsICdib2R5JywgJyNkb2N1bWVudCddKTtcbmZ1bmN0aW9uIGlzTGFzdFRyYXZlcnNhYmxlTm9kZShub2RlKSB7XG4gIHJldHVybiBsYXN0VHJhdmVyc2FibGVOb2RlTmFtZXMuaGFzKGdldE5vZGVOYW1lKG5vZGUpKTtcbn1cbmZ1bmN0aW9uIGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkge1xuICByZXR1cm4gZ2V0V2luZG93KGVsZW1lbnQpLmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG59XG5mdW5jdGlvbiBnZXROb2RlU2Nyb2xsKGVsZW1lbnQpIHtcbiAgaWYgKGlzRWxlbWVudChlbGVtZW50KSkge1xuICAgIHJldHVybiB7XG4gICAgICBzY3JvbGxMZWZ0OiBlbGVtZW50LnNjcm9sbExlZnQsXG4gICAgICBzY3JvbGxUb3A6IGVsZW1lbnQuc2Nyb2xsVG9wXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHNjcm9sbExlZnQ6IGVsZW1lbnQuc2Nyb2xsWCxcbiAgICBzY3JvbGxUb3A6IGVsZW1lbnQuc2Nyb2xsWVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0UGFyZW50Tm9kZShub2RlKSB7XG4gIGlmIChnZXROb2RlTmFtZShub2RlKSA9PT0gJ2h0bWwnKSB7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbiAgY29uc3QgcmVzdWx0ID1cbiAgLy8gU3RlcCBpbnRvIHRoZSBzaGFkb3cgRE9NIG9mIHRoZSBwYXJlbnQgb2YgYSBzbG90dGVkIG5vZGUuXG4gIG5vZGUuYXNzaWduZWRTbG90IHx8XG4gIC8vIERPTSBFbGVtZW50IGRldGVjdGVkLlxuICBub2RlLnBhcmVudE5vZGUgfHxcbiAgLy8gU2hhZG93Um9vdCBkZXRlY3RlZC5cbiAgaXNTaGFkb3dSb290KG5vZGUpICYmIG5vZGUuaG9zdCB8fFxuICAvLyBGYWxsYmFjay5cbiAgZ2V0RG9jdW1lbnRFbGVtZW50KG5vZGUpO1xuICByZXR1cm4gaXNTaGFkb3dSb290KHJlc3VsdCkgPyByZXN1bHQuaG9zdCA6IHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yKG5vZGUpIHtcbiAgY29uc3QgcGFyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUobm9kZSk7XG4gIGlmIChpc0xhc3RUcmF2ZXJzYWJsZU5vZGUocGFyZW50Tm9kZSkpIHtcbiAgICByZXR1cm4gbm9kZS5vd25lckRvY3VtZW50ID8gbm9kZS5vd25lckRvY3VtZW50LmJvZHkgOiBub2RlLmJvZHk7XG4gIH1cbiAgaWYgKGlzSFRNTEVsZW1lbnQocGFyZW50Tm9kZSkgJiYgaXNPdmVyZmxvd0VsZW1lbnQocGFyZW50Tm9kZSkpIHtcbiAgICByZXR1cm4gcGFyZW50Tm9kZTtcbiAgfVxuICByZXR1cm4gZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3IocGFyZW50Tm9kZSk7XG59XG5mdW5jdGlvbiBnZXRPdmVyZmxvd0FuY2VzdG9ycyhub2RlLCBsaXN0LCB0cmF2ZXJzZUlmcmFtZXMpIHtcbiAgdmFyIF9ub2RlJG93bmVyRG9jdW1lbnQyO1xuICBpZiAobGlzdCA9PT0gdm9pZCAwKSB7XG4gICAgbGlzdCA9IFtdO1xuICB9XG4gIGlmICh0cmF2ZXJzZUlmcmFtZXMgPT09IHZvaWQgMCkge1xuICAgIHRyYXZlcnNlSWZyYW1lcyA9IHRydWU7XG4gIH1cbiAgY29uc3Qgc2Nyb2xsYWJsZUFuY2VzdG9yID0gZ2V0TmVhcmVzdE92ZXJmbG93QW5jZXN0b3Iobm9kZSk7XG4gIGNvbnN0IGlzQm9keSA9IHNjcm9sbGFibGVBbmNlc3RvciA9PT0gKChfbm9kZSRvd25lckRvY3VtZW50MiA9IG5vZGUub3duZXJEb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9ub2RlJG93bmVyRG9jdW1lbnQyLmJvZHkpO1xuICBjb25zdCB3aW4gPSBnZXRXaW5kb3coc2Nyb2xsYWJsZUFuY2VzdG9yKTtcbiAgaWYgKGlzQm9keSkge1xuICAgIGNvbnN0IGZyYW1lRWxlbWVudCA9IGdldEZyYW1lRWxlbWVudCh3aW4pO1xuICAgIHJldHVybiBsaXN0LmNvbmNhdCh3aW4sIHdpbi52aXN1YWxWaWV3cG9ydCB8fCBbXSwgaXNPdmVyZmxvd0VsZW1lbnQoc2Nyb2xsYWJsZUFuY2VzdG9yKSA/IHNjcm9sbGFibGVBbmNlc3RvciA6IFtdLCBmcmFtZUVsZW1lbnQgJiYgdHJhdmVyc2VJZnJhbWVzID8gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZnJhbWVFbGVtZW50KSA6IFtdKTtcbiAgfVxuICByZXR1cm4gbGlzdC5jb25jYXQoc2Nyb2xsYWJsZUFuY2VzdG9yLCBnZXRPdmVyZmxvd0FuY2VzdG9ycyhzY3JvbGxhYmxlQW5jZXN0b3IsIFtdLCB0cmF2ZXJzZUlmcmFtZXMpKTtcbn1cbmZ1bmN0aW9uIGdldEZyYW1lRWxlbWVudCh3aW4pIHtcbiAgcmV0dXJuIHdpbi5wYXJlbnQgJiYgT2JqZWN0LmdldFByb3RvdHlwZU9mKHdpbi5wYXJlbnQpID8gd2luLmZyYW1lRWxlbWVudCA6IG51bGw7XG59XG5cbmV4cG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldENvbnRhaW5pbmdCbG9jaywgZ2V0RG9jdW1lbnRFbGVtZW50LCBnZXRGcmFtZUVsZW1lbnQsIGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yLCBnZXROb2RlTmFtZSwgZ2V0Tm9kZVNjcm9sbCwgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIGdldFBhcmVudE5vZGUsIGdldFdpbmRvdywgaXNDb250YWluaW5nQmxvY2ssIGlzRWxlbWVudCwgaXNIVE1MRWxlbWVudCwgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBpc05vZGUsIGlzT3ZlcmZsb3dFbGVtZW50LCBpc1NoYWRvd1Jvb3QsIGlzVGFibGVFbGVtZW50LCBpc1RvcExheWVyLCBpc1dlYktpdCB9O1xuIiwiLyoqXG4gKiBDdXN0b20gcG9zaXRpb25pbmcgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdmlydHVhbC1lbGVtZW50c1xuICovXG5cbmNvbnN0IHNpZGVzID0gWyd0b3AnLCAncmlnaHQnLCAnYm90dG9tJywgJ2xlZnQnXTtcbmNvbnN0IGFsaWdubWVudHMgPSBbJ3N0YXJ0JywgJ2VuZCddO1xuY29uc3QgcGxhY2VtZW50cyA9IC8qI19fUFVSRV9fKi9zaWRlcy5yZWR1Y2UoKGFjYywgc2lkZSkgPT4gYWNjLmNvbmNhdChzaWRlLCBzaWRlICsgXCItXCIgKyBhbGlnbm1lbnRzWzBdLCBzaWRlICsgXCItXCIgKyBhbGlnbm1lbnRzWzFdKSwgW10pO1xuY29uc3QgbWluID0gTWF0aC5taW47XG5jb25zdCBtYXggPSBNYXRoLm1heDtcbmNvbnN0IHJvdW5kID0gTWF0aC5yb3VuZDtcbmNvbnN0IGZsb29yID0gTWF0aC5mbG9vcjtcbmNvbnN0IGNyZWF0ZUNvb3JkcyA9IHYgPT4gKHtcbiAgeDogdixcbiAgeTogdlxufSk7XG5jb25zdCBvcHBvc2l0ZVNpZGVNYXAgPSB7XG4gIGxlZnQ6ICdyaWdodCcsXG4gIHJpZ2h0OiAnbGVmdCcsXG4gIGJvdHRvbTogJ3RvcCcsXG4gIHRvcDogJ2JvdHRvbSdcbn07XG5jb25zdCBvcHBvc2l0ZUFsaWdubWVudE1hcCA9IHtcbiAgc3RhcnQ6ICdlbmQnLFxuICBlbmQ6ICdzdGFydCdcbn07XG5mdW5jdGlvbiBjbGFtcChzdGFydCwgdmFsdWUsIGVuZCkge1xuICByZXR1cm4gbWF4KHN0YXJ0LCBtaW4odmFsdWUsIGVuZCkpO1xufVxuZnVuY3Rpb24gZXZhbHVhdGUodmFsdWUsIHBhcmFtKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbicgPyB2YWx1ZShwYXJhbSkgOiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIGdldFNpZGUocGxhY2VtZW50KSB7XG4gIHJldHVybiBwbGFjZW1lbnQuc3BsaXQoJy0nKVswXTtcbn1cbmZ1bmN0aW9uIGdldEFsaWdubWVudChwbGFjZW1lbnQpIHtcbiAgcmV0dXJuIHBsYWNlbWVudC5zcGxpdCgnLScpWzFdO1xufVxuZnVuY3Rpb24gZ2V0T3Bwb3NpdGVBeGlzKGF4aXMpIHtcbiAgcmV0dXJuIGF4aXMgPT09ICd4JyA/ICd5JyA6ICd4Jztcbn1cbmZ1bmN0aW9uIGdldEF4aXNMZW5ndGgoYXhpcykge1xuICByZXR1cm4gYXhpcyA9PT0gJ3knID8gJ2hlaWdodCcgOiAnd2lkdGgnO1xufVxuY29uc3QgeUF4aXNTaWRlcyA9IC8qI19fUFVSRV9fKi9uZXcgU2V0KFsndG9wJywgJ2JvdHRvbSddKTtcbmZ1bmN0aW9uIGdldFNpZGVBeGlzKHBsYWNlbWVudCkge1xuICByZXR1cm4geUF4aXNTaWRlcy5oYXMoZ2V0U2lkZShwbGFjZW1lbnQpKSA/ICd5JyA6ICd4Jztcbn1cbmZ1bmN0aW9uIGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KSB7XG4gIHJldHVybiBnZXRPcHBvc2l0ZUF4aXMoZ2V0U2lkZUF4aXMocGxhY2VtZW50KSk7XG59XG5mdW5jdGlvbiBnZXRBbGlnbm1lbnRTaWRlcyhwbGFjZW1lbnQsIHJlY3RzLCBydGwpIHtcbiAgaWYgKHJ0bCA9PT0gdm9pZCAwKSB7XG4gICAgcnRsID0gZmFsc2U7XG4gIH1cbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGNvbnN0IGFsaWdubWVudEF4aXMgPSBnZXRBbGlnbm1lbnRBeGlzKHBsYWNlbWVudCk7XG4gIGNvbnN0IGxlbmd0aCA9IGdldEF4aXNMZW5ndGgoYWxpZ25tZW50QXhpcyk7XG4gIGxldCBtYWluQWxpZ25tZW50U2lkZSA9IGFsaWdubWVudEF4aXMgPT09ICd4JyA/IGFsaWdubWVudCA9PT0gKHJ0bCA/ICdlbmQnIDogJ3N0YXJ0JykgPyAncmlnaHQnIDogJ2xlZnQnIDogYWxpZ25tZW50ID09PSAnc3RhcnQnID8gJ2JvdHRvbScgOiAndG9wJztcbiAgaWYgKHJlY3RzLnJlZmVyZW5jZVtsZW5ndGhdID4gcmVjdHMuZmxvYXRpbmdbbGVuZ3RoXSkge1xuICAgIG1haW5BbGlnbm1lbnRTaWRlID0gZ2V0T3Bwb3NpdGVQbGFjZW1lbnQobWFpbkFsaWdubWVudFNpZGUpO1xuICB9XG4gIHJldHVybiBbbWFpbkFsaWdubWVudFNpZGUsIGdldE9wcG9zaXRlUGxhY2VtZW50KG1haW5BbGlnbm1lbnRTaWRlKV07XG59XG5mdW5jdGlvbiBnZXRFeHBhbmRlZFBsYWNlbWVudHMocGxhY2VtZW50KSB7XG4gIGNvbnN0IG9wcG9zaXRlUGxhY2VtZW50ID0gZ2V0T3Bwb3NpdGVQbGFjZW1lbnQocGxhY2VtZW50KTtcbiAgcmV0dXJuIFtnZXRPcHBvc2l0ZUFsaWdubWVudFBsYWNlbWVudChwbGFjZW1lbnQpLCBvcHBvc2l0ZVBsYWNlbWVudCwgZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQob3Bwb3NpdGVQbGFjZW1lbnQpXTtcbn1cbmZ1bmN0aW9uIGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50KHBsYWNlbWVudCkge1xuICByZXR1cm4gcGxhY2VtZW50LnJlcGxhY2UoL3N0YXJ0fGVuZC9nLCBhbGlnbm1lbnQgPT4gb3Bwb3NpdGVBbGlnbm1lbnRNYXBbYWxpZ25tZW50XSk7XG59XG5jb25zdCBsclBsYWNlbWVudCA9IFsnbGVmdCcsICdyaWdodCddO1xuY29uc3QgcmxQbGFjZW1lbnQgPSBbJ3JpZ2h0JywgJ2xlZnQnXTtcbmNvbnN0IHRiUGxhY2VtZW50ID0gWyd0b3AnLCAnYm90dG9tJ107XG5jb25zdCBidFBsYWNlbWVudCA9IFsnYm90dG9tJywgJ3RvcCddO1xuZnVuY3Rpb24gZ2V0U2lkZUxpc3Qoc2lkZSwgaXNTdGFydCwgcnRsKSB7XG4gIHN3aXRjaCAoc2lkZSkge1xuICAgIGNhc2UgJ3RvcCc6XG4gICAgY2FzZSAnYm90dG9tJzpcbiAgICAgIGlmIChydGwpIHJldHVybiBpc1N0YXJ0ID8gcmxQbGFjZW1lbnQgOiBsclBsYWNlbWVudDtcbiAgICAgIHJldHVybiBpc1N0YXJ0ID8gbHJQbGFjZW1lbnQgOiBybFBsYWNlbWVudDtcbiAgICBjYXNlICdsZWZ0JzpcbiAgICBjYXNlICdyaWdodCc6XG4gICAgICByZXR1cm4gaXNTdGFydCA/IHRiUGxhY2VtZW50IDogYnRQbGFjZW1lbnQ7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBbXTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0T3Bwb3NpdGVBeGlzUGxhY2VtZW50cyhwbGFjZW1lbnQsIGZsaXBBbGlnbm1lbnQsIGRpcmVjdGlvbiwgcnRsKSB7XG4gIGNvbnN0IGFsaWdubWVudCA9IGdldEFsaWdubWVudChwbGFjZW1lbnQpO1xuICBsZXQgbGlzdCA9IGdldFNpZGVMaXN0KGdldFNpZGUocGxhY2VtZW50KSwgZGlyZWN0aW9uID09PSAnc3RhcnQnLCBydGwpO1xuICBpZiAoYWxpZ25tZW50KSB7XG4gICAgbGlzdCA9IGxpc3QubWFwKHNpZGUgPT4gc2lkZSArIFwiLVwiICsgYWxpZ25tZW50KTtcbiAgICBpZiAoZmxpcEFsaWdubWVudCkge1xuICAgICAgbGlzdCA9IGxpc3QuY29uY2F0KGxpc3QubWFwKGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50KSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBsaXN0O1xufVxuZnVuY3Rpb24gZ2V0T3Bwb3NpdGVQbGFjZW1lbnQocGxhY2VtZW50KSB7XG4gIHJldHVybiBwbGFjZW1lbnQucmVwbGFjZSgvbGVmdHxyaWdodHxib3R0b218dG9wL2csIHNpZGUgPT4gb3Bwb3NpdGVTaWRlTWFwW3NpZGVdKTtcbn1cbmZ1bmN0aW9uIGV4cGFuZFBhZGRpbmdPYmplY3QocGFkZGluZykge1xuICByZXR1cm4ge1xuICAgIHRvcDogMCxcbiAgICByaWdodDogMCxcbiAgICBib3R0b206IDAsXG4gICAgbGVmdDogMCxcbiAgICAuLi5wYWRkaW5nXG4gIH07XG59XG5mdW5jdGlvbiBnZXRQYWRkaW5nT2JqZWN0KHBhZGRpbmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBwYWRkaW5nICE9PSAnbnVtYmVyJyA/IGV4cGFuZFBhZGRpbmdPYmplY3QocGFkZGluZykgOiB7XG4gICAgdG9wOiBwYWRkaW5nLFxuICAgIHJpZ2h0OiBwYWRkaW5nLFxuICAgIGJvdHRvbTogcGFkZGluZyxcbiAgICBsZWZ0OiBwYWRkaW5nXG4gIH07XG59XG5mdW5jdGlvbiByZWN0VG9DbGllbnRSZWN0KHJlY3QpIHtcbiAgY29uc3Qge1xuICAgIHgsXG4gICAgeSxcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSA9IHJlY3Q7XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgIHRvcDogeSxcbiAgICBsZWZ0OiB4LFxuICAgIHJpZ2h0OiB4ICsgd2lkdGgsXG4gICAgYm90dG9tOiB5ICsgaGVpZ2h0LFxuICAgIHgsXG4gICAgeVxuICB9O1xufVxuXG5leHBvcnQgeyBhbGlnbm1lbnRzLCBjbGFtcCwgY3JlYXRlQ29vcmRzLCBldmFsdWF0ZSwgZXhwYW5kUGFkZGluZ09iamVjdCwgZmxvb3IsIGdldEFsaWdubWVudCwgZ2V0QWxpZ25tZW50QXhpcywgZ2V0QWxpZ25tZW50U2lkZXMsIGdldEF4aXNMZW5ndGgsIGdldEV4cGFuZGVkUGxhY2VtZW50cywgZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQsIGdldE9wcG9zaXRlQXhpcywgZ2V0T3Bwb3NpdGVBeGlzUGxhY2VtZW50cywgZ2V0T3Bwb3NpdGVQbGFjZW1lbnQsIGdldFBhZGRpbmdPYmplY3QsIGdldFNpZGUsIGdldFNpZGVBeGlzLCBtYXgsIG1pbiwgcGxhY2VtZW50cywgcmVjdFRvQ2xpZW50UmVjdCwgcm91bmQsIHNpZGVzIH07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=