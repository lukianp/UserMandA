"use strict";
(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[1375],{

/***/ 4520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  s: () => (/* binding */ Legend)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(40961);
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/legendPortalContext.js
var legendPortalContext = __webpack_require__(55846);
// EXTERNAL MODULE: ./node_modules/recharts/es6/component/DefaultLegendContent.js
var DefaultLegendContent = __webpack_require__(7275);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/DataUtils.js
var DataUtils = __webpack_require__(59744);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/payload/getUniqPayload.js
var getUniqPayload = __webpack_require__(79799);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/hooks.js
var hooks = __webpack_require__(49082);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/legendSelectors.js
var legendSelectors = __webpack_require__(47962);
;// ./node_modules/recharts/es6/context/legendPayloadContext.js



/**
 * Use this hook in Legend, or anywhere else where you want to read the current Legend items.
 * @return all Legend items ready to be rendered
 */
function useLegendPayload() {
  return (0,hooks/* useAppSelector */.G)(legendSelectors/* selectLegendPayload */.g0);
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/useElementOffset.js
var useElementOffset = __webpack_require__(66583);
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/chartLayoutContext.js
var chartLayoutContext = __webpack_require__(19287);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/legendSlice.js
var legendSlice = __webpack_require__(91283);
;// ./node_modules/recharts/es6/component/Legend.js
var _excluded = ["contextPayload"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }












function defaultUniqBy(entry) {
  return entry.value;
}
function LegendContent(props) {
  var {
      contextPayload
    } = props,
    otherProps = _objectWithoutProperties(props, _excluded);
  var finalPayload = (0,getUniqPayload/* getUniqPayload */.s)(contextPayload, props.payloadUniqBy, defaultUniqBy);
  var contentProps = _objectSpread(_objectSpread({}, otherProps), {}, {
    payload: finalPayload
  });
  if (/*#__PURE__*/react.isValidElement(props.content)) {
    return /*#__PURE__*/react.cloneElement(props.content, contentProps);
  }
  if (typeof props.content === 'function') {
    return /*#__PURE__*/react.createElement(props.content, contentProps);
  }
  return /*#__PURE__*/react.createElement(DefaultLegendContent/* DefaultLegendContent */.g, contentProps);
}
function getDefaultPosition(style, props, margin, chartWidth, chartHeight, box) {
  var {
    layout,
    align,
    verticalAlign
  } = props;
  var hPos, vPos;
  if (!style || (style.left === undefined || style.left === null) && (style.right === undefined || style.right === null)) {
    if (align === 'center' && layout === 'vertical') {
      hPos = {
        left: ((chartWidth || 0) - box.width) / 2
      };
    } else {
      hPos = align === 'right' ? {
        right: margin && margin.right || 0
      } : {
        left: margin && margin.left || 0
      };
    }
  }
  if (!style || (style.top === undefined || style.top === null) && (style.bottom === undefined || style.bottom === null)) {
    if (verticalAlign === 'middle') {
      vPos = {
        top: ((chartHeight || 0) - box.height) / 2
      };
    } else {
      vPos = verticalAlign === 'bottom' ? {
        bottom: margin && margin.bottom || 0
      } : {
        top: margin && margin.top || 0
      };
    }
  }
  return _objectSpread(_objectSpread({}, hPos), vPos);
}
function LegendSettingsDispatcher(props) {
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  (0,react.useEffect)(() => {
    dispatch((0,legendSlice/* setLegendSettings */.h1)(props));
  }, [dispatch, props]);
  return null;
}
function LegendSizeDispatcher(props) {
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  (0,react.useEffect)(() => {
    dispatch((0,legendSlice/* setLegendSize */.hx)(props));
    return () => {
      dispatch((0,legendSlice/* setLegendSize */.hx)({
        width: 0,
        height: 0
      }));
    };
  }, [dispatch, props]);
  return null;
}
function LegendWrapper(props) {
  var contextPayload = useLegendPayload();
  var legendPortalFromContext = (0,legendPortalContext/* useLegendPortal */.M)();
  var margin = (0,chartLayoutContext/* useMargin */.Kp)();
  var {
    width: widthFromProps,
    height: heightFromProps,
    wrapperStyle,
    portal: portalFromProps
  } = props;
  // The contextPayload is not used directly inside the hook, but we need the onBBoxUpdate call
  // when the payload changes, therefore it's here as a dependency.
  var [lastBoundingBox, updateBoundingBox] = (0,useElementOffset/* useElementOffset */.V)([contextPayload]);
  var chartWidth = (0,chartLayoutContext/* useChartWidth */.yi)();
  var chartHeight = (0,chartLayoutContext/* useChartHeight */.rY)();
  if (chartWidth == null || chartHeight == null) {
    return null;
  }
  var maxWidth = chartWidth - (margin.left || 0) - (margin.right || 0);
  // eslint-disable-next-line @typescript-eslint/no-use-before-define
  var widthOrHeight = Legend.getWidthOrHeight(props.layout, heightFromProps, widthFromProps, maxWidth);
  // if the user supplies their own portal, only use their defined wrapper styles
  var outerStyle = portalFromProps ? wrapperStyle : _objectSpread(_objectSpread({
    position: 'absolute',
    width: (widthOrHeight === null || widthOrHeight === void 0 ? void 0 : widthOrHeight.width) || widthFromProps || 'auto',
    height: (widthOrHeight === null || widthOrHeight === void 0 ? void 0 : widthOrHeight.height) || heightFromProps || 'auto'
  }, getDefaultPosition(wrapperStyle, props, margin, chartWidth, chartHeight, lastBoundingBox)), wrapperStyle);
  var legendPortal = portalFromProps !== null && portalFromProps !== void 0 ? portalFromProps : legendPortalFromContext;
  if (legendPortal == null) {
    return null;
  }
  var legendElement = /*#__PURE__*/react.createElement("div", {
    className: "recharts-legend-wrapper",
    style: outerStyle,
    ref: updateBoundingBox
  }, /*#__PURE__*/react.createElement(LegendSettingsDispatcher, {
    layout: props.layout,
    align: props.align,
    verticalAlign: props.verticalAlign,
    itemSorter: props.itemSorter
  }), /*#__PURE__*/react.createElement(LegendSizeDispatcher, {
    width: lastBoundingBox.width,
    height: lastBoundingBox.height
  }), /*#__PURE__*/react.createElement(LegendContent, _extends({}, props, widthOrHeight, {
    margin: margin,
    chartWidth: chartWidth,
    chartHeight: chartHeight,
    contextPayload: contextPayload
  })));
  return /*#__PURE__*/(0,react_dom.createPortal)(legendElement, legendPortal);
}
class Legend extends react.PureComponent {
  static getWidthOrHeight(layout, height, width, maxWidth) {
    if (layout === 'vertical' && (0,DataUtils/* isNumber */.Et)(height)) {
      return {
        height
      };
    }
    if (layout === 'horizontal') {
      return {
        width: width || maxWidth
      };
    }
    return null;
  }
  render() {
    return /*#__PURE__*/react.createElement(LegendWrapper, this.props);
  }
}
_defineProperty(Legend, "displayName", 'Legend');
_defineProperty(Legend, "defaultProps", {
  align: 'center',
  iconSize: 14,
  itemSorter: 'value',
  layout: 'horizontal',
  verticalAlign: 'bottom'
});

/***/ }),

/***/ 5298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G9: () => (/* binding */ useErrorBarContext),
/* harmony export */   pU: () => (/* binding */ ReportErrorBarSettings),
/* harmony export */   zk: () => (/* binding */ SetErrorBarContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _state_errorBarSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32117);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49082);
/* harmony import */ var _RegisterGraphicalItemId__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(84044);
var _excluded = ["children"];
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }





var initialContextState = {
  data: [],
  xAxisId: 'xAxis-0',
  yAxisId: 'yAxis-0',
  dataPointFormatter: () => ({
    x: 0,
    y: 0,
    value: 0
  }),
  errorBarOffset: 0
};
var ErrorBarContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(initialContextState);
function SetErrorBarContext(props) {
  var {
      children
    } = props,
    rest = _objectWithoutProperties(props, _excluded);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(ErrorBarContext.Provider, {
    value: rest
  }, children);
}
var useErrorBarContext = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ErrorBarContext);
function ReportErrorBarSettings(props) {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .j)();
  var graphicalItemId = (0,_RegisterGraphicalItemId__WEBPACK_IMPORTED_MODULE_3__/* .useGraphicalItemId */ .N)();
  var prevPropsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (graphicalItemId == null) {
      // ErrorBar outside a graphical item context does not do anything.
      return;
    }
    if (prevPropsRef.current === null) {
      dispatch((0,_state_errorBarSlice__WEBPACK_IMPORTED_MODULE_1__/* .addErrorBar */ .h7)({
        itemId: graphicalItemId,
        errorBar: props
      }));
    } else if (prevPropsRef.current !== props) {
      dispatch((0,_state_errorBarSlice__WEBPACK_IMPORTED_MODULE_1__/* .replaceErrorBar */ .UL)({
        itemId: graphicalItemId,
        prev: prevPropsRef.current,
        next: props
      }));
    }
    prevPropsRef.current = props;
  }, [dispatch, graphicalItemId, props]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    return () => {
      if (prevPropsRef.current != null) {
        dispatch((0,_state_errorBarSlice__WEBPACK_IMPORTED_MODULE_1__/* .removeErrorBar */ .I)({
          itemId: graphicalItemId,
          errorBar: prevPropsRef.current
        }));
        prevPropsRef.current = null;
      }
    };
  }, [dispatch, graphicalItemId]);
  return null;
}

/***/ }),

/***/ 5614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dL: () => (/* binding */ PolarLabelListContextProvider),
/* harmony export */   h8: () => (/* binding */ CartesianLabelListContextProvider),
/* harmony export */   qY: () => (/* binding */ LabelListFromLabelProp)
/* harmony export */ });
/* unused harmony export LabelList */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var es_toolkit_compat_last__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20025);
/* harmony import */ var es_toolkit_compat_last__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_last__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Label__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(91706);
/* harmony import */ var _container_Layer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86069);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33964);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59744);
/* harmony import */ var _util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(80196);
var _excluded = ["valueAccessor"],
  _excluded2 = ["dataKey", "clockWise", "id", "textBreakAll"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }









/**
 * This is public API because we expose it as the valueAccessor parameter.
 *
 * The properties of "viewBox" are repeated as the root props of the entry object.
 * So it doesn't matter if you read entry.x or entry.viewBox.x, they are the same.
 *
 * It's not necessary to pass redundant data, but we keep it for backward compatibility.
 */

/**
 * LabelList props do not allow refs because the same props are reused in multiple elements so we don't have a good single place to ref to.
 */

/**
 * This is the type accepted for the `label` prop on various graphical items.
 * It accepts:
 *
 * boolean:
 *    true = labels show,
 *    false = labels don't show
 * React element:
 *    will be cloned with extra props
 * function:
 *    is used as <Label content={function} />, so this will be called once for each individual label (so typically once for each data point)
 * object:
 *    the props to be passed to a LabelList component
 */

var defaultAccessor = entry => Array.isArray(entry.value) ? es_toolkit_compat_last__WEBPACK_IMPORTED_MODULE_1___default()(entry.value) : entry.value;
var CartesianLabelListContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
var CartesianLabelListContextProvider = CartesianLabelListContext.Provider;
var PolarLabelListContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
var PolarLabelListContextProvider = PolarLabelListContext.Provider;
function useCartesianLabelListContext() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(CartesianLabelListContext);
}
function usePolarLabelListContext() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(PolarLabelListContext);
}
function LabelList(_ref) {
  var {
      valueAccessor = defaultAccessor
    } = _ref,
    restProps = _objectWithoutProperties(_ref, _excluded);
  var {
      dataKey,
      clockWise,
      id,
      textBreakAll
    } = restProps,
    others = _objectWithoutProperties(restProps, _excluded2);
  var cartesianData = useCartesianLabelListContext();
  var polarData = usePolarLabelListContext();
  var data = cartesianData || polarData;
  if (!data || !data.length) {
    return null;
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_container_Layer__WEBPACK_IMPORTED_MODULE_3__/* .Layer */ .W, {
    className: "recharts-label-list"
  }, data.map((entry, index) => {
    var _restProps$fill;
    var value = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_5__/* .isNullish */ .uy)(dataKey) ? valueAccessor(entry, index) : (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__/* .getValueByDataKey */ .kr)(entry && entry.payload, dataKey);
    var idProps = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_5__/* .isNullish */ .uy)(id) ? {} : {
      id: "".concat(id, "-").concat(index)
    };
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Label__WEBPACK_IMPORTED_MODULE_2__/* .Label */ .JU, _extends({
      key: "label-".concat(index) // eslint-disable-line react/no-array-index-key
    }, (0,_util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_6__/* .svgPropertiesAndEvents */ .a)(entry), others, idProps, {
      /*
       * Prefer to use the explicit fill from LabelList props.
       * Only in an absence of that, fall back to the fill of the entry.
       * The entry fill can be quite difficult to see especially in Bar, Pie, RadialBar in inside positions.
       * On the other hand it's quite convenient in Scatter, Line, or when the position is outside the Bar, Pie filled shapes.
       */
      fill: (_restProps$fill = restProps.fill) !== null && _restProps$fill !== void 0 ? _restProps$fill : entry.fill,
      parentViewBox: entry.parentViewBox,
      value: value,
      textBreakAll: textBreakAll,
      viewBox: entry.viewBox,
      index: index
    }));
  }));
}
LabelList.displayName = 'LabelList';
function LabelListFromLabelProp(_ref2) {
  var {
    label
  } = _ref2;
  if (!label) {
    return null;
  }
  if (label === true) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(LabelList, {
      key: "labelList-implicit"
    });
  }
  if (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.isValidElement(label) || (0,_Label__WEBPACK_IMPORTED_MODULE_2__/* .isLabelContentAFunction */ .ZY)(label)) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(LabelList, {
      key: "labelList-implicit",
      content: label
    });
  }
  if (typeof label === 'object') {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(LabelList, _extends({
      key: "labelList-implicit"
    }, label, {
      type: String(label.type)
    }));
  }
  return null;
}

/***/ }),

/***/ 7275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ DefaultLegendContent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34164);
/* harmony import */ var _container_Surface__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49303);
/* harmony import */ var _shape_Symbols__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65787);
/* harmony import */ var _util_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98940);
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/**
 * @fileOverview Default Legend Content
 */






var SIZE = 32;
class DefaultLegendContent extends react__WEBPACK_IMPORTED_MODULE_0__.PureComponent {
  /**
   * Render the path of icon
   * @param data Data of each legend item
   * @param iconType if defined, it will always render this icon. If undefined then it uses icon from data.type
   * @return Path element
   */
  renderIcon(data, iconType) {
    var {
      inactiveColor
    } = this.props;
    var halfSize = SIZE / 2;
    var sixthSize = SIZE / 6;
    var thirdSize = SIZE / 3;
    var color = data.inactive ? inactiveColor : data.color;
    var preferredIcon = iconType !== null && iconType !== void 0 ? iconType : data.type;
    if (preferredIcon === 'none') {
      return null;
    }
    if (preferredIcon === 'plainline') {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("line", {
        strokeWidth: 4,
        fill: "none",
        stroke: color,
        strokeDasharray: data.payload.strokeDasharray,
        x1: 0,
        y1: halfSize,
        x2: SIZE,
        y2: halfSize,
        className: "recharts-legend-icon"
      });
    }
    if (preferredIcon === 'line') {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
        strokeWidth: 4,
        fill: "none",
        stroke: color,
        d: "M0,".concat(halfSize, "h").concat(thirdSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(2 * thirdSize, ",").concat(halfSize, "\n            H").concat(SIZE, "M").concat(2 * thirdSize, ",").concat(halfSize, "\n            A").concat(sixthSize, ",").concat(sixthSize, ",0,1,1,").concat(thirdSize, ",").concat(halfSize),
        className: "recharts-legend-icon"
      });
    }
    if (preferredIcon === 'rect') {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
        stroke: "none",
        fill: color,
        d: "M0,".concat(SIZE / 8, "h").concat(SIZE, "v").concat(SIZE * 3 / 4, "h").concat(-SIZE, "z"),
        className: "recharts-legend-icon"
      });
    }
    if (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.isValidElement(data.legendIcon)) {
      var iconProps = _objectSpread({}, data);
      delete iconProps.legendIcon;
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.cloneElement(data.legendIcon, iconProps);
    }
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Symbols__WEBPACK_IMPORTED_MODULE_3__/* .Symbols */ .i, {
      fill: color,
      cx: halfSize,
      cy: halfSize,
      size: SIZE,
      sizeType: "diameter",
      type: preferredIcon
    });
  }

  /**
   * Draw items of legend
   * @return Items
   */
  renderItems() {
    var {
      payload,
      iconSize,
      layout,
      formatter,
      inactiveColor,
      iconType
    } = this.props;
    var viewBox = {
      x: 0,
      y: 0,
      width: SIZE,
      height: SIZE
    };
    var itemStyle = {
      display: layout === 'horizontal' ? 'inline-block' : 'block',
      marginRight: 10
    };
    var svgStyle = {
      display: 'inline-block',
      verticalAlign: 'middle',
      marginRight: 4
    };
    return payload.map((entry, i) => {
      var finalFormatter = entry.formatter || formatter;
      var className = (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)({
        'recharts-legend-item': true,
        ["legend-item-".concat(i)]: true,
        inactive: entry.inactive
      });
      if (entry.type === 'none') {
        return null;
      }
      var color = entry.inactive ? inactiveColor : entry.color;
      var finalValue = finalFormatter ? finalFormatter(entry.value, entry, i) : entry.value;
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", _extends({
        className: className,
        style: itemStyle
        // eslint-disable-next-line react/no-array-index-key
        ,
        key: "legend-item-".concat(i)
      }, (0,_util_types__WEBPACK_IMPORTED_MODULE_4__/* .adaptEventsOfChild */ .X)(this.props, entry, i)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_container_Surface__WEBPACK_IMPORTED_MODULE_2__/* .Surface */ .u, {
        width: iconSize,
        height: iconSize,
        viewBox: viewBox,
        style: svgStyle,
        "aria-label": "".concat(finalValue, " legend icon")
      }, this.renderIcon(entry, iconType)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
        className: "recharts-legend-item-text",
        style: {
          color
        }
      }, finalValue));
    });
  }
  render() {
    var {
      payload,
      layout,
      align
    } = this.props;
    if (!payload || !payload.length) {
      return null;
    }
    var finalStyle = {
      padding: 0,
      margin: 0,
      textAlign: layout === 'horizontal' ? align : 'left'
    };
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", {
      className: "recharts-default-legend",
      style: finalStyle
    }, this.renderItems());
  }
}
_defineProperty(DefaultLegendContent, "displayName", 'Legend');
_defineProperty(DefaultLegendContent, "defaultProps", {
  align: 'center',
  iconSize: 14,
  inactiveColor: '#ccc',
  layout: 'horizontal',
  verticalAlign: 'middle'
});

/***/ }),

/***/ 12070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: () => (/* binding */ PanoramaContextProvider),
/* harmony export */   r: () => (/* binding */ useIsPanorama)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);


var PanoramaContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
var useIsPanorama = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(PanoramaContext) != null;
var PanoramaContextProvider = _ref => {
  var {
    children
  } = _ref;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(PanoramaContext.Provider, {
    value: true
  }, children);
};

/***/ }),

/***/ 18689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ DefaultTooltipContent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60184);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34164);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59744);
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/**
 * @fileOverview Default Tooltip Content
 */





function defaultFormatter(value) {
  return Array.isArray(value) && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(value[0]) && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(value[1]) ? value.join(' ~ ') : value;
}
var DefaultTooltipContent = props => {
  var {
    separator = ' : ',
    contentStyle = {},
    itemStyle = {},
    labelStyle = {},
    payload,
    formatter,
    itemSorter,
    wrapperClassName,
    labelClassName,
    label,
    labelFormatter,
    accessibilityLayer = false
  } = props;
  var renderContent = () => {
    if (payload && payload.length) {
      var listStyle = {
        padding: 0,
        margin: 0
      };
      var items = (itemSorter ? es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default()(payload, itemSorter) : payload).map((entry, i) => {
        if (entry.type === 'none') {
          return null;
        }
        var finalFormatter = entry.formatter || formatter || defaultFormatter;
        var {
          value,
          name
        } = entry;
        var finalValue = value;
        var finalName = name;
        if (finalFormatter) {
          var formatted = finalFormatter(value, name, entry, i, payload);
          if (Array.isArray(formatted)) {
            [finalValue, finalName] = formatted;
          } else if (formatted != null) {
            finalValue = formatted;
          } else {
            return null;
          }
        }
        var finalItemStyle = _objectSpread({
          display: 'block',
          paddingTop: 4,
          paddingBottom: 4,
          color: entry.color || '#000'
        }, itemStyle);
        return (
          /*#__PURE__*/
          // eslint-disable-next-line react/no-array-index-key
          react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", {
            className: "recharts-tooltip-item",
            key: "tooltip-item-".concat(i),
            style: finalItemStyle
          }, (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(finalName) ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
            className: "recharts-tooltip-item-name"
          }, finalName) : null, (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(finalName) ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
            className: "recharts-tooltip-item-separator"
          }, separator) : null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
            className: "recharts-tooltip-item-value"
          }, finalValue), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
            className: "recharts-tooltip-item-unit"
          }, entry.unit || ''))
        );
      });
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", {
        className: "recharts-tooltip-item-list",
        style: listStyle
      }, items);
    }
    return null;
  };
  var finalStyle = _objectSpread({
    margin: 0,
    padding: 10,
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    whiteSpace: 'nowrap'
  }, contentStyle);
  var finalLabelStyle = _objectSpread({
    margin: 0
  }, labelStyle);
  var hasLabel = !(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(label);
  var finalLabel = hasLabel ? label : '';
  var wrapperCN = (0,clsx__WEBPACK_IMPORTED_MODULE_2__/* .clsx */ .$)('recharts-default-tooltip', wrapperClassName);
  var labelCN = (0,clsx__WEBPACK_IMPORTED_MODULE_2__/* .clsx */ .$)('recharts-tooltip-label', labelClassName);
  if (hasLabel && labelFormatter && payload !== undefined && payload !== null) {
    finalLabel = labelFormatter(label, payload);
  }
  var accessibilityAttributes = accessibilityLayer ? {
    role: 'status',
    'aria-live': 'assertive'
  } : {};
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", _extends({
    className: wrapperCN,
    style: finalStyle
  }, accessibilityAttributes), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", {
    className: labelCN,
    style: finalLabelStyle
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.isValidElement(finalLabel) ? finalLabel : "".concat(finalLabel)), renderContent());
};

/***/ }),

/***/ 19287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A3: () => (/* binding */ ReportChartSize),
/* harmony export */   Ft: () => (/* binding */ ReportChartMargin),
/* harmony export */   Kp: () => (/* binding */ useMargin),
/* harmony export */   W7: () => (/* binding */ useOffsetInternal),
/* harmony export */   WX: () => (/* binding */ useChartLayout),
/* harmony export */   fz: () => (/* binding */ selectChartLayout),
/* harmony export */   rY: () => (/* binding */ useChartHeight),
/* harmony export */   sk: () => (/* binding */ useViewBox),
/* harmony export */   yi: () => (/* binding */ useChartWidth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49082);
/* harmony import */ var _state_layoutSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66426);
/* harmony import */ var _state_selectors_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36189);
/* harmony import */ var _state_selectors_containerSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5180);
/* harmony import */ var _PanoramaContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(12070);
/* harmony import */ var _state_selectors_brushSelectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76461);
/* harmony import */ var _component_ResponsiveContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(28482);
/* harmony import */ var _util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8813);









var useViewBox = () => {
  var _useAppSelector;
  var panorama = (0,_PanoramaContext__WEBPACK_IMPORTED_MODULE_5__/* .useIsPanorama */ .r)();
  var rootViewBox = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__/* .selectChartViewBox */ .Ds);
  var brushDimensions = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_brushSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectBrushDimensions */ .U);
  var brushPadding = (_useAppSelector = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_brushSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectBrushSettings */ .C)) === null || _useAppSelector === void 0 ? void 0 : _useAppSelector.padding;
  if (!panorama || !brushDimensions || !brushPadding) {
    return rootViewBox;
  }
  return {
    width: brushDimensions.width - brushPadding.left - brushPadding.right,
    height: brushDimensions.height - brushPadding.top - brushPadding.bottom,
    x: brushPadding.left,
    y: brushPadding.top
  };
};
var manyComponentsThrowErrorsIfOffsetIsUndefined = {
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  width: 0,
  height: 0,
  brushBottom: 0
};
/**
 * For internal use only. If you want this information, `import { useOffset } from 'recharts'` instead.
 *
 * Returns the offset of the chart in pixels.
 *
 * @returns {ChartOffsetInternal} The offset of the chart in pixels, or a default value if not in a chart context.
 */
var useOffsetInternal = () => {
  var _useAppSelector2;
  return (_useAppSelector2 = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__/* .selectChartOffsetInternal */ .HZ)) !== null && _useAppSelector2 !== void 0 ? _useAppSelector2 : manyComponentsThrowErrorsIfOffsetIsUndefined;
};

/**
 * Returns the width of the chart in pixels.
 *
 * If you are using chart with hardcoded `width` prop, then the width returned will be the same
 * as the `width` prop on the main chart element.
 *
 * If you are using a chart with a `ResponsiveContainer`, the width will be the size of the chart
 * as the ResponsiveContainer has decided it would be.
 *
 * If the chart has any axes or legend, the `width` will be the size of the chart
 * including the axes and legend. Meaning: adding axes and legend will not change the width.
 *
 * The dimensions do not scale, meaning as user zoom in and out, the width number will not change
 * as the chart gets visually larger or smaller.
 *
 * Returns `undefined` if used outside a chart context.
 *
 * @returns {number | undefined} The width of the chart in pixels, or `undefined` if not in a chart context.
 */
var useChartWidth = () => {
  return (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_containerSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectChartWidth */ .Lp);
};

/**
 * Returns the height of the chart in pixels.
 *
 * If you are using chart with hardcoded `height` props, then the height returned will be the same
 * as the `height` prop on the main chart element.
 *
 * If you are using a chart with a `ResponsiveContainer`, the height will be the size of the chart
 * as the ResponsiveContainer has decided it would be.
 *
 * If the chart has any axes or legend, the `height` will be the size of the chart
 * including the axes and legend. Meaning: adding axes and legend will not change the height.
 *
 * The dimensions do not scale, meaning as user zoom in and out, the height number will not change
 * as the chart gets visually larger or smaller.
 *
 * Returns `undefined` if used outside a chart context.
 *
 * @returns {number | undefined} The height of the chart in pixels, or `undefined` if not in a chart context.
 */
var useChartHeight = () => {
  return (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_containerSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectChartHeight */ .A$);
};

/**
 * Margin is the empty space around the chart. Excludes axes and legend and brushes and the like.
 * This is declared by the user in the chart props.
 * If you are interested in the space occupied by axes, legend, or brushes,
 * use `useOffset` instead.
 *
 * Returns `undefined` if used outside a chart context.
 *
 * @returns {Margin | undefined} The margin of the chart in pixels, or `undefined` if not in a chart context.
 */
var useMargin = () => {
  return (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(state => state.layout.margin);
};
var selectChartLayout = state => state.layout.layoutType;
var useChartLayout = () => (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(selectChartLayout);
var ReportChartSize = props => {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .j)();

  /*
   * Skip dispatching properties in panorama chart for two reasons:
   * 1. The root chart should be deciding on these properties, and
   * 2. Brush reads these properties from redux store, and so they must remain stable
   *      to avoid circular dependency and infinite re-rendering.
   */
  var isPanorama = (0,_PanoramaContext__WEBPACK_IMPORTED_MODULE_5__/* .useIsPanorama */ .r)();
  var {
    width: widthFromProps,
    height: heightFromProps
  } = props;
  var responsiveContainerCalculations = (0,_component_ResponsiveContainer__WEBPACK_IMPORTED_MODULE_7__/* .useResponsiveContainerContext */ .w)();
  var width = widthFromProps;
  var height = heightFromProps;
  if (responsiveContainerCalculations) {
    /*
     * In case we receive width and height from ResponsiveContainer,
     * we will always prefer those.
     * Only in case ResponsiveContainer does not provide width or height,
     * we will fall back to the explicitly provided width and height.
     *
     * This to me feels backwards - we should allow override by the more specific props on individual charts, right?
     * But this is 3.x behaviour, so let's keep it for backwards compatibility.
     *
     * We can change this in 4.x if we want to.
     */
    width = responsiveContainerCalculations.width > 0 ? responsiveContainerCalculations.width : widthFromProps;
    height = responsiveContainerCalculations.height > 0 ? responsiveContainerCalculations.height : heightFromProps;
  }
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!isPanorama && (0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_8__/* .isPositiveNumber */ .F)(width) && (0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_8__/* .isPositiveNumber */ .F)(height)) {
      dispatch((0,_state_layoutSlice__WEBPACK_IMPORTED_MODULE_2__/* .setChartSize */ .gX)({
        width,
        height
      }));
    }
  }, [dispatch, isPanorama, width, height]);
  return null;
};
var ReportChartMargin = _ref => {
  var {
    margin
  } = _ref;
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .j)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    dispatch((0,_state_layoutSlice__WEBPACK_IMPORTED_MODULE_2__/* .setMargin */ .B_)(margin));
  }, [dispatch, margin]);
  return null;
};

/***/ }),

/***/ 20261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ Text)
/* harmony export */ });
/* unused harmony export getWordsByLines */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34164);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59744);
/* harmony import */ var _util_Global__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59938);
/* harmony import */ var _util_DOMUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(81636);
/* harmony import */ var _util_ReduceCSSCalc__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(90013);
/* harmony import */ var _util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(80196);
var _excluded = ["x", "y", "lineHeight", "capHeight", "scaleToFit", "textAnchor", "verticalAnchor", "fill"],
  _excluded2 = ["dx", "dy", "angle", "className", "breakAll"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }








var BREAKING_SPACES = /[ \f\n\r\t\v\u2028\u2029]+/;
var calculateWordWidths = _ref => {
  var {
    children,
    breakAll,
    style
  } = _ref;
  try {
    var words = [];
    if (!(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNullish */ .uy)(children)) {
      if (breakAll) {
        words = children.toString().split('');
      } else {
        words = children.toString().split(BREAKING_SPACES);
      }
    }
    var wordsWithComputedWidth = words.map(word => ({
      word,
      width: (0,_util_DOMUtils__WEBPACK_IMPORTED_MODULE_4__/* .getStringSize */ .Pu)(word, style).width
    }));
    var spaceWidth = breakAll ? 0 : (0,_util_DOMUtils__WEBPACK_IMPORTED_MODULE_4__/* .getStringSize */ .Pu)('\u00A0', style).width;
    return {
      wordsWithComputedWidth,
      spaceWidth
    };
  } catch (_unused) {
    return null;
  }
};
var calculateWordsByLines = (_ref2, initialWordsWithComputedWith, spaceWidth, lineWidth, scaleToFit) => {
  var {
    maxLines,
    children,
    style,
    breakAll
  } = _ref2;
  var shouldLimitLines = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumber */ .Et)(maxLines);
  var text = children;
  var calculate = function calculate() {
    var words = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    return words.reduce((result, _ref3) => {
      var {
        word,
        width
      } = _ref3;
      var currentLine = result[result.length - 1];
      if (currentLine && (lineWidth == null || scaleToFit || currentLine.width + width + spaceWidth < Number(lineWidth))) {
        // Word can be added to an existing line
        currentLine.words.push(word);
        currentLine.width += width + spaceWidth;
      } else {
        // Add first word to line or word is too long to scaleToFit on existing line
        var newLine = {
          words: [word],
          width
        };
        result.push(newLine);
      }
      return result;
    }, []);
  };
  var originalResult = calculate(initialWordsWithComputedWith);
  var findLongestLine = words => words.reduce((a, b) => a.width > b.width ? a : b);
  if (!shouldLimitLines || scaleToFit) {
    return originalResult;
  }
  var overflows = originalResult.length > maxLines || findLongestLine(originalResult).width > Number(lineWidth);
  if (!overflows) {
    return originalResult;
  }
  var suffix = '…';
  var checkOverflow = index => {
    var tempText = text.slice(0, index);
    var words = calculateWordWidths({
      breakAll,
      style,
      children: tempText + suffix
    }).wordsWithComputedWidth;
    var result = calculate(words);
    var doesOverflow = result.length > maxLines || findLongestLine(result).width > Number(lineWidth);
    return [doesOverflow, result];
  };
  var start = 0;
  var end = text.length - 1;
  var iterations = 0;
  var trimmedResult;
  while (start <= end && iterations <= text.length - 1) {
    var middle = Math.floor((start + end) / 2);
    var prev = middle - 1;
    var [doesPrevOverflow, result] = checkOverflow(prev);
    var [doesMiddleOverflow] = checkOverflow(middle);
    if (!doesPrevOverflow && !doesMiddleOverflow) {
      start = middle + 1;
    }
    if (doesPrevOverflow && doesMiddleOverflow) {
      end = middle - 1;
    }
    if (!doesPrevOverflow && doesMiddleOverflow) {
      trimmedResult = result;
      break;
    }
    iterations++;
  }

  // Fallback to originalResult (result without trimming) if we cannot find the
  // where to trim.  This should not happen :tm:
  return trimmedResult || originalResult;
};
var getWordsWithoutCalculate = children => {
  var words = !(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNullish */ .uy)(children) ? children.toString().split(BREAKING_SPACES) : [];
  return [{
    words
  }];
};
var getWordsByLines = _ref4 => {
  var {
    width,
    scaleToFit,
    children,
    style,
    breakAll,
    maxLines
  } = _ref4;
  // Only perform calculations if using features that require them (multiline, scaleToFit)
  if ((width || scaleToFit) && !_util_Global__WEBPACK_IMPORTED_MODULE_3__/* .Global */ .m.isSsr) {
    var wordsWithComputedWidth, spaceWidth;
    var wordWidths = calculateWordWidths({
      breakAll,
      children,
      style
    });
    if (wordWidths) {
      var {
        wordsWithComputedWidth: wcw,
        spaceWidth: sw
      } = wordWidths;
      wordsWithComputedWidth = wcw;
      spaceWidth = sw;
    } else {
      return getWordsWithoutCalculate(children);
    }
    return calculateWordsByLines({
      breakAll,
      children,
      maxLines,
      style
    }, wordsWithComputedWidth, spaceWidth, width, scaleToFit);
  }
  return getWordsWithoutCalculate(children);
};
var DEFAULT_FILL = '#808080';
var Text = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((_ref5, ref) => {
  var {
      x: propsX = 0,
      y: propsY = 0,
      lineHeight = '1em',
      // Magic number from d3
      capHeight = '0.71em',
      scaleToFit = false,
      textAnchor = 'start',
      // Maintain compat with existing charts / default SVG behavior
      verticalAnchor = 'end',
      fill = DEFAULT_FILL
    } = _ref5,
    props = _objectWithoutProperties(_ref5, _excluded);
  var wordsByLines = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    return getWordsByLines({
      breakAll: props.breakAll,
      children: props.children,
      maxLines: props.maxLines,
      scaleToFit,
      style: props.style,
      width: props.width
    });
  }, [props.breakAll, props.children, props.maxLines, scaleToFit, props.style, props.width]);
  var {
      dx,
      dy,
      angle,
      className,
      breakAll
    } = props,
    textProps = _objectWithoutProperties(props, _excluded2);
  if (!(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumOrStr */ .vh)(propsX) || !(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumOrStr */ .vh)(propsY) || wordsByLines.length === 0) {
    return null;
  }
  var x = propsX + ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumber */ .Et)(dx) ? dx : 0);
  var y = propsY + ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumber */ .Et)(dy) ? dy : 0);
  var startDy;
  switch (verticalAnchor) {
    case 'start':
      startDy = (0,_util_ReduceCSSCalc__WEBPACK_IMPORTED_MODULE_5__/* .reduceCSSCalc */ .l)("calc(".concat(capHeight, ")"));
      break;
    case 'middle':
      startDy = (0,_util_ReduceCSSCalc__WEBPACK_IMPORTED_MODULE_5__/* .reduceCSSCalc */ .l)("calc(".concat((wordsByLines.length - 1) / 2, " * -").concat(lineHeight, " + (").concat(capHeight, " / 2))"));
      break;
    default:
      startDy = (0,_util_ReduceCSSCalc__WEBPACK_IMPORTED_MODULE_5__/* .reduceCSSCalc */ .l)("calc(".concat(wordsByLines.length - 1, " * -").concat(lineHeight, ")"));
      break;
  }
  var transforms = [];
  if (scaleToFit) {
    var lineWidth = wordsByLines[0].width;
    var {
      width
    } = props;
    transforms.push("scale(".concat((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNumber */ .Et)(width) ? width / lineWidth : 1, ")"));
  }
  if (angle) {
    transforms.push("rotate(".concat(angle, ", ").concat(x, ", ").concat(y, ")"));
  }
  if (transforms.length) {
    textProps.transform = transforms.join(' ');
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("text", _extends({}, (0,_util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_6__/* .svgPropertiesAndEvents */ .a)(textProps), {
    ref: ref,
    x: x,
    y: y,
    className: (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)('recharts-text', className),
    textAnchor: textAnchor,
    fill: fill.includes('url') ? DEFAULT_FILL : fill
  }), wordsByLines.map((line, index) => {
    var words = line.words.join(breakAll ? '' : ' ');
    return (
      /*#__PURE__*/
      // duplicate words will cause duplicate keys
      // eslint-disable-next-line react/no-array-index-key
      react__WEBPACK_IMPORTED_MODULE_0__.createElement("tspan", {
        x: x,
        dy: index === 0 ? startDy : lineHeight,
        key: "".concat(words, "-").concat(index)
      }, words)
    );
  }));
});
Text.displayName = 'Text';

/***/ }),

/***/ 28482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  u: () => (/* binding */ ResponsiveContainer),
  w: () => (/* binding */ useResponsiveContainerContext)
});

// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(34164);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
// EXTERNAL MODULE: ./node_modules/es-toolkit/compat/throttle.js
var throttle = __webpack_require__(74297);
var throttle_default = /*#__PURE__*/__webpack_require__.n(throttle);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/LogUtils.js
var LogUtils = __webpack_require__(6634);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/DataUtils.js
var DataUtils = __webpack_require__(59744);
;// ./node_modules/recharts/es6/component/responsiveContainerUtils.js

var calculateChartDimensions = (containerWidth, containerHeight, props) => {
  var {
    width = '100%',
    height = '100%',
    aspect,
    maxHeight
  } = props;

  /*
   * The containerWidth and containerHeight are already percentage based because it's set as that percentage in CSS.
   * Means we don't have to calculate percentages here.
   */
  var calculatedWidth = (0,DataUtils/* isPercent */._3)(width) ? containerWidth : Number(width);
  var calculatedHeight = (0,DataUtils/* isPercent */._3)(height) ? containerHeight : Number(height);
  if (aspect && aspect > 0) {
    // Preserve the desired aspect ratio
    if (calculatedWidth) {
      // Will default to using width for aspect ratio
      calculatedHeight = calculatedWidth / aspect;
    } else if (calculatedHeight) {
      // But we should also take height into consideration
      calculatedWidth = calculatedHeight * aspect;
    }

    // if maxHeight is set, overwrite if calculatedHeight is greater than maxHeight
    if (maxHeight && calculatedHeight > maxHeight) {
      calculatedHeight = maxHeight;
    }
  }
  return {
    calculatedWidth,
    calculatedHeight
  };
};
var bothOverflow = {
  width: 0,
  height: 0,
  overflow: 'visible'
};
var overflowX = {
  width: 0,
  overflowX: 'visible'
};
var overflowY = {
  height: 0,
  overflowY: 'visible'
};
var noStyle = {};

/**
 * This zero-size, overflow-visible is required to allow the chart to shrink.
 * Without it, the chart itself will fill the ResponsiveContainer, and while it allows the chart to grow,
 * it would always keep the container at the size of the chart,
 * and ResizeObserver would never fire.
 * With this zero-size element, the chart itself never actually fills the container,
 * it just so happens that it is visible because it overflows.
 * I learned this trick from the `react-virtualized` library: https://github.com/bvaughn/react-virtualized-auto-sizer/blob/master/src/AutoSizer.ts
 * See https://github.com/recharts/recharts/issues/172 and also https://github.com/bvaughn/react-virtualized/issues/68
 *
 * Also, we don't need to apply the zero-size style if the dimension is a fixed number (or undefined),
 * because in that case the chart can't shrink in that dimension anyway.
 * This fixes defining the dimensions using aspect ratio: https://github.com/recharts/recharts/issues/6245
 */
var getInnerDivStyle = props => {
  var {
    width,
    height
  } = props;
  var isWidthPercent = (0,DataUtils/* isPercent */._3)(width);
  var isHeightPercent = (0,DataUtils/* isPercent */._3)(height);
  if (isWidthPercent && isHeightPercent) {
    return bothOverflow;
  }
  if (isWidthPercent) {
    return overflowX;
  }
  if (isHeightPercent) {
    return overflowY;
  }
  return noStyle;
};
function getDefaultWidthAndHeight(_ref) {
  var {
    width,
    height,
    aspect
  } = _ref;
  var calculatedWidth = width;
  var calculatedHeight = height;
  if (calculatedWidth === undefined && calculatedHeight === undefined) {
    calculatedWidth = '100%';
    calculatedHeight = '100%';
  } else if (calculatedWidth === undefined) {
    calculatedWidth = aspect && aspect > 0 ? undefined : '100%';
  } else if (calculatedHeight === undefined) {
    calculatedHeight = aspect && aspect > 0 ? undefined : '100%';
  }
  return {
    width: calculatedWidth,
    height: calculatedHeight
  };
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/isWellBehavedNumber.js
var isWellBehavedNumber = __webpack_require__(8813);
;// ./node_modules/recharts/es6/component/ResponsiveContainer.js
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }








var ResponsiveContainerContext = /*#__PURE__*/(0,react.createContext)({
  width: -1,
  height: -1
});
function ResponsiveContainerContextProvider(_ref) {
  var {
    children,
    width,
    height
  } = _ref;
  var size = (0,react.useMemo)(() => ({
    width,
    height
  }), [width, height]);
  if (width <= 0 || height <= 0) {
    /*
     * Don't render the container if width or height is non-positive because
     * in that case the chart will not be rendered properly anyway.
     * We will instead wait for the next resize event to provide the correct dimensions.
     */
    return null;
  }
  return /*#__PURE__*/react.createElement(ResponsiveContainerContext.Provider, {
    value: size
  }, children);
}
var useResponsiveContainerContext = () => (0,react.useContext)(ResponsiveContainerContext);
var SizeDetectorContainer = /*#__PURE__*/(0,react.forwardRef)((_ref2, ref) => {
  var {
    aspect,
    initialDimension = {
      width: -1,
      height: -1
    },
    width,
    height,
    /*
     * default min-width to 0 if not specified - 'auto' causes issues with flexbox
     * https://github.com/recharts/recharts/issues/172
     */
    minWidth = 0,
    minHeight,
    maxHeight,
    children,
    debounce = 0,
    id,
    className,
    onResize,
    style = {}
  } = _ref2;
  var containerRef = (0,react.useRef)(null);
  /*
   * We are using a ref to avoid re-creating the ResizeObserver when the onResize function changes.
   * The ref is updated on every render, so the latest onResize function is always available in the effect.
   */
  var onResizeRef = (0,react.useRef)();
  onResizeRef.current = onResize;
  (0,react.useImperativeHandle)(ref, () => containerRef.current);
  var [sizes, setSizes] = (0,react.useState)({
    containerWidth: initialDimension.width,
    containerHeight: initialDimension.height
  });
  var setContainerSize = (0,react.useCallback)((newWidth, newHeight) => {
    setSizes(prevState => {
      var roundedWidth = Math.round(newWidth);
      var roundedHeight = Math.round(newHeight);
      if (prevState.containerWidth === roundedWidth && prevState.containerHeight === roundedHeight) {
        return prevState;
      }
      return {
        containerWidth: roundedWidth,
        containerHeight: roundedHeight
      };
    });
  }, []);
  (0,react.useEffect)(() => {
    var callback = entries => {
      var _onResizeRef$current;
      var {
        width: containerWidth,
        height: containerHeight
      } = entries[0].contentRect;
      setContainerSize(containerWidth, containerHeight);
      (_onResizeRef$current = onResizeRef.current) === null || _onResizeRef$current === void 0 || _onResizeRef$current.call(onResizeRef, containerWidth, containerHeight);
    };
    if (debounce > 0) {
      callback = throttle_default()(callback, debounce, {
        trailing: true,
        leading: false
      });
    }
    var observer = new ResizeObserver(callback);
    var {
      width: containerWidth,
      height: containerHeight
    } = containerRef.current.getBoundingClientRect();
    setContainerSize(containerWidth, containerHeight);
    observer.observe(containerRef.current);
    return () => {
      observer.disconnect();
    };
  }, [setContainerSize, debounce]);
  var {
    containerWidth,
    containerHeight
  } = sizes;
  (0,LogUtils/* warn */.R)(!aspect || aspect > 0, 'The aspect(%s) must be greater than zero.', aspect);
  var {
    calculatedWidth,
    calculatedHeight
  } = calculateChartDimensions(containerWidth, containerHeight, {
    width,
    height,
    aspect,
    maxHeight
  });
  (0,LogUtils/* warn */.R)(calculatedWidth > 0 || calculatedHeight > 0, "The width(%s) and height(%s) of chart should be greater than 0,\n       please check the style of container, or the props width(%s) and height(%s),\n       or add a minWidth(%s) or minHeight(%s) or use aspect(%s) to control the\n       height and width.", calculatedWidth, calculatedHeight, width, height, minWidth, minHeight, aspect);
  return /*#__PURE__*/react.createElement("div", {
    id: id ? "".concat(id) : undefined,
    className: (0,clsx/* clsx */.$)('recharts-responsive-container', className),
    style: _objectSpread(_objectSpread({}, style), {}, {
      width,
      height,
      minWidth,
      minHeight,
      maxHeight
    }),
    ref: containerRef
  }, /*#__PURE__*/react.createElement("div", {
    style: getInnerDivStyle({
      width,
      height
    })
  }, /*#__PURE__*/react.createElement(ResponsiveContainerContextProvider, {
    width: calculatedWidth,
    height: calculatedHeight
  }, children)));
});

/**
 * The `ResponsiveContainer` component is a container that adjusts its width and height based on the size of its parent element.
 * It is used to create responsive charts that adapt to different screen sizes.
 *
 * This component uses the `ResizeObserver` API to monitor changes to the size of its parent element.
 * If you need to support older browsers that do not support this API, you may need to include a polyfill.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver
 */
var ResponsiveContainer = /*#__PURE__*/(0,react.forwardRef)((props, ref) => {
  var responsiveContainerContext = useResponsiveContainerContext();
  if ((0,isWellBehavedNumber/* isPositiveNumber */.F)(responsiveContainerContext.width) && (0,isWellBehavedNumber/* isPositiveNumber */.F)(responsiveContainerContext.height)) {
    /*
     * If we detect that we are already inside another ResponsiveContainer,
     * we do not attempt to add another layer of responsiveness.
     */
    return props.children;
  }
  var {
    width,
    height
  } = getDefaultWidthAndHeight({
    width: props.width,
    height: props.height,
    aspect: props.aspect
  });

  /*
   * Let's try to get the calculated dimensions without having the div container set up.
   * Sometimes this does produce fixed, positive dimensions. If so, we can skip rendering the div and monitoring its size.
   */
  var {
    calculatedWidth,
    calculatedHeight
  } = calculateChartDimensions(undefined, undefined, {
    width,
    height,
    aspect: props.aspect,
    maxHeight: props.maxHeight
  });
  if ((0,DataUtils/* isNumber */.Et)(calculatedWidth) && (0,DataUtils/* isNumber */.Et)(calculatedHeight)) {
    /*
     * If it just so happens that the combination of width, height, and aspect ratio
     * results in fixed dimensions, then we don't need to monitor the container's size.
     * We can just provide these fixed dimensions to the context.
     *
     * Note that here we are not checking for positive numbers;
     * if the user provides a zero or negative width/height, we will just pass that along
     * as whatever size we detect won't be helping anyway.
     */
    return /*#__PURE__*/react.createElement(ResponsiveContainerContextProvider, {
      width: calculatedWidth,
      height: calculatedHeight
    }, props.children);
  }
  /*
   * Static analysis did not produce fixed dimensions,
   * so we need to render a special div and monitor its size.
   */
  return /*#__PURE__*/react.createElement(SizeDetectorContainer, _extends({}, props, {
    width: width,
    height: height,
    ref: ref
  }));
});

/***/ }),

/***/ 31230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ BrushUpdateDispatchContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);

var BrushUpdateDispatchContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(() => {});

/***/ }),

/***/ 32945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ useAccessibilityLayer)
/* harmony export */ });
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49082);

var useAccessibilityLayer = () => (0,_state_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .G)(state => state.rootProps.accessibilityLayer);

/***/ }),

/***/ 49303:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ Surface)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34164);
/* harmony import */ var _util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(80196);
var _excluded = ["children", "width", "height", "viewBox", "className", "style", "title", "desc"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
/**
 * @fileOverview Surface
 */




var Surface = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((props, ref) => {
  var {
      children,
      width,
      height,
      viewBox,
      className,
      style,
      title,
      desc
    } = props,
    others = _objectWithoutProperties(props, _excluded);
  var svgView = viewBox || {
    width,
    height,
    x: 0,
    y: 0
  };
  var layerClass = (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)('recharts-surface', className);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({}, (0,_util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_2__/* .svgPropertiesAndEvents */ .a)(others), {
    className: layerClass,
    width: width,
    height: height,
    style: style,
    viewBox: "".concat(svgView.x, " ").concat(svgView.y, " ").concat(svgView.width, " ").concat(svgView.height),
    ref: ref
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("title", null, title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("desc", null, desc), children);
});

/***/ }),

/***/ 55846:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ useLegendPortal),
/* harmony export */   t: () => (/* binding */ LegendPortalContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);

var LegendPortalContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
var useLegendPortal = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(LegendPortalContext);

/***/ }),

/***/ 58008:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Cj: () => (/* binding */ useMouseEnterItemDispatch),
/* harmony export */   Pg: () => (/* binding */ useMouseLeaveItemDispatch),
/* harmony export */   Ub: () => (/* binding */ useMouseClickItemDispatch)
/* harmony export */ });
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49082);
/* harmony import */ var _state_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74531);


var useMouseEnterItemDispatch = (onMouseEnterFromProps, dataKey) => {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .j)();
  return (data, index) => event => {
    onMouseEnterFromProps === null || onMouseEnterFromProps === void 0 || onMouseEnterFromProps(data, index, event);
    dispatch((0,_state_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .setActiveMouseOverItemIndex */ .RD)({
      activeIndex: String(index),
      activeDataKey: dataKey,
      activeCoordinate: data.tooltipPosition
    }));
  };
};
var useMouseLeaveItemDispatch = onMouseLeaveFromProps => {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .j)();
  return (data, index) => event => {
    onMouseLeaveFromProps === null || onMouseLeaveFromProps === void 0 || onMouseLeaveFromProps(data, index, event);
    dispatch((0,_state_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .mouseLeaveItem */ .oP)());
  };
};
var useMouseClickItemDispatch = (onMouseClickFromProps, dataKey) => {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .j)();
  return (data, index) => event => {
    onMouseClickFromProps === null || onMouseClickFromProps === void 0 || onMouseClickFromProps(data, index, event);
    dispatch((0,_state_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .setActiveClickItemIndex */ .ML)({
      activeIndex: String(index),
      activeDataKey: dataKey,
      activeCoordinate: data.tooltipPosition
    }));
  };
};

/***/ }),

/***/ 67965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Oo: () => (/* binding */ useChartData),
/* harmony export */   TK: () => (/* binding */ ChartDataContextProvider),
/* harmony export */   eE: () => (/* binding */ useDataIndex),
/* harmony export */   qG: () => (/* binding */ SetComputedData)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _state_chartDataSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46446);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49082);
/* harmony import */ var _PanoramaContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12070);




var ChartDataContextProvider = props => {
  var {
    chartData
  } = props;
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .j)();
  var isPanorama = (0,_PanoramaContext__WEBPACK_IMPORTED_MODULE_3__/* .useIsPanorama */ .r)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isPanorama) {
      // Panorama mode reuses data from the main chart, so we must not overwrite it here.
      return () => {
        // there is nothing to clean up
      };
    }
    dispatch((0,_state_chartDataSlice__WEBPACK_IMPORTED_MODULE_1__/* .setChartData */ .hq)(chartData));
    return () => {
      dispatch((0,_state_chartDataSlice__WEBPACK_IMPORTED_MODULE_1__/* .setChartData */ .hq)(undefined));
    };
  }, [chartData, dispatch, isPanorama]);
  return null;
};
var SetComputedData = props => {
  var {
    computedData
  } = props;
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .j)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    dispatch((0,_state_chartDataSlice__WEBPACK_IMPORTED_MODULE_1__/* .setComputedData */ .Ut)(computedData));
    return () => {
      dispatch((0,_state_chartDataSlice__WEBPACK_IMPORTED_MODULE_1__/* .setChartData */ .hq)(undefined));
    };
  }, [computedData, dispatch]);
  return null;
};
var selectChartData = state => state.chartData.chartData;

/**
 * "data" is the data of the chart - it has no type because this part of recharts is very flexible.
 * Basically it's an array of "something" and then there's the dataKey property in various places
 * that's meant to pull other things away from the data.
 *
 * Some charts have `data` defined on the chart root, and they will return the array through this hook.
 * For example: <ComposedChart data={data} />.
 *
 * Other charts, such as Pie, have data defined on individual graphical elements.
 * These charts will return `undefined` through this hook, and you need to read the data from children.
 * For example: <PieChart><Pie data={data} />
 *
 * Some charts also allow setting both - data on the parent, and data on the children at the same time!
 * However, this particular selector will only return the ones defined on the parent.
 *
 * @deprecated use one of the other selectors instead - which one, depends on how do you identify the applicable graphical items.
 *
 * @return data array for some charts and undefined for other
 */
var useChartData = () => (0,_state_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppSelector */ .G)(selectChartData);
var selectDataIndex = state => {
  var {
    dataStartIndex,
    dataEndIndex
  } = state.chartData;
  return {
    startIndex: dataStartIndex,
    endIndex: dataEndIndex
  };
};

/**
 * startIndex and endIndex are data boundaries, set through Brush.
 *
 * @return object with startIndex and endIndex
 */
var useDataIndex = () => {
  return (0,_state_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppSelector */ .G)(selectDataIndex);
};

/***/ }),

/***/ 72050:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   f: () => (/* binding */ Cell)
/* harmony export */ });
/**
 * @fileOverview Cross
 */

var Cell = _props => null;
Cell.displayName = 'Cell';

/***/ }),

/***/ 74354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ TooltipPortalContext),
/* harmony export */   X: () => (/* binding */ useTooltipPortal)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);

var TooltipPortalContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
var useTooltipPortal = () => (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(TooltipPortalContext);

/***/ }),

/***/ 80279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export Customized */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _container_Layer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86069);
/* harmony import */ var _util_LogUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6634);
var _excluded = ["component"];
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
/**
 * @fileOverview Customized
 */




/**
 * custom svg elements by rechart instance props and state.
 * @returns {Object}   svg elements
 */
function Customized(_ref) {
  var {
      component
    } = _ref,
    props = _objectWithoutProperties(_ref, _excluded);
  var child;
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(component)) {
    child = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(component, props);
  } else if (typeof component === 'function') {
    child = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(component, props);
  } else {
    (0,_util_LogUtils__WEBPACK_IMPORTED_MODULE_2__/* .warn */ .R)(false, "Customized's props `component` must be React.element or Function, but got %s.", typeof component);
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_container_Layer__WEBPACK_IMPORTED_MODULE_1__/* .Layer */ .W, {
    className: "recharts-customized-wrapper"
  }, child);
}
Customized.displayName = 'Customized';

/***/ }),

/***/ 81943:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ RootSurface)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19287);
/* harmony import */ var _context_accessibilityContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32945);
/* harmony import */ var _context_PanoramaContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12070);
/* harmony import */ var _Surface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49303);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49082);
/* harmony import */ var _state_selectors_brushSelectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76461);
/* harmony import */ var _util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8813);
var _excluded = ["children"];
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }









var FULL_WIDTH_AND_HEIGHT = {
  width: '100%',
  height: '100%',
  /*
   * display: block is necessary here because the default for an SVG is display: inline,
   * which in some browsers (Chrome) adds a little bit of extra space above and below the SVG
   * to make space for the descender of letters like "g" and "y". This throws off the height calculation
   * and causes the container to grow indefinitely on each render with responsive=true.
   * Display: block removes that extra space.
   *
   * Interestingly, Firefox does not have this problem, but it doesn't hurt to add the style anyway.
   */
  display: 'block'
};
var MainChartSurface = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((props, ref) => {
  var width = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_1__/* .useChartWidth */ .yi)();
  var height = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_1__/* .useChartHeight */ .rY)();
  var hasAccessibilityLayer = (0,_context_accessibilityContext__WEBPACK_IMPORTED_MODULE_2__/* .useAccessibilityLayer */ .$)();
  if (!(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_7__/* .isPositiveNumber */ .F)(width) || !(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_7__/* .isPositiveNumber */ .F)(height)) {
    return null;
  }
  var {
    children,
    otherAttributes,
    title,
    desc
  } = props;
  var tabIndex, role;
  if (typeof otherAttributes.tabIndex === 'number') {
    tabIndex = otherAttributes.tabIndex;
  } else {
    tabIndex = hasAccessibilityLayer ? 0 : undefined;
  }
  if (typeof otherAttributes.role === 'string') {
    role = otherAttributes.role;
  } else {
    role = hasAccessibilityLayer ? 'application' : undefined;
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Surface__WEBPACK_IMPORTED_MODULE_4__/* .Surface */ .u, _extends({}, otherAttributes, {
    title: title,
    desc: desc,
    role: role,
    tabIndex: tabIndex,
    width: width,
    height: height,
    style: FULL_WIDTH_AND_HEIGHT,
    ref: ref
  }), children);
});
var BrushPanoramaSurface = _ref => {
  var {
    children
  } = _ref;
  var brushDimensions = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_5__/* .useAppSelector */ .G)(_state_selectors_brushSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectBrushDimensions */ .U);
  if (!brushDimensions) {
    return null;
  }
  var {
    width,
    height,
    y,
    x
  } = brushDimensions;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Surface__WEBPACK_IMPORTED_MODULE_4__/* .Surface */ .u, {
    width: width,
    height: height,
    x: x,
    y: y
  }, children);
};
var RootSurface = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((_ref2, ref) => {
  var {
      children
    } = _ref2,
    rest = _objectWithoutProperties(_ref2, _excluded);
  var isPanorama = (0,_context_PanoramaContext__WEBPACK_IMPORTED_MODULE_3__/* .useIsPanorama */ .r)();
  if (isPanorama) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(BrushPanoramaSurface, null, children);
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(MainChartSurface, _extends({
    ref: ref
  }, rest), children);
});

/***/ }),

/***/ 84044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ useGraphicalItemId),
/* harmony export */   x: () => (/* binding */ RegisterGraphicalItemId)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _util_useUniqueId__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(90885);



var GraphicalItemIdContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
var RegisterGraphicalItemId = _ref => {
  var {
    id,
    type,
    children
  } = _ref;
  var resolvedId = (0,_util_useUniqueId__WEBPACK_IMPORTED_MODULE_1__/* .useUniqueId */ .Y)("recharts-".concat(type), id);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(GraphicalItemIdContext.Provider, {
    value: resolvedId
  }, children(resolvedId));
};
function useGraphicalItemId() {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(GraphicalItemIdContext);
}

/***/ }),

/***/ 84399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  m: () => (/* binding */ Tooltip)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
// EXTERNAL MODULE: ./node_modules/react-dom/index.js
var react_dom = __webpack_require__(40961);
// EXTERNAL MODULE: ./node_modules/recharts/es6/component/DefaultTooltipContent.js
var DefaultTooltipContent = __webpack_require__(18689);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/tooltip/translate.js
var translate = __webpack_require__(41571);
;// ./node_modules/recharts/es6/component/TooltipBoundingBox.js
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }



class TooltipBoundingBox extends react.PureComponent {
  constructor() {
    super(...arguments);
    _defineProperty(this, "state", {
      dismissed: false,
      dismissedAtCoordinate: {
        x: 0,
        y: 0
      }
    });
    _defineProperty(this, "handleKeyDown", event => {
      if (event.key === 'Escape') {
        var _this$props$coordinat, _this$props$coordinat2, _this$props$coordinat3, _this$props$coordinat4;
        this.setState({
          dismissed: true,
          dismissedAtCoordinate: {
            x: (_this$props$coordinat = (_this$props$coordinat2 = this.props.coordinate) === null || _this$props$coordinat2 === void 0 ? void 0 : _this$props$coordinat2.x) !== null && _this$props$coordinat !== void 0 ? _this$props$coordinat : 0,
            y: (_this$props$coordinat3 = (_this$props$coordinat4 = this.props.coordinate) === null || _this$props$coordinat4 === void 0 ? void 0 : _this$props$coordinat4.y) !== null && _this$props$coordinat3 !== void 0 ? _this$props$coordinat3 : 0
          }
        });
      }
    });
  }
  componentDidMount() {
    document.addEventListener('keydown', this.handleKeyDown);
  }
  componentWillUnmount() {
    document.removeEventListener('keydown', this.handleKeyDown);
  }
  componentDidUpdate() {
    var _this$props$coordinat5, _this$props$coordinat6;
    if (!this.state.dismissed) {
      return;
    }
    if (((_this$props$coordinat5 = this.props.coordinate) === null || _this$props$coordinat5 === void 0 ? void 0 : _this$props$coordinat5.x) !== this.state.dismissedAtCoordinate.x || ((_this$props$coordinat6 = this.props.coordinate) === null || _this$props$coordinat6 === void 0 ? void 0 : _this$props$coordinat6.y) !== this.state.dismissedAtCoordinate.y) {
      this.state.dismissed = false;
    }
  }
  render() {
    var {
      active,
      allowEscapeViewBox,
      animationDuration,
      animationEasing,
      children,
      coordinate,
      hasPayload,
      isAnimationActive,
      offset,
      position,
      reverseDirection,
      useTranslate3d,
      viewBox,
      wrapperStyle,
      lastBoundingBox,
      innerRef,
      hasPortalFromProps
    } = this.props;
    var {
      cssClasses,
      cssProperties
    } = (0,translate/* getTooltipTranslate */.eK)({
      allowEscapeViewBox,
      coordinate,
      offsetTopLeft: offset,
      position,
      reverseDirection,
      tooltipBox: {
        height: lastBoundingBox.height,
        width: lastBoundingBox.width
      },
      useTranslate3d,
      viewBox
    });

    // do not use absolute styles if the user has passed a custom portal prop
    var positionStyles = hasPortalFromProps ? {} : _objectSpread(_objectSpread({
      transition: isAnimationActive && active ? "transform ".concat(animationDuration, "ms ").concat(animationEasing) : undefined
    }, cssProperties), {}, {
      pointerEvents: 'none',
      visibility: !this.state.dismissed && active && hasPayload ? 'visible' : 'hidden',
      position: 'absolute',
      top: 0,
      left: 0
    });
    var outerStyle = _objectSpread(_objectSpread({}, positionStyles), {}, {
      visibility: !this.state.dismissed && active && hasPayload ? 'visible' : 'hidden'
    }, wrapperStyle);
    return (
      /*#__PURE__*/
      // This element allow listening to the `Escape` key. See https://github.com/recharts/recharts/pull/2925
      react.createElement("div", {
        // @ts-expect-error typescript library does not recognize xmlns attribute, but it's required for an HTML chunk inside SVG.
        xmlns: "http://www.w3.org/1999/xhtml",
        tabIndex: -1,
        className: cssClasses,
        style: outerStyle,
        ref: innerRef
      }, children)
    );
  }
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/Global.js
var Global = __webpack_require__(59938);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/payload/getUniqPayload.js
var getUniqPayload = __webpack_require__(79799);
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/chartLayoutContext.js
var chartLayoutContext = __webpack_require__(19287);
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/accessibilityContext.js
var accessibilityContext = __webpack_require__(32945);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/useElementOffset.js
var useElementOffset = __webpack_require__(66583);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(34164);
// EXTERNAL MODULE: ./node_modules/recharts/es6/shape/Curve.js
var Curve = __webpack_require__(45249);
// EXTERNAL MODULE: ./node_modules/recharts/es6/shape/Cross.js
var Cross = __webpack_require__(35862);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/cursor/getCursorRectangle.js
var getCursorRectangle = __webpack_require__(74613);
// EXTERNAL MODULE: ./node_modules/recharts/es6/shape/Rectangle.js
var Rectangle = __webpack_require__(34723);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/cursor/getRadialCursorPoints.js
var getRadialCursorPoints = __webpack_require__(68334);
// EXTERNAL MODULE: ./node_modules/recharts/es6/shape/Sector.js
var Sector = __webpack_require__(58522);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/cursor/getCursorPoints.js
var getCursorPoints = __webpack_require__(41389);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/hooks.js
var hooks = __webpack_require__(49082);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/ChartUtils.js
var ChartUtils = __webpack_require__(33964);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/tooltipSelectors.js + 1 modules
var tooltipSelectors = __webpack_require__(33032);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipAxis.js
var selectTooltipAxis = __webpack_require__(37617);
;// ./node_modules/recharts/es6/context/useTooltipAxis.js
function useTooltipAxis_ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function useTooltipAxis_objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? useTooltipAxis_ownKeys(Object(t), !0).forEach(function (r) { useTooltipAxis_defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : useTooltipAxis_ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function useTooltipAxis_defineProperty(e, r, t) { return (r = useTooltipAxis_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function useTooltipAxis_toPropertyKey(t) { var i = useTooltipAxis_toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function useTooltipAxis_toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }




var useTooltipAxis = () => (0,hooks/* useAppSelector */.G)(selectTooltipAxis/* selectTooltipAxis */.D);
var useTooltipAxisBandSize = () => {
  var tooltipAxis = useTooltipAxis();
  var tooltipTicks = (0,hooks/* useAppSelector */.G)(tooltipSelectors/* selectTooltipAxisTicks */.R4);
  var tooltipAxisScale = (0,hooks/* useAppSelector */.G)(tooltipSelectors/* selectTooltipAxisScale */.fl);
  return (0,ChartUtils/* getBandSizeOfAxis */.Hj)(useTooltipAxis_objectSpread(useTooltipAxis_objectSpread({}, tooltipAxis), {}, {
    scale: tooltipAxisScale
  }), tooltipTicks);
};
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectors.js
var selectors = __webpack_require__(87997);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/svgPropertiesNoEvents.js
var svgPropertiesNoEvents = __webpack_require__(55448);
;// ./node_modules/recharts/es6/component/Cursor.js
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Cursor_ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function Cursor_objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? Cursor_ownKeys(Object(t), !0).forEach(function (r) { Cursor_defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Cursor_ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function Cursor_defineProperty(e, r, t) { return (r = Cursor_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function Cursor_toPropertyKey(t) { var i = Cursor_toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function Cursor_toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }















/**
 * If set false, no cursor will be drawn when tooltip is active.
 * If set an object, the option is the configuration of cursor.
 * If set a React element, the option is the custom react element of drawing cursor
 */

function CursorInternal(props) {
  var {
    coordinate,
    payload,
    index,
    offset,
    tooltipAxisBandSize,
    layout,
    cursor,
    tooltipEventType,
    chartName
  } = props;

  // The cursor is a part of the Tooltip, and it should be shown (by default) when the Tooltip is active.
  var activeCoordinate = coordinate;
  var activePayload = payload;
  var activeTooltipIndex = index;
  if (!cursor || !activeCoordinate || chartName !== 'ScatterChart' && tooltipEventType !== 'axis') {
    return null;
  }
  var restProps, cursorComp;
  if (chartName === 'ScatterChart') {
    restProps = activeCoordinate;
    cursorComp = Cross/* Cross */.F;
  } else if (chartName === 'BarChart') {
    restProps = (0,getCursorRectangle/* getCursorRectangle */.C)(layout, activeCoordinate, offset, tooltipAxisBandSize);
    cursorComp = Rectangle/* Rectangle */.M;
  } else if (layout === 'radial') {
    // @ts-expect-error TODO the state is marked as containing Coordinate but actually in polar charts it contains PolarCoordinate, we should keep the polar state separate
    var {
      cx,
      cy,
      radius,
      startAngle,
      endAngle
    } = (0,getRadialCursorPoints/* getRadialCursorPoints */.H)(activeCoordinate);
    restProps = {
      cx,
      cy,
      startAngle,
      endAngle,
      innerRadius: radius,
      outerRadius: radius
    };
    cursorComp = Sector/* Sector */.h;
  } else {
    restProps = {
      points: (0,getCursorPoints/* getCursorPoints */.K)(layout, activeCoordinate, offset)
    };
    cursorComp = Curve/* Curve */.I;
  }
  var extraClassName = typeof cursor === 'object' && 'className' in cursor ? cursor.className : undefined;
  var cursorProps = Cursor_objectSpread(Cursor_objectSpread(Cursor_objectSpread(Cursor_objectSpread({
    stroke: '#ccc',
    pointerEvents: 'none'
  }, offset), restProps), (0,svgPropertiesNoEvents/* svgPropertiesNoEventsFromUnknown */.ic)(cursor)), {}, {
    payload: activePayload,
    payloadIndex: activeTooltipIndex,
    className: (0,clsx/* clsx */.$)('recharts-tooltip-cursor', extraClassName)
  });
  if (/*#__PURE__*/(0,react.isValidElement)(cursor)) {
    // @ts-expect-error we don't know if cursorProps are correct for this element
    return /*#__PURE__*/(0,react.cloneElement)(cursor, cursorProps);
  }
  return /*#__PURE__*/(0,react.createElement)(cursorComp, cursorProps);
}

/*
 * Cursor is the background, or a highlight,
 * that shows when user mouses over or activates
 * an area.
 *
 * It usually shows together with a tooltip
 * to emphasise which part of the chart does the tooltip refer to.
 */
function Cursor(props) {
  var tooltipAxisBandSize = useTooltipAxisBandSize();
  var offset = (0,chartLayoutContext/* useOffsetInternal */.W7)();
  var layout = (0,chartLayoutContext/* useChartLayout */.WX)();
  var chartName = (0,selectors/* useChartName */.fW)();
  return /*#__PURE__*/react.createElement(CursorInternal, _extends({}, props, {
    coordinate: props.coordinate,
    index: props.index,
    payload: props.payload,
    offset: offset,
    layout: layout,
    tooltipAxisBandSize: tooltipAxisBandSize,
    chartName: chartName
  }));
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/tooltipPortalContext.js
var tooltipPortalContext = __webpack_require__(74354);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/tooltipSlice.js
var tooltipSlice = __webpack_require__(74531);
// EXTERNAL MODULE: ./node_modules/recharts/es6/synchronisation/useChartSynchronisation.js + 2 modules
var useChartSynchronisation = __webpack_require__(63042);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipEventType.js
var selectTooltipEventType = __webpack_require__(55978);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/resolveDefaultProps.js
var resolveDefaultProps = __webpack_require__(77404);
;// ./node_modules/recharts/es6/component/Tooltip.js
function Tooltip_ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function Tooltip_objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? Tooltip_ownKeys(Object(t), !0).forEach(function (r) { Tooltip_defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : Tooltip_ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function Tooltip_defineProperty(e, r, t) { return (r = Tooltip_toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function Tooltip_toPropertyKey(t) { var i = Tooltip_toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function Tooltip_toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


















function defaultUniqBy(entry) {
  return entry.dataKey;
}
function renderContent(content, props) {
  if (/*#__PURE__*/react.isValidElement(content)) {
    return /*#__PURE__*/react.cloneElement(content, props);
  }
  if (typeof content === 'function') {
    return /*#__PURE__*/react.createElement(content, props);
  }
  return /*#__PURE__*/react.createElement(DefaultTooltipContent/* DefaultTooltipContent */.E, props);
}
var emptyPayload = [];
var defaultTooltipProps = {
  allowEscapeViewBox: {
    x: false,
    y: false
  },
  animationDuration: 400,
  animationEasing: 'ease',
  axisId: 0,
  contentStyle: {},
  cursor: true,
  filterNull: true,
  isAnimationActive: !Global/* Global */.m.isSsr,
  itemSorter: 'name',
  itemStyle: {},
  labelStyle: {},
  offset: 10,
  reverseDirection: {
    x: false,
    y: false
  },
  separator: ' : ',
  trigger: 'hover',
  useTranslate3d: false,
  wrapperStyle: {}
};
function Tooltip(outsideProps) {
  var props = (0,resolveDefaultProps/* resolveDefaultProps */.e)(outsideProps, defaultTooltipProps);
  var {
    active: activeFromProps,
    allowEscapeViewBox,
    animationDuration,
    animationEasing,
    content,
    filterNull,
    isAnimationActive,
    offset,
    payloadUniqBy,
    position,
    reverseDirection,
    useTranslate3d,
    wrapperStyle,
    cursor,
    shared,
    trigger,
    defaultIndex,
    portal: portalFromProps,
    axisId
  } = props;
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  var defaultIndexAsString = typeof defaultIndex === 'number' ? String(defaultIndex) : defaultIndex;
  (0,react.useEffect)(() => {
    dispatch((0,tooltipSlice/* setTooltipSettingsState */.UF)({
      shared,
      trigger,
      axisId,
      active: activeFromProps,
      defaultIndex: defaultIndexAsString
    }));
  }, [dispatch, shared, trigger, axisId, activeFromProps, defaultIndexAsString]);
  var viewBox = (0,chartLayoutContext/* useViewBox */.sk)();
  var accessibilityLayer = (0,accessibilityContext/* useAccessibilityLayer */.$)();
  var tooltipEventType = (0,selectTooltipEventType/* useTooltipEventType */.Td)(shared);
  var {
    activeIndex,
    isActive
  } = (0,hooks/* useAppSelector */.G)(state => (0,selectors/* selectIsTooltipActive */.yn)(state, tooltipEventType, trigger, defaultIndexAsString));
  var payloadFromRedux = (0,hooks/* useAppSelector */.G)(state => (0,selectors/* selectTooltipPayload */.u9)(state, tooltipEventType, trigger, defaultIndexAsString));
  var labelFromRedux = (0,hooks/* useAppSelector */.G)(state => (0,selectors/* selectActiveLabel */.BZ)(state, tooltipEventType, trigger, defaultIndexAsString));
  var coordinate = (0,hooks/* useAppSelector */.G)(state => (0,selectors/* selectActiveCoordinate */.dS)(state, tooltipEventType, trigger, defaultIndexAsString));
  var payload = payloadFromRedux;
  var tooltipPortalFromContext = (0,tooltipPortalContext/* useTooltipPortal */.X)();
  /*
   * The user can set `active=true` on the Tooltip in which case the Tooltip will stay always active,
   * or `active=false` in which case the Tooltip never shows.
   *
   * If the `active` prop is not defined then it will show and hide based on mouse or keyboard activity.
   */
  var finalIsActive = activeFromProps !== null && activeFromProps !== void 0 ? activeFromProps : isActive;
  var [lastBoundingBox, updateBoundingBox] = (0,useElementOffset/* useElementOffset */.V)([payload, finalIsActive]);
  var finalLabel = tooltipEventType === 'axis' ? labelFromRedux : undefined;
  (0,useChartSynchronisation/* useTooltipChartSynchronisation */.m7)(tooltipEventType, trigger, coordinate, finalLabel, activeIndex, finalIsActive);
  var tooltipPortal = portalFromProps !== null && portalFromProps !== void 0 ? portalFromProps : tooltipPortalFromContext;
  if (tooltipPortal == null) {
    return null;
  }
  var finalPayload = payload !== null && payload !== void 0 ? payload : emptyPayload;
  if (!finalIsActive) {
    finalPayload = emptyPayload;
  }
  if (filterNull && finalPayload.length) {
    finalPayload = (0,getUniqPayload/* getUniqPayload */.s)(payload.filter(entry => entry.value != null && (entry.hide !== true || props.includeHidden)), payloadUniqBy, defaultUniqBy);
  }
  var hasPayload = finalPayload.length > 0;
  var tooltipElement = /*#__PURE__*/react.createElement(TooltipBoundingBox, {
    allowEscapeViewBox: allowEscapeViewBox,
    animationDuration: animationDuration,
    animationEasing: animationEasing,
    isAnimationActive: isAnimationActive,
    active: finalIsActive,
    coordinate: coordinate,
    hasPayload: hasPayload,
    offset: offset,
    position: position,
    reverseDirection: reverseDirection,
    useTranslate3d: useTranslate3d,
    viewBox: viewBox,
    wrapperStyle: wrapperStyle,
    lastBoundingBox: lastBoundingBox,
    innerRef: updateBoundingBox,
    hasPortalFromProps: Boolean(portalFromProps)
  }, renderContent(content, Tooltip_objectSpread(Tooltip_objectSpread({}, props), {}, {
    // @ts-expect-error renderContent method expects the payload to be mutable, TODO make it immutable
    payload: finalPayload,
    label: finalLabel,
    active: finalIsActive,
    coordinate,
    accessibilityLayer
  })));
  return /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/(0,react_dom.createPortal)(tooltipElement, tooltipPortal), finalIsActive && /*#__PURE__*/react.createElement(Cursor, {
    cursor: cursor,
    tooltipEventType: tooltipEventType,
    coordinate: coordinate,
    payload: payload,
    index: activeIndex
  }));
}

/***/ }),

/***/ 84518:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ useClipPathId),
/* harmony export */   f: () => (/* binding */ ClipPathProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59744);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33092);




var ClipPathIdContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);

/**
 * Generates a unique clip path ID for use in SVG elements,
 * and puts it in a context provider.
 *
 * To read the clip path ID, use the `useClipPathId` hook,
 * or render `<ClipPath>` component which will automatically use the ID from this context.
 *
 * @param props children - React children to be wrapped by the provider
 * @returns React Context Provider
 */
var ClipPathProvider = _ref => {
  var {
    children
  } = _ref;
  var [clipPathId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("".concat((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .uniqueId */ .NF)('recharts'), "-clip"));
  var plotArea = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .usePlotArea */ .oM)();
  if (plotArea == null) {
    return null;
  }
  var {
    x,
    y,
    width,
    height
  } = plotArea;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(ClipPathIdContext.Provider, {
    value: clipPathId
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("clipPath", {
    id: clipPathId
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: x,
    y: y,
    height: height,
    width: width
  }))), children);
};
var useClipPathId = () => {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(ClipPathIdContext);
};

/***/ }),

/***/ 85695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ ActivePoints)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _util_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98940);
/* harmony import */ var _shape_Dot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(66613);
/* harmony import */ var _container_Layer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86069);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49082);
/* harmony import */ var _state_selectors_tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33032);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33092);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59744);
/* harmony import */ var _util_svgPropertiesNoEvents__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(55448);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }










var renderActivePoint = _ref => {
  var {
    point,
    childIndex,
    mainColor,
    activeDot,
    dataKey
  } = _ref;
  if (activeDot === false || point.x == null || point.y == null) {
    return null;
  }
  var dotProps = _objectSpread(_objectSpread({
    index: childIndex,
    dataKey,
    // @ts-expect-error activeDot is contributing unknown props
    cx: point.x,
    // @ts-expect-error activeDot is contributing unknown props
    cy: point.y,
    // @ts-expect-error activeDot is contributing unknown props
    r: 4,
    // @ts-expect-error activeDot is contributing unknown props
    fill: mainColor !== null && mainColor !== void 0 ? mainColor : 'none',
    // @ts-expect-error activeDot is contributing unknown props
    strokeWidth: 2,
    // @ts-expect-error activeDot is contributing unknown props
    stroke: '#fff',
    payload: point.payload,
    value: point.value
  }, (0,_util_svgPropertiesNoEvents__WEBPACK_IMPORTED_MODULE_8__/* .svgPropertiesNoEventsFromUnknown */ .ic)(activeDot)), (0,_util_types__WEBPACK_IMPORTED_MODULE_1__/* .adaptEventHandlers */ ._)(activeDot));
  var dot;
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(activeDot)) {
    // @ts-expect-error element cloning does not have types
    dot = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(activeDot, dotProps);
  } else if (typeof activeDot === 'function') {
    dot = activeDot(dotProps);
  } else {
    dot = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Dot__WEBPACK_IMPORTED_MODULE_2__/* .Dot */ .c, dotProps);
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_container_Layer__WEBPACK_IMPORTED_MODULE_3__/* .Layer */ .W, {
    className: "recharts-active-dot"
  }, dot);
};
function ActivePoints(_ref2) {
  var {
    points,
    mainColor,
    activeDot,
    itemDataKey
  } = _ref2;
  var activeTooltipIndex = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .G)(_state_selectors_tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectActiveTooltipIndex */ .A2);
  var activeDataPoints = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useActiveTooltipDataPoints */ .EI)();
  if (points == null || activeDataPoints == null) {
    return null;
  }
  var activePoint = points.find(p => activeDataPoints.includes(p.payload));
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_7__/* .isNullish */ .uy)(activePoint)) {
    return null;
  }
  return renderActivePoint({
    point: activePoint,
    childIndex: Number(activeTooltipIndex),
    mainColor,
    dataKey: itemDataKey,
    activeDot
  });
}

/***/ }),

/***/ 86069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ Layer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34164);
/* harmony import */ var _util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(80196);
var _excluded = ["children", "className"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }



var Layer = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, ref) => {
  var {
      children,
      className
    } = props,
    others = _objectWithoutProperties(props, _excluded);
  var layerClass = (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)('recharts-layer', className);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", _extends({
    className: layerClass
  }, (0,_util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_2__/* .svgPropertiesAndEvents */ .a)(others), {
    ref: ref
  }), children);
});

/***/ }),

/***/ 91706:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $w: () => (/* binding */ PolarLabelContextProvider),
/* harmony export */   JU: () => (/* binding */ Label),
/* harmony export */   ZY: () => (/* binding */ isLabelContentAFunction),
/* harmony export */   _I: () => (/* binding */ CartesianLabelFromLabelProp),
/* harmony export */   mr: () => (/* binding */ PolarLabelFromLabelProp),
/* harmony export */   zJ: () => (/* binding */ CartesianLabelContextProvider)
/* harmony export */ });
/* unused harmony export usePolarLabelContext */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34164);
/* harmony import */ var _Text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20261);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59744);
/* harmony import */ var _util_PolarUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14040);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19287);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49082);
/* harmony import */ var _state_selectors_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(61270);
/* harmony import */ var _util_resolveDefaultProps__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(77404);
/* harmony import */ var _util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(80196);
var _excluded = ["labelRef"];
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }











var CartesianLabelContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
var CartesianLabelContextProvider = _ref => {
  var {
    x,
    y,
    width,
    height,
    children
  } = _ref;
  var viewBox = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    x,
    y,
    width,
    height
  }), [x, y, width, height]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(CartesianLabelContext.Provider, {
    value: viewBox
  }, children);
};
var useCartesianLabelContext = () => {
  var labelChildContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(CartesianLabelContext);
  var chartContext = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .useViewBox */ .sk)();
  return labelChildContext || chartContext;
};
var PolarLabelContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
var PolarLabelContextProvider = _ref2 => {
  var {
    cx,
    cy,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    clockWise,
    children
  } = _ref2;
  var viewBox = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    cx,
    cy,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    clockWise
  }), [cx, cy, innerRadius, outerRadius, startAngle, endAngle, clockWise]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(PolarLabelContext.Provider, {
    value: viewBox
  }, children);
};
var usePolarLabelContext = () => {
  var labelChildContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(PolarLabelContext);
  var chartContext = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useAppSelector */ .G)(_state_selectors_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_7__/* .selectPolarViewBox */ .D0);
  return labelChildContext || chartContext;
};
var getLabel = props => {
  var {
    value,
    formatter
  } = props;
  var label = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(props.children) ? value : props.children;
  if (typeof formatter === 'function') {
    return formatter(label);
  }
  return label;
};
var isLabelContentAFunction = content => {
  return content != null && typeof content === 'function';
};
var getDeltaAngle = (startAngle, endAngle) => {
  var sign = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(endAngle - startAngle);
  var deltaAngle = Math.min(Math.abs(endAngle - startAngle), 360);
  return sign * deltaAngle;
};
var renderRadialLabel = (labelProps, position, label, attrs, viewBox) => {
  var {
    offset,
    className
  } = labelProps;
  var {
    cx,
    cy,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    clockWise
  } = viewBox;
  var radius = (innerRadius + outerRadius) / 2;
  var deltaAngle = getDeltaAngle(startAngle, endAngle);
  var sign = deltaAngle >= 0 ? 1 : -1;
  var labelAngle, direction;
  switch (position) {
    case 'insideStart':
      labelAngle = startAngle + sign * offset;
      direction = clockWise;
      break;
    case 'insideEnd':
      labelAngle = endAngle - sign * offset;
      direction = !clockWise;
      break;
    case 'end':
      labelAngle = endAngle + sign * offset;
      direction = clockWise;
      break;
    default:
      throw new Error("Unsupported position ".concat(position));
  }
  direction = deltaAngle <= 0 ? direction : !direction;
  var startPoint = (0,_util_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(cx, cy, radius, labelAngle);
  var endPoint = (0,_util_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(cx, cy, radius, labelAngle + (direction ? 1 : -1) * 359);
  var path = "M".concat(startPoint.x, ",").concat(startPoint.y, "\n    A").concat(radius, ",").concat(radius, ",0,1,").concat(direction ? 0 : 1, ",\n    ").concat(endPoint.x, ",").concat(endPoint.y);
  var id = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(labelProps.id) ? (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .uniqueId */ .NF)('recharts-radial-line-') : labelProps.id;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("text", _extends({}, attrs, {
    dominantBaseline: "central",
    className: (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)('recharts-radial-bar-label', className)
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    id: id,
    d: path
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("textPath", {
    xlinkHref: "#".concat(id)
  }, label));
};
var getAttrsOfPolarLabel = (viewBox, offset, position) => {
  var {
    cx,
    cy,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle
  } = viewBox;
  var midAngle = (startAngle + endAngle) / 2;
  if (position === 'outside') {
    var {
      x: _x,
      y: _y
    } = (0,_util_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(cx, cy, outerRadius + offset, midAngle);
    return {
      x: _x,
      y: _y,
      textAnchor: _x >= cx ? 'start' : 'end',
      verticalAnchor: 'middle'
    };
  }
  if (position === 'center') {
    return {
      x: cx,
      y: cy,
      textAnchor: 'middle',
      verticalAnchor: 'middle'
    };
  }
  if (position === 'centerTop') {
    return {
      x: cx,
      y: cy,
      textAnchor: 'middle',
      verticalAnchor: 'start'
    };
  }
  if (position === 'centerBottom') {
    return {
      x: cx,
      y: cy,
      textAnchor: 'middle',
      verticalAnchor: 'end'
    };
  }
  var r = (innerRadius + outerRadius) / 2;
  var {
    x,
    y
  } = (0,_util_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(cx, cy, r, midAngle);
  return {
    x,
    y,
    textAnchor: 'middle',
    verticalAnchor: 'middle'
  };
};
var isPolar = viewBox => 'cx' in viewBox && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(viewBox.cx);
var getAttrsOfCartesianLabel = (props, viewBox) => {
  var {
    parentViewBox: parentViewBoxFromProps,
    offset,
    position
  } = props;
  var parentViewBox;
  if (parentViewBoxFromProps != null && !isPolar(parentViewBoxFromProps)) {
    // Check that nobody is trying to pass a polar viewBox to a cartesian label
    parentViewBox = parentViewBoxFromProps;
  }
  var {
    x,
    y,
    width,
    height
  } = viewBox;

  // Define vertical offsets and position inverts based on the value being positive or negative
  var verticalSign = height >= 0 ? 1 : -1;
  var verticalOffset = verticalSign * offset;
  var verticalEnd = verticalSign > 0 ? 'end' : 'start';
  var verticalStart = verticalSign > 0 ? 'start' : 'end';

  // Define horizontal offsets and position inverts based on the value being positive or negative
  var horizontalSign = width >= 0 ? 1 : -1;
  var horizontalOffset = horizontalSign * offset;
  var horizontalEnd = horizontalSign > 0 ? 'end' : 'start';
  var horizontalStart = horizontalSign > 0 ? 'start' : 'end';
  if (position === 'top') {
    var attrs = {
      x: x + width / 2,
      y: y - verticalSign * offset,
      textAnchor: 'middle',
      verticalAnchor: verticalEnd
    };
    return _objectSpread(_objectSpread({}, attrs), parentViewBox ? {
      height: Math.max(y - parentViewBox.y, 0),
      width
    } : {});
  }
  if (position === 'bottom') {
    var _attrs = {
      x: x + width / 2,
      y: y + height + verticalOffset,
      textAnchor: 'middle',
      verticalAnchor: verticalStart
    };
    return _objectSpread(_objectSpread({}, _attrs), parentViewBox ? {
      height: Math.max(parentViewBox.y + parentViewBox.height - (y + height), 0),
      width
    } : {});
  }
  if (position === 'left') {
    var _attrs2 = {
      x: x - horizontalOffset,
      y: y + height / 2,
      textAnchor: horizontalEnd,
      verticalAnchor: 'middle'
    };
    return _objectSpread(_objectSpread({}, _attrs2), parentViewBox ? {
      width: Math.max(_attrs2.x - parentViewBox.x, 0),
      height
    } : {});
  }
  if (position === 'right') {
    var _attrs3 = {
      x: x + width + horizontalOffset,
      y: y + height / 2,
      textAnchor: horizontalStart,
      verticalAnchor: 'middle'
    };
    return _objectSpread(_objectSpread({}, _attrs3), parentViewBox ? {
      width: Math.max(parentViewBox.x + parentViewBox.width - _attrs3.x, 0),
      height
    } : {});
  }
  var sizeAttrs = parentViewBox ? {
    width,
    height
  } : {};
  if (position === 'insideLeft') {
    return _objectSpread({
      x: x + horizontalOffset,
      y: y + height / 2,
      textAnchor: horizontalStart,
      verticalAnchor: 'middle'
    }, sizeAttrs);
  }
  if (position === 'insideRight') {
    return _objectSpread({
      x: x + width - horizontalOffset,
      y: y + height / 2,
      textAnchor: horizontalEnd,
      verticalAnchor: 'middle'
    }, sizeAttrs);
  }
  if (position === 'insideTop') {
    return _objectSpread({
      x: x + width / 2,
      y: y + verticalOffset,
      textAnchor: 'middle',
      verticalAnchor: verticalStart
    }, sizeAttrs);
  }
  if (position === 'insideBottom') {
    return _objectSpread({
      x: x + width / 2,
      y: y + height - verticalOffset,
      textAnchor: 'middle',
      verticalAnchor: verticalEnd
    }, sizeAttrs);
  }
  if (position === 'insideTopLeft') {
    return _objectSpread({
      x: x + horizontalOffset,
      y: y + verticalOffset,
      textAnchor: horizontalStart,
      verticalAnchor: verticalStart
    }, sizeAttrs);
  }
  if (position === 'insideTopRight') {
    return _objectSpread({
      x: x + width - horizontalOffset,
      y: y + verticalOffset,
      textAnchor: horizontalEnd,
      verticalAnchor: verticalStart
    }, sizeAttrs);
  }
  if (position === 'insideBottomLeft') {
    return _objectSpread({
      x: x + horizontalOffset,
      y: y + height - verticalOffset,
      textAnchor: horizontalStart,
      verticalAnchor: verticalEnd
    }, sizeAttrs);
  }
  if (position === 'insideBottomRight') {
    return _objectSpread({
      x: x + width - horizontalOffset,
      y: y + height - verticalOffset,
      textAnchor: horizontalEnd,
      verticalAnchor: verticalEnd
    }, sizeAttrs);
  }
  if (!!position && typeof position === 'object' && ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(position.x) || (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isPercent */ ._3)(position.x)) && ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(position.y) || (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isPercent */ ._3)(position.y))) {
    return _objectSpread({
      x: x + (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .getPercentValue */ .F4)(position.x, width),
      y: y + (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .getPercentValue */ .F4)(position.y, height),
      textAnchor: 'end',
      verticalAnchor: 'end'
    }, sizeAttrs);
  }
  return _objectSpread({
    x: x + width / 2,
    y: y + height / 2,
    textAnchor: 'middle',
    verticalAnchor: 'middle'
  }, sizeAttrs);
};
var defaultLabelProps = {
  offset: 5
};
function Label(outerProps) {
  var props = (0,_util_resolveDefaultProps__WEBPACK_IMPORTED_MODULE_8__/* .resolveDefaultProps */ .e)(outerProps, defaultLabelProps);
  var {
    viewBox: viewBoxFromProps,
    position,
    value,
    children,
    content,
    className = '',
    textBreakAll,
    labelRef
  } = props;
  var polarViewBox = usePolarLabelContext();
  var cartesianViewBox = useCartesianLabelContext();

  /*
   * I am not proud about this solution, but it's a quick fix for https://github.com/recharts/recharts/issues/6030#issuecomment-3155352460.
   * What we should really do is split Label into two components: CartesianLabel and PolarLabel and then handle their respective viewBoxes separately.
   * Also other components should set its own viewBox in a context so that we can fix https://github.com/recharts/recharts/issues/6156
   */
  var resolvedViewBox = position === 'center' ? cartesianViewBox : polarViewBox !== null && polarViewBox !== void 0 ? polarViewBox : cartesianViewBox;
  var viewBox = viewBoxFromProps || resolvedViewBox;
  if (!viewBox || (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(value) && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(children) && ! /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(content) && typeof content !== 'function') {
    return null;
  }
  var propsWithViewBox = _objectSpread(_objectSpread({}, props), {}, {
    viewBox
  });
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(content)) {
    var {
        labelRef: _
      } = propsWithViewBox,
      propsWithoutLabelRef = _objectWithoutProperties(propsWithViewBox, _excluded);
    return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(content, propsWithoutLabelRef);
  }
  var label;
  if (typeof content === 'function') {
    label = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(content, propsWithViewBox);
    if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(label)) {
      return label;
    }
  } else {
    label = getLabel(props);
  }
  var isPolarLabel = isPolar(viewBox);
  var attrs = (0,_util_svgPropertiesAndEvents__WEBPACK_IMPORTED_MODULE_9__/* .svgPropertiesAndEvents */ .a)(props);
  if (isPolarLabel && (position === 'insideStart' || position === 'insideEnd' || position === 'end')) {
    return renderRadialLabel(props, position, label, attrs, viewBox);
  }
  var positionAttrs = isPolarLabel ? getAttrsOfPolarLabel(viewBox, props.offset, props.position) : getAttrsOfCartesianLabel(props, viewBox);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Text__WEBPACK_IMPORTED_MODULE_2__/* .Text */ .E, _extends({
    ref: labelRef,
    className: (0,clsx__WEBPACK_IMPORTED_MODULE_1__/* .clsx */ .$)('recharts-label', className)
  }, attrs, positionAttrs, {
    breakAll: textBreakAll
  }), label);
}
Label.displayName = 'Label';
var parseLabel = (label, viewBox, labelRef) => {
  if (!label) {
    return null;
  }
  var commonProps = {
    viewBox,
    labelRef
  };
  if (label === true) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(Label, _extends({
      key: "label-implicit"
    }, commonProps));
  }
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(label)) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(Label, _extends({
      key: "label-implicit",
      value: label
    }, commonProps));
  }
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(label)) {
    if (label.type === Label) {
      return /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(label, _objectSpread({
        key: 'label-implicit'
      }, commonProps));
    }
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(Label, _extends({
      key: "label-implicit",
      content: label
    }, commonProps));
  }
  if (isLabelContentAFunction(label)) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(Label, _extends({
      key: "label-implicit",
      content: label
    }, commonProps));
  }
  if (label && typeof label === 'object') {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(Label, _extends({}, label, {
      key: "label-implicit"
    }, commonProps));
  }
  return null;
};
function CartesianLabelFromLabelProp(_ref3) {
  var {
    label,
    labelRef
  } = _ref3;
  var viewBox = useCartesianLabelContext();
  return parseLabel(label, viewBox, labelRef) || null;
}
function PolarLabelFromLabelProp(_ref4) {
  var {
    label
  } = _ref4;
  var viewBox = usePolarLabelContext();
  return parseLabel(label, viewBox) || null;
}

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi1iMDhlYjdhNC42MTYzODk1MDAwOWQwNDUyNjExNi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFnRDtBQUN5Qjs7QUFFekU7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLFNBQVMsK0JBQWMsQ0FBQywyQ0FBbUI7QUFDM0MsQzs7Ozs7Ozs7QUNUQTtBQUNBLHNCQUFzQix3RUFBd0UsZ0JBQWdCLHNCQUFzQixPQUFPLHNCQUFzQixvQkFBb0IsZ0RBQWdELFdBQVc7QUFDaFAseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDN0o7QUFDa0I7QUFDUjtBQUN3QjtBQUNIO0FBQ2pCO0FBQ21CO0FBQ0c7QUFDUDtBQUM2QjtBQUNqQjtBQUN4QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQSxxQkFBcUIsd0NBQWM7QUFDbkMsbURBQW1ELGlCQUFpQjtBQUNwRTtBQUNBLEdBQUc7QUFDSCxtQkFBbUIsb0JBQW9CO0FBQ3ZDLHdCQUF3QixrQkFBa0I7QUFDMUM7QUFDQTtBQUNBLHdCQUF3QixtQkFBbUI7QUFDM0M7QUFDQSxzQkFBc0IsbUJBQW1CLENBQUMsZ0RBQW9CO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QztBQUN2QztBQUNBO0FBQ0EsaUJBQWlCLCtCQUFjO0FBQy9CLEVBQUUsbUJBQVM7QUFDWCxhQUFhLHlDQUFpQjtBQUM5QixHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLCtCQUFjO0FBQy9CLEVBQUUsbUJBQVM7QUFDWCxhQUFhLHFDQUFhO0FBQzFCO0FBQ0EsZUFBZSxxQ0FBYTtBQUM1QjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixnQkFBZ0I7QUFDdkMsZ0NBQWdDLDhDQUFlO0FBQy9DLGVBQWUsd0NBQVM7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsNkNBQTZDLDRDQUFnQjtBQUM3RCxtQkFBbUIsNENBQWE7QUFDaEMsb0JBQW9CLDZDQUFjO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsbUJBQW1CO0FBQ3REO0FBQ0E7QUFDQTtBQUNBLEdBQUcsZUFBZSxtQkFBbUI7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLGdCQUFnQixtQkFBbUI7QUFDdEM7QUFDQTtBQUNBLEdBQUcsZ0JBQWdCLG1CQUFtQiwyQkFBMkI7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsc0JBQXNCLDBCQUFZO0FBQ2xDO0FBQ08scUJBQXFCLG1CQUFhO0FBQ3pDO0FBQ0EsaUNBQWlDLDhCQUFRO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixtQkFBbUI7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxFOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUtEO0FBQ0EsMENBQTBDLDBCQUEwQixtREFBbUQsb0NBQW9DLHlDQUF5QyxZQUFZLGNBQWMsd0NBQXdDLHFEQUFxRDtBQUMzVCwrQ0FBK0MsMEJBQTBCLFlBQVksdUJBQXVCLDhCQUE4QixtQ0FBbUMsZUFBZTtBQUM3SjtBQUNzQztBQUNpQjtBQUN0QztBQUNlO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLG1DQUFtQyxvREFBYTtBQUN6QztBQUNQO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQSxzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0EsR0FBRztBQUNIO0FBQ08sK0JBQStCLGlEQUFVO0FBQ3pDO0FBQ1AsaUJBQWlCLHFFQUFjO0FBQy9CLHdCQUF3QixxRkFBa0I7QUFDMUMscUJBQXFCLDZDQUFNO0FBQzNCLEVBQUUsZ0RBQVM7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSwyRUFBVztBQUMxQjtBQUNBO0FBQ0EsT0FBTztBQUNQLE1BQU07QUFDTixlQUFlLCtFQUFlO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsZ0RBQVM7QUFDWDtBQUNBO0FBQ0EsaUJBQWlCLDZFQUFjO0FBQy9CO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakVBO0FBQ0E7QUFDQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDN0o7QUFDbUI7QUFDUjtBQUNlO0FBQ2Q7QUFDWTtBQUNUO0FBQzBCOztBQUV4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxVQUFVO0FBQzNDO0FBQ0E7QUFDQTs7QUFFQSw0REFBNEQsNkRBQUk7QUFDaEUsNkNBQTZDLG9EQUFhO0FBQ25EO0FBQ1AseUNBQXlDLG9EQUFhO0FBQy9DO0FBQ1A7QUFDQSxTQUFTLGlEQUFVO0FBQ25CO0FBQ0E7QUFDQSxTQUFTLGlEQUFVO0FBQ25CO0FBQ087QUFDUDtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixnREFBbUIsQ0FBQyw0REFBSztBQUMvQztBQUNBLEdBQUc7QUFDSDtBQUNBLGdCQUFnQixvRUFBUywwQ0FBMEMsNkVBQWlCO0FBQ3BGLGtCQUFrQixvRUFBUyxVQUFVO0FBQ3JDO0FBQ0E7QUFDQSx3QkFBd0IsZ0RBQW1CLENBQUMsbURBQUs7QUFDakQ7QUFDQSxLQUFLLEVBQUUsNkZBQXNCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQSxLQUFLO0FBQ0w7QUFDQSxtQkFBbUIsaURBQW9CLFdBQVcseUVBQXVCO0FBQ3pFLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esd0JBQXdCLGdEQUFtQjtBQUMzQztBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7O0FDNUhBLHNCQUFzQix3RUFBd0UsZ0JBQWdCLHNCQUFzQixPQUFPLHNCQUFzQixvQkFBb0IsZ0RBQWdELFdBQVc7QUFDaFAseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRO0FBQ0E7QUFDQTtBQUMrQjtBQUNPO0FBQ1Y7QUFDbUI7QUFDSjtBQUNRO0FBQ25EO0FBQ08sbUNBQW1DLGdEQUFhO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsZ0RBQW1CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsMEJBQTBCLGdEQUFtQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSwwQkFBMEIsZ0RBQW1CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EscUJBQXFCLGlEQUFvQjtBQUN6QyxzQ0FBc0M7QUFDdEM7QUFDQSwwQkFBMEIsK0NBQWtCO0FBQzVDO0FBQ0Esd0JBQXdCLGdEQUFtQixDQUFDLDREQUFPO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixtREFBSTtBQUMxQjtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixnREFBbUI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sRUFBRSx3RUFBa0Isc0NBQXNDLGdEQUFtQixDQUFDLGdFQUFPO0FBQzVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLGtEQUFrRCxnREFBbUI7QUFDNUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdEQUFtQjtBQUMzQztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsRTs7Ozs7Ozs7Ozs7O0FDdks4QjtBQUNtQjtBQUNsRCxtQ0FBbUMsb0RBQWE7QUFDekMsMEJBQTBCLGlEQUFVO0FBQ3BDO0FBQ1A7QUFDQTtBQUNBLElBQUk7QUFDSixzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0EsR0FBRztBQUNILEU7Ozs7Ozs7Ozs7Ozs7OztBQ1hBLHNCQUFzQix3RUFBd0UsZ0JBQWdCLHNCQUFzQixPQUFPLHNCQUFzQixvQkFBb0IsZ0RBQWdELFdBQVc7QUFDaFAseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRO0FBQ0E7QUFDQTs7QUFFK0I7QUFDZTtBQUNsQjtBQUM4QjtBQUMxRDtBQUNBLGlDQUFpQyxxRUFBVSxjQUFjLHFFQUFVO0FBQ25FO0FBQ087QUFDUDtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCLGtCQUFrQjtBQUNsQixtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsK0RBQU07QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsVUFBVSxnREFBbUI7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsV0FBVyxFQUFFLHFFQUFVLDJCQUEyQixnREFBbUI7QUFDckU7QUFDQSxXQUFXLHFCQUFxQixxRUFBVSwyQkFBMkIsZ0RBQW1CO0FBQ3hGO0FBQ0EsV0FBVyxrQ0FBa0MsZ0RBQW1CO0FBQ2hFO0FBQ0EsV0FBVyw0QkFBNEIsZ0RBQW1CO0FBQzFEO0FBQ0EsV0FBVztBQUNYO0FBQ0EsT0FBTztBQUNQLDBCQUEwQixnREFBbUI7QUFDN0M7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSCxrQkFBa0Isb0VBQVM7QUFDM0I7QUFDQSxrQkFBa0IsbURBQUk7QUFDdEIsZ0JBQWdCLG1EQUFJO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0E7QUFDQSxHQUFHLHlDQUF5QyxnREFBbUI7QUFDL0Q7QUFDQTtBQUNBLEdBQUcsZUFBZSxpREFBb0I7QUFDdEMsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEhrQztBQUM4QjtBQUNEO0FBQzhDO0FBQ2pCO0FBQzFDO0FBQzZDO0FBQ2Q7QUFDbEI7QUFDeEQ7QUFDUDtBQUNBLGlCQUFpQix3RUFBYTtBQUM5QixvQkFBb0IscUVBQWMsQ0FBQyxvR0FBa0I7QUFDckQsd0JBQXdCLHFFQUFjLENBQUMsMkZBQXFCO0FBQzVELHdDQUF3QyxxRUFBYyxDQUFDLHlGQUFtQjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0VBQWtFLFlBQVk7QUFDOUU7QUFDQTtBQUNBO0FBQ0EsYUFBYSxxQkFBcUI7QUFDbEM7QUFDTztBQUNQO0FBQ0EsNkJBQTZCLHFFQUFjLENBQUMsMkdBQXlCO0FBQ3JFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLG9CQUFvQjtBQUNqQztBQUNPO0FBQ1AsU0FBUyxxRUFBYyxDQUFDLDJGQUFnQjtBQUN4Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxvQkFBb0I7QUFDakM7QUFDTztBQUNQLFNBQVMscUVBQWMsQ0FBQyw0RkFBaUI7QUFDekM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsb0JBQW9CO0FBQ2pDO0FBQ087QUFDUCxTQUFTLHFFQUFjO0FBQ3ZCO0FBQ087QUFDQSwyQkFBMkIscUVBQWM7QUFDekM7QUFDUCxpQkFBaUIscUVBQWM7O0FBRS9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQix3RUFBYTtBQUNoQztBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osd0NBQXdDLHNHQUE2QjtBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSxnREFBUztBQUNYLHVCQUF1QixvRkFBZ0IsV0FBVyxvRkFBZ0I7QUFDbEUsZUFBZSwwRUFBWTtBQUMzQjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxJQUFJO0FBQ0osaUJBQWlCLHFFQUFjO0FBQy9CLEVBQUUsZ0RBQVM7QUFDWCxhQUFhLHVFQUFTO0FBQ3RCLEdBQUc7QUFDSDtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlKQTtBQUNBO0FBQ0Esc0JBQXNCLHdFQUF3RSxnQkFBZ0Isc0JBQXNCLE9BQU8sc0JBQXNCLG9CQUFvQixnREFBZ0QsV0FBVztBQUNoUCwwQ0FBMEMsMEJBQTBCLG1EQUFtRCxvQ0FBb0MseUNBQXlDLFlBQVksY0FBYyx3Q0FBd0MscURBQXFEO0FBQzNULCtDQUErQywwQkFBMEIsWUFBWSx1QkFBdUIsOEJBQThCLG1DQUFtQyxlQUFlO0FBQzdKO0FBQ2E7QUFDaEI7QUFDd0M7QUFDNUI7QUFDUztBQUNLO0FBQ2tCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0EsU0FBUyxvRUFBUztBQUNsQjtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLHVFQUFhO0FBQzFCLEtBQUs7QUFDTCxvQ0FBb0MsdUVBQWE7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHlCQUF5QixtRUFBUTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxvRUFBUztBQUN4QjtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBLGdDQUFnQyx5REFBTTtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDTyx3QkFBd0IsaURBQVU7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLHFCQUFxQiw4Q0FBTztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0EsT0FBTyxxRUFBVSxhQUFhLHFFQUFVO0FBQ3hDO0FBQ0E7QUFDQSxvQkFBb0IsbUVBQVE7QUFDNUIsb0JBQW9CLG1FQUFRO0FBQzVCO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQiwyRUFBYTtBQUM3QjtBQUNBO0FBQ0EsZ0JBQWdCLDJFQUFhO0FBQzdCO0FBQ0E7QUFDQSxnQkFBZ0IsMkVBQWE7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ04sb0NBQW9DLG1FQUFRO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGdEQUFtQixvQkFBb0IsRUFBRSw2RkFBc0I7QUFDckY7QUFDQTtBQUNBO0FBQ0EsZUFBZSxtREFBSTtBQUNuQjtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLGdEQUFtQjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNELDBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hQOEM7QUFDdkM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTs7QUFFSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QiwrQkFBUztBQUNqQyx5QkFBeUIsK0JBQVM7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSix1QkFBdUIsK0JBQVM7QUFDaEMsd0JBQXdCLCtCQUFTO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQzs7OztBQ3RHQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLHlCQUF5Qix3QkFBd0Isb0NBQW9DLHlDQUF5QyxrQ0FBa0MsMERBQTBELDBCQUEwQjtBQUNwUCw0QkFBNEIsZ0JBQWdCLHNCQUFzQixPQUFPLGtEQUFrRCxzREFBc0QsOEJBQThCLG1KQUFtSixxRUFBcUUsS0FBSztBQUM1YSxvQ0FBb0Msb0VBQW9FLDBEQUEwRDtBQUNsSyw2QkFBNkIsbUNBQW1DO0FBQ2hFLDhCQUE4QiwwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUM3TztBQUNHO0FBQ3VHO0FBQ3BGO0FBQ1Y7QUFDMEU7QUFDbkQ7QUFDbEI7QUFDN0MsOENBQThDLHVCQUFhO0FBQzNEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixhQUFhLGlCQUFPO0FBQ3BCO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixtQkFBbUI7QUFDekM7QUFDQSxHQUFHO0FBQ0g7QUFDTywwQ0FBMEMsb0JBQVU7QUFDM0QseUNBQXlDLG9CQUFVO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHFCQUFxQixnQkFBTTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixnQkFBTTtBQUMxQjtBQUNBLEVBQUUsNkJBQW1CO0FBQ3JCLDBCQUEwQixrQkFBUTtBQUNsQztBQUNBO0FBQ0EsR0FBRztBQUNILHlCQUF5QixxQkFBVztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHO0FBQ0gsRUFBRSxtQkFBUztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsa0JBQVE7QUFDekI7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLEVBQUUsd0JBQUk7QUFDTjtBQUNBO0FBQ0E7QUFDQSxJQUFJLEVBQUUsd0JBQXdCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsd0JBQUk7QUFDTixzQkFBc0IsbUJBQW1CO0FBQ3pDO0FBQ0EsZUFBZSxvQkFBSTtBQUNuQix5Q0FBeUMsWUFBWTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsR0FBRyxlQUFlLG1CQUFtQjtBQUNyQyxXQUFXLGdCQUFnQjtBQUMzQjtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUcsZUFBZSxtQkFBbUI7QUFDckM7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHVDQUF1QyxvQkFBVTtBQUN4RDtBQUNBLE1BQU0sK0NBQWdCLHNDQUFzQywrQ0FBZ0I7QUFDNUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxFQUFFLHdCQUF3QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxFQUFFLHdCQUF3QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxNQUFNLDhCQUFRLHFCQUFxQiw4QkFBUTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixtQkFBbUIsbUNBQW1DO0FBQzVFO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7O0FDek5xQztBQUMvQiw4Q0FBOEMsb0RBQWEsU0FBUyxFOzs7Ozs7Ozs7OztBQ0QzQjtBQUN6QyxrQ0FBa0MscUVBQWMsOEM7Ozs7Ozs7Ozs7Ozs7QUNEdkQ7QUFDQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDNUw7QUFDQTtBQUNBO0FBQytCO0FBQ0k7QUFDUDtBQUM0QztBQUNqRSwyQkFBMkIsaURBQVU7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG1EQUFJO0FBQ3ZCLHNCQUFzQixnREFBbUIsbUJBQW1CLEVBQUUsNkZBQXNCO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUcsZ0JBQWdCLGdEQUFtQixxQ0FBcUMsZ0RBQW1CO0FBQzlGLENBQUMsRTs7Ozs7Ozs7Ozs7O0FDdENpRDtBQUMzQyx1Q0FBdUMsb0RBQWE7QUFDcEQsNEJBQTRCLGlEQUFVLHNCOzs7Ozs7Ozs7Ozs7OztBQ0ZHO0FBQzZEO0FBQ3RHO0FBQ1AsaUJBQWlCLHFFQUFjO0FBQy9CO0FBQ0E7QUFDQSxhQUFhLDBGQUEyQjtBQUN4QztBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNPO0FBQ1AsaUJBQWlCLHFFQUFjO0FBQy9CO0FBQ0E7QUFDQSxhQUFhLDZFQUFjO0FBQzNCO0FBQ0E7QUFDTztBQUNQLGlCQUFpQixxRUFBYztBQUMvQjtBQUNBO0FBQ0EsYUFBYSxzRkFBdUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5QmtDO0FBQ3NDO0FBQ1I7QUFDZDtBQUMzQztBQUNQO0FBQ0E7QUFDQSxJQUFJO0FBQ0osaUJBQWlCLHFFQUFjO0FBQy9CLG1CQUFtQix3RUFBYTtBQUNoQyxFQUFFLGdEQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSw2RUFBWTtBQUN6QjtBQUNBLGVBQWUsNkVBQVk7QUFDM0I7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLElBQUk7QUFDSixpQkFBaUIscUVBQWM7QUFDL0IsRUFBRSxnREFBUztBQUNYLGFBQWEsZ0ZBQWU7QUFDNUI7QUFDQSxlQUFlLDZFQUFZO0FBQzNCO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsTUFBTTtBQUMzQztBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsTUFBTTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08seUJBQXlCLHFFQUFjO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsU0FBUyxxRUFBYztBQUN2QixFOzs7Ozs7Ozs7O0FDN0VBO0FBQ0E7QUFDQTs7QUFFTztBQUNQLDBCOzs7Ozs7Ozs7Ozs7QUNMa0Q7QUFDM0Msd0NBQXdDLG9EQUFhO0FBQ3JELDZCQUE2QixpREFBVSx1Qjs7Ozs7Ozs7Ozs7QUNGOUM7QUFDQSwwQ0FBMEMsMEJBQTBCLG1EQUFtRCxvQ0FBb0MseUNBQXlDLFlBQVksY0FBYyx3Q0FBd0MscURBQXFEO0FBQzNULCtDQUErQywwQkFBMEIsWUFBWSx1QkFBdUIsOEJBQThCLG1DQUFtQyxlQUFlO0FBQzVMO0FBQ0E7QUFDQTtBQUMrQjtBQUNxQztBQUN6QjtBQUNIO0FBQ3hDO0FBQ0E7QUFDQSxhQUFhLFVBQVU7QUFDdkI7QUFDTztBQUNQO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLG1CQUFtQixxREFBYztBQUNqQyx5QkFBeUIsbURBQVk7QUFDckMsSUFBSTtBQUNKLHlCQUF5QixvREFBYTtBQUN0QyxJQUFJO0FBQ0osSUFBSSw2REFBSTtBQUNSO0FBQ0Esc0JBQXNCLGdEQUFtQixDQUFDLDREQUFLO0FBQy9DO0FBQ0EsR0FBRztBQUNIO0FBQ0Esc0M7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9CQTtBQUNBLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDNUwsc0JBQXNCLHdFQUF3RSxnQkFBZ0Isc0JBQXNCLE9BQU8sc0JBQXNCLG9CQUFvQixnREFBZ0QsV0FBVztBQUNqTjtBQUNJO0FBQzJDO0FBQ047QUFDYjtBQUN2QjtBQUNZO0FBQzBCO0FBQ1g7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxpREFBVTtBQUM5QyxjQUFjLG9GQUFhO0FBQzNCLGVBQWUscUZBQWM7QUFDN0IsOEJBQThCLDZGQUFxQjtBQUNuRCxPQUFPLG9GQUFnQixZQUFZLG9GQUFnQjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLHNCQUFzQixnREFBbUIsQ0FBQyxzREFBTyxhQUFhO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSix3QkFBd0IscUVBQWMsQ0FBQywyRkFBcUI7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixzQkFBc0IsZ0RBQW1CLENBQUMsc0RBQU87QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDTywrQkFBK0IsaURBQVU7QUFDaEQ7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLG1CQUFtQixnRkFBYTtBQUNoQztBQUNBLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQSxzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0EsR0FBRztBQUNILENBQUMsRTs7Ozs7Ozs7Ozs7OztBQy9GOEI7QUFDbUI7QUFDQTtBQUNsRCwwQ0FBMEMsb0RBQWE7QUFDaEQ7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixtQkFBbUIsdUVBQVc7QUFDOUIsc0JBQXNCLGdEQUFtQjtBQUN6QztBQUNBLEdBQUc7QUFDSDtBQUNPO0FBQ1AsU0FBUyxpREFBVTtBQUNuQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJBLHlCQUF5Qix3QkFBd0Isb0NBQW9DLHlDQUF5QyxrQ0FBa0MsMERBQTBELDBCQUEwQjtBQUNwUCw0QkFBNEIsZ0JBQWdCLHNCQUFzQixPQUFPLGtEQUFrRCxzREFBc0QsOEJBQThCLG1KQUFtSixxRUFBcUUsS0FBSztBQUM1YSxvQ0FBb0Msb0VBQW9FLDBEQUEwRDtBQUNsSyw2QkFBNkIsbUNBQW1DO0FBQ2hFLDhCQUE4QiwwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUMxTztBQUNPO0FBQzBCO0FBQ3pELGlDQUFpQyxtQkFBYTtBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLE1BQU0sRUFBRSx5Q0FBbUI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsS0FBSzs7QUFFTDtBQUNBLGlEQUFpRDtBQUNqRDtBQUNBLEtBQUssb0JBQW9CO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsbURBQW1ELHFCQUFxQjtBQUN4RTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxNQUFNLG1CQUFtQjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdHQSxTQUFTLHNCQUFPLFNBQVMsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsU0FBUywyQkFBYSxNQUFNLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0QsUUFBUSxzQkFBTyx1Q0FBdUMsNkJBQWUsZUFBZSx5R0FBeUcsc0JBQU8sbUNBQW1DLHFFQUFxRSxLQUFLO0FBQzVhLFNBQVMsNkJBQWUsWUFBWSxZQUFZLDRCQUFjLDBDQUEwQywwREFBMEQ7QUFDbEssU0FBUyw0QkFBYyxNQUFNLFFBQVEsMEJBQVksZUFBZTtBQUNoRSxTQUFTLDBCQUFZLFNBQVMsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDek47QUFDTztBQUM4QztBQUM1QjtBQUNsRSwyQkFBMkIsK0JBQWMsQ0FBQywwQ0FBaUI7QUFDM0Q7QUFDUDtBQUNBLHFCQUFxQiwrQkFBYyxDQUFDLCtDQUFzQjtBQUMxRCx5QkFBeUIsK0JBQWMsQ0FBQywrQ0FBc0I7QUFDOUQsU0FBUyx3Q0FBaUIsQ0FBQywyQkFBYSxDQUFDLDJCQUFhLEdBQUcsa0JBQWtCO0FBQzNFO0FBQ0EsR0FBRztBQUNILEU7Ozs7OztBQ2pCQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLFNBQVMsY0FBTyxTQUFTLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLFNBQVMsbUJBQWEsTUFBTSxnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELFFBQVEsY0FBTyx1Q0FBdUMscUJBQWUsZUFBZSx5R0FBeUcsY0FBTyxtQ0FBbUMscUVBQXFFLEtBQUs7QUFDNWEsU0FBUyxxQkFBZSxZQUFZLFlBQVksb0JBQWMsMENBQTBDLDBEQUEwRDtBQUNsSyxTQUFTLG9CQUFjLE1BQU0sUUFBUSxrQkFBWSxlQUFlO0FBQ2hFLFNBQVMsa0JBQVksU0FBUywwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUMxTztBQUNxQztBQUN4QztBQUNXO0FBQ0E7QUFDZ0M7QUFDeEI7QUFDOEI7QUFDcEM7QUFDd0I7QUFDaUI7QUFDZjtBQUNQO0FBQ3FCOztBQUVqRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJOztBQUVKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLGtCQUFLO0FBQ3RCLElBQUk7QUFDSixnQkFBZ0IsZ0RBQWtCO0FBQ2xDLGlCQUFpQiwwQkFBUztBQUMxQixJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLEVBQUUsc0RBQXFCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsb0JBQU07QUFDdkIsSUFBSTtBQUNKO0FBQ0EsY0FBYywwQ0FBZTtBQUM3QjtBQUNBLGlCQUFpQixrQkFBSztBQUN0QjtBQUNBO0FBQ0Esb0JBQW9CLG1CQUFhLENBQUMsbUJBQWEsQ0FBQyxtQkFBYSxDQUFDLG1CQUFhO0FBQzNFO0FBQ0E7QUFDQSxHQUFHLHVCQUF1QixrRUFBZ0MsYUFBYTtBQUN2RTtBQUNBO0FBQ0EsZUFBZSxvQkFBSTtBQUNuQixHQUFHO0FBQ0gsbUJBQW1CLHdCQUFjO0FBQ2pDO0FBQ0Esd0JBQXdCLHNCQUFZO0FBQ3BDO0FBQ0Esc0JBQXNCLHVCQUFhO0FBQ25DOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLDRCQUE0QixzQkFBc0I7QUFDbEQsZUFBZSxnREFBaUI7QUFDaEMsZUFBZSw2Q0FBYztBQUM3QixrQkFBa0Isa0NBQVk7QUFDOUIsc0JBQXNCLG1CQUFtQiw0QkFBNEI7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQzs7Ozs7Ozs7Ozs7O0FDcEhBLFNBQVMsZUFBTyxTQUFTLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLFNBQVMsb0JBQWEsTUFBTSxnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELFFBQVEsZUFBTyx1Q0FBdUMsc0JBQWUsZUFBZSx5R0FBeUcsZUFBTyxtQ0FBbUMscUVBQXFFLEtBQUs7QUFDNWEsU0FBUyxzQkFBZSxZQUFZLFlBQVkscUJBQWMsMENBQTBDLDBEQUEwRDtBQUNsSyxTQUFTLHFCQUFjLE1BQU0sUUFBUSxtQkFBWSxlQUFlO0FBQ2hFLFNBQVMsbUJBQVksU0FBUywwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUMxTztBQUNHO0FBQ087QUFDdUI7QUFDTjtBQUNsQjtBQUN3QjtBQUNMO0FBQ2E7QUFDWjtBQUMxQjtBQUNvRztBQUNuRTtBQUNIO0FBQ0E7QUFDNEI7QUFDWjtBQUNkO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG9CQUFvQjtBQUN2Qyx3QkFBd0Isa0JBQWtCO0FBQzFDO0FBQ0E7QUFDQSx3QkFBd0IsbUJBQW1CO0FBQzNDO0FBQ0Esc0JBQXNCLG1CQUFtQixDQUFDLGtEQUFxQjtBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQSxzQkFBc0Isb0JBQU07QUFDNUI7QUFDQSxlQUFlO0FBQ2YsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLGNBQWMsa0RBQW1CO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osaUJBQWlCLCtCQUFjO0FBQy9CO0FBQ0EsRUFBRSxtQkFBUztBQUNYLGFBQWEsZ0RBQXVCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILGdCQUFnQix5Q0FBVTtBQUMxQiwyQkFBMkIscURBQXFCO0FBQ2hELHlCQUF5QixzREFBbUI7QUFDNUM7QUFDQTtBQUNBO0FBQ0EsSUFBSSxFQUFFLCtCQUFjLFVBQVUsMkNBQXFCO0FBQ25ELHlCQUF5QiwrQkFBYyxVQUFVLDBDQUFvQjtBQUNyRSx1QkFBdUIsK0JBQWMsVUFBVSx1Q0FBaUI7QUFDaEUsbUJBQW1CLCtCQUFjLFVBQVUsNENBQXNCO0FBQ2pFO0FBQ0EsaUNBQWlDLGdEQUFnQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2Qyw0Q0FBZ0I7QUFDN0Q7QUFDQSxFQUFFLGtFQUE4QjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsd0NBQWM7QUFDakM7QUFDQTtBQUNBLG9DQUFvQyxtQkFBbUIsQ0FBQyxrQkFBa0I7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLHlCQUF5QixvQkFBYSxDQUFDLG9CQUFhLEdBQUcsWUFBWTtBQUN0RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsc0JBQXNCLG1CQUFtQixDQUFDLGNBQWMscUJBQXFCLDBCQUFZLCtEQUErRCxtQkFBbUIsQ0FBQyxNQUFNO0FBQ2xMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQzs7Ozs7Ozs7Ozs7Ozs7QUNqSytCO0FBQzZCO0FBQ2Y7QUFDTjtBQUN2QyxxQ0FBcUMsb0RBQWE7O0FBRWxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsSUFBSTtBQUNKLHFCQUFxQiwrQ0FBUSxXQUFXLG1FQUFRO0FBQ2hELGlCQUFpQiw2REFBVztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHNCQUFzQixnREFBbUI7QUFDekM7QUFDQSxHQUFHLGVBQWUsZ0RBQW1CLDRCQUE0QixnREFBbUI7QUFDcEY7QUFDQSxHQUFHLGVBQWUsZ0RBQW1CO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ087QUFDUCxTQUFTLGlEQUFVO0FBQ25CLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Q0EseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQzFPO0FBQ3NCO0FBQ0Y7QUFDaEI7QUFDUTtBQUNLO0FBQytCO0FBQ3pCO0FBQ1I7QUFDbUM7QUFDakY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUcsRUFBRSx1R0FBZ0MsY0FBYyx3RUFBa0I7QUFDckU7QUFDQSxtQkFBbUIscURBQWM7QUFDakM7QUFDQSx1QkFBdUIsbURBQVk7QUFDbkMsSUFBSTtBQUNKO0FBQ0EsSUFBSTtBQUNKLHVCQUF1QixnREFBbUIsQ0FBQyxvREFBRztBQUM5QztBQUNBLHNCQUFzQixnREFBbUIsQ0FBQyw0REFBSztBQUMvQztBQUNBLEdBQUc7QUFDSDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSiwyQkFBMkIscUVBQWMsQ0FBQyxpR0FBd0I7QUFDbEUseUJBQXlCLDRFQUEwQjtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sb0VBQVM7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEM7Ozs7Ozs7Ozs7Ozs7QUNoRkE7QUFDQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDN0o7QUFDSDtBQUM0QztBQUNqRSx5QkFBeUIsNkNBQWdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLG1CQUFtQixtREFBSTtBQUN2QixzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0EsR0FBRyxFQUFFLDZGQUFzQjtBQUMzQjtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJEO0FBQ0EsMENBQTBDLDBCQUEwQixtREFBbUQsb0NBQW9DLHlDQUF5QyxZQUFZLGNBQWMsd0NBQXdDLHFEQUFxRDtBQUMzVCwrQ0FBK0MsMEJBQTBCLFlBQVksdUJBQXVCLDhCQUE4QixtQ0FBbUMsZUFBZTtBQUM1TCx5QkFBeUIsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsNEJBQTRCLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0Qsc0RBQXNELDhCQUE4QixtSkFBbUoscUVBQXFFLEtBQUs7QUFDNWEsb0NBQW9DLG9FQUFvRSwwREFBMEQ7QUFDbEssNkJBQTZCLG1DQUFtQztBQUNoRSw4QkFBOEIsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDelEsc0JBQXNCLHdFQUF3RSxnQkFBZ0Isc0JBQXNCLE9BQU8sc0JBQXNCLG9CQUFvQixnREFBZ0QsV0FBVztBQUNqTjtBQUN5RTtBQUM1RTtBQUNFO0FBQ3NGO0FBQzlEO0FBQ0s7QUFDWDtBQUMyQjtBQUNUO0FBQ007QUFDeEUseUNBQXlDLG9EQUFhO0FBQy9DO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLGdCQUFnQiw4Q0FBTztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxzQkFBc0IsZ0RBQW1CO0FBQ3pDO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSwwQkFBMEIsaURBQVU7QUFDcEMscUJBQXFCLGlGQUFVO0FBQy9CO0FBQ0E7QUFDQSxxQ0FBcUMsb0RBQWE7QUFDM0M7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osZ0JBQWdCLDhDQUFPO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILHNCQUFzQixnREFBbUI7QUFDekM7QUFDQSxHQUFHO0FBQ0g7QUFDTztBQUNQLDBCQUEwQixpREFBVTtBQUNwQyxxQkFBcUIscUVBQWMsQ0FBQyw2RkFBa0I7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLGNBQWMsb0VBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsYUFBYSxtRUFBUTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiw0RUFBZ0I7QUFDbkMsaUJBQWlCLDRFQUFnQjtBQUNqQztBQUNBLFdBQVcsb0VBQVMsa0JBQWtCLG1FQUFRO0FBQzlDLHNCQUFzQixnREFBbUIsb0JBQW9CO0FBQzdEO0FBQ0EsZUFBZSxtREFBSTtBQUNuQixHQUFHLGdCQUFnQixnREFBbUIsNEJBQTRCLGdEQUFtQjtBQUNyRjtBQUNBO0FBQ0EsR0FBRyxpQkFBaUIsZ0RBQW1CO0FBQ3ZDO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTSxFQUFFLDRFQUFnQjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxFQUFFLDRFQUFnQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxtRUFBUTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTs7QUFFSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0EsTUFBTSxJQUFJO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0EsTUFBTSxJQUFJO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0EsTUFBTSxJQUFJO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0EsTUFBTSxJQUFJO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EscURBQXFELG1FQUFRLGdCQUFnQixvRUFBUyxrQkFBa0IsbUVBQVEsZ0JBQWdCLG9FQUFTO0FBQ3pJO0FBQ0EsYUFBYSwwRUFBZTtBQUM1QixhQUFhLDBFQUFlO0FBQzVCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxjQUFjLHVGQUFtQjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixvRUFBUyxXQUFXLG9FQUFTLDZCQUE2QixxREFBYztBQUMxRjtBQUNBO0FBQ0EsdURBQXVELFlBQVk7QUFDbkU7QUFDQSxHQUFHO0FBQ0gsbUJBQW1CLHFEQUFjO0FBQ2pDO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQSx3QkFBd0IsbURBQVk7QUFDcEM7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLG9EQUFhO0FBQ3RDLHFCQUFxQixxREFBYztBQUNuQztBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLGNBQWMsNkZBQXNCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGdEQUFtQixDQUFDLGdEQUFJO0FBQzlDO0FBQ0EsZUFBZSxtREFBSTtBQUNuQixHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQSxLQUFLO0FBQ0w7QUFDQSxNQUFNLHFFQUFVO0FBQ2hCLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLG1CQUFtQixxREFBYztBQUNqQztBQUNBLDBCQUEwQixtREFBWTtBQUN0QztBQUNBLE9BQU87QUFDUDtBQUNBLHdCQUF3QixnREFBbUI7QUFDM0M7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0Esd0JBQXdCLGdEQUFtQjtBQUMzQztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3QkFBd0IsZ0RBQW1CLG1CQUFtQjtBQUM5RDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGV4dC9sZWdlbmRQYXlsb2FkQ29udGV4dC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29tcG9uZW50L0xlZ2VuZC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGV4dC9FcnJvckJhckNvbnRleHQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbXBvbmVudC9MYWJlbExpc3QuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbXBvbmVudC9EZWZhdWx0TGVnZW5kQ29udGVudC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGV4dC9QYW5vcmFtYUNvbnRleHQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbXBvbmVudC9EZWZhdWx0VG9vbHRpcENvbnRlbnQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb21wb25lbnQvVGV4dC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29tcG9uZW50L3Jlc3BvbnNpdmVDb250YWluZXJVdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29tcG9uZW50L1Jlc3BvbnNpdmVDb250YWluZXIuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbnRleHQvYnJ1c2hVcGRhdGVDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L2FjY2Vzc2liaWxpdHlDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250YWluZXIvU3VyZmFjZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGV4dC9sZWdlbmRQb3J0YWxDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L3Rvb2x0aXBDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L2NoYXJ0RGF0YUNvbnRleHQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbXBvbmVudC9DZWxsLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L3Rvb2x0aXBQb3J0YWxDb250ZXh0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb21wb25lbnQvQ3VzdG9taXplZC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGFpbmVyL1Jvb3RTdXJmYWNlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L1JlZ2lzdGVyR3JhcGhpY2FsSXRlbUlkLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb21wb25lbnQvVG9vbHRpcEJvdW5kaW5nQm94LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb250ZXh0L3VzZVRvb2x0aXBBeGlzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb21wb25lbnQvQ3Vyc29yLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9jb21wb25lbnQvVG9vbHRpcC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29udGFpbmVyL0NsaXBQYXRoUHJvdmlkZXIuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbXBvbmVudC9BY3RpdmVQb2ludHMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L2NvbnRhaW5lci9MYXllci5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvY29tcG9uZW50L0xhYmVsLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vc3RhdGUvaG9va3MnO1xuaW1wb3J0IHsgc2VsZWN0TGVnZW5kUGF5bG9hZCB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9sZWdlbmRTZWxlY3RvcnMnO1xuXG4vKipcbiAqIFVzZSB0aGlzIGhvb2sgaW4gTGVnZW5kLCBvciBhbnl3aGVyZSBlbHNlIHdoZXJlIHlvdSB3YW50IHRvIHJlYWQgdGhlIGN1cnJlbnQgTGVnZW5kIGl0ZW1zLlxuICogQHJldHVybiBhbGwgTGVnZW5kIGl0ZW1zIHJlYWR5IHRvIGJlIHJlbmRlcmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VMZWdlbmRQYXlsb2FkKCkge1xuICByZXR1cm4gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0TGVnZW5kUGF5bG9hZCk7XG59IiwidmFyIF9leGNsdWRlZCA9IFtcImNvbnRleHRQYXlsb2FkXCJdO1xuZnVuY3Rpb24gX2V4dGVuZHMoKSB7IHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7IGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7IHZhciB0ID0gYXJndW1lbnRzW2VdOyBmb3IgKHZhciByIGluIHQpICh7fSkuaGFzT3duUHJvcGVydHkuY2FsbCh0LCByKSAmJiAobltyXSA9IHRbcl0pOyB9IHJldHVybiBuOyB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpOyB9XG5mdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhlLCB0KSB7IGlmIChudWxsID09IGUpIHJldHVybiB7fTsgdmFyIG8sIHIsIGkgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShlLCB0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG4gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyBmb3IgKHIgPSAwOyByIDwgbi5sZW5ndGg7IHIrKykgbyA9IG5bcl0sIC0xID09PSB0LmluZGV4T2YobykgJiYge30ucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChlLCBvKSAmJiAoaVtvXSA9IGVbb10pOyB9IHJldHVybiBpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShyLCBlKSB7IGlmIChudWxsID09IHIpIHJldHVybiB7fTsgdmFyIHQgPSB7fTsgZm9yICh2YXIgbiBpbiByKSBpZiAoe30uaGFzT3duUHJvcGVydHkuY2FsbChyLCBuKSkgeyBpZiAoLTEgIT09IGUuaW5kZXhPZihuKSkgY29udGludWU7IHRbbl0gPSByW25dOyB9IHJldHVybiB0OyB9XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBQdXJlQ29tcG9uZW50LCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVQb3J0YWwgfSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0IHsgdXNlTGVnZW5kUG9ydGFsIH0gZnJvbSAnLi4vY29udGV4dC9sZWdlbmRQb3J0YWxDb250ZXh0JztcbmltcG9ydCB7IERlZmF1bHRMZWdlbmRDb250ZW50IH0gZnJvbSAnLi9EZWZhdWx0TGVnZW5kQ29udGVudCc7XG5pbXBvcnQgeyBpc051bWJlciB9IGZyb20gJy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IGdldFVuaXFQYXlsb2FkIH0gZnJvbSAnLi4vdXRpbC9wYXlsb2FkL2dldFVuaXFQYXlsb2FkJztcbmltcG9ydCB7IHVzZUxlZ2VuZFBheWxvYWQgfSBmcm9tICcuLi9jb250ZXh0L2xlZ2VuZFBheWxvYWRDb250ZXh0JztcbmltcG9ydCB7IHVzZUVsZW1lbnRPZmZzZXQgfSBmcm9tICcuLi91dGlsL3VzZUVsZW1lbnRPZmZzZXQnO1xuaW1wb3J0IHsgdXNlQ2hhcnRIZWlnaHQsIHVzZUNoYXJ0V2lkdGgsIHVzZU1hcmdpbiB9IGZyb20gJy4uL2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0JztcbmltcG9ydCB7IHNldExlZ2VuZFNldHRpbmdzLCBzZXRMZWdlbmRTaXplIH0gZnJvbSAnLi4vc3RhdGUvbGVnZW5kU2xpY2UnO1xuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5mdW5jdGlvbiBkZWZhdWx0VW5pcUJ5KGVudHJ5KSB7XG4gIHJldHVybiBlbnRyeS52YWx1ZTtcbn1cbmZ1bmN0aW9uIExlZ2VuZENvbnRlbnQocHJvcHMpIHtcbiAgdmFyIHtcbiAgICAgIGNvbnRleHRQYXlsb2FkXG4gICAgfSA9IHByb3BzLFxuICAgIG90aGVyUHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMocHJvcHMsIF9leGNsdWRlZCk7XG4gIHZhciBmaW5hbFBheWxvYWQgPSBnZXRVbmlxUGF5bG9hZChjb250ZXh0UGF5bG9hZCwgcHJvcHMucGF5bG9hZFVuaXFCeSwgZGVmYXVsdFVuaXFCeSk7XG4gIHZhciBjb250ZW50UHJvcHMgPSBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIG90aGVyUHJvcHMpLCB7fSwge1xuICAgIHBheWxvYWQ6IGZpbmFsUGF5bG9hZFxuICB9KTtcbiAgaWYgKC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChwcm9wcy5jb250ZW50KSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY2xvbmVFbGVtZW50KHByb3BzLmNvbnRlbnQsIGNvbnRlbnRQcm9wcyk7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcm9wcy5jb250ZW50ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KHByb3BzLmNvbnRlbnQsIGNvbnRlbnRQcm9wcyk7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KERlZmF1bHRMZWdlbmRDb250ZW50LCBjb250ZW50UHJvcHMpO1xufVxuZnVuY3Rpb24gZ2V0RGVmYXVsdFBvc2l0aW9uKHN0eWxlLCBwcm9wcywgbWFyZ2luLCBjaGFydFdpZHRoLCBjaGFydEhlaWdodCwgYm94KSB7XG4gIHZhciB7XG4gICAgbGF5b3V0LFxuICAgIGFsaWduLFxuICAgIHZlcnRpY2FsQWxpZ25cbiAgfSA9IHByb3BzO1xuICB2YXIgaFBvcywgdlBvcztcbiAgaWYgKCFzdHlsZSB8fCAoc3R5bGUubGVmdCA9PT0gdW5kZWZpbmVkIHx8IHN0eWxlLmxlZnQgPT09IG51bGwpICYmIChzdHlsZS5yaWdodCA9PT0gdW5kZWZpbmVkIHx8IHN0eWxlLnJpZ2h0ID09PSBudWxsKSkge1xuICAgIGlmIChhbGlnbiA9PT0gJ2NlbnRlcicgJiYgbGF5b3V0ID09PSAndmVydGljYWwnKSB7XG4gICAgICBoUG9zID0ge1xuICAgICAgICBsZWZ0OiAoKGNoYXJ0V2lkdGggfHwgMCkgLSBib3gud2lkdGgpIC8gMlxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgaFBvcyA9IGFsaWduID09PSAncmlnaHQnID8ge1xuICAgICAgICByaWdodDogbWFyZ2luICYmIG1hcmdpbi5yaWdodCB8fCAwXG4gICAgICB9IDoge1xuICAgICAgICBsZWZ0OiBtYXJnaW4gJiYgbWFyZ2luLmxlZnQgfHwgMFxuICAgICAgfTtcbiAgICB9XG4gIH1cbiAgaWYgKCFzdHlsZSB8fCAoc3R5bGUudG9wID09PSB1bmRlZmluZWQgfHwgc3R5bGUudG9wID09PSBudWxsKSAmJiAoc3R5bGUuYm90dG9tID09PSB1bmRlZmluZWQgfHwgc3R5bGUuYm90dG9tID09PSBudWxsKSkge1xuICAgIGlmICh2ZXJ0aWNhbEFsaWduID09PSAnbWlkZGxlJykge1xuICAgICAgdlBvcyA9IHtcbiAgICAgICAgdG9wOiAoKGNoYXJ0SGVpZ2h0IHx8IDApIC0gYm94LmhlaWdodCkgLyAyXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICB2UG9zID0gdmVydGljYWxBbGlnbiA9PT0gJ2JvdHRvbScgPyB7XG4gICAgICAgIGJvdHRvbTogbWFyZ2luICYmIG1hcmdpbi5ib3R0b20gfHwgMFxuICAgICAgfSA6IHtcbiAgICAgICAgdG9wOiBtYXJnaW4gJiYgbWFyZ2luLnRvcCB8fCAwXG4gICAgICB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBoUG9zKSwgdlBvcyk7XG59XG5mdW5jdGlvbiBMZWdlbmRTZXR0aW5nc0Rpc3BhdGNoZXIocHJvcHMpIHtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkaXNwYXRjaChzZXRMZWdlbmRTZXR0aW5ncyhwcm9wcykpO1xuICB9LCBbZGlzcGF0Y2gsIHByb3BzXSk7XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gTGVnZW5kU2l6ZURpc3BhdGNoZXIocHJvcHMpIHtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkaXNwYXRjaChzZXRMZWdlbmRTaXplKHByb3BzKSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRpc3BhdGNoKHNldExlZ2VuZFNpemUoe1xuICAgICAgICB3aWR0aDogMCxcbiAgICAgICAgaGVpZ2h0OiAwXG4gICAgICB9KSk7XG4gICAgfTtcbiAgfSwgW2Rpc3BhdGNoLCBwcm9wc10pO1xuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIExlZ2VuZFdyYXBwZXIocHJvcHMpIHtcbiAgdmFyIGNvbnRleHRQYXlsb2FkID0gdXNlTGVnZW5kUGF5bG9hZCgpO1xuICB2YXIgbGVnZW5kUG9ydGFsRnJvbUNvbnRleHQgPSB1c2VMZWdlbmRQb3J0YWwoKTtcbiAgdmFyIG1hcmdpbiA9IHVzZU1hcmdpbigpO1xuICB2YXIge1xuICAgIHdpZHRoOiB3aWR0aEZyb21Qcm9wcyxcbiAgICBoZWlnaHQ6IGhlaWdodEZyb21Qcm9wcyxcbiAgICB3cmFwcGVyU3R5bGUsXG4gICAgcG9ydGFsOiBwb3J0YWxGcm9tUHJvcHNcbiAgfSA9IHByb3BzO1xuICAvLyBUaGUgY29udGV4dFBheWxvYWQgaXMgbm90IHVzZWQgZGlyZWN0bHkgaW5zaWRlIHRoZSBob29rLCBidXQgd2UgbmVlZCB0aGUgb25CQm94VXBkYXRlIGNhbGxcbiAgLy8gd2hlbiB0aGUgcGF5bG9hZCBjaGFuZ2VzLCB0aGVyZWZvcmUgaXQncyBoZXJlIGFzIGEgZGVwZW5kZW5jeS5cbiAgdmFyIFtsYXN0Qm91bmRpbmdCb3gsIHVwZGF0ZUJvdW5kaW5nQm94XSA9IHVzZUVsZW1lbnRPZmZzZXQoW2NvbnRleHRQYXlsb2FkXSk7XG4gIHZhciBjaGFydFdpZHRoID0gdXNlQ2hhcnRXaWR0aCgpO1xuICB2YXIgY2hhcnRIZWlnaHQgPSB1c2VDaGFydEhlaWdodCgpO1xuICBpZiAoY2hhcnRXaWR0aCA9PSBudWxsIHx8IGNoYXJ0SGVpZ2h0ID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgbWF4V2lkdGggPSBjaGFydFdpZHRoIC0gKG1hcmdpbi5sZWZ0IHx8IDApIC0gKG1hcmdpbi5yaWdodCB8fCAwKTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11c2UtYmVmb3JlLWRlZmluZVxuICB2YXIgd2lkdGhPckhlaWdodCA9IExlZ2VuZC5nZXRXaWR0aE9ySGVpZ2h0KHByb3BzLmxheW91dCwgaGVpZ2h0RnJvbVByb3BzLCB3aWR0aEZyb21Qcm9wcywgbWF4V2lkdGgpO1xuICAvLyBpZiB0aGUgdXNlciBzdXBwbGllcyB0aGVpciBvd24gcG9ydGFsLCBvbmx5IHVzZSB0aGVpciBkZWZpbmVkIHdyYXBwZXIgc3R5bGVzXG4gIHZhciBvdXRlclN0eWxlID0gcG9ydGFsRnJvbVByb3BzID8gd3JhcHBlclN0eWxlIDogX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHtcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB3aWR0aDogKHdpZHRoT3JIZWlnaHQgPT09IG51bGwgfHwgd2lkdGhPckhlaWdodCA9PT0gdm9pZCAwID8gdm9pZCAwIDogd2lkdGhPckhlaWdodC53aWR0aCkgfHwgd2lkdGhGcm9tUHJvcHMgfHwgJ2F1dG8nLFxuICAgIGhlaWdodDogKHdpZHRoT3JIZWlnaHQgPT09IG51bGwgfHwgd2lkdGhPckhlaWdodCA9PT0gdm9pZCAwID8gdm9pZCAwIDogd2lkdGhPckhlaWdodC5oZWlnaHQpIHx8IGhlaWdodEZyb21Qcm9wcyB8fCAnYXV0bydcbiAgfSwgZ2V0RGVmYXVsdFBvc2l0aW9uKHdyYXBwZXJTdHlsZSwgcHJvcHMsIG1hcmdpbiwgY2hhcnRXaWR0aCwgY2hhcnRIZWlnaHQsIGxhc3RCb3VuZGluZ0JveCkpLCB3cmFwcGVyU3R5bGUpO1xuICB2YXIgbGVnZW5kUG9ydGFsID0gcG9ydGFsRnJvbVByb3BzICE9PSBudWxsICYmIHBvcnRhbEZyb21Qcm9wcyAhPT0gdm9pZCAwID8gcG9ydGFsRnJvbVByb3BzIDogbGVnZW5kUG9ydGFsRnJvbUNvbnRleHQ7XG4gIGlmIChsZWdlbmRQb3J0YWwgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBsZWdlbmRFbGVtZW50ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIGNsYXNzTmFtZTogXCJyZWNoYXJ0cy1sZWdlbmQtd3JhcHBlclwiLFxuICAgIHN0eWxlOiBvdXRlclN0eWxlLFxuICAgIHJlZjogdXBkYXRlQm91bmRpbmdCb3hcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGVnZW5kU2V0dGluZ3NEaXNwYXRjaGVyLCB7XG4gICAgbGF5b3V0OiBwcm9wcy5sYXlvdXQsXG4gICAgYWxpZ246IHByb3BzLmFsaWduLFxuICAgIHZlcnRpY2FsQWxpZ246IHByb3BzLnZlcnRpY2FsQWxpZ24sXG4gICAgaXRlbVNvcnRlcjogcHJvcHMuaXRlbVNvcnRlclxuICB9KSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGVnZW5kU2l6ZURpc3BhdGNoZXIsIHtcbiAgICB3aWR0aDogbGFzdEJvdW5kaW5nQm94LndpZHRoLFxuICAgIGhlaWdodDogbGFzdEJvdW5kaW5nQm94LmhlaWdodFxuICB9KSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGVnZW5kQ29udGVudCwgX2V4dGVuZHMoe30sIHByb3BzLCB3aWR0aE9ySGVpZ2h0LCB7XG4gICAgbWFyZ2luOiBtYXJnaW4sXG4gICAgY2hhcnRXaWR0aDogY2hhcnRXaWR0aCxcbiAgICBjaGFydEhlaWdodDogY2hhcnRIZWlnaHQsXG4gICAgY29udGV4dFBheWxvYWQ6IGNvbnRleHRQYXlsb2FkXG4gIH0pKSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovY3JlYXRlUG9ydGFsKGxlZ2VuZEVsZW1lbnQsIGxlZ2VuZFBvcnRhbCk7XG59XG5leHBvcnQgY2xhc3MgTGVnZW5kIGV4dGVuZHMgUHVyZUNvbXBvbmVudCB7XG4gIHN0YXRpYyBnZXRXaWR0aE9ySGVpZ2h0KGxheW91dCwgaGVpZ2h0LCB3aWR0aCwgbWF4V2lkdGgpIHtcbiAgICBpZiAobGF5b3V0ID09PSAndmVydGljYWwnICYmIGlzTnVtYmVyKGhlaWdodCkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGhlaWdodFxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGxheW91dCA9PT0gJ2hvcml6b250YWwnKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB3aWR0aDogd2lkdGggfHwgbWF4V2lkdGhcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGVnZW5kV3JhcHBlciwgdGhpcy5wcm9wcyk7XG4gIH1cbn1cbl9kZWZpbmVQcm9wZXJ0eShMZWdlbmQsIFwiZGlzcGxheU5hbWVcIiwgJ0xlZ2VuZCcpO1xuX2RlZmluZVByb3BlcnR5KExlZ2VuZCwgXCJkZWZhdWx0UHJvcHNcIiwge1xuICBhbGlnbjogJ2NlbnRlcicsXG4gIGljb25TaXplOiAxNCxcbiAgaXRlbVNvcnRlcjogJ3ZhbHVlJyxcbiAgbGF5b3V0OiAnaG9yaXpvbnRhbCcsXG4gIHZlcnRpY2FsQWxpZ246ICdib3R0b20nXG59KTsiLCJ2YXIgX2V4Y2x1ZGVkID0gW1wiY2hpbGRyZW5cIl07XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFcnJvckJhciwgcmVtb3ZlRXJyb3JCYXIsIHJlcGxhY2VFcnJvckJhciB9IGZyb20gJy4uL3N0YXRlL2Vycm9yQmFyU2xpY2UnO1xuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5pbXBvcnQgeyB1c2VHcmFwaGljYWxJdGVtSWQgfSBmcm9tICcuL1JlZ2lzdGVyR3JhcGhpY2FsSXRlbUlkJztcbnZhciBpbml0aWFsQ29udGV4dFN0YXRlID0ge1xuICBkYXRhOiBbXSxcbiAgeEF4aXNJZDogJ3hBeGlzLTAnLFxuICB5QXhpc0lkOiAneUF4aXMtMCcsXG4gIGRhdGFQb2ludEZvcm1hdHRlcjogKCkgPT4gKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgdmFsdWU6IDBcbiAgfSksXG4gIGVycm9yQmFyT2Zmc2V0OiAwXG59O1xudmFyIEVycm9yQmFyQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KGluaXRpYWxDb250ZXh0U3RhdGUpO1xuZXhwb3J0IGZ1bmN0aW9uIFNldEVycm9yQmFyQ29udGV4dChwcm9wcykge1xuICB2YXIge1xuICAgICAgY2hpbGRyZW5cbiAgICB9ID0gcHJvcHMsXG4gICAgcmVzdCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhwcm9wcywgX2V4Y2x1ZGVkKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEVycm9yQmFyQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiByZXN0XG4gIH0sIGNoaWxkcmVuKTtcbn1cbmV4cG9ydCB2YXIgdXNlRXJyb3JCYXJDb250ZXh0ID0gKCkgPT4gdXNlQ29udGV4dChFcnJvckJhckNvbnRleHQpO1xuZXhwb3J0IGZ1bmN0aW9uIFJlcG9ydEVycm9yQmFyU2V0dGluZ3MocHJvcHMpIHtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdmFyIGdyYXBoaWNhbEl0ZW1JZCA9IHVzZUdyYXBoaWNhbEl0ZW1JZCgpO1xuICB2YXIgcHJldlByb3BzUmVmID0gdXNlUmVmKG51bGwpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChncmFwaGljYWxJdGVtSWQgPT0gbnVsbCkge1xuICAgICAgLy8gRXJyb3JCYXIgb3V0c2lkZSBhIGdyYXBoaWNhbCBpdGVtIGNvbnRleHQgZG9lcyBub3QgZG8gYW55dGhpbmcuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChwcmV2UHJvcHNSZWYuY3VycmVudCA9PT0gbnVsbCkge1xuICAgICAgZGlzcGF0Y2goYWRkRXJyb3JCYXIoe1xuICAgICAgICBpdGVtSWQ6IGdyYXBoaWNhbEl0ZW1JZCxcbiAgICAgICAgZXJyb3JCYXI6IHByb3BzXG4gICAgICB9KSk7XG4gICAgfSBlbHNlIGlmIChwcmV2UHJvcHNSZWYuY3VycmVudCAhPT0gcHJvcHMpIHtcbiAgICAgIGRpc3BhdGNoKHJlcGxhY2VFcnJvckJhcih7XG4gICAgICAgIGl0ZW1JZDogZ3JhcGhpY2FsSXRlbUlkLFxuICAgICAgICBwcmV2OiBwcmV2UHJvcHNSZWYuY3VycmVudCxcbiAgICAgICAgbmV4dDogcHJvcHNcbiAgICAgIH0pKTtcbiAgICB9XG4gICAgcHJldlByb3BzUmVmLmN1cnJlbnQgPSBwcm9wcztcbiAgfSwgW2Rpc3BhdGNoLCBncmFwaGljYWxJdGVtSWQsIHByb3BzXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChwcmV2UHJvcHNSZWYuY3VycmVudCAhPSBudWxsKSB7XG4gICAgICAgIGRpc3BhdGNoKHJlbW92ZUVycm9yQmFyKHtcbiAgICAgICAgICBpdGVtSWQ6IGdyYXBoaWNhbEl0ZW1JZCxcbiAgICAgICAgICBlcnJvckJhcjogcHJldlByb3BzUmVmLmN1cnJlbnRcbiAgICAgICAgfSkpO1xuICAgICAgICBwcmV2UHJvcHNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2Rpc3BhdGNoLCBncmFwaGljYWxJdGVtSWRdKTtcbiAgcmV0dXJuIG51bGw7XG59IiwidmFyIF9leGNsdWRlZCA9IFtcInZhbHVlQWNjZXNzb3JcIl0sXG4gIF9leGNsdWRlZDIgPSBbXCJkYXRhS2V5XCIsIFwiY2xvY2tXaXNlXCIsIFwiaWRcIiwgXCJ0ZXh0QnJlYWtBbGxcIl07XG5mdW5jdGlvbiBfZXh0ZW5kcygpIHsgcmV0dXJuIF9leHRlbmRzID0gT2JqZWN0LmFzc2lnbiA/IE9iamVjdC5hc3NpZ24uYmluZCgpIDogZnVuY3Rpb24gKG4pIHsgZm9yICh2YXIgZSA9IDE7IGUgPCBhcmd1bWVudHMubGVuZ3RoOyBlKyspIHsgdmFyIHQgPSBhcmd1bWVudHNbZV07IGZvciAodmFyIHIgaW4gdCkgKHt9KS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsIHIpICYmIChuW3JdID0gdFtyXSk7IH0gcmV0dXJuIG47IH0sIF9leHRlbmRzLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7IH1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhlLCB0KSB7IGlmIChudWxsID09IGUpIHJldHVybiB7fTsgdmFyIG8sIHIsIGkgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShlLCB0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG4gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyBmb3IgKHIgPSAwOyByIDwgbi5sZW5ndGg7IHIrKykgbyA9IG5bcl0sIC0xID09PSB0LmluZGV4T2YobykgJiYge30ucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChlLCBvKSAmJiAoaVtvXSA9IGVbb10pOyB9IHJldHVybiBpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShyLCBlKSB7IGlmIChudWxsID09IHIpIHJldHVybiB7fTsgdmFyIHQgPSB7fTsgZm9yICh2YXIgbiBpbiByKSBpZiAoe30uaGFzT3duUHJvcGVydHkuY2FsbChyLCBuKSkgeyBpZiAoLTEgIT09IGUuaW5kZXhPZihuKSkgY29udGludWU7IHRbbl0gPSByW25dOyB9IHJldHVybiB0OyB9XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGxhc3QgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvbGFzdCc7XG5pbXBvcnQgeyBpc0xhYmVsQ29udGVudEFGdW5jdGlvbiwgTGFiZWwgfSBmcm9tICcuL0xhYmVsJztcbmltcG9ydCB7IExheWVyIH0gZnJvbSAnLi4vY29udGFpbmVyL0xheWVyJztcbmltcG9ydCB7IGdldFZhbHVlQnlEYXRhS2V5IH0gZnJvbSAnLi4vdXRpbC9DaGFydFV0aWxzJztcbmltcG9ydCB7IGlzTnVsbGlzaCB9IGZyb20gJy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IHN2Z1Byb3BlcnRpZXNBbmRFdmVudHMgfSBmcm9tICcuLi91dGlsL3N2Z1Byb3BlcnRpZXNBbmRFdmVudHMnO1xuXG4vKipcbiAqIFRoaXMgaXMgcHVibGljIEFQSSBiZWNhdXNlIHdlIGV4cG9zZSBpdCBhcyB0aGUgdmFsdWVBY2Nlc3NvciBwYXJhbWV0ZXIuXG4gKlxuICogVGhlIHByb3BlcnRpZXMgb2YgXCJ2aWV3Qm94XCIgYXJlIHJlcGVhdGVkIGFzIHRoZSByb290IHByb3BzIG9mIHRoZSBlbnRyeSBvYmplY3QuXG4gKiBTbyBpdCBkb2Vzbid0IG1hdHRlciBpZiB5b3UgcmVhZCBlbnRyeS54IG9yIGVudHJ5LnZpZXdCb3gueCwgdGhleSBhcmUgdGhlIHNhbWUuXG4gKlxuICogSXQncyBub3QgbmVjZXNzYXJ5IHRvIHBhc3MgcmVkdW5kYW50IGRhdGEsIGJ1dCB3ZSBrZWVwIGl0IGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LlxuICovXG5cbi8qKlxuICogTGFiZWxMaXN0IHByb3BzIGRvIG5vdCBhbGxvdyByZWZzIGJlY2F1c2UgdGhlIHNhbWUgcHJvcHMgYXJlIHJldXNlZCBpbiBtdWx0aXBsZSBlbGVtZW50cyBzbyB3ZSBkb24ndCBoYXZlIGEgZ29vZCBzaW5nbGUgcGxhY2UgdG8gcmVmIHRvLlxuICovXG5cbi8qKlxuICogVGhpcyBpcyB0aGUgdHlwZSBhY2NlcHRlZCBmb3IgdGhlIGBsYWJlbGAgcHJvcCBvbiB2YXJpb3VzIGdyYXBoaWNhbCBpdGVtcy5cbiAqIEl0IGFjY2VwdHM6XG4gKlxuICogYm9vbGVhbjpcbiAqICAgIHRydWUgPSBsYWJlbHMgc2hvdyxcbiAqICAgIGZhbHNlID0gbGFiZWxzIGRvbid0IHNob3dcbiAqIFJlYWN0IGVsZW1lbnQ6XG4gKiAgICB3aWxsIGJlIGNsb25lZCB3aXRoIGV4dHJhIHByb3BzXG4gKiBmdW5jdGlvbjpcbiAqICAgIGlzIHVzZWQgYXMgPExhYmVsIGNvbnRlbnQ9e2Z1bmN0aW9ufSAvPiwgc28gdGhpcyB3aWxsIGJlIGNhbGxlZCBvbmNlIGZvciBlYWNoIGluZGl2aWR1YWwgbGFiZWwgKHNvIHR5cGljYWxseSBvbmNlIGZvciBlYWNoIGRhdGEgcG9pbnQpXG4gKiBvYmplY3Q6XG4gKiAgICB0aGUgcHJvcHMgdG8gYmUgcGFzc2VkIHRvIGEgTGFiZWxMaXN0IGNvbXBvbmVudFxuICovXG5cbnZhciBkZWZhdWx0QWNjZXNzb3IgPSBlbnRyeSA9PiBBcnJheS5pc0FycmF5KGVudHJ5LnZhbHVlKSA/IGxhc3QoZW50cnkudmFsdWUpIDogZW50cnkudmFsdWU7XG52YXIgQ2FydGVzaWFuTGFiZWxMaXN0Q29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5leHBvcnQgdmFyIENhcnRlc2lhbkxhYmVsTGlzdENvbnRleHRQcm92aWRlciA9IENhcnRlc2lhbkxhYmVsTGlzdENvbnRleHQuUHJvdmlkZXI7XG52YXIgUG9sYXJMYWJlbExpc3RDb250ZXh0ID0gLyojX19QVVJFX18qL2NyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmV4cG9ydCB2YXIgUG9sYXJMYWJlbExpc3RDb250ZXh0UHJvdmlkZXIgPSBQb2xhckxhYmVsTGlzdENvbnRleHQuUHJvdmlkZXI7XG5mdW5jdGlvbiB1c2VDYXJ0ZXNpYW5MYWJlbExpc3RDb250ZXh0KCkge1xuICByZXR1cm4gdXNlQ29udGV4dChDYXJ0ZXNpYW5MYWJlbExpc3RDb250ZXh0KTtcbn1cbmZ1bmN0aW9uIHVzZVBvbGFyTGFiZWxMaXN0Q29udGV4dCgpIHtcbiAgcmV0dXJuIHVzZUNvbnRleHQoUG9sYXJMYWJlbExpc3RDb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBMYWJlbExpc3QoX3JlZikge1xuICB2YXIge1xuICAgICAgdmFsdWVBY2Nlc3NvciA9IGRlZmF1bHRBY2Nlc3NvclxuICAgIH0gPSBfcmVmLFxuICAgIHJlc3RQcm9wcyA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmLCBfZXhjbHVkZWQpO1xuICB2YXIge1xuICAgICAgZGF0YUtleSxcbiAgICAgIGNsb2NrV2lzZSxcbiAgICAgIGlkLFxuICAgICAgdGV4dEJyZWFrQWxsXG4gICAgfSA9IHJlc3RQcm9wcyxcbiAgICBvdGhlcnMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMocmVzdFByb3BzLCBfZXhjbHVkZWQyKTtcbiAgdmFyIGNhcnRlc2lhbkRhdGEgPSB1c2VDYXJ0ZXNpYW5MYWJlbExpc3RDb250ZXh0KCk7XG4gIHZhciBwb2xhckRhdGEgPSB1c2VQb2xhckxhYmVsTGlzdENvbnRleHQoKTtcbiAgdmFyIGRhdGEgPSBjYXJ0ZXNpYW5EYXRhIHx8IHBvbGFyRGF0YTtcbiAgaWYgKCFkYXRhIHx8ICFkYXRhLmxlbmd0aCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYXllciwge1xuICAgIGNsYXNzTmFtZTogXCJyZWNoYXJ0cy1sYWJlbC1saXN0XCJcbiAgfSwgZGF0YS5tYXAoKGVudHJ5LCBpbmRleCkgPT4ge1xuICAgIHZhciBfcmVzdFByb3BzJGZpbGw7XG4gICAgdmFyIHZhbHVlID0gaXNOdWxsaXNoKGRhdGFLZXkpID8gdmFsdWVBY2Nlc3NvcihlbnRyeSwgaW5kZXgpIDogZ2V0VmFsdWVCeURhdGFLZXkoZW50cnkgJiYgZW50cnkucGF5bG9hZCwgZGF0YUtleSk7XG4gICAgdmFyIGlkUHJvcHMgPSBpc051bGxpc2goaWQpID8ge30gOiB7XG4gICAgICBpZDogXCJcIi5jb25jYXQoaWQsIFwiLVwiKS5jb25jYXQoaW5kZXgpXG4gICAgfTtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIF9leHRlbmRzKHtcbiAgICAgIGtleTogXCJsYWJlbC1cIi5jb25jYXQoaW5kZXgpIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgcmVhY3Qvbm8tYXJyYXktaW5kZXgta2V5XG4gICAgfSwgc3ZnUHJvcGVydGllc0FuZEV2ZW50cyhlbnRyeSksIG90aGVycywgaWRQcm9wcywge1xuICAgICAgLypcbiAgICAgICAqIFByZWZlciB0byB1c2UgdGhlIGV4cGxpY2l0IGZpbGwgZnJvbSBMYWJlbExpc3QgcHJvcHMuXG4gICAgICAgKiBPbmx5IGluIGFuIGFic2VuY2Ugb2YgdGhhdCwgZmFsbCBiYWNrIHRvIHRoZSBmaWxsIG9mIHRoZSBlbnRyeS5cbiAgICAgICAqIFRoZSBlbnRyeSBmaWxsIGNhbiBiZSBxdWl0ZSBkaWZmaWN1bHQgdG8gc2VlIGVzcGVjaWFsbHkgaW4gQmFyLCBQaWUsIFJhZGlhbEJhciBpbiBpbnNpZGUgcG9zaXRpb25zLlxuICAgICAgICogT24gdGhlIG90aGVyIGhhbmQgaXQncyBxdWl0ZSBjb252ZW5pZW50IGluIFNjYXR0ZXIsIExpbmUsIG9yIHdoZW4gdGhlIHBvc2l0aW9uIGlzIG91dHNpZGUgdGhlIEJhciwgUGllIGZpbGxlZCBzaGFwZXMuXG4gICAgICAgKi9cbiAgICAgIGZpbGw6IChfcmVzdFByb3BzJGZpbGwgPSByZXN0UHJvcHMuZmlsbCkgIT09IG51bGwgJiYgX3Jlc3RQcm9wcyRmaWxsICE9PSB2b2lkIDAgPyBfcmVzdFByb3BzJGZpbGwgOiBlbnRyeS5maWxsLFxuICAgICAgcGFyZW50Vmlld0JveDogZW50cnkucGFyZW50Vmlld0JveCxcbiAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgIHRleHRCcmVha0FsbDogdGV4dEJyZWFrQWxsLFxuICAgICAgdmlld0JveDogZW50cnkudmlld0JveCxcbiAgICAgIGluZGV4OiBpbmRleFxuICAgIH0pKTtcbiAgfSkpO1xufVxuTGFiZWxMaXN0LmRpc3BsYXlOYW1lID0gJ0xhYmVsTGlzdCc7XG5leHBvcnQgZnVuY3Rpb24gTGFiZWxMaXN0RnJvbUxhYmVsUHJvcChfcmVmMikge1xuICB2YXIge1xuICAgIGxhYmVsXG4gIH0gPSBfcmVmMjtcbiAgaWYgKCFsYWJlbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChsYWJlbCA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbExpc3QsIHtcbiAgICAgIGtleTogXCJsYWJlbExpc3QtaW1wbGljaXRcIlxuICAgIH0pO1xuICB9XG4gIGlmICgvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQobGFiZWwpIHx8IGlzTGFiZWxDb250ZW50QUZ1bmN0aW9uKGxhYmVsKSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbExpc3QsIHtcbiAgICAgIGtleTogXCJsYWJlbExpc3QtaW1wbGljaXRcIixcbiAgICAgIGNvbnRlbnQ6IGxhYmVsXG4gICAgfSk7XG4gIH1cbiAgaWYgKHR5cGVvZiBsYWJlbCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWxMaXN0LCBfZXh0ZW5kcyh7XG4gICAgICBrZXk6IFwibGFiZWxMaXN0LWltcGxpY2l0XCJcbiAgICB9LCBsYWJlbCwge1xuICAgICAgdHlwZTogU3RyaW5nKGxhYmVsLnR5cGUpXG4gICAgfSkpO1xuICB9XG4gIHJldHVybiBudWxsO1xufSIsImZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG4vKipcbiAqIEBmaWxlT3ZlcnZpZXcgRGVmYXVsdCBMZWdlbmQgQ29udGVudFxuICovXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBQdXJlQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY2xzeCB9IGZyb20gJ2Nsc3gnO1xuaW1wb3J0IHsgU3VyZmFjZSB9IGZyb20gJy4uL2NvbnRhaW5lci9TdXJmYWNlJztcbmltcG9ydCB7IFN5bWJvbHMgfSBmcm9tICcuLi9zaGFwZS9TeW1ib2xzJztcbmltcG9ydCB7IGFkYXB0RXZlbnRzT2ZDaGlsZCB9IGZyb20gJy4uL3V0aWwvdHlwZXMnO1xudmFyIFNJWkUgPSAzMjtcbmV4cG9ydCBjbGFzcyBEZWZhdWx0TGVnZW5kQ29udGVudCBleHRlbmRzIFB1cmVDb21wb25lbnQge1xuICAvKipcbiAgICogUmVuZGVyIHRoZSBwYXRoIG9mIGljb25cbiAgICogQHBhcmFtIGRhdGEgRGF0YSBvZiBlYWNoIGxlZ2VuZCBpdGVtXG4gICAqIEBwYXJhbSBpY29uVHlwZSBpZiBkZWZpbmVkLCBpdCB3aWxsIGFsd2F5cyByZW5kZXIgdGhpcyBpY29uLiBJZiB1bmRlZmluZWQgdGhlbiBpdCB1c2VzIGljb24gZnJvbSBkYXRhLnR5cGVcbiAgICogQHJldHVybiBQYXRoIGVsZW1lbnRcbiAgICovXG4gIHJlbmRlckljb24oZGF0YSwgaWNvblR5cGUpIHtcbiAgICB2YXIge1xuICAgICAgaW5hY3RpdmVDb2xvclxuICAgIH0gPSB0aGlzLnByb3BzO1xuICAgIHZhciBoYWxmU2l6ZSA9IFNJWkUgLyAyO1xuICAgIHZhciBzaXh0aFNpemUgPSBTSVpFIC8gNjtcbiAgICB2YXIgdGhpcmRTaXplID0gU0laRSAvIDM7XG4gICAgdmFyIGNvbG9yID0gZGF0YS5pbmFjdGl2ZSA/IGluYWN0aXZlQ29sb3IgOiBkYXRhLmNvbG9yO1xuICAgIHZhciBwcmVmZXJyZWRJY29uID0gaWNvblR5cGUgIT09IG51bGwgJiYgaWNvblR5cGUgIT09IHZvaWQgMCA/IGljb25UeXBlIDogZGF0YS50eXBlO1xuICAgIGlmIChwcmVmZXJyZWRJY29uID09PSAnbm9uZScpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAocHJlZmVycmVkSWNvbiA9PT0gJ3BsYWlubGluZScpIHtcbiAgICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcImxpbmVcIiwge1xuICAgICAgICBzdHJva2VXaWR0aDogNCxcbiAgICAgICAgZmlsbDogXCJub25lXCIsXG4gICAgICAgIHN0cm9rZTogY29sb3IsXG4gICAgICAgIHN0cm9rZURhc2hhcnJheTogZGF0YS5wYXlsb2FkLnN0cm9rZURhc2hhcnJheSxcbiAgICAgICAgeDE6IDAsXG4gICAgICAgIHkxOiBoYWxmU2l6ZSxcbiAgICAgICAgeDI6IFNJWkUsXG4gICAgICAgIHkyOiBoYWxmU2l6ZSxcbiAgICAgICAgY2xhc3NOYW1lOiBcInJlY2hhcnRzLWxlZ2VuZC1pY29uXCJcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocHJlZmVycmVkSWNvbiA9PT0gJ2xpbmUnKSB7XG4gICAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcbiAgICAgICAgc3Ryb2tlV2lkdGg6IDQsXG4gICAgICAgIGZpbGw6IFwibm9uZVwiLFxuICAgICAgICBzdHJva2U6IGNvbG9yLFxuICAgICAgICBkOiBcIk0wLFwiLmNvbmNhdChoYWxmU2l6ZSwgXCJoXCIpLmNvbmNhdCh0aGlyZFNpemUsIFwiXFxuICAgICAgICAgICAgQVwiKS5jb25jYXQoc2l4dGhTaXplLCBcIixcIikuY29uY2F0KHNpeHRoU2l6ZSwgXCIsMCwxLDEsXCIpLmNvbmNhdCgyICogdGhpcmRTaXplLCBcIixcIikuY29uY2F0KGhhbGZTaXplLCBcIlxcbiAgICAgICAgICAgIEhcIikuY29uY2F0KFNJWkUsIFwiTVwiKS5jb25jYXQoMiAqIHRoaXJkU2l6ZSwgXCIsXCIpLmNvbmNhdChoYWxmU2l6ZSwgXCJcXG4gICAgICAgICAgICBBXCIpLmNvbmNhdChzaXh0aFNpemUsIFwiLFwiKS5jb25jYXQoc2l4dGhTaXplLCBcIiwwLDEsMSxcIikuY29uY2F0KHRoaXJkU2l6ZSwgXCIsXCIpLmNvbmNhdChoYWxmU2l6ZSksXG4gICAgICAgIGNsYXNzTmFtZTogXCJyZWNoYXJ0cy1sZWdlbmQtaWNvblwiXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHByZWZlcnJlZEljb24gPT09ICdyZWN0Jykge1xuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7XG4gICAgICAgIHN0cm9rZTogXCJub25lXCIsXG4gICAgICAgIGZpbGw6IGNvbG9yLFxuICAgICAgICBkOiBcIk0wLFwiLmNvbmNhdChTSVpFIC8gOCwgXCJoXCIpLmNvbmNhdChTSVpFLCBcInZcIikuY29uY2F0KFNJWkUgKiAzIC8gNCwgXCJoXCIpLmNvbmNhdCgtU0laRSwgXCJ6XCIpLFxuICAgICAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtbGVnZW5kLWljb25cIlxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICgvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQoZGF0YS5sZWdlbmRJY29uKSkge1xuICAgICAgdmFyIGljb25Qcm9wcyA9IF9vYmplY3RTcHJlYWQoe30sIGRhdGEpO1xuICAgICAgZGVsZXRlIGljb25Qcm9wcy5sZWdlbmRJY29uO1xuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jbG9uZUVsZW1lbnQoZGF0YS5sZWdlbmRJY29uLCBpY29uUHJvcHMpO1xuICAgIH1cbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoU3ltYm9scywge1xuICAgICAgZmlsbDogY29sb3IsXG4gICAgICBjeDogaGFsZlNpemUsXG4gICAgICBjeTogaGFsZlNpemUsXG4gICAgICBzaXplOiBTSVpFLFxuICAgICAgc2l6ZVR5cGU6IFwiZGlhbWV0ZXJcIixcbiAgICAgIHR5cGU6IHByZWZlcnJlZEljb25cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEcmF3IGl0ZW1zIG9mIGxlZ2VuZFxuICAgKiBAcmV0dXJuIEl0ZW1zXG4gICAqL1xuICByZW5kZXJJdGVtcygpIHtcbiAgICB2YXIge1xuICAgICAgcGF5bG9hZCxcbiAgICAgIGljb25TaXplLFxuICAgICAgbGF5b3V0LFxuICAgICAgZm9ybWF0dGVyLFxuICAgICAgaW5hY3RpdmVDb2xvcixcbiAgICAgIGljb25UeXBlXG4gICAgfSA9IHRoaXMucHJvcHM7XG4gICAgdmFyIHZpZXdCb3ggPSB7XG4gICAgICB4OiAwLFxuICAgICAgeTogMCxcbiAgICAgIHdpZHRoOiBTSVpFLFxuICAgICAgaGVpZ2h0OiBTSVpFXG4gICAgfTtcbiAgICB2YXIgaXRlbVN0eWxlID0ge1xuICAgICAgZGlzcGxheTogbGF5b3V0ID09PSAnaG9yaXpvbnRhbCcgPyAnaW5saW5lLWJsb2NrJyA6ICdibG9jaycsXG4gICAgICBtYXJnaW5SaWdodDogMTBcbiAgICB9O1xuICAgIHZhciBzdmdTdHlsZSA9IHtcbiAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgdmVydGljYWxBbGlnbjogJ21pZGRsZScsXG4gICAgICBtYXJnaW5SaWdodDogNFxuICAgIH07XG4gICAgcmV0dXJuIHBheWxvYWQubWFwKChlbnRyeSwgaSkgPT4ge1xuICAgICAgdmFyIGZpbmFsRm9ybWF0dGVyID0gZW50cnkuZm9ybWF0dGVyIHx8IGZvcm1hdHRlcjtcbiAgICAgIHZhciBjbGFzc05hbWUgPSBjbHN4KHtcbiAgICAgICAgJ3JlY2hhcnRzLWxlZ2VuZC1pdGVtJzogdHJ1ZSxcbiAgICAgICAgW1wibGVnZW5kLWl0ZW0tXCIuY29uY2F0KGkpXTogdHJ1ZSxcbiAgICAgICAgaW5hY3RpdmU6IGVudHJ5LmluYWN0aXZlXG4gICAgICB9KTtcbiAgICAgIGlmIChlbnRyeS50eXBlID09PSAnbm9uZScpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICB2YXIgY29sb3IgPSBlbnRyeS5pbmFjdGl2ZSA/IGluYWN0aXZlQ29sb3IgOiBlbnRyeS5jb2xvcjtcbiAgICAgIHZhciBmaW5hbFZhbHVlID0gZmluYWxGb3JtYXR0ZXIgPyBmaW5hbEZvcm1hdHRlcihlbnRyeS52YWx1ZSwgZW50cnksIGkpIDogZW50cnkudmFsdWU7XG4gICAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCBfZXh0ZW5kcyh7XG4gICAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgICAgICBzdHlsZTogaXRlbVN0eWxlXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC9uby1hcnJheS1pbmRleC1rZXlcbiAgICAgICAgLFxuICAgICAgICBrZXk6IFwibGVnZW5kLWl0ZW0tXCIuY29uY2F0KGkpXG4gICAgICB9LCBhZGFwdEV2ZW50c09mQ2hpbGQodGhpcy5wcm9wcywgZW50cnksIGkpKSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoU3VyZmFjZSwge1xuICAgICAgICB3aWR0aDogaWNvblNpemUsXG4gICAgICAgIGhlaWdodDogaWNvblNpemUsXG4gICAgICAgIHZpZXdCb3g6IHZpZXdCb3gsXG4gICAgICAgIHN0eWxlOiBzdmdTdHlsZSxcbiAgICAgICAgXCJhcmlhLWxhYmVsXCI6IFwiXCIuY29uY2F0KGZpbmFsVmFsdWUsIFwiIGxlZ2VuZCBpY29uXCIpXG4gICAgICB9LCB0aGlzLnJlbmRlckljb24oZW50cnksIGljb25UeXBlKSksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7XG4gICAgICAgIGNsYXNzTmFtZTogXCJyZWNoYXJ0cy1sZWdlbmQtaXRlbS10ZXh0XCIsXG4gICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgY29sb3JcbiAgICAgICAgfVxuICAgICAgfSwgZmluYWxWYWx1ZSkpO1xuICAgIH0pO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICB2YXIge1xuICAgICAgcGF5bG9hZCxcbiAgICAgIGxheW91dCxcbiAgICAgIGFsaWduXG4gICAgfSA9IHRoaXMucHJvcHM7XG4gICAgaWYgKCFwYXlsb2FkIHx8ICFwYXlsb2FkLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBmaW5hbFN0eWxlID0ge1xuICAgICAgcGFkZGluZzogMCxcbiAgICAgIG1hcmdpbjogMCxcbiAgICAgIHRleHRBbGlnbjogbGF5b3V0ID09PSAnaG9yaXpvbnRhbCcgPyBhbGlnbiA6ICdsZWZ0J1xuICAgIH07XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwidWxcIiwge1xuICAgICAgY2xhc3NOYW1lOiBcInJlY2hhcnRzLWRlZmF1bHQtbGVnZW5kXCIsXG4gICAgICBzdHlsZTogZmluYWxTdHlsZVxuICAgIH0sIHRoaXMucmVuZGVySXRlbXMoKSk7XG4gIH1cbn1cbl9kZWZpbmVQcm9wZXJ0eShEZWZhdWx0TGVnZW5kQ29udGVudCwgXCJkaXNwbGF5TmFtZVwiLCAnTGVnZW5kJyk7XG5fZGVmaW5lUHJvcGVydHkoRGVmYXVsdExlZ2VuZENvbnRlbnQsIFwiZGVmYXVsdFByb3BzXCIsIHtcbiAgYWxpZ246ICdjZW50ZXInLFxuICBpY29uU2l6ZTogMTQsXG4gIGluYWN0aXZlQ29sb3I6ICcjY2NjJyxcbiAgbGF5b3V0OiAnaG9yaXpvbnRhbCcsXG4gIHZlcnRpY2FsQWxpZ246ICdtaWRkbGUnXG59KTsiLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xudmFyIFBhbm9yYW1hQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KG51bGwpO1xuZXhwb3J0IHZhciB1c2VJc1Bhbm9yYW1hID0gKCkgPT4gdXNlQ29udGV4dChQYW5vcmFtYUNvbnRleHQpICE9IG51bGw7XG5leHBvcnQgdmFyIFBhbm9yYW1hQ29udGV4dFByb3ZpZGVyID0gX3JlZiA9PiB7XG4gIHZhciB7XG4gICAgY2hpbGRyZW5cbiAgfSA9IF9yZWY7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChQYW5vcmFtYUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxuICB9LCBjaGlsZHJlbik7XG59OyIsImZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG4vKipcbiAqIEBmaWxlT3ZlcnZpZXcgRGVmYXVsdCBUb29sdGlwIENvbnRlbnRcbiAqL1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgc29ydEJ5IGZyb20gJ2VzLXRvb2xraXQvY29tcGF0L3NvcnRCeSc7XG5pbXBvcnQgeyBjbHN4IH0gZnJvbSAnY2xzeCc7XG5pbXBvcnQgeyBpc051bGxpc2gsIGlzTnVtT3JTdHIgfSBmcm9tICcuLi91dGlsL0RhdGFVdGlscyc7XG5mdW5jdGlvbiBkZWZhdWx0Rm9ybWF0dGVyKHZhbHVlKSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSAmJiBpc051bU9yU3RyKHZhbHVlWzBdKSAmJiBpc051bU9yU3RyKHZhbHVlWzFdKSA/IHZhbHVlLmpvaW4oJyB+ICcpIDogdmFsdWU7XG59XG5leHBvcnQgdmFyIERlZmF1bHRUb29sdGlwQ29udGVudCA9IHByb3BzID0+IHtcbiAgdmFyIHtcbiAgICBzZXBhcmF0b3IgPSAnIDogJyxcbiAgICBjb250ZW50U3R5bGUgPSB7fSxcbiAgICBpdGVtU3R5bGUgPSB7fSxcbiAgICBsYWJlbFN0eWxlID0ge30sXG4gICAgcGF5bG9hZCxcbiAgICBmb3JtYXR0ZXIsXG4gICAgaXRlbVNvcnRlcixcbiAgICB3cmFwcGVyQ2xhc3NOYW1lLFxuICAgIGxhYmVsQ2xhc3NOYW1lLFxuICAgIGxhYmVsLFxuICAgIGxhYmVsRm9ybWF0dGVyLFxuICAgIGFjY2Vzc2liaWxpdHlMYXllciA9IGZhbHNlXG4gIH0gPSBwcm9wcztcbiAgdmFyIHJlbmRlckNvbnRlbnQgPSAoKSA9PiB7XG4gICAgaWYgKHBheWxvYWQgJiYgcGF5bG9hZC5sZW5ndGgpIHtcbiAgICAgIHZhciBsaXN0U3R5bGUgPSB7XG4gICAgICAgIHBhZGRpbmc6IDAsXG4gICAgICAgIG1hcmdpbjogMFxuICAgICAgfTtcbiAgICAgIHZhciBpdGVtcyA9IChpdGVtU29ydGVyID8gc29ydEJ5KHBheWxvYWQsIGl0ZW1Tb3J0ZXIpIDogcGF5bG9hZCkubWFwKChlbnRyeSwgaSkgPT4ge1xuICAgICAgICBpZiAoZW50cnkudHlwZSA9PT0gJ25vbmUnKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGZpbmFsRm9ybWF0dGVyID0gZW50cnkuZm9ybWF0dGVyIHx8IGZvcm1hdHRlciB8fCBkZWZhdWx0Rm9ybWF0dGVyO1xuICAgICAgICB2YXIge1xuICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgIG5hbWVcbiAgICAgICAgfSA9IGVudHJ5O1xuICAgICAgICB2YXIgZmluYWxWYWx1ZSA9IHZhbHVlO1xuICAgICAgICB2YXIgZmluYWxOYW1lID0gbmFtZTtcbiAgICAgICAgaWYgKGZpbmFsRm9ybWF0dGVyKSB7XG4gICAgICAgICAgdmFyIGZvcm1hdHRlZCA9IGZpbmFsRm9ybWF0dGVyKHZhbHVlLCBuYW1lLCBlbnRyeSwgaSwgcGF5bG9hZCk7XG4gICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZm9ybWF0dGVkKSkge1xuICAgICAgICAgICAgW2ZpbmFsVmFsdWUsIGZpbmFsTmFtZV0gPSBmb3JtYXR0ZWQ7XG4gICAgICAgICAgfSBlbHNlIGlmIChmb3JtYXR0ZWQgIT0gbnVsbCkge1xuICAgICAgICAgICAgZmluYWxWYWx1ZSA9IGZvcm1hdHRlZDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBmaW5hbEl0ZW1TdHlsZSA9IF9vYmplY3RTcHJlYWQoe1xuICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgICAgcGFkZGluZ1RvcDogNCxcbiAgICAgICAgICBwYWRkaW5nQm90dG9tOiA0LFxuICAgICAgICAgIGNvbG9yOiBlbnRyeS5jb2xvciB8fCAnIzAwMCdcbiAgICAgICAgfSwgaXRlbVN0eWxlKTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAvKiNfX1BVUkVfXyovXG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0L25vLWFycmF5LWluZGV4LWtleVxuICAgICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJsaVwiLCB7XG4gICAgICAgICAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtdG9vbHRpcC1pdGVtXCIsXG4gICAgICAgICAgICBrZXk6IFwidG9vbHRpcC1pdGVtLVwiLmNvbmNhdChpKSxcbiAgICAgICAgICAgIHN0eWxlOiBmaW5hbEl0ZW1TdHlsZVxuICAgICAgICAgIH0sIGlzTnVtT3JTdHIoZmluYWxOYW1lKSA/IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7XG4gICAgICAgICAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtdG9vbHRpcC1pdGVtLW5hbWVcIlxuICAgICAgICAgIH0sIGZpbmFsTmFtZSkgOiBudWxsLCBpc051bU9yU3RyKGZpbmFsTmFtZSkgPyAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInNwYW5cIiwge1xuICAgICAgICAgICAgY2xhc3NOYW1lOiBcInJlY2hhcnRzLXRvb2x0aXAtaXRlbS1zZXBhcmF0b3JcIlxuICAgICAgICAgIH0sIHNlcGFyYXRvcikgOiBudWxsLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInNwYW5cIiwge1xuICAgICAgICAgICAgY2xhc3NOYW1lOiBcInJlY2hhcnRzLXRvb2x0aXAtaXRlbS12YWx1ZVwiXG4gICAgICAgICAgfSwgZmluYWxWYWx1ZSksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7XG4gICAgICAgICAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtdG9vbHRpcC1pdGVtLXVuaXRcIlxuICAgICAgICAgIH0sIGVudHJ5LnVuaXQgfHwgJycpKVxuICAgICAgICApO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJ1bFwiLCB7XG4gICAgICAgIGNsYXNzTmFtZTogXCJyZWNoYXJ0cy10b29sdGlwLWl0ZW0tbGlzdFwiLFxuICAgICAgICBzdHlsZTogbGlzdFN0eWxlXG4gICAgICB9LCBpdGVtcyk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9O1xuICB2YXIgZmluYWxTdHlsZSA9IF9vYmplY3RTcHJlYWQoe1xuICAgIG1hcmdpbjogMCxcbiAgICBwYWRkaW5nOiAxMCxcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmJyxcbiAgICBib3JkZXI6ICcxcHggc29saWQgI2NjYycsXG4gICAgd2hpdGVTcGFjZTogJ25vd3JhcCdcbiAgfSwgY29udGVudFN0eWxlKTtcbiAgdmFyIGZpbmFsTGFiZWxTdHlsZSA9IF9vYmplY3RTcHJlYWQoe1xuICAgIG1hcmdpbjogMFxuICB9LCBsYWJlbFN0eWxlKTtcbiAgdmFyIGhhc0xhYmVsID0gIWlzTnVsbGlzaChsYWJlbCk7XG4gIHZhciBmaW5hbExhYmVsID0gaGFzTGFiZWwgPyBsYWJlbCA6ICcnO1xuICB2YXIgd3JhcHBlckNOID0gY2xzeCgncmVjaGFydHMtZGVmYXVsdC10b29sdGlwJywgd3JhcHBlckNsYXNzTmFtZSk7XG4gIHZhciBsYWJlbENOID0gY2xzeCgncmVjaGFydHMtdG9vbHRpcC1sYWJlbCcsIGxhYmVsQ2xhc3NOYW1lKTtcbiAgaWYgKGhhc0xhYmVsICYmIGxhYmVsRm9ybWF0dGVyICYmIHBheWxvYWQgIT09IHVuZGVmaW5lZCAmJiBwYXlsb2FkICE9PSBudWxsKSB7XG4gICAgZmluYWxMYWJlbCA9IGxhYmVsRm9ybWF0dGVyKGxhYmVsLCBwYXlsb2FkKTtcbiAgfVxuICB2YXIgYWNjZXNzaWJpbGl0eUF0dHJpYnV0ZXMgPSBhY2Nlc3NpYmlsaXR5TGF5ZXIgPyB7XG4gICAgcm9sZTogJ3N0YXR1cycsXG4gICAgJ2FyaWEtbGl2ZSc6ICdhc3NlcnRpdmUnXG4gIH0gOiB7fTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIF9leHRlbmRzKHtcbiAgICBjbGFzc05hbWU6IHdyYXBwZXJDTixcbiAgICBzdHlsZTogZmluYWxTdHlsZVxuICB9LCBhY2Nlc3NpYmlsaXR5QXR0cmlidXRlcyksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwicFwiLCB7XG4gICAgY2xhc3NOYW1lOiBsYWJlbENOLFxuICAgIHN0eWxlOiBmaW5hbExhYmVsU3R5bGVcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmlzVmFsaWRFbGVtZW50KGZpbmFsTGFiZWwpID8gZmluYWxMYWJlbCA6IFwiXCIuY29uY2F0KGZpbmFsTGFiZWwpKSwgcmVuZGVyQ29udGVudCgpKTtcbn07IiwiaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2gsIHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vc3RhdGUvaG9va3MnO1xuaW1wb3J0IHsgc2V0Q2hhcnRTaXplLCBzZXRNYXJnaW4gfSBmcm9tICcuLi9zdGF0ZS9sYXlvdXRTbGljZSc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RDaGFydFZpZXdCb3ggfSBmcm9tICcuLi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydEhlaWdodCwgc2VsZWN0Q2hhcnRXaWR0aCB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9jb250YWluZXJTZWxlY3RvcnMnO1xuaW1wb3J0IHsgdXNlSXNQYW5vcmFtYSB9IGZyb20gJy4vUGFub3JhbWFDb250ZXh0JztcbmltcG9ydCB7IHNlbGVjdEJydXNoRGltZW5zaW9ucywgc2VsZWN0QnJ1c2hTZXR0aW5ncyB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9icnVzaFNlbGVjdG9ycyc7XG5pbXBvcnQgeyB1c2VSZXNwb25zaXZlQ29udGFpbmVyQ29udGV4dCB9IGZyb20gJy4uL2NvbXBvbmVudC9SZXNwb25zaXZlQ29udGFpbmVyJztcbmltcG9ydCB7IGlzUG9zaXRpdmVOdW1iZXIgfSBmcm9tICcuLi91dGlsL2lzV2VsbEJlaGF2ZWROdW1iZXInO1xuZXhwb3J0IHZhciB1c2VWaWV3Qm94ID0gKCkgPT4ge1xuICB2YXIgX3VzZUFwcFNlbGVjdG9yO1xuICB2YXIgcGFub3JhbWEgPSB1c2VJc1Bhbm9yYW1hKCk7XG4gIHZhciByb290Vmlld0JveCA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdENoYXJ0Vmlld0JveCk7XG4gIHZhciBicnVzaERpbWVuc2lvbnMgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RCcnVzaERpbWVuc2lvbnMpO1xuICB2YXIgYnJ1c2hQYWRkaW5nID0gKF91c2VBcHBTZWxlY3RvciA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdEJydXNoU2V0dGluZ3MpKSA9PT0gbnVsbCB8fCBfdXNlQXBwU2VsZWN0b3IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF91c2VBcHBTZWxlY3Rvci5wYWRkaW5nO1xuICBpZiAoIXBhbm9yYW1hIHx8ICFicnVzaERpbWVuc2lvbnMgfHwgIWJydXNoUGFkZGluZykge1xuICAgIHJldHVybiByb290Vmlld0JveDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoOiBicnVzaERpbWVuc2lvbnMud2lkdGggLSBicnVzaFBhZGRpbmcubGVmdCAtIGJydXNoUGFkZGluZy5yaWdodCxcbiAgICBoZWlnaHQ6IGJydXNoRGltZW5zaW9ucy5oZWlnaHQgLSBicnVzaFBhZGRpbmcudG9wIC0gYnJ1c2hQYWRkaW5nLmJvdHRvbSxcbiAgICB4OiBicnVzaFBhZGRpbmcubGVmdCxcbiAgICB5OiBicnVzaFBhZGRpbmcudG9wXG4gIH07XG59O1xudmFyIG1hbnlDb21wb25lbnRzVGhyb3dFcnJvcnNJZk9mZnNldElzVW5kZWZpbmVkID0ge1xuICB0b3A6IDAsXG4gIGJvdHRvbTogMCxcbiAgbGVmdDogMCxcbiAgcmlnaHQ6IDAsXG4gIHdpZHRoOiAwLFxuICBoZWlnaHQ6IDAsXG4gIGJydXNoQm90dG9tOiAwXG59O1xuLyoqXG4gKiBGb3IgaW50ZXJuYWwgdXNlIG9ubHkuIElmIHlvdSB3YW50IHRoaXMgaW5mb3JtYXRpb24sIGBpbXBvcnQgeyB1c2VPZmZzZXQgfSBmcm9tICdyZWNoYXJ0cydgIGluc3RlYWQuXG4gKlxuICogUmV0dXJucyB0aGUgb2Zmc2V0IG9mIHRoZSBjaGFydCBpbiBwaXhlbHMuXG4gKlxuICogQHJldHVybnMge0NoYXJ0T2Zmc2V0SW50ZXJuYWx9IFRoZSBvZmZzZXQgb2YgdGhlIGNoYXJ0IGluIHBpeGVscywgb3IgYSBkZWZhdWx0IHZhbHVlIGlmIG5vdCBpbiBhIGNoYXJ0IGNvbnRleHQuXG4gKi9cbmV4cG9ydCB2YXIgdXNlT2Zmc2V0SW50ZXJuYWwgPSAoKSA9PiB7XG4gIHZhciBfdXNlQXBwU2VsZWN0b3IyO1xuICByZXR1cm4gKF91c2VBcHBTZWxlY3RvcjIgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RDaGFydE9mZnNldEludGVybmFsKSkgIT09IG51bGwgJiYgX3VzZUFwcFNlbGVjdG9yMiAhPT0gdm9pZCAwID8gX3VzZUFwcFNlbGVjdG9yMiA6IG1hbnlDb21wb25lbnRzVGhyb3dFcnJvcnNJZk9mZnNldElzVW5kZWZpbmVkO1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSB3aWR0aCBvZiB0aGUgY2hhcnQgaW4gcGl4ZWxzLlxuICpcbiAqIElmIHlvdSBhcmUgdXNpbmcgY2hhcnQgd2l0aCBoYXJkY29kZWQgYHdpZHRoYCBwcm9wLCB0aGVuIHRoZSB3aWR0aCByZXR1cm5lZCB3aWxsIGJlIHRoZSBzYW1lXG4gKiBhcyB0aGUgYHdpZHRoYCBwcm9wIG9uIHRoZSBtYWluIGNoYXJ0IGVsZW1lbnQuXG4gKlxuICogSWYgeW91IGFyZSB1c2luZyBhIGNoYXJ0IHdpdGggYSBgUmVzcG9uc2l2ZUNvbnRhaW5lcmAsIHRoZSB3aWR0aCB3aWxsIGJlIHRoZSBzaXplIG9mIHRoZSBjaGFydFxuICogYXMgdGhlIFJlc3BvbnNpdmVDb250YWluZXIgaGFzIGRlY2lkZWQgaXQgd291bGQgYmUuXG4gKlxuICogSWYgdGhlIGNoYXJ0IGhhcyBhbnkgYXhlcyBvciBsZWdlbmQsIHRoZSBgd2lkdGhgIHdpbGwgYmUgdGhlIHNpemUgb2YgdGhlIGNoYXJ0XG4gKiBpbmNsdWRpbmcgdGhlIGF4ZXMgYW5kIGxlZ2VuZC4gTWVhbmluZzogYWRkaW5nIGF4ZXMgYW5kIGxlZ2VuZCB3aWxsIG5vdCBjaGFuZ2UgdGhlIHdpZHRoLlxuICpcbiAqIFRoZSBkaW1lbnNpb25zIGRvIG5vdCBzY2FsZSwgbWVhbmluZyBhcyB1c2VyIHpvb20gaW4gYW5kIG91dCwgdGhlIHdpZHRoIG51bWJlciB3aWxsIG5vdCBjaGFuZ2VcbiAqIGFzIHRoZSBjaGFydCBnZXRzIHZpc3VhbGx5IGxhcmdlciBvciBzbWFsbGVyLlxuICpcbiAqIFJldHVybnMgYHVuZGVmaW5lZGAgaWYgdXNlZCBvdXRzaWRlIGEgY2hhcnQgY29udGV4dC5cbiAqXG4gKiBAcmV0dXJucyB7bnVtYmVyIHwgdW5kZWZpbmVkfSBUaGUgd2lkdGggb2YgdGhlIGNoYXJ0IGluIHBpeGVscywgb3IgYHVuZGVmaW5lZGAgaWYgbm90IGluIGEgY2hhcnQgY29udGV4dC5cbiAqL1xuZXhwb3J0IHZhciB1c2VDaGFydFdpZHRoID0gKCkgPT4ge1xuICByZXR1cm4gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0Q2hhcnRXaWR0aCk7XG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGhlaWdodCBvZiB0aGUgY2hhcnQgaW4gcGl4ZWxzLlxuICpcbiAqIElmIHlvdSBhcmUgdXNpbmcgY2hhcnQgd2l0aCBoYXJkY29kZWQgYGhlaWdodGAgcHJvcHMsIHRoZW4gdGhlIGhlaWdodCByZXR1cm5lZCB3aWxsIGJlIHRoZSBzYW1lXG4gKiBhcyB0aGUgYGhlaWdodGAgcHJvcCBvbiB0aGUgbWFpbiBjaGFydCBlbGVtZW50LlxuICpcbiAqIElmIHlvdSBhcmUgdXNpbmcgYSBjaGFydCB3aXRoIGEgYFJlc3BvbnNpdmVDb250YWluZXJgLCB0aGUgaGVpZ2h0IHdpbGwgYmUgdGhlIHNpemUgb2YgdGhlIGNoYXJ0XG4gKiBhcyB0aGUgUmVzcG9uc2l2ZUNvbnRhaW5lciBoYXMgZGVjaWRlZCBpdCB3b3VsZCBiZS5cbiAqXG4gKiBJZiB0aGUgY2hhcnQgaGFzIGFueSBheGVzIG9yIGxlZ2VuZCwgdGhlIGBoZWlnaHRgIHdpbGwgYmUgdGhlIHNpemUgb2YgdGhlIGNoYXJ0XG4gKiBpbmNsdWRpbmcgdGhlIGF4ZXMgYW5kIGxlZ2VuZC4gTWVhbmluZzogYWRkaW5nIGF4ZXMgYW5kIGxlZ2VuZCB3aWxsIG5vdCBjaGFuZ2UgdGhlIGhlaWdodC5cbiAqXG4gKiBUaGUgZGltZW5zaW9ucyBkbyBub3Qgc2NhbGUsIG1lYW5pbmcgYXMgdXNlciB6b29tIGluIGFuZCBvdXQsIHRoZSBoZWlnaHQgbnVtYmVyIHdpbGwgbm90IGNoYW5nZVxuICogYXMgdGhlIGNoYXJ0IGdldHMgdmlzdWFsbHkgbGFyZ2VyIG9yIHNtYWxsZXIuXG4gKlxuICogUmV0dXJucyBgdW5kZWZpbmVkYCBpZiB1c2VkIG91dHNpZGUgYSBjaGFydCBjb250ZXh0LlxuICpcbiAqIEByZXR1cm5zIHtudW1iZXIgfCB1bmRlZmluZWR9IFRoZSBoZWlnaHQgb2YgdGhlIGNoYXJ0IGluIHBpeGVscywgb3IgYHVuZGVmaW5lZGAgaWYgbm90IGluIGEgY2hhcnQgY29udGV4dC5cbiAqL1xuZXhwb3J0IHZhciB1c2VDaGFydEhlaWdodCA9ICgpID0+IHtcbiAgcmV0dXJuIHVzZUFwcFNlbGVjdG9yKHNlbGVjdENoYXJ0SGVpZ2h0KTtcbn07XG5cbi8qKlxuICogTWFyZ2luIGlzIHRoZSBlbXB0eSBzcGFjZSBhcm91bmQgdGhlIGNoYXJ0LiBFeGNsdWRlcyBheGVzIGFuZCBsZWdlbmQgYW5kIGJydXNoZXMgYW5kIHRoZSBsaWtlLlxuICogVGhpcyBpcyBkZWNsYXJlZCBieSB0aGUgdXNlciBpbiB0aGUgY2hhcnQgcHJvcHMuXG4gKiBJZiB5b3UgYXJlIGludGVyZXN0ZWQgaW4gdGhlIHNwYWNlIG9jY3VwaWVkIGJ5IGF4ZXMsIGxlZ2VuZCwgb3IgYnJ1c2hlcyxcbiAqIHVzZSBgdXNlT2Zmc2V0YCBpbnN0ZWFkLlxuICpcbiAqIFJldHVybnMgYHVuZGVmaW5lZGAgaWYgdXNlZCBvdXRzaWRlIGEgY2hhcnQgY29udGV4dC5cbiAqXG4gKiBAcmV0dXJucyB7TWFyZ2luIHwgdW5kZWZpbmVkfSBUaGUgbWFyZ2luIG9mIHRoZSBjaGFydCBpbiBwaXhlbHMsIG9yIGB1bmRlZmluZWRgIGlmIG5vdCBpbiBhIGNoYXJ0IGNvbnRleHQuXG4gKi9cbmV4cG9ydCB2YXIgdXNlTWFyZ2luID0gKCkgPT4ge1xuICByZXR1cm4gdXNlQXBwU2VsZWN0b3Ioc3RhdGUgPT4gc3RhdGUubGF5b3V0Lm1hcmdpbik7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RDaGFydExheW91dCA9IHN0YXRlID0+IHN0YXRlLmxheW91dC5sYXlvdXRUeXBlO1xuZXhwb3J0IHZhciB1c2VDaGFydExheW91dCA9ICgpID0+IHVzZUFwcFNlbGVjdG9yKHNlbGVjdENoYXJ0TGF5b3V0KTtcbmV4cG9ydCB2YXIgUmVwb3J0Q2hhcnRTaXplID0gcHJvcHMgPT4ge1xuICB2YXIgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuXG4gIC8qXG4gICAqIFNraXAgZGlzcGF0Y2hpbmcgcHJvcGVydGllcyBpbiBwYW5vcmFtYSBjaGFydCBmb3IgdHdvIHJlYXNvbnM6XG4gICAqIDEuIFRoZSByb290IGNoYXJ0IHNob3VsZCBiZSBkZWNpZGluZyBvbiB0aGVzZSBwcm9wZXJ0aWVzLCBhbmRcbiAgICogMi4gQnJ1c2ggcmVhZHMgdGhlc2UgcHJvcGVydGllcyBmcm9tIHJlZHV4IHN0b3JlLCBhbmQgc28gdGhleSBtdXN0IHJlbWFpbiBzdGFibGVcbiAgICogICAgICB0byBhdm9pZCBjaXJjdWxhciBkZXBlbmRlbmN5IGFuZCBpbmZpbml0ZSByZS1yZW5kZXJpbmcuXG4gICAqL1xuICB2YXIgaXNQYW5vcmFtYSA9IHVzZUlzUGFub3JhbWEoKTtcbiAgdmFyIHtcbiAgICB3aWR0aDogd2lkdGhGcm9tUHJvcHMsXG4gICAgaGVpZ2h0OiBoZWlnaHRGcm9tUHJvcHNcbiAgfSA9IHByb3BzO1xuICB2YXIgcmVzcG9uc2l2ZUNvbnRhaW5lckNhbGN1bGF0aW9ucyA9IHVzZVJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0KCk7XG4gIHZhciB3aWR0aCA9IHdpZHRoRnJvbVByb3BzO1xuICB2YXIgaGVpZ2h0ID0gaGVpZ2h0RnJvbVByb3BzO1xuICBpZiAocmVzcG9uc2l2ZUNvbnRhaW5lckNhbGN1bGF0aW9ucykge1xuICAgIC8qXG4gICAgICogSW4gY2FzZSB3ZSByZWNlaXZlIHdpZHRoIGFuZCBoZWlnaHQgZnJvbSBSZXNwb25zaXZlQ29udGFpbmVyLFxuICAgICAqIHdlIHdpbGwgYWx3YXlzIHByZWZlciB0aG9zZS5cbiAgICAgKiBPbmx5IGluIGNhc2UgUmVzcG9uc2l2ZUNvbnRhaW5lciBkb2VzIG5vdCBwcm92aWRlIHdpZHRoIG9yIGhlaWdodCxcbiAgICAgKiB3ZSB3aWxsIGZhbGwgYmFjayB0byB0aGUgZXhwbGljaXRseSBwcm92aWRlZCB3aWR0aCBhbmQgaGVpZ2h0LlxuICAgICAqXG4gICAgICogVGhpcyB0byBtZSBmZWVscyBiYWNrd2FyZHMgLSB3ZSBzaG91bGQgYWxsb3cgb3ZlcnJpZGUgYnkgdGhlIG1vcmUgc3BlY2lmaWMgcHJvcHMgb24gaW5kaXZpZHVhbCBjaGFydHMsIHJpZ2h0P1xuICAgICAqIEJ1dCB0aGlzIGlzIDMueCBiZWhhdmlvdXIsIHNvIGxldCdzIGtlZXAgaXQgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuICAgICAqXG4gICAgICogV2UgY2FuIGNoYW5nZSB0aGlzIGluIDQueCBpZiB3ZSB3YW50IHRvLlxuICAgICAqL1xuICAgIHdpZHRoID0gcmVzcG9uc2l2ZUNvbnRhaW5lckNhbGN1bGF0aW9ucy53aWR0aCA+IDAgPyByZXNwb25zaXZlQ29udGFpbmVyQ2FsY3VsYXRpb25zLndpZHRoIDogd2lkdGhGcm9tUHJvcHM7XG4gICAgaGVpZ2h0ID0gcmVzcG9uc2l2ZUNvbnRhaW5lckNhbGN1bGF0aW9ucy5oZWlnaHQgPiAwID8gcmVzcG9uc2l2ZUNvbnRhaW5lckNhbGN1bGF0aW9ucy5oZWlnaHQgOiBoZWlnaHRGcm9tUHJvcHM7XG4gIH1cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlzUGFub3JhbWEgJiYgaXNQb3NpdGl2ZU51bWJlcih3aWR0aCkgJiYgaXNQb3NpdGl2ZU51bWJlcihoZWlnaHQpKSB7XG4gICAgICBkaXNwYXRjaChzZXRDaGFydFNpemUoe1xuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0XG4gICAgICB9KSk7XG4gICAgfVxuICB9LCBbZGlzcGF0Y2gsIGlzUGFub3JhbWEsIHdpZHRoLCBoZWlnaHRdKTtcbiAgcmV0dXJuIG51bGw7XG59O1xuZXhwb3J0IHZhciBSZXBvcnRDaGFydE1hcmdpbiA9IF9yZWYgPT4ge1xuICB2YXIge1xuICAgIG1hcmdpblxuICB9ID0gX3JlZjtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkaXNwYXRjaChzZXRNYXJnaW4obWFyZ2luKSk7XG4gIH0sIFtkaXNwYXRjaCwgbWFyZ2luXSk7XG4gIHJldHVybiBudWxsO1xufTsiLCJ2YXIgX2V4Y2x1ZGVkID0gW1wieFwiLCBcInlcIiwgXCJsaW5lSGVpZ2h0XCIsIFwiY2FwSGVpZ2h0XCIsIFwic2NhbGVUb0ZpdFwiLCBcInRleHRBbmNob3JcIiwgXCJ2ZXJ0aWNhbEFuY2hvclwiLCBcImZpbGxcIl0sXG4gIF9leGNsdWRlZDIgPSBbXCJkeFwiLCBcImR5XCIsIFwiYW5nbGVcIiwgXCJjbGFzc05hbWVcIiwgXCJicmVha0FsbFwiXTtcbmZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKGUsIHQpIHsgaWYgKG51bGwgPT0gZSkgcmV0dXJuIHt9OyB2YXIgbywgciwgaSA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKGUsIHQpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbiA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IGZvciAociA9IDA7IHIgPCBuLmxlbmd0aDsgcisrKSBvID0gbltyXSwgLTEgPT09IHQuaW5kZXhPZihvKSAmJiB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKGUsIG8pICYmIChpW29dID0gZVtvXSk7IH0gcmV0dXJuIGk7IH1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHIsIGUpIHsgaWYgKG51bGwgPT0gcikgcmV0dXJuIHt9OyB2YXIgdCA9IHt9OyBmb3IgKHZhciBuIGluIHIpIGlmICh7fS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHIsIG4pKSB7IGlmICgtMSAhPT0gZS5pbmRleE9mKG4pKSBjb250aW51ZTsgdFtuXSA9IHJbbl07IH0gcmV0dXJuIHQ7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lbW8sIGZvcndhcmRSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjbHN4IH0gZnJvbSAnY2xzeCc7XG5pbXBvcnQgeyBpc051bGxpc2gsIGlzTnVtYmVyLCBpc051bU9yU3RyIH0gZnJvbSAnLi4vdXRpbC9EYXRhVXRpbHMnO1xuaW1wb3J0IHsgR2xvYmFsIH0gZnJvbSAnLi4vdXRpbC9HbG9iYWwnO1xuaW1wb3J0IHsgZ2V0U3RyaW5nU2l6ZSB9IGZyb20gJy4uL3V0aWwvRE9NVXRpbHMnO1xuaW1wb3J0IHsgcmVkdWNlQ1NTQ2FsYyB9IGZyb20gJy4uL3V0aWwvUmVkdWNlQ1NTQ2FsYyc7XG5pbXBvcnQgeyBzdmdQcm9wZXJ0aWVzQW5kRXZlbnRzIH0gZnJvbSAnLi4vdXRpbC9zdmdQcm9wZXJ0aWVzQW5kRXZlbnRzJztcbnZhciBCUkVBS0lOR19TUEFDRVMgPSAvWyBcXGZcXG5cXHJcXHRcXHZcXHUyMDI4XFx1MjAyOV0rLztcbnZhciBjYWxjdWxhdGVXb3JkV2lkdGhzID0gX3JlZiA9PiB7XG4gIHZhciB7XG4gICAgY2hpbGRyZW4sXG4gICAgYnJlYWtBbGwsXG4gICAgc3R5bGVcbiAgfSA9IF9yZWY7XG4gIHRyeSB7XG4gICAgdmFyIHdvcmRzID0gW107XG4gICAgaWYgKCFpc051bGxpc2goY2hpbGRyZW4pKSB7XG4gICAgICBpZiAoYnJlYWtBbGwpIHtcbiAgICAgICAgd29yZHMgPSBjaGlsZHJlbi50b1N0cmluZygpLnNwbGl0KCcnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdvcmRzID0gY2hpbGRyZW4udG9TdHJpbmcoKS5zcGxpdChCUkVBS0lOR19TUEFDRVMpO1xuICAgICAgfVxuICAgIH1cbiAgICB2YXIgd29yZHNXaXRoQ29tcHV0ZWRXaWR0aCA9IHdvcmRzLm1hcCh3b3JkID0+ICh7XG4gICAgICB3b3JkLFxuICAgICAgd2lkdGg6IGdldFN0cmluZ1NpemUod29yZCwgc3R5bGUpLndpZHRoXG4gICAgfSkpO1xuICAgIHZhciBzcGFjZVdpZHRoID0gYnJlYWtBbGwgPyAwIDogZ2V0U3RyaW5nU2l6ZSgnXFx1MDBBMCcsIHN0eWxlKS53aWR0aDtcbiAgICByZXR1cm4ge1xuICAgICAgd29yZHNXaXRoQ29tcHV0ZWRXaWR0aCxcbiAgICAgIHNwYWNlV2lkdGhcbiAgICB9O1xuICB9IGNhdGNoIChfdW51c2VkKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn07XG52YXIgY2FsY3VsYXRlV29yZHNCeUxpbmVzID0gKF9yZWYyLCBpbml0aWFsV29yZHNXaXRoQ29tcHV0ZWRXaXRoLCBzcGFjZVdpZHRoLCBsaW5lV2lkdGgsIHNjYWxlVG9GaXQpID0+IHtcbiAgdmFyIHtcbiAgICBtYXhMaW5lcyxcbiAgICBjaGlsZHJlbixcbiAgICBzdHlsZSxcbiAgICBicmVha0FsbFxuICB9ID0gX3JlZjI7XG4gIHZhciBzaG91bGRMaW1pdExpbmVzID0gaXNOdW1iZXIobWF4TGluZXMpO1xuICB2YXIgdGV4dCA9IGNoaWxkcmVuO1xuICB2YXIgY2FsY3VsYXRlID0gZnVuY3Rpb24gY2FsY3VsYXRlKCkge1xuICAgIHZhciB3b3JkcyA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDogW107XG4gICAgcmV0dXJuIHdvcmRzLnJlZHVjZSgocmVzdWx0LCBfcmVmMykgPT4ge1xuICAgICAgdmFyIHtcbiAgICAgICAgd29yZCxcbiAgICAgICAgd2lkdGhcbiAgICAgIH0gPSBfcmVmMztcbiAgICAgIHZhciBjdXJyZW50TGluZSA9IHJlc3VsdFtyZXN1bHQubGVuZ3RoIC0gMV07XG4gICAgICBpZiAoY3VycmVudExpbmUgJiYgKGxpbmVXaWR0aCA9PSBudWxsIHx8IHNjYWxlVG9GaXQgfHwgY3VycmVudExpbmUud2lkdGggKyB3aWR0aCArIHNwYWNlV2lkdGggPCBOdW1iZXIobGluZVdpZHRoKSkpIHtcbiAgICAgICAgLy8gV29yZCBjYW4gYmUgYWRkZWQgdG8gYW4gZXhpc3RpbmcgbGluZVxuICAgICAgICBjdXJyZW50TGluZS53b3Jkcy5wdXNoKHdvcmQpO1xuICAgICAgICBjdXJyZW50TGluZS53aWR0aCArPSB3aWR0aCArIHNwYWNlV2lkdGg7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBBZGQgZmlyc3Qgd29yZCB0byBsaW5lIG9yIHdvcmQgaXMgdG9vIGxvbmcgdG8gc2NhbGVUb0ZpdCBvbiBleGlzdGluZyBsaW5lXG4gICAgICAgIHZhciBuZXdMaW5lID0ge1xuICAgICAgICAgIHdvcmRzOiBbd29yZF0sXG4gICAgICAgICAgd2lkdGhcbiAgICAgICAgfTtcbiAgICAgICAgcmVzdWx0LnB1c2gobmV3TGluZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0sIFtdKTtcbiAgfTtcbiAgdmFyIG9yaWdpbmFsUmVzdWx0ID0gY2FsY3VsYXRlKGluaXRpYWxXb3Jkc1dpdGhDb21wdXRlZFdpdGgpO1xuICB2YXIgZmluZExvbmdlc3RMaW5lID0gd29yZHMgPT4gd29yZHMucmVkdWNlKChhLCBiKSA9PiBhLndpZHRoID4gYi53aWR0aCA/IGEgOiBiKTtcbiAgaWYgKCFzaG91bGRMaW1pdExpbmVzIHx8IHNjYWxlVG9GaXQpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxSZXN1bHQ7XG4gIH1cbiAgdmFyIG92ZXJmbG93cyA9IG9yaWdpbmFsUmVzdWx0Lmxlbmd0aCA+IG1heExpbmVzIHx8IGZpbmRMb25nZXN0TGluZShvcmlnaW5hbFJlc3VsdCkud2lkdGggPiBOdW1iZXIobGluZVdpZHRoKTtcbiAgaWYgKCFvdmVyZmxvd3MpIHtcbiAgICByZXR1cm4gb3JpZ2luYWxSZXN1bHQ7XG4gIH1cbiAgdmFyIHN1ZmZpeCA9ICfigKYnO1xuICB2YXIgY2hlY2tPdmVyZmxvdyA9IGluZGV4ID0+IHtcbiAgICB2YXIgdGVtcFRleHQgPSB0ZXh0LnNsaWNlKDAsIGluZGV4KTtcbiAgICB2YXIgd29yZHMgPSBjYWxjdWxhdGVXb3JkV2lkdGhzKHtcbiAgICAgIGJyZWFrQWxsLFxuICAgICAgc3R5bGUsXG4gICAgICBjaGlsZHJlbjogdGVtcFRleHQgKyBzdWZmaXhcbiAgICB9KS53b3Jkc1dpdGhDb21wdXRlZFdpZHRoO1xuICAgIHZhciByZXN1bHQgPSBjYWxjdWxhdGUod29yZHMpO1xuICAgIHZhciBkb2VzT3ZlcmZsb3cgPSByZXN1bHQubGVuZ3RoID4gbWF4TGluZXMgfHwgZmluZExvbmdlc3RMaW5lKHJlc3VsdCkud2lkdGggPiBOdW1iZXIobGluZVdpZHRoKTtcbiAgICByZXR1cm4gW2RvZXNPdmVyZmxvdywgcmVzdWx0XTtcbiAgfTtcbiAgdmFyIHN0YXJ0ID0gMDtcbiAgdmFyIGVuZCA9IHRleHQubGVuZ3RoIC0gMTtcbiAgdmFyIGl0ZXJhdGlvbnMgPSAwO1xuICB2YXIgdHJpbW1lZFJlc3VsdDtcbiAgd2hpbGUgKHN0YXJ0IDw9IGVuZCAmJiBpdGVyYXRpb25zIDw9IHRleHQubGVuZ3RoIC0gMSkge1xuICAgIHZhciBtaWRkbGUgPSBNYXRoLmZsb29yKChzdGFydCArIGVuZCkgLyAyKTtcbiAgICB2YXIgcHJldiA9IG1pZGRsZSAtIDE7XG4gICAgdmFyIFtkb2VzUHJldk92ZXJmbG93LCByZXN1bHRdID0gY2hlY2tPdmVyZmxvdyhwcmV2KTtcbiAgICB2YXIgW2RvZXNNaWRkbGVPdmVyZmxvd10gPSBjaGVja092ZXJmbG93KG1pZGRsZSk7XG4gICAgaWYgKCFkb2VzUHJldk92ZXJmbG93ICYmICFkb2VzTWlkZGxlT3ZlcmZsb3cpIHtcbiAgICAgIHN0YXJ0ID0gbWlkZGxlICsgMTtcbiAgICB9XG4gICAgaWYgKGRvZXNQcmV2T3ZlcmZsb3cgJiYgZG9lc01pZGRsZU92ZXJmbG93KSB7XG4gICAgICBlbmQgPSBtaWRkbGUgLSAxO1xuICAgIH1cbiAgICBpZiAoIWRvZXNQcmV2T3ZlcmZsb3cgJiYgZG9lc01pZGRsZU92ZXJmbG93KSB7XG4gICAgICB0cmltbWVkUmVzdWx0ID0gcmVzdWx0O1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGl0ZXJhdGlvbnMrKztcbiAgfVxuXG4gIC8vIEZhbGxiYWNrIHRvIG9yaWdpbmFsUmVzdWx0IChyZXN1bHQgd2l0aG91dCB0cmltbWluZykgaWYgd2UgY2Fubm90IGZpbmQgdGhlXG4gIC8vIHdoZXJlIHRvIHRyaW0uICBUaGlzIHNob3VsZCBub3QgaGFwcGVuIDp0bTpcbiAgcmV0dXJuIHRyaW1tZWRSZXN1bHQgfHwgb3JpZ2luYWxSZXN1bHQ7XG59O1xudmFyIGdldFdvcmRzV2l0aG91dENhbGN1bGF0ZSA9IGNoaWxkcmVuID0+IHtcbiAgdmFyIHdvcmRzID0gIWlzTnVsbGlzaChjaGlsZHJlbikgPyBjaGlsZHJlbi50b1N0cmluZygpLnNwbGl0KEJSRUFLSU5HX1NQQUNFUykgOiBbXTtcbiAgcmV0dXJuIFt7XG4gICAgd29yZHNcbiAgfV07XG59O1xuZXhwb3J0IHZhciBnZXRXb3Jkc0J5TGluZXMgPSBfcmVmNCA9PiB7XG4gIHZhciB7XG4gICAgd2lkdGgsXG4gICAgc2NhbGVUb0ZpdCxcbiAgICBjaGlsZHJlbixcbiAgICBzdHlsZSxcbiAgICBicmVha0FsbCxcbiAgICBtYXhMaW5lc1xuICB9ID0gX3JlZjQ7XG4gIC8vIE9ubHkgcGVyZm9ybSBjYWxjdWxhdGlvbnMgaWYgdXNpbmcgZmVhdHVyZXMgdGhhdCByZXF1aXJlIHRoZW0gKG11bHRpbGluZSwgc2NhbGVUb0ZpdClcbiAgaWYgKCh3aWR0aCB8fCBzY2FsZVRvRml0KSAmJiAhR2xvYmFsLmlzU3NyKSB7XG4gICAgdmFyIHdvcmRzV2l0aENvbXB1dGVkV2lkdGgsIHNwYWNlV2lkdGg7XG4gICAgdmFyIHdvcmRXaWR0aHMgPSBjYWxjdWxhdGVXb3JkV2lkdGhzKHtcbiAgICAgIGJyZWFrQWxsLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBzdHlsZVxuICAgIH0pO1xuICAgIGlmICh3b3JkV2lkdGhzKSB7XG4gICAgICB2YXIge1xuICAgICAgICB3b3Jkc1dpdGhDb21wdXRlZFdpZHRoOiB3Y3csXG4gICAgICAgIHNwYWNlV2lkdGg6IHN3XG4gICAgICB9ID0gd29yZFdpZHRocztcbiAgICAgIHdvcmRzV2l0aENvbXB1dGVkV2lkdGggPSB3Y3c7XG4gICAgICBzcGFjZVdpZHRoID0gc3c7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBnZXRXb3Jkc1dpdGhvdXRDYWxjdWxhdGUoY2hpbGRyZW4pO1xuICAgIH1cbiAgICByZXR1cm4gY2FsY3VsYXRlV29yZHNCeUxpbmVzKHtcbiAgICAgIGJyZWFrQWxsLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBtYXhMaW5lcyxcbiAgICAgIHN0eWxlXG4gICAgfSwgd29yZHNXaXRoQ29tcHV0ZWRXaWR0aCwgc3BhY2VXaWR0aCwgd2lkdGgsIHNjYWxlVG9GaXQpO1xuICB9XG4gIHJldHVybiBnZXRXb3Jkc1dpdGhvdXRDYWxjdWxhdGUoY2hpbGRyZW4pO1xufTtcbnZhciBERUZBVUxUX0ZJTEwgPSAnIzgwODA4MCc7XG5leHBvcnQgdmFyIFRleHQgPSAvKiNfX1BVUkVfXyovZm9yd2FyZFJlZigoX3JlZjUsIHJlZikgPT4ge1xuICB2YXIge1xuICAgICAgeDogcHJvcHNYID0gMCxcbiAgICAgIHk6IHByb3BzWSA9IDAsXG4gICAgICBsaW5lSGVpZ2h0ID0gJzFlbScsXG4gICAgICAvLyBNYWdpYyBudW1iZXIgZnJvbSBkM1xuICAgICAgY2FwSGVpZ2h0ID0gJzAuNzFlbScsXG4gICAgICBzY2FsZVRvRml0ID0gZmFsc2UsXG4gICAgICB0ZXh0QW5jaG9yID0gJ3N0YXJ0JyxcbiAgICAgIC8vIE1haW50YWluIGNvbXBhdCB3aXRoIGV4aXN0aW5nIGNoYXJ0cyAvIGRlZmF1bHQgU1ZHIGJlaGF2aW9yXG4gICAgICB2ZXJ0aWNhbEFuY2hvciA9ICdlbmQnLFxuICAgICAgZmlsbCA9IERFRkFVTFRfRklMTFxuICAgIH0gPSBfcmVmNSxcbiAgICBwcm9wcyA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmNSwgX2V4Y2x1ZGVkKTtcbiAgdmFyIHdvcmRzQnlMaW5lcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBnZXRXb3Jkc0J5TGluZXMoe1xuICAgICAgYnJlYWtBbGw6IHByb3BzLmJyZWFrQWxsLFxuICAgICAgY2hpbGRyZW46IHByb3BzLmNoaWxkcmVuLFxuICAgICAgbWF4TGluZXM6IHByb3BzLm1heExpbmVzLFxuICAgICAgc2NhbGVUb0ZpdCxcbiAgICAgIHN0eWxlOiBwcm9wcy5zdHlsZSxcbiAgICAgIHdpZHRoOiBwcm9wcy53aWR0aFxuICAgIH0pO1xuICB9LCBbcHJvcHMuYnJlYWtBbGwsIHByb3BzLmNoaWxkcmVuLCBwcm9wcy5tYXhMaW5lcywgc2NhbGVUb0ZpdCwgcHJvcHMuc3R5bGUsIHByb3BzLndpZHRoXSk7XG4gIHZhciB7XG4gICAgICBkeCxcbiAgICAgIGR5LFxuICAgICAgYW5nbGUsXG4gICAgICBjbGFzc05hbWUsXG4gICAgICBicmVha0FsbFxuICAgIH0gPSBwcm9wcyxcbiAgICB0ZXh0UHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMocHJvcHMsIF9leGNsdWRlZDIpO1xuICBpZiAoIWlzTnVtT3JTdHIocHJvcHNYKSB8fCAhaXNOdW1PclN0cihwcm9wc1kpIHx8IHdvcmRzQnlMaW5lcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgeCA9IHByb3BzWCArIChpc051bWJlcihkeCkgPyBkeCA6IDApO1xuICB2YXIgeSA9IHByb3BzWSArIChpc051bWJlcihkeSkgPyBkeSA6IDApO1xuICB2YXIgc3RhcnREeTtcbiAgc3dpdGNoICh2ZXJ0aWNhbEFuY2hvcikge1xuICAgIGNhc2UgJ3N0YXJ0JzpcbiAgICAgIHN0YXJ0RHkgPSByZWR1Y2VDU1NDYWxjKFwiY2FsYyhcIi5jb25jYXQoY2FwSGVpZ2h0LCBcIilcIikpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbWlkZGxlJzpcbiAgICAgIHN0YXJ0RHkgPSByZWR1Y2VDU1NDYWxjKFwiY2FsYyhcIi5jb25jYXQoKHdvcmRzQnlMaW5lcy5sZW5ndGggLSAxKSAvIDIsIFwiICogLVwiKS5jb25jYXQobGluZUhlaWdodCwgXCIgKyAoXCIpLmNvbmNhdChjYXBIZWlnaHQsIFwiIC8gMikpXCIpKTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBzdGFydER5ID0gcmVkdWNlQ1NTQ2FsYyhcImNhbGMoXCIuY29uY2F0KHdvcmRzQnlMaW5lcy5sZW5ndGggLSAxLCBcIiAqIC1cIikuY29uY2F0KGxpbmVIZWlnaHQsIFwiKVwiKSk7XG4gICAgICBicmVhaztcbiAgfVxuICB2YXIgdHJhbnNmb3JtcyA9IFtdO1xuICBpZiAoc2NhbGVUb0ZpdCkge1xuICAgIHZhciBsaW5lV2lkdGggPSB3b3Jkc0J5TGluZXNbMF0ud2lkdGg7XG4gICAgdmFyIHtcbiAgICAgIHdpZHRoXG4gICAgfSA9IHByb3BzO1xuICAgIHRyYW5zZm9ybXMucHVzaChcInNjYWxlKFwiLmNvbmNhdChpc051bWJlcih3aWR0aCkgPyB3aWR0aCAvIGxpbmVXaWR0aCA6IDEsIFwiKVwiKSk7XG4gIH1cbiAgaWYgKGFuZ2xlKSB7XG4gICAgdHJhbnNmb3Jtcy5wdXNoKFwicm90YXRlKFwiLmNvbmNhdChhbmdsZSwgXCIsIFwiKS5jb25jYXQoeCwgXCIsIFwiKS5jb25jYXQoeSwgXCIpXCIpKTtcbiAgfVxuICBpZiAodHJhbnNmb3Jtcy5sZW5ndGgpIHtcbiAgICB0ZXh0UHJvcHMudHJhbnNmb3JtID0gdHJhbnNmb3Jtcy5qb2luKCcgJyk7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwidGV4dFwiLCBfZXh0ZW5kcyh7fSwgc3ZnUHJvcGVydGllc0FuZEV2ZW50cyh0ZXh0UHJvcHMpLCB7XG4gICAgcmVmOiByZWYsXG4gICAgeDogeCxcbiAgICB5OiB5LFxuICAgIGNsYXNzTmFtZTogY2xzeCgncmVjaGFydHMtdGV4dCcsIGNsYXNzTmFtZSksXG4gICAgdGV4dEFuY2hvcjogdGV4dEFuY2hvcixcbiAgICBmaWxsOiBmaWxsLmluY2x1ZGVzKCd1cmwnKSA/IERFRkFVTFRfRklMTCA6IGZpbGxcbiAgfSksIHdvcmRzQnlMaW5lcy5tYXAoKGxpbmUsIGluZGV4KSA9PiB7XG4gICAgdmFyIHdvcmRzID0gbGluZS53b3Jkcy5qb2luKGJyZWFrQWxsID8gJycgOiAnICcpO1xuICAgIHJldHVybiAoXG4gICAgICAvKiNfX1BVUkVfXyovXG4gICAgICAvLyBkdXBsaWNhdGUgd29yZHMgd2lsbCBjYXVzZSBkdXBsaWNhdGUga2V5c1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0L25vLWFycmF5LWluZGV4LWtleVxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcInRzcGFuXCIsIHtcbiAgICAgICAgeDogeCxcbiAgICAgICAgZHk6IGluZGV4ID09PSAwID8gc3RhcnREeSA6IGxpbmVIZWlnaHQsXG4gICAgICAgIGtleTogXCJcIi5jb25jYXQod29yZHMsIFwiLVwiKS5jb25jYXQoaW5kZXgpXG4gICAgICB9LCB3b3JkcylcbiAgICApO1xuICB9KSk7XG59KTtcblRleHQuZGlzcGxheU5hbWUgPSAnVGV4dCc7IiwiaW1wb3J0IHsgaXNQZXJjZW50IH0gZnJvbSAnLi4vdXRpbC9EYXRhVXRpbHMnO1xuZXhwb3J0IHZhciBjYWxjdWxhdGVDaGFydERpbWVuc2lvbnMgPSAoY29udGFpbmVyV2lkdGgsIGNvbnRhaW5lckhlaWdodCwgcHJvcHMpID0+IHtcbiAgdmFyIHtcbiAgICB3aWR0aCA9ICcxMDAlJyxcbiAgICBoZWlnaHQgPSAnMTAwJScsXG4gICAgYXNwZWN0LFxuICAgIG1heEhlaWdodFxuICB9ID0gcHJvcHM7XG5cbiAgLypcbiAgICogVGhlIGNvbnRhaW5lcldpZHRoIGFuZCBjb250YWluZXJIZWlnaHQgYXJlIGFscmVhZHkgcGVyY2VudGFnZSBiYXNlZCBiZWNhdXNlIGl0J3Mgc2V0IGFzIHRoYXQgcGVyY2VudGFnZSBpbiBDU1MuXG4gICAqIE1lYW5zIHdlIGRvbid0IGhhdmUgdG8gY2FsY3VsYXRlIHBlcmNlbnRhZ2VzIGhlcmUuXG4gICAqL1xuICB2YXIgY2FsY3VsYXRlZFdpZHRoID0gaXNQZXJjZW50KHdpZHRoKSA/IGNvbnRhaW5lcldpZHRoIDogTnVtYmVyKHdpZHRoKTtcbiAgdmFyIGNhbGN1bGF0ZWRIZWlnaHQgPSBpc1BlcmNlbnQoaGVpZ2h0KSA/IGNvbnRhaW5lckhlaWdodCA6IE51bWJlcihoZWlnaHQpO1xuICBpZiAoYXNwZWN0ICYmIGFzcGVjdCA+IDApIHtcbiAgICAvLyBQcmVzZXJ2ZSB0aGUgZGVzaXJlZCBhc3BlY3QgcmF0aW9cbiAgICBpZiAoY2FsY3VsYXRlZFdpZHRoKSB7XG4gICAgICAvLyBXaWxsIGRlZmF1bHQgdG8gdXNpbmcgd2lkdGggZm9yIGFzcGVjdCByYXRpb1xuICAgICAgY2FsY3VsYXRlZEhlaWdodCA9IGNhbGN1bGF0ZWRXaWR0aCAvIGFzcGVjdDtcbiAgICB9IGVsc2UgaWYgKGNhbGN1bGF0ZWRIZWlnaHQpIHtcbiAgICAgIC8vIEJ1dCB3ZSBzaG91bGQgYWxzbyB0YWtlIGhlaWdodCBpbnRvIGNvbnNpZGVyYXRpb25cbiAgICAgIGNhbGN1bGF0ZWRXaWR0aCA9IGNhbGN1bGF0ZWRIZWlnaHQgKiBhc3BlY3Q7XG4gICAgfVxuXG4gICAgLy8gaWYgbWF4SGVpZ2h0IGlzIHNldCwgb3ZlcndyaXRlIGlmIGNhbGN1bGF0ZWRIZWlnaHQgaXMgZ3JlYXRlciB0aGFuIG1heEhlaWdodFxuICAgIGlmIChtYXhIZWlnaHQgJiYgY2FsY3VsYXRlZEhlaWdodCA+IG1heEhlaWdodCkge1xuICAgICAgY2FsY3VsYXRlZEhlaWdodCA9IG1heEhlaWdodDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBjYWxjdWxhdGVkV2lkdGgsXG4gICAgY2FsY3VsYXRlZEhlaWdodFxuICB9O1xufTtcbnZhciBib3RoT3ZlcmZsb3cgPSB7XG4gIHdpZHRoOiAwLFxuICBoZWlnaHQ6IDAsXG4gIG92ZXJmbG93OiAndmlzaWJsZSdcbn07XG52YXIgb3ZlcmZsb3dYID0ge1xuICB3aWR0aDogMCxcbiAgb3ZlcmZsb3dYOiAndmlzaWJsZSdcbn07XG52YXIgb3ZlcmZsb3dZID0ge1xuICBoZWlnaHQ6IDAsXG4gIG92ZXJmbG93WTogJ3Zpc2libGUnXG59O1xudmFyIG5vU3R5bGUgPSB7fTtcblxuLyoqXG4gKiBUaGlzIHplcm8tc2l6ZSwgb3ZlcmZsb3ctdmlzaWJsZSBpcyByZXF1aXJlZCB0byBhbGxvdyB0aGUgY2hhcnQgdG8gc2hyaW5rLlxuICogV2l0aG91dCBpdCwgdGhlIGNoYXJ0IGl0c2VsZiB3aWxsIGZpbGwgdGhlIFJlc3BvbnNpdmVDb250YWluZXIsIGFuZCB3aGlsZSBpdCBhbGxvd3MgdGhlIGNoYXJ0IHRvIGdyb3csXG4gKiBpdCB3b3VsZCBhbHdheXMga2VlcCB0aGUgY29udGFpbmVyIGF0IHRoZSBzaXplIG9mIHRoZSBjaGFydCxcbiAqIGFuZCBSZXNpemVPYnNlcnZlciB3b3VsZCBuZXZlciBmaXJlLlxuICogV2l0aCB0aGlzIHplcm8tc2l6ZSBlbGVtZW50LCB0aGUgY2hhcnQgaXRzZWxmIG5ldmVyIGFjdHVhbGx5IGZpbGxzIHRoZSBjb250YWluZXIsXG4gKiBpdCBqdXN0IHNvIGhhcHBlbnMgdGhhdCBpdCBpcyB2aXNpYmxlIGJlY2F1c2UgaXQgb3ZlcmZsb3dzLlxuICogSSBsZWFybmVkIHRoaXMgdHJpY2sgZnJvbSB0aGUgYHJlYWN0LXZpcnR1YWxpemVkYCBsaWJyYXJ5OiBodHRwczovL2dpdGh1Yi5jb20vYnZhdWdobi9yZWFjdC12aXJ0dWFsaXplZC1hdXRvLXNpemVyL2Jsb2IvbWFzdGVyL3NyYy9BdXRvU2l6ZXIudHNcbiAqIFNlZSBodHRwczovL2dpdGh1Yi5jb20vcmVjaGFydHMvcmVjaGFydHMvaXNzdWVzLzE3MiBhbmQgYWxzbyBodHRwczovL2dpdGh1Yi5jb20vYnZhdWdobi9yZWFjdC12aXJ0dWFsaXplZC9pc3N1ZXMvNjhcbiAqXG4gKiBBbHNvLCB3ZSBkb24ndCBuZWVkIHRvIGFwcGx5IHRoZSB6ZXJvLXNpemUgc3R5bGUgaWYgdGhlIGRpbWVuc2lvbiBpcyBhIGZpeGVkIG51bWJlciAob3IgdW5kZWZpbmVkKSxcbiAqIGJlY2F1c2UgaW4gdGhhdCBjYXNlIHRoZSBjaGFydCBjYW4ndCBzaHJpbmsgaW4gdGhhdCBkaW1lbnNpb24gYW55d2F5LlxuICogVGhpcyBmaXhlcyBkZWZpbmluZyB0aGUgZGltZW5zaW9ucyB1c2luZyBhc3BlY3QgcmF0aW86IGh0dHBzOi8vZ2l0aHViLmNvbS9yZWNoYXJ0cy9yZWNoYXJ0cy9pc3N1ZXMvNjI0NVxuICovXG5leHBvcnQgdmFyIGdldElubmVyRGl2U3R5bGUgPSBwcm9wcyA9PiB7XG4gIHZhciB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSBwcm9wcztcbiAgdmFyIGlzV2lkdGhQZXJjZW50ID0gaXNQZXJjZW50KHdpZHRoKTtcbiAgdmFyIGlzSGVpZ2h0UGVyY2VudCA9IGlzUGVyY2VudChoZWlnaHQpO1xuICBpZiAoaXNXaWR0aFBlcmNlbnQgJiYgaXNIZWlnaHRQZXJjZW50KSB7XG4gICAgcmV0dXJuIGJvdGhPdmVyZmxvdztcbiAgfVxuICBpZiAoaXNXaWR0aFBlcmNlbnQpIHtcbiAgICByZXR1cm4gb3ZlcmZsb3dYO1xuICB9XG4gIGlmIChpc0hlaWdodFBlcmNlbnQpIHtcbiAgICByZXR1cm4gb3ZlcmZsb3dZO1xuICB9XG4gIHJldHVybiBub1N0eWxlO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBnZXREZWZhdWx0V2lkdGhBbmRIZWlnaHQoX3JlZikge1xuICB2YXIge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICBhc3BlY3RcbiAgfSA9IF9yZWY7XG4gIHZhciBjYWxjdWxhdGVkV2lkdGggPSB3aWR0aDtcbiAgdmFyIGNhbGN1bGF0ZWRIZWlnaHQgPSBoZWlnaHQ7XG4gIGlmIChjYWxjdWxhdGVkV2lkdGggPT09IHVuZGVmaW5lZCAmJiBjYWxjdWxhdGVkSGVpZ2h0ID09PSB1bmRlZmluZWQpIHtcbiAgICBjYWxjdWxhdGVkV2lkdGggPSAnMTAwJSc7XG4gICAgY2FsY3VsYXRlZEhlaWdodCA9ICcxMDAlJztcbiAgfSBlbHNlIGlmIChjYWxjdWxhdGVkV2lkdGggPT09IHVuZGVmaW5lZCkge1xuICAgIGNhbGN1bGF0ZWRXaWR0aCA9IGFzcGVjdCAmJiBhc3BlY3QgPiAwID8gdW5kZWZpbmVkIDogJzEwMCUnO1xuICB9IGVsc2UgaWYgKGNhbGN1bGF0ZWRIZWlnaHQgPT09IHVuZGVmaW5lZCkge1xuICAgIGNhbGN1bGF0ZWRIZWlnaHQgPSBhc3BlY3QgJiYgYXNwZWN0ID4gMCA/IHVuZGVmaW5lZCA6ICcxMDAlJztcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoOiBjYWxjdWxhdGVkV2lkdGgsXG4gICAgaGVpZ2h0OiBjYWxjdWxhdGVkSGVpZ2h0XG4gIH07XG59IiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7IHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7IGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7IHZhciB0ID0gYXJndW1lbnRzW2VdOyBmb3IgKHZhciByIGluIHQpICh7fSkuaGFzT3duUHJvcGVydHkuY2FsbCh0LCByKSAmJiAobltyXSA9IHRbcl0pOyB9IHJldHVybiBuOyB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpOyB9XG5mdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGNsc3ggfSBmcm9tICdjbHN4JztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIGZvcndhcmRSZWYsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZUltcGVyYXRpdmVIYW5kbGUsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdGhyb3R0bGUgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvdGhyb3R0bGUnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uL3V0aWwvTG9nVXRpbHMnO1xuaW1wb3J0IHsgY2FsY3VsYXRlQ2hhcnREaW1lbnNpb25zLCBnZXREZWZhdWx0V2lkdGhBbmRIZWlnaHQsIGdldElubmVyRGl2U3R5bGUgfSBmcm9tICcuL3Jlc3BvbnNpdmVDb250YWluZXJVdGlscyc7XG5pbXBvcnQgeyBpc1Bvc2l0aXZlTnVtYmVyIH0gZnJvbSAnLi4vdXRpbC9pc1dlbGxCZWhhdmVkTnVtYmVyJztcbmltcG9ydCB7IGlzTnVtYmVyIH0gZnJvbSAnLi4vdXRpbC9EYXRhVXRpbHMnO1xudmFyIFJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0ID0gLyojX19QVVJFX18qL2NyZWF0ZUNvbnRleHQoe1xuICB3aWR0aDogLTEsXG4gIGhlaWdodDogLTFcbn0pO1xuZnVuY3Rpb24gUmVzcG9uc2l2ZUNvbnRhaW5lckNvbnRleHRQcm92aWRlcihfcmVmKSB7XG4gIHZhciB7XG4gICAgY2hpbGRyZW4sXG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSBfcmVmO1xuICB2YXIgc2l6ZSA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSksIFt3aWR0aCwgaGVpZ2h0XSk7XG4gIGlmICh3aWR0aCA8PSAwIHx8IGhlaWdodCA8PSAwKSB7XG4gICAgLypcbiAgICAgKiBEb24ndCByZW5kZXIgdGhlIGNvbnRhaW5lciBpZiB3aWR0aCBvciBoZWlnaHQgaXMgbm9uLXBvc2l0aXZlIGJlY2F1c2VcbiAgICAgKiBpbiB0aGF0IGNhc2UgdGhlIGNoYXJ0IHdpbGwgbm90IGJlIHJlbmRlcmVkIHByb3Blcmx5IGFueXdheS5cbiAgICAgKiBXZSB3aWxsIGluc3RlYWQgd2FpdCBmb3IgdGhlIG5leHQgcmVzaXplIGV2ZW50IHRvIHByb3ZpZGUgdGhlIGNvcnJlY3QgZGltZW5zaW9ucy5cbiAgICAgKi9cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVzcG9uc2l2ZUNvbnRhaW5lckNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogc2l6ZVxuICB9LCBjaGlsZHJlbik7XG59XG5leHBvcnQgdmFyIHVzZVJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0ID0gKCkgPT4gdXNlQ29udGV4dChSZXNwb25zaXZlQ29udGFpbmVyQ29udGV4dCk7XG52YXIgU2l6ZURldGVjdG9yQ29udGFpbmVyID0gLyojX19QVVJFX18qL2ZvcndhcmRSZWYoKF9yZWYyLCByZWYpID0+IHtcbiAgdmFyIHtcbiAgICBhc3BlY3QsXG4gICAgaW5pdGlhbERpbWVuc2lvbiA9IHtcbiAgICAgIHdpZHRoOiAtMSxcbiAgICAgIGhlaWdodDogLTFcbiAgICB9LFxuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICAvKlxuICAgICAqIGRlZmF1bHQgbWluLXdpZHRoIHRvIDAgaWYgbm90IHNwZWNpZmllZCAtICdhdXRvJyBjYXVzZXMgaXNzdWVzIHdpdGggZmxleGJveFxuICAgICAqIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWNoYXJ0cy9yZWNoYXJ0cy9pc3N1ZXMvMTcyXG4gICAgICovXG4gICAgbWluV2lkdGggPSAwLFxuICAgIG1pbkhlaWdodCxcbiAgICBtYXhIZWlnaHQsXG4gICAgY2hpbGRyZW4sXG4gICAgZGVib3VuY2UgPSAwLFxuICAgIGlkLFxuICAgIGNsYXNzTmFtZSxcbiAgICBvblJlc2l6ZSxcbiAgICBzdHlsZSA9IHt9XG4gIH0gPSBfcmVmMjtcbiAgdmFyIGNvbnRhaW5lclJlZiA9IHVzZVJlZihudWxsKTtcbiAgLypcbiAgICogV2UgYXJlIHVzaW5nIGEgcmVmIHRvIGF2b2lkIHJlLWNyZWF0aW5nIHRoZSBSZXNpemVPYnNlcnZlciB3aGVuIHRoZSBvblJlc2l6ZSBmdW5jdGlvbiBjaGFuZ2VzLlxuICAgKiBUaGUgcmVmIGlzIHVwZGF0ZWQgb24gZXZlcnkgcmVuZGVyLCBzbyB0aGUgbGF0ZXN0IG9uUmVzaXplIGZ1bmN0aW9uIGlzIGFsd2F5cyBhdmFpbGFibGUgaW4gdGhlIGVmZmVjdC5cbiAgICovXG4gIHZhciBvblJlc2l6ZVJlZiA9IHVzZVJlZigpO1xuICBvblJlc2l6ZVJlZi5jdXJyZW50ID0gb25SZXNpemU7XG4gIHVzZUltcGVyYXRpdmVIYW5kbGUocmVmLCAoKSA9PiBjb250YWluZXJSZWYuY3VycmVudCk7XG4gIHZhciBbc2l6ZXMsIHNldFNpemVzXSA9IHVzZVN0YXRlKHtcbiAgICBjb250YWluZXJXaWR0aDogaW5pdGlhbERpbWVuc2lvbi53aWR0aCxcbiAgICBjb250YWluZXJIZWlnaHQ6IGluaXRpYWxEaW1lbnNpb24uaGVpZ2h0XG4gIH0pO1xuICB2YXIgc2V0Q29udGFpbmVyU2l6ZSA9IHVzZUNhbGxiYWNrKChuZXdXaWR0aCwgbmV3SGVpZ2h0KSA9PiB7XG4gICAgc2V0U2l6ZXMocHJldlN0YXRlID0+IHtcbiAgICAgIHZhciByb3VuZGVkV2lkdGggPSBNYXRoLnJvdW5kKG5ld1dpZHRoKTtcbiAgICAgIHZhciByb3VuZGVkSGVpZ2h0ID0gTWF0aC5yb3VuZChuZXdIZWlnaHQpO1xuICAgICAgaWYgKHByZXZTdGF0ZS5jb250YWluZXJXaWR0aCA9PT0gcm91bmRlZFdpZHRoICYmIHByZXZTdGF0ZS5jb250YWluZXJIZWlnaHQgPT09IHJvdW5kZWRIZWlnaHQpIHtcbiAgICAgICAgcmV0dXJuIHByZXZTdGF0ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvbnRhaW5lcldpZHRoOiByb3VuZGVkV2lkdGgsXG4gICAgICAgIGNvbnRhaW5lckhlaWdodDogcm91bmRlZEhlaWdodFxuICAgICAgfTtcbiAgICB9KTtcbiAgfSwgW10pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZhciBjYWxsYmFjayA9IGVudHJpZXMgPT4ge1xuICAgICAgdmFyIF9vblJlc2l6ZVJlZiRjdXJyZW50O1xuICAgICAgdmFyIHtcbiAgICAgICAgd2lkdGg6IGNvbnRhaW5lcldpZHRoLFxuICAgICAgICBoZWlnaHQ6IGNvbnRhaW5lckhlaWdodFxuICAgICAgfSA9IGVudHJpZXNbMF0uY29udGVudFJlY3Q7XG4gICAgICBzZXRDb250YWluZXJTaXplKGNvbnRhaW5lcldpZHRoLCBjb250YWluZXJIZWlnaHQpO1xuICAgICAgKF9vblJlc2l6ZVJlZiRjdXJyZW50ID0gb25SZXNpemVSZWYuY3VycmVudCkgPT09IG51bGwgfHwgX29uUmVzaXplUmVmJGN1cnJlbnQgPT09IHZvaWQgMCB8fCBfb25SZXNpemVSZWYkY3VycmVudC5jYWxsKG9uUmVzaXplUmVmLCBjb250YWluZXJXaWR0aCwgY29udGFpbmVySGVpZ2h0KTtcbiAgICB9O1xuICAgIGlmIChkZWJvdW5jZSA+IDApIHtcbiAgICAgIGNhbGxiYWNrID0gdGhyb3R0bGUoY2FsbGJhY2ssIGRlYm91bmNlLCB7XG4gICAgICAgIHRyYWlsaW5nOiB0cnVlLFxuICAgICAgICBsZWFkaW5nOiBmYWxzZVxuICAgICAgfSk7XG4gICAgfVxuICAgIHZhciBvYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcihjYWxsYmFjayk7XG4gICAgdmFyIHtcbiAgICAgIHdpZHRoOiBjb250YWluZXJXaWR0aCxcbiAgICAgIGhlaWdodDogY29udGFpbmVySGVpZ2h0XG4gICAgfSA9IGNvbnRhaW5lclJlZi5jdXJyZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHNldENvbnRhaW5lclNpemUoY29udGFpbmVyV2lkdGgsIGNvbnRhaW5lckhlaWdodCk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShjb250YWluZXJSZWYuY3VycmVudCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICB9O1xuICB9LCBbc2V0Q29udGFpbmVyU2l6ZSwgZGVib3VuY2VdKTtcbiAgdmFyIHtcbiAgICBjb250YWluZXJXaWR0aCxcbiAgICBjb250YWluZXJIZWlnaHRcbiAgfSA9IHNpemVzO1xuICB3YXJuKCFhc3BlY3QgfHwgYXNwZWN0ID4gMCwgJ1RoZSBhc3BlY3QoJXMpIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8uJywgYXNwZWN0KTtcbiAgdmFyIHtcbiAgICBjYWxjdWxhdGVkV2lkdGgsXG4gICAgY2FsY3VsYXRlZEhlaWdodFxuICB9ID0gY2FsY3VsYXRlQ2hhcnREaW1lbnNpb25zKGNvbnRhaW5lcldpZHRoLCBjb250YWluZXJIZWlnaHQsIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgYXNwZWN0LFxuICAgIG1heEhlaWdodFxuICB9KTtcbiAgd2FybihjYWxjdWxhdGVkV2lkdGggPiAwIHx8IGNhbGN1bGF0ZWRIZWlnaHQgPiAwLCBcIlRoZSB3aWR0aCglcykgYW5kIGhlaWdodCglcykgb2YgY2hhcnQgc2hvdWxkIGJlIGdyZWF0ZXIgdGhhbiAwLFxcbiAgICAgICBwbGVhc2UgY2hlY2sgdGhlIHN0eWxlIG9mIGNvbnRhaW5lciwgb3IgdGhlIHByb3BzIHdpZHRoKCVzKSBhbmQgaGVpZ2h0KCVzKSxcXG4gICAgICAgb3IgYWRkIGEgbWluV2lkdGgoJXMpIG9yIG1pbkhlaWdodCglcykgb3IgdXNlIGFzcGVjdCglcykgdG8gY29udHJvbCB0aGVcXG4gICAgICAgaGVpZ2h0IGFuZCB3aWR0aC5cIiwgY2FsY3VsYXRlZFdpZHRoLCBjYWxjdWxhdGVkSGVpZ2h0LCB3aWR0aCwgaGVpZ2h0LCBtaW5XaWR0aCwgbWluSGVpZ2h0LCBhc3BlY3QpO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIGlkOiBpZCA/IFwiXCIuY29uY2F0KGlkKSA6IHVuZGVmaW5lZCxcbiAgICBjbGFzc05hbWU6IGNsc3goJ3JlY2hhcnRzLXJlc3BvbnNpdmUtY29udGFpbmVyJywgY2xhc3NOYW1lKSxcbiAgICBzdHlsZTogX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBzdHlsZSksIHt9LCB7XG4gICAgICB3aWR0aCxcbiAgICAgIGhlaWdodCxcbiAgICAgIG1pbldpZHRoLFxuICAgICAgbWluSGVpZ2h0LFxuICAgICAgbWF4SGVpZ2h0XG4gICAgfSksXG4gICAgcmVmOiBjb250YWluZXJSZWZcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIHN0eWxlOiBnZXRJbm5lckRpdlN0eWxlKHtcbiAgICAgIHdpZHRoLFxuICAgICAgaGVpZ2h0XG4gICAgfSlcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVzcG9uc2l2ZUNvbnRhaW5lckNvbnRleHRQcm92aWRlciwge1xuICAgIHdpZHRoOiBjYWxjdWxhdGVkV2lkdGgsXG4gICAgaGVpZ2h0OiBjYWxjdWxhdGVkSGVpZ2h0XG4gIH0sIGNoaWxkcmVuKSkpO1xufSk7XG5cbi8qKlxuICogVGhlIGBSZXNwb25zaXZlQ29udGFpbmVyYCBjb21wb25lbnQgaXMgYSBjb250YWluZXIgdGhhdCBhZGp1c3RzIGl0cyB3aWR0aCBhbmQgaGVpZ2h0IGJhc2VkIG9uIHRoZSBzaXplIG9mIGl0cyBwYXJlbnQgZWxlbWVudC5cbiAqIEl0IGlzIHVzZWQgdG8gY3JlYXRlIHJlc3BvbnNpdmUgY2hhcnRzIHRoYXQgYWRhcHQgdG8gZGlmZmVyZW50IHNjcmVlbiBzaXplcy5cbiAqXG4gKiBUaGlzIGNvbXBvbmVudCB1c2VzIHRoZSBgUmVzaXplT2JzZXJ2ZXJgIEFQSSB0byBtb25pdG9yIGNoYW5nZXMgdG8gdGhlIHNpemUgb2YgaXRzIHBhcmVudCBlbGVtZW50LlxuICogSWYgeW91IG5lZWQgdG8gc3VwcG9ydCBvbGRlciBicm93c2VycyB0aGF0IGRvIG5vdCBzdXBwb3J0IHRoaXMgQVBJLCB5b3UgbWF5IG5lZWQgdG8gaW5jbHVkZSBhIHBvbHlmaWxsLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1Jlc2l6ZU9ic2VydmVyXG4gKi9cbmV4cG9ydCB2YXIgUmVzcG9uc2l2ZUNvbnRhaW5lciA9IC8qI19fUFVSRV9fKi9mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIHZhciByZXNwb25zaXZlQ29udGFpbmVyQ29udGV4dCA9IHVzZVJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0KCk7XG4gIGlmIChpc1Bvc2l0aXZlTnVtYmVyKHJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0LndpZHRoKSAmJiBpc1Bvc2l0aXZlTnVtYmVyKHJlc3BvbnNpdmVDb250YWluZXJDb250ZXh0LmhlaWdodCkpIHtcbiAgICAvKlxuICAgICAqIElmIHdlIGRldGVjdCB0aGF0IHdlIGFyZSBhbHJlYWR5IGluc2lkZSBhbm90aGVyIFJlc3BvbnNpdmVDb250YWluZXIsXG4gICAgICogd2UgZG8gbm90IGF0dGVtcHQgdG8gYWRkIGFub3RoZXIgbGF5ZXIgb2YgcmVzcG9uc2l2ZW5lc3MuXG4gICAgICovXG4gICAgcmV0dXJuIHByb3BzLmNoaWxkcmVuO1xuICB9XG4gIHZhciB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSBnZXREZWZhdWx0V2lkdGhBbmRIZWlnaHQoe1xuICAgIHdpZHRoOiBwcm9wcy53aWR0aCxcbiAgICBoZWlnaHQ6IHByb3BzLmhlaWdodCxcbiAgICBhc3BlY3Q6IHByb3BzLmFzcGVjdFxuICB9KTtcblxuICAvKlxuICAgKiBMZXQncyB0cnkgdG8gZ2V0IHRoZSBjYWxjdWxhdGVkIGRpbWVuc2lvbnMgd2l0aG91dCBoYXZpbmcgdGhlIGRpdiBjb250YWluZXIgc2V0IHVwLlxuICAgKiBTb21ldGltZXMgdGhpcyBkb2VzIHByb2R1Y2UgZml4ZWQsIHBvc2l0aXZlIGRpbWVuc2lvbnMuIElmIHNvLCB3ZSBjYW4gc2tpcCByZW5kZXJpbmcgdGhlIGRpdiBhbmQgbW9uaXRvcmluZyBpdHMgc2l6ZS5cbiAgICovXG4gIHZhciB7XG4gICAgY2FsY3VsYXRlZFdpZHRoLFxuICAgIGNhbGN1bGF0ZWRIZWlnaHRcbiAgfSA9IGNhbGN1bGF0ZUNoYXJ0RGltZW5zaW9ucyh1bmRlZmluZWQsIHVuZGVmaW5lZCwge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICBhc3BlY3Q6IHByb3BzLmFzcGVjdCxcbiAgICBtYXhIZWlnaHQ6IHByb3BzLm1heEhlaWdodFxuICB9KTtcbiAgaWYgKGlzTnVtYmVyKGNhbGN1bGF0ZWRXaWR0aCkgJiYgaXNOdW1iZXIoY2FsY3VsYXRlZEhlaWdodCkpIHtcbiAgICAvKlxuICAgICAqIElmIGl0IGp1c3Qgc28gaGFwcGVucyB0aGF0IHRoZSBjb21iaW5hdGlvbiBvZiB3aWR0aCwgaGVpZ2h0LCBhbmQgYXNwZWN0IHJhdGlvXG4gICAgICogcmVzdWx0cyBpbiBmaXhlZCBkaW1lbnNpb25zLCB0aGVuIHdlIGRvbid0IG5lZWQgdG8gbW9uaXRvciB0aGUgY29udGFpbmVyJ3Mgc2l6ZS5cbiAgICAgKiBXZSBjYW4ganVzdCBwcm92aWRlIHRoZXNlIGZpeGVkIGRpbWVuc2lvbnMgdG8gdGhlIGNvbnRleHQuXG4gICAgICpcbiAgICAgKiBOb3RlIHRoYXQgaGVyZSB3ZSBhcmUgbm90IGNoZWNraW5nIGZvciBwb3NpdGl2ZSBudW1iZXJzO1xuICAgICAqIGlmIHRoZSB1c2VyIHByb3ZpZGVzIGEgemVybyBvciBuZWdhdGl2ZSB3aWR0aC9oZWlnaHQsIHdlIHdpbGwganVzdCBwYXNzIHRoYXQgYWxvbmdcbiAgICAgKiBhcyB3aGF0ZXZlciBzaXplIHdlIGRldGVjdCB3b24ndCBiZSBoZWxwaW5nIGFueXdheS5cbiAgICAgKi9cbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVzcG9uc2l2ZUNvbnRhaW5lckNvbnRleHRQcm92aWRlciwge1xuICAgICAgd2lkdGg6IGNhbGN1bGF0ZWRXaWR0aCxcbiAgICAgIGhlaWdodDogY2FsY3VsYXRlZEhlaWdodFxuICAgIH0sIHByb3BzLmNoaWxkcmVuKTtcbiAgfVxuICAvKlxuICAgKiBTdGF0aWMgYW5hbHlzaXMgZGlkIG5vdCBwcm9kdWNlIGZpeGVkIGRpbWVuc2lvbnMsXG4gICAqIHNvIHdlIG5lZWQgdG8gcmVuZGVyIGEgc3BlY2lhbCBkaXYgYW5kIG1vbml0b3IgaXRzIHNpemUuXG4gICAqL1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoU2l6ZURldGVjdG9yQ29udGFpbmVyLCBfZXh0ZW5kcyh7fSwgcHJvcHMsIHtcbiAgICB3aWR0aDogd2lkdGgsXG4gICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgcmVmOiByZWZcbiAgfSkpO1xufSk7IiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmV4cG9ydCB2YXIgQnJ1c2hVcGRhdGVEaXNwYXRjaENvbnRleHQgPSAvKiNfX1BVUkVfXyovY3JlYXRlQ29udGV4dCgoKSA9PiB7fSk7IiwiaW1wb3J0IHsgdXNlQXBwU2VsZWN0b3IgfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5leHBvcnQgdmFyIHVzZUFjY2Vzc2liaWxpdHlMYXllciA9ICgpID0+IHVzZUFwcFNlbGVjdG9yKHN0YXRlID0+IHN0YXRlLnJvb3RQcm9wcy5hY2Nlc3NpYmlsaXR5TGF5ZXIpOyIsInZhciBfZXhjbHVkZWQgPSBbXCJjaGlsZHJlblwiLCBcIndpZHRoXCIsIFwiaGVpZ2h0XCIsIFwidmlld0JveFwiLCBcImNsYXNzTmFtZVwiLCBcInN0eWxlXCIsIFwidGl0bGVcIiwgXCJkZXNjXCJdO1xuZnVuY3Rpb24gX2V4dGVuZHMoKSB7IHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7IGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7IHZhciB0ID0gYXJndW1lbnRzW2VdOyBmb3IgKHZhciByIGluIHQpICh7fSkuaGFzT3duUHJvcGVydHkuY2FsbCh0LCByKSAmJiAobltyXSA9IHRbcl0pOyB9IHJldHVybiBuOyB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuLyoqXG4gKiBAZmlsZU92ZXJ2aWV3IFN1cmZhY2VcbiAqL1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZm9yd2FyZFJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsc3ggfSBmcm9tICdjbHN4JztcbmltcG9ydCB7IHN2Z1Byb3BlcnRpZXNBbmRFdmVudHMgfSBmcm9tICcuLi91dGlsL3N2Z1Byb3BlcnRpZXNBbmRFdmVudHMnO1xuZXhwb3J0IHZhciBTdXJmYWNlID0gLyojX19QVVJFX18qL2ZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgdmFyIHtcbiAgICAgIGNoaWxkcmVuLFxuICAgICAgd2lkdGgsXG4gICAgICBoZWlnaHQsXG4gICAgICB2aWV3Qm94LFxuICAgICAgY2xhc3NOYW1lLFxuICAgICAgc3R5bGUsXG4gICAgICB0aXRsZSxcbiAgICAgIGRlc2NcbiAgICB9ID0gcHJvcHMsXG4gICAgb3RoZXJzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKHByb3BzLCBfZXhjbHVkZWQpO1xuICB2YXIgc3ZnVmlldyA9IHZpZXdCb3ggfHwge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4OiAwLFxuICAgIHk6IDBcbiAgfTtcbiAgdmFyIGxheWVyQ2xhc3MgPSBjbHN4KCdyZWNoYXJ0cy1zdXJmYWNlJywgY2xhc3NOYW1lKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwic3ZnXCIsIF9leHRlbmRzKHt9LCBzdmdQcm9wZXJ0aWVzQW5kRXZlbnRzKG90aGVycyksIHtcbiAgICBjbGFzc05hbWU6IGxheWVyQ2xhc3MsXG4gICAgd2lkdGg6IHdpZHRoLFxuICAgIGhlaWdodDogaGVpZ2h0LFxuICAgIHN0eWxlOiBzdHlsZSxcbiAgICB2aWV3Qm94OiBcIlwiLmNvbmNhdChzdmdWaWV3LngsIFwiIFwiKS5jb25jYXQoc3ZnVmlldy55LCBcIiBcIikuY29uY2F0KHN2Z1ZpZXcud2lkdGgsIFwiIFwiKS5jb25jYXQoc3ZnVmlldy5oZWlnaHQpLFxuICAgIHJlZjogcmVmXG4gIH0pLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIG51bGwsIHRpdGxlKSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkZXNjXCIsIG51bGwsIGRlc2MpLCBjaGlsZHJlbik7XG59KTsiLCJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuZXhwb3J0IHZhciBMZWdlbmRQb3J0YWxDb250ZXh0ID0gLyojX19QVVJFX18qL2NyZWF0ZUNvbnRleHQobnVsbCk7XG5leHBvcnQgdmFyIHVzZUxlZ2VuZFBvcnRhbCA9ICgpID0+IHVzZUNvbnRleHQoTGVnZW5kUG9ydGFsQ29udGV4dCk7IiwiaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5pbXBvcnQgeyBtb3VzZUxlYXZlSXRlbSwgc2V0QWN0aXZlQ2xpY2tJdGVtSW5kZXgsIHNldEFjdGl2ZU1vdXNlT3Zlckl0ZW1JbmRleCB9IGZyb20gJy4uL3N0YXRlL3Rvb2x0aXBTbGljZSc7XG5leHBvcnQgdmFyIHVzZU1vdXNlRW50ZXJJdGVtRGlzcGF0Y2ggPSAob25Nb3VzZUVudGVyRnJvbVByb3BzLCBkYXRhS2V5KSA9PiB7XG4gIHZhciBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIHJldHVybiAoZGF0YSwgaW5kZXgpID0+IGV2ZW50ID0+IHtcbiAgICBvbk1vdXNlRW50ZXJGcm9tUHJvcHMgPT09IG51bGwgfHwgb25Nb3VzZUVudGVyRnJvbVByb3BzID09PSB2b2lkIDAgfHwgb25Nb3VzZUVudGVyRnJvbVByb3BzKGRhdGEsIGluZGV4LCBldmVudCk7XG4gICAgZGlzcGF0Y2goc2V0QWN0aXZlTW91c2VPdmVySXRlbUluZGV4KHtcbiAgICAgIGFjdGl2ZUluZGV4OiBTdHJpbmcoaW5kZXgpLFxuICAgICAgYWN0aXZlRGF0YUtleTogZGF0YUtleSxcbiAgICAgIGFjdGl2ZUNvb3JkaW5hdGU6IGRhdGEudG9vbHRpcFBvc2l0aW9uXG4gICAgfSkpO1xuICB9O1xufTtcbmV4cG9ydCB2YXIgdXNlTW91c2VMZWF2ZUl0ZW1EaXNwYXRjaCA9IG9uTW91c2VMZWF2ZUZyb21Qcm9wcyA9PiB7XG4gIHZhciBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIHJldHVybiAoZGF0YSwgaW5kZXgpID0+IGV2ZW50ID0+IHtcbiAgICBvbk1vdXNlTGVhdmVGcm9tUHJvcHMgPT09IG51bGwgfHwgb25Nb3VzZUxlYXZlRnJvbVByb3BzID09PSB2b2lkIDAgfHwgb25Nb3VzZUxlYXZlRnJvbVByb3BzKGRhdGEsIGluZGV4LCBldmVudCk7XG4gICAgZGlzcGF0Y2gobW91c2VMZWF2ZUl0ZW0oKSk7XG4gIH07XG59O1xuZXhwb3J0IHZhciB1c2VNb3VzZUNsaWNrSXRlbURpc3BhdGNoID0gKG9uTW91c2VDbGlja0Zyb21Qcm9wcywgZGF0YUtleSkgPT4ge1xuICB2YXIgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuICByZXR1cm4gKGRhdGEsIGluZGV4KSA9PiBldmVudCA9PiB7XG4gICAgb25Nb3VzZUNsaWNrRnJvbVByb3BzID09PSBudWxsIHx8IG9uTW91c2VDbGlja0Zyb21Qcm9wcyA9PT0gdm9pZCAwIHx8IG9uTW91c2VDbGlja0Zyb21Qcm9wcyhkYXRhLCBpbmRleCwgZXZlbnQpO1xuICAgIGRpc3BhdGNoKHNldEFjdGl2ZUNsaWNrSXRlbUluZGV4KHtcbiAgICAgIGFjdGl2ZUluZGV4OiBTdHJpbmcoaW5kZXgpLFxuICAgICAgYWN0aXZlRGF0YUtleTogZGF0YUtleSxcbiAgICAgIGFjdGl2ZUNvb3JkaW5hdGU6IGRhdGEudG9vbHRpcFBvc2l0aW9uXG4gICAgfSkpO1xuICB9O1xufTsiLCJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBzZXRDaGFydERhdGEsIHNldENvbXB1dGVkRGF0YSB9IGZyb20gJy4uL3N0YXRlL2NoYXJ0RGF0YVNsaWNlJztcbmltcG9ydCB7IHVzZUFwcERpc3BhdGNoLCB1c2VBcHBTZWxlY3RvciB9IGZyb20gJy4uL3N0YXRlL2hvb2tzJztcbmltcG9ydCB7IHVzZUlzUGFub3JhbWEgfSBmcm9tICcuL1Bhbm9yYW1hQ29udGV4dCc7XG5leHBvcnQgdmFyIENoYXJ0RGF0YUNvbnRleHRQcm92aWRlciA9IHByb3BzID0+IHtcbiAgdmFyIHtcbiAgICBjaGFydERhdGFcbiAgfSA9IHByb3BzO1xuICB2YXIgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuICB2YXIgaXNQYW5vcmFtYSA9IHVzZUlzUGFub3JhbWEoKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNQYW5vcmFtYSkge1xuICAgICAgLy8gUGFub3JhbWEgbW9kZSByZXVzZXMgZGF0YSBmcm9tIHRoZSBtYWluIGNoYXJ0LCBzbyB3ZSBtdXN0IG5vdCBvdmVyd3JpdGUgaXQgaGVyZS5cbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIC8vIHRoZXJlIGlzIG5vdGhpbmcgdG8gY2xlYW4gdXBcbiAgICAgIH07XG4gICAgfVxuICAgIGRpc3BhdGNoKHNldENoYXJ0RGF0YShjaGFydERhdGEpKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZGlzcGF0Y2goc2V0Q2hhcnREYXRhKHVuZGVmaW5lZCkpO1xuICAgIH07XG4gIH0sIFtjaGFydERhdGEsIGRpc3BhdGNoLCBpc1Bhbm9yYW1hXSk7XG4gIHJldHVybiBudWxsO1xufTtcbmV4cG9ydCB2YXIgU2V0Q29tcHV0ZWREYXRhID0gcHJvcHMgPT4ge1xuICB2YXIge1xuICAgIGNvbXB1dGVkRGF0YVxuICB9ID0gcHJvcHM7XG4gIHZhciBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZGlzcGF0Y2goc2V0Q29tcHV0ZWREYXRhKGNvbXB1dGVkRGF0YSkpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkaXNwYXRjaChzZXRDaGFydERhdGEodW5kZWZpbmVkKSk7XG4gICAgfTtcbiAgfSwgW2NvbXB1dGVkRGF0YSwgZGlzcGF0Y2hdKTtcbiAgcmV0dXJuIG51bGw7XG59O1xudmFyIHNlbGVjdENoYXJ0RGF0YSA9IHN0YXRlID0+IHN0YXRlLmNoYXJ0RGF0YS5jaGFydERhdGE7XG5cbi8qKlxuICogXCJkYXRhXCIgaXMgdGhlIGRhdGEgb2YgdGhlIGNoYXJ0IC0gaXQgaGFzIG5vIHR5cGUgYmVjYXVzZSB0aGlzIHBhcnQgb2YgcmVjaGFydHMgaXMgdmVyeSBmbGV4aWJsZS5cbiAqIEJhc2ljYWxseSBpdCdzIGFuIGFycmF5IG9mIFwic29tZXRoaW5nXCIgYW5kIHRoZW4gdGhlcmUncyB0aGUgZGF0YUtleSBwcm9wZXJ0eSBpbiB2YXJpb3VzIHBsYWNlc1xuICogdGhhdCdzIG1lYW50IHRvIHB1bGwgb3RoZXIgdGhpbmdzIGF3YXkgZnJvbSB0aGUgZGF0YS5cbiAqXG4gKiBTb21lIGNoYXJ0cyBoYXZlIGBkYXRhYCBkZWZpbmVkIG9uIHRoZSBjaGFydCByb290LCBhbmQgdGhleSB3aWxsIHJldHVybiB0aGUgYXJyYXkgdGhyb3VnaCB0aGlzIGhvb2suXG4gKiBGb3IgZXhhbXBsZTogPENvbXBvc2VkQ2hhcnQgZGF0YT17ZGF0YX0gLz4uXG4gKlxuICogT3RoZXIgY2hhcnRzLCBzdWNoIGFzIFBpZSwgaGF2ZSBkYXRhIGRlZmluZWQgb24gaW5kaXZpZHVhbCBncmFwaGljYWwgZWxlbWVudHMuXG4gKiBUaGVzZSBjaGFydHMgd2lsbCByZXR1cm4gYHVuZGVmaW5lZGAgdGhyb3VnaCB0aGlzIGhvb2ssIGFuZCB5b3UgbmVlZCB0byByZWFkIHRoZSBkYXRhIGZyb20gY2hpbGRyZW4uXG4gKiBGb3IgZXhhbXBsZTogPFBpZUNoYXJ0PjxQaWUgZGF0YT17ZGF0YX0gLz5cbiAqXG4gKiBTb21lIGNoYXJ0cyBhbHNvIGFsbG93IHNldHRpbmcgYm90aCAtIGRhdGEgb24gdGhlIHBhcmVudCwgYW5kIGRhdGEgb24gdGhlIGNoaWxkcmVuIGF0IHRoZSBzYW1lIHRpbWUhXG4gKiBIb3dldmVyLCB0aGlzIHBhcnRpY3VsYXIgc2VsZWN0b3Igd2lsbCBvbmx5IHJldHVybiB0aGUgb25lcyBkZWZpbmVkIG9uIHRoZSBwYXJlbnQuXG4gKlxuICogQGRlcHJlY2F0ZWQgdXNlIG9uZSBvZiB0aGUgb3RoZXIgc2VsZWN0b3JzIGluc3RlYWQgLSB3aGljaCBvbmUsIGRlcGVuZHMgb24gaG93IGRvIHlvdSBpZGVudGlmeSB0aGUgYXBwbGljYWJsZSBncmFwaGljYWwgaXRlbXMuXG4gKlxuICogQHJldHVybiBkYXRhIGFycmF5IGZvciBzb21lIGNoYXJ0cyBhbmQgdW5kZWZpbmVkIGZvciBvdGhlclxuICovXG5leHBvcnQgdmFyIHVzZUNoYXJ0RGF0YSA9ICgpID0+IHVzZUFwcFNlbGVjdG9yKHNlbGVjdENoYXJ0RGF0YSk7XG52YXIgc2VsZWN0RGF0YUluZGV4ID0gc3RhdGUgPT4ge1xuICB2YXIge1xuICAgIGRhdGFTdGFydEluZGV4LFxuICAgIGRhdGFFbmRJbmRleFxuICB9ID0gc3RhdGUuY2hhcnREYXRhO1xuICByZXR1cm4ge1xuICAgIHN0YXJ0SW5kZXg6IGRhdGFTdGFydEluZGV4LFxuICAgIGVuZEluZGV4OiBkYXRhRW5kSW5kZXhcbiAgfTtcbn07XG5cbi8qKlxuICogc3RhcnRJbmRleCBhbmQgZW5kSW5kZXggYXJlIGRhdGEgYm91bmRhcmllcywgc2V0IHRocm91Z2ggQnJ1c2guXG4gKlxuICogQHJldHVybiBvYmplY3Qgd2l0aCBzdGFydEluZGV4IGFuZCBlbmRJbmRleFxuICovXG5leHBvcnQgdmFyIHVzZURhdGFJbmRleCA9ICgpID0+IHtcbiAgcmV0dXJuIHVzZUFwcFNlbGVjdG9yKHNlbGVjdERhdGFJbmRleCk7XG59OyIsIi8qKlxuICogQGZpbGVPdmVydmlldyBDcm9zc1xuICovXG5cbmV4cG9ydCB2YXIgQ2VsbCA9IF9wcm9wcyA9PiBudWxsO1xuQ2VsbC5kaXNwbGF5TmFtZSA9ICdDZWxsJzsiLCJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuZXhwb3J0IHZhciBUb29sdGlwUG9ydGFsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KG51bGwpO1xuZXhwb3J0IHZhciB1c2VUb29sdGlwUG9ydGFsID0gKCkgPT4gdXNlQ29udGV4dChUb29sdGlwUG9ydGFsQ29udGV4dCk7IiwidmFyIF9leGNsdWRlZCA9IFtcImNvbXBvbmVudFwiXTtcbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhlLCB0KSB7IGlmIChudWxsID09IGUpIHJldHVybiB7fTsgdmFyIG8sIHIsIGkgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShlLCB0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG4gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyBmb3IgKHIgPSAwOyByIDwgbi5sZW5ndGg7IHIrKykgbyA9IG5bcl0sIC0xID09PSB0LmluZGV4T2YobykgJiYge30ucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChlLCBvKSAmJiAoaVtvXSA9IGVbb10pOyB9IHJldHVybiBpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShyLCBlKSB7IGlmIChudWxsID09IHIpIHJldHVybiB7fTsgdmFyIHQgPSB7fTsgZm9yICh2YXIgbiBpbiByKSBpZiAoe30uaGFzT3duUHJvcGVydHkuY2FsbChyLCBuKSkgeyBpZiAoLTEgIT09IGUuaW5kZXhPZihuKSkgY29udGludWU7IHRbbl0gPSByW25dOyB9IHJldHVybiB0OyB9XG4vKipcbiAqIEBmaWxlT3ZlcnZpZXcgQ3VzdG9taXplZFxuICovXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBpc1ZhbGlkRWxlbWVudCwgY2xvbmVFbGVtZW50LCBjcmVhdGVFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGF5ZXIgfSBmcm9tICcuLi9jb250YWluZXIvTGF5ZXInO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uL3V0aWwvTG9nVXRpbHMnO1xuLyoqXG4gKiBjdXN0b20gc3ZnIGVsZW1lbnRzIGJ5IHJlY2hhcnQgaW5zdGFuY2UgcHJvcHMgYW5kIHN0YXRlLlxuICogQHJldHVybnMge09iamVjdH0gICBzdmcgZWxlbWVudHNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEN1c3RvbWl6ZWQoX3JlZikge1xuICB2YXIge1xuICAgICAgY29tcG9uZW50XG4gICAgfSA9IF9yZWYsXG4gICAgcHJvcHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoX3JlZiwgX2V4Y2x1ZGVkKTtcbiAgdmFyIGNoaWxkO1xuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGNvbXBvbmVudCkpIHtcbiAgICBjaGlsZCA9IC8qI19fUFVSRV9fKi9jbG9uZUVsZW1lbnQoY29tcG9uZW50LCBwcm9wcyk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGNvbXBvbmVudCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNoaWxkID0gLyojX19QVVJFX18qL2NyZWF0ZUVsZW1lbnQoY29tcG9uZW50LCBwcm9wcyk7XG4gIH0gZWxzZSB7XG4gICAgd2FybihmYWxzZSwgXCJDdXN0b21pemVkJ3MgcHJvcHMgYGNvbXBvbmVudGAgbXVzdCBiZSBSZWFjdC5lbGVtZW50IG9yIEZ1bmN0aW9uLCBidXQgZ290ICVzLlwiLCB0eXBlb2YgY29tcG9uZW50KTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGF5ZXIsIHtcbiAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtY3VzdG9taXplZC13cmFwcGVyXCJcbiAgfSwgY2hpbGQpO1xufVxuQ3VzdG9taXplZC5kaXNwbGF5TmFtZSA9ICdDdXN0b21pemVkJzsiLCJ2YXIgX2V4Y2x1ZGVkID0gW1wiY2hpbGRyZW5cIl07XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX2V4dGVuZHMoKSB7IHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7IGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7IHZhciB0ID0gYXJndW1lbnRzW2VdOyBmb3IgKHZhciByIGluIHQpICh7fSkuaGFzT3duUHJvcGVydHkuY2FsbCh0LCByKSAmJiAobltyXSA9IHRbcl0pOyB9IHJldHVybiBuOyB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpOyB9XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBmb3J3YXJkUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ2hhcnRIZWlnaHQsIHVzZUNoYXJ0V2lkdGggfSBmcm9tICcuLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyB1c2VBY2Nlc3NpYmlsaXR5TGF5ZXIgfSBmcm9tICcuLi9jb250ZXh0L2FjY2Vzc2liaWxpdHlDb250ZXh0JztcbmltcG9ydCB7IHVzZUlzUGFub3JhbWEgfSBmcm9tICcuLi9jb250ZXh0L1Bhbm9yYW1hQ29udGV4dCc7XG5pbXBvcnQgeyBTdXJmYWNlIH0gZnJvbSAnLi9TdXJmYWNlJztcbmltcG9ydCB7IHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vc3RhdGUvaG9va3MnO1xuaW1wb3J0IHsgc2VsZWN0QnJ1c2hEaW1lbnNpb25zIH0gZnJvbSAnLi4vc3RhdGUvc2VsZWN0b3JzL2JydXNoU2VsZWN0b3JzJztcbmltcG9ydCB7IGlzUG9zaXRpdmVOdW1iZXIgfSBmcm9tICcuLi91dGlsL2lzV2VsbEJlaGF2ZWROdW1iZXInO1xudmFyIEZVTExfV0lEVEhfQU5EX0hFSUdIVCA9IHtcbiAgd2lkdGg6ICcxMDAlJyxcbiAgaGVpZ2h0OiAnMTAwJScsXG4gIC8qXG4gICAqIGRpc3BsYXk6IGJsb2NrIGlzIG5lY2Vzc2FyeSBoZXJlIGJlY2F1c2UgdGhlIGRlZmF1bHQgZm9yIGFuIFNWRyBpcyBkaXNwbGF5OiBpbmxpbmUsXG4gICAqIHdoaWNoIGluIHNvbWUgYnJvd3NlcnMgKENocm9tZSkgYWRkcyBhIGxpdHRsZSBiaXQgb2YgZXh0cmEgc3BhY2UgYWJvdmUgYW5kIGJlbG93IHRoZSBTVkdcbiAgICogdG8gbWFrZSBzcGFjZSBmb3IgdGhlIGRlc2NlbmRlciBvZiBsZXR0ZXJzIGxpa2UgXCJnXCIgYW5kIFwieVwiLiBUaGlzIHRocm93cyBvZmYgdGhlIGhlaWdodCBjYWxjdWxhdGlvblxuICAgKiBhbmQgY2F1c2VzIHRoZSBjb250YWluZXIgdG8gZ3JvdyBpbmRlZmluaXRlbHkgb24gZWFjaCByZW5kZXIgd2l0aCByZXNwb25zaXZlPXRydWUuXG4gICAqIERpc3BsYXk6IGJsb2NrIHJlbW92ZXMgdGhhdCBleHRyYSBzcGFjZS5cbiAgICpcbiAgICogSW50ZXJlc3RpbmdseSwgRmlyZWZveCBkb2VzIG5vdCBoYXZlIHRoaXMgcHJvYmxlbSwgYnV0IGl0IGRvZXNuJ3QgaHVydCB0byBhZGQgdGhlIHN0eWxlIGFueXdheS5cbiAgICovXG4gIGRpc3BsYXk6ICdibG9jaydcbn07XG52YXIgTWFpbkNoYXJ0U3VyZmFjZSA9IC8qI19fUFVSRV9fKi9mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIHZhciB3aWR0aCA9IHVzZUNoYXJ0V2lkdGgoKTtcbiAgdmFyIGhlaWdodCA9IHVzZUNoYXJ0SGVpZ2h0KCk7XG4gIHZhciBoYXNBY2Nlc3NpYmlsaXR5TGF5ZXIgPSB1c2VBY2Nlc3NpYmlsaXR5TGF5ZXIoKTtcbiAgaWYgKCFpc1Bvc2l0aXZlTnVtYmVyKHdpZHRoKSB8fCAhaXNQb3NpdGl2ZU51bWJlcihoZWlnaHQpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIHtcbiAgICBjaGlsZHJlbixcbiAgICBvdGhlckF0dHJpYnV0ZXMsXG4gICAgdGl0bGUsXG4gICAgZGVzY1xuICB9ID0gcHJvcHM7XG4gIHZhciB0YWJJbmRleCwgcm9sZTtcbiAgaWYgKHR5cGVvZiBvdGhlckF0dHJpYnV0ZXMudGFiSW5kZXggPT09ICdudW1iZXInKSB7XG4gICAgdGFiSW5kZXggPSBvdGhlckF0dHJpYnV0ZXMudGFiSW5kZXg7XG4gIH0gZWxzZSB7XG4gICAgdGFiSW5kZXggPSBoYXNBY2Nlc3NpYmlsaXR5TGF5ZXIgPyAwIDogdW5kZWZpbmVkO1xuICB9XG4gIGlmICh0eXBlb2Ygb3RoZXJBdHRyaWJ1dGVzLnJvbGUgPT09ICdzdHJpbmcnKSB7XG4gICAgcm9sZSA9IG90aGVyQXR0cmlidXRlcy5yb2xlO1xuICB9IGVsc2Uge1xuICAgIHJvbGUgPSBoYXNBY2Nlc3NpYmlsaXR5TGF5ZXIgPyAnYXBwbGljYXRpb24nIDogdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChTdXJmYWNlLCBfZXh0ZW5kcyh7fSwgb3RoZXJBdHRyaWJ1dGVzLCB7XG4gICAgdGl0bGU6IHRpdGxlLFxuICAgIGRlc2M6IGRlc2MsXG4gICAgcm9sZTogcm9sZSxcbiAgICB0YWJJbmRleDogdGFiSW5kZXgsXG4gICAgd2lkdGg6IHdpZHRoLFxuICAgIGhlaWdodDogaGVpZ2h0LFxuICAgIHN0eWxlOiBGVUxMX1dJRFRIX0FORF9IRUlHSFQsXG4gICAgcmVmOiByZWZcbiAgfSksIGNoaWxkcmVuKTtcbn0pO1xudmFyIEJydXNoUGFub3JhbWFTdXJmYWNlID0gX3JlZiA9PiB7XG4gIHZhciB7XG4gICAgY2hpbGRyZW5cbiAgfSA9IF9yZWY7XG4gIHZhciBicnVzaERpbWVuc2lvbnMgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RCcnVzaERpbWVuc2lvbnMpO1xuICBpZiAoIWJydXNoRGltZW5zaW9ucykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgIHksXG4gICAgeFxuICB9ID0gYnJ1c2hEaW1lbnNpb25zO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoU3VyZmFjZSwge1xuICAgIHdpZHRoOiB3aWR0aCxcbiAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICB4OiB4LFxuICAgIHk6IHlcbiAgfSwgY2hpbGRyZW4pO1xufTtcbmV4cG9ydCB2YXIgUm9vdFN1cmZhY2UgPSAvKiNfX1BVUkVfXyovZm9yd2FyZFJlZigoX3JlZjIsIHJlZikgPT4ge1xuICB2YXIge1xuICAgICAgY2hpbGRyZW5cbiAgICB9ID0gX3JlZjIsXG4gICAgcmVzdCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmMiwgX2V4Y2x1ZGVkKTtcbiAgdmFyIGlzUGFub3JhbWEgPSB1c2VJc1Bhbm9yYW1hKCk7XG4gIGlmIChpc1Bhbm9yYW1hKSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEJydXNoUGFub3JhbWFTdXJmYWNlLCBudWxsLCBjaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KE1haW5DaGFydFN1cmZhY2UsIF9leHRlbmRzKHtcbiAgICByZWY6IHJlZlxuICB9LCByZXN0KSwgY2hpbGRyZW4pO1xufSk7IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVVuaXF1ZUlkIH0gZnJvbSAnLi4vdXRpbC91c2VVbmlxdWVJZCc7XG52YXIgR3JhcGhpY2FsSXRlbUlkQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5leHBvcnQgdmFyIFJlZ2lzdGVyR3JhcGhpY2FsSXRlbUlkID0gX3JlZiA9PiB7XG4gIHZhciB7XG4gICAgaWQsXG4gICAgdHlwZSxcbiAgICBjaGlsZHJlblxuICB9ID0gX3JlZjtcbiAgdmFyIHJlc29sdmVkSWQgPSB1c2VVbmlxdWVJZChcInJlY2hhcnRzLVwiLmNvbmNhdCh0eXBlKSwgaWQpO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoR3JhcGhpY2FsSXRlbUlkQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiByZXNvbHZlZElkXG4gIH0sIGNoaWxkcmVuKHJlc29sdmVkSWQpKTtcbn07XG5leHBvcnQgZnVuY3Rpb24gdXNlR3JhcGhpY2FsSXRlbUlkKCkge1xuICByZXR1cm4gdXNlQ29udGV4dChHcmFwaGljYWxJdGVtSWRDb250ZXh0KTtcbn0iLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFB1cmVDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRUb29sdGlwVHJhbnNsYXRlIH0gZnJvbSAnLi4vdXRpbC90b29sdGlwL3RyYW5zbGF0ZSc7XG5leHBvcnQgY2xhc3MgVG9vbHRpcEJvdW5kaW5nQm94IGV4dGVuZHMgUHVyZUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgX2RlZmluZVByb3BlcnR5KHRoaXMsIFwic3RhdGVcIiwge1xuICAgICAgZGlzbWlzc2VkOiBmYWxzZSxcbiAgICAgIGRpc21pc3NlZEF0Q29vcmRpbmF0ZToge1xuICAgICAgICB4OiAwLFxuICAgICAgICB5OiAwXG4gICAgICB9XG4gICAgfSk7XG4gICAgX2RlZmluZVByb3BlcnR5KHRoaXMsIFwiaGFuZGxlS2V5RG93blwiLCBldmVudCA9PiB7XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICB2YXIgX3RoaXMkcHJvcHMkY29vcmRpbmF0LCBfdGhpcyRwcm9wcyRjb29yZGluYXQyLCBfdGhpcyRwcm9wcyRjb29yZGluYXQzLCBfdGhpcyRwcm9wcyRjb29yZGluYXQ0O1xuICAgICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgICBkaXNtaXNzZWQ6IHRydWUsXG4gICAgICAgICAgZGlzbWlzc2VkQXRDb29yZGluYXRlOiB7XG4gICAgICAgICAgICB4OiAoX3RoaXMkcHJvcHMkY29vcmRpbmF0ID0gKF90aGlzJHByb3BzJGNvb3JkaW5hdDIgPSB0aGlzLnByb3BzLmNvb3JkaW5hdGUpID09PSBudWxsIHx8IF90aGlzJHByb3BzJGNvb3JkaW5hdDIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJHByb3BzJGNvb3JkaW5hdDIueCkgIT09IG51bGwgJiYgX3RoaXMkcHJvcHMkY29vcmRpbmF0ICE9PSB2b2lkIDAgPyBfdGhpcyRwcm9wcyRjb29yZGluYXQgOiAwLFxuICAgICAgICAgICAgeTogKF90aGlzJHByb3BzJGNvb3JkaW5hdDMgPSAoX3RoaXMkcHJvcHMkY29vcmRpbmF0NCA9IHRoaXMucHJvcHMuY29vcmRpbmF0ZSkgPT09IG51bGwgfHwgX3RoaXMkcHJvcHMkY29vcmRpbmF0NCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkcHJvcHMkY29vcmRpbmF0NC55KSAhPT0gbnVsbCAmJiBfdGhpcyRwcm9wcyRjb29yZGluYXQzICE9PSB2b2lkIDAgPyBfdGhpcyRwcm9wcyRjb29yZGluYXQzIDogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHRoaXMuaGFuZGxlS2V5RG93bik7XG4gIH1cbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHRoaXMuaGFuZGxlS2V5RG93bik7XG4gIH1cbiAgY29tcG9uZW50RGlkVXBkYXRlKCkge1xuICAgIHZhciBfdGhpcyRwcm9wcyRjb29yZGluYXQ1LCBfdGhpcyRwcm9wcyRjb29yZGluYXQ2O1xuICAgIGlmICghdGhpcy5zdGF0ZS5kaXNtaXNzZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCgoX3RoaXMkcHJvcHMkY29vcmRpbmF0NSA9IHRoaXMucHJvcHMuY29vcmRpbmF0ZSkgPT09IG51bGwgfHwgX3RoaXMkcHJvcHMkY29vcmRpbmF0NSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkcHJvcHMkY29vcmRpbmF0NS54KSAhPT0gdGhpcy5zdGF0ZS5kaXNtaXNzZWRBdENvb3JkaW5hdGUueCB8fCAoKF90aGlzJHByb3BzJGNvb3JkaW5hdDYgPSB0aGlzLnByb3BzLmNvb3JkaW5hdGUpID09PSBudWxsIHx8IF90aGlzJHByb3BzJGNvb3JkaW5hdDYgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJHByb3BzJGNvb3JkaW5hdDYueSkgIT09IHRoaXMuc3RhdGUuZGlzbWlzc2VkQXRDb29yZGluYXRlLnkpIHtcbiAgICAgIHRoaXMuc3RhdGUuZGlzbWlzc2VkID0gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJlbmRlcigpIHtcbiAgICB2YXIge1xuICAgICAgYWN0aXZlLFxuICAgICAgYWxsb3dFc2NhcGVWaWV3Qm94LFxuICAgICAgYW5pbWF0aW9uRHVyYXRpb24sXG4gICAgICBhbmltYXRpb25FYXNpbmcsXG4gICAgICBjaGlsZHJlbixcbiAgICAgIGNvb3JkaW5hdGUsXG4gICAgICBoYXNQYXlsb2FkLFxuICAgICAgaXNBbmltYXRpb25BY3RpdmUsXG4gICAgICBvZmZzZXQsXG4gICAgICBwb3NpdGlvbixcbiAgICAgIHJldmVyc2VEaXJlY3Rpb24sXG4gICAgICB1c2VUcmFuc2xhdGUzZCxcbiAgICAgIHZpZXdCb3gsXG4gICAgICB3cmFwcGVyU3R5bGUsXG4gICAgICBsYXN0Qm91bmRpbmdCb3gsXG4gICAgICBpbm5lclJlZixcbiAgICAgIGhhc1BvcnRhbEZyb21Qcm9wc1xuICAgIH0gPSB0aGlzLnByb3BzO1xuICAgIHZhciB7XG4gICAgICBjc3NDbGFzc2VzLFxuICAgICAgY3NzUHJvcGVydGllc1xuICAgIH0gPSBnZXRUb29sdGlwVHJhbnNsYXRlKHtcbiAgICAgIGFsbG93RXNjYXBlVmlld0JveCxcbiAgICAgIGNvb3JkaW5hdGUsXG4gICAgICBvZmZzZXRUb3BMZWZ0OiBvZmZzZXQsXG4gICAgICBwb3NpdGlvbixcbiAgICAgIHJldmVyc2VEaXJlY3Rpb24sXG4gICAgICB0b29sdGlwQm94OiB7XG4gICAgICAgIGhlaWdodDogbGFzdEJvdW5kaW5nQm94LmhlaWdodCxcbiAgICAgICAgd2lkdGg6IGxhc3RCb3VuZGluZ0JveC53aWR0aFxuICAgICAgfSxcbiAgICAgIHVzZVRyYW5zbGF0ZTNkLFxuICAgICAgdmlld0JveFxuICAgIH0pO1xuXG4gICAgLy8gZG8gbm90IHVzZSBhYnNvbHV0ZSBzdHlsZXMgaWYgdGhlIHVzZXIgaGFzIHBhc3NlZCBhIGN1c3RvbSBwb3J0YWwgcHJvcFxuICAgIHZhciBwb3NpdGlvblN0eWxlcyA9IGhhc1BvcnRhbEZyb21Qcm9wcyA/IHt9IDogX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHtcbiAgICAgIHRyYW5zaXRpb246IGlzQW5pbWF0aW9uQWN0aXZlICYmIGFjdGl2ZSA/IFwidHJhbnNmb3JtIFwiLmNvbmNhdChhbmltYXRpb25EdXJhdGlvbiwgXCJtcyBcIikuY29uY2F0KGFuaW1hdGlvbkVhc2luZykgOiB1bmRlZmluZWRcbiAgICB9LCBjc3NQcm9wZXJ0aWVzKSwge30sIHtcbiAgICAgIHBvaW50ZXJFdmVudHM6ICdub25lJyxcbiAgICAgIHZpc2liaWxpdHk6ICF0aGlzLnN0YXRlLmRpc21pc3NlZCAmJiBhY3RpdmUgJiYgaGFzUGF5bG9hZCA/ICd2aXNpYmxlJyA6ICdoaWRkZW4nLFxuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICB0b3A6IDAsXG4gICAgICBsZWZ0OiAwXG4gICAgfSk7XG4gICAgdmFyIG91dGVyU3R5bGUgPSBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHBvc2l0aW9uU3R5bGVzKSwge30sIHtcbiAgICAgIHZpc2liaWxpdHk6ICF0aGlzLnN0YXRlLmRpc21pc3NlZCAmJiBhY3RpdmUgJiYgaGFzUGF5bG9hZCA/ICd2aXNpYmxlJyA6ICdoaWRkZW4nXG4gICAgfSwgd3JhcHBlclN0eWxlKTtcbiAgICByZXR1cm4gKFxuICAgICAgLyojX19QVVJFX18qL1xuICAgICAgLy8gVGhpcyBlbGVtZW50IGFsbG93IGxpc3RlbmluZyB0byB0aGUgYEVzY2FwZWAga2V5LiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3JlY2hhcnRzL3JlY2hhcnRzL3B1bGwvMjkyNVxuICAgICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgdHlwZXNjcmlwdCBsaWJyYXJ5IGRvZXMgbm90IHJlY29nbml6ZSB4bWxucyBhdHRyaWJ1dGUsIGJ1dCBpdCdzIHJlcXVpcmVkIGZvciBhbiBIVE1MIGNodW5rIGluc2lkZSBTVkcuXG4gICAgICAgIHhtbG5zOiBcImh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWxcIixcbiAgICAgICAgdGFiSW5kZXg6IC0xLFxuICAgICAgICBjbGFzc05hbWU6IGNzc0NsYXNzZXMsXG4gICAgICAgIHN0eWxlOiBvdXRlclN0eWxlLFxuICAgICAgICByZWY6IGlubmVyUmVmXG4gICAgICB9LCBjaGlsZHJlbilcbiAgICApO1xuICB9XG59IiwiZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5pbXBvcnQgeyB1c2VBcHBTZWxlY3RvciB9IGZyb20gJy4uL3N0YXRlL2hvb2tzJztcbmltcG9ydCB7IGdldEJhbmRTaXplT2ZBeGlzIH0gZnJvbSAnLi4vdXRpbC9DaGFydFV0aWxzJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBBeGlzU2NhbGUsIHNlbGVjdFRvb2x0aXBBeGlzVGlja3MgfSBmcm9tICcuLi9zdGF0ZS9zZWxlY3RvcnMvdG9vbHRpcFNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpcyB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwQXhpcyc7XG5leHBvcnQgdmFyIHVzZVRvb2x0aXBBeGlzID0gKCkgPT4gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0VG9vbHRpcEF4aXMpO1xuZXhwb3J0IHZhciB1c2VUb29sdGlwQXhpc0JhbmRTaXplID0gKCkgPT4ge1xuICB2YXIgdG9vbHRpcEF4aXMgPSB1c2VUb29sdGlwQXhpcygpO1xuICB2YXIgdG9vbHRpcFRpY2tzID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0VG9vbHRpcEF4aXNUaWNrcyk7XG4gIHZhciB0b29sdGlwQXhpc1NjYWxlID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0VG9vbHRpcEF4aXNTY2FsZSk7XG4gIHJldHVybiBnZXRCYW5kU2l6ZU9mQXhpcyhfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHRvb2x0aXBBeGlzKSwge30sIHtcbiAgICBzY2FsZTogdG9vbHRpcEF4aXNTY2FsZVxuICB9KSwgdG9vbHRpcFRpY2tzKTtcbn07IiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7IHJldHVybiBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gPyBPYmplY3QuYXNzaWduLmJpbmQoKSA6IGZ1bmN0aW9uIChuKSB7IGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7IHZhciB0ID0gYXJndW1lbnRzW2VdOyBmb3IgKHZhciByIGluIHQpICh7fSkuaGFzT3duUHJvcGVydHkuY2FsbCh0LCByKSAmJiAobltyXSA9IHRbcl0pOyB9IHJldHVybiBuOyB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpOyB9XG5mdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsb25lRWxlbWVudCwgY3JlYXRlRWxlbWVudCwgaXNWYWxpZEVsZW1lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjbHN4IH0gZnJvbSAnY2xzeCc7XG5pbXBvcnQgeyBDdXJ2ZSB9IGZyb20gJy4uL3NoYXBlL0N1cnZlJztcbmltcG9ydCB7IENyb3NzIH0gZnJvbSAnLi4vc2hhcGUvQ3Jvc3MnO1xuaW1wb3J0IHsgZ2V0Q3Vyc29yUmVjdGFuZ2xlIH0gZnJvbSAnLi4vdXRpbC9jdXJzb3IvZ2V0Q3Vyc29yUmVjdGFuZ2xlJztcbmltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4uL3NoYXBlL1JlY3RhbmdsZSc7XG5pbXBvcnQgeyBnZXRSYWRpYWxDdXJzb3JQb2ludHMgfSBmcm9tICcuLi91dGlsL2N1cnNvci9nZXRSYWRpYWxDdXJzb3JQb2ludHMnO1xuaW1wb3J0IHsgU2VjdG9yIH0gZnJvbSAnLi4vc2hhcGUvU2VjdG9yJztcbmltcG9ydCB7IGdldEN1cnNvclBvaW50cyB9IGZyb20gJy4uL3V0aWwvY3Vyc29yL2dldEN1cnNvclBvaW50cyc7XG5pbXBvcnQgeyB1c2VDaGFydExheW91dCwgdXNlT2Zmc2V0SW50ZXJuYWwgfSBmcm9tICcuLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyB1c2VUb29sdGlwQXhpc0JhbmRTaXplIH0gZnJvbSAnLi4vY29udGV4dC91c2VUb29sdGlwQXhpcyc7XG5pbXBvcnQgeyB1c2VDaGFydE5hbWUgfSBmcm9tICcuLi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0b3JzJztcbmltcG9ydCB7IHN2Z1Byb3BlcnRpZXNOb0V2ZW50c0Zyb21Vbmtub3duIH0gZnJvbSAnLi4vdXRpbC9zdmdQcm9wZXJ0aWVzTm9FdmVudHMnO1xuXG4vKipcbiAqIElmIHNldCBmYWxzZSwgbm8gY3Vyc29yIHdpbGwgYmUgZHJhd24gd2hlbiB0b29sdGlwIGlzIGFjdGl2ZS5cbiAqIElmIHNldCBhbiBvYmplY3QsIHRoZSBvcHRpb24gaXMgdGhlIGNvbmZpZ3VyYXRpb24gb2YgY3Vyc29yLlxuICogSWYgc2V0IGEgUmVhY3QgZWxlbWVudCwgdGhlIG9wdGlvbiBpcyB0aGUgY3VzdG9tIHJlYWN0IGVsZW1lbnQgb2YgZHJhd2luZyBjdXJzb3JcbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gQ3Vyc29ySW50ZXJuYWwocHJvcHMpIHtcbiAgdmFyIHtcbiAgICBjb29yZGluYXRlLFxuICAgIHBheWxvYWQsXG4gICAgaW5kZXgsXG4gICAgb2Zmc2V0LFxuICAgIHRvb2x0aXBBeGlzQmFuZFNpemUsXG4gICAgbGF5b3V0LFxuICAgIGN1cnNvcixcbiAgICB0b29sdGlwRXZlbnRUeXBlLFxuICAgIGNoYXJ0TmFtZVxuICB9ID0gcHJvcHM7XG5cbiAgLy8gVGhlIGN1cnNvciBpcyBhIHBhcnQgb2YgdGhlIFRvb2x0aXAsIGFuZCBpdCBzaG91bGQgYmUgc2hvd24gKGJ5IGRlZmF1bHQpIHdoZW4gdGhlIFRvb2x0aXAgaXMgYWN0aXZlLlxuICB2YXIgYWN0aXZlQ29vcmRpbmF0ZSA9IGNvb3JkaW5hdGU7XG4gIHZhciBhY3RpdmVQYXlsb2FkID0gcGF5bG9hZDtcbiAgdmFyIGFjdGl2ZVRvb2x0aXBJbmRleCA9IGluZGV4O1xuICBpZiAoIWN1cnNvciB8fCAhYWN0aXZlQ29vcmRpbmF0ZSB8fCBjaGFydE5hbWUgIT09ICdTY2F0dGVyQ2hhcnQnICYmIHRvb2x0aXBFdmVudFR5cGUgIT09ICdheGlzJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciByZXN0UHJvcHMsIGN1cnNvckNvbXA7XG4gIGlmIChjaGFydE5hbWUgPT09ICdTY2F0dGVyQ2hhcnQnKSB7XG4gICAgcmVzdFByb3BzID0gYWN0aXZlQ29vcmRpbmF0ZTtcbiAgICBjdXJzb3JDb21wID0gQ3Jvc3M7XG4gIH0gZWxzZSBpZiAoY2hhcnROYW1lID09PSAnQmFyQ2hhcnQnKSB7XG4gICAgcmVzdFByb3BzID0gZ2V0Q3Vyc29yUmVjdGFuZ2xlKGxheW91dCwgYWN0aXZlQ29vcmRpbmF0ZSwgb2Zmc2V0LCB0b29sdGlwQXhpc0JhbmRTaXplKTtcbiAgICBjdXJzb3JDb21wID0gUmVjdGFuZ2xlO1xuICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ3JhZGlhbCcpIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIFRPRE8gdGhlIHN0YXRlIGlzIG1hcmtlZCBhcyBjb250YWluaW5nIENvb3JkaW5hdGUgYnV0IGFjdHVhbGx5IGluIHBvbGFyIGNoYXJ0cyBpdCBjb250YWlucyBQb2xhckNvb3JkaW5hdGUsIHdlIHNob3VsZCBrZWVwIHRoZSBwb2xhciBzdGF0ZSBzZXBhcmF0ZVxuICAgIHZhciB7XG4gICAgICBjeCxcbiAgICAgIGN5LFxuICAgICAgcmFkaXVzLFxuICAgICAgc3RhcnRBbmdsZSxcbiAgICAgIGVuZEFuZ2xlXG4gICAgfSA9IGdldFJhZGlhbEN1cnNvclBvaW50cyhhY3RpdmVDb29yZGluYXRlKTtcbiAgICByZXN0UHJvcHMgPSB7XG4gICAgICBjeCxcbiAgICAgIGN5LFxuICAgICAgc3RhcnRBbmdsZSxcbiAgICAgIGVuZEFuZ2xlLFxuICAgICAgaW5uZXJSYWRpdXM6IHJhZGl1cyxcbiAgICAgIG91dGVyUmFkaXVzOiByYWRpdXNcbiAgICB9O1xuICAgIGN1cnNvckNvbXAgPSBTZWN0b3I7XG4gIH0gZWxzZSB7XG4gICAgcmVzdFByb3BzID0ge1xuICAgICAgcG9pbnRzOiBnZXRDdXJzb3JQb2ludHMobGF5b3V0LCBhY3RpdmVDb29yZGluYXRlLCBvZmZzZXQpXG4gICAgfTtcbiAgICBjdXJzb3JDb21wID0gQ3VydmU7XG4gIH1cbiAgdmFyIGV4dHJhQ2xhc3NOYW1lID0gdHlwZW9mIGN1cnNvciA9PT0gJ29iamVjdCcgJiYgJ2NsYXNzTmFtZScgaW4gY3Vyc29yID8gY3Vyc29yLmNsYXNzTmFtZSA6IHVuZGVmaW5lZDtcbiAgdmFyIGN1cnNvclByb3BzID0gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7XG4gICAgc3Ryb2tlOiAnI2NjYycsXG4gICAgcG9pbnRlckV2ZW50czogJ25vbmUnXG4gIH0sIG9mZnNldCksIHJlc3RQcm9wcyksIHN2Z1Byb3BlcnRpZXNOb0V2ZW50c0Zyb21Vbmtub3duKGN1cnNvcikpLCB7fSwge1xuICAgIHBheWxvYWQ6IGFjdGl2ZVBheWxvYWQsXG4gICAgcGF5bG9hZEluZGV4OiBhY3RpdmVUb29sdGlwSW5kZXgsXG4gICAgY2xhc3NOYW1lOiBjbHN4KCdyZWNoYXJ0cy10b29sdGlwLWN1cnNvcicsIGV4dHJhQ2xhc3NOYW1lKVxuICB9KTtcbiAgaWYgKC8qI19fUFVSRV9fKi9pc1ZhbGlkRWxlbWVudChjdXJzb3IpKSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3ZSBkb24ndCBrbm93IGlmIGN1cnNvclByb3BzIGFyZSBjb3JyZWN0IGZvciB0aGlzIGVsZW1lbnRcbiAgICByZXR1cm4gLyojX19QVVJFX18qL2Nsb25lRWxlbWVudChjdXJzb3IsIGN1cnNvclByb3BzKTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL2NyZWF0ZUVsZW1lbnQoY3Vyc29yQ29tcCwgY3Vyc29yUHJvcHMpO1xufVxuXG4vKlxuICogQ3Vyc29yIGlzIHRoZSBiYWNrZ3JvdW5kLCBvciBhIGhpZ2hsaWdodCxcbiAqIHRoYXQgc2hvd3Mgd2hlbiB1c2VyIG1vdXNlcyBvdmVyIG9yIGFjdGl2YXRlc1xuICogYW4gYXJlYS5cbiAqXG4gKiBJdCB1c3VhbGx5IHNob3dzIHRvZ2V0aGVyIHdpdGggYSB0b29sdGlwXG4gKiB0byBlbXBoYXNpc2Ugd2hpY2ggcGFydCBvZiB0aGUgY2hhcnQgZG9lcyB0aGUgdG9vbHRpcCByZWZlciB0by5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEN1cnNvcihwcm9wcykge1xuICB2YXIgdG9vbHRpcEF4aXNCYW5kU2l6ZSA9IHVzZVRvb2x0aXBBeGlzQmFuZFNpemUoKTtcbiAgdmFyIG9mZnNldCA9IHVzZU9mZnNldEludGVybmFsKCk7XG4gIHZhciBsYXlvdXQgPSB1c2VDaGFydExheW91dCgpO1xuICB2YXIgY2hhcnROYW1lID0gdXNlQ2hhcnROYW1lKCk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChDdXJzb3JJbnRlcm5hbCwgX2V4dGVuZHMoe30sIHByb3BzLCB7XG4gICAgY29vcmRpbmF0ZTogcHJvcHMuY29vcmRpbmF0ZSxcbiAgICBpbmRleDogcHJvcHMuaW5kZXgsXG4gICAgcGF5bG9hZDogcHJvcHMucGF5bG9hZCxcbiAgICBvZmZzZXQ6IG9mZnNldCxcbiAgICBsYXlvdXQ6IGxheW91dCxcbiAgICB0b29sdGlwQXhpc0JhbmRTaXplOiB0b29sdGlwQXhpc0JhbmRTaXplLFxuICAgIGNoYXJ0TmFtZTogY2hhcnROYW1lXG4gIH0pKTtcbn0iLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBEZWZhdWx0VG9vbHRpcENvbnRlbnQgfSBmcm9tICcuL0RlZmF1bHRUb29sdGlwQ29udGVudCc7XG5pbXBvcnQgeyBUb29sdGlwQm91bmRpbmdCb3ggfSBmcm9tICcuL1Rvb2x0aXBCb3VuZGluZ0JveCc7XG5pbXBvcnQgeyBHbG9iYWwgfSBmcm9tICcuLi91dGlsL0dsb2JhbCc7XG5pbXBvcnQgeyBnZXRVbmlxUGF5bG9hZCB9IGZyb20gJy4uL3V0aWwvcGF5bG9hZC9nZXRVbmlxUGF5bG9hZCc7XG5pbXBvcnQgeyB1c2VWaWV3Qm94IH0gZnJvbSAnLi4vY29udGV4dC9jaGFydExheW91dENvbnRleHQnO1xuaW1wb3J0IHsgdXNlQWNjZXNzaWJpbGl0eUxheWVyIH0gZnJvbSAnLi4vY29udGV4dC9hY2Nlc3NpYmlsaXR5Q29udGV4dCc7XG5pbXBvcnQgeyB1c2VFbGVtZW50T2Zmc2V0IH0gZnJvbSAnLi4vdXRpbC91c2VFbGVtZW50T2Zmc2V0JztcbmltcG9ydCB7IEN1cnNvciB9IGZyb20gJy4vQ3Vyc29yJztcbmltcG9ydCB7IHNlbGVjdEFjdGl2ZUNvb3JkaW5hdGUsIHNlbGVjdEFjdGl2ZUxhYmVsLCBzZWxlY3RJc1Rvb2x0aXBBY3RpdmUsIHNlbGVjdFRvb2x0aXBQYXlsb2FkIH0gZnJvbSAnLi4vc3RhdGUvc2VsZWN0b3JzL3NlbGVjdG9ycyc7XG5pbXBvcnQgeyB1c2VUb29sdGlwUG9ydGFsIH0gZnJvbSAnLi4vY29udGV4dC90b29sdGlwUG9ydGFsQ29udGV4dCc7XG5pbXBvcnQgeyB1c2VBcHBEaXNwYXRjaCwgdXNlQXBwU2VsZWN0b3IgfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5pbXBvcnQgeyBzZXRUb29sdGlwU2V0dGluZ3NTdGF0ZSB9IGZyb20gJy4uL3N0YXRlL3Rvb2x0aXBTbGljZSc7XG5pbXBvcnQgeyB1c2VUb29sdGlwQ2hhcnRTeW5jaHJvbmlzYXRpb24gfSBmcm9tICcuLi9zeW5jaHJvbmlzYXRpb24vdXNlQ2hhcnRTeW5jaHJvbmlzYXRpb24nO1xuaW1wb3J0IHsgdXNlVG9vbHRpcEV2ZW50VHlwZSB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwRXZlbnRUeXBlJztcbmltcG9ydCB7IHJlc29sdmVEZWZhdWx0UHJvcHMgfSBmcm9tICcuLi91dGlsL3Jlc29sdmVEZWZhdWx0UHJvcHMnO1xuZnVuY3Rpb24gZGVmYXVsdFVuaXFCeShlbnRyeSkge1xuICByZXR1cm4gZW50cnkuZGF0YUtleTtcbn1cbmZ1bmN0aW9uIHJlbmRlckNvbnRlbnQoY29udGVudCwgcHJvcHMpIHtcbiAgaWYgKC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChjb250ZW50KSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY2xvbmVFbGVtZW50KGNvbnRlbnQsIHByb3BzKTtcbiAgfVxuICBpZiAodHlwZW9mIGNvbnRlbnQgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoY29udGVudCwgcHJvcHMpO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChEZWZhdWx0VG9vbHRpcENvbnRlbnQsIHByb3BzKTtcbn1cbnZhciBlbXB0eVBheWxvYWQgPSBbXTtcbnZhciBkZWZhdWx0VG9vbHRpcFByb3BzID0ge1xuICBhbGxvd0VzY2FwZVZpZXdCb3g6IHtcbiAgICB4OiBmYWxzZSxcbiAgICB5OiBmYWxzZVxuICB9LFxuICBhbmltYXRpb25EdXJhdGlvbjogNDAwLFxuICBhbmltYXRpb25FYXNpbmc6ICdlYXNlJyxcbiAgYXhpc0lkOiAwLFxuICBjb250ZW50U3R5bGU6IHt9LFxuICBjdXJzb3I6IHRydWUsXG4gIGZpbHRlck51bGw6IHRydWUsXG4gIGlzQW5pbWF0aW9uQWN0aXZlOiAhR2xvYmFsLmlzU3NyLFxuICBpdGVtU29ydGVyOiAnbmFtZScsXG4gIGl0ZW1TdHlsZToge30sXG4gIGxhYmVsU3R5bGU6IHt9LFxuICBvZmZzZXQ6IDEwLFxuICByZXZlcnNlRGlyZWN0aW9uOiB7XG4gICAgeDogZmFsc2UsXG4gICAgeTogZmFsc2VcbiAgfSxcbiAgc2VwYXJhdG9yOiAnIDogJyxcbiAgdHJpZ2dlcjogJ2hvdmVyJyxcbiAgdXNlVHJhbnNsYXRlM2Q6IGZhbHNlLFxuICB3cmFwcGVyU3R5bGU6IHt9XG59O1xuZXhwb3J0IGZ1bmN0aW9uIFRvb2x0aXAob3V0c2lkZVByb3BzKSB7XG4gIHZhciBwcm9wcyA9IHJlc29sdmVEZWZhdWx0UHJvcHMob3V0c2lkZVByb3BzLCBkZWZhdWx0VG9vbHRpcFByb3BzKTtcbiAgdmFyIHtcbiAgICBhY3RpdmU6IGFjdGl2ZUZyb21Qcm9wcyxcbiAgICBhbGxvd0VzY2FwZVZpZXdCb3gsXG4gICAgYW5pbWF0aW9uRHVyYXRpb24sXG4gICAgYW5pbWF0aW9uRWFzaW5nLFxuICAgIGNvbnRlbnQsXG4gICAgZmlsdGVyTnVsbCxcbiAgICBpc0FuaW1hdGlvbkFjdGl2ZSxcbiAgICBvZmZzZXQsXG4gICAgcGF5bG9hZFVuaXFCeSxcbiAgICBwb3NpdGlvbixcbiAgICByZXZlcnNlRGlyZWN0aW9uLFxuICAgIHVzZVRyYW5zbGF0ZTNkLFxuICAgIHdyYXBwZXJTdHlsZSxcbiAgICBjdXJzb3IsXG4gICAgc2hhcmVkLFxuICAgIHRyaWdnZXIsXG4gICAgZGVmYXVsdEluZGV4LFxuICAgIHBvcnRhbDogcG9ydGFsRnJvbVByb3BzLFxuICAgIGF4aXNJZFxuICB9ID0gcHJvcHM7XG4gIHZhciBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIHZhciBkZWZhdWx0SW5kZXhBc1N0cmluZyA9IHR5cGVvZiBkZWZhdWx0SW5kZXggPT09ICdudW1iZXInID8gU3RyaW5nKGRlZmF1bHRJbmRleCkgOiBkZWZhdWx0SW5kZXg7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZGlzcGF0Y2goc2V0VG9vbHRpcFNldHRpbmdzU3RhdGUoe1xuICAgICAgc2hhcmVkLFxuICAgICAgdHJpZ2dlcixcbiAgICAgIGF4aXNJZCxcbiAgICAgIGFjdGl2ZTogYWN0aXZlRnJvbVByb3BzLFxuICAgICAgZGVmYXVsdEluZGV4OiBkZWZhdWx0SW5kZXhBc1N0cmluZ1xuICAgIH0pKTtcbiAgfSwgW2Rpc3BhdGNoLCBzaGFyZWQsIHRyaWdnZXIsIGF4aXNJZCwgYWN0aXZlRnJvbVByb3BzLCBkZWZhdWx0SW5kZXhBc1N0cmluZ10pO1xuICB2YXIgdmlld0JveCA9IHVzZVZpZXdCb3goKTtcbiAgdmFyIGFjY2Vzc2liaWxpdHlMYXllciA9IHVzZUFjY2Vzc2liaWxpdHlMYXllcigpO1xuICB2YXIgdG9vbHRpcEV2ZW50VHlwZSA9IHVzZVRvb2x0aXBFdmVudFR5cGUoc2hhcmVkKTtcbiAgdmFyIHtcbiAgICBhY3RpdmVJbmRleCxcbiAgICBpc0FjdGl2ZVxuICB9ID0gdXNlQXBwU2VsZWN0b3Ioc3RhdGUgPT4gc2VsZWN0SXNUb29sdGlwQWN0aXZlKHN0YXRlLCB0b29sdGlwRXZlbnRUeXBlLCB0cmlnZ2VyLCBkZWZhdWx0SW5kZXhBc1N0cmluZykpO1xuICB2YXIgcGF5bG9hZEZyb21SZWR1eCA9IHVzZUFwcFNlbGVjdG9yKHN0YXRlID0+IHNlbGVjdFRvb2x0aXBQYXlsb2FkKHN0YXRlLCB0b29sdGlwRXZlbnRUeXBlLCB0cmlnZ2VyLCBkZWZhdWx0SW5kZXhBc1N0cmluZykpO1xuICB2YXIgbGFiZWxGcm9tUmVkdXggPSB1c2VBcHBTZWxlY3RvcihzdGF0ZSA9PiBzZWxlY3RBY3RpdmVMYWJlbChzdGF0ZSwgdG9vbHRpcEV2ZW50VHlwZSwgdHJpZ2dlciwgZGVmYXVsdEluZGV4QXNTdHJpbmcpKTtcbiAgdmFyIGNvb3JkaW5hdGUgPSB1c2VBcHBTZWxlY3RvcihzdGF0ZSA9PiBzZWxlY3RBY3RpdmVDb29yZGluYXRlKHN0YXRlLCB0b29sdGlwRXZlbnRUeXBlLCB0cmlnZ2VyLCBkZWZhdWx0SW5kZXhBc1N0cmluZykpO1xuICB2YXIgcGF5bG9hZCA9IHBheWxvYWRGcm9tUmVkdXg7XG4gIHZhciB0b29sdGlwUG9ydGFsRnJvbUNvbnRleHQgPSB1c2VUb29sdGlwUG9ydGFsKCk7XG4gIC8qXG4gICAqIFRoZSB1c2VyIGNhbiBzZXQgYGFjdGl2ZT10cnVlYCBvbiB0aGUgVG9vbHRpcCBpbiB3aGljaCBjYXNlIHRoZSBUb29sdGlwIHdpbGwgc3RheSBhbHdheXMgYWN0aXZlLFxuICAgKiBvciBgYWN0aXZlPWZhbHNlYCBpbiB3aGljaCBjYXNlIHRoZSBUb29sdGlwIG5ldmVyIHNob3dzLlxuICAgKlxuICAgKiBJZiB0aGUgYGFjdGl2ZWAgcHJvcCBpcyBub3QgZGVmaW5lZCB0aGVuIGl0IHdpbGwgc2hvdyBhbmQgaGlkZSBiYXNlZCBvbiBtb3VzZSBvciBrZXlib2FyZCBhY3Rpdml0eS5cbiAgICovXG4gIHZhciBmaW5hbElzQWN0aXZlID0gYWN0aXZlRnJvbVByb3BzICE9PSBudWxsICYmIGFjdGl2ZUZyb21Qcm9wcyAhPT0gdm9pZCAwID8gYWN0aXZlRnJvbVByb3BzIDogaXNBY3RpdmU7XG4gIHZhciBbbGFzdEJvdW5kaW5nQm94LCB1cGRhdGVCb3VuZGluZ0JveF0gPSB1c2VFbGVtZW50T2Zmc2V0KFtwYXlsb2FkLCBmaW5hbElzQWN0aXZlXSk7XG4gIHZhciBmaW5hbExhYmVsID0gdG9vbHRpcEV2ZW50VHlwZSA9PT0gJ2F4aXMnID8gbGFiZWxGcm9tUmVkdXggOiB1bmRlZmluZWQ7XG4gIHVzZVRvb2x0aXBDaGFydFN5bmNocm9uaXNhdGlvbih0b29sdGlwRXZlbnRUeXBlLCB0cmlnZ2VyLCBjb29yZGluYXRlLCBmaW5hbExhYmVsLCBhY3RpdmVJbmRleCwgZmluYWxJc0FjdGl2ZSk7XG4gIHZhciB0b29sdGlwUG9ydGFsID0gcG9ydGFsRnJvbVByb3BzICE9PSBudWxsICYmIHBvcnRhbEZyb21Qcm9wcyAhPT0gdm9pZCAwID8gcG9ydGFsRnJvbVByb3BzIDogdG9vbHRpcFBvcnRhbEZyb21Db250ZXh0O1xuICBpZiAodG9vbHRpcFBvcnRhbCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIGZpbmFsUGF5bG9hZCA9IHBheWxvYWQgIT09IG51bGwgJiYgcGF5bG9hZCAhPT0gdm9pZCAwID8gcGF5bG9hZCA6IGVtcHR5UGF5bG9hZDtcbiAgaWYgKCFmaW5hbElzQWN0aXZlKSB7XG4gICAgZmluYWxQYXlsb2FkID0gZW1wdHlQYXlsb2FkO1xuICB9XG4gIGlmIChmaWx0ZXJOdWxsICYmIGZpbmFsUGF5bG9hZC5sZW5ndGgpIHtcbiAgICBmaW5hbFBheWxvYWQgPSBnZXRVbmlxUGF5bG9hZChwYXlsb2FkLmZpbHRlcihlbnRyeSA9PiBlbnRyeS52YWx1ZSAhPSBudWxsICYmIChlbnRyeS5oaWRlICE9PSB0cnVlIHx8IHByb3BzLmluY2x1ZGVIaWRkZW4pKSwgcGF5bG9hZFVuaXFCeSwgZGVmYXVsdFVuaXFCeSk7XG4gIH1cbiAgdmFyIGhhc1BheWxvYWQgPSBmaW5hbFBheWxvYWQubGVuZ3RoID4gMDtcbiAgdmFyIHRvb2x0aXBFbGVtZW50ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoVG9vbHRpcEJvdW5kaW5nQm94LCB7XG4gICAgYWxsb3dFc2NhcGVWaWV3Qm94OiBhbGxvd0VzY2FwZVZpZXdCb3gsXG4gICAgYW5pbWF0aW9uRHVyYXRpb246IGFuaW1hdGlvbkR1cmF0aW9uLFxuICAgIGFuaW1hdGlvbkVhc2luZzogYW5pbWF0aW9uRWFzaW5nLFxuICAgIGlzQW5pbWF0aW9uQWN0aXZlOiBpc0FuaW1hdGlvbkFjdGl2ZSxcbiAgICBhY3RpdmU6IGZpbmFsSXNBY3RpdmUsXG4gICAgY29vcmRpbmF0ZTogY29vcmRpbmF0ZSxcbiAgICBoYXNQYXlsb2FkOiBoYXNQYXlsb2FkLFxuICAgIG9mZnNldDogb2Zmc2V0LFxuICAgIHBvc2l0aW9uOiBwb3NpdGlvbixcbiAgICByZXZlcnNlRGlyZWN0aW9uOiByZXZlcnNlRGlyZWN0aW9uLFxuICAgIHVzZVRyYW5zbGF0ZTNkOiB1c2VUcmFuc2xhdGUzZCxcbiAgICB2aWV3Qm94OiB2aWV3Qm94LFxuICAgIHdyYXBwZXJTdHlsZTogd3JhcHBlclN0eWxlLFxuICAgIGxhc3RCb3VuZGluZ0JveDogbGFzdEJvdW5kaW5nQm94LFxuICAgIGlubmVyUmVmOiB1cGRhdGVCb3VuZGluZ0JveCxcbiAgICBoYXNQb3J0YWxGcm9tUHJvcHM6IEJvb2xlYW4ocG9ydGFsRnJvbVByb3BzKVxuICB9LCByZW5kZXJDb250ZW50KGNvbnRlbnQsIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcHJvcHMpLCB7fSwge1xuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgcmVuZGVyQ29udGVudCBtZXRob2QgZXhwZWN0cyB0aGUgcGF5bG9hZCB0byBiZSBtdXRhYmxlLCBUT0RPIG1ha2UgaXQgaW1tdXRhYmxlXG4gICAgcGF5bG9hZDogZmluYWxQYXlsb2FkLFxuICAgIGxhYmVsOiBmaW5hbExhYmVsLFxuICAgIGFjdGl2ZTogZmluYWxJc0FjdGl2ZSxcbiAgICBjb29yZGluYXRlLFxuICAgIGFjY2Vzc2liaWxpdHlMYXllclxuICB9KSkpO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9jcmVhdGVQb3J0YWwodG9vbHRpcEVsZW1lbnQsIHRvb2x0aXBQb3J0YWwpLCBmaW5hbElzQWN0aXZlICYmIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEN1cnNvciwge1xuICAgIGN1cnNvcjogY3Vyc29yLFxuICAgIHRvb2x0aXBFdmVudFR5cGU6IHRvb2x0aXBFdmVudFR5cGUsXG4gICAgY29vcmRpbmF0ZTogY29vcmRpbmF0ZSxcbiAgICBwYXlsb2FkOiBwYXlsb2FkLFxuICAgIGluZGV4OiBhY3RpdmVJbmRleFxuICB9KSk7XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1bmlxdWVJZCB9IGZyb20gJy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IHVzZVBsb3RBcmVhIH0gZnJvbSAnLi4vaG9va3MnO1xudmFyIENsaXBQYXRoSWRDb250ZXh0ID0gLyojX19QVVJFX18qL2NyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcblxuLyoqXG4gKiBHZW5lcmF0ZXMgYSB1bmlxdWUgY2xpcCBwYXRoIElEIGZvciB1c2UgaW4gU1ZHIGVsZW1lbnRzLFxuICogYW5kIHB1dHMgaXQgaW4gYSBjb250ZXh0IHByb3ZpZGVyLlxuICpcbiAqIFRvIHJlYWQgdGhlIGNsaXAgcGF0aCBJRCwgdXNlIHRoZSBgdXNlQ2xpcFBhdGhJZGAgaG9vayxcbiAqIG9yIHJlbmRlciBgPENsaXBQYXRoPmAgY29tcG9uZW50IHdoaWNoIHdpbGwgYXV0b21hdGljYWxseSB1c2UgdGhlIElEIGZyb20gdGhpcyBjb250ZXh0LlxuICpcbiAqIEBwYXJhbSBwcm9wcyBjaGlsZHJlbiAtIFJlYWN0IGNoaWxkcmVuIHRvIGJlIHdyYXBwZWQgYnkgdGhlIHByb3ZpZGVyXG4gKiBAcmV0dXJucyBSZWFjdCBDb250ZXh0IFByb3ZpZGVyXG4gKi9cbmV4cG9ydCB2YXIgQ2xpcFBhdGhQcm92aWRlciA9IF9yZWYgPT4ge1xuICB2YXIge1xuICAgIGNoaWxkcmVuXG4gIH0gPSBfcmVmO1xuICB2YXIgW2NsaXBQYXRoSWRdID0gdXNlU3RhdGUoXCJcIi5jb25jYXQodW5pcXVlSWQoJ3JlY2hhcnRzJyksIFwiLWNsaXBcIikpO1xuICB2YXIgcGxvdEFyZWEgPSB1c2VQbG90QXJlYSgpO1xuICBpZiAocGxvdEFyZWEgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoLFxuICAgIGhlaWdodFxuICB9ID0gcGxvdEFyZWE7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChDbGlwUGF0aElkQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjbGlwUGF0aElkXG4gIH0sIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiZGVmc1wiLCBudWxsLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcImNsaXBQYXRoXCIsIHtcbiAgICBpZDogY2xpcFBhdGhJZFxuICB9LCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInJlY3RcIiwge1xuICAgIHg6IHgsXG4gICAgeTogeSxcbiAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICB3aWR0aDogd2lkdGhcbiAgfSkpKSwgY2hpbGRyZW4pO1xufTtcbmV4cG9ydCB2YXIgdXNlQ2xpcFBhdGhJZCA9ICgpID0+IHtcbiAgcmV0dXJuIHVzZUNvbnRleHQoQ2xpcFBhdGhJZENvbnRleHQpO1xufTsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsb25lRWxlbWVudCwgaXNWYWxpZEVsZW1lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGFwdEV2ZW50SGFuZGxlcnMgfSBmcm9tICcuLi91dGlsL3R5cGVzJztcbmltcG9ydCB7IERvdCB9IGZyb20gJy4uL3NoYXBlL0RvdCc7XG5pbXBvcnQgeyBMYXllciB9IGZyb20gJy4uL2NvbnRhaW5lci9MYXllcic7XG5pbXBvcnQgeyB1c2VBcHBTZWxlY3RvciB9IGZyb20gJy4uL3N0YXRlL2hvb2tzJztcbmltcG9ydCB7IHNlbGVjdEFjdGl2ZVRvb2x0aXBJbmRleCB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy90b29sdGlwU2VsZWN0b3JzJztcbmltcG9ydCB7IHVzZUFjdGl2ZVRvb2x0aXBEYXRhUG9pbnRzIH0gZnJvbSAnLi4vaG9va3MnO1xuaW1wb3J0IHsgaXNOdWxsaXNoIH0gZnJvbSAnLi4vdXRpbC9EYXRhVXRpbHMnO1xuaW1wb3J0IHsgc3ZnUHJvcGVydGllc05vRXZlbnRzRnJvbVVua25vd24gfSBmcm9tICcuLi91dGlsL3N2Z1Byb3BlcnRpZXNOb0V2ZW50cyc7XG52YXIgcmVuZGVyQWN0aXZlUG9pbnQgPSBfcmVmID0+IHtcbiAgdmFyIHtcbiAgICBwb2ludCxcbiAgICBjaGlsZEluZGV4LFxuICAgIG1haW5Db2xvcixcbiAgICBhY3RpdmVEb3QsXG4gICAgZGF0YUtleVxuICB9ID0gX3JlZjtcbiAgaWYgKGFjdGl2ZURvdCA9PT0gZmFsc2UgfHwgcG9pbnQueCA9PSBudWxsIHx8IHBvaW50LnkgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBkb3RQcm9wcyA9IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7XG4gICAgaW5kZXg6IGNoaWxkSW5kZXgsXG4gICAgZGF0YUtleSxcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGFjdGl2ZURvdCBpcyBjb250cmlidXRpbmcgdW5rbm93biBwcm9wc1xuICAgIGN4OiBwb2ludC54LFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgYWN0aXZlRG90IGlzIGNvbnRyaWJ1dGluZyB1bmtub3duIHByb3BzXG4gICAgY3k6IHBvaW50LnksXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBhY3RpdmVEb3QgaXMgY29udHJpYnV0aW5nIHVua25vd24gcHJvcHNcbiAgICByOiA0LFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgYWN0aXZlRG90IGlzIGNvbnRyaWJ1dGluZyB1bmtub3duIHByb3BzXG4gICAgZmlsbDogbWFpbkNvbG9yICE9PSBudWxsICYmIG1haW5Db2xvciAhPT0gdm9pZCAwID8gbWFpbkNvbG9yIDogJ25vbmUnLFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgYWN0aXZlRG90IGlzIGNvbnRyaWJ1dGluZyB1bmtub3duIHByb3BzXG4gICAgc3Ryb2tlV2lkdGg6IDIsXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciBhY3RpdmVEb3QgaXMgY29udHJpYnV0aW5nIHVua25vd24gcHJvcHNcbiAgICBzdHJva2U6ICcjZmZmJyxcbiAgICBwYXlsb2FkOiBwb2ludC5wYXlsb2FkLFxuICAgIHZhbHVlOiBwb2ludC52YWx1ZVxuICB9LCBzdmdQcm9wZXJ0aWVzTm9FdmVudHNGcm9tVW5rbm93bihhY3RpdmVEb3QpKSwgYWRhcHRFdmVudEhhbmRsZXJzKGFjdGl2ZURvdCkpO1xuICB2YXIgZG90O1xuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGFjdGl2ZURvdCkpIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGVsZW1lbnQgY2xvbmluZyBkb2VzIG5vdCBoYXZlIHR5cGVzXG4gICAgZG90ID0gLyojX19QVVJFX18qL2Nsb25lRWxlbWVudChhY3RpdmVEb3QsIGRvdFByb3BzKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgYWN0aXZlRG90ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgZG90ID0gYWN0aXZlRG90KGRvdFByb3BzKTtcbiAgfSBlbHNlIHtcbiAgICBkb3QgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChEb3QsIGRvdFByb3BzKTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGF5ZXIsIHtcbiAgICBjbGFzc05hbWU6IFwicmVjaGFydHMtYWN0aXZlLWRvdFwiXG4gIH0sIGRvdCk7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIEFjdGl2ZVBvaW50cyhfcmVmMikge1xuICB2YXIge1xuICAgIHBvaW50cyxcbiAgICBtYWluQ29sb3IsXG4gICAgYWN0aXZlRG90LFxuICAgIGl0ZW1EYXRhS2V5XG4gIH0gPSBfcmVmMjtcbiAgdmFyIGFjdGl2ZVRvb2x0aXBJbmRleCA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdEFjdGl2ZVRvb2x0aXBJbmRleCk7XG4gIHZhciBhY3RpdmVEYXRhUG9pbnRzID0gdXNlQWN0aXZlVG9vbHRpcERhdGFQb2ludHMoKTtcbiAgaWYgKHBvaW50cyA9PSBudWxsIHx8IGFjdGl2ZURhdGFQb2ludHMgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBhY3RpdmVQb2ludCA9IHBvaW50cy5maW5kKHAgPT4gYWN0aXZlRGF0YVBvaW50cy5pbmNsdWRlcyhwLnBheWxvYWQpKTtcbiAgaWYgKGlzTnVsbGlzaChhY3RpdmVQb2ludCkpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gcmVuZGVyQWN0aXZlUG9pbnQoe1xuICAgIHBvaW50OiBhY3RpdmVQb2ludCxcbiAgICBjaGlsZEluZGV4OiBOdW1iZXIoYWN0aXZlVG9vbHRpcEluZGV4KSxcbiAgICBtYWluQ29sb3IsXG4gICAgZGF0YUtleTogaXRlbURhdGFLZXksXG4gICAgYWN0aXZlRG90XG4gIH0pO1xufSIsInZhciBfZXhjbHVkZWQgPSBbXCJjaGlsZHJlblwiLCBcImNsYXNzTmFtZVwiXTtcbmZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKGUsIHQpIHsgaWYgKG51bGwgPT0gZSkgcmV0dXJuIHt9OyB2YXIgbywgciwgaSA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKGUsIHQpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbiA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IGZvciAociA9IDA7IHIgPCBuLmxlbmd0aDsgcisrKSBvID0gbltyXSwgLTEgPT09IHQuaW5kZXhPZihvKSAmJiB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKGUsIG8pICYmIChpW29dID0gZVtvXSk7IH0gcmV0dXJuIGk7IH1cbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHIsIGUpIHsgaWYgKG51bGwgPT0gcikgcmV0dXJuIHt9OyB2YXIgdCA9IHt9OyBmb3IgKHZhciBuIGluIHIpIGlmICh7fS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHIsIG4pKSB7IGlmICgtMSAhPT0gZS5pbmRleE9mKG4pKSBjb250aW51ZTsgdFtuXSA9IHJbbl07IH0gcmV0dXJuIHQ7IH1cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsc3ggfSBmcm9tICdjbHN4JztcbmltcG9ydCB7IHN2Z1Byb3BlcnRpZXNBbmRFdmVudHMgfSBmcm9tICcuLi91dGlsL3N2Z1Byb3BlcnRpZXNBbmRFdmVudHMnO1xuZXhwb3J0IHZhciBMYXllciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIHZhciB7XG4gICAgICBjaGlsZHJlbixcbiAgICAgIGNsYXNzTmFtZVxuICAgIH0gPSBwcm9wcyxcbiAgICBvdGhlcnMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMocHJvcHMsIF9leGNsdWRlZCk7XG4gIHZhciBsYXllckNsYXNzID0gY2xzeCgncmVjaGFydHMtbGF5ZXInLCBjbGFzc05hbWUpO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJnXCIsIF9leHRlbmRzKHtcbiAgICBjbGFzc05hbWU6IGxheWVyQ2xhc3NcbiAgfSwgc3ZnUHJvcGVydGllc0FuZEV2ZW50cyhvdGhlcnMpLCB7XG4gICAgcmVmOiByZWZcbiAgfSksIGNoaWxkcmVuKTtcbn0pOyIsInZhciBfZXhjbHVkZWQgPSBbXCJsYWJlbFJlZlwiXTtcbmZ1bmN0aW9uIF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhlLCB0KSB7IGlmIChudWxsID09IGUpIHJldHVybiB7fTsgdmFyIG8sIHIsIGkgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShlLCB0KTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG4gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyBmb3IgKHIgPSAwOyByIDwgbi5sZW5ndGg7IHIrKykgbyA9IG5bcl0sIC0xID09PSB0LmluZGV4T2YobykgJiYge30ucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChlLCBvKSAmJiAoaVtvXSA9IGVbb10pOyB9IHJldHVybiBpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShyLCBlKSB7IGlmIChudWxsID09IHIpIHJldHVybiB7fTsgdmFyIHQgPSB7fTsgZm9yICh2YXIgbiBpbiByKSBpZiAoe30uaGFzT3duUHJvcGVydHkuY2FsbChyLCBuKSkgeyBpZiAoLTEgIT09IGUuaW5kZXhPZihuKSkgY29udGludWU7IHRbbl0gPSByW25dOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY2xvbmVFbGVtZW50LCBpc1ZhbGlkRWxlbWVudCwgY3JlYXRlRWxlbWVudCwgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsc3ggfSBmcm9tICdjbHN4JztcbmltcG9ydCB7IFRleHQgfSBmcm9tICcuL1RleHQnO1xuaW1wb3J0IHsgaXNOdW1PclN0ciwgaXNOdW1iZXIsIGlzUGVyY2VudCwgZ2V0UGVyY2VudFZhbHVlLCB1bmlxdWVJZCwgbWF0aFNpZ24sIGlzTnVsbGlzaCB9IGZyb20gJy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IHBvbGFyVG9DYXJ0ZXNpYW4gfSBmcm9tICcuLi91dGlsL1BvbGFyVXRpbHMnO1xuaW1wb3J0IHsgdXNlVmlld0JveCB9IGZyb20gJy4uL2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0JztcbmltcG9ydCB7IHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vc3RhdGUvaG9va3MnO1xuaW1wb3J0IHsgc2VsZWN0UG9sYXJWaWV3Qm94IH0gZnJvbSAnLi4vc3RhdGUvc2VsZWN0b3JzL3BvbGFyQXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyByZXNvbHZlRGVmYXVsdFByb3BzIH0gZnJvbSAnLi4vdXRpbC9yZXNvbHZlRGVmYXVsdFByb3BzJztcbmltcG9ydCB7IHN2Z1Byb3BlcnRpZXNBbmRFdmVudHMgfSBmcm9tICcuLi91dGlsL3N2Z1Byb3BlcnRpZXNBbmRFdmVudHMnO1xudmFyIENhcnRlc2lhbkxhYmVsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KG51bGwpO1xuZXhwb3J0IHZhciBDYXJ0ZXNpYW5MYWJlbENvbnRleHRQcm92aWRlciA9IF9yZWYgPT4ge1xuICB2YXIge1xuICAgIHgsXG4gICAgeSxcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgY2hpbGRyZW5cbiAgfSA9IF9yZWY7XG4gIHZhciB2aWV3Qm94ID0gdXNlTWVtbygoKSA9PiAoe1xuICAgIHgsXG4gICAgeSxcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSksIFt4LCB5LCB3aWR0aCwgaGVpZ2h0XSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChDYXJ0ZXNpYW5MYWJlbENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdmlld0JveFxuICB9LCBjaGlsZHJlbik7XG59O1xudmFyIHVzZUNhcnRlc2lhbkxhYmVsQ29udGV4dCA9ICgpID0+IHtcbiAgdmFyIGxhYmVsQ2hpbGRDb250ZXh0ID0gdXNlQ29udGV4dChDYXJ0ZXNpYW5MYWJlbENvbnRleHQpO1xuICB2YXIgY2hhcnRDb250ZXh0ID0gdXNlVmlld0JveCgpO1xuICByZXR1cm4gbGFiZWxDaGlsZENvbnRleHQgfHwgY2hhcnRDb250ZXh0O1xufTtcbnZhciBQb2xhckxhYmVsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb250ZXh0KG51bGwpO1xuZXhwb3J0IHZhciBQb2xhckxhYmVsQ29udGV4dFByb3ZpZGVyID0gX3JlZjIgPT4ge1xuICB2YXIge1xuICAgIGN4LFxuICAgIGN5LFxuICAgIGlubmVyUmFkaXVzLFxuICAgIG91dGVyUmFkaXVzLFxuICAgIHN0YXJ0QW5nbGUsXG4gICAgZW5kQW5nbGUsXG4gICAgY2xvY2tXaXNlLFxuICAgIGNoaWxkcmVuXG4gIH0gPSBfcmVmMjtcbiAgdmFyIHZpZXdCb3ggPSB1c2VNZW1vKCgpID0+ICh7XG4gICAgY3gsXG4gICAgY3ksXG4gICAgaW5uZXJSYWRpdXMsXG4gICAgb3V0ZXJSYWRpdXMsXG4gICAgc3RhcnRBbmdsZSxcbiAgICBlbmRBbmdsZSxcbiAgICBjbG9ja1dpc2VcbiAgfSksIFtjeCwgY3ksIGlubmVyUmFkaXVzLCBvdXRlclJhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGNsb2NrV2lzZV0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUG9sYXJMYWJlbENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdmlld0JveFxuICB9LCBjaGlsZHJlbik7XG59O1xuZXhwb3J0IHZhciB1c2VQb2xhckxhYmVsQ29udGV4dCA9ICgpID0+IHtcbiAgdmFyIGxhYmVsQ2hpbGRDb250ZXh0ID0gdXNlQ29udGV4dChQb2xhckxhYmVsQ29udGV4dCk7XG4gIHZhciBjaGFydENvbnRleHQgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RQb2xhclZpZXdCb3gpO1xuICByZXR1cm4gbGFiZWxDaGlsZENvbnRleHQgfHwgY2hhcnRDb250ZXh0O1xufTtcbnZhciBnZXRMYWJlbCA9IHByb3BzID0+IHtcbiAgdmFyIHtcbiAgICB2YWx1ZSxcbiAgICBmb3JtYXR0ZXJcbiAgfSA9IHByb3BzO1xuICB2YXIgbGFiZWwgPSBpc051bGxpc2gocHJvcHMuY2hpbGRyZW4pID8gdmFsdWUgOiBwcm9wcy5jaGlsZHJlbjtcbiAgaWYgKHR5cGVvZiBmb3JtYXR0ZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gZm9ybWF0dGVyKGxhYmVsKTtcbiAgfVxuICByZXR1cm4gbGFiZWw7XG59O1xuZXhwb3J0IHZhciBpc0xhYmVsQ29udGVudEFGdW5jdGlvbiA9IGNvbnRlbnQgPT4ge1xuICByZXR1cm4gY29udGVudCAhPSBudWxsICYmIHR5cGVvZiBjb250ZW50ID09PSAnZnVuY3Rpb24nO1xufTtcbnZhciBnZXREZWx0YUFuZ2xlID0gKHN0YXJ0QW5nbGUsIGVuZEFuZ2xlKSA9PiB7XG4gIHZhciBzaWduID0gbWF0aFNpZ24oZW5kQW5nbGUgLSBzdGFydEFuZ2xlKTtcbiAgdmFyIGRlbHRhQW5nbGUgPSBNYXRoLm1pbihNYXRoLmFicyhlbmRBbmdsZSAtIHN0YXJ0QW5nbGUpLCAzNjApO1xuICByZXR1cm4gc2lnbiAqIGRlbHRhQW5nbGU7XG59O1xudmFyIHJlbmRlclJhZGlhbExhYmVsID0gKGxhYmVsUHJvcHMsIHBvc2l0aW9uLCBsYWJlbCwgYXR0cnMsIHZpZXdCb3gpID0+IHtcbiAgdmFyIHtcbiAgICBvZmZzZXQsXG4gICAgY2xhc3NOYW1lXG4gIH0gPSBsYWJlbFByb3BzO1xuICB2YXIge1xuICAgIGN4LFxuICAgIGN5LFxuICAgIGlubmVyUmFkaXVzLFxuICAgIG91dGVyUmFkaXVzLFxuICAgIHN0YXJ0QW5nbGUsXG4gICAgZW5kQW5nbGUsXG4gICAgY2xvY2tXaXNlXG4gIH0gPSB2aWV3Qm94O1xuICB2YXIgcmFkaXVzID0gKGlubmVyUmFkaXVzICsgb3V0ZXJSYWRpdXMpIC8gMjtcbiAgdmFyIGRlbHRhQW5nbGUgPSBnZXREZWx0YUFuZ2xlKHN0YXJ0QW5nbGUsIGVuZEFuZ2xlKTtcbiAgdmFyIHNpZ24gPSBkZWx0YUFuZ2xlID49IDAgPyAxIDogLTE7XG4gIHZhciBsYWJlbEFuZ2xlLCBkaXJlY3Rpb247XG4gIHN3aXRjaCAocG9zaXRpb24pIHtcbiAgICBjYXNlICdpbnNpZGVTdGFydCc6XG4gICAgICBsYWJlbEFuZ2xlID0gc3RhcnRBbmdsZSArIHNpZ24gKiBvZmZzZXQ7XG4gICAgICBkaXJlY3Rpb24gPSBjbG9ja1dpc2U7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdpbnNpZGVFbmQnOlxuICAgICAgbGFiZWxBbmdsZSA9IGVuZEFuZ2xlIC0gc2lnbiAqIG9mZnNldDtcbiAgICAgIGRpcmVjdGlvbiA9ICFjbG9ja1dpc2U7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdlbmQnOlxuICAgICAgbGFiZWxBbmdsZSA9IGVuZEFuZ2xlICsgc2lnbiAqIG9mZnNldDtcbiAgICAgIGRpcmVjdGlvbiA9IGNsb2NrV2lzZTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbnN1cHBvcnRlZCBwb3NpdGlvbiBcIi5jb25jYXQocG9zaXRpb24pKTtcbiAgfVxuICBkaXJlY3Rpb24gPSBkZWx0YUFuZ2xlIDw9IDAgPyBkaXJlY3Rpb24gOiAhZGlyZWN0aW9uO1xuICB2YXIgc3RhcnRQb2ludCA9IHBvbGFyVG9DYXJ0ZXNpYW4oY3gsIGN5LCByYWRpdXMsIGxhYmVsQW5nbGUpO1xuICB2YXIgZW5kUG9pbnQgPSBwb2xhclRvQ2FydGVzaWFuKGN4LCBjeSwgcmFkaXVzLCBsYWJlbEFuZ2xlICsgKGRpcmVjdGlvbiA/IDEgOiAtMSkgKiAzNTkpO1xuICB2YXIgcGF0aCA9IFwiTVwiLmNvbmNhdChzdGFydFBvaW50LngsIFwiLFwiKS5jb25jYXQoc3RhcnRQb2ludC55LCBcIlxcbiAgICBBXCIpLmNvbmNhdChyYWRpdXMsIFwiLFwiKS5jb25jYXQocmFkaXVzLCBcIiwwLDEsXCIpLmNvbmNhdChkaXJlY3Rpb24gPyAwIDogMSwgXCIsXFxuICAgIFwiKS5jb25jYXQoZW5kUG9pbnQueCwgXCIsXCIpLmNvbmNhdChlbmRQb2ludC55KTtcbiAgdmFyIGlkID0gaXNOdWxsaXNoKGxhYmVsUHJvcHMuaWQpID8gdW5pcXVlSWQoJ3JlY2hhcnRzLXJhZGlhbC1saW5lLScpIDogbGFiZWxQcm9wcy5pZDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwidGV4dFwiLCBfZXh0ZW5kcyh7fSwgYXR0cnMsIHtcbiAgICBkb21pbmFudEJhc2VsaW5lOiBcImNlbnRyYWxcIixcbiAgICBjbGFzc05hbWU6IGNsc3goJ3JlY2hhcnRzLXJhZGlhbC1iYXItbGFiZWwnLCBjbGFzc05hbWUpXG4gIH0pLCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcImRlZnNcIiwgbnVsbCwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwYXRoXCIsIHtcbiAgICBpZDogaWQsXG4gICAgZDogcGF0aFxuICB9KSksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwidGV4dFBhdGhcIiwge1xuICAgIHhsaW5rSHJlZjogXCIjXCIuY29uY2F0KGlkKVxuICB9LCBsYWJlbCkpO1xufTtcbnZhciBnZXRBdHRyc09mUG9sYXJMYWJlbCA9ICh2aWV3Qm94LCBvZmZzZXQsIHBvc2l0aW9uKSA9PiB7XG4gIHZhciB7XG4gICAgY3gsXG4gICAgY3ksXG4gICAgaW5uZXJSYWRpdXMsXG4gICAgb3V0ZXJSYWRpdXMsXG4gICAgc3RhcnRBbmdsZSxcbiAgICBlbmRBbmdsZVxuICB9ID0gdmlld0JveDtcbiAgdmFyIG1pZEFuZ2xlID0gKHN0YXJ0QW5nbGUgKyBlbmRBbmdsZSkgLyAyO1xuICBpZiAocG9zaXRpb24gPT09ICdvdXRzaWRlJykge1xuICAgIHZhciB7XG4gICAgICB4OiBfeCxcbiAgICAgIHk6IF95XG4gICAgfSA9IHBvbGFyVG9DYXJ0ZXNpYW4oY3gsIGN5LCBvdXRlclJhZGl1cyArIG9mZnNldCwgbWlkQW5nbGUpO1xuICAgIHJldHVybiB7XG4gICAgICB4OiBfeCxcbiAgICAgIHk6IF95LFxuICAgICAgdGV4dEFuY2hvcjogX3ggPj0gY3ggPyAnc3RhcnQnIDogJ2VuZCcsXG4gICAgICB2ZXJ0aWNhbEFuY2hvcjogJ21pZGRsZSdcbiAgICB9O1xuICB9XG4gIGlmIChwb3NpdGlvbiA9PT0gJ2NlbnRlcicpIHtcbiAgICByZXR1cm4ge1xuICAgICAgeDogY3gsXG4gICAgICB5OiBjeSxcbiAgICAgIHRleHRBbmNob3I6ICdtaWRkbGUnLFxuICAgICAgdmVydGljYWxBbmNob3I6ICdtaWRkbGUnXG4gICAgfTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdjZW50ZXJUb3AnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHg6IGN4LFxuICAgICAgeTogY3ksXG4gICAgICB0ZXh0QW5jaG9yOiAnbWlkZGxlJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnc3RhcnQnXG4gICAgfTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdjZW50ZXJCb3R0b20nKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHg6IGN4LFxuICAgICAgeTogY3ksXG4gICAgICB0ZXh0QW5jaG9yOiAnbWlkZGxlJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnZW5kJ1xuICAgIH07XG4gIH1cbiAgdmFyIHIgPSAoaW5uZXJSYWRpdXMgKyBvdXRlclJhZGl1cykgLyAyO1xuICB2YXIge1xuICAgIHgsXG4gICAgeVxuICB9ID0gcG9sYXJUb0NhcnRlc2lhbihjeCwgY3ksIHIsIG1pZEFuZ2xlKTtcbiAgcmV0dXJuIHtcbiAgICB4LFxuICAgIHksXG4gICAgdGV4dEFuY2hvcjogJ21pZGRsZScsXG4gICAgdmVydGljYWxBbmNob3I6ICdtaWRkbGUnXG4gIH07XG59O1xudmFyIGlzUG9sYXIgPSB2aWV3Qm94ID0+ICdjeCcgaW4gdmlld0JveCAmJiBpc051bWJlcih2aWV3Qm94LmN4KTtcbnZhciBnZXRBdHRyc09mQ2FydGVzaWFuTGFiZWwgPSAocHJvcHMsIHZpZXdCb3gpID0+IHtcbiAgdmFyIHtcbiAgICBwYXJlbnRWaWV3Qm94OiBwYXJlbnRWaWV3Qm94RnJvbVByb3BzLFxuICAgIG9mZnNldCxcbiAgICBwb3NpdGlvblxuICB9ID0gcHJvcHM7XG4gIHZhciBwYXJlbnRWaWV3Qm94O1xuICBpZiAocGFyZW50Vmlld0JveEZyb21Qcm9wcyAhPSBudWxsICYmICFpc1BvbGFyKHBhcmVudFZpZXdCb3hGcm9tUHJvcHMpKSB7XG4gICAgLy8gQ2hlY2sgdGhhdCBub2JvZHkgaXMgdHJ5aW5nIHRvIHBhc3MgYSBwb2xhciB2aWV3Qm94IHRvIGEgY2FydGVzaWFuIGxhYmVsXG4gICAgcGFyZW50Vmlld0JveCA9IHBhcmVudFZpZXdCb3hGcm9tUHJvcHM7XG4gIH1cbiAgdmFyIHtcbiAgICB4LFxuICAgIHksXG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSB2aWV3Qm94O1xuXG4gIC8vIERlZmluZSB2ZXJ0aWNhbCBvZmZzZXRzIGFuZCBwb3NpdGlvbiBpbnZlcnRzIGJhc2VkIG9uIHRoZSB2YWx1ZSBiZWluZyBwb3NpdGl2ZSBvciBuZWdhdGl2ZVxuICB2YXIgdmVydGljYWxTaWduID0gaGVpZ2h0ID49IDAgPyAxIDogLTE7XG4gIHZhciB2ZXJ0aWNhbE9mZnNldCA9IHZlcnRpY2FsU2lnbiAqIG9mZnNldDtcbiAgdmFyIHZlcnRpY2FsRW5kID0gdmVydGljYWxTaWduID4gMCA/ICdlbmQnIDogJ3N0YXJ0JztcbiAgdmFyIHZlcnRpY2FsU3RhcnQgPSB2ZXJ0aWNhbFNpZ24gPiAwID8gJ3N0YXJ0JyA6ICdlbmQnO1xuXG4gIC8vIERlZmluZSBob3Jpem9udGFsIG9mZnNldHMgYW5kIHBvc2l0aW9uIGludmVydHMgYmFzZWQgb24gdGhlIHZhbHVlIGJlaW5nIHBvc2l0aXZlIG9yIG5lZ2F0aXZlXG4gIHZhciBob3Jpem9udGFsU2lnbiA9IHdpZHRoID49IDAgPyAxIDogLTE7XG4gIHZhciBob3Jpem9udGFsT2Zmc2V0ID0gaG9yaXpvbnRhbFNpZ24gKiBvZmZzZXQ7XG4gIHZhciBob3Jpem9udGFsRW5kID0gaG9yaXpvbnRhbFNpZ24gPiAwID8gJ2VuZCcgOiAnc3RhcnQnO1xuICB2YXIgaG9yaXpvbnRhbFN0YXJ0ID0gaG9yaXpvbnRhbFNpZ24gPiAwID8gJ3N0YXJ0JyA6ICdlbmQnO1xuICBpZiAocG9zaXRpb24gPT09ICd0b3AnKSB7XG4gICAgdmFyIGF0dHJzID0ge1xuICAgICAgeDogeCArIHdpZHRoIC8gMixcbiAgICAgIHk6IHkgLSB2ZXJ0aWNhbFNpZ24gKiBvZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiAnbWlkZGxlJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiB2ZXJ0aWNhbEVuZFxuICAgIH07XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYXR0cnMpLCBwYXJlbnRWaWV3Qm94ID8ge1xuICAgICAgaGVpZ2h0OiBNYXRoLm1heCh5IC0gcGFyZW50Vmlld0JveC55LCAwKSxcbiAgICAgIHdpZHRoXG4gICAgfSA6IHt9KTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdib3R0b20nKSB7XG4gICAgdmFyIF9hdHRycyA9IHtcbiAgICAgIHg6IHggKyB3aWR0aCAvIDIsXG4gICAgICB5OiB5ICsgaGVpZ2h0ICsgdmVydGljYWxPZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiAnbWlkZGxlJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiB2ZXJ0aWNhbFN0YXJ0XG4gICAgfTtcbiAgICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBfYXR0cnMpLCBwYXJlbnRWaWV3Qm94ID8ge1xuICAgICAgaGVpZ2h0OiBNYXRoLm1heChwYXJlbnRWaWV3Qm94LnkgKyBwYXJlbnRWaWV3Qm94LmhlaWdodCAtICh5ICsgaGVpZ2h0KSwgMCksXG4gICAgICB3aWR0aFxuICAgIH0gOiB7fSk7XG4gIH1cbiAgaWYgKHBvc2l0aW9uID09PSAnbGVmdCcpIHtcbiAgICB2YXIgX2F0dHJzMiA9IHtcbiAgICAgIHg6IHggLSBob3Jpem9udGFsT2Zmc2V0LFxuICAgICAgeTogeSArIGhlaWdodCAvIDIsXG4gICAgICB0ZXh0QW5jaG9yOiBob3Jpem9udGFsRW5kLFxuICAgICAgdmVydGljYWxBbmNob3I6ICdtaWRkbGUnXG4gICAgfTtcbiAgICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBfYXR0cnMyKSwgcGFyZW50Vmlld0JveCA/IHtcbiAgICAgIHdpZHRoOiBNYXRoLm1heChfYXR0cnMyLnggLSBwYXJlbnRWaWV3Qm94LngsIDApLFxuICAgICAgaGVpZ2h0XG4gICAgfSA6IHt9KTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdyaWdodCcpIHtcbiAgICB2YXIgX2F0dHJzMyA9IHtcbiAgICAgIHg6IHggKyB3aWR0aCArIGhvcml6b250YWxPZmZzZXQsXG4gICAgICB5OiB5ICsgaGVpZ2h0IC8gMixcbiAgICAgIHRleHRBbmNob3I6IGhvcml6b250YWxTdGFydCxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnbWlkZGxlJ1xuICAgIH07XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgX2F0dHJzMyksIHBhcmVudFZpZXdCb3ggPyB7XG4gICAgICB3aWR0aDogTWF0aC5tYXgocGFyZW50Vmlld0JveC54ICsgcGFyZW50Vmlld0JveC53aWR0aCAtIF9hdHRyczMueCwgMCksXG4gICAgICBoZWlnaHRcbiAgICB9IDoge30pO1xuICB9XG4gIHZhciBzaXplQXR0cnMgPSBwYXJlbnRWaWV3Qm94ID8ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodFxuICB9IDoge307XG4gIGlmIChwb3NpdGlvbiA9PT0gJ2luc2lkZUxlZnQnKSB7XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgICAgeDogeCArIGhvcml6b250YWxPZmZzZXQsXG4gICAgICB5OiB5ICsgaGVpZ2h0IC8gMixcbiAgICAgIHRleHRBbmNob3I6IGhvcml6b250YWxTdGFydCxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnbWlkZGxlJ1xuICAgIH0sIHNpemVBdHRycyk7XG4gIH1cbiAgaWYgKHBvc2l0aW9uID09PSAnaW5zaWRlUmlnaHQnKSB7XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgICAgeDogeCArIHdpZHRoIC0gaG9yaXpvbnRhbE9mZnNldCxcbiAgICAgIHk6IHkgKyBoZWlnaHQgLyAyLFxuICAgICAgdGV4dEFuY2hvcjogaG9yaXpvbnRhbEVuZCxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnbWlkZGxlJ1xuICAgIH0sIHNpemVBdHRycyk7XG4gIH1cbiAgaWYgKHBvc2l0aW9uID09PSAnaW5zaWRlVG9wJykge1xuICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKHtcbiAgICAgIHg6IHggKyB3aWR0aCAvIDIsXG4gICAgICB5OiB5ICsgdmVydGljYWxPZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiAnbWlkZGxlJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiB2ZXJ0aWNhbFN0YXJ0XG4gICAgfSwgc2l6ZUF0dHJzKTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdpbnNpZGVCb3R0b20nKSB7XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgICAgeDogeCArIHdpZHRoIC8gMixcbiAgICAgIHk6IHkgKyBoZWlnaHQgLSB2ZXJ0aWNhbE9mZnNldCxcbiAgICAgIHRleHRBbmNob3I6ICdtaWRkbGUnLFxuICAgICAgdmVydGljYWxBbmNob3I6IHZlcnRpY2FsRW5kXG4gICAgfSwgc2l6ZUF0dHJzKTtcbiAgfVxuICBpZiAocG9zaXRpb24gPT09ICdpbnNpZGVUb3BMZWZ0Jykge1xuICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKHtcbiAgICAgIHg6IHggKyBob3Jpem9udGFsT2Zmc2V0LFxuICAgICAgeTogeSArIHZlcnRpY2FsT2Zmc2V0LFxuICAgICAgdGV4dEFuY2hvcjogaG9yaXpvbnRhbFN0YXJ0LFxuICAgICAgdmVydGljYWxBbmNob3I6IHZlcnRpY2FsU3RhcnRcbiAgICB9LCBzaXplQXR0cnMpO1xuICB9XG4gIGlmIChwb3NpdGlvbiA9PT0gJ2luc2lkZVRvcFJpZ2h0Jykge1xuICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKHtcbiAgICAgIHg6IHggKyB3aWR0aCAtIGhvcml6b250YWxPZmZzZXQsXG4gICAgICB5OiB5ICsgdmVydGljYWxPZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiBob3Jpem9udGFsRW5kLFxuICAgICAgdmVydGljYWxBbmNob3I6IHZlcnRpY2FsU3RhcnRcbiAgICB9LCBzaXplQXR0cnMpO1xuICB9XG4gIGlmIChwb3NpdGlvbiA9PT0gJ2luc2lkZUJvdHRvbUxlZnQnKSB7XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgICAgeDogeCArIGhvcml6b250YWxPZmZzZXQsXG4gICAgICB5OiB5ICsgaGVpZ2h0IC0gdmVydGljYWxPZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiBob3Jpem9udGFsU3RhcnQsXG4gICAgICB2ZXJ0aWNhbEFuY2hvcjogdmVydGljYWxFbmRcbiAgICB9LCBzaXplQXR0cnMpO1xuICB9XG4gIGlmIChwb3NpdGlvbiA9PT0gJ2luc2lkZUJvdHRvbVJpZ2h0Jykge1xuICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKHtcbiAgICAgIHg6IHggKyB3aWR0aCAtIGhvcml6b250YWxPZmZzZXQsXG4gICAgICB5OiB5ICsgaGVpZ2h0IC0gdmVydGljYWxPZmZzZXQsXG4gICAgICB0ZXh0QW5jaG9yOiBob3Jpem9udGFsRW5kLFxuICAgICAgdmVydGljYWxBbmNob3I6IHZlcnRpY2FsRW5kXG4gICAgfSwgc2l6ZUF0dHJzKTtcbiAgfVxuICBpZiAoISFwb3NpdGlvbiAmJiB0eXBlb2YgcG9zaXRpb24gPT09ICdvYmplY3QnICYmIChpc051bWJlcihwb3NpdGlvbi54KSB8fCBpc1BlcmNlbnQocG9zaXRpb24ueCkpICYmIChpc051bWJlcihwb3NpdGlvbi55KSB8fCBpc1BlcmNlbnQocG9zaXRpb24ueSkpKSB7XG4gICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgICAgeDogeCArIGdldFBlcmNlbnRWYWx1ZShwb3NpdGlvbi54LCB3aWR0aCksXG4gICAgICB5OiB5ICsgZ2V0UGVyY2VudFZhbHVlKHBvc2l0aW9uLnksIGhlaWdodCksXG4gICAgICB0ZXh0QW5jaG9yOiAnZW5kJyxcbiAgICAgIHZlcnRpY2FsQW5jaG9yOiAnZW5kJ1xuICAgIH0sIHNpemVBdHRycyk7XG4gIH1cbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoe1xuICAgIHg6IHggKyB3aWR0aCAvIDIsXG4gICAgeTogeSArIGhlaWdodCAvIDIsXG4gICAgdGV4dEFuY2hvcjogJ21pZGRsZScsXG4gICAgdmVydGljYWxBbmNob3I6ICdtaWRkbGUnXG4gIH0sIHNpemVBdHRycyk7XG59O1xudmFyIGRlZmF1bHRMYWJlbFByb3BzID0ge1xuICBvZmZzZXQ6IDVcbn07XG5leHBvcnQgZnVuY3Rpb24gTGFiZWwob3V0ZXJQcm9wcykge1xuICB2YXIgcHJvcHMgPSByZXNvbHZlRGVmYXVsdFByb3BzKG91dGVyUHJvcHMsIGRlZmF1bHRMYWJlbFByb3BzKTtcbiAgdmFyIHtcbiAgICB2aWV3Qm94OiB2aWV3Qm94RnJvbVByb3BzLFxuICAgIHBvc2l0aW9uLFxuICAgIHZhbHVlLFxuICAgIGNoaWxkcmVuLFxuICAgIGNvbnRlbnQsXG4gICAgY2xhc3NOYW1lID0gJycsXG4gICAgdGV4dEJyZWFrQWxsLFxuICAgIGxhYmVsUmVmXG4gIH0gPSBwcm9wcztcbiAgdmFyIHBvbGFyVmlld0JveCA9IHVzZVBvbGFyTGFiZWxDb250ZXh0KCk7XG4gIHZhciBjYXJ0ZXNpYW5WaWV3Qm94ID0gdXNlQ2FydGVzaWFuTGFiZWxDb250ZXh0KCk7XG5cbiAgLypcbiAgICogSSBhbSBub3QgcHJvdWQgYWJvdXQgdGhpcyBzb2x1dGlvbiwgYnV0IGl0J3MgYSBxdWljayBmaXggZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWNoYXJ0cy9yZWNoYXJ0cy9pc3N1ZXMvNjAzMCNpc3N1ZWNvbW1lbnQtMzE1NTM1MjQ2MC5cbiAgICogV2hhdCB3ZSBzaG91bGQgcmVhbGx5IGRvIGlzIHNwbGl0IExhYmVsIGludG8gdHdvIGNvbXBvbmVudHM6IENhcnRlc2lhbkxhYmVsIGFuZCBQb2xhckxhYmVsIGFuZCB0aGVuIGhhbmRsZSB0aGVpciByZXNwZWN0aXZlIHZpZXdCb3hlcyBzZXBhcmF0ZWx5LlxuICAgKiBBbHNvIG90aGVyIGNvbXBvbmVudHMgc2hvdWxkIHNldCBpdHMgb3duIHZpZXdCb3ggaW4gYSBjb250ZXh0IHNvIHRoYXQgd2UgY2FuIGZpeCBodHRwczovL2dpdGh1Yi5jb20vcmVjaGFydHMvcmVjaGFydHMvaXNzdWVzLzYxNTZcbiAgICovXG4gIHZhciByZXNvbHZlZFZpZXdCb3ggPSBwb3NpdGlvbiA9PT0gJ2NlbnRlcicgPyBjYXJ0ZXNpYW5WaWV3Qm94IDogcG9sYXJWaWV3Qm94ICE9PSBudWxsICYmIHBvbGFyVmlld0JveCAhPT0gdm9pZCAwID8gcG9sYXJWaWV3Qm94IDogY2FydGVzaWFuVmlld0JveDtcbiAgdmFyIHZpZXdCb3ggPSB2aWV3Qm94RnJvbVByb3BzIHx8IHJlc29sdmVkVmlld0JveDtcbiAgaWYgKCF2aWV3Qm94IHx8IGlzTnVsbGlzaCh2YWx1ZSkgJiYgaXNOdWxsaXNoKGNoaWxkcmVuKSAmJiAhIC8qI19fUFVSRV9fKi9pc1ZhbGlkRWxlbWVudChjb250ZW50KSAmJiB0eXBlb2YgY29udGVudCAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBwcm9wc1dpdGhWaWV3Qm94ID0gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBwcm9wcyksIHt9LCB7XG4gICAgdmlld0JveFxuICB9KTtcbiAgaWYgKC8qI19fUFVSRV9fKi9pc1ZhbGlkRWxlbWVudChjb250ZW50KSkge1xuICAgIHZhciB7XG4gICAgICAgIGxhYmVsUmVmOiBfXG4gICAgICB9ID0gcHJvcHNXaXRoVmlld0JveCxcbiAgICAgIHByb3BzV2l0aG91dExhYmVsUmVmID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKHByb3BzV2l0aFZpZXdCb3gsIF9leGNsdWRlZCk7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9jbG9uZUVsZW1lbnQoY29udGVudCwgcHJvcHNXaXRob3V0TGFiZWxSZWYpO1xuICB9XG4gIHZhciBsYWJlbDtcbiAgaWYgKHR5cGVvZiBjb250ZW50ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgbGFiZWwgPSAvKiNfX1BVUkVfXyovY3JlYXRlRWxlbWVudChjb250ZW50LCBwcm9wc1dpdGhWaWV3Qm94KTtcbiAgICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGxhYmVsKSkge1xuICAgICAgcmV0dXJuIGxhYmVsO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBsYWJlbCA9IGdldExhYmVsKHByb3BzKTtcbiAgfVxuICB2YXIgaXNQb2xhckxhYmVsID0gaXNQb2xhcih2aWV3Qm94KTtcbiAgdmFyIGF0dHJzID0gc3ZnUHJvcGVydGllc0FuZEV2ZW50cyhwcm9wcyk7XG4gIGlmIChpc1BvbGFyTGFiZWwgJiYgKHBvc2l0aW9uID09PSAnaW5zaWRlU3RhcnQnIHx8IHBvc2l0aW9uID09PSAnaW5zaWRlRW5kJyB8fCBwb3NpdGlvbiA9PT0gJ2VuZCcpKSB7XG4gICAgcmV0dXJuIHJlbmRlclJhZGlhbExhYmVsKHByb3BzLCBwb3NpdGlvbiwgbGFiZWwsIGF0dHJzLCB2aWV3Qm94KTtcbiAgfVxuICB2YXIgcG9zaXRpb25BdHRycyA9IGlzUG9sYXJMYWJlbCA/IGdldEF0dHJzT2ZQb2xhckxhYmVsKHZpZXdCb3gsIHByb3BzLm9mZnNldCwgcHJvcHMucG9zaXRpb24pIDogZ2V0QXR0cnNPZkNhcnRlc2lhbkxhYmVsKHByb3BzLCB2aWV3Qm94KTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFRleHQsIF9leHRlbmRzKHtcbiAgICByZWY6IGxhYmVsUmVmLFxuICAgIGNsYXNzTmFtZTogY2xzeCgncmVjaGFydHMtbGFiZWwnLCBjbGFzc05hbWUpXG4gIH0sIGF0dHJzLCBwb3NpdGlvbkF0dHJzLCB7XG4gICAgYnJlYWtBbGw6IHRleHRCcmVha0FsbFxuICB9KSwgbGFiZWwpO1xufVxuTGFiZWwuZGlzcGxheU5hbWUgPSAnTGFiZWwnO1xudmFyIHBhcnNlTGFiZWwgPSAobGFiZWwsIHZpZXdCb3gsIGxhYmVsUmVmKSA9PiB7XG4gIGlmICghbGFiZWwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgY29tbW9uUHJvcHMgPSB7XG4gICAgdmlld0JveCxcbiAgICBsYWJlbFJlZlxuICB9O1xuICBpZiAobGFiZWwgPT09IHRydWUpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIF9leHRlbmRzKHtcbiAgICAgIGtleTogXCJsYWJlbC1pbXBsaWNpdFwiXG4gICAgfSwgY29tbW9uUHJvcHMpKTtcbiAgfVxuICBpZiAoaXNOdW1PclN0cihsYWJlbCkpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIF9leHRlbmRzKHtcbiAgICAgIGtleTogXCJsYWJlbC1pbXBsaWNpdFwiLFxuICAgICAgdmFsdWU6IGxhYmVsXG4gICAgfSwgY29tbW9uUHJvcHMpKTtcbiAgfVxuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGxhYmVsKSkge1xuICAgIGlmIChsYWJlbC50eXBlID09PSBMYWJlbCkge1xuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9jbG9uZUVsZW1lbnQobGFiZWwsIF9vYmplY3RTcHJlYWQoe1xuICAgICAgICBrZXk6ICdsYWJlbC1pbXBsaWNpdCdcbiAgICAgIH0sIGNvbW1vblByb3BzKSk7XG4gICAgfVxuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwgX2V4dGVuZHMoe1xuICAgICAga2V5OiBcImxhYmVsLWltcGxpY2l0XCIsXG4gICAgICBjb250ZW50OiBsYWJlbFxuICAgIH0sIGNvbW1vblByb3BzKSk7XG4gIH1cbiAgaWYgKGlzTGFiZWxDb250ZW50QUZ1bmN0aW9uKGxhYmVsKSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYWJlbCwgX2V4dGVuZHMoe1xuICAgICAga2V5OiBcImxhYmVsLWltcGxpY2l0XCIsXG4gICAgICBjb250ZW50OiBsYWJlbFxuICAgIH0sIGNvbW1vblByb3BzKSk7XG4gIH1cbiAgaWYgKGxhYmVsICYmIHR5cGVvZiBsYWJlbCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTGFiZWwsIF9leHRlbmRzKHt9LCBsYWJlbCwge1xuICAgICAga2V5OiBcImxhYmVsLWltcGxpY2l0XCJcbiAgICB9LCBjb21tb25Qcm9wcykpO1xuICB9XG4gIHJldHVybiBudWxsO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBDYXJ0ZXNpYW5MYWJlbEZyb21MYWJlbFByb3AoX3JlZjMpIHtcbiAgdmFyIHtcbiAgICBsYWJlbCxcbiAgICBsYWJlbFJlZlxuICB9ID0gX3JlZjM7XG4gIHZhciB2aWV3Qm94ID0gdXNlQ2FydGVzaWFuTGFiZWxDb250ZXh0KCk7XG4gIHJldHVybiBwYXJzZUxhYmVsKGxhYmVsLCB2aWV3Qm94LCBsYWJlbFJlZikgfHwgbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBQb2xhckxhYmVsRnJvbUxhYmVsUHJvcChfcmVmNCkge1xuICB2YXIge1xuICAgIGxhYmVsXG4gIH0gPSBfcmVmNDtcbiAgdmFyIHZpZXdCb3ggPSB1c2VQb2xhckxhYmVsQ29udGV4dCgpO1xuICByZXR1cm4gcGFyc2VMYWJlbChsYWJlbCwgdmlld0JveCkgfHwgbnVsbDtcbn0iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=