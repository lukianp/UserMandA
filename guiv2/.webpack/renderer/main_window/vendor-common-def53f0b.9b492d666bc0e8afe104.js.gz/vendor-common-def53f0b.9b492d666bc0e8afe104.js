"use strict";
(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[6185],{

/***/ 5511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  dG: () => (/* binding */ getNiceTickValues),
  M8: () => (/* binding */ getTickValuesFixedDomain)
});

// UNUSED EXPORTS: calculateStep, getFormatStep, getTickOfSingleValue, getValidInterval

// EXTERNAL MODULE: ./node_modules/decimal.js-light/decimal.js
var decimal = __webpack_require__(38351);
var decimal_default = /*#__PURE__*/__webpack_require__.n(decimal);
;// ./node_modules/recharts/es6/util/scale/util/utils.js
var identity = i => i;
var PLACE_HOLDER = {
  '@@functional/placeholder': true
};
var isPlaceHolder = val => val === PLACE_HOLDER;
var curry0 = fn => function _curried() {
  if (arguments.length === 0 || arguments.length === 1 && isPlaceHolder(arguments.length <= 0 ? undefined : arguments[0])) {
    return _curried;
  }
  return fn(...arguments);
};
var curryN = (n, fn) => {
  if (n === 1) {
    return fn;
  }
  return curry0(function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var argsLength = args.filter(arg => arg !== PLACE_HOLDER).length;
    if (argsLength >= n) {
      return fn(...args);
    }
    return curryN(n - argsLength, curry0(function () {
      for (var _len2 = arguments.length, restArgs = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        restArgs[_key2] = arguments[_key2];
      }
      var newArgs = args.map(arg => isPlaceHolder(arg) ? restArgs.shift() : arg);
      return fn(...newArgs, ...restArgs);
    }));
  });
};
var curry = fn => curryN(fn.length, fn);
var range = (begin, end) => {
  var arr = [];
  for (var i = begin; i < end; ++i) {
    arr[i - begin] = i;
  }
  return arr;
};
var map = curry((fn, arr) => {
  if (Array.isArray(arr)) {
    return arr.map(fn);
  }
  return Object.keys(arr).map(key => arr[key]).map(fn);
});
var compose = function compose() {
  for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }
  if (!args.length) {
    return identity;
  }
  var fns = args.reverse();
  // first function can receive multiply arguments
  var firstFn = fns[0];
  var tailsFn = fns.slice(1);
  return function () {
    return tailsFn.reduce((res, fn) => fn(res), firstFn(...arguments));
  };
};
var reverse = arr => {
  if (Array.isArray(arr)) {
    return arr.reverse();
  }

  // can be string
  return arr.split('').reverse().join('');
};
var memoize = fn => {
  var lastArgs = null;
  var lastResult = null;
  return function () {
    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      args[_key4] = arguments[_key4];
    }
    if (lastArgs && args.every((val, i) => {
      var _lastArgs;
      return val === ((_lastArgs = lastArgs) === null || _lastArgs === void 0 ? void 0 : _lastArgs[i]);
    })) {
      return lastResult;
    }
    lastArgs = args;
    lastResult = fn(...args);
    return lastResult;
  };
};
;// ./node_modules/recharts/es6/util/scale/util/arithmetic.js
/**
 * @fileOverview Some common arithmetic methods
 * @author xile611
 * @date 2015-09-17
 */



/**
 * Get the digit count of a number.
 * If the absolute value is in the interval [0.1, 1), the result is 0.
 * If the absolute value is in the interval [0.01, 0.1), the digit count is -1.
 * If the absolute value is in the interval [0.001, 0.01), the digit count is -2.
 *
 * @param  {Number} value The number
 * @return {Integer}      Digit count
 */
function getDigitCount(value) {
  var result;
  if (value === 0) {
    result = 1;
  } else {
    result = Math.floor(new (decimal_default())(value).abs().log(10).toNumber()) + 1;
  }
  return result;
}

/**
 * Get the data in the interval [start, end) with a fixed step.
 * Also handles JS calculation precision issues.
 *
 * @param  {Decimal} start Start point
 * @param  {Decimal} end   End point, not included
 * @param  {Decimal} step  Step size
 * @return {Array}         Array of numbers
 */
function rangeStep(start, end, step) {
  var num = new (decimal_default())(start);
  var i = 0;
  var result = [];

  // magic number to prevent infinite loop
  while (num.lt(end) && i < 100000) {
    result.push(num.toNumber());
    num = num.add(step);
    i++;
  }
  return result;
}

/**
 * Linear interpolation of numbers.
 *
 * @param  {Number} a  Endpoint of the domain
 * @param  {Number} b  Endpoint of the domain
 * @param  {Number} t  A value in [0, 1]
 * @return {Number}    A value in the domain
 */
var interpolateNumber = curry((a, b, t) => {
  var newA = +a;
  var newB = +b;
  return newA + t * (newB - newA);
});

/**
 * Inverse operation of linear interpolation.
 *
 * @param  {Number} a Endpoint of the domain
 * @param  {Number} b Endpoint of the domain
 * @param  {Number} x Can be considered as an output value after interpolation
 * @return {Number}   When x is in the range a ~ b, the return value is in [0, 1]
 */
var uninterpolateNumber = curry((a, b, x) => {
  var diff = b - +a;
  diff = diff || Infinity;
  return (x - a) / diff;
});

/**
 * Inverse operation of linear interpolation with truncation.
 *
 * @param  {Number} a Endpoint of the domain
 * @param  {Number} b Endpoint of the domain
 * @param  {Number} x Can be considered as an output value after interpolation
 * @return {Number}   When x is in the interval a ~ b, the return value is in [0, 1].
 *                    When x is not in the interval a ~ b, it will be truncated to the interval a ~ b.
 */
var uninterpolateTruncation = curry((a, b, x) => {
  var diff = b - +a;
  diff = diff || Infinity;
  return Math.max(0, Math.min(1, (x - a) / diff));
});

;// ./node_modules/recharts/es6/util/scale/getNiceTickValues.js
/**
 * @fileOverview calculate tick values of scale
 * @author xile611, arcthur
 * @date 2015-09-17
 */



/**
 * Calculate a interval of a minimum value and a maximum value
 *
 * @param  {Number} min       The minimum value
 * @param  {Number} max       The maximum value
 * @return {Array} An interval
 */
var getValidInterval = _ref => {
  var [min, max] = _ref;
  var [validMin, validMax] = [min, max];

  // exchange
  if (min > max) {
    [validMin, validMax] = [max, min];
  }
  return [validMin, validMax];
};

/**
 * Calculate the step which is easy to understand between ticks, like 10, 20, 25
 *
 * @param  roughStep        The rough step calculated by dividing the difference by the tickCount
 * @param  allowDecimals    Allow the ticks to be decimals or not
 * @param  correctionFactor A correction factor
 * @return The step which is easy to understand between two ticks
 */
var getFormatStep = (roughStep, allowDecimals, correctionFactor) => {
  if (roughStep.lte(0)) {
    return new (decimal_default())(0);
  }
  var digitCount = getDigitCount(roughStep.toNumber());
  // The ratio between the rough step and the smallest number which has a bigger
  // order of magnitudes than the rough step
  var digitCountValue = new (decimal_default())(10).pow(digitCount);
  var stepRatio = roughStep.div(digitCountValue);
  // When an integer and a float multiplied, the accuracy of result may be wrong
  var stepRatioScale = digitCount !== 1 ? 0.05 : 0.1;
  var amendStepRatio = new (decimal_default())(Math.ceil(stepRatio.div(stepRatioScale).toNumber())).add(correctionFactor).mul(stepRatioScale);
  var formatStep = amendStepRatio.mul(digitCountValue);
  return allowDecimals ? new (decimal_default())(formatStep.toNumber()) : new (decimal_default())(Math.ceil(formatStep.toNumber()));
};

/**
 * calculate the ticks when the minimum value equals to the maximum value
 *
 * @param  value         The minimum value which is also the maximum value
 * @param  tickCount     The count of ticks
 * @param  allowDecimals Allow the ticks to be decimals or not
 * @return array of ticks
 */
var getTickOfSingleValue = (value, tickCount, allowDecimals) => {
  var step = new (decimal_default())(1);
  // calculate the middle value of ticks
  var middle = new (decimal_default())(value);
  if (!middle.isint() && allowDecimals) {
    var absVal = Math.abs(value);
    if (absVal < 1) {
      // The step should be a float number when the difference is smaller than 1
      step = new (decimal_default())(10).pow(getDigitCount(value) - 1);
      middle = new (decimal_default())(Math.floor(middle.div(step).toNumber())).mul(step);
    } else if (absVal > 1) {
      // Return the maximum integer which is smaller than 'value' when 'value' is greater than 1
      middle = new (decimal_default())(Math.floor(value));
    }
  } else if (value === 0) {
    middle = new (decimal_default())(Math.floor((tickCount - 1) / 2));
  } else if (!allowDecimals) {
    middle = new (decimal_default())(Math.floor(value));
  }
  var middleIndex = Math.floor((tickCount - 1) / 2);
  var fn = compose(map(n => middle.add(new (decimal_default())(n - middleIndex).mul(step)).toNumber()), range);
  return fn(0, tickCount);
};

/**
 * Calculate the step
 *
 * @param  min              The minimum value of an interval
 * @param  max              The maximum value of an interval
 * @param  tickCount        The count of ticks
 * @param  allowDecimals    Allow the ticks to be decimals or not
 * @param  correctionFactor A correction factor
 * @return The step, minimum value of ticks, maximum value of ticks
 */
var _calculateStep = function calculateStep(min, max, tickCount, allowDecimals) {
  var correctionFactor = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
  // dirty hack (for recharts' test)
  if (!Number.isFinite((max - min) / (tickCount - 1))) {
    return {
      step: new (decimal_default())(0),
      tickMin: new (decimal_default())(0),
      tickMax: new (decimal_default())(0)
    };
  }

  // The step which is easy to understand between two ticks
  var step = getFormatStep(new (decimal_default())(max).sub(min).div(tickCount - 1), allowDecimals, correctionFactor);

  // A medial value of ticks
  var middle;

  // When 0 is inside the interval, 0 should be a tick
  if (min <= 0 && max >= 0) {
    middle = new (decimal_default())(0);
  } else {
    // calculate the middle value
    middle = new (decimal_default())(min).add(max).div(2);
    // minus modulo value
    middle = middle.sub(new (decimal_default())(middle).mod(step));
  }
  var belowCount = Math.ceil(middle.sub(min).div(step).toNumber());
  var upCount = Math.ceil(new (decimal_default())(max).sub(middle).div(step).toNumber());
  var scaleCount = belowCount + upCount + 1;
  if (scaleCount > tickCount) {
    // When more ticks need to cover the interval, step should be bigger.
    return _calculateStep(min, max, tickCount, allowDecimals, correctionFactor + 1);
  }
  if (scaleCount < tickCount) {
    // When less ticks can cover the interval, we should add some additional ticks
    upCount = max > 0 ? upCount + (tickCount - scaleCount) : upCount;
    belowCount = max > 0 ? belowCount : belowCount + (tickCount - scaleCount);
  }
  return {
    step,
    tickMin: middle.sub(new (decimal_default())(belowCount).mul(step)),
    tickMax: middle.add(new (decimal_default())(upCount).mul(step))
  };
};

/**
 * Calculate the ticks of an interval. Ticks can appear outside the interval
 * if it makes them more rounded and nice.
 *
 * @param tuple of [min,max] min: The minimum value, max: The maximum value
 * @param tickCount     The count of ticks
 * @param allowDecimals Allow the ticks to be decimals or not
 * @return array of ticks
 */

function getNiceTickValuesFn(_ref2) {
  var [min, max] = _ref2;
  var tickCount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 6;
  var allowDecimals = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  // More than two ticks should be return
  var count = Math.max(tickCount, 2);
  var [cormin, cormax] = getValidInterval([min, max]);
  if (cormin === -Infinity || cormax === Infinity) {
    var _values = cormax === Infinity ? [cormin, ...range(0, tickCount - 1).map(() => Infinity)] : [...range(0, tickCount - 1).map(() => -Infinity), cormax];
    return min > max ? reverse(_values) : _values;
  }
  if (cormin === cormax) {
    return getTickOfSingleValue(cormin, tickCount, allowDecimals);
  }

  // Get the step between two ticks
  var {
    step,
    tickMin,
    tickMax
  } = _calculateStep(cormin, cormax, count, allowDecimals, 0);
  var values = rangeStep(tickMin, tickMax.add(new (decimal_default())(0.1).mul(step)), step);
  return min > max ? reverse(values) : values;
}

/**
 * Calculate the ticks of an interval.
 * Ticks will be constrained to the interval [min, max] even if it makes them less rounded and nice.
 *
 * @param tuple of [min,max] min: The minimum value, max: The maximum value
 * @param tickCount     The count of ticks. This function may return less than tickCount ticks if the interval is too small.
 * @param allowDecimals Allow the ticks to be decimals or not
 * @return array of ticks
 */
function getTickValuesFixedDomainFn(_ref3, tickCount) {
  var [min, max] = _ref3;
  var allowDecimals = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  // More than two ticks should be return
  var [cormin, cormax] = getValidInterval([min, max]);
  if (cormin === -Infinity || cormax === Infinity) {
    return [min, max];
  }
  if (cormin === cormax) {
    return [cormin];
  }
  var count = Math.max(tickCount, 2);
  var step = getFormatStep(new (decimal_default())(cormax).sub(cormin).div(count - 1), allowDecimals, 0);
  var values = [...rangeStep(new (decimal_default())(cormin), new (decimal_default())(cormax), step), cormax];
  if (allowDecimals === false) {
    /*
     * allowDecimals is false means that we want to have integer ticks.
     * The step is guaranteed to be an integer in the code above which is great start
     * but when the first step is not an integer, it will start stepping from a decimal value anyway.
     * So we need to round all the values to integers after the fact.
     */
    values = values.map(value => Math.round(value));
  }
  return min > max ? reverse(values) : values;
}
var getNiceTickValues = memoize(getNiceTickValuesFn);
var getTickValuesFixedDomain = memoize(getTickValuesFixedDomainFn);

/***/ }),

/***/ 8107:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   n: () => (/* binding */ useAnimationId)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _DataUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59744);



/**
 * This hook returns a unique animation id for the object input.
 * If input changes (as in, reference equality is different), the animation id will change.
 * If input does not change, the animation id will not change.
 *
 * This is useful for animations. The Animate component
 * does have a `shouldReAnimate` prop but that doesn't seem to be doing what the name implies.
 * Also, we don't always want to re-animate on every render;
 * we only want to re-animate when the input changes. Not the internal state (e.g. `isAnimating`).
 *
 * @param input The object to check for changes. Uses reference equality (=== operator)
 * @param prefix Optional prefix to use for the animation id
 * @returns A unique animation id
 */
function useAnimationId(input) {
  var prefix = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'animation-';
  var animationId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)((0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .uniqueId */ .NF)(prefix));
  var prevProps = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(input);
  if (prevProps.current !== input) {
    animationId.current = (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .uniqueId */ .NF)(prefix);
    prevProps.current = input;
  }
  return animationId.current;
}

/***/ }),

/***/ 8292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* reexport safe */ _getNiceTickValues__WEBPACK_IMPORTED_MODULE_0__.M8),
/* harmony export */   d: () => (/* reexport safe */ _getNiceTickValues__WEBPACK_IMPORTED_MODULE_0__.dG)
/* harmony export */ });
/* harmony import */ var _getNiceTickValues__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5511);


/***/ }),

/***/ 8813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ isPositiveNumber),
/* harmony export */   H: () => (/* binding */ isWellBehavedNumber)
/* harmony export */ });
function isWellBehavedNumber(n) {
  return Number.isFinite(n);
}
function isPositiveNumber(n) {
  return typeof n === 'number' && n > 0 && Number.isFinite(n);
}

/***/ }),

/***/ 41571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   eK: () => (/* binding */ getTooltipTranslate)
/* harmony export */ });
/* unused harmony exports getTooltipCSSClassName, getTooltipTranslateXY, getTransformStyle */
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(34164);
/* harmony import */ var _DataUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59744);


var CSS_CLASS_PREFIX = 'recharts-tooltip-wrapper';
var TOOLTIP_HIDDEN = {
  visibility: 'hidden'
};
function getTooltipCSSClassName(_ref) {
  var {
    coordinate,
    translateX,
    translateY
  } = _ref;
  return (0,clsx__WEBPACK_IMPORTED_MODULE_0__/* .clsx */ .$)(CSS_CLASS_PREFIX, {
    ["".concat(CSS_CLASS_PREFIX, "-right")]: (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(translateX) && coordinate && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(coordinate.x) && translateX >= coordinate.x,
    ["".concat(CSS_CLASS_PREFIX, "-left")]: (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(translateX) && coordinate && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(coordinate.x) && translateX < coordinate.x,
    ["".concat(CSS_CLASS_PREFIX, "-bottom")]: (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(translateY) && coordinate && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(coordinate.y) && translateY >= coordinate.y,
    ["".concat(CSS_CLASS_PREFIX, "-top")]: (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(translateY) && coordinate && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(coordinate.y) && translateY < coordinate.y
  });
}
function getTooltipTranslateXY(_ref2) {
  var {
    allowEscapeViewBox,
    coordinate,
    key,
    offsetTopLeft,
    position,
    reverseDirection,
    tooltipDimension,
    viewBox,
    viewBoxDimension
  } = _ref2;
  if (position && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(position[key])) {
    return position[key];
  }
  var negative = coordinate[key] - tooltipDimension - (offsetTopLeft > 0 ? offsetTopLeft : 0);
  var positive = coordinate[key] + offsetTopLeft;
  if (allowEscapeViewBox[key]) {
    return reverseDirection[key] ? negative : positive;
  }
  var viewBoxKey = viewBox[key];
  if (viewBoxKey == null) {
    return 0;
  }
  if (reverseDirection[key]) {
    var _tooltipBoundary = negative;
    var _viewBoxBoundary = viewBoxKey;
    if (_tooltipBoundary < _viewBoxBoundary) {
      return Math.max(positive, viewBoxKey);
    }
    return Math.max(negative, viewBoxKey);
  }
  if (viewBoxDimension == null) {
    return 0;
  }
  var tooltipBoundary = positive + tooltipDimension;
  var viewBoxBoundary = viewBoxKey + viewBoxDimension;
  if (tooltipBoundary > viewBoxBoundary) {
    return Math.max(negative, viewBoxKey);
  }
  return Math.max(positive, viewBoxKey);
}
function getTransformStyle(_ref3) {
  var {
    translateX,
    translateY,
    useTranslate3d
  } = _ref3;
  return {
    transform: useTranslate3d ? "translate3d(".concat(translateX, "px, ").concat(translateY, "px, 0)") : "translate(".concat(translateX, "px, ").concat(translateY, "px)")
  };
}
function getTooltipTranslate(_ref4) {
  var {
    allowEscapeViewBox,
    coordinate,
    offsetTopLeft,
    position,
    reverseDirection,
    tooltipBox,
    useTranslate3d,
    viewBox
  } = _ref4;
  var cssProperties, translateX, translateY;
  if (tooltipBox.height > 0 && tooltipBox.width > 0 && coordinate) {
    translateX = getTooltipTranslateXY({
      allowEscapeViewBox,
      coordinate,
      key: 'x',
      offsetTopLeft,
      position,
      reverseDirection,
      tooltipDimension: tooltipBox.width,
      viewBox,
      viewBoxDimension: viewBox.width
    });
    translateY = getTooltipTranslateXY({
      allowEscapeViewBox,
      coordinate,
      key: 'y',
      offsetTopLeft,
      position,
      reverseDirection,
      tooltipDimension: tooltipBox.height,
      viewBox,
      viewBoxDimension: viewBox.height
    });
    cssProperties = getTransformStyle({
      translateX,
      translateY,
      useTranslate3d
    });
  } else {
    cssProperties = TOOLTIP_HIDDEN;
  }
  return {
    cssProperties,
    cssClasses: getTooltipCSSClassName({
      translateX,
      translateY,
      coordinate
    })
  };
}

/***/ }),

/***/ 55448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Rw: () => (/* binding */ isSvgElementPropKey),
/* harmony export */   Xc: () => (/* binding */ isDataAttribute),
/* harmony export */   ic: () => (/* binding */ svgPropertiesNoEventsFromUnknown),
/* harmony export */   uZ: () => (/* binding */ svgPropertiesNoEvents)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);

var SVGElementPropKeys = ['aria-activedescendant', 'aria-atomic', 'aria-autocomplete', 'aria-busy', 'aria-checked', 'aria-colcount', 'aria-colindex', 'aria-colspan', 'aria-controls', 'aria-current', 'aria-describedby', 'aria-details', 'aria-disabled', 'aria-errormessage', 'aria-expanded', 'aria-flowto', 'aria-haspopup', 'aria-hidden', 'aria-invalid', 'aria-keyshortcuts', 'aria-label', 'aria-labelledby', 'aria-level', 'aria-live', 'aria-modal', 'aria-multiline', 'aria-multiselectable', 'aria-orientation', 'aria-owns', 'aria-placeholder', 'aria-posinset', 'aria-pressed', 'aria-readonly', 'aria-relevant', 'aria-required', 'aria-roledescription', 'aria-rowcount', 'aria-rowindex', 'aria-rowspan', 'aria-selected', 'aria-setsize', 'aria-sort', 'aria-valuemax', 'aria-valuemin', 'aria-valuenow', 'aria-valuetext', 'className', 'color', 'height', 'id', 'lang', 'max', 'media', 'method', 'min', 'name', 'style',
/*
 * removed 'type' SVGElementPropKey because we do not currently use any SVG elements
 * that can use it, and it conflicts with the recharts prop 'type'
 * https://github.com/recharts/recharts/pull/3327
 * https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/type
 */
// 'type',
'target', 'width', 'role', 'tabIndex', 'accentHeight', 'accumulate', 'additive', 'alignmentBaseline', 'allowReorder', 'alphabetic', 'amplitude', 'arabicForm', 'ascent', 'attributeName', 'attributeType', 'autoReverse', 'azimuth', 'baseFrequency', 'baselineShift', 'baseProfile', 'bbox', 'begin', 'bias', 'by', 'calcMode', 'capHeight', 'clip', 'clipPath', 'clipPathUnits', 'clipRule', 'colorInterpolation', 'colorInterpolationFilters', 'colorProfile', 'colorRendering', 'contentScriptType', 'contentStyleType', 'cursor', 'cx', 'cy', 'd', 'decelerate', 'descent', 'diffuseConstant', 'direction', 'display', 'divisor', 'dominantBaseline', 'dur', 'dx', 'dy', 'edgeMode', 'elevation', 'enableBackground', 'end', 'exponent', 'externalResourcesRequired', 'fill', 'fillOpacity', 'fillRule', 'filter', 'filterRes', 'filterUnits', 'floodColor', 'floodOpacity', 'focusable', 'fontFamily', 'fontSize', 'fontSizeAdjust', 'fontStretch', 'fontStyle', 'fontVariant', 'fontWeight', 'format', 'from', 'fx', 'fy', 'g1', 'g2', 'glyphName', 'glyphOrientationHorizontal', 'glyphOrientationVertical', 'glyphRef', 'gradientTransform', 'gradientUnits', 'hanging', 'horizAdvX', 'horizOriginX', 'href', 'ideographic', 'imageRendering', 'in2', 'in', 'intercept', 'k1', 'k2', 'k3', 'k4', 'k', 'kernelMatrix', 'kernelUnitLength', 'kerning', 'keyPoints', 'keySplines', 'keyTimes', 'lengthAdjust', 'letterSpacing', 'lightingColor', 'limitingConeAngle', 'local', 'markerEnd', 'markerHeight', 'markerMid', 'markerStart', 'markerUnits', 'markerWidth', 'mask', 'maskContentUnits', 'maskUnits', 'mathematical', 'mode', 'numOctaves', 'offset', 'opacity', 'operator', 'order', 'orient', 'orientation', 'origin', 'overflow', 'overlinePosition', 'overlineThickness', 'paintOrder', 'panose1', 'pathLength', 'patternContentUnits', 'patternTransform', 'patternUnits', 'pointerEvents', 'pointsAtX', 'pointsAtY', 'pointsAtZ', 'preserveAlpha', 'preserveAspectRatio', 'primitiveUnits', 'r', 'radius', 'refX', 'refY', 'renderingIntent', 'repeatCount', 'repeatDur', 'requiredExtensions', 'requiredFeatures', 'restart', 'result', 'rotate', 'rx', 'ry', 'seed', 'shapeRendering', 'slope', 'spacing', 'specularConstant', 'specularExponent', 'speed', 'spreadMethod', 'startOffset', 'stdDeviation', 'stemh', 'stemv', 'stitchTiles', 'stopColor', 'stopOpacity', 'strikethroughPosition', 'strikethroughThickness', 'string', 'stroke', 'strokeDasharray', 'strokeDashoffset', 'strokeLinecap', 'strokeLinejoin', 'strokeMiterlimit', 'strokeOpacity', 'strokeWidth', 'surfaceScale', 'systemLanguage', 'tableValues', 'targetX', 'targetY', 'textAnchor', 'textDecoration', 'textLength', 'textRendering', 'to', 'transform', 'u1', 'u2', 'underlinePosition', 'underlineThickness', 'unicode', 'unicodeBidi', 'unicodeRange', 'unitsPerEm', 'vAlphabetic', 'values', 'vectorEffect', 'version', 'vertAdvY', 'vertOriginX', 'vertOriginY', 'vHanging', 'vIdeographic', 'viewTarget', 'visibility', 'vMathematical', 'widths', 'wordSpacing', 'writingMode', 'x1', 'x2', 'x', 'xChannelSelector', 'xHeight', 'xlinkActuate', 'xlinkArcrole', 'xlinkHref', 'xlinkRole', 'xlinkShow', 'xlinkTitle', 'xlinkType', 'xmlBase', 'xmlLang', 'xmlns', 'xmlnsXlink', 'xmlSpace', 'y1', 'y2', 'y', 'yChannelSelector', 'z', 'zoomAndPan', 'ref', 'key', 'angle'];
function isSvgElementPropKey(key) {
  if (typeof key !== 'string') {
    return false;
  }
  var allowedSvgKeys = SVGElementPropKeys;
  return allowedSvgKeys.includes(key);
}
/**
 * Checks if the property is a data attribute.
 * @param key The property key.
 * @returns True if the key starts with 'data-', false otherwise.
 */
function isDataAttribute(key) {
  return typeof key === 'string' && key.startsWith('data-');
}

/**
 * Filters an object to only include SVG properties. Removes all event handlers too.
 * @param obj - The object to filter
 * @returns A new object containing only valid SVG properties, excluding event handlers.
 */
function svgPropertiesNoEvents(obj) {
  var filteredEntries = Object.entries(obj).filter(_ref => {
    var [key] = _ref;
    return isSvgElementPropKey(key) || isDataAttribute(key);
  });
  return Object.fromEntries(filteredEntries);
}

/**
 * Function to filter SVG properties from various input types.
 * The input types can be:
 * - A record of string keys to any values, in which case it returns a record of only SVG properties
 * - A React element, in which case it returns the props of the element filtered to only SVG properties
 * - Anything else, in which case it returns null
 *
 * This function has a wide-open return type, because it will read and filter the props of an arbitrary React element.
 * This can be SVG, HTML, whatnot, with arbitrary values, so we can't type it more specifically.
 *
 * If you wish to have a type-safe version, use svgPropertiesNoEvents directly with a typed object.
 *
 * @param input - The input to filter, which can be a record, a React element, or other types.
 * @returns A record of SVG properties if the input is a record or React element, otherwise null.
 */
function svgPropertiesNoEventsFromUnknown(input) {
  if (input == null) {
    return null;
  }
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(input) && typeof input.props === 'object' && input.props !== null) {
    var p = input.props;
    return svgPropertiesNoEvents(p);
  }
  if (typeof input === 'object' && !Array.isArray(input)) {
    return svgPropertiesNoEvents(input);
  }
  return null;
}

/***/ }),

/***/ 56956:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ useReportScale)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _state_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(49082);
/* harmony import */ var _state_selectors_containerSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5180);
/* harmony import */ var _state_layoutSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66426);
/* harmony import */ var _isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8813);





function useReportScale() {
  var dispatch = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .j)();
  var [ref, setRef] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  var scale = (0,_state_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .G)(_state_selectors_containerSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectContainerScale */ .et);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (ref == null) {
      return;
    }
    var rect = ref.getBoundingClientRect();
    var newScale = rect.width / ref.offsetWidth;
    if ((0,_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_4__/* .isWellBehavedNumber */ .H)(newScale) && newScale !== scale) {
      dispatch((0,_state_layoutSlice__WEBPACK_IMPORTED_MODULE_3__/* .setScale */ .hF)(newScale));
    }
  }, [ref, dispatch, scale]);
  return setRef;
}

/***/ }),

/***/ 66583:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ useElementOffset)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);

var EPS = 1;

/**
 * TODO this documentation does not reflect what this hook is doing, update it.
 * Stores the `offsetHeight`, `offsetLeft`, `offsetTop`, and `offsetWidth` of a DOM element.
 */

/**
 * Use this to listen to element layout changes.
 *
 * Very useful for reading actual sizes of DOM elements relative to the viewport.
 *
 * @param extraDependencies use this to trigger new DOM dimensions read when any of these change. Good for things like payload and label, that will re-render something down in the children array, but you want to read the layout box of a parent.
 * @returns [lastElementOffset, updateElementOffset] most recent value, and setter. Pass the setter to a DOM element ref like this: `<div ref={updateElementOffset}>`
 */
function useElementOffset() {
  var extraDependencies = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var [lastBoundingBox, setLastBoundingBox] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    height: 0,
    left: 0,
    top: 0,
    width: 0
  });
  var updateBoundingBox = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(node => {
    if (node != null) {
      var rect = node.getBoundingClientRect();
      var box = {
        height: rect.height,
        left: rect.left,
        top: rect.top,
        width: rect.width
      };
      if (Math.abs(box.height - lastBoundingBox.height) > EPS || Math.abs(box.left - lastBoundingBox.left) > EPS || Math.abs(box.top - lastBoundingBox.top) > EPS || Math.abs(box.width - lastBoundingBox.width) > EPS) {
        setLastBoundingBox({
          height: box.height,
          left: box.left,
          top: box.top,
          width: box.width
        });
      }
    }
  },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  [lastBoundingBox.width, lastBoundingBox.height, lastBoundingBox.top, lastBoundingBox.left, ...extraDependencies]);
  return [lastBoundingBox, updateBoundingBox];
}

/***/ }),

/***/ 72925:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ getStackSeriesIdentifier)
/* harmony export */ });
/**
 * Returns identifier for stack series which is one individual graphical item in the stack.
 * @param graphicalItem - The graphical item representing the series in the stack.
 * @return The identifier for the series in the stack
 */
function getStackSeriesIdentifier(graphicalItem) {
  return graphicalItem === null || graphicalItem === void 0 ? void 0 : graphicalItem.id;
}

/***/ }),

/***/ 77404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ resolveDefaultProps)
/* harmony export */ });
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/**
 * This function mimics the behavior of the `defaultProps` static property in React.
 * Functional components do not have a defaultProps property, so this function is useful to resolve default props.
 *
 * The common recommendation is to use ES6 destructuring with default values in the function signature,
 * but you need to be careful there and make sure you destructure all the individual properties
 * and not the whole object. See the test file for example.
 *
 * And because destructuring all properties one by one is a faff, and it's easy to miss one property,
 * this function exists.
 *
 * @param realProps - the props object passed to the component by the user
 * @param defaultProps - the default props object defined in the component by Recharts
 * @returns - the props object with all the default props resolved. All `undefined` values are replaced with the default value.
 */
function resolveDefaultProps(realProps, defaultProps) {
  /*
   * To avoid mutating the original `realProps` object passed to the function, create a shallow copy of it.
   * `resolvedProps` will be modified directly with the defaults.
   */
  var resolvedProps = _objectSpread({}, realProps);
  /*
   * Since the function guarantees `D extends Partial<T>`, this assignment is safe.
   * It allows TypeScript to work with the well-defined `Partial<T>` type inside the loop,
   * making subsequent type inference (especially for `dp[key]`) much more straightforward for the compiler.
   * This is a key step to improve type safety *without* value assertions later.
   */
  var dp = defaultProps;
  /*
   * `Object.keys` doesn't preserve strong key types - it always returns Array<string>.
   * However, due to the `D extends Partial<T>` constraint,
   * we know these keys *must* also be valid keys of `T`.
   * This assertion informs TypeScript of this relationship, avoiding type errors when using `key` to index `acc` (type T).
   *
   * Type assertions are not sound but in this case it's necessary
   * as `Object.keys` does not do what we want it to do.
   */
  var keys = Object.keys(defaultProps);
  var withDefaults = keys.reduce((acc, key) => {
    if (acc[key] === undefined && dp[key] !== undefined) {
      acc[key] = dp[key];
    }
    return acc;
  }, resolvedProps);
  /*
   * And again type assertions are not safe but here we have done the runtime work
   * so let's bypass the lack of static type safety and tell the compiler what happened.
   */
  return withDefaults;
}

/**
 * Helper type to extract the keys of T that are required.
 * It iterates through each key K in T. If Pick<T, K> cannot be assigned an empty object {},
 * it means K is required, so we keep K; otherwise, we discard it (never).
 * [keyof T] at the end creates a union of the kept keys.
 */

/**
 * Helper type to extract the keys of T that are optional.
 * It iterates through each key K in T. If Pick<T, K> can be assigned an empty object {},
 * it means K is optional (or potentially missing), so we keep K; otherwise, we discard it (never).
 * [keyof T] at the end creates a union of the kept keys.
 */

/**
 * Helper type to ensure keys of D exist in T.
 * For each key K in D, if K is also a key of T, keep the type D[K].
 * If K is NOT a key of T, map it to type `never`.
 * An object cannot have a property of type `never`, effectively disallowing extra keys.
 */

/**
 * This type will take a source type `Props` and a default type `Defaults` and will return a new type
 * where all properties that are optional in `Props` but required in `Defaults` are made required in the result.
 * Properties that are required in `Props` and optional in `Defaults` will remain required.
 * Properties that are optional in both `Props` and `Defaults` will remain optional.
 *
 * This is useful for creating a type that represents the resolved props of a component with default props.
 */

/***/ }),

/***/ 79799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   s: () => (/* binding */ getUniqPayload)
/* harmony export */ });
/* harmony import */ var es_toolkit_compat_uniqBy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1081);
/* harmony import */ var es_toolkit_compat_uniqBy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_uniqBy__WEBPACK_IMPORTED_MODULE_0__);


/**
 * This is configuration option that decides how to filter for unique values only:
 *
 * - `false` means "no filter"
 * - `true` means "use recharts default filter"
 * - function means "use return of this function as the default key"
 */

function getUniqPayload(payload, option, defaultUniqBy) {
  if (option === true) {
    return es_toolkit_compat_uniqBy__WEBPACK_IMPORTED_MODULE_0___default()(payload, defaultUniqBy);
  }
  if (typeof option === 'function') {
    return es_toolkit_compat_uniqBy__WEBPACK_IMPORTED_MODULE_0___default()(payload, option);
  }
  return payload;
}

/***/ }),

/***/ 80196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ svgPropertiesAndEvents),
/* harmony export */   y: () => (/* binding */ svgPropertiesAndEventsFromUnknown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _excludeEventProps__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28129);
/* harmony import */ var _svgPropertiesNoEvents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(55448);



/**
 * Filters an object to only include SVG properties, data attributes, and event handlers.
 * @param obj - The object to filter.
 * @returns A new object containing only valid SVG properties, data attributes, and event handlers.
 */
function svgPropertiesAndEvents(obj) {
  var filteredEntries = Object.entries(obj).filter(_ref => {
    var [key] = _ref;
    return (0,_svgPropertiesNoEvents__WEBPACK_IMPORTED_MODULE_2__/* .isSvgElementPropKey */ .Rw)(key) || (0,_svgPropertiesNoEvents__WEBPACK_IMPORTED_MODULE_2__/* .isDataAttribute */ .Xc)(key) || (0,_excludeEventProps__WEBPACK_IMPORTED_MODULE_1__/* .isEventKey */ .q)(key);
  });
  return Object.fromEntries(filteredEntries);
}

/**
 * Function to filter SVG properties from various input types.
 * The input types can be:
 * - A record of string keys to any values, in which case it returns a record of only SVG properties
 * - A React element, in which case it returns the props of the element filtered to only SVG properties
 * - Anything else, in which case it returns null
 *
 * This function has a wide-open return type, because it will read and filter the props of an arbitrary React element.
 * This can be SVG, HTML, whatnot, with arbitrary values, so we can't type it more specifically.
 *
 * If you wish to have a type-safe version, use svgPropertiesNoEvents directly with a typed object.
 *
 * @param input - The input to filter, which can be a record, a React element, or other types.
 * @returns A record of SVG properties if the input is a record or React element, otherwise null.
 */
function svgPropertiesAndEventsFromUnknown(input) {
  if (input == null) {
    return null;
  }
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(input)) {
    return svgPropertiesAndEvents(input.props);
  }
  if (typeof input === 'object' && !Array.isArray(input)) {
    return svgPropertiesAndEvents(input);
  }
  return null;
}

/***/ }),

/***/ 90885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Y: () => (/* binding */ useUniqueId)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
var react_namespaceObject = /*#__PURE__*/__webpack_require__.t(react, 2);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/DataUtils.js
var DataUtils = __webpack_require__(59744);
;// ./node_modules/recharts/es6/util/useId.js
var _ref;



/**
 * Fallback for React.useId() for versions prior to React 18.
 * Generates a unique ID using a simple counter and a prefix.
 *
 * @returns A unique ID that remains consistent across renders.
 */
var useIdFallback = () => {
  var [id] = react.useState(() => (0,DataUtils/* uniqueId */.NF)('uid-'));
  return id;
};

/*
 * This weird syntax is used to avoid a build-time error in React 17 and earlier when building with Webpack.
 * See https://github.com/webpack/webpack/issues/14814
 */
var useId = (_ref = react_namespaceObject['useId'.toString()]) !== null && _ref !== void 0 ? _ref : useIdFallback;
;// ./node_modules/recharts/es6/util/useUniqueId.js


/**
 * A hook that generates a unique ID. It uses React.useId() in React 18+ for SSR safety
 * and falls back to a client-side-only unique ID generator for older versions.
 *
 * The ID will stay the same across renders, and you can optionally provide a prefix.
 *
 * @param [prefix] - An optional prefix for the generated ID.
 * @param [customId] - An optional custom ID to override the generated one.
 * @returns The unique ID.
 */
function useUniqueId(prefix, customId) {
  /*
   * We have to call this hook here even if we don't use the result because
   * rules of hooks demand that hooks are never called conditionally.
   */
  var generatedId = useId();

  // If a custom ID is provided, it always takes precedence.
  if (customId) {
    return customId;
  }

  // Apply the prefix if one was provided.
  return prefix ? "".concat(prefix, "-").concat(generatedId) : generatedId;
}

/**
 * The useUniqueId hook returns a unique ID that is either reused from external props or generated internally.
 * Either way the ID is now guaranteed to be present so no more nulls or undefined.
 */

/***/ }),

/***/ 93749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JH: () => (/* binding */ isWellFormedNumberDomain),
/* harmony export */   f5: () => (/* binding */ numericalDomainSpecifiedWithoutRequiringData),
/* harmony export */   v1: () => (/* binding */ parseNumericalUserDomain)
/* harmony export */ });
/* unused harmony export extendDomain */
/* harmony import */ var _ChartUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33964);
/* harmony import */ var _DataUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59744);
/* harmony import */ var _isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8813);



function isWellFormedNumberDomain(v) {
  if (Array.isArray(v) && v.length === 2) {
    var [min, max] = v;
    if ((0,_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_2__/* .isWellBehavedNumber */ .H)(min) && (0,_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_2__/* .isWellBehavedNumber */ .H)(max)) {
      return true;
    }
  }
  return false;
}
function extendDomain(providedDomain, boundaryDomain, allowDataOverflow) {
  if (allowDataOverflow) {
    // If the data are allowed to overflow - we're fine with whatever user provided
    return providedDomain;
  }
  /*
   * If the data are not allowed to overflow - we need to extend the domain.
   * Means that effectively the user is allowed to make the domain larger
   * but not smaller.
   */
  return [Math.min(providedDomain[0], boundaryDomain[0]), Math.max(providedDomain[1], boundaryDomain[1])];
}

/**
 * So Recharts allows users to provide their own domains,
 * but it also places some expectations on what the domain is.
 * We can improve on the typescript typing, but we also need a runtime test
 to observe that the user-provided domain is well-formed,
 * that is: an array with exactly two numbers.
 *
 * This function does not accept data as an argument.
 * This is to enable a performance optimization - if the domain is there,
 * and we know what it is without traversing all the data,
 * then we don't have to traverse all the data!
 *
 * If the user-provided domain is not well-formed,
 * this function will return undefined - in which case we should traverse the data to calculate the real domain.
 *
 * This function is for parsing the numerical domain only.
 *
 * @param userDomain external prop, user provided, before validation. Can have various shapes: array, function, special magical strings inside too.
 * @param allowDataOverflow boolean, provided by users. If true then the data domain wins
 *
 * @return [min, max] domain if it's well-formed; undefined if the domain is invalid
 */
function numericalDomainSpecifiedWithoutRequiringData(userDomain, allowDataOverflow) {
  if (!allowDataOverflow) {
    // Cannot compute data overflow if the data is not provided
    return undefined;
  }
  if (typeof userDomain === 'function') {
    // The user function expects the data to be provided as an argument
    return undefined;
  }
  if (Array.isArray(userDomain) && userDomain.length === 2) {
    var [providedMin, providedMax] = userDomain;
    var finalMin, finalMax;
    if ((0,_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_2__/* .isWellBehavedNumber */ .H)(providedMin)) {
      finalMin = providedMin;
    } else if (typeof providedMin === 'function') {
      // The user function expects the data to be provided as an argument
      return undefined;
    }
    if ((0,_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_2__/* .isWellBehavedNumber */ .H)(providedMax)) {
      finalMax = providedMax;
    } else if (typeof providedMax === 'function') {
      // The user function expects the data to be provided as an argument
      return undefined;
    }
    var candidate = [finalMin, finalMax];
    if (isWellFormedNumberDomain(candidate)) {
      return candidate;
    }
  }
  return undefined;
}

/**
 * So Recharts allows users to provide their own domains,
 * but it also places some expectations on what the domain is.
 * We can improve on the typescript typing, but we also need a runtime test
 * to observe that the user-provided domain is well-formed,
 * that is: an array with exactly two numbers.
 * If the user-provided domain is not well-formed,
 * this function will return undefined - in which case we should traverse the data to calculate the real domain.
 *
 * This function is for parsing the numerical domain only.
 *
 * You are probably thinking, why does domain need tick count?
 * Well it adjusts the domain based on where the "nice ticks" land, and nice ticks depend on the tick count.
 *
 * @param userDomain external prop, user provided, before validation. Can have various shapes: array, function, special magical strings inside too.
 * @param dataDomain calculated from data. Can be undefined, as an option for performance optimization
 * @param allowDataOverflow provided by users. If true then the data domain wins
 *
 * @return [min, max] domain if it's well-formed; undefined if the domain is invalid
 */
function parseNumericalUserDomain(userDomain, dataDomain, allowDataOverflow) {
  if (!allowDataOverflow && dataDomain == null) {
    // Cannot compute data overflow if the data is not provided
    return undefined;
  }
  if (typeof userDomain === 'function' && dataDomain != null) {
    try {
      var result = userDomain(dataDomain, allowDataOverflow);
      if (isWellFormedNumberDomain(result)) {
        return extendDomain(result, dataDomain, allowDataOverflow);
      }
    } catch (_unused) {
      /* ignore the exception and compute domain from data later */
    }
  }
  if (Array.isArray(userDomain) && userDomain.length === 2) {
    var [providedMin, providedMax] = userDomain;
    var finalMin, finalMax;
    if (providedMin === 'auto') {
      if (dataDomain != null) {
        finalMin = Math.min(...dataDomain);
      }
    } else if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(providedMin)) {
      finalMin = providedMin;
    } else if (typeof providedMin === 'function') {
      try {
        if (dataDomain != null) {
          finalMin = providedMin(dataDomain === null || dataDomain === void 0 ? void 0 : dataDomain[0]);
        }
      } catch (_unused2) {
        /* ignore the exception and compute domain from data later */
      }
    } else if (typeof providedMin === 'string' && _ChartUtils__WEBPACK_IMPORTED_MODULE_0__/* .MIN_VALUE_REG */ .IH.test(providedMin)) {
      var match = _ChartUtils__WEBPACK_IMPORTED_MODULE_0__/* .MIN_VALUE_REG */ .IH.exec(providedMin);
      if (match == null || dataDomain == null) {
        finalMin = undefined;
      } else {
        var value = +match[1];
        finalMin = dataDomain[0] - value;
      }
    } else {
      finalMin = dataDomain === null || dataDomain === void 0 ? void 0 : dataDomain[0];
    }
    if (providedMax === 'auto') {
      if (dataDomain != null) {
        finalMax = Math.max(...dataDomain);
      }
    } else if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNumber */ .Et)(providedMax)) {
      finalMax = providedMax;
    } else if (typeof providedMax === 'function') {
      try {
        if (dataDomain != null) {
          finalMax = providedMax(dataDomain === null || dataDomain === void 0 ? void 0 : dataDomain[1]);
        }
      } catch (_unused3) {
        /* ignore the exception and compute domain from data later */
      }
    } else if (typeof providedMax === 'string' && _ChartUtils__WEBPACK_IMPORTED_MODULE_0__/* .MAX_VALUE_REG */ .qx.test(providedMax)) {
      var _match = _ChartUtils__WEBPACK_IMPORTED_MODULE_0__/* .MAX_VALUE_REG */ .qx.exec(providedMax);
      if (_match == null || dataDomain == null) {
        finalMax = undefined;
      } else {
        var _value = +_match[1];
        finalMax = dataDomain[1] + _value;
      }
    } else {
      finalMax = dataDomain === null || dataDomain === void 0 ? void 0 : dataDomain[1];
    }
    var candidate = [finalMin, finalMax];
    if (isWellFormedNumberDomain(candidate)) {
      if (dataDomain == null) {
        return candidate;
      }
      return extendDomain(candidate, dataDomain, allowDataOverflow);
    }
  }
  return undefined;
}

/***/ }),

/***/ 98940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   X: () => (/* binding */ adaptEventsOfChild),
/* harmony export */   _: () => (/* binding */ adaptEventHandlers)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var _excludeEventProps__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28129);



/**
 * Determines how values are stacked:
 *
 * - `none` is the default, it adds values on top of each other. No smarts. Negative values will overlap.
 * - `expand` make it so that the values always add up to 1 - so the chart will look like a rectangle.
 * - `wiggle` and `silhouette` tries to keep the chart centered.
 * - `sign` stacks positive values above zero and negative values below zero. Similar to `none` but handles negatives.
 * - `positive` ignores all negative values, and then behaves like \`none\`.
 *
 * Also see https://d3js.org/d3-shape/stack#stack-offsets
 * (note that the `diverging` offset in d3 is named `sign` in recharts)
 */

/**
 * @deprecated use either `CartesianLayout` or `PolarLayout` instead.
 * Mixing both charts families leads to ambiguity in the type system.
 * These two layouts share very few properties, so it is best to keep them separate.
 */

/**
 * @deprecated do not use: too many properties, mixing too many concepts, cartesian and polar together, everything optional.
 */

//
// Event Handler Types -- Copied from @types/react/index.d.ts and adapted for Props.
//

/** The type of easing function to use for animations */

/** Specifies the duration of animation, the unit of this option is ms. */

/**
 * This object defines the offset of the chart area and width and height and brush and ... it's a bit too much information all in one.
 * We use it internally but let's not expose it to the outside world.
 * If you are looking for this information, instead import `ChartOffset` or `PlotArea` from `recharts`.
 */

/**
 * The domain of axis.
 * This is the definition
 *
 * Numeric domain is always defined by an array of exactly two values, for the min and the max of the axis.
 * Categorical domain is defined as array of all possible values.
 *
 * Can be specified in many ways:
 * - array of numbers
 * - with special strings like 'dataMin' and 'dataMax'
 * - with special string math like 'dataMin - 100'
 * - with keyword 'auto'
 * - or a function
 * - array of functions
 * - or a combination of the above
 */

/**
 * NumberDomain is an evaluated {@link AxisDomain}.
 * Unlike {@link AxisDomain}, it has no variety - it's a tuple of two number.
 * This is after all the keywords and functions were evaluated and what is left is [min, max].
 *
 * Know that the min, max values are not guaranteed to be nice numbers - values like -Infinity or NaN are possible.
 *
 * There are also `category` axes that have different things than numbers in their domain.
 */

/** The props definition of base axis */

/** Defines how ticks are placed and whether / how tick collisions are handled.
 * 'preserveStart' keeps the left tick on collision and ensures that the first tick is always shown.
 * 'preserveEnd' keeps the right tick on collision and ensures that the last tick is always shown.
 * 'preserveStartEnd' keeps the left tick on collision and ensures that the first and last ticks always show.
 * 'equidistantPreserveStart' selects a number N such that every nTh tick will be shown without collision.
 */

/**
 * Ticks can be any type when the axis is the type of category.
 *
 * Ticks must be numbers when the axis is the type of number.
 */

var adaptEventHandlers = (props, newHandler) => {
  if (!props || typeof props === 'function' || typeof props === 'boolean') {
    return null;
  }
  var inputProps = props;
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(props)) {
    inputProps = props.props;
  }
  if (typeof inputProps !== 'object' && typeof inputProps !== 'function') {
    return null;
  }
  var out = {};
  Object.keys(inputProps).forEach(key => {
    if ((0,_excludeEventProps__WEBPACK_IMPORTED_MODULE_1__/* .isEventKey */ .q)(key)) {
      out[key] = newHandler || (e => inputProps[key](inputProps, e));
    }
  });
  return out;
};
var getEventHandlerOfChild = (originalHandler, data, index) => e => {
  originalHandler(data, index, e);
  return null;
};
var adaptEventsOfChild = (props, data, index) => {
  if (props === null || typeof props !== 'object' && typeof props !== 'function') {
    return null;
  }
  var out = null;
  Object.keys(props).forEach(key => {
    var item = props[key];
    if ((0,_excludeEventProps__WEBPACK_IMPORTED_MODULE_1__/* .isEventKey */ .q)(key) && typeof item === 'function') {
      if (!out) out = {};
      out[key] = getEventHandlerOfChild(item, data, index);
    }
  });
  return out;
};

/**
 * 'axis' means that all graphical items belonging to this axis tick will be highlighted,
 * and all will be present in the tooltip.
 * Tooltip with 'axis' will display when hovering on the chart background.
 *
 * 'item' means only the one graphical item being hovered will show in the tooltip.
 * Tooltip with 'item' will display when hovering over individual graphical items.
 *
 * This is calculated internally;
 * charts have a `defaultTooltipEventType` and `validateTooltipEventTypes` options.
 *
 * Users then use <Tooltip shared={true} /> or <Tooltip shared={false} /> to control their preference,
 * and charts will then see what is allowed and what is not.
 */

/**
 * These are the props we are going to pass to an `activeDot` if it is a function or a custom Component
 */

/**
 * This is the type of `activeDot` prop on:
 * - Area
 * - Line
 * - Radar
 */

// TODO we need two different range objects, one for polar and another for cartesian layouts

/**
 * Simplified version of the MouseEvent so that we don't have to mock the whole thing in tests.
 *
 * This is meant to represent the React.MouseEvent
 * which is a wrapper on top of https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent
 */

/**
 * Coordinates relative to the top-left corner of the chart.
 * Also include scale which means that a chart that's scaled will return the same coordinates as a chart that's not scaled.
 */

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi1kZWY1M2YwYi4yMWI1MGFiNTIwOWFmZTMyMWFmNy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3RUFBd0UsYUFBYTtBQUNyRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlGQUFpRixlQUFlO0FBQ2hHO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNPO0FBQ0E7QUFDUDtBQUNBLHNCQUFzQixTQUFTO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTTtBQUNQLHlFQUF5RSxlQUFlO0FBQ3hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSwyRUFBMkUsZUFBZTtBQUMxRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7O0FDdEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDdUM7QUFDUDs7QUFFaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxRQUFRO0FBQ3BCLFlBQVksY0FBYztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLDRCQUE0QixtQkFBTztBQUNuQztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLFNBQVM7QUFDckIsWUFBWSxTQUFTO0FBQ3JCLFlBQVksU0FBUztBQUNyQixZQUFZLGVBQWU7QUFDM0I7QUFDQTtBQUNBLGdCQUFnQixtQkFBTztBQUN2QjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsWUFBWSxRQUFRO0FBQ3BCLFlBQVksUUFBUTtBQUNwQixZQUFZLFFBQVE7QUFDcEIsWUFBWSxXQUFXO0FBQ3ZCO0FBQ0Esd0JBQXdCLEtBQUs7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxZQUFZLFFBQVE7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksUUFBUTtBQUNwQixZQUFZLFVBQVU7QUFDdEI7QUFDQSwwQkFBMEIsS0FBSztBQUMvQjtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBLFlBQVksUUFBUTtBQUNwQixZQUFZLFFBQVE7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksVUFBVTtBQUN0QjtBQUNBO0FBQ0EsOEJBQThCLEtBQUs7QUFDbkM7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7O0FDM0ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDdUM7QUFDOEI7QUFDUjtBQUM3RDtBQUNBO0FBQ0E7QUFDQSxZQUFZLFFBQVE7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksT0FBTztBQUNuQjtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxlQUFlLG1CQUFPO0FBQ3RCO0FBQ0EsbUJBQW1CLGFBQWE7QUFDaEM7QUFDQTtBQUNBLDRCQUE0QixtQkFBTztBQUNuQztBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsbUJBQU87QUFDbEM7QUFDQSw2QkFBNkIsbUJBQU8sOEJBQThCLG1CQUFPO0FBQ3pFOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLGlCQUFpQixtQkFBTztBQUN4QjtBQUNBLG1CQUFtQixtQkFBTztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixtQkFBTyxTQUFTLGFBQWE7QUFDOUMsbUJBQW1CLG1CQUFPO0FBQzFCLE1BQU07QUFDTjtBQUNBLG1CQUFtQixtQkFBTztBQUMxQjtBQUNBLElBQUk7QUFDSixpQkFBaUIsbUJBQU87QUFDeEIsSUFBSTtBQUNKLGlCQUFpQixtQkFBTztBQUN4QjtBQUNBO0FBQ0EsV0FBVyxPQUFPLENBQUMsR0FBRyxxQkFBcUIsbUJBQU8sMENBQTBDLEtBQUs7QUFDakc7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsbUJBQU87QUFDdkIsbUJBQW1CLG1CQUFPO0FBQzFCLG1CQUFtQixtQkFBTztBQUMxQjtBQUNBOztBQUVBO0FBQ0EsK0JBQStCLG1CQUFPOztBQUV0QztBQUNBOztBQUVBO0FBQ0E7QUFDQSxpQkFBaUIsbUJBQU87QUFDeEIsSUFBSTtBQUNKO0FBQ0EsaUJBQWlCLG1CQUFPO0FBQ3hCO0FBQ0EsNEJBQTRCLG1CQUFPO0FBQ25DO0FBQ0E7QUFDQSw4QkFBOEIsbUJBQU87QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLG1CQUFPO0FBQ25DLDRCQUE0QixtQkFBTztBQUNuQztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUMyQztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELEtBQUssOENBQThDLEtBQUs7QUFDNUcsdUJBQXVCLE9BQU87QUFDOUI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixlQUFlLFNBQVMsMEJBQTBCLG1CQUFPO0FBQ3pELHFCQUFxQixPQUFPO0FBQzVCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixtQkFBTztBQUN0QyxtQkFBbUIsU0FBUyxLQUFLLG1CQUFPLGNBQWMsbUJBQU87QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLE9BQU87QUFDNUI7QUFDTyx3QkFBd0IsT0FBTztBQUMvQiwrQkFBK0IsT0FBTyw2Qjs7Ozs7Ozs7Ozs7O0FDL01kO0FBQ1E7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0Esb0JBQW9CLDZDQUFNLENBQUMsOERBQVE7QUFDbkMsa0JBQWtCLDZDQUFNO0FBQ3hCO0FBQ0EsMEJBQTBCLDhEQUFRO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FFMUJPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQSxDOzs7Ozs7Ozs7Ozs7O0FDTDRCO0FBQ1k7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLFNBQVMsbURBQUk7QUFDYiw2Q0FBNkMsOERBQVEsOEJBQThCLDhEQUFRO0FBQzNGLDRDQUE0Qyw4REFBUSw4QkFBOEIsOERBQVE7QUFDMUYsOENBQThDLDhEQUFRLDhCQUE4Qiw4REFBUTtBQUM1RiwyQ0FBMkMsOERBQVEsOEJBQThCLDhEQUFRO0FBQ3pGLEdBQUc7QUFDSDtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osa0JBQWtCLDhEQUFRO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7QUMxSHVDO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixxREFBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7OztBQ2xFNEM7QUFDb0I7QUFDYTtBQUM3QjtBQUNZO0FBQ3JEO0FBQ1AsaUJBQWlCLHFFQUFjO0FBQy9CLHNCQUFzQiwrQ0FBUTtBQUM5QixjQUFjLHFFQUFjLENBQUMsK0ZBQW9CO0FBQ2pELEVBQUUsZ0RBQVM7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxrRkFBbUI7QUFDM0IsZUFBZSxzRUFBUTtBQUN2QjtBQUNBLEdBQUc7QUFDSDtBQUNBLEM7Ozs7Ozs7Ozs7O0FDcEI4QztBQUM5Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrSUFBK0ksb0JBQW9CO0FBQ25LO0FBQ087QUFDUDtBQUNBLDhDQUE4QywrQ0FBUTtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCwwQkFBMEIsa0RBQVc7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7QUM5Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxDOzs7Ozs7Ozs7O0FDUEEseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSwyRkFBMkY7QUFDM0YseUNBQXlDO0FBQ3pDO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHdGQUF3RjtBQUN4RixrRUFBa0U7QUFDbEU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHOzs7Ozs7Ozs7Ozs7QUNwRjhDOztBQUU5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0EsV0FBVywrREFBTTtBQUNqQjtBQUNBO0FBQ0EsV0FBVywrREFBTTtBQUNqQjtBQUNBO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7QUNsQnVDO0FBQ1U7QUFDOEI7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLFdBQVcscUZBQW1CLFNBQVMsaUZBQWUsU0FBUyx1RUFBVTtBQUN6RSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixxREFBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQytCO0FBQ1E7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1AsYUFBYSxjQUFjLE9BQU8sOEJBQVE7QUFDMUM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLG9CQUFvQixxQkFBSyx5RTs7QUNuQkE7O0FBRWhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixLQUFLOztBQUV6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsRzs7Ozs7Ozs7Ozs7Ozs7OztBQy9CNEQ7QUFDckI7QUFDcUI7QUFDckQ7QUFDUDtBQUNBO0FBQ0EsUUFBUSxrRkFBbUIsU0FBUyxrRkFBbUI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtEO0FBQ2xEO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxrRkFBbUI7QUFDM0I7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0EsUUFBUSxrRkFBbUI7QUFDM0I7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtEO0FBQ2xEO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sU0FBUyw4REFBUTtBQUN2QjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0EsTUFBTSw0Q0FBNEMsZ0VBQWE7QUFDL0Qsa0JBQWtCLGdFQUFhO0FBQy9CO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sU0FBUyw4REFBUTtBQUN2QjtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0EsTUFBTSw0Q0FBNEMsZ0VBQWE7QUFDL0QsbUJBQW1CLGdFQUFhO0FBQ2hDO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDOzs7Ozs7Ozs7Ozs7O0FDaEx1QztBQUNVOztBQUVqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxpQ0FBaUMsaUJBQWlCO0FBQ2xELFdBQVcsaUJBQWlCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHFEQUFjO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSx1RUFBVTtBQUNsQjtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSx1RUFBVTtBQUNsQjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLE1BQU0sdUJBQXVCLE9BQU87QUFDdkU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxHIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvc2NhbGUvdXRpbC91dGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9zY2FsZS91dGlsL2FyaXRobWV0aWMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvc2NhbGUvZ2V0TmljZVRpY2tWYWx1ZXMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvdXNlQW5pbWF0aW9uSWQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvc2NhbGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvaXNXZWxsQmVoYXZlZE51bWJlci5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC90b29sdGlwL3RyYW5zbGF0ZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9zdmdQcm9wZXJ0aWVzTm9FdmVudHMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvdXNlUmVwb3J0U2NhbGUuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvdXNlRWxlbWVudE9mZnNldC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9zdGFja3MvZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi91dGlsL3Jlc29sdmVEZWZhdWx0UHJvcHMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvcGF5bG9hZC9nZXRVbmlxUGF5bG9hZC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9zdmdQcm9wZXJ0aWVzQW5kRXZlbnRzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi91dGlsL3VzZUlkLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi91dGlsL3VzZVVuaXF1ZUlkLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi91dGlsL2lzRG9tYWluU3BlY2lmaWVkQnlVc2VyLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi91dGlsL3R5cGVzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBpZGVudGl0eSA9IGkgPT4gaTtcbmV4cG9ydCB2YXIgUExBQ0VfSE9MREVSID0ge1xuICAnQEBmdW5jdGlvbmFsL3BsYWNlaG9sZGVyJzogdHJ1ZVxufTtcbnZhciBpc1BsYWNlSG9sZGVyID0gdmFsID0+IHZhbCA9PT0gUExBQ0VfSE9MREVSO1xudmFyIGN1cnJ5MCA9IGZuID0+IGZ1bmN0aW9uIF9jdXJyaWVkKCkge1xuICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMCB8fCBhcmd1bWVudHMubGVuZ3RoID09PSAxICYmIGlzUGxhY2VIb2xkZXIoYXJndW1lbnRzLmxlbmd0aCA8PSAwID8gdW5kZWZpbmVkIDogYXJndW1lbnRzWzBdKSkge1xuICAgIHJldHVybiBfY3VycmllZDtcbiAgfVxuICByZXR1cm4gZm4oLi4uYXJndW1lbnRzKTtcbn07XG52YXIgY3VycnlOID0gKG4sIGZuKSA9PiB7XG4gIGlmIChuID09PSAxKSB7XG4gICAgcmV0dXJuIGZuO1xuICB9XG4gIHJldHVybiBjdXJyeTAoZnVuY3Rpb24gKCkge1xuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICB9XG4gICAgdmFyIGFyZ3NMZW5ndGggPSBhcmdzLmZpbHRlcihhcmcgPT4gYXJnICE9PSBQTEFDRV9IT0xERVIpLmxlbmd0aDtcbiAgICBpZiAoYXJnc0xlbmd0aCA+PSBuKSB7XG4gICAgICByZXR1cm4gZm4oLi4uYXJncyk7XG4gICAgfVxuICAgIHJldHVybiBjdXJyeU4obiAtIGFyZ3NMZW5ndGgsIGN1cnJ5MChmdW5jdGlvbiAoKSB7XG4gICAgICBmb3IgKHZhciBfbGVuMiA9IGFyZ3VtZW50cy5sZW5ndGgsIHJlc3RBcmdzID0gbmV3IEFycmF5KF9sZW4yKSwgX2tleTIgPSAwOyBfa2V5MiA8IF9sZW4yOyBfa2V5MisrKSB7XG4gICAgICAgIHJlc3RBcmdzW19rZXkyXSA9IGFyZ3VtZW50c1tfa2V5Ml07XG4gICAgICB9XG4gICAgICB2YXIgbmV3QXJncyA9IGFyZ3MubWFwKGFyZyA9PiBpc1BsYWNlSG9sZGVyKGFyZykgPyByZXN0QXJncy5zaGlmdCgpIDogYXJnKTtcbiAgICAgIHJldHVybiBmbiguLi5uZXdBcmdzLCAuLi5yZXN0QXJncyk7XG4gICAgfSkpO1xuICB9KTtcbn07XG5leHBvcnQgdmFyIGN1cnJ5ID0gZm4gPT4gY3VycnlOKGZuLmxlbmd0aCwgZm4pO1xuZXhwb3J0IHZhciByYW5nZSA9IChiZWdpbiwgZW5kKSA9PiB7XG4gIHZhciBhcnIgPSBbXTtcbiAgZm9yICh2YXIgaSA9IGJlZ2luOyBpIDwgZW5kOyArK2kpIHtcbiAgICBhcnJbaSAtIGJlZ2luXSA9IGk7XG4gIH1cbiAgcmV0dXJuIGFycjtcbn07XG5leHBvcnQgdmFyIG1hcCA9IGN1cnJ5KChmbiwgYXJyKSA9PiB7XG4gIGlmIChBcnJheS5pc0FycmF5KGFycikpIHtcbiAgICByZXR1cm4gYXJyLm1hcChmbik7XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5rZXlzKGFycikubWFwKGtleSA9PiBhcnJba2V5XSkubWFwKGZuKTtcbn0pO1xuZXhwb3J0IHZhciBjb21wb3NlID0gZnVuY3Rpb24gY29tcG9zZSgpIHtcbiAgZm9yICh2YXIgX2xlbjMgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4zKSwgX2tleTMgPSAwOyBfa2V5MyA8IF9sZW4zOyBfa2V5MysrKSB7XG4gICAgYXJnc1tfa2V5M10gPSBhcmd1bWVudHNbX2tleTNdO1xuICB9XG4gIGlmICghYXJncy5sZW5ndGgpIHtcbiAgICByZXR1cm4gaWRlbnRpdHk7XG4gIH1cbiAgdmFyIGZucyA9IGFyZ3MucmV2ZXJzZSgpO1xuICAvLyBmaXJzdCBmdW5jdGlvbiBjYW4gcmVjZWl2ZSBtdWx0aXBseSBhcmd1bWVudHNcbiAgdmFyIGZpcnN0Rm4gPSBmbnNbMF07XG4gIHZhciB0YWlsc0ZuID0gZm5zLnNsaWNlKDEpO1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0YWlsc0ZuLnJlZHVjZSgocmVzLCBmbikgPT4gZm4ocmVzKSwgZmlyc3RGbiguLi5hcmd1bWVudHMpKTtcbiAgfTtcbn07XG5leHBvcnQgdmFyIHJldmVyc2UgPSBhcnIgPT4ge1xuICBpZiAoQXJyYXkuaXNBcnJheShhcnIpKSB7XG4gICAgcmV0dXJuIGFyci5yZXZlcnNlKCk7XG4gIH1cblxuICAvLyBjYW4gYmUgc3RyaW5nXG4gIHJldHVybiBhcnIuc3BsaXQoJycpLnJldmVyc2UoKS5qb2luKCcnKTtcbn07XG5leHBvcnQgdmFyIG1lbW9pemUgPSBmbiA9PiB7XG4gIHZhciBsYXN0QXJncyA9IG51bGw7XG4gIHZhciBsYXN0UmVzdWx0ID0gbnVsbDtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBmb3IgKHZhciBfbGVuNCA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbjQpLCBfa2V5NCA9IDA7IF9rZXk0IDwgX2xlbjQ7IF9rZXk0KyspIHtcbiAgICAgIGFyZ3NbX2tleTRdID0gYXJndW1lbnRzW19rZXk0XTtcbiAgICB9XG4gICAgaWYgKGxhc3RBcmdzICYmIGFyZ3MuZXZlcnkoKHZhbCwgaSkgPT4ge1xuICAgICAgdmFyIF9sYXN0QXJncztcbiAgICAgIHJldHVybiB2YWwgPT09ICgoX2xhc3RBcmdzID0gbGFzdEFyZ3MpID09PSBudWxsIHx8IF9sYXN0QXJncyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2xhc3RBcmdzW2ldKTtcbiAgICB9KSkge1xuICAgICAgcmV0dXJuIGxhc3RSZXN1bHQ7XG4gICAgfVxuICAgIGxhc3RBcmdzID0gYXJncztcbiAgICBsYXN0UmVzdWx0ID0gZm4oLi4uYXJncyk7XG4gICAgcmV0dXJuIGxhc3RSZXN1bHQ7XG4gIH07XG59OyIsIi8qKlxuICogQGZpbGVPdmVydmlldyBTb21lIGNvbW1vbiBhcml0aG1ldGljIG1ldGhvZHNcbiAqIEBhdXRob3IgeGlsZTYxMVxuICogQGRhdGUgMjAxNS0wOS0xN1xuICovXG5pbXBvcnQgRGVjaW1hbCBmcm9tICdkZWNpbWFsLmpzLWxpZ2h0JztcbmltcG9ydCB7IGN1cnJ5IH0gZnJvbSAnLi91dGlscyc7XG5cbi8qKlxuICogR2V0IHRoZSBkaWdpdCBjb3VudCBvZiBhIG51bWJlci5cbiAqIElmIHRoZSBhYnNvbHV0ZSB2YWx1ZSBpcyBpbiB0aGUgaW50ZXJ2YWwgWzAuMSwgMSksIHRoZSByZXN1bHQgaXMgMC5cbiAqIElmIHRoZSBhYnNvbHV0ZSB2YWx1ZSBpcyBpbiB0aGUgaW50ZXJ2YWwgWzAuMDEsIDAuMSksIHRoZSBkaWdpdCBjb3VudCBpcyAtMS5cbiAqIElmIHRoZSBhYnNvbHV0ZSB2YWx1ZSBpcyBpbiB0aGUgaW50ZXJ2YWwgWzAuMDAxLCAwLjAxKSwgdGhlIGRpZ2l0IGNvdW50IGlzIC0yLlxuICpcbiAqIEBwYXJhbSAge051bWJlcn0gdmFsdWUgVGhlIG51bWJlclxuICogQHJldHVybiB7SW50ZWdlcn0gICAgICBEaWdpdCBjb3VudFxuICovXG5mdW5jdGlvbiBnZXREaWdpdENvdW50KHZhbHVlKSB7XG4gIHZhciByZXN1bHQ7XG4gIGlmICh2YWx1ZSA9PT0gMCkge1xuICAgIHJlc3VsdCA9IDE7XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0ID0gTWF0aC5mbG9vcihuZXcgRGVjaW1hbCh2YWx1ZSkuYWJzKCkubG9nKDEwKS50b051bWJlcigpKSArIDE7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBHZXQgdGhlIGRhdGEgaW4gdGhlIGludGVydmFsIFtzdGFydCwgZW5kKSB3aXRoIGEgZml4ZWQgc3RlcC5cbiAqIEFsc28gaGFuZGxlcyBKUyBjYWxjdWxhdGlvbiBwcmVjaXNpb24gaXNzdWVzLlxuICpcbiAqIEBwYXJhbSAge0RlY2ltYWx9IHN0YXJ0IFN0YXJ0IHBvaW50XG4gKiBAcGFyYW0gIHtEZWNpbWFsfSBlbmQgICBFbmQgcG9pbnQsIG5vdCBpbmNsdWRlZFxuICogQHBhcmFtICB7RGVjaW1hbH0gc3RlcCAgU3RlcCBzaXplXG4gKiBAcmV0dXJuIHtBcnJheX0gICAgICAgICBBcnJheSBvZiBudW1iZXJzXG4gKi9cbmZ1bmN0aW9uIHJhbmdlU3RlcChzdGFydCwgZW5kLCBzdGVwKSB7XG4gIHZhciBudW0gPSBuZXcgRGVjaW1hbChzdGFydCk7XG4gIHZhciBpID0gMDtcbiAgdmFyIHJlc3VsdCA9IFtdO1xuXG4gIC8vIG1hZ2ljIG51bWJlciB0byBwcmV2ZW50IGluZmluaXRlIGxvb3BcbiAgd2hpbGUgKG51bS5sdChlbmQpICYmIGkgPCAxMDAwMDApIHtcbiAgICByZXN1bHQucHVzaChudW0udG9OdW1iZXIoKSk7XG4gICAgbnVtID0gbnVtLmFkZChzdGVwKTtcbiAgICBpKys7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBMaW5lYXIgaW50ZXJwb2xhdGlvbiBvZiBudW1iZXJzLlxuICpcbiAqIEBwYXJhbSAge051bWJlcn0gYSAgRW5kcG9pbnQgb2YgdGhlIGRvbWFpblxuICogQHBhcmFtICB7TnVtYmVyfSBiICBFbmRwb2ludCBvZiB0aGUgZG9tYWluXG4gKiBAcGFyYW0gIHtOdW1iZXJ9IHQgIEEgdmFsdWUgaW4gWzAsIDFdXG4gKiBAcmV0dXJuIHtOdW1iZXJ9ICAgIEEgdmFsdWUgaW4gdGhlIGRvbWFpblxuICovXG52YXIgaW50ZXJwb2xhdGVOdW1iZXIgPSBjdXJyeSgoYSwgYiwgdCkgPT4ge1xuICB2YXIgbmV3QSA9ICthO1xuICB2YXIgbmV3QiA9ICtiO1xuICByZXR1cm4gbmV3QSArIHQgKiAobmV3QiAtIG5ld0EpO1xufSk7XG5cbi8qKlxuICogSW52ZXJzZSBvcGVyYXRpb24gb2YgbGluZWFyIGludGVycG9sYXRpb24uXG4gKlxuICogQHBhcmFtICB7TnVtYmVyfSBhIEVuZHBvaW50IG9mIHRoZSBkb21haW5cbiAqIEBwYXJhbSAge051bWJlcn0gYiBFbmRwb2ludCBvZiB0aGUgZG9tYWluXG4gKiBAcGFyYW0gIHtOdW1iZXJ9IHggQ2FuIGJlIGNvbnNpZGVyZWQgYXMgYW4gb3V0cHV0IHZhbHVlIGFmdGVyIGludGVycG9sYXRpb25cbiAqIEByZXR1cm4ge051bWJlcn0gICBXaGVuIHggaXMgaW4gdGhlIHJhbmdlIGEgfiBiLCB0aGUgcmV0dXJuIHZhbHVlIGlzIGluIFswLCAxXVxuICovXG52YXIgdW5pbnRlcnBvbGF0ZU51bWJlciA9IGN1cnJ5KChhLCBiLCB4KSA9PiB7XG4gIHZhciBkaWZmID0gYiAtICthO1xuICBkaWZmID0gZGlmZiB8fCBJbmZpbml0eTtcbiAgcmV0dXJuICh4IC0gYSkgLyBkaWZmO1xufSk7XG5cbi8qKlxuICogSW52ZXJzZSBvcGVyYXRpb24gb2YgbGluZWFyIGludGVycG9sYXRpb24gd2l0aCB0cnVuY2F0aW9uLlxuICpcbiAqIEBwYXJhbSAge051bWJlcn0gYSBFbmRwb2ludCBvZiB0aGUgZG9tYWluXG4gKiBAcGFyYW0gIHtOdW1iZXJ9IGIgRW5kcG9pbnQgb2YgdGhlIGRvbWFpblxuICogQHBhcmFtICB7TnVtYmVyfSB4IENhbiBiZSBjb25zaWRlcmVkIGFzIGFuIG91dHB1dCB2YWx1ZSBhZnRlciBpbnRlcnBvbGF0aW9uXG4gKiBAcmV0dXJuIHtOdW1iZXJ9ICAgV2hlbiB4IGlzIGluIHRoZSBpbnRlcnZhbCBhIH4gYiwgdGhlIHJldHVybiB2YWx1ZSBpcyBpbiBbMCwgMV0uXG4gKiAgICAgICAgICAgICAgICAgICAgV2hlbiB4IGlzIG5vdCBpbiB0aGUgaW50ZXJ2YWwgYSB+IGIsIGl0IHdpbGwgYmUgdHJ1bmNhdGVkIHRvIHRoZSBpbnRlcnZhbCBhIH4gYi5cbiAqL1xudmFyIHVuaW50ZXJwb2xhdGVUcnVuY2F0aW9uID0gY3VycnkoKGEsIGIsIHgpID0+IHtcbiAgdmFyIGRpZmYgPSBiIC0gK2E7XG4gIGRpZmYgPSBkaWZmIHx8IEluZmluaXR5O1xuICByZXR1cm4gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgKHggLSBhKSAvIGRpZmYpKTtcbn0pO1xuZXhwb3J0IHsgcmFuZ2VTdGVwLCBnZXREaWdpdENvdW50LCBpbnRlcnBvbGF0ZU51bWJlciwgdW5pbnRlcnBvbGF0ZU51bWJlciwgdW5pbnRlcnBvbGF0ZVRydW5jYXRpb24gfTsiLCIvKipcbiAqIEBmaWxlT3ZlcnZpZXcgY2FsY3VsYXRlIHRpY2sgdmFsdWVzIG9mIHNjYWxlXG4gKiBAYXV0aG9yIHhpbGU2MTEsIGFyY3RodXJcbiAqIEBkYXRlIDIwMTUtMDktMTdcbiAqL1xuaW1wb3J0IERlY2ltYWwgZnJvbSAnZGVjaW1hbC5qcy1saWdodCc7XG5pbXBvcnQgeyBjb21wb3NlLCByYW5nZSwgbWVtb2l6ZSwgbWFwLCByZXZlcnNlIH0gZnJvbSAnLi91dGlsL3V0aWxzJztcbmltcG9ydCB7IGdldERpZ2l0Q291bnQsIHJhbmdlU3RlcCB9IGZyb20gJy4vdXRpbC9hcml0aG1ldGljJztcbi8qKlxuICogQ2FsY3VsYXRlIGEgaW50ZXJ2YWwgb2YgYSBtaW5pbXVtIHZhbHVlIGFuZCBhIG1heGltdW0gdmFsdWVcbiAqXG4gKiBAcGFyYW0gIHtOdW1iZXJ9IG1pbiAgICAgICBUaGUgbWluaW11bSB2YWx1ZVxuICogQHBhcmFtICB7TnVtYmVyfSBtYXggICAgICAgVGhlIG1heGltdW0gdmFsdWVcbiAqIEByZXR1cm4ge0FycmF5fSBBbiBpbnRlcnZhbFxuICovXG5leHBvcnQgdmFyIGdldFZhbGlkSW50ZXJ2YWwgPSBfcmVmID0+IHtcbiAgdmFyIFttaW4sIG1heF0gPSBfcmVmO1xuICB2YXIgW3ZhbGlkTWluLCB2YWxpZE1heF0gPSBbbWluLCBtYXhdO1xuXG4gIC8vIGV4Y2hhbmdlXG4gIGlmIChtaW4gPiBtYXgpIHtcbiAgICBbdmFsaWRNaW4sIHZhbGlkTWF4XSA9IFttYXgsIG1pbl07XG4gIH1cbiAgcmV0dXJuIFt2YWxpZE1pbiwgdmFsaWRNYXhdO1xufTtcblxuLyoqXG4gKiBDYWxjdWxhdGUgdGhlIHN0ZXAgd2hpY2ggaXMgZWFzeSB0byB1bmRlcnN0YW5kIGJldHdlZW4gdGlja3MsIGxpa2UgMTAsIDIwLCAyNVxuICpcbiAqIEBwYXJhbSAgcm91Z2hTdGVwICAgICAgICBUaGUgcm91Z2ggc3RlcCBjYWxjdWxhdGVkIGJ5IGRpdmlkaW5nIHRoZSBkaWZmZXJlbmNlIGJ5IHRoZSB0aWNrQ291bnRcbiAqIEBwYXJhbSAgYWxsb3dEZWNpbWFscyAgICBBbGxvdyB0aGUgdGlja3MgdG8gYmUgZGVjaW1hbHMgb3Igbm90XG4gKiBAcGFyYW0gIGNvcnJlY3Rpb25GYWN0b3IgQSBjb3JyZWN0aW9uIGZhY3RvclxuICogQHJldHVybiBUaGUgc3RlcCB3aGljaCBpcyBlYXN5IHRvIHVuZGVyc3RhbmQgYmV0d2VlbiB0d28gdGlja3NcbiAqL1xuZXhwb3J0IHZhciBnZXRGb3JtYXRTdGVwID0gKHJvdWdoU3RlcCwgYWxsb3dEZWNpbWFscywgY29ycmVjdGlvbkZhY3RvcikgPT4ge1xuICBpZiAocm91Z2hTdGVwLmx0ZSgwKSkge1xuICAgIHJldHVybiBuZXcgRGVjaW1hbCgwKTtcbiAgfVxuICB2YXIgZGlnaXRDb3VudCA9IGdldERpZ2l0Q291bnQocm91Z2hTdGVwLnRvTnVtYmVyKCkpO1xuICAvLyBUaGUgcmF0aW8gYmV0d2VlbiB0aGUgcm91Z2ggc3RlcCBhbmQgdGhlIHNtYWxsZXN0IG51bWJlciB3aGljaCBoYXMgYSBiaWdnZXJcbiAgLy8gb3JkZXIgb2YgbWFnbml0dWRlcyB0aGFuIHRoZSByb3VnaCBzdGVwXG4gIHZhciBkaWdpdENvdW50VmFsdWUgPSBuZXcgRGVjaW1hbCgxMCkucG93KGRpZ2l0Q291bnQpO1xuICB2YXIgc3RlcFJhdGlvID0gcm91Z2hTdGVwLmRpdihkaWdpdENvdW50VmFsdWUpO1xuICAvLyBXaGVuIGFuIGludGVnZXIgYW5kIGEgZmxvYXQgbXVsdGlwbGllZCwgdGhlIGFjY3VyYWN5IG9mIHJlc3VsdCBtYXkgYmUgd3JvbmdcbiAgdmFyIHN0ZXBSYXRpb1NjYWxlID0gZGlnaXRDb3VudCAhPT0gMSA/IDAuMDUgOiAwLjE7XG4gIHZhciBhbWVuZFN0ZXBSYXRpbyA9IG5ldyBEZWNpbWFsKE1hdGguY2VpbChzdGVwUmF0aW8uZGl2KHN0ZXBSYXRpb1NjYWxlKS50b051bWJlcigpKSkuYWRkKGNvcnJlY3Rpb25GYWN0b3IpLm11bChzdGVwUmF0aW9TY2FsZSk7XG4gIHZhciBmb3JtYXRTdGVwID0gYW1lbmRTdGVwUmF0aW8ubXVsKGRpZ2l0Q291bnRWYWx1ZSk7XG4gIHJldHVybiBhbGxvd0RlY2ltYWxzID8gbmV3IERlY2ltYWwoZm9ybWF0U3RlcC50b051bWJlcigpKSA6IG5ldyBEZWNpbWFsKE1hdGguY2VpbChmb3JtYXRTdGVwLnRvTnVtYmVyKCkpKTtcbn07XG5cbi8qKlxuICogY2FsY3VsYXRlIHRoZSB0aWNrcyB3aGVuIHRoZSBtaW5pbXVtIHZhbHVlIGVxdWFscyB0byB0aGUgbWF4aW11bSB2YWx1ZVxuICpcbiAqIEBwYXJhbSAgdmFsdWUgICAgICAgICBUaGUgbWluaW11bSB2YWx1ZSB3aGljaCBpcyBhbHNvIHRoZSBtYXhpbXVtIHZhbHVlXG4gKiBAcGFyYW0gIHRpY2tDb3VudCAgICAgVGhlIGNvdW50IG9mIHRpY2tzXG4gKiBAcGFyYW0gIGFsbG93RGVjaW1hbHMgQWxsb3cgdGhlIHRpY2tzIHRvIGJlIGRlY2ltYWxzIG9yIG5vdFxuICogQHJldHVybiBhcnJheSBvZiB0aWNrc1xuICovXG5leHBvcnQgdmFyIGdldFRpY2tPZlNpbmdsZVZhbHVlID0gKHZhbHVlLCB0aWNrQ291bnQsIGFsbG93RGVjaW1hbHMpID0+IHtcbiAgdmFyIHN0ZXAgPSBuZXcgRGVjaW1hbCgxKTtcbiAgLy8gY2FsY3VsYXRlIHRoZSBtaWRkbGUgdmFsdWUgb2YgdGlja3NcbiAgdmFyIG1pZGRsZSA9IG5ldyBEZWNpbWFsKHZhbHVlKTtcbiAgaWYgKCFtaWRkbGUuaXNpbnQoKSAmJiBhbGxvd0RlY2ltYWxzKSB7XG4gICAgdmFyIGFic1ZhbCA9IE1hdGguYWJzKHZhbHVlKTtcbiAgICBpZiAoYWJzVmFsIDwgMSkge1xuICAgICAgLy8gVGhlIHN0ZXAgc2hvdWxkIGJlIGEgZmxvYXQgbnVtYmVyIHdoZW4gdGhlIGRpZmZlcmVuY2UgaXMgc21hbGxlciB0aGFuIDFcbiAgICAgIHN0ZXAgPSBuZXcgRGVjaW1hbCgxMCkucG93KGdldERpZ2l0Q291bnQodmFsdWUpIC0gMSk7XG4gICAgICBtaWRkbGUgPSBuZXcgRGVjaW1hbChNYXRoLmZsb29yKG1pZGRsZS5kaXYoc3RlcCkudG9OdW1iZXIoKSkpLm11bChzdGVwKTtcbiAgICB9IGVsc2UgaWYgKGFic1ZhbCA+IDEpIHtcbiAgICAgIC8vIFJldHVybiB0aGUgbWF4aW11bSBpbnRlZ2VyIHdoaWNoIGlzIHNtYWxsZXIgdGhhbiAndmFsdWUnIHdoZW4gJ3ZhbHVlJyBpcyBncmVhdGVyIHRoYW4gMVxuICAgICAgbWlkZGxlID0gbmV3IERlY2ltYWwoTWF0aC5mbG9vcih2YWx1ZSkpO1xuICAgIH1cbiAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gMCkge1xuICAgIG1pZGRsZSA9IG5ldyBEZWNpbWFsKE1hdGguZmxvb3IoKHRpY2tDb3VudCAtIDEpIC8gMikpO1xuICB9IGVsc2UgaWYgKCFhbGxvd0RlY2ltYWxzKSB7XG4gICAgbWlkZGxlID0gbmV3IERlY2ltYWwoTWF0aC5mbG9vcih2YWx1ZSkpO1xuICB9XG4gIHZhciBtaWRkbGVJbmRleCA9IE1hdGguZmxvb3IoKHRpY2tDb3VudCAtIDEpIC8gMik7XG4gIHZhciBmbiA9IGNvbXBvc2UobWFwKG4gPT4gbWlkZGxlLmFkZChuZXcgRGVjaW1hbChuIC0gbWlkZGxlSW5kZXgpLm11bChzdGVwKSkudG9OdW1iZXIoKSksIHJhbmdlKTtcbiAgcmV0dXJuIGZuKDAsIHRpY2tDb3VudCk7XG59O1xuXG4vKipcbiAqIENhbGN1bGF0ZSB0aGUgc3RlcFxuICpcbiAqIEBwYXJhbSAgbWluICAgICAgICAgICAgICBUaGUgbWluaW11bSB2YWx1ZSBvZiBhbiBpbnRlcnZhbFxuICogQHBhcmFtICBtYXggICAgICAgICAgICAgIFRoZSBtYXhpbXVtIHZhbHVlIG9mIGFuIGludGVydmFsXG4gKiBAcGFyYW0gIHRpY2tDb3VudCAgICAgICAgVGhlIGNvdW50IG9mIHRpY2tzXG4gKiBAcGFyYW0gIGFsbG93RGVjaW1hbHMgICAgQWxsb3cgdGhlIHRpY2tzIHRvIGJlIGRlY2ltYWxzIG9yIG5vdFxuICogQHBhcmFtICBjb3JyZWN0aW9uRmFjdG9yIEEgY29ycmVjdGlvbiBmYWN0b3JcbiAqIEByZXR1cm4gVGhlIHN0ZXAsIG1pbmltdW0gdmFsdWUgb2YgdGlja3MsIG1heGltdW0gdmFsdWUgb2YgdGlja3NcbiAqL1xudmFyIF9jYWxjdWxhdGVTdGVwID0gZnVuY3Rpb24gY2FsY3VsYXRlU3RlcChtaW4sIG1heCwgdGlja0NvdW50LCBhbGxvd0RlY2ltYWxzKSB7XG4gIHZhciBjb3JyZWN0aW9uRmFjdG9yID0gYXJndW1lbnRzLmxlbmd0aCA+IDQgJiYgYXJndW1lbnRzWzRdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbNF0gOiAwO1xuICAvLyBkaXJ0eSBoYWNrIChmb3IgcmVjaGFydHMnIHRlc3QpXG4gIGlmICghTnVtYmVyLmlzRmluaXRlKChtYXggLSBtaW4pIC8gKHRpY2tDb3VudCAtIDEpKSkge1xuICAgIHJldHVybiB7XG4gICAgICBzdGVwOiBuZXcgRGVjaW1hbCgwKSxcbiAgICAgIHRpY2tNaW46IG5ldyBEZWNpbWFsKDApLFxuICAgICAgdGlja01heDogbmV3IERlY2ltYWwoMClcbiAgICB9O1xuICB9XG5cbiAgLy8gVGhlIHN0ZXAgd2hpY2ggaXMgZWFzeSB0byB1bmRlcnN0YW5kIGJldHdlZW4gdHdvIHRpY2tzXG4gIHZhciBzdGVwID0gZ2V0Rm9ybWF0U3RlcChuZXcgRGVjaW1hbChtYXgpLnN1YihtaW4pLmRpdih0aWNrQ291bnQgLSAxKSwgYWxsb3dEZWNpbWFscywgY29ycmVjdGlvbkZhY3Rvcik7XG5cbiAgLy8gQSBtZWRpYWwgdmFsdWUgb2YgdGlja3NcbiAgdmFyIG1pZGRsZTtcblxuICAvLyBXaGVuIDAgaXMgaW5zaWRlIHRoZSBpbnRlcnZhbCwgMCBzaG91bGQgYmUgYSB0aWNrXG4gIGlmIChtaW4gPD0gMCAmJiBtYXggPj0gMCkge1xuICAgIG1pZGRsZSA9IG5ldyBEZWNpbWFsKDApO1xuICB9IGVsc2Uge1xuICAgIC8vIGNhbGN1bGF0ZSB0aGUgbWlkZGxlIHZhbHVlXG4gICAgbWlkZGxlID0gbmV3IERlY2ltYWwobWluKS5hZGQobWF4KS5kaXYoMik7XG4gICAgLy8gbWludXMgbW9kdWxvIHZhbHVlXG4gICAgbWlkZGxlID0gbWlkZGxlLnN1YihuZXcgRGVjaW1hbChtaWRkbGUpLm1vZChzdGVwKSk7XG4gIH1cbiAgdmFyIGJlbG93Q291bnQgPSBNYXRoLmNlaWwobWlkZGxlLnN1YihtaW4pLmRpdihzdGVwKS50b051bWJlcigpKTtcbiAgdmFyIHVwQ291bnQgPSBNYXRoLmNlaWwobmV3IERlY2ltYWwobWF4KS5zdWIobWlkZGxlKS5kaXYoc3RlcCkudG9OdW1iZXIoKSk7XG4gIHZhciBzY2FsZUNvdW50ID0gYmVsb3dDb3VudCArIHVwQ291bnQgKyAxO1xuICBpZiAoc2NhbGVDb3VudCA+IHRpY2tDb3VudCkge1xuICAgIC8vIFdoZW4gbW9yZSB0aWNrcyBuZWVkIHRvIGNvdmVyIHRoZSBpbnRlcnZhbCwgc3RlcCBzaG91bGQgYmUgYmlnZ2VyLlxuICAgIHJldHVybiBfY2FsY3VsYXRlU3RlcChtaW4sIG1heCwgdGlja0NvdW50LCBhbGxvd0RlY2ltYWxzLCBjb3JyZWN0aW9uRmFjdG9yICsgMSk7XG4gIH1cbiAgaWYgKHNjYWxlQ291bnQgPCB0aWNrQ291bnQpIHtcbiAgICAvLyBXaGVuIGxlc3MgdGlja3MgY2FuIGNvdmVyIHRoZSBpbnRlcnZhbCwgd2Ugc2hvdWxkIGFkZCBzb21lIGFkZGl0aW9uYWwgdGlja3NcbiAgICB1cENvdW50ID0gbWF4ID4gMCA/IHVwQ291bnQgKyAodGlja0NvdW50IC0gc2NhbGVDb3VudCkgOiB1cENvdW50O1xuICAgIGJlbG93Q291bnQgPSBtYXggPiAwID8gYmVsb3dDb3VudCA6IGJlbG93Q291bnQgKyAodGlja0NvdW50IC0gc2NhbGVDb3VudCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzdGVwLFxuICAgIHRpY2tNaW46IG1pZGRsZS5zdWIobmV3IERlY2ltYWwoYmVsb3dDb3VudCkubXVsKHN0ZXApKSxcbiAgICB0aWNrTWF4OiBtaWRkbGUuYWRkKG5ldyBEZWNpbWFsKHVwQ291bnQpLm11bChzdGVwKSlcbiAgfTtcbn07XG5cbi8qKlxuICogQ2FsY3VsYXRlIHRoZSB0aWNrcyBvZiBhbiBpbnRlcnZhbC4gVGlja3MgY2FuIGFwcGVhciBvdXRzaWRlIHRoZSBpbnRlcnZhbFxuICogaWYgaXQgbWFrZXMgdGhlbSBtb3JlIHJvdW5kZWQgYW5kIG5pY2UuXG4gKlxuICogQHBhcmFtIHR1cGxlIG9mIFttaW4sbWF4XSBtaW46IFRoZSBtaW5pbXVtIHZhbHVlLCBtYXg6IFRoZSBtYXhpbXVtIHZhbHVlXG4gKiBAcGFyYW0gdGlja0NvdW50ICAgICBUaGUgY291bnQgb2YgdGlja3NcbiAqIEBwYXJhbSBhbGxvd0RlY2ltYWxzIEFsbG93IHRoZSB0aWNrcyB0byBiZSBkZWNpbWFscyBvciBub3RcbiAqIEByZXR1cm4gYXJyYXkgb2YgdGlja3NcbiAqL1xuZXhwb3J0IHsgX2NhbGN1bGF0ZVN0ZXAgYXMgY2FsY3VsYXRlU3RlcCB9O1xuZnVuY3Rpb24gZ2V0TmljZVRpY2tWYWx1ZXNGbihfcmVmMikge1xuICB2YXIgW21pbiwgbWF4XSA9IF9yZWYyO1xuICB2YXIgdGlja0NvdW50ID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiA2O1xuICB2YXIgYWxsb3dEZWNpbWFscyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDogdHJ1ZTtcbiAgLy8gTW9yZSB0aGFuIHR3byB0aWNrcyBzaG91bGQgYmUgcmV0dXJuXG4gIHZhciBjb3VudCA9IE1hdGgubWF4KHRpY2tDb3VudCwgMik7XG4gIHZhciBbY29ybWluLCBjb3JtYXhdID0gZ2V0VmFsaWRJbnRlcnZhbChbbWluLCBtYXhdKTtcbiAgaWYgKGNvcm1pbiA9PT0gLUluZmluaXR5IHx8IGNvcm1heCA9PT0gSW5maW5pdHkpIHtcbiAgICB2YXIgX3ZhbHVlcyA9IGNvcm1heCA9PT0gSW5maW5pdHkgPyBbY29ybWluLCAuLi5yYW5nZSgwLCB0aWNrQ291bnQgLSAxKS5tYXAoKCkgPT4gSW5maW5pdHkpXSA6IFsuLi5yYW5nZSgwLCB0aWNrQ291bnQgLSAxKS5tYXAoKCkgPT4gLUluZmluaXR5KSwgY29ybWF4XTtcbiAgICByZXR1cm4gbWluID4gbWF4ID8gcmV2ZXJzZShfdmFsdWVzKSA6IF92YWx1ZXM7XG4gIH1cbiAgaWYgKGNvcm1pbiA9PT0gY29ybWF4KSB7XG4gICAgcmV0dXJuIGdldFRpY2tPZlNpbmdsZVZhbHVlKGNvcm1pbiwgdGlja0NvdW50LCBhbGxvd0RlY2ltYWxzKTtcbiAgfVxuXG4gIC8vIEdldCB0aGUgc3RlcCBiZXR3ZWVuIHR3byB0aWNrc1xuICB2YXIge1xuICAgIHN0ZXAsXG4gICAgdGlja01pbixcbiAgICB0aWNrTWF4XG4gIH0gPSBfY2FsY3VsYXRlU3RlcChjb3JtaW4sIGNvcm1heCwgY291bnQsIGFsbG93RGVjaW1hbHMsIDApO1xuICB2YXIgdmFsdWVzID0gcmFuZ2VTdGVwKHRpY2tNaW4sIHRpY2tNYXguYWRkKG5ldyBEZWNpbWFsKDAuMSkubXVsKHN0ZXApKSwgc3RlcCk7XG4gIHJldHVybiBtaW4gPiBtYXggPyByZXZlcnNlKHZhbHVlcykgOiB2YWx1ZXM7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlIHRoZSB0aWNrcyBvZiBhbiBpbnRlcnZhbC5cbiAqIFRpY2tzIHdpbGwgYmUgY29uc3RyYWluZWQgdG8gdGhlIGludGVydmFsIFttaW4sIG1heF0gZXZlbiBpZiBpdCBtYWtlcyB0aGVtIGxlc3Mgcm91bmRlZCBhbmQgbmljZS5cbiAqXG4gKiBAcGFyYW0gdHVwbGUgb2YgW21pbixtYXhdIG1pbjogVGhlIG1pbmltdW0gdmFsdWUsIG1heDogVGhlIG1heGltdW0gdmFsdWVcbiAqIEBwYXJhbSB0aWNrQ291bnQgICAgIFRoZSBjb3VudCBvZiB0aWNrcy4gVGhpcyBmdW5jdGlvbiBtYXkgcmV0dXJuIGxlc3MgdGhhbiB0aWNrQ291bnQgdGlja3MgaWYgdGhlIGludGVydmFsIGlzIHRvbyBzbWFsbC5cbiAqIEBwYXJhbSBhbGxvd0RlY2ltYWxzIEFsbG93IHRoZSB0aWNrcyB0byBiZSBkZWNpbWFscyBvciBub3RcbiAqIEByZXR1cm4gYXJyYXkgb2YgdGlja3NcbiAqL1xuZnVuY3Rpb24gZ2V0VGlja1ZhbHVlc0ZpeGVkRG9tYWluRm4oX3JlZjMsIHRpY2tDb3VudCkge1xuICB2YXIgW21pbiwgbWF4XSA9IF9yZWYzO1xuICB2YXIgYWxsb3dEZWNpbWFscyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDogdHJ1ZTtcbiAgLy8gTW9yZSB0aGFuIHR3byB0aWNrcyBzaG91bGQgYmUgcmV0dXJuXG4gIHZhciBbY29ybWluLCBjb3JtYXhdID0gZ2V0VmFsaWRJbnRlcnZhbChbbWluLCBtYXhdKTtcbiAgaWYgKGNvcm1pbiA9PT0gLUluZmluaXR5IHx8IGNvcm1heCA9PT0gSW5maW5pdHkpIHtcbiAgICByZXR1cm4gW21pbiwgbWF4XTtcbiAgfVxuICBpZiAoY29ybWluID09PSBjb3JtYXgpIHtcbiAgICByZXR1cm4gW2Nvcm1pbl07XG4gIH1cbiAgdmFyIGNvdW50ID0gTWF0aC5tYXgodGlja0NvdW50LCAyKTtcbiAgdmFyIHN0ZXAgPSBnZXRGb3JtYXRTdGVwKG5ldyBEZWNpbWFsKGNvcm1heCkuc3ViKGNvcm1pbikuZGl2KGNvdW50IC0gMSksIGFsbG93RGVjaW1hbHMsIDApO1xuICB2YXIgdmFsdWVzID0gWy4uLnJhbmdlU3RlcChuZXcgRGVjaW1hbChjb3JtaW4pLCBuZXcgRGVjaW1hbChjb3JtYXgpLCBzdGVwKSwgY29ybWF4XTtcbiAgaWYgKGFsbG93RGVjaW1hbHMgPT09IGZhbHNlKSB7XG4gICAgLypcbiAgICAgKiBhbGxvd0RlY2ltYWxzIGlzIGZhbHNlIG1lYW5zIHRoYXQgd2Ugd2FudCB0byBoYXZlIGludGVnZXIgdGlja3MuXG4gICAgICogVGhlIHN0ZXAgaXMgZ3VhcmFudGVlZCB0byBiZSBhbiBpbnRlZ2VyIGluIHRoZSBjb2RlIGFib3ZlIHdoaWNoIGlzIGdyZWF0IHN0YXJ0XG4gICAgICogYnV0IHdoZW4gdGhlIGZpcnN0IHN0ZXAgaXMgbm90IGFuIGludGVnZXIsIGl0IHdpbGwgc3RhcnQgc3RlcHBpbmcgZnJvbSBhIGRlY2ltYWwgdmFsdWUgYW55d2F5LlxuICAgICAqIFNvIHdlIG5lZWQgdG8gcm91bmQgYWxsIHRoZSB2YWx1ZXMgdG8gaW50ZWdlcnMgYWZ0ZXIgdGhlIGZhY3QuXG4gICAgICovXG4gICAgdmFsdWVzID0gdmFsdWVzLm1hcCh2YWx1ZSA9PiBNYXRoLnJvdW5kKHZhbHVlKSk7XG4gIH1cbiAgcmV0dXJuIG1pbiA+IG1heCA/IHJldmVyc2UodmFsdWVzKSA6IHZhbHVlcztcbn1cbmV4cG9ydCB2YXIgZ2V0TmljZVRpY2tWYWx1ZXMgPSBtZW1vaXplKGdldE5pY2VUaWNrVmFsdWVzRm4pO1xuZXhwb3J0IHZhciBnZXRUaWNrVmFsdWVzRml4ZWREb21haW4gPSBtZW1vaXplKGdldFRpY2tWYWx1ZXNGaXhlZERvbWFpbkZuKTsiLCJpbXBvcnQgeyB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1bmlxdWVJZCB9IGZyb20gJy4vRGF0YVV0aWxzJztcblxuLyoqXG4gKiBUaGlzIGhvb2sgcmV0dXJucyBhIHVuaXF1ZSBhbmltYXRpb24gaWQgZm9yIHRoZSBvYmplY3QgaW5wdXQuXG4gKiBJZiBpbnB1dCBjaGFuZ2VzIChhcyBpbiwgcmVmZXJlbmNlIGVxdWFsaXR5IGlzIGRpZmZlcmVudCksIHRoZSBhbmltYXRpb24gaWQgd2lsbCBjaGFuZ2UuXG4gKiBJZiBpbnB1dCBkb2VzIG5vdCBjaGFuZ2UsIHRoZSBhbmltYXRpb24gaWQgd2lsbCBub3QgY2hhbmdlLlxuICpcbiAqIFRoaXMgaXMgdXNlZnVsIGZvciBhbmltYXRpb25zLiBUaGUgQW5pbWF0ZSBjb21wb25lbnRcbiAqIGRvZXMgaGF2ZSBhIGBzaG91bGRSZUFuaW1hdGVgIHByb3AgYnV0IHRoYXQgZG9lc24ndCBzZWVtIHRvIGJlIGRvaW5nIHdoYXQgdGhlIG5hbWUgaW1wbGllcy5cbiAqIEFsc28sIHdlIGRvbid0IGFsd2F5cyB3YW50IHRvIHJlLWFuaW1hdGUgb24gZXZlcnkgcmVuZGVyO1xuICogd2Ugb25seSB3YW50IHRvIHJlLWFuaW1hdGUgd2hlbiB0aGUgaW5wdXQgY2hhbmdlcy4gTm90IHRoZSBpbnRlcm5hbCBzdGF0ZSAoZS5nLiBgaXNBbmltYXRpbmdgKS5cbiAqXG4gKiBAcGFyYW0gaW5wdXQgVGhlIG9iamVjdCB0byBjaGVjayBmb3IgY2hhbmdlcy4gVXNlcyByZWZlcmVuY2UgZXF1YWxpdHkgKD09PSBvcGVyYXRvcilcbiAqIEBwYXJhbSBwcmVmaXggT3B0aW9uYWwgcHJlZml4IHRvIHVzZSBmb3IgdGhlIGFuaW1hdGlvbiBpZFxuICogQHJldHVybnMgQSB1bmlxdWUgYW5pbWF0aW9uIGlkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VBbmltYXRpb25JZChpbnB1dCkge1xuICB2YXIgcHJlZml4ID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiAnYW5pbWF0aW9uLSc7XG4gIHZhciBhbmltYXRpb25JZCA9IHVzZVJlZih1bmlxdWVJZChwcmVmaXgpKTtcbiAgdmFyIHByZXZQcm9wcyA9IHVzZVJlZihpbnB1dCk7XG4gIGlmIChwcmV2UHJvcHMuY3VycmVudCAhPT0gaW5wdXQpIHtcbiAgICBhbmltYXRpb25JZC5jdXJyZW50ID0gdW5pcXVlSWQocHJlZml4KTtcbiAgICBwcmV2UHJvcHMuY3VycmVudCA9IGlucHV0O1xuICB9XG4gIHJldHVybiBhbmltYXRpb25JZC5jdXJyZW50O1xufSIsImV4cG9ydCB7IGdldE5pY2VUaWNrVmFsdWVzLCBnZXRUaWNrVmFsdWVzRml4ZWREb21haW4gfSBmcm9tICcuL2dldE5pY2VUaWNrVmFsdWVzJzsiLCJleHBvcnQgZnVuY3Rpb24gaXNXZWxsQmVoYXZlZE51bWJlcihuKSB7XG4gIHJldHVybiBOdW1iZXIuaXNGaW5pdGUobik7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNQb3NpdGl2ZU51bWJlcihuKSB7XG4gIHJldHVybiB0eXBlb2YgbiA9PT0gJ251bWJlcicgJiYgbiA+IDAgJiYgTnVtYmVyLmlzRmluaXRlKG4pO1xufSIsImltcG9ydCB7IGNsc3ggfSBmcm9tICdjbHN4JztcbmltcG9ydCB7IGlzTnVtYmVyIH0gZnJvbSAnLi4vRGF0YVV0aWxzJztcbnZhciBDU1NfQ0xBU1NfUFJFRklYID0gJ3JlY2hhcnRzLXRvb2x0aXAtd3JhcHBlcic7XG52YXIgVE9PTFRJUF9ISURERU4gPSB7XG4gIHZpc2liaWxpdHk6ICdoaWRkZW4nXG59O1xuZXhwb3J0IGZ1bmN0aW9uIGdldFRvb2x0aXBDU1NDbGFzc05hbWUoX3JlZikge1xuICB2YXIge1xuICAgIGNvb3JkaW5hdGUsXG4gICAgdHJhbnNsYXRlWCxcbiAgICB0cmFuc2xhdGVZXG4gIH0gPSBfcmVmO1xuICByZXR1cm4gY2xzeChDU1NfQ0xBU1NfUFJFRklYLCB7XG4gICAgW1wiXCIuY29uY2F0KENTU19DTEFTU19QUkVGSVgsIFwiLXJpZ2h0XCIpXTogaXNOdW1iZXIodHJhbnNsYXRlWCkgJiYgY29vcmRpbmF0ZSAmJiBpc051bWJlcihjb29yZGluYXRlLngpICYmIHRyYW5zbGF0ZVggPj0gY29vcmRpbmF0ZS54LFxuICAgIFtcIlwiLmNvbmNhdChDU1NfQ0xBU1NfUFJFRklYLCBcIi1sZWZ0XCIpXTogaXNOdW1iZXIodHJhbnNsYXRlWCkgJiYgY29vcmRpbmF0ZSAmJiBpc051bWJlcihjb29yZGluYXRlLngpICYmIHRyYW5zbGF0ZVggPCBjb29yZGluYXRlLngsXG4gICAgW1wiXCIuY29uY2F0KENTU19DTEFTU19QUkVGSVgsIFwiLWJvdHRvbVwiKV06IGlzTnVtYmVyKHRyYW5zbGF0ZVkpICYmIGNvb3JkaW5hdGUgJiYgaXNOdW1iZXIoY29vcmRpbmF0ZS55KSAmJiB0cmFuc2xhdGVZID49IGNvb3JkaW5hdGUueSxcbiAgICBbXCJcIi5jb25jYXQoQ1NTX0NMQVNTX1BSRUZJWCwgXCItdG9wXCIpXTogaXNOdW1iZXIodHJhbnNsYXRlWSkgJiYgY29vcmRpbmF0ZSAmJiBpc051bWJlcihjb29yZGluYXRlLnkpICYmIHRyYW5zbGF0ZVkgPCBjb29yZGluYXRlLnlcbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9vbHRpcFRyYW5zbGF0ZVhZKF9yZWYyKSB7XG4gIHZhciB7XG4gICAgYWxsb3dFc2NhcGVWaWV3Qm94LFxuICAgIGNvb3JkaW5hdGUsXG4gICAga2V5LFxuICAgIG9mZnNldFRvcExlZnQsXG4gICAgcG9zaXRpb24sXG4gICAgcmV2ZXJzZURpcmVjdGlvbixcbiAgICB0b29sdGlwRGltZW5zaW9uLFxuICAgIHZpZXdCb3gsXG4gICAgdmlld0JveERpbWVuc2lvblxuICB9ID0gX3JlZjI7XG4gIGlmIChwb3NpdGlvbiAmJiBpc051bWJlcihwb3NpdGlvbltrZXldKSkge1xuICAgIHJldHVybiBwb3NpdGlvbltrZXldO1xuICB9XG4gIHZhciBuZWdhdGl2ZSA9IGNvb3JkaW5hdGVba2V5XSAtIHRvb2x0aXBEaW1lbnNpb24gLSAob2Zmc2V0VG9wTGVmdCA+IDAgPyBvZmZzZXRUb3BMZWZ0IDogMCk7XG4gIHZhciBwb3NpdGl2ZSA9IGNvb3JkaW5hdGVba2V5XSArIG9mZnNldFRvcExlZnQ7XG4gIGlmIChhbGxvd0VzY2FwZVZpZXdCb3hba2V5XSkge1xuICAgIHJldHVybiByZXZlcnNlRGlyZWN0aW9uW2tleV0gPyBuZWdhdGl2ZSA6IHBvc2l0aXZlO1xuICB9XG4gIHZhciB2aWV3Qm94S2V5ID0gdmlld0JveFtrZXldO1xuICBpZiAodmlld0JveEtleSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cbiAgaWYgKHJldmVyc2VEaXJlY3Rpb25ba2V5XSkge1xuICAgIHZhciBfdG9vbHRpcEJvdW5kYXJ5ID0gbmVnYXRpdmU7XG4gICAgdmFyIF92aWV3Qm94Qm91bmRhcnkgPSB2aWV3Qm94S2V5O1xuICAgIGlmIChfdG9vbHRpcEJvdW5kYXJ5IDwgX3ZpZXdCb3hCb3VuZGFyeSkge1xuICAgICAgcmV0dXJuIE1hdGgubWF4KHBvc2l0aXZlLCB2aWV3Qm94S2V5KTtcbiAgICB9XG4gICAgcmV0dXJuIE1hdGgubWF4KG5lZ2F0aXZlLCB2aWV3Qm94S2V5KTtcbiAgfVxuICBpZiAodmlld0JveERpbWVuc2lvbiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cbiAgdmFyIHRvb2x0aXBCb3VuZGFyeSA9IHBvc2l0aXZlICsgdG9vbHRpcERpbWVuc2lvbjtcbiAgdmFyIHZpZXdCb3hCb3VuZGFyeSA9IHZpZXdCb3hLZXkgKyB2aWV3Qm94RGltZW5zaW9uO1xuICBpZiAodG9vbHRpcEJvdW5kYXJ5ID4gdmlld0JveEJvdW5kYXJ5KSB7XG4gICAgcmV0dXJuIE1hdGgubWF4KG5lZ2F0aXZlLCB2aWV3Qm94S2V5KTtcbiAgfVxuICByZXR1cm4gTWF0aC5tYXgocG9zaXRpdmUsIHZpZXdCb3hLZXkpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRyYW5zZm9ybVN0eWxlKF9yZWYzKSB7XG4gIHZhciB7XG4gICAgdHJhbnNsYXRlWCxcbiAgICB0cmFuc2xhdGVZLFxuICAgIHVzZVRyYW5zbGF0ZTNkXG4gIH0gPSBfcmVmMztcbiAgcmV0dXJuIHtcbiAgICB0cmFuc2Zvcm06IHVzZVRyYW5zbGF0ZTNkID8gXCJ0cmFuc2xhdGUzZChcIi5jb25jYXQodHJhbnNsYXRlWCwgXCJweCwgXCIpLmNvbmNhdCh0cmFuc2xhdGVZLCBcInB4LCAwKVwiKSA6IFwidHJhbnNsYXRlKFwiLmNvbmNhdCh0cmFuc2xhdGVYLCBcInB4LCBcIikuY29uY2F0KHRyYW5zbGF0ZVksIFwicHgpXCIpXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9vbHRpcFRyYW5zbGF0ZShfcmVmNCkge1xuICB2YXIge1xuICAgIGFsbG93RXNjYXBlVmlld0JveCxcbiAgICBjb29yZGluYXRlLFxuICAgIG9mZnNldFRvcExlZnQsXG4gICAgcG9zaXRpb24sXG4gICAgcmV2ZXJzZURpcmVjdGlvbixcbiAgICB0b29sdGlwQm94LFxuICAgIHVzZVRyYW5zbGF0ZTNkLFxuICAgIHZpZXdCb3hcbiAgfSA9IF9yZWY0O1xuICB2YXIgY3NzUHJvcGVydGllcywgdHJhbnNsYXRlWCwgdHJhbnNsYXRlWTtcbiAgaWYgKHRvb2x0aXBCb3guaGVpZ2h0ID4gMCAmJiB0b29sdGlwQm94LndpZHRoID4gMCAmJiBjb29yZGluYXRlKSB7XG4gICAgdHJhbnNsYXRlWCA9IGdldFRvb2x0aXBUcmFuc2xhdGVYWSh7XG4gICAgICBhbGxvd0VzY2FwZVZpZXdCb3gsXG4gICAgICBjb29yZGluYXRlLFxuICAgICAga2V5OiAneCcsXG4gICAgICBvZmZzZXRUb3BMZWZ0LFxuICAgICAgcG9zaXRpb24sXG4gICAgICByZXZlcnNlRGlyZWN0aW9uLFxuICAgICAgdG9vbHRpcERpbWVuc2lvbjogdG9vbHRpcEJveC53aWR0aCxcbiAgICAgIHZpZXdCb3gsXG4gICAgICB2aWV3Qm94RGltZW5zaW9uOiB2aWV3Qm94LndpZHRoXG4gICAgfSk7XG4gICAgdHJhbnNsYXRlWSA9IGdldFRvb2x0aXBUcmFuc2xhdGVYWSh7XG4gICAgICBhbGxvd0VzY2FwZVZpZXdCb3gsXG4gICAgICBjb29yZGluYXRlLFxuICAgICAga2V5OiAneScsXG4gICAgICBvZmZzZXRUb3BMZWZ0LFxuICAgICAgcG9zaXRpb24sXG4gICAgICByZXZlcnNlRGlyZWN0aW9uLFxuICAgICAgdG9vbHRpcERpbWVuc2lvbjogdG9vbHRpcEJveC5oZWlnaHQsXG4gICAgICB2aWV3Qm94LFxuICAgICAgdmlld0JveERpbWVuc2lvbjogdmlld0JveC5oZWlnaHRcbiAgICB9KTtcbiAgICBjc3NQcm9wZXJ0aWVzID0gZ2V0VHJhbnNmb3JtU3R5bGUoe1xuICAgICAgdHJhbnNsYXRlWCxcbiAgICAgIHRyYW5zbGF0ZVksXG4gICAgICB1c2VUcmFuc2xhdGUzZFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGNzc1Byb3BlcnRpZXMgPSBUT09MVElQX0hJRERFTjtcbiAgfVxuICByZXR1cm4ge1xuICAgIGNzc1Byb3BlcnRpZXMsXG4gICAgY3NzQ2xhc3NlczogZ2V0VG9vbHRpcENTU0NsYXNzTmFtZSh7XG4gICAgICB0cmFuc2xhdGVYLFxuICAgICAgdHJhbnNsYXRlWSxcbiAgICAgIGNvb3JkaW5hdGVcbiAgICB9KVxuICB9O1xufSIsImltcG9ydCB7IGlzVmFsaWRFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xudmFyIFNWR0VsZW1lbnRQcm9wS2V5cyA9IFsnYXJpYS1hY3RpdmVkZXNjZW5kYW50JywgJ2FyaWEtYXRvbWljJywgJ2FyaWEtYXV0b2NvbXBsZXRlJywgJ2FyaWEtYnVzeScsICdhcmlhLWNoZWNrZWQnLCAnYXJpYS1jb2xjb3VudCcsICdhcmlhLWNvbGluZGV4JywgJ2FyaWEtY29sc3BhbicsICdhcmlhLWNvbnRyb2xzJywgJ2FyaWEtY3VycmVudCcsICdhcmlhLWRlc2NyaWJlZGJ5JywgJ2FyaWEtZGV0YWlscycsICdhcmlhLWRpc2FibGVkJywgJ2FyaWEtZXJyb3JtZXNzYWdlJywgJ2FyaWEtZXhwYW5kZWQnLCAnYXJpYS1mbG93dG8nLCAnYXJpYS1oYXNwb3B1cCcsICdhcmlhLWhpZGRlbicsICdhcmlhLWludmFsaWQnLCAnYXJpYS1rZXlzaG9ydGN1dHMnLCAnYXJpYS1sYWJlbCcsICdhcmlhLWxhYmVsbGVkYnknLCAnYXJpYS1sZXZlbCcsICdhcmlhLWxpdmUnLCAnYXJpYS1tb2RhbCcsICdhcmlhLW11bHRpbGluZScsICdhcmlhLW11bHRpc2VsZWN0YWJsZScsICdhcmlhLW9yaWVudGF0aW9uJywgJ2FyaWEtb3ducycsICdhcmlhLXBsYWNlaG9sZGVyJywgJ2FyaWEtcG9zaW5zZXQnLCAnYXJpYS1wcmVzc2VkJywgJ2FyaWEtcmVhZG9ubHknLCAnYXJpYS1yZWxldmFudCcsICdhcmlhLXJlcXVpcmVkJywgJ2FyaWEtcm9sZWRlc2NyaXB0aW9uJywgJ2FyaWEtcm93Y291bnQnLCAnYXJpYS1yb3dpbmRleCcsICdhcmlhLXJvd3NwYW4nLCAnYXJpYS1zZWxlY3RlZCcsICdhcmlhLXNldHNpemUnLCAnYXJpYS1zb3J0JywgJ2FyaWEtdmFsdWVtYXgnLCAnYXJpYS12YWx1ZW1pbicsICdhcmlhLXZhbHVlbm93JywgJ2FyaWEtdmFsdWV0ZXh0JywgJ2NsYXNzTmFtZScsICdjb2xvcicsICdoZWlnaHQnLCAnaWQnLCAnbGFuZycsICdtYXgnLCAnbWVkaWEnLCAnbWV0aG9kJywgJ21pbicsICduYW1lJywgJ3N0eWxlJyxcbi8qXG4gKiByZW1vdmVkICd0eXBlJyBTVkdFbGVtZW50UHJvcEtleSBiZWNhdXNlIHdlIGRvIG5vdCBjdXJyZW50bHkgdXNlIGFueSBTVkcgZWxlbWVudHNcbiAqIHRoYXQgY2FuIHVzZSBpdCwgYW5kIGl0IGNvbmZsaWN0cyB3aXRoIHRoZSByZWNoYXJ0cyBwcm9wICd0eXBlJ1xuICogaHR0cHM6Ly9naXRodWIuY29tL3JlY2hhcnRzL3JlY2hhcnRzL3B1bGwvMzMyN1xuICogaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvU1ZHL0F0dHJpYnV0ZS90eXBlXG4gKi9cbi8vICd0eXBlJyxcbid0YXJnZXQnLCAnd2lkdGgnLCAncm9sZScsICd0YWJJbmRleCcsICdhY2NlbnRIZWlnaHQnLCAnYWNjdW11bGF0ZScsICdhZGRpdGl2ZScsICdhbGlnbm1lbnRCYXNlbGluZScsICdhbGxvd1Jlb3JkZXInLCAnYWxwaGFiZXRpYycsICdhbXBsaXR1ZGUnLCAnYXJhYmljRm9ybScsICdhc2NlbnQnLCAnYXR0cmlidXRlTmFtZScsICdhdHRyaWJ1dGVUeXBlJywgJ2F1dG9SZXZlcnNlJywgJ2F6aW11dGgnLCAnYmFzZUZyZXF1ZW5jeScsICdiYXNlbGluZVNoaWZ0JywgJ2Jhc2VQcm9maWxlJywgJ2Jib3gnLCAnYmVnaW4nLCAnYmlhcycsICdieScsICdjYWxjTW9kZScsICdjYXBIZWlnaHQnLCAnY2xpcCcsICdjbGlwUGF0aCcsICdjbGlwUGF0aFVuaXRzJywgJ2NsaXBSdWxlJywgJ2NvbG9ySW50ZXJwb2xhdGlvbicsICdjb2xvckludGVycG9sYXRpb25GaWx0ZXJzJywgJ2NvbG9yUHJvZmlsZScsICdjb2xvclJlbmRlcmluZycsICdjb250ZW50U2NyaXB0VHlwZScsICdjb250ZW50U3R5bGVUeXBlJywgJ2N1cnNvcicsICdjeCcsICdjeScsICdkJywgJ2RlY2VsZXJhdGUnLCAnZGVzY2VudCcsICdkaWZmdXNlQ29uc3RhbnQnLCAnZGlyZWN0aW9uJywgJ2Rpc3BsYXknLCAnZGl2aXNvcicsICdkb21pbmFudEJhc2VsaW5lJywgJ2R1cicsICdkeCcsICdkeScsICdlZGdlTW9kZScsICdlbGV2YXRpb24nLCAnZW5hYmxlQmFja2dyb3VuZCcsICdlbmQnLCAnZXhwb25lbnQnLCAnZXh0ZXJuYWxSZXNvdXJjZXNSZXF1aXJlZCcsICdmaWxsJywgJ2ZpbGxPcGFjaXR5JywgJ2ZpbGxSdWxlJywgJ2ZpbHRlcicsICdmaWx0ZXJSZXMnLCAnZmlsdGVyVW5pdHMnLCAnZmxvb2RDb2xvcicsICdmbG9vZE9wYWNpdHknLCAnZm9jdXNhYmxlJywgJ2ZvbnRGYW1pbHknLCAnZm9udFNpemUnLCAnZm9udFNpemVBZGp1c3QnLCAnZm9udFN0cmV0Y2gnLCAnZm9udFN0eWxlJywgJ2ZvbnRWYXJpYW50JywgJ2ZvbnRXZWlnaHQnLCAnZm9ybWF0JywgJ2Zyb20nLCAnZngnLCAnZnknLCAnZzEnLCAnZzInLCAnZ2x5cGhOYW1lJywgJ2dseXBoT3JpZW50YXRpb25Ib3Jpem9udGFsJywgJ2dseXBoT3JpZW50YXRpb25WZXJ0aWNhbCcsICdnbHlwaFJlZicsICdncmFkaWVudFRyYW5zZm9ybScsICdncmFkaWVudFVuaXRzJywgJ2hhbmdpbmcnLCAnaG9yaXpBZHZYJywgJ2hvcml6T3JpZ2luWCcsICdocmVmJywgJ2lkZW9ncmFwaGljJywgJ2ltYWdlUmVuZGVyaW5nJywgJ2luMicsICdpbicsICdpbnRlcmNlcHQnLCAnazEnLCAnazInLCAnazMnLCAnazQnLCAnaycsICdrZXJuZWxNYXRyaXgnLCAna2VybmVsVW5pdExlbmd0aCcsICdrZXJuaW5nJywgJ2tleVBvaW50cycsICdrZXlTcGxpbmVzJywgJ2tleVRpbWVzJywgJ2xlbmd0aEFkanVzdCcsICdsZXR0ZXJTcGFjaW5nJywgJ2xpZ2h0aW5nQ29sb3InLCAnbGltaXRpbmdDb25lQW5nbGUnLCAnbG9jYWwnLCAnbWFya2VyRW5kJywgJ21hcmtlckhlaWdodCcsICdtYXJrZXJNaWQnLCAnbWFya2VyU3RhcnQnLCAnbWFya2VyVW5pdHMnLCAnbWFya2VyV2lkdGgnLCAnbWFzaycsICdtYXNrQ29udGVudFVuaXRzJywgJ21hc2tVbml0cycsICdtYXRoZW1hdGljYWwnLCAnbW9kZScsICdudW1PY3RhdmVzJywgJ29mZnNldCcsICdvcGFjaXR5JywgJ29wZXJhdG9yJywgJ29yZGVyJywgJ29yaWVudCcsICdvcmllbnRhdGlvbicsICdvcmlnaW4nLCAnb3ZlcmZsb3cnLCAnb3ZlcmxpbmVQb3NpdGlvbicsICdvdmVybGluZVRoaWNrbmVzcycsICdwYWludE9yZGVyJywgJ3Bhbm9zZTEnLCAncGF0aExlbmd0aCcsICdwYXR0ZXJuQ29udGVudFVuaXRzJywgJ3BhdHRlcm5UcmFuc2Zvcm0nLCAncGF0dGVyblVuaXRzJywgJ3BvaW50ZXJFdmVudHMnLCAncG9pbnRzQXRYJywgJ3BvaW50c0F0WScsICdwb2ludHNBdFonLCAncHJlc2VydmVBbHBoYScsICdwcmVzZXJ2ZUFzcGVjdFJhdGlvJywgJ3ByaW1pdGl2ZVVuaXRzJywgJ3InLCAncmFkaXVzJywgJ3JlZlgnLCAncmVmWScsICdyZW5kZXJpbmdJbnRlbnQnLCAncmVwZWF0Q291bnQnLCAncmVwZWF0RHVyJywgJ3JlcXVpcmVkRXh0ZW5zaW9ucycsICdyZXF1aXJlZEZlYXR1cmVzJywgJ3Jlc3RhcnQnLCAncmVzdWx0JywgJ3JvdGF0ZScsICdyeCcsICdyeScsICdzZWVkJywgJ3NoYXBlUmVuZGVyaW5nJywgJ3Nsb3BlJywgJ3NwYWNpbmcnLCAnc3BlY3VsYXJDb25zdGFudCcsICdzcGVjdWxhckV4cG9uZW50JywgJ3NwZWVkJywgJ3NwcmVhZE1ldGhvZCcsICdzdGFydE9mZnNldCcsICdzdGREZXZpYXRpb24nLCAnc3RlbWgnLCAnc3RlbXYnLCAnc3RpdGNoVGlsZXMnLCAnc3RvcENvbG9yJywgJ3N0b3BPcGFjaXR5JywgJ3N0cmlrZXRocm91Z2hQb3NpdGlvbicsICdzdHJpa2V0aHJvdWdoVGhpY2tuZXNzJywgJ3N0cmluZycsICdzdHJva2UnLCAnc3Ryb2tlRGFzaGFycmF5JywgJ3N0cm9rZURhc2hvZmZzZXQnLCAnc3Ryb2tlTGluZWNhcCcsICdzdHJva2VMaW5lam9pbicsICdzdHJva2VNaXRlcmxpbWl0JywgJ3N0cm9rZU9wYWNpdHknLCAnc3Ryb2tlV2lkdGgnLCAnc3VyZmFjZVNjYWxlJywgJ3N5c3RlbUxhbmd1YWdlJywgJ3RhYmxlVmFsdWVzJywgJ3RhcmdldFgnLCAndGFyZ2V0WScsICd0ZXh0QW5jaG9yJywgJ3RleHREZWNvcmF0aW9uJywgJ3RleHRMZW5ndGgnLCAndGV4dFJlbmRlcmluZycsICd0bycsICd0cmFuc2Zvcm0nLCAndTEnLCAndTInLCAndW5kZXJsaW5lUG9zaXRpb24nLCAndW5kZXJsaW5lVGhpY2tuZXNzJywgJ3VuaWNvZGUnLCAndW5pY29kZUJpZGknLCAndW5pY29kZVJhbmdlJywgJ3VuaXRzUGVyRW0nLCAndkFscGhhYmV0aWMnLCAndmFsdWVzJywgJ3ZlY3RvckVmZmVjdCcsICd2ZXJzaW9uJywgJ3ZlcnRBZHZZJywgJ3ZlcnRPcmlnaW5YJywgJ3ZlcnRPcmlnaW5ZJywgJ3ZIYW5naW5nJywgJ3ZJZGVvZ3JhcGhpYycsICd2aWV3VGFyZ2V0JywgJ3Zpc2liaWxpdHknLCAndk1hdGhlbWF0aWNhbCcsICd3aWR0aHMnLCAnd29yZFNwYWNpbmcnLCAnd3JpdGluZ01vZGUnLCAneDEnLCAneDInLCAneCcsICd4Q2hhbm5lbFNlbGVjdG9yJywgJ3hIZWlnaHQnLCAneGxpbmtBY3R1YXRlJywgJ3hsaW5rQXJjcm9sZScsICd4bGlua0hyZWYnLCAneGxpbmtSb2xlJywgJ3hsaW5rU2hvdycsICd4bGlua1RpdGxlJywgJ3hsaW5rVHlwZScsICd4bWxCYXNlJywgJ3htbExhbmcnLCAneG1sbnMnLCAneG1sbnNYbGluaycsICd4bWxTcGFjZScsICd5MScsICd5MicsICd5JywgJ3lDaGFubmVsU2VsZWN0b3InLCAneicsICd6b29tQW5kUGFuJywgJ3JlZicsICdrZXknLCAnYW5nbGUnXTtcbmV4cG9ydCBmdW5jdGlvbiBpc1N2Z0VsZW1lbnRQcm9wS2V5KGtleSkge1xuICBpZiAodHlwZW9mIGtleSAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgdmFyIGFsbG93ZWRTdmdLZXlzID0gU1ZHRWxlbWVudFByb3BLZXlzO1xuICByZXR1cm4gYWxsb3dlZFN2Z0tleXMuaW5jbHVkZXMoa2V5KTtcbn1cbi8qKlxuICogQ2hlY2tzIGlmIHRoZSBwcm9wZXJ0eSBpcyBhIGRhdGEgYXR0cmlidXRlLlxuICogQHBhcmFtIGtleSBUaGUgcHJvcGVydHkga2V5LlxuICogQHJldHVybnMgVHJ1ZSBpZiB0aGUga2V5IHN0YXJ0cyB3aXRoICdkYXRhLScsIGZhbHNlIG90aGVyd2lzZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzRGF0YUF0dHJpYnV0ZShrZXkpIHtcbiAgcmV0dXJuIHR5cGVvZiBrZXkgPT09ICdzdHJpbmcnICYmIGtleS5zdGFydHNXaXRoKCdkYXRhLScpO1xufVxuXG4vKipcbiAqIEZpbHRlcnMgYW4gb2JqZWN0IHRvIG9ubHkgaW5jbHVkZSBTVkcgcHJvcGVydGllcy4gUmVtb3ZlcyBhbGwgZXZlbnQgaGFuZGxlcnMgdG9vLlxuICogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gZmlsdGVyXG4gKiBAcmV0dXJucyBBIG5ldyBvYmplY3QgY29udGFpbmluZyBvbmx5IHZhbGlkIFNWRyBwcm9wZXJ0aWVzLCBleGNsdWRpbmcgZXZlbnQgaGFuZGxlcnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdmdQcm9wZXJ0aWVzTm9FdmVudHMob2JqKSB7XG4gIHZhciBmaWx0ZXJlZEVudHJpZXMgPSBPYmplY3QuZW50cmllcyhvYmopLmZpbHRlcihfcmVmID0+IHtcbiAgICB2YXIgW2tleV0gPSBfcmVmO1xuICAgIHJldHVybiBpc1N2Z0VsZW1lbnRQcm9wS2V5KGtleSkgfHwgaXNEYXRhQXR0cmlidXRlKGtleSk7XG4gIH0pO1xuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKGZpbHRlcmVkRW50cmllcyk7XG59XG5cbi8qKlxuICogRnVuY3Rpb24gdG8gZmlsdGVyIFNWRyBwcm9wZXJ0aWVzIGZyb20gdmFyaW91cyBpbnB1dCB0eXBlcy5cbiAqIFRoZSBpbnB1dCB0eXBlcyBjYW4gYmU6XG4gKiAtIEEgcmVjb3JkIG9mIHN0cmluZyBrZXlzIHRvIGFueSB2YWx1ZXMsIGluIHdoaWNoIGNhc2UgaXQgcmV0dXJucyBhIHJlY29yZCBvZiBvbmx5IFNWRyBwcm9wZXJ0aWVzXG4gKiAtIEEgUmVhY3QgZWxlbWVudCwgaW4gd2hpY2ggY2FzZSBpdCByZXR1cm5zIHRoZSBwcm9wcyBvZiB0aGUgZWxlbWVudCBmaWx0ZXJlZCB0byBvbmx5IFNWRyBwcm9wZXJ0aWVzXG4gKiAtIEFueXRoaW5nIGVsc2UsIGluIHdoaWNoIGNhc2UgaXQgcmV0dXJucyBudWxsXG4gKlxuICogVGhpcyBmdW5jdGlvbiBoYXMgYSB3aWRlLW9wZW4gcmV0dXJuIHR5cGUsIGJlY2F1c2UgaXQgd2lsbCByZWFkIGFuZCBmaWx0ZXIgdGhlIHByb3BzIG9mIGFuIGFyYml0cmFyeSBSZWFjdCBlbGVtZW50LlxuICogVGhpcyBjYW4gYmUgU1ZHLCBIVE1MLCB3aGF0bm90LCB3aXRoIGFyYml0cmFyeSB2YWx1ZXMsIHNvIHdlIGNhbid0IHR5cGUgaXQgbW9yZSBzcGVjaWZpY2FsbHkuXG4gKlxuICogSWYgeW91IHdpc2ggdG8gaGF2ZSBhIHR5cGUtc2FmZSB2ZXJzaW9uLCB1c2Ugc3ZnUHJvcGVydGllc05vRXZlbnRzIGRpcmVjdGx5IHdpdGggYSB0eXBlZCBvYmplY3QuXG4gKlxuICogQHBhcmFtIGlucHV0IC0gVGhlIGlucHV0IHRvIGZpbHRlciwgd2hpY2ggY2FuIGJlIGEgcmVjb3JkLCBhIFJlYWN0IGVsZW1lbnQsIG9yIG90aGVyIHR5cGVzLlxuICogQHJldHVybnMgQSByZWNvcmQgb2YgU1ZHIHByb3BlcnRpZXMgaWYgdGhlIGlucHV0IGlzIGEgcmVjb3JkIG9yIFJlYWN0IGVsZW1lbnQsIG90aGVyd2lzZSBudWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3ZnUHJvcGVydGllc05vRXZlbnRzRnJvbVVua25vd24oaW5wdXQpIHtcbiAgaWYgKGlucHV0ID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGlucHV0KSAmJiB0eXBlb2YgaW5wdXQucHJvcHMgPT09ICdvYmplY3QnICYmIGlucHV0LnByb3BzICE9PSBudWxsKSB7XG4gICAgdmFyIHAgPSBpbnB1dC5wcm9wcztcbiAgICByZXR1cm4gc3ZnUHJvcGVydGllc05vRXZlbnRzKHApO1xuICB9XG4gIGlmICh0eXBlb2YgaW5wdXQgPT09ICdvYmplY3QnICYmICFBcnJheS5pc0FycmF5KGlucHV0KSkge1xuICAgIHJldHVybiBzdmdQcm9wZXJ0aWVzTm9FdmVudHMoaW5wdXQpO1xuICB9XG4gIHJldHVybiBudWxsO1xufSIsImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VBcHBEaXNwYXRjaCwgdXNlQXBwU2VsZWN0b3IgfSBmcm9tICcuLi9zdGF0ZS9ob29rcyc7XG5pbXBvcnQgeyBzZWxlY3RDb250YWluZXJTY2FsZSB9IGZyb20gJy4uL3N0YXRlL3NlbGVjdG9ycy9jb250YWluZXJTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2V0U2NhbGUgfSBmcm9tICcuLi9zdGF0ZS9sYXlvdXRTbGljZSc7XG5pbXBvcnQgeyBpc1dlbGxCZWhhdmVkTnVtYmVyIH0gZnJvbSAnLi9pc1dlbGxCZWhhdmVkTnVtYmVyJztcbmV4cG9ydCBmdW5jdGlvbiB1c2VSZXBvcnRTY2FsZSgpIHtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdmFyIFtyZWYsIHNldFJlZl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgdmFyIHNjYWxlID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0Q29udGFpbmVyU2NhbGUpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChyZWYgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgcmVjdCA9IHJlZi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICB2YXIgbmV3U2NhbGUgPSByZWN0LndpZHRoIC8gcmVmLm9mZnNldFdpZHRoO1xuICAgIGlmIChpc1dlbGxCZWhhdmVkTnVtYmVyKG5ld1NjYWxlKSAmJiBuZXdTY2FsZSAhPT0gc2NhbGUpIHtcbiAgICAgIGRpc3BhdGNoKHNldFNjYWxlKG5ld1NjYWxlKSk7XG4gICAgfVxuICB9LCBbcmVmLCBkaXNwYXRjaCwgc2NhbGVdKTtcbiAgcmV0dXJuIHNldFJlZjtcbn0iLCJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG52YXIgRVBTID0gMTtcblxuLyoqXG4gKiBUT0RPIHRoaXMgZG9jdW1lbnRhdGlvbiBkb2VzIG5vdCByZWZsZWN0IHdoYXQgdGhpcyBob29rIGlzIGRvaW5nLCB1cGRhdGUgaXQuXG4gKiBTdG9yZXMgdGhlIGBvZmZzZXRIZWlnaHRgLCBgb2Zmc2V0TGVmdGAsIGBvZmZzZXRUb3BgLCBhbmQgYG9mZnNldFdpZHRoYCBvZiBhIERPTSBlbGVtZW50LlxuICovXG5cbi8qKlxuICogVXNlIHRoaXMgdG8gbGlzdGVuIHRvIGVsZW1lbnQgbGF5b3V0IGNoYW5nZXMuXG4gKlxuICogVmVyeSB1c2VmdWwgZm9yIHJlYWRpbmcgYWN0dWFsIHNpemVzIG9mIERPTSBlbGVtZW50cyByZWxhdGl2ZSB0byB0aGUgdmlld3BvcnQuXG4gKlxuICogQHBhcmFtIGV4dHJhRGVwZW5kZW5jaWVzIHVzZSB0aGlzIHRvIHRyaWdnZXIgbmV3IERPTSBkaW1lbnNpb25zIHJlYWQgd2hlbiBhbnkgb2YgdGhlc2UgY2hhbmdlLiBHb29kIGZvciB0aGluZ3MgbGlrZSBwYXlsb2FkIGFuZCBsYWJlbCwgdGhhdCB3aWxsIHJlLXJlbmRlciBzb21ldGhpbmcgZG93biBpbiB0aGUgY2hpbGRyZW4gYXJyYXksIGJ1dCB5b3Ugd2FudCB0byByZWFkIHRoZSBsYXlvdXQgYm94IG9mIGEgcGFyZW50LlxuICogQHJldHVybnMgW2xhc3RFbGVtZW50T2Zmc2V0LCB1cGRhdGVFbGVtZW50T2Zmc2V0XSBtb3N0IHJlY2VudCB2YWx1ZSwgYW5kIHNldHRlci4gUGFzcyB0aGUgc2V0dGVyIHRvIGEgRE9NIGVsZW1lbnQgcmVmIGxpa2UgdGhpczogYDxkaXYgcmVmPXt1cGRhdGVFbGVtZW50T2Zmc2V0fT5gXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VFbGVtZW50T2Zmc2V0KCkge1xuICB2YXIgZXh0cmFEZXBlbmRlbmNpZXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6IFtdO1xuICB2YXIgW2xhc3RCb3VuZGluZ0JveCwgc2V0TGFzdEJvdW5kaW5nQm94XSA9IHVzZVN0YXRlKHtcbiAgICBoZWlnaHQ6IDAsXG4gICAgbGVmdDogMCxcbiAgICB0b3A6IDAsXG4gICAgd2lkdGg6IDBcbiAgfSk7XG4gIHZhciB1cGRhdGVCb3VuZGluZ0JveCA9IHVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmIChub2RlICE9IG51bGwpIHtcbiAgICAgIHZhciByZWN0ID0gbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIHZhciBib3ggPSB7XG4gICAgICAgIGhlaWdodDogcmVjdC5oZWlnaHQsXG4gICAgICAgIGxlZnQ6IHJlY3QubGVmdCxcbiAgICAgICAgdG9wOiByZWN0LnRvcCxcbiAgICAgICAgd2lkdGg6IHJlY3Qud2lkdGhcbiAgICAgIH07XG4gICAgICBpZiAoTWF0aC5hYnMoYm94LmhlaWdodCAtIGxhc3RCb3VuZGluZ0JveC5oZWlnaHQpID4gRVBTIHx8IE1hdGguYWJzKGJveC5sZWZ0IC0gbGFzdEJvdW5kaW5nQm94LmxlZnQpID4gRVBTIHx8IE1hdGguYWJzKGJveC50b3AgLSBsYXN0Qm91bmRpbmdCb3gudG9wKSA+IEVQUyB8fCBNYXRoLmFicyhib3gud2lkdGggLSBsYXN0Qm91bmRpbmdCb3gud2lkdGgpID4gRVBTKSB7XG4gICAgICAgIHNldExhc3RCb3VuZGluZ0JveCh7XG4gICAgICAgICAgaGVpZ2h0OiBib3guaGVpZ2h0LFxuICAgICAgICAgIGxlZnQ6IGJveC5sZWZ0LFxuICAgICAgICAgIHRvcDogYm94LnRvcCxcbiAgICAgICAgICB3aWR0aDogYm94LndpZHRoXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICBbbGFzdEJvdW5kaW5nQm94LndpZHRoLCBsYXN0Qm91bmRpbmdCb3guaGVpZ2h0LCBsYXN0Qm91bmRpbmdCb3gudG9wLCBsYXN0Qm91bmRpbmdCb3gubGVmdCwgLi4uZXh0cmFEZXBlbmRlbmNpZXNdKTtcbiAgcmV0dXJuIFtsYXN0Qm91bmRpbmdCb3gsIHVwZGF0ZUJvdW5kaW5nQm94XTtcbn0iLCIvKipcbiAqIFJldHVybnMgaWRlbnRpZmllciBmb3Igc3RhY2sgc2VyaWVzIHdoaWNoIGlzIG9uZSBpbmRpdmlkdWFsIGdyYXBoaWNhbCBpdGVtIGluIHRoZSBzdGFjay5cbiAqIEBwYXJhbSBncmFwaGljYWxJdGVtIC0gVGhlIGdyYXBoaWNhbCBpdGVtIHJlcHJlc2VudGluZyB0aGUgc2VyaWVzIGluIHRoZSBzdGFjay5cbiAqIEByZXR1cm4gVGhlIGlkZW50aWZpZXIgZm9yIHRoZSBzZXJpZXMgaW4gdGhlIHN0YWNrXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdGFja1Nlcmllc0lkZW50aWZpZXIoZ3JhcGhpY2FsSXRlbSkge1xuICByZXR1cm4gZ3JhcGhpY2FsSXRlbSA9PT0gbnVsbCB8fCBncmFwaGljYWxJdGVtID09PSB2b2lkIDAgPyB2b2lkIDAgOiBncmFwaGljYWxJdGVtLmlkO1xufSIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIG1pbWljcyB0aGUgYmVoYXZpb3Igb2YgdGhlIGBkZWZhdWx0UHJvcHNgIHN0YXRpYyBwcm9wZXJ0eSBpbiBSZWFjdC5cbiAqIEZ1bmN0aW9uYWwgY29tcG9uZW50cyBkbyBub3QgaGF2ZSBhIGRlZmF1bHRQcm9wcyBwcm9wZXJ0eSwgc28gdGhpcyBmdW5jdGlvbiBpcyB1c2VmdWwgdG8gcmVzb2x2ZSBkZWZhdWx0IHByb3BzLlxuICpcbiAqIFRoZSBjb21tb24gcmVjb21tZW5kYXRpb24gaXMgdG8gdXNlIEVTNiBkZXN0cnVjdHVyaW5nIHdpdGggZGVmYXVsdCB2YWx1ZXMgaW4gdGhlIGZ1bmN0aW9uIHNpZ25hdHVyZSxcbiAqIGJ1dCB5b3UgbmVlZCB0byBiZSBjYXJlZnVsIHRoZXJlIGFuZCBtYWtlIHN1cmUgeW91IGRlc3RydWN0dXJlIGFsbCB0aGUgaW5kaXZpZHVhbCBwcm9wZXJ0aWVzXG4gKiBhbmQgbm90IHRoZSB3aG9sZSBvYmplY3QuIFNlZSB0aGUgdGVzdCBmaWxlIGZvciBleGFtcGxlLlxuICpcbiAqIEFuZCBiZWNhdXNlIGRlc3RydWN0dXJpbmcgYWxsIHByb3BlcnRpZXMgb25lIGJ5IG9uZSBpcyBhIGZhZmYsIGFuZCBpdCdzIGVhc3kgdG8gbWlzcyBvbmUgcHJvcGVydHksXG4gKiB0aGlzIGZ1bmN0aW9uIGV4aXN0cy5cbiAqXG4gKiBAcGFyYW0gcmVhbFByb3BzIC0gdGhlIHByb3BzIG9iamVjdCBwYXNzZWQgdG8gdGhlIGNvbXBvbmVudCBieSB0aGUgdXNlclxuICogQHBhcmFtIGRlZmF1bHRQcm9wcyAtIHRoZSBkZWZhdWx0IHByb3BzIG9iamVjdCBkZWZpbmVkIGluIHRoZSBjb21wb25lbnQgYnkgUmVjaGFydHNcbiAqIEByZXR1cm5zIC0gdGhlIHByb3BzIG9iamVjdCB3aXRoIGFsbCB0aGUgZGVmYXVsdCBwcm9wcyByZXNvbHZlZC4gQWxsIGB1bmRlZmluZWRgIHZhbHVlcyBhcmUgcmVwbGFjZWQgd2l0aCB0aGUgZGVmYXVsdCB2YWx1ZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVEZWZhdWx0UHJvcHMocmVhbFByb3BzLCBkZWZhdWx0UHJvcHMpIHtcbiAgLypcbiAgICogVG8gYXZvaWQgbXV0YXRpbmcgdGhlIG9yaWdpbmFsIGByZWFsUHJvcHNgIG9iamVjdCBwYXNzZWQgdG8gdGhlIGZ1bmN0aW9uLCBjcmVhdGUgYSBzaGFsbG93IGNvcHkgb2YgaXQuXG4gICAqIGByZXNvbHZlZFByb3BzYCB3aWxsIGJlIG1vZGlmaWVkIGRpcmVjdGx5IHdpdGggdGhlIGRlZmF1bHRzLlxuICAgKi9cbiAgdmFyIHJlc29sdmVkUHJvcHMgPSBfb2JqZWN0U3ByZWFkKHt9LCByZWFsUHJvcHMpO1xuICAvKlxuICAgKiBTaW5jZSB0aGUgZnVuY3Rpb24gZ3VhcmFudGVlcyBgRCBleHRlbmRzIFBhcnRpYWw8VD5gLCB0aGlzIGFzc2lnbm1lbnQgaXMgc2FmZS5cbiAgICogSXQgYWxsb3dzIFR5cGVTY3JpcHQgdG8gd29yayB3aXRoIHRoZSB3ZWxsLWRlZmluZWQgYFBhcnRpYWw8VD5gIHR5cGUgaW5zaWRlIHRoZSBsb29wLFxuICAgKiBtYWtpbmcgc3Vic2VxdWVudCB0eXBlIGluZmVyZW5jZSAoZXNwZWNpYWxseSBmb3IgYGRwW2tleV1gKSBtdWNoIG1vcmUgc3RyYWlnaHRmb3J3YXJkIGZvciB0aGUgY29tcGlsZXIuXG4gICAqIFRoaXMgaXMgYSBrZXkgc3RlcCB0byBpbXByb3ZlIHR5cGUgc2FmZXR5ICp3aXRob3V0KiB2YWx1ZSBhc3NlcnRpb25zIGxhdGVyLlxuICAgKi9cbiAgdmFyIGRwID0gZGVmYXVsdFByb3BzO1xuICAvKlxuICAgKiBgT2JqZWN0LmtleXNgIGRvZXNuJ3QgcHJlc2VydmUgc3Ryb25nIGtleSB0eXBlcyAtIGl0IGFsd2F5cyByZXR1cm5zIEFycmF5PHN0cmluZz4uXG4gICAqIEhvd2V2ZXIsIGR1ZSB0byB0aGUgYEQgZXh0ZW5kcyBQYXJ0aWFsPFQ+YCBjb25zdHJhaW50LFxuICAgKiB3ZSBrbm93IHRoZXNlIGtleXMgKm11c3QqIGFsc28gYmUgdmFsaWQga2V5cyBvZiBgVGAuXG4gICAqIFRoaXMgYXNzZXJ0aW9uIGluZm9ybXMgVHlwZVNjcmlwdCBvZiB0aGlzIHJlbGF0aW9uc2hpcCwgYXZvaWRpbmcgdHlwZSBlcnJvcnMgd2hlbiB1c2luZyBga2V5YCB0byBpbmRleCBgYWNjYCAodHlwZSBUKS5cbiAgICpcbiAgICogVHlwZSBhc3NlcnRpb25zIGFyZSBub3Qgc291bmQgYnV0IGluIHRoaXMgY2FzZSBpdCdzIG5lY2Vzc2FyeVxuICAgKiBhcyBgT2JqZWN0LmtleXNgIGRvZXMgbm90IGRvIHdoYXQgd2Ugd2FudCBpdCB0byBkby5cbiAgICovXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXMoZGVmYXVsdFByb3BzKTtcbiAgdmFyIHdpdGhEZWZhdWx0cyA9IGtleXMucmVkdWNlKChhY2MsIGtleSkgPT4ge1xuICAgIGlmIChhY2Nba2V5XSA9PT0gdW5kZWZpbmVkICYmIGRwW2tleV0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgYWNjW2tleV0gPSBkcFtrZXldO1xuICAgIH1cbiAgICByZXR1cm4gYWNjO1xuICB9LCByZXNvbHZlZFByb3BzKTtcbiAgLypcbiAgICogQW5kIGFnYWluIHR5cGUgYXNzZXJ0aW9ucyBhcmUgbm90IHNhZmUgYnV0IGhlcmUgd2UgaGF2ZSBkb25lIHRoZSBydW50aW1lIHdvcmtcbiAgICogc28gbGV0J3MgYnlwYXNzIHRoZSBsYWNrIG9mIHN0YXRpYyB0eXBlIHNhZmV0eSBhbmQgdGVsbCB0aGUgY29tcGlsZXIgd2hhdCBoYXBwZW5lZC5cbiAgICovXG4gIHJldHVybiB3aXRoRGVmYXVsdHM7XG59XG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gZXh0cmFjdCB0aGUga2V5cyBvZiBUIHRoYXQgYXJlIHJlcXVpcmVkLlxuICogSXQgaXRlcmF0ZXMgdGhyb3VnaCBlYWNoIGtleSBLIGluIFQuIElmIFBpY2s8VCwgSz4gY2Fubm90IGJlIGFzc2lnbmVkIGFuIGVtcHR5IG9iamVjdCB7fSxcbiAqIGl0IG1lYW5zIEsgaXMgcmVxdWlyZWQsIHNvIHdlIGtlZXAgSzsgb3RoZXJ3aXNlLCB3ZSBkaXNjYXJkIGl0IChuZXZlcikuXG4gKiBba2V5b2YgVF0gYXQgdGhlIGVuZCBjcmVhdGVzIGEgdW5pb24gb2YgdGhlIGtlcHQga2V5cy5cbiAqL1xuXG4vKipcbiAqIEhlbHBlciB0eXBlIHRvIGV4dHJhY3QgdGhlIGtleXMgb2YgVCB0aGF0IGFyZSBvcHRpb25hbC5cbiAqIEl0IGl0ZXJhdGVzIHRocm91Z2ggZWFjaCBrZXkgSyBpbiBULiBJZiBQaWNrPFQsIEs+IGNhbiBiZSBhc3NpZ25lZCBhbiBlbXB0eSBvYmplY3Qge30sXG4gKiBpdCBtZWFucyBLIGlzIG9wdGlvbmFsIChvciBwb3RlbnRpYWxseSBtaXNzaW5nKSwgc28gd2Uga2VlcCBLOyBvdGhlcndpc2UsIHdlIGRpc2NhcmQgaXQgKG5ldmVyKS5cbiAqIFtrZXlvZiBUXSBhdCB0aGUgZW5kIGNyZWF0ZXMgYSB1bmlvbiBvZiB0aGUga2VwdCBrZXlzLlxuICovXG5cbi8qKlxuICogSGVscGVyIHR5cGUgdG8gZW5zdXJlIGtleXMgb2YgRCBleGlzdCBpbiBULlxuICogRm9yIGVhY2gga2V5IEsgaW4gRCwgaWYgSyBpcyBhbHNvIGEga2V5IG9mIFQsIGtlZXAgdGhlIHR5cGUgRFtLXS5cbiAqIElmIEsgaXMgTk9UIGEga2V5IG9mIFQsIG1hcCBpdCB0byB0eXBlIGBuZXZlcmAuXG4gKiBBbiBvYmplY3QgY2Fubm90IGhhdmUgYSBwcm9wZXJ0eSBvZiB0eXBlIGBuZXZlcmAsIGVmZmVjdGl2ZWx5IGRpc2FsbG93aW5nIGV4dHJhIGtleXMuXG4gKi9cblxuLyoqXG4gKiBUaGlzIHR5cGUgd2lsbCB0YWtlIGEgc291cmNlIHR5cGUgYFByb3BzYCBhbmQgYSBkZWZhdWx0IHR5cGUgYERlZmF1bHRzYCBhbmQgd2lsbCByZXR1cm4gYSBuZXcgdHlwZVxuICogd2hlcmUgYWxsIHByb3BlcnRpZXMgdGhhdCBhcmUgb3B0aW9uYWwgaW4gYFByb3BzYCBidXQgcmVxdWlyZWQgaW4gYERlZmF1bHRzYCBhcmUgbWFkZSByZXF1aXJlZCBpbiB0aGUgcmVzdWx0LlxuICogUHJvcGVydGllcyB0aGF0IGFyZSByZXF1aXJlZCBpbiBgUHJvcHNgIGFuZCBvcHRpb25hbCBpbiBgRGVmYXVsdHNgIHdpbGwgcmVtYWluIHJlcXVpcmVkLlxuICogUHJvcGVydGllcyB0aGF0IGFyZSBvcHRpb25hbCBpbiBib3RoIGBQcm9wc2AgYW5kIGBEZWZhdWx0c2Agd2lsbCByZW1haW4gb3B0aW9uYWwuXG4gKlxuICogVGhpcyBpcyB1c2VmdWwgZm9yIGNyZWF0aW5nIGEgdHlwZSB0aGF0IHJlcHJlc2VudHMgdGhlIHJlc29sdmVkIHByb3BzIG9mIGEgY29tcG9uZW50IHdpdGggZGVmYXVsdCBwcm9wcy5cbiAqLyIsImltcG9ydCB1bmlxQnkgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvdW5pcUJ5JztcblxuLyoqXG4gKiBUaGlzIGlzIGNvbmZpZ3VyYXRpb24gb3B0aW9uIHRoYXQgZGVjaWRlcyBob3cgdG8gZmlsdGVyIGZvciB1bmlxdWUgdmFsdWVzIG9ubHk6XG4gKlxuICogLSBgZmFsc2VgIG1lYW5zIFwibm8gZmlsdGVyXCJcbiAqIC0gYHRydWVgIG1lYW5zIFwidXNlIHJlY2hhcnRzIGRlZmF1bHQgZmlsdGVyXCJcbiAqIC0gZnVuY3Rpb24gbWVhbnMgXCJ1c2UgcmV0dXJuIG9mIHRoaXMgZnVuY3Rpb24gYXMgdGhlIGRlZmF1bHQga2V5XCJcbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VW5pcVBheWxvYWQocGF5bG9hZCwgb3B0aW9uLCBkZWZhdWx0VW5pcUJ5KSB7XG4gIGlmIChvcHRpb24gPT09IHRydWUpIHtcbiAgICByZXR1cm4gdW5pcUJ5KHBheWxvYWQsIGRlZmF1bHRVbmlxQnkpO1xuICB9XG4gIGlmICh0eXBlb2Ygb3B0aW9uID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIHVuaXFCeShwYXlsb2FkLCBvcHRpb24pO1xuICB9XG4gIHJldHVybiBwYXlsb2FkO1xufSIsImltcG9ydCB7IGlzVmFsaWRFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaXNFdmVudEtleSB9IGZyb20gJy4vZXhjbHVkZUV2ZW50UHJvcHMnO1xuaW1wb3J0IHsgaXNEYXRhQXR0cmlidXRlLCBpc1N2Z0VsZW1lbnRQcm9wS2V5IH0gZnJvbSAnLi9zdmdQcm9wZXJ0aWVzTm9FdmVudHMnO1xuLyoqXG4gKiBGaWx0ZXJzIGFuIG9iamVjdCB0byBvbmx5IGluY2x1ZGUgU1ZHIHByb3BlcnRpZXMsIGRhdGEgYXR0cmlidXRlcywgYW5kIGV2ZW50IGhhbmRsZXJzLlxuICogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gZmlsdGVyLlxuICogQHJldHVybnMgQSBuZXcgb2JqZWN0IGNvbnRhaW5pbmcgb25seSB2YWxpZCBTVkcgcHJvcGVydGllcywgZGF0YSBhdHRyaWJ1dGVzLCBhbmQgZXZlbnQgaGFuZGxlcnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdmdQcm9wZXJ0aWVzQW5kRXZlbnRzKG9iaikge1xuICB2YXIgZmlsdGVyZWRFbnRyaWVzID0gT2JqZWN0LmVudHJpZXMob2JqKS5maWx0ZXIoX3JlZiA9PiB7XG4gICAgdmFyIFtrZXldID0gX3JlZjtcbiAgICByZXR1cm4gaXNTdmdFbGVtZW50UHJvcEtleShrZXkpIHx8IGlzRGF0YUF0dHJpYnV0ZShrZXkpIHx8IGlzRXZlbnRLZXkoa2V5KTtcbiAgfSk7XG4gIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoZmlsdGVyZWRFbnRyaWVzKTtcbn1cblxuLyoqXG4gKiBGdW5jdGlvbiB0byBmaWx0ZXIgU1ZHIHByb3BlcnRpZXMgZnJvbSB2YXJpb3VzIGlucHV0IHR5cGVzLlxuICogVGhlIGlucHV0IHR5cGVzIGNhbiBiZTpcbiAqIC0gQSByZWNvcmQgb2Ygc3RyaW5nIGtleXMgdG8gYW55IHZhbHVlcywgaW4gd2hpY2ggY2FzZSBpdCByZXR1cm5zIGEgcmVjb3JkIG9mIG9ubHkgU1ZHIHByb3BlcnRpZXNcbiAqIC0gQSBSZWFjdCBlbGVtZW50LCBpbiB3aGljaCBjYXNlIGl0IHJldHVybnMgdGhlIHByb3BzIG9mIHRoZSBlbGVtZW50IGZpbHRlcmVkIHRvIG9ubHkgU1ZHIHByb3BlcnRpZXNcbiAqIC0gQW55dGhpbmcgZWxzZSwgaW4gd2hpY2ggY2FzZSBpdCByZXR1cm5zIG51bGxcbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIGhhcyBhIHdpZGUtb3BlbiByZXR1cm4gdHlwZSwgYmVjYXVzZSBpdCB3aWxsIHJlYWQgYW5kIGZpbHRlciB0aGUgcHJvcHMgb2YgYW4gYXJiaXRyYXJ5IFJlYWN0IGVsZW1lbnQuXG4gKiBUaGlzIGNhbiBiZSBTVkcsIEhUTUwsIHdoYXRub3QsIHdpdGggYXJiaXRyYXJ5IHZhbHVlcywgc28gd2UgY2FuJ3QgdHlwZSBpdCBtb3JlIHNwZWNpZmljYWxseS5cbiAqXG4gKiBJZiB5b3Ugd2lzaCB0byBoYXZlIGEgdHlwZS1zYWZlIHZlcnNpb24sIHVzZSBzdmdQcm9wZXJ0aWVzTm9FdmVudHMgZGlyZWN0bHkgd2l0aCBhIHR5cGVkIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0gaW5wdXQgLSBUaGUgaW5wdXQgdG8gZmlsdGVyLCB3aGljaCBjYW4gYmUgYSByZWNvcmQsIGEgUmVhY3QgZWxlbWVudCwgb3Igb3RoZXIgdHlwZXMuXG4gKiBAcmV0dXJucyBBIHJlY29yZCBvZiBTVkcgcHJvcGVydGllcyBpZiB0aGUgaW5wdXQgaXMgYSByZWNvcmQgb3IgUmVhY3QgZWxlbWVudCwgb3RoZXJ3aXNlIG51bGwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdmdQcm9wZXJ0aWVzQW5kRXZlbnRzRnJvbVVua25vd24oaW5wdXQpIHtcbiAgaWYgKGlucHV0ID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KGlucHV0KSkge1xuICAgIHJldHVybiBzdmdQcm9wZXJ0aWVzQW5kRXZlbnRzKGlucHV0LnByb3BzKTtcbiAgfVxuICBpZiAodHlwZW9mIGlucHV0ID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShpbnB1dCkpIHtcbiAgICByZXR1cm4gc3ZnUHJvcGVydGllc0FuZEV2ZW50cyhpbnB1dCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59IiwidmFyIF9yZWY7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1bmlxdWVJZCB9IGZyb20gJy4vRGF0YVV0aWxzJztcblxuLyoqXG4gKiBGYWxsYmFjayBmb3IgUmVhY3QudXNlSWQoKSBmb3IgdmVyc2lvbnMgcHJpb3IgdG8gUmVhY3QgMTguXG4gKiBHZW5lcmF0ZXMgYSB1bmlxdWUgSUQgdXNpbmcgYSBzaW1wbGUgY291bnRlciBhbmQgYSBwcmVmaXguXG4gKlxuICogQHJldHVybnMgQSB1bmlxdWUgSUQgdGhhdCByZW1haW5zIGNvbnNpc3RlbnQgYWNyb3NzIHJlbmRlcnMuXG4gKi9cbmV4cG9ydCB2YXIgdXNlSWRGYWxsYmFjayA9ICgpID0+IHtcbiAgdmFyIFtpZF0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiB1bmlxdWVJZCgndWlkLScpKTtcbiAgcmV0dXJuIGlkO1xufTtcblxuLypcbiAqIFRoaXMgd2VpcmQgc3ludGF4IGlzIHVzZWQgdG8gYXZvaWQgYSBidWlsZC10aW1lIGVycm9yIGluIFJlYWN0IDE3IGFuZCBlYXJsaWVyIHdoZW4gYnVpbGRpbmcgd2l0aCBXZWJwYWNrLlxuICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS93ZWJwYWNrL3dlYnBhY2svaXNzdWVzLzE0ODE0XG4gKi9cbmV4cG9ydCB2YXIgdXNlSWQgPSAoX3JlZiA9IFJlYWN0Wyd1c2VJZCcudG9TdHJpbmcoKV0pICE9PSBudWxsICYmIF9yZWYgIT09IHZvaWQgMCA/IF9yZWYgOiB1c2VJZEZhbGxiYWNrOyIsImltcG9ydCB7IHVzZUlkIH0gZnJvbSAnLi91c2VJZCc7XG5cbi8qKlxuICogQSBob29rIHRoYXQgZ2VuZXJhdGVzIGEgdW5pcXVlIElELiBJdCB1c2VzIFJlYWN0LnVzZUlkKCkgaW4gUmVhY3QgMTgrIGZvciBTU1Igc2FmZXR5XG4gKiBhbmQgZmFsbHMgYmFjayB0byBhIGNsaWVudC1zaWRlLW9ubHkgdW5pcXVlIElEIGdlbmVyYXRvciBmb3Igb2xkZXIgdmVyc2lvbnMuXG4gKlxuICogVGhlIElEIHdpbGwgc3RheSB0aGUgc2FtZSBhY3Jvc3MgcmVuZGVycywgYW5kIHlvdSBjYW4gb3B0aW9uYWxseSBwcm92aWRlIGEgcHJlZml4LlxuICpcbiAqIEBwYXJhbSBbcHJlZml4XSAtIEFuIG9wdGlvbmFsIHByZWZpeCBmb3IgdGhlIGdlbmVyYXRlZCBJRC5cbiAqIEBwYXJhbSBbY3VzdG9tSWRdIC0gQW4gb3B0aW9uYWwgY3VzdG9tIElEIHRvIG92ZXJyaWRlIHRoZSBnZW5lcmF0ZWQgb25lLlxuICogQHJldHVybnMgVGhlIHVuaXF1ZSBJRC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVVuaXF1ZUlkKHByZWZpeCwgY3VzdG9tSWQpIHtcbiAgLypcbiAgICogV2UgaGF2ZSB0byBjYWxsIHRoaXMgaG9vayBoZXJlIGV2ZW4gaWYgd2UgZG9uJ3QgdXNlIHRoZSByZXN1bHQgYmVjYXVzZVxuICAgKiBydWxlcyBvZiBob29rcyBkZW1hbmQgdGhhdCBob29rcyBhcmUgbmV2ZXIgY2FsbGVkIGNvbmRpdGlvbmFsbHkuXG4gICAqL1xuICB2YXIgZ2VuZXJhdGVkSWQgPSB1c2VJZCgpO1xuXG4gIC8vIElmIGEgY3VzdG9tIElEIGlzIHByb3ZpZGVkLCBpdCBhbHdheXMgdGFrZXMgcHJlY2VkZW5jZS5cbiAgaWYgKGN1c3RvbUlkKSB7XG4gICAgcmV0dXJuIGN1c3RvbUlkO1xuICB9XG5cbiAgLy8gQXBwbHkgdGhlIHByZWZpeCBpZiBvbmUgd2FzIHByb3ZpZGVkLlxuICByZXR1cm4gcHJlZml4ID8gXCJcIi5jb25jYXQocHJlZml4LCBcIi1cIikuY29uY2F0KGdlbmVyYXRlZElkKSA6IGdlbmVyYXRlZElkO1xufVxuXG4vKipcbiAqIFRoZSB1c2VVbmlxdWVJZCBob29rIHJldHVybnMgYSB1bmlxdWUgSUQgdGhhdCBpcyBlaXRoZXIgcmV1c2VkIGZyb20gZXh0ZXJuYWwgcHJvcHMgb3IgZ2VuZXJhdGVkIGludGVybmFsbHkuXG4gKiBFaXRoZXIgd2F5IHRoZSBJRCBpcyBub3cgZ3VhcmFudGVlZCB0byBiZSBwcmVzZW50IHNvIG5vIG1vcmUgbnVsbHMgb3IgdW5kZWZpbmVkLlxuICovIiwiaW1wb3J0IHsgTUFYX1ZBTFVFX1JFRywgTUlOX1ZBTFVFX1JFRyB9IGZyb20gJy4vQ2hhcnRVdGlscyc7XG5pbXBvcnQgeyBpc051bWJlciB9IGZyb20gJy4vRGF0YVV0aWxzJztcbmltcG9ydCB7IGlzV2VsbEJlaGF2ZWROdW1iZXIgfSBmcm9tICcuL2lzV2VsbEJlaGF2ZWROdW1iZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGlzV2VsbEZvcm1lZE51bWJlckRvbWFpbih2KSB7XG4gIGlmIChBcnJheS5pc0FycmF5KHYpICYmIHYubGVuZ3RoID09PSAyKSB7XG4gICAgdmFyIFttaW4sIG1heF0gPSB2O1xuICAgIGlmIChpc1dlbGxCZWhhdmVkTnVtYmVyKG1pbikgJiYgaXNXZWxsQmVoYXZlZE51bWJlcihtYXgpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGV4dGVuZERvbWFpbihwcm92aWRlZERvbWFpbiwgYm91bmRhcnlEb21haW4sIGFsbG93RGF0YU92ZXJmbG93KSB7XG4gIGlmIChhbGxvd0RhdGFPdmVyZmxvdykge1xuICAgIC8vIElmIHRoZSBkYXRhIGFyZSBhbGxvd2VkIHRvIG92ZXJmbG93IC0gd2UncmUgZmluZSB3aXRoIHdoYXRldmVyIHVzZXIgcHJvdmlkZWRcbiAgICByZXR1cm4gcHJvdmlkZWREb21haW47XG4gIH1cbiAgLypcbiAgICogSWYgdGhlIGRhdGEgYXJlIG5vdCBhbGxvd2VkIHRvIG92ZXJmbG93IC0gd2UgbmVlZCB0byBleHRlbmQgdGhlIGRvbWFpbi5cbiAgICogTWVhbnMgdGhhdCBlZmZlY3RpdmVseSB0aGUgdXNlciBpcyBhbGxvd2VkIHRvIG1ha2UgdGhlIGRvbWFpbiBsYXJnZXJcbiAgICogYnV0IG5vdCBzbWFsbGVyLlxuICAgKi9cbiAgcmV0dXJuIFtNYXRoLm1pbihwcm92aWRlZERvbWFpblswXSwgYm91bmRhcnlEb21haW5bMF0pLCBNYXRoLm1heChwcm92aWRlZERvbWFpblsxXSwgYm91bmRhcnlEb21haW5bMV0pXTtcbn1cblxuLyoqXG4gKiBTbyBSZWNoYXJ0cyBhbGxvd3MgdXNlcnMgdG8gcHJvdmlkZSB0aGVpciBvd24gZG9tYWlucyxcbiAqIGJ1dCBpdCBhbHNvIHBsYWNlcyBzb21lIGV4cGVjdGF0aW9ucyBvbiB3aGF0IHRoZSBkb21haW4gaXMuXG4gKiBXZSBjYW4gaW1wcm92ZSBvbiB0aGUgdHlwZXNjcmlwdCB0eXBpbmcsIGJ1dCB3ZSBhbHNvIG5lZWQgYSBydW50aW1lIHRlc3RcbiB0byBvYnNlcnZlIHRoYXQgdGhlIHVzZXItcHJvdmlkZWQgZG9tYWluIGlzIHdlbGwtZm9ybWVkLFxuICogdGhhdCBpczogYW4gYXJyYXkgd2l0aCBleGFjdGx5IHR3byBudW1iZXJzLlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gZG9lcyBub3QgYWNjZXB0IGRhdGEgYXMgYW4gYXJndW1lbnQuXG4gKiBUaGlzIGlzIHRvIGVuYWJsZSBhIHBlcmZvcm1hbmNlIG9wdGltaXphdGlvbiAtIGlmIHRoZSBkb21haW4gaXMgdGhlcmUsXG4gKiBhbmQgd2Uga25vdyB3aGF0IGl0IGlzIHdpdGhvdXQgdHJhdmVyc2luZyBhbGwgdGhlIGRhdGEsXG4gKiB0aGVuIHdlIGRvbid0IGhhdmUgdG8gdHJhdmVyc2UgYWxsIHRoZSBkYXRhIVxuICpcbiAqIElmIHRoZSB1c2VyLXByb3ZpZGVkIGRvbWFpbiBpcyBub3Qgd2VsbC1mb3JtZWQsXG4gKiB0aGlzIGZ1bmN0aW9uIHdpbGwgcmV0dXJuIHVuZGVmaW5lZCAtIGluIHdoaWNoIGNhc2Ugd2Ugc2hvdWxkIHRyYXZlcnNlIHRoZSBkYXRhIHRvIGNhbGN1bGF0ZSB0aGUgcmVhbCBkb21haW4uXG4gKlxuICogVGhpcyBmdW5jdGlvbiBpcyBmb3IgcGFyc2luZyB0aGUgbnVtZXJpY2FsIGRvbWFpbiBvbmx5LlxuICpcbiAqIEBwYXJhbSB1c2VyRG9tYWluIGV4dGVybmFsIHByb3AsIHVzZXIgcHJvdmlkZWQsIGJlZm9yZSB2YWxpZGF0aW9uLiBDYW4gaGF2ZSB2YXJpb3VzIHNoYXBlczogYXJyYXksIGZ1bmN0aW9uLCBzcGVjaWFsIG1hZ2ljYWwgc3RyaW5ncyBpbnNpZGUgdG9vLlxuICogQHBhcmFtIGFsbG93RGF0YU92ZXJmbG93IGJvb2xlYW4sIHByb3ZpZGVkIGJ5IHVzZXJzLiBJZiB0cnVlIHRoZW4gdGhlIGRhdGEgZG9tYWluIHdpbnNcbiAqXG4gKiBAcmV0dXJuIFttaW4sIG1heF0gZG9tYWluIGlmIGl0J3Mgd2VsbC1mb3JtZWQ7IHVuZGVmaW5lZCBpZiB0aGUgZG9tYWluIGlzIGludmFsaWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG51bWVyaWNhbERvbWFpblNwZWNpZmllZFdpdGhvdXRSZXF1aXJpbmdEYXRhKHVzZXJEb21haW4sIGFsbG93RGF0YU92ZXJmbG93KSB7XG4gIGlmICghYWxsb3dEYXRhT3ZlcmZsb3cpIHtcbiAgICAvLyBDYW5ub3QgY29tcHV0ZSBkYXRhIG92ZXJmbG93IGlmIHRoZSBkYXRhIGlzIG5vdCBwcm92aWRlZFxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKHR5cGVvZiB1c2VyRG9tYWluID09PSAnZnVuY3Rpb24nKSB7XG4gICAgLy8gVGhlIHVzZXIgZnVuY3Rpb24gZXhwZWN0cyB0aGUgZGF0YSB0byBiZSBwcm92aWRlZCBhcyBhbiBhcmd1bWVudFxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodXNlckRvbWFpbikgJiYgdXNlckRvbWFpbi5sZW5ndGggPT09IDIpIHtcbiAgICB2YXIgW3Byb3ZpZGVkTWluLCBwcm92aWRlZE1heF0gPSB1c2VyRG9tYWluO1xuICAgIHZhciBmaW5hbE1pbiwgZmluYWxNYXg7XG4gICAgaWYgKGlzV2VsbEJlaGF2ZWROdW1iZXIocHJvdmlkZWRNaW4pKSB7XG4gICAgICBmaW5hbE1pbiA9IHByb3ZpZGVkTWluO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHByb3ZpZGVkTWluID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAvLyBUaGUgdXNlciBmdW5jdGlvbiBleHBlY3RzIHRoZSBkYXRhIHRvIGJlIHByb3ZpZGVkIGFzIGFuIGFyZ3VtZW50XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoaXNXZWxsQmVoYXZlZE51bWJlcihwcm92aWRlZE1heCkpIHtcbiAgICAgIGZpbmFsTWF4ID0gcHJvdmlkZWRNYXg7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgcHJvdmlkZWRNYXggPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIC8vIFRoZSB1c2VyIGZ1bmN0aW9uIGV4cGVjdHMgdGhlIGRhdGEgdG8gYmUgcHJvdmlkZWQgYXMgYW4gYXJndW1lbnRcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHZhciBjYW5kaWRhdGUgPSBbZmluYWxNaW4sIGZpbmFsTWF4XTtcbiAgICBpZiAoaXNXZWxsRm9ybWVkTnVtYmVyRG9tYWluKGNhbmRpZGF0ZSkpIHtcbiAgICAgIHJldHVybiBjYW5kaWRhdGU7XG4gICAgfVxuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG5cbi8qKlxuICogU28gUmVjaGFydHMgYWxsb3dzIHVzZXJzIHRvIHByb3ZpZGUgdGhlaXIgb3duIGRvbWFpbnMsXG4gKiBidXQgaXQgYWxzbyBwbGFjZXMgc29tZSBleHBlY3RhdGlvbnMgb24gd2hhdCB0aGUgZG9tYWluIGlzLlxuICogV2UgY2FuIGltcHJvdmUgb24gdGhlIHR5cGVzY3JpcHQgdHlwaW5nLCBidXQgd2UgYWxzbyBuZWVkIGEgcnVudGltZSB0ZXN0XG4gKiB0byBvYnNlcnZlIHRoYXQgdGhlIHVzZXItcHJvdmlkZWQgZG9tYWluIGlzIHdlbGwtZm9ybWVkLFxuICogdGhhdCBpczogYW4gYXJyYXkgd2l0aCBleGFjdGx5IHR3byBudW1iZXJzLlxuICogSWYgdGhlIHVzZXItcHJvdmlkZWQgZG9tYWluIGlzIG5vdCB3ZWxsLWZvcm1lZCxcbiAqIHRoaXMgZnVuY3Rpb24gd2lsbCByZXR1cm4gdW5kZWZpbmVkIC0gaW4gd2hpY2ggY2FzZSB3ZSBzaG91bGQgdHJhdmVyc2UgdGhlIGRhdGEgdG8gY2FsY3VsYXRlIHRoZSByZWFsIGRvbWFpbi5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIGlzIGZvciBwYXJzaW5nIHRoZSBudW1lcmljYWwgZG9tYWluIG9ubHkuXG4gKlxuICogWW91IGFyZSBwcm9iYWJseSB0aGlua2luZywgd2h5IGRvZXMgZG9tYWluIG5lZWQgdGljayBjb3VudD9cbiAqIFdlbGwgaXQgYWRqdXN0cyB0aGUgZG9tYWluIGJhc2VkIG9uIHdoZXJlIHRoZSBcIm5pY2UgdGlja3NcIiBsYW5kLCBhbmQgbmljZSB0aWNrcyBkZXBlbmQgb24gdGhlIHRpY2sgY291bnQuXG4gKlxuICogQHBhcmFtIHVzZXJEb21haW4gZXh0ZXJuYWwgcHJvcCwgdXNlciBwcm92aWRlZCwgYmVmb3JlIHZhbGlkYXRpb24uIENhbiBoYXZlIHZhcmlvdXMgc2hhcGVzOiBhcnJheSwgZnVuY3Rpb24sIHNwZWNpYWwgbWFnaWNhbCBzdHJpbmdzIGluc2lkZSB0b28uXG4gKiBAcGFyYW0gZGF0YURvbWFpbiBjYWxjdWxhdGVkIGZyb20gZGF0YS4gQ2FuIGJlIHVuZGVmaW5lZCwgYXMgYW4gb3B0aW9uIGZvciBwZXJmb3JtYW5jZSBvcHRpbWl6YXRpb25cbiAqIEBwYXJhbSBhbGxvd0RhdGFPdmVyZmxvdyBwcm92aWRlZCBieSB1c2Vycy4gSWYgdHJ1ZSB0aGVuIHRoZSBkYXRhIGRvbWFpbiB3aW5zXG4gKlxuICogQHJldHVybiBbbWluLCBtYXhdIGRvbWFpbiBpZiBpdCdzIHdlbGwtZm9ybWVkOyB1bmRlZmluZWQgaWYgdGhlIGRvbWFpbiBpcyBpbnZhbGlkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZU51bWVyaWNhbFVzZXJEb21haW4odXNlckRvbWFpbiwgZGF0YURvbWFpbiwgYWxsb3dEYXRhT3ZlcmZsb3cpIHtcbiAgaWYgKCFhbGxvd0RhdGFPdmVyZmxvdyAmJiBkYXRhRG9tYWluID09IG51bGwpIHtcbiAgICAvLyBDYW5ub3QgY29tcHV0ZSBkYXRhIG92ZXJmbG93IGlmIHRoZSBkYXRhIGlzIG5vdCBwcm92aWRlZFxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKHR5cGVvZiB1c2VyRG9tYWluID09PSAnZnVuY3Rpb24nICYmIGRhdGFEb21haW4gIT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICB2YXIgcmVzdWx0ID0gdXNlckRvbWFpbihkYXRhRG9tYWluLCBhbGxvd0RhdGFPdmVyZmxvdyk7XG4gICAgICBpZiAoaXNXZWxsRm9ybWVkTnVtYmVyRG9tYWluKHJlc3VsdCkpIHtcbiAgICAgICAgcmV0dXJuIGV4dGVuZERvbWFpbihyZXN1bHQsIGRhdGFEb21haW4sIGFsbG93RGF0YU92ZXJmbG93KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChfdW51c2VkKSB7XG4gICAgICAvKiBpZ25vcmUgdGhlIGV4Y2VwdGlvbiBhbmQgY29tcHV0ZSBkb21haW4gZnJvbSBkYXRhIGxhdGVyICovXG4gICAgfVxuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHVzZXJEb21haW4pICYmIHVzZXJEb21haW4ubGVuZ3RoID09PSAyKSB7XG4gICAgdmFyIFtwcm92aWRlZE1pbiwgcHJvdmlkZWRNYXhdID0gdXNlckRvbWFpbjtcbiAgICB2YXIgZmluYWxNaW4sIGZpbmFsTWF4O1xuICAgIGlmIChwcm92aWRlZE1pbiA9PT0gJ2F1dG8nKSB7XG4gICAgICBpZiAoZGF0YURvbWFpbiAhPSBudWxsKSB7XG4gICAgICAgIGZpbmFsTWluID0gTWF0aC5taW4oLi4uZGF0YURvbWFpbik7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChpc051bWJlcihwcm92aWRlZE1pbikpIHtcbiAgICAgIGZpbmFsTWluID0gcHJvdmlkZWRNaW47XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgcHJvdmlkZWRNaW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChkYXRhRG9tYWluICE9IG51bGwpIHtcbiAgICAgICAgICBmaW5hbE1pbiA9IHByb3ZpZGVkTWluKGRhdGFEb21haW4gPT09IG51bGwgfHwgZGF0YURvbWFpbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGF0YURvbWFpblswXSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKF91bnVzZWQyKSB7XG4gICAgICAgIC8qIGlnbm9yZSB0aGUgZXhjZXB0aW9uIGFuZCBjb21wdXRlIGRvbWFpbiBmcm9tIGRhdGEgbGF0ZXIgKi9cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBwcm92aWRlZE1pbiA9PT0gJ3N0cmluZycgJiYgTUlOX1ZBTFVFX1JFRy50ZXN0KHByb3ZpZGVkTWluKSkge1xuICAgICAgdmFyIG1hdGNoID0gTUlOX1ZBTFVFX1JFRy5leGVjKHByb3ZpZGVkTWluKTtcbiAgICAgIGlmIChtYXRjaCA9PSBudWxsIHx8IGRhdGFEb21haW4gPT0gbnVsbCkge1xuICAgICAgICBmaW5hbE1pbiA9IHVuZGVmaW5lZDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciB2YWx1ZSA9ICttYXRjaFsxXTtcbiAgICAgICAgZmluYWxNaW4gPSBkYXRhRG9tYWluWzBdIC0gdmFsdWU7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbmFsTWluID0gZGF0YURvbWFpbiA9PT0gbnVsbCB8fCBkYXRhRG9tYWluID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkYXRhRG9tYWluWzBdO1xuICAgIH1cbiAgICBpZiAocHJvdmlkZWRNYXggPT09ICdhdXRvJykge1xuICAgICAgaWYgKGRhdGFEb21haW4gIT0gbnVsbCkge1xuICAgICAgICBmaW5hbE1heCA9IE1hdGgubWF4KC4uLmRhdGFEb21haW4pO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaXNOdW1iZXIocHJvdmlkZWRNYXgpKSB7XG4gICAgICBmaW5hbE1heCA9IHByb3ZpZGVkTWF4O1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHByb3ZpZGVkTWF4ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoZGF0YURvbWFpbiAhPSBudWxsKSB7XG4gICAgICAgICAgZmluYWxNYXggPSBwcm92aWRlZE1heChkYXRhRG9tYWluID09PSBudWxsIHx8IGRhdGFEb21haW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRhdGFEb21haW5bMV0pO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChfdW51c2VkMykge1xuICAgICAgICAvKiBpZ25vcmUgdGhlIGV4Y2VwdGlvbiBhbmQgY29tcHV0ZSBkb21haW4gZnJvbSBkYXRhIGxhdGVyICovXG4gICAgICB9XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgcHJvdmlkZWRNYXggPT09ICdzdHJpbmcnICYmIE1BWF9WQUxVRV9SRUcudGVzdChwcm92aWRlZE1heCkpIHtcbiAgICAgIHZhciBfbWF0Y2ggPSBNQVhfVkFMVUVfUkVHLmV4ZWMocHJvdmlkZWRNYXgpO1xuICAgICAgaWYgKF9tYXRjaCA9PSBudWxsIHx8IGRhdGFEb21haW4gPT0gbnVsbCkge1xuICAgICAgICBmaW5hbE1heCA9IHVuZGVmaW5lZDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciBfdmFsdWUgPSArX21hdGNoWzFdO1xuICAgICAgICBmaW5hbE1heCA9IGRhdGFEb21haW5bMV0gKyBfdmFsdWU7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbmFsTWF4ID0gZGF0YURvbWFpbiA9PT0gbnVsbCB8fCBkYXRhRG9tYWluID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkYXRhRG9tYWluWzFdO1xuICAgIH1cbiAgICB2YXIgY2FuZGlkYXRlID0gW2ZpbmFsTWluLCBmaW5hbE1heF07XG4gICAgaWYgKGlzV2VsbEZvcm1lZE51bWJlckRvbWFpbihjYW5kaWRhdGUpKSB7XG4gICAgICBpZiAoZGF0YURvbWFpbiA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBjYW5kaWRhdGU7XG4gICAgICB9XG4gICAgICByZXR1cm4gZXh0ZW5kRG9tYWluKGNhbmRpZGF0ZSwgZGF0YURvbWFpbiwgYWxsb3dEYXRhT3ZlcmZsb3cpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufSIsImltcG9ydCB7IGlzVmFsaWRFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaXNFdmVudEtleSB9IGZyb20gJy4vZXhjbHVkZUV2ZW50UHJvcHMnO1xuXG4vKipcbiAqIERldGVybWluZXMgaG93IHZhbHVlcyBhcmUgc3RhY2tlZDpcbiAqXG4gKiAtIGBub25lYCBpcyB0aGUgZGVmYXVsdCwgaXQgYWRkcyB2YWx1ZXMgb24gdG9wIG9mIGVhY2ggb3RoZXIuIE5vIHNtYXJ0cy4gTmVnYXRpdmUgdmFsdWVzIHdpbGwgb3ZlcmxhcC5cbiAqIC0gYGV4cGFuZGAgbWFrZSBpdCBzbyB0aGF0IHRoZSB2YWx1ZXMgYWx3YXlzIGFkZCB1cCB0byAxIC0gc28gdGhlIGNoYXJ0IHdpbGwgbG9vayBsaWtlIGEgcmVjdGFuZ2xlLlxuICogLSBgd2lnZ2xlYCBhbmQgYHNpbGhvdWV0dGVgIHRyaWVzIHRvIGtlZXAgdGhlIGNoYXJ0IGNlbnRlcmVkLlxuICogLSBgc2lnbmAgc3RhY2tzIHBvc2l0aXZlIHZhbHVlcyBhYm92ZSB6ZXJvIGFuZCBuZWdhdGl2ZSB2YWx1ZXMgYmVsb3cgemVyby4gU2ltaWxhciB0byBgbm9uZWAgYnV0IGhhbmRsZXMgbmVnYXRpdmVzLlxuICogLSBgcG9zaXRpdmVgIGlnbm9yZXMgYWxsIG5lZ2F0aXZlIHZhbHVlcywgYW5kIHRoZW4gYmVoYXZlcyBsaWtlIFxcYG5vbmVcXGAuXG4gKlxuICogQWxzbyBzZWUgaHR0cHM6Ly9kM2pzLm9yZy9kMy1zaGFwZS9zdGFjayNzdGFjay1vZmZzZXRzXG4gKiAobm90ZSB0aGF0IHRoZSBgZGl2ZXJnaW5nYCBvZmZzZXQgaW4gZDMgaXMgbmFtZWQgYHNpZ25gIGluIHJlY2hhcnRzKVxuICovXG5cbi8qKlxuICogQGRlcHJlY2F0ZWQgdXNlIGVpdGhlciBgQ2FydGVzaWFuTGF5b3V0YCBvciBgUG9sYXJMYXlvdXRgIGluc3RlYWQuXG4gKiBNaXhpbmcgYm90aCBjaGFydHMgZmFtaWxpZXMgbGVhZHMgdG8gYW1iaWd1aXR5IGluIHRoZSB0eXBlIHN5c3RlbS5cbiAqIFRoZXNlIHR3byBsYXlvdXRzIHNoYXJlIHZlcnkgZmV3IHByb3BlcnRpZXMsIHNvIGl0IGlzIGJlc3QgdG8ga2VlcCB0aGVtIHNlcGFyYXRlLlxuICovXG5cbi8qKlxuICogQGRlcHJlY2F0ZWQgZG8gbm90IHVzZTogdG9vIG1hbnkgcHJvcGVydGllcywgbWl4aW5nIHRvbyBtYW55IGNvbmNlcHRzLCBjYXJ0ZXNpYW4gYW5kIHBvbGFyIHRvZ2V0aGVyLCBldmVyeXRoaW5nIG9wdGlvbmFsLlxuICovXG5cbi8vXG4vLyBFdmVudCBIYW5kbGVyIFR5cGVzIC0tIENvcGllZCBmcm9tIEB0eXBlcy9yZWFjdC9pbmRleC5kLnRzIGFuZCBhZGFwdGVkIGZvciBQcm9wcy5cbi8vXG5cbi8qKiBUaGUgdHlwZSBvZiBlYXNpbmcgZnVuY3Rpb24gdG8gdXNlIGZvciBhbmltYXRpb25zICovXG5cbi8qKiBTcGVjaWZpZXMgdGhlIGR1cmF0aW9uIG9mIGFuaW1hdGlvbiwgdGhlIHVuaXQgb2YgdGhpcyBvcHRpb24gaXMgbXMuICovXG5cbi8qKlxuICogVGhpcyBvYmplY3QgZGVmaW5lcyB0aGUgb2Zmc2V0IG9mIHRoZSBjaGFydCBhcmVhIGFuZCB3aWR0aCBhbmQgaGVpZ2h0IGFuZCBicnVzaCBhbmQgLi4uIGl0J3MgYSBiaXQgdG9vIG11Y2ggaW5mb3JtYXRpb24gYWxsIGluIG9uZS5cbiAqIFdlIHVzZSBpdCBpbnRlcm5hbGx5IGJ1dCBsZXQncyBub3QgZXhwb3NlIGl0IHRvIHRoZSBvdXRzaWRlIHdvcmxkLlxuICogSWYgeW91IGFyZSBsb29raW5nIGZvciB0aGlzIGluZm9ybWF0aW9uLCBpbnN0ZWFkIGltcG9ydCBgQ2hhcnRPZmZzZXRgIG9yIGBQbG90QXJlYWAgZnJvbSBgcmVjaGFydHNgLlxuICovXG5cbi8qKlxuICogVGhlIGRvbWFpbiBvZiBheGlzLlxuICogVGhpcyBpcyB0aGUgZGVmaW5pdGlvblxuICpcbiAqIE51bWVyaWMgZG9tYWluIGlzIGFsd2F5cyBkZWZpbmVkIGJ5IGFuIGFycmF5IG9mIGV4YWN0bHkgdHdvIHZhbHVlcywgZm9yIHRoZSBtaW4gYW5kIHRoZSBtYXggb2YgdGhlIGF4aXMuXG4gKiBDYXRlZ29yaWNhbCBkb21haW4gaXMgZGVmaW5lZCBhcyBhcnJheSBvZiBhbGwgcG9zc2libGUgdmFsdWVzLlxuICpcbiAqIENhbiBiZSBzcGVjaWZpZWQgaW4gbWFueSB3YXlzOlxuICogLSBhcnJheSBvZiBudW1iZXJzXG4gKiAtIHdpdGggc3BlY2lhbCBzdHJpbmdzIGxpa2UgJ2RhdGFNaW4nIGFuZCAnZGF0YU1heCdcbiAqIC0gd2l0aCBzcGVjaWFsIHN0cmluZyBtYXRoIGxpa2UgJ2RhdGFNaW4gLSAxMDAnXG4gKiAtIHdpdGgga2V5d29yZCAnYXV0bydcbiAqIC0gb3IgYSBmdW5jdGlvblxuICogLSBhcnJheSBvZiBmdW5jdGlvbnNcbiAqIC0gb3IgYSBjb21iaW5hdGlvbiBvZiB0aGUgYWJvdmVcbiAqL1xuXG4vKipcbiAqIE51bWJlckRvbWFpbiBpcyBhbiBldmFsdWF0ZWQge0BsaW5rIEF4aXNEb21haW59LlxuICogVW5saWtlIHtAbGluayBBeGlzRG9tYWlufSwgaXQgaGFzIG5vIHZhcmlldHkgLSBpdCdzIGEgdHVwbGUgb2YgdHdvIG51bWJlci5cbiAqIFRoaXMgaXMgYWZ0ZXIgYWxsIHRoZSBrZXl3b3JkcyBhbmQgZnVuY3Rpb25zIHdlcmUgZXZhbHVhdGVkIGFuZCB3aGF0IGlzIGxlZnQgaXMgW21pbiwgbWF4XS5cbiAqXG4gKiBLbm93IHRoYXQgdGhlIG1pbiwgbWF4IHZhbHVlcyBhcmUgbm90IGd1YXJhbnRlZWQgdG8gYmUgbmljZSBudW1iZXJzIC0gdmFsdWVzIGxpa2UgLUluZmluaXR5IG9yIE5hTiBhcmUgcG9zc2libGUuXG4gKlxuICogVGhlcmUgYXJlIGFsc28gYGNhdGVnb3J5YCBheGVzIHRoYXQgaGF2ZSBkaWZmZXJlbnQgdGhpbmdzIHRoYW4gbnVtYmVycyBpbiB0aGVpciBkb21haW4uXG4gKi9cblxuLyoqIFRoZSBwcm9wcyBkZWZpbml0aW9uIG9mIGJhc2UgYXhpcyAqL1xuXG4vKiogRGVmaW5lcyBob3cgdGlja3MgYXJlIHBsYWNlZCBhbmQgd2hldGhlciAvIGhvdyB0aWNrIGNvbGxpc2lvbnMgYXJlIGhhbmRsZWQuXG4gKiAncHJlc2VydmVTdGFydCcga2VlcHMgdGhlIGxlZnQgdGljayBvbiBjb2xsaXNpb24gYW5kIGVuc3VyZXMgdGhhdCB0aGUgZmlyc3QgdGljayBpcyBhbHdheXMgc2hvd24uXG4gKiAncHJlc2VydmVFbmQnIGtlZXBzIHRoZSByaWdodCB0aWNrIG9uIGNvbGxpc2lvbiBhbmQgZW5zdXJlcyB0aGF0IHRoZSBsYXN0IHRpY2sgaXMgYWx3YXlzIHNob3duLlxuICogJ3ByZXNlcnZlU3RhcnRFbmQnIGtlZXBzIHRoZSBsZWZ0IHRpY2sgb24gY29sbGlzaW9uIGFuZCBlbnN1cmVzIHRoYXQgdGhlIGZpcnN0IGFuZCBsYXN0IHRpY2tzIGFsd2F5cyBzaG93LlxuICogJ2VxdWlkaXN0YW50UHJlc2VydmVTdGFydCcgc2VsZWN0cyBhIG51bWJlciBOIHN1Y2ggdGhhdCBldmVyeSBuVGggdGljayB3aWxsIGJlIHNob3duIHdpdGhvdXQgY29sbGlzaW9uLlxuICovXG5cbi8qKlxuICogVGlja3MgY2FuIGJlIGFueSB0eXBlIHdoZW4gdGhlIGF4aXMgaXMgdGhlIHR5cGUgb2YgY2F0ZWdvcnkuXG4gKlxuICogVGlja3MgbXVzdCBiZSBudW1iZXJzIHdoZW4gdGhlIGF4aXMgaXMgdGhlIHR5cGUgb2YgbnVtYmVyLlxuICovXG5cbmV4cG9ydCB2YXIgYWRhcHRFdmVudEhhbmRsZXJzID0gKHByb3BzLCBuZXdIYW5kbGVyKSA9PiB7XG4gIGlmICghcHJvcHMgfHwgdHlwZW9mIHByb3BzID09PSAnZnVuY3Rpb24nIHx8IHR5cGVvZiBwcm9wcyA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIGlucHV0UHJvcHMgPSBwcm9wcztcbiAgaWYgKC8qI19fUFVSRV9fKi9pc1ZhbGlkRWxlbWVudChwcm9wcykpIHtcbiAgICBpbnB1dFByb3BzID0gcHJvcHMucHJvcHM7XG4gIH1cbiAgaWYgKHR5cGVvZiBpbnB1dFByb3BzICE9PSAnb2JqZWN0JyAmJiB0eXBlb2YgaW5wdXRQcm9wcyAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBvdXQgPSB7fTtcbiAgT2JqZWN0LmtleXMoaW5wdXRQcm9wcykuZm9yRWFjaChrZXkgPT4ge1xuICAgIGlmIChpc0V2ZW50S2V5KGtleSkpIHtcbiAgICAgIG91dFtrZXldID0gbmV3SGFuZGxlciB8fCAoZSA9PiBpbnB1dFByb3BzW2tleV0oaW5wdXRQcm9wcywgZSkpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBvdXQ7XG59O1xudmFyIGdldEV2ZW50SGFuZGxlck9mQ2hpbGQgPSAob3JpZ2luYWxIYW5kbGVyLCBkYXRhLCBpbmRleCkgPT4gZSA9PiB7XG4gIG9yaWdpbmFsSGFuZGxlcihkYXRhLCBpbmRleCwgZSk7XG4gIHJldHVybiBudWxsO1xufTtcbmV4cG9ydCB2YXIgYWRhcHRFdmVudHNPZkNoaWxkID0gKHByb3BzLCBkYXRhLCBpbmRleCkgPT4ge1xuICBpZiAocHJvcHMgPT09IG51bGwgfHwgdHlwZW9mIHByb3BzICE9PSAnb2JqZWN0JyAmJiB0eXBlb2YgcHJvcHMgIT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgb3V0ID0gbnVsbDtcbiAgT2JqZWN0LmtleXMocHJvcHMpLmZvckVhY2goa2V5ID0+IHtcbiAgICB2YXIgaXRlbSA9IHByb3BzW2tleV07XG4gICAgaWYgKGlzRXZlbnRLZXkoa2V5KSAmJiB0eXBlb2YgaXRlbSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgaWYgKCFvdXQpIG91dCA9IHt9O1xuICAgICAgb3V0W2tleV0gPSBnZXRFdmVudEhhbmRsZXJPZkNoaWxkKGl0ZW0sIGRhdGEsIGluZGV4KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gb3V0O1xufTtcblxuLyoqXG4gKiAnYXhpcycgbWVhbnMgdGhhdCBhbGwgZ3JhcGhpY2FsIGl0ZW1zIGJlbG9uZ2luZyB0byB0aGlzIGF4aXMgdGljayB3aWxsIGJlIGhpZ2hsaWdodGVkLFxuICogYW5kIGFsbCB3aWxsIGJlIHByZXNlbnQgaW4gdGhlIHRvb2x0aXAuXG4gKiBUb29sdGlwIHdpdGggJ2F4aXMnIHdpbGwgZGlzcGxheSB3aGVuIGhvdmVyaW5nIG9uIHRoZSBjaGFydCBiYWNrZ3JvdW5kLlxuICpcbiAqICdpdGVtJyBtZWFucyBvbmx5IHRoZSBvbmUgZ3JhcGhpY2FsIGl0ZW0gYmVpbmcgaG92ZXJlZCB3aWxsIHNob3cgaW4gdGhlIHRvb2x0aXAuXG4gKiBUb29sdGlwIHdpdGggJ2l0ZW0nIHdpbGwgZGlzcGxheSB3aGVuIGhvdmVyaW5nIG92ZXIgaW5kaXZpZHVhbCBncmFwaGljYWwgaXRlbXMuXG4gKlxuICogVGhpcyBpcyBjYWxjdWxhdGVkIGludGVybmFsbHk7XG4gKiBjaGFydHMgaGF2ZSBhIGBkZWZhdWx0VG9vbHRpcEV2ZW50VHlwZWAgYW5kIGB2YWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzYCBvcHRpb25zLlxuICpcbiAqIFVzZXJzIHRoZW4gdXNlIDxUb29sdGlwIHNoYXJlZD17dHJ1ZX0gLz4gb3IgPFRvb2x0aXAgc2hhcmVkPXtmYWxzZX0gLz4gdG8gY29udHJvbCB0aGVpciBwcmVmZXJlbmNlLFxuICogYW5kIGNoYXJ0cyB3aWxsIHRoZW4gc2VlIHdoYXQgaXMgYWxsb3dlZCBhbmQgd2hhdCBpcyBub3QuXG4gKi9cblxuLyoqXG4gKiBUaGVzZSBhcmUgdGhlIHByb3BzIHdlIGFyZSBnb2luZyB0byBwYXNzIHRvIGFuIGBhY3RpdmVEb3RgIGlmIGl0IGlzIGEgZnVuY3Rpb24gb3IgYSBjdXN0b20gQ29tcG9uZW50XG4gKi9cblxuLyoqXG4gKiBUaGlzIGlzIHRoZSB0eXBlIG9mIGBhY3RpdmVEb3RgIHByb3Agb246XG4gKiAtIEFyZWFcbiAqIC0gTGluZVxuICogLSBSYWRhclxuICovXG5cbi8vIFRPRE8gd2UgbmVlZCB0d28gZGlmZmVyZW50IHJhbmdlIG9iamVjdHMsIG9uZSBmb3IgcG9sYXIgYW5kIGFub3RoZXIgZm9yIGNhcnRlc2lhbiBsYXlvdXRzXG5cbi8qKlxuICogU2ltcGxpZmllZCB2ZXJzaW9uIG9mIHRoZSBNb3VzZUV2ZW50IHNvIHRoYXQgd2UgZG9uJ3QgaGF2ZSB0byBtb2NrIHRoZSB3aG9sZSB0aGluZyBpbiB0ZXN0cy5cbiAqXG4gKiBUaGlzIGlzIG1lYW50IHRvIHJlcHJlc2VudCB0aGUgUmVhY3QuTW91c2VFdmVudFxuICogd2hpY2ggaXMgYSB3cmFwcGVyIG9uIHRvcCBvZiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvTW91c2VFdmVudFxuICovXG5cbi8qKlxuICogQ29vcmRpbmF0ZXMgcmVsYXRpdmUgdG8gdGhlIHRvcC1sZWZ0IGNvcm5lciBvZiB0aGUgY2hhcnQuXG4gKiBBbHNvIGluY2x1ZGUgc2NhbGUgd2hpY2ggbWVhbnMgdGhhdCBhIGNoYXJ0IHRoYXQncyBzY2FsZWQgd2lsbCByZXR1cm4gdGhlIHNhbWUgY29vcmRpbmF0ZXMgYXMgYSBjaGFydCB0aGF0J3Mgbm90IHNjYWxlZC5cbiAqLyJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==