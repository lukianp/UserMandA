"use strict";
(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[3],{

/***/ 4217:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ combineCoordinateForDefaultIndex)
/* harmony export */ });
var combineCoordinateForDefaultIndex = (width, height, layout, offset, tooltipTicks, defaultIndex, tooltipConfigurations, tooltipPayloadSearcher) => {
  if (defaultIndex == null || tooltipPayloadSearcher == null) {
    return undefined;
  }
  // With defaultIndex alone, we don't have enough information to decide _which_ of the multiple tooltips to display. So we choose the first one.
  var firstConfiguration = tooltipConfigurations[0];
  // @ts-expect-error we need to rethink the tooltipPayloadSearcher type
  var maybePosition = firstConfiguration == null ? undefined : tooltipPayloadSearcher(firstConfiguration.positions, defaultIndex);
  if (maybePosition != null) {
    return maybePosition;
  }
  var tick = tooltipTicks === null || tooltipTicks === void 0 ? void 0 : tooltipTicks[Number(defaultIndex)];
  if (!tick) {
    return undefined;
  }
  switch (layout) {
    case 'horizontal':
      {
        return {
          x: tick.coordinate,
          y: (offset.top + height) / 2
        };
      }
    default:
      {
        // This logic is not super sound - it conflates vertical, radial, centric layouts into just one. TODO improve!
        return {
          x: (offset.left + width) / 2,
          y: tick.coordinate
        };
      }
  }
};

/***/ }),

/***/ 4364:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F0: () => (/* binding */ DATA_ITEM_INDEX_ATTRIBUTE_NAME),
/* harmony export */   dc: () => (/* binding */ COLOR_PANEL),
/* harmony export */   tQ: () => (/* binding */ DEFAULT_Y_AXIS_WIDTH),
/* harmony export */   um: () => (/* binding */ DATA_ITEM_DATAKEY_ATTRIBUTE_NAME)
/* harmony export */ });
var COLOR_PANEL = ['#1890FF', '#66B5FF', '#41D9C7', '#2FC25B', '#6EDB8F', '#9AE65C', '#FACC14', '#E6965C', '#57AD71', '#223273', '#738AE6', '#7564CC', '#8543E0', '#A877ED', '#5C8EE6', '#13C2C2', '#70E0E0', '#5CA3E6', '#3436C7', '#8082FF', '#DD81E6', '#F04864', '#FA7D92', '#D598D9'];

/**
 * We use this attribute to identify which element is the one that the user is touching.
 * The index is the position of the element in the data array.
 * This can be either a number (for array-based charts) or a string (for the charts that have a matrix-shaped data).
 */
var DATA_ITEM_INDEX_ATTRIBUTE_NAME = 'data-recharts-item-index';
/**
 * We use this attribute to identify which element is the one that the user is touching.
 * DataKey works here as a kind of identifier for the element. It's not a perfect identifier for ~two~ three reasons:
 *
 * 1. There can be two different elements with the same dataKey; we won't know which is it
 * 2. DataKey can be a function, and that serialized will be a `[Function: anonymous]` string
 * which means we will be able to identify that it was a function but can't tell which one.
 * This will lead to some weird bugs. A proper fix would be to either:
 * a) use a unique identifier for each element (passed from props, or generated)
 * b) figure out how to compare the dataKey or graphical item by object reference
 *
 * a) is a fuss because we don't have the unique identifier in props,
 * and b) is possible most of the time except for touchMove events which work differently from mouseEnter/mouseLeave:
 * - while mouseEnter is fired for the element that the mouse is over,
 * touchMove is fired for the element where user has started touching. As the finger moves,
 * we can identify the element that the user is touching by using the elementFromPoint method,
 * but it keeps calling the handler on the element where touchStart was fired.
 *
 * Okay and now I discovered a third reason: the dataKey can be undefined and that's still fine
 * because if dataKey is undefined then graphical elements assume the dataKey of the axes.
 * Which makes it a convenient way of using recharts to render a chart but horrible identifier.
 */
var DATA_ITEM_DATAKEY_ATTRIBUTE_NAME = 'data-recharts-item-data-key';
var DEFAULT_Y_AXIS_WIDTH = 60;

/***/ }),

/***/ 5180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A$: () => (/* binding */ selectChartHeight),
/* harmony export */   HK: () => (/* binding */ selectMargin),
/* harmony export */   Lp: () => (/* binding */ selectChartWidth),
/* harmony export */   et: () => (/* binding */ selectContainerScale)
/* harmony export */ });
var selectChartWidth = state => state.layout.width;
var selectChartHeight = state => state.layout.height;
var selectContainerScale = state => state.layout.scale;
var selectMargin = state => state.layout.margin;

/***/ }),

/***/ 6392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ numberDomainEqualityCheck)
/* harmony export */ });
var numberDomainEqualityCheck = (a, b) => {
  if (a === b) {
    return true;
  }
  if (a == null || b == null) {
    return false;
  }
  return a[0] === b[0] && a[1] === b[1];
};

/***/ }),

/***/ 8596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YF: () => (/* binding */ mouseClickMiddleware),
/* harmony export */   dj: () => (/* binding */ mouseMoveAction),
/* harmony export */   fP: () => (/* binding */ mouseMoveMiddleware),
/* harmony export */   ky: () => (/* binding */ mouseClickAction)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);
/* harmony import */ var _tooltipSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74531);
/* harmony import */ var _selectors_selectActivePropsFromChartPointer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(20954);
/* harmony import */ var _selectors_selectTooltipEventType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55978);
/* harmony import */ var _util_getChartPointer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99516);





var mouseClickAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createAction */ .VP)('mouseClick');
var mouseClickMiddleware = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createListenerMiddleware */ .Nc)();

// TODO: there's a bug here when you click the chart the activeIndex resets to zero
mouseClickMiddleware.startListening({
  actionCreator: mouseClickAction,
  effect: (action, listenerApi) => {
    var mousePointer = action.payload;
    var activeProps = (0,_selectors_selectActivePropsFromChartPointer__WEBPACK_IMPORTED_MODULE_2__/* .selectActivePropsFromChartPointer */ .g)(listenerApi.getState(), (0,_util_getChartPointer__WEBPACK_IMPORTED_MODULE_4__/* .getChartPointer */ .w)(mousePointer));
    if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
      listenerApi.dispatch((0,_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .setMouseClickAxisIndex */ .jF)({
        activeIndex: activeProps.activeIndex,
        activeDataKey: undefined,
        activeCoordinate: activeProps.activeCoordinate
      }));
    }
  }
});
var mouseMoveAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createAction */ .VP)('mouseMove');
var mouseMoveMiddleware = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createListenerMiddleware */ .Nc)();
mouseMoveMiddleware.startListening({
  actionCreator: mouseMoveAction,
  effect: (action, listenerApi) => {
    var mousePointer = action.payload;
    var state = listenerApi.getState();
    var tooltipEventType = (0,_selectors_selectTooltipEventType__WEBPACK_IMPORTED_MODULE_3__/* .selectTooltipEventType */ .au)(state, state.tooltip.settings.shared);
    var activeProps = (0,_selectors_selectActivePropsFromChartPointer__WEBPACK_IMPORTED_MODULE_2__/* .selectActivePropsFromChartPointer */ .g)(state, (0,_util_getChartPointer__WEBPACK_IMPORTED_MODULE_4__/* .getChartPointer */ .w)(mousePointer));

    // this functionality only applies to charts that have axes
    if (tooltipEventType === 'axis') {
      if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
        listenerApi.dispatch((0,_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .setMouseOverAxisIndex */ .Nt)({
          activeIndex: activeProps.activeIndex,
          activeDataKey: undefined,
          activeCoordinate: activeProps.activeCoordinate
        }));
      } else {
        // this is needed to clear tooltip state when the mouse moves out of the inRange (svg - offset) function, but not yet out of the svg
        listenerApi.dispatch((0,_tooltipSlice__WEBPACK_IMPORTED_MODULE_1__/* .mouseLeaveChart */ .xS)());
      }
    }
  }
});

/***/ }),

/***/ 9531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ isStacked)
/* harmony export */ });
/**
 * Some graphical items allow data stacking. The stacks are optional,
 * so all props here are optional too.
 */

/**
 * Some graphical items allow data stacking.
 * This interface is used to represent the items that are stacked
 * because the user has provided the stackId and dataKey properties.
 */

function isStacked(graphicalItem) {
  return graphicalItem.stackId != null && graphicalItem.dataKey != null;
}

/***/ }),

/***/ 11114:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $X: () => (/* binding */ selectReferenceLines),
/* harmony export */   AV: () => (/* binding */ selectDomainDefinition),
/* harmony export */   BQ: () => (/* binding */ selectCartesianAxisSize),
/* harmony export */   CH: () => (/* binding */ selectAllErrorBarSettings),
/* harmony export */   CR: () => (/* binding */ selectTicksOfGraphicalItem),
/* harmony export */   D5: () => (/* binding */ selectAxisRange),
/* harmony export */   DP: () => (/* binding */ selectBaseAxis),
/* harmony export */   EZ: () => (/* binding */ combineDomainOfAllAppliedNumericalValuesIncludingErrorValues),
/* harmony export */   Gx: () => (/* binding */ selectAxisWithScale),
/* harmony export */   Hd: () => (/* binding */ selectAxisSettings),
/* harmony export */   IO: () => (/* binding */ filterGraphicalNotStackedItems),
/* harmony export */   KR: () => (/* binding */ selectYAxisPosition),
/* harmony export */   Kr: () => (/* binding */ selectReferenceDots),
/* harmony export */   L$: () => (/* binding */ selectXAxisPosition),
/* harmony export */   Lu: () => (/* binding */ selectDomainFromUserPreference),
/* harmony export */   Lw: () => (/* binding */ selectXAxisSize),
/* harmony export */   MK: () => (/* binding */ combineStackGroups),
/* harmony export */   N8: () => (/* binding */ implicitZAxis),
/* harmony export */   Nk: () => (/* binding */ combineDisplayedData),
/* harmony export */   Oz: () => (/* binding */ combineDotsDomain),
/* harmony export */   P9: () => (/* binding */ filterReferenceElements),
/* harmony export */   PU: () => (/* binding */ implicitXAxis),
/* harmony export */   Qn: () => (/* binding */ combineScaleFunction),
/* harmony export */   Rl: () => (/* binding */ selectXAxisSettings),
/* harmony export */   S5: () => (/* binding */ getDomainDefinition),
/* harmony export */   TC: () => (/* binding */ selectStackGroups),
/* harmony export */   UE: () => (/* binding */ combineGraphicalItemTicks),
/* harmony export */   Y: () => (/* binding */ selectZAxisWithScale),
/* harmony export */   ZB: () => (/* binding */ selectAxisPropsNeededForCartesianGridTicksGenerator),
/* harmony export */   Zi: () => (/* binding */ selectTicksOfAxis),
/* harmony export */   _y: () => (/* binding */ selectChartDirection),
/* harmony export */   bb: () => (/* binding */ combineLinesDomain),
/* harmony export */   cd: () => (/* binding */ implicitYAxis),
/* harmony export */   ec: () => (/* binding */ combineGraphicalItemsSettings),
/* harmony export */   eo: () => (/* binding */ itemAxisPredicate),
/* harmony export */   fb: () => (/* binding */ combineAppliedValues),
/* harmony export */   g1: () => (/* binding */ combineAxisDomainWithNiceTicks),
/* harmony export */   gT: () => (/* binding */ selectReferenceAreas),
/* harmony export */   hc: () => (/* binding */ selectYAxisSettingsNoDefaults),
/* harmony export */   iV: () => (/* binding */ selectAxisScale),
/* harmony export */   iv: () => (/* binding */ combineCategoricalDomain),
/* harmony export */   ld: () => (/* binding */ selectUnfilteredCartesianItems),
/* harmony export */   pM: () => (/* binding */ combineDomainOfStackGroups),
/* harmony export */   q: () => (/* binding */ combineAreasDomain),
/* harmony export */   rj: () => (/* binding */ combineGraphicalItemsData),
/* harmony export */   ro: () => (/* binding */ combineAxisTicks),
/* harmony export */   sf: () => (/* binding */ selectYAxisSettings),
/* harmony export */   sr: () => (/* binding */ combineRealScaleType),
/* harmony export */   tF: () => (/* binding */ combineDuplicateDomain),
/* harmony export */   tP: () => (/* binding */ combineAxisDomain),
/* harmony export */   um: () => (/* binding */ selectHasBar),
/* harmony export */   wL: () => (/* binding */ combineNumericalDomain),
/* harmony export */   wP: () => (/* binding */ selectYAxisSize),
/* harmony export */   wi: () => (/* binding */ selectDuplicateDomain),
/* harmony export */   xM: () => (/* binding */ selectRealScaleType),
/* harmony export */   xp: () => (/* binding */ combineNiceTicks),
/* harmony export */   y7: () => (/* binding */ selectXAxisSettingsNoDefaults),
/* harmony export */   yi: () => (/* binding */ mergeDomains)
/* harmony export */ });
/* unused harmony exports selectZAxisSettings, selectCartesianItemsSettings, selectStackedCartesianItemsSettings, selectCartesianGraphicalItemsData, selectDisplayedData, selectAllAppliedValues, isErrorBarRelevantForAxisType, fromMainValueToError, getErrorDomainByDataKey, selectDisplayedStackedData, selectDomainOfStackGroups, selectReferenceDotsByAxis, selectReferenceAreasByAxis, selectReferenceLinesByAxis, selectNumericalDomain, selectAxisDomain, selectNiceTicks, selectAxisDomainIncludingNiceTicks, selectSmallestDistanceBetweenValues, selectCalculatedXAxisPadding, selectCalculatedYAxisPadding, combineXAxisRange, combineYAxisRange, selectAxisRangeWithReverse, selectErrorBarsSettings, selectAllXAxesOffsetSteps, selectAllYAxesOffsetSteps, selectCategoricalDomain */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var es_toolkit_compat_range__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43412);
/* harmony import */ var es_toolkit_compat_range__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_range__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(39625);
/* harmony import */ var es_toolkit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68866);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19287);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33964);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(98453);
/* harmony import */ var _util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(93749);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59744);
/* harmony import */ var _util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8813);
/* harmony import */ var _util_scale__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8292);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5180);
/* harmony import */ var _selectAllAxes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(68861);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(36189);
/* harmony import */ var _brushSelectors__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(76461);
/* harmony import */ var _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(82695);
/* harmony import */ var _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(61270);
/* harmony import */ var _pickAxisType__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(41927);
/* harmony import */ var _pickAxisId__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(79926);
/* harmony import */ var _combiners_combineAxisRangeWithReverse__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(19495);
/* harmony import */ var _util_Constants__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4364);
/* harmony import */ var _util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(72925);
/* harmony import */ var _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(37617);
/* harmony import */ var _combiners_combineDisplayedStackedData__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(86907);
/* harmony import */ var _types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9531);
/* harmony import */ var _numberDomainEqualityCheck__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6392);
/* harmony import */ var _arrayEqualityCheck__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(22608);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }



























var defaultNumericDomain = [0, 'auto'];

/**
 * angle, radius, X, Y, and Z axes all have domain and range and scale and associated settings
 */

/**
 * X and Y axes have ticks. Z axis is never displayed and so it lacks ticks
 * and tick settings.
 */

/**
 * If an axis is not explicitly defined as an element,
 * we still need to render something in the chart and we need
 * some object to hold the domain and default settings.
 */
var implicitXAxis = {
  allowDataOverflow: false,
  allowDecimals: true,
  allowDuplicatedCategory: true,
  angle: 0,
  dataKey: undefined,
  domain: undefined,
  height: 30,
  hide: true,
  id: 0,
  includeHidden: false,
  interval: 'preserveEnd',
  minTickGap: 5,
  mirror: false,
  name: undefined,
  orientation: 'bottom',
  padding: {
    left: 0,
    right: 0
  },
  reversed: false,
  scale: 'auto',
  tick: true,
  tickCount: 5,
  tickFormatter: undefined,
  ticks: undefined,
  type: 'category',
  unit: undefined
};
var selectXAxisSettingsNoDefaults = (state, axisId) => {
  return state.cartesianAxis.xAxis[axisId];
};
var selectXAxisSettings = (state, axisId) => {
  var axis = selectXAxisSettingsNoDefaults(state, axisId);
  if (axis == null) {
    return implicitXAxis;
  }
  return axis;
};

/**
 * If an axis is not explicitly defined as an element,
 * we still need to render something in the chart and we need
 * some object to hold the domain and default settings.
 */
var implicitYAxis = {
  allowDataOverflow: false,
  allowDecimals: true,
  allowDuplicatedCategory: true,
  angle: 0,
  dataKey: undefined,
  domain: defaultNumericDomain,
  hide: true,
  id: 0,
  includeHidden: false,
  interval: 'preserveEnd',
  minTickGap: 5,
  mirror: false,
  name: undefined,
  orientation: 'left',
  padding: {
    top: 0,
    bottom: 0
  },
  reversed: false,
  scale: 'auto',
  tick: true,
  tickCount: 5,
  tickFormatter: undefined,
  ticks: undefined,
  type: 'number',
  unit: undefined,
  width: _util_Constants__WEBPACK_IMPORTED_MODULE_20__/* .DEFAULT_Y_AXIS_WIDTH */ .tQ
};
var selectYAxisSettingsNoDefaults = (state, axisId) => {
  return state.cartesianAxis.yAxis[axisId];
};
var selectYAxisSettings = (state, axisId) => {
  var axis = selectYAxisSettingsNoDefaults(state, axisId);
  if (axis == null) {
    return implicitYAxis;
  }
  return axis;
};
var implicitZAxis = {
  domain: [0, 'auto'],
  includeHidden: false,
  reversed: false,
  allowDataOverflow: false,
  allowDuplicatedCategory: false,
  dataKey: undefined,
  id: 0,
  name: '',
  range: [64, 64],
  scale: 'auto',
  type: 'number',
  unit: ''
};
var selectZAxisSettings = (state, axisId) => {
  var axis = state.cartesianAxis.zAxis[axisId];
  if (axis == null) {
    return implicitZAxis;
  }
  return axis;
};
var selectBaseAxis = (state, axisType, axisId) => {
  switch (axisType) {
    case 'xAxis':
      {
        return selectXAxisSettings(state, axisId);
      }
    case 'yAxis':
      {
        return selectYAxisSettings(state, axisId);
      }
    case 'zAxis':
      {
        return selectZAxisSettings(state, axisId);
      }
    case 'angleAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectAngleAxis */ .Be)(state, axisId);
      }
    case 'radiusAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectRadiusAxis */ .Gl)(state, axisId);
      }
    default:
      throw new Error("Unexpected axis type: ".concat(axisType));
  }
};
var selectCartesianAxisSettings = (state, axisType, axisId) => {
  switch (axisType) {
    case 'xAxis':
      {
        return selectXAxisSettings(state, axisId);
      }
    case 'yAxis':
      {
        return selectYAxisSettings(state, axisId);
      }
    default:
      throw new Error("Unexpected axis type: ".concat(axisType));
  }
};

/**
 * Selects either an X or Y axis. Doesn't work with Z axis - for that, instead use selectBaseAxis.
 * @param state Root state
 * @param axisType xAxis | yAxis
 * @param axisId xAxisId | yAxisId
 * @returns axis settings object
 */
var selectAxisSettings = (state, axisType, axisId) => {
  switch (axisType) {
    case 'xAxis':
      {
        return selectXAxisSettings(state, axisId);
      }
    case 'yAxis':
      {
        return selectYAxisSettings(state, axisId);
      }
    case 'angleAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectAngleAxis */ .Be)(state, axisId);
      }
    case 'radiusAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectRadiusAxis */ .Gl)(state, axisId);
      }
    default:
      throw new Error("Unexpected axis type: ".concat(axisType));
  }
};

/**
 * @param state RechartsRootState
 * @return boolean true if there is at least one Bar or RadialBar
 */
var selectHasBar = state => state.graphicalItems.cartesianItems.some(item => item.type === 'bar') || state.graphicalItems.polarItems.some(item => item.type === 'radialBar');

/**
 * Filters CartesianGraphicalItemSettings by the relevant axis ID
 * @param axisType 'xAxis' | 'yAxis' | 'zAxis' | 'radiusAxis' | 'angleAxis'
 * @param axisId from props, defaults to 0
 *
 * @returns Predicate function that return true for CartesianGraphicalItemSettings that are relevant to the specified axis
 */
function itemAxisPredicate(axisType, axisId) {
  return item => {
    switch (axisType) {
      case 'xAxis':
        // This is sensitive to the data type, as 0 !== '0'. I wonder if we should be more flexible. How does 2.x branch behave? TODO write test for that
        return 'xAxisId' in item && item.xAxisId === axisId;
      case 'yAxis':
        return 'yAxisId' in item && item.yAxisId === axisId;
      case 'zAxis':
        return 'zAxisId' in item && item.zAxisId === axisId;
      case 'angleAxis':
        return 'angleAxisId' in item && item.angleAxisId === axisId;
      case 'radiusAxis':
        return 'radiusAxisId' in item && item.radiusAxisId === axisId;
      default:
        return false;
    }
  };
}
var selectUnfilteredCartesianItems = state => state.graphicalItems.cartesianItems;
var selectAxisPredicate = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, _pickAxisId__WEBPACK_IMPORTED_MODULE_18__/* .pickAxisId */ .E], itemAxisPredicate);
var combineGraphicalItemsSettings = (graphicalItems, axisSettings, axisPredicate) => graphicalItems.filter(axisPredicate).filter(item => {
  if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.includeHidden) === true) {
    return true;
  }
  return !item.hide;
});
var selectCartesianItemsSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectUnfilteredCartesianItems, selectBaseAxis, selectAxisPredicate], combineGraphicalItemsSettings, {
  memoizeOptions: {
    resultEqualityCheck: _arrayEqualityCheck__WEBPACK_IMPORTED_MODULE_26__/* .arrayEqualityCheck */ .I
  }
});
var selectStackedCartesianItemsSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectCartesianItemsSettings], cartesianItems => {
  return cartesianItems.filter(item => item.type === 'area' || item.type === 'bar').filter(_types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_24__/* .isStacked */ .g);
});
var filterGraphicalNotStackedItems = cartesianItems => cartesianItems.filter(item => !('stackId' in item) || item.stackId === undefined);
var selectCartesianItemsSettingsExceptStacked = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectCartesianItemsSettings], filterGraphicalNotStackedItems);
var combineGraphicalItemsData = cartesianItems => cartesianItems.map(item => item.data).filter(Boolean).flat(1);

/**
 * This is a "cheap" selector - it returns the data but doesn't iterate them, so it is not sensitive on the array length.
 * Also does not apply dataKey yet.
 * @param state RechartsRootState
 * @returns data defined on the chart graphical items, such as Line or Scatter or Pie, and filtered with appropriate dataKey
 */
var selectCartesianGraphicalItemsData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectCartesianItemsSettings], combineGraphicalItemsData, {
  memoizeOptions: {
    resultEqualityCheck: _arrayEqualityCheck__WEBPACK_IMPORTED_MODULE_26__/* .arrayEqualityCheck */ .I
  }
});
var combineDisplayedData = (graphicalItemsData, _ref) => {
  var {
    chartData = [],
    dataStartIndex,
    dataEndIndex
  } = _ref;
  if (graphicalItemsData.length > 0) {
    /*
     * There is no slicing when data is defined on graphical items. Why?
     * Because Brush ignores data defined on graphical items,
     * and does not render.
     * So Brush will never show up in a Scatter chart for example.
     * This is something we will need to fix.
     *
     * Now, when the root chart data is not defined, the dataEndIndex is 0,
     * which means the itemsData will be sliced to an empty array anyway.
     * But that's an implementation detail, and we can fix that too.
     *
     * Also, in absence of Axis dataKey, we use the dataKey from each item, respectively.
     * This is the usual pattern for numerical axis, that is the one where bars go up:
     * users don't specify any dataKey by default and expect the axis to "just match the data".
     */
    return graphicalItemsData;
  }
  return chartData.slice(dataStartIndex, dataEndIndex + 1);
};

/**
 * This selector will return all data there is in the chart: graphical items, chart root, all together.
 * Useful for figuring out an axis domain (because that needs to know of everything),
 * not useful for rendering individual graphical elements (because they need to know which data is theirs and which is not).
 *
 * This function will discard the original indexes, so it is also not useful for anything that depends on ordering.
 */
var selectDisplayedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectCartesianGraphicalItemsData, _dataSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS], combineDisplayedData);
var combineAppliedValues = (data, axisSettings, items) => {
  if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null) {
    return data.map(item => ({
      value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getValueByDataKey */ .kr)(item, axisSettings.dataKey)
    }));
  }
  if (items.length > 0) {
    return items.map(item => item.dataKey).flatMap(dataKey => data.map(entry => ({
      value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getValueByDataKey */ .kr)(entry, dataKey)
    })));
  }
  return data.map(entry => ({
    value: entry
  }));
};

/**
 * This selector will return all values with the appropriate dataKey applied on them.
 * Which dataKey is appropriate depends on where it is defined.
 *
 * This is an expensive selector - it will iterate all data and compute their value using the provided dataKey.
 */
var selectAllAppliedValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDisplayedData, selectBaseAxis, selectCartesianItemsSettings], combineAppliedValues);
function isErrorBarRelevantForAxisType(axisType, errorBar) {
  switch (axisType) {
    case 'xAxis':
      return errorBar.direction === 'x';
    case 'yAxis':
      return errorBar.direction === 'y';
    default:
      return false;
  }
}

/**
 * This is type of "error" in chart. It is set by using ErrorBar, and it can represent confidence interval,
 * or gap in the data, or standard deviation, or quartiles in boxplot, or whiskers or whatever.
 *
 * We will internally represent it as a tuple of two numbers, where the first number is the lower bound and the second number is the upper bound.
 *
 * It is also true that the first number should be lower than or equal to the associated "main value",
 * and the second number should be higher than or equal to the associated "main value".
 */

function fromMainValueToError(value) {
  if (isNumber(value) && Number.isFinite(value)) {
    return [value, value];
  }
  if (Array.isArray(value)) {
    var minError = Math.min(...value);
    var maxError = Math.max(...value);
    if (!isNan(minError) && !isNan(maxError) && Number.isFinite(minError) && Number.isFinite(maxError)) {
      return [minError, maxError];
    }
  }
  return undefined;
}
function makeNumber(val) {
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .isNumOrStr */ .vh)(val) || val instanceof Date) {
    var n = Number(val);
    if ((0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(n)) {
      return n;
    }
  }
  return undefined;
}
function makeDomain(val) {
  if (Array.isArray(val)) {
    var attempt = [makeNumber(val[0]), makeNumber(val[1])];
    if ((0,_util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .isWellFormedNumberDomain */ .JH)(attempt)) {
      return attempt;
    }
    return undefined;
  }
  var n = makeNumber(val);
  if (n == null) {
    return undefined;
  }
  return [n, n];
}
function onlyAllowNumbers(data) {
  return data.map(makeNumber).filter(es_toolkit__WEBPACK_IMPORTED_MODULE_3__/* .isNotNil */ .n9f);
}

/**
 * @param entry One item in the 'data' array. Could be anything really - this is defined externally. This is the raw, before dataKey application
 * @param appliedValue This is the result of applying the 'main' dataKey on the `entry`.
 * @param relevantErrorBars Error bars that are relevant for the current axis and layout and all that.
 * @return either undefined or an array of ErrorValue
 */
function getErrorDomainByDataKey(entry, appliedValue, relevantErrorBars) {
  if (!relevantErrorBars || typeof appliedValue !== 'number' || (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .isNan */ .M8)(appliedValue)) {
    return [];
  }
  if (!relevantErrorBars.length) {
    return [];
  }
  return onlyAllowNumbers(relevantErrorBars.flatMap(eb => {
    var errorValue = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getValueByDataKey */ .kr)(entry, eb.dataKey);
    var lowBound, highBound;
    if (Array.isArray(errorValue)) {
      [lowBound, highBound] = errorValue;
    } else {
      lowBound = highBound = errorValue;
    }
    if (!(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(lowBound) || !(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(highBound)) {
      return undefined;
    }
    return [appliedValue - lowBound, appliedValue + highBound];
  }));
}
var selectDisplayedStackedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectStackedCartesianItemsSettings, _dataSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS, _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_22__/* .selectTooltipAxis */ .D], _combiners_combineDisplayedStackedData__WEBPACK_IMPORTED_MODULE_23__/* .combineDisplayedStackedData */ .A);
var combineStackGroups = (displayedData, items, stackOffsetType) => {
  var initialItemsGroups = {};
  var itemsGroup = items.reduce((acc, item) => {
    if (item.stackId == null) {
      return acc;
    }
    if (acc[item.stackId] == null) {
      acc[item.stackId] = [];
    }
    acc[item.stackId].push(item);
    return acc;
  }, initialItemsGroups);
  return Object.fromEntries(Object.entries(itemsGroup).map(_ref2 => {
    var [stackId, graphicalItems] = _ref2;
    var dataKeys = graphicalItems.map(_util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_21__/* .getStackSeriesIdentifier */ .x);
    return [stackId, {
      // @ts-expect-error getStackedData requires that the input is array of objects, Recharts does not test for that
      stackedData: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getStackedData */ .yy)(displayedData, dataKeys, stackOffsetType),
      graphicalItems
    }];
  }));
};

/**
 * Stack groups are groups of graphical items that stack on each other.
 * Stack is a function of axis type (X, Y), axis ID, and stack ID.
 * Graphical items that do not have a stack ID are not going to be present in stack groups.
 */
var selectStackGroups = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDisplayedStackedData, selectStackedCartesianItemsSettings, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_15__/* .selectStackOffsetType */ .eC], combineStackGroups);
var combineDomainOfStackGroups = (stackGroups, _ref3, axisType, domainFromUserPreference) => {
  var {
    dataStartIndex,
    dataEndIndex
  } = _ref3;
  if (domainFromUserPreference != null) {
    // User has specified a domain, so we respect that and we can skip computing anything else
    return undefined;
  }
  if (axisType === 'zAxis') {
    // ZAxis ignores stacks
    return undefined;
  }
  var domainOfStackGroups = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getDomainOfStackGroups */ .Mk)(stackGroups, dataStartIndex, dataEndIndex);
  if (domainOfStackGroups != null && domainOfStackGroups[0] === 0 && domainOfStackGroups[1] === 0) {
    return undefined;
  }
  return domainOfStackGroups;
};
var selectAllowsDataOverflow = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis], axisSettings => axisSettings.allowDataOverflow);
var getDomainDefinition = axisSettings => {
  var _axisSettings$domain;
  if (axisSettings == null || !('domain' in axisSettings)) {
    return defaultNumericDomain;
  }
  if (axisSettings.domain != null) {
    return axisSettings.domain;
  }
  if (axisSettings.ticks != null) {
    if (axisSettings.type === 'number') {
      var allValues = onlyAllowNumbers(axisSettings.ticks);
      return [Math.min(...allValues), Math.max(...allValues)];
    }
    if (axisSettings.type === 'category') {
      return axisSettings.ticks.map(String);
    }
  }
  return (_axisSettings$domain = axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.domain) !== null && _axisSettings$domain !== void 0 ? _axisSettings$domain : defaultNumericDomain;
};
var selectDomainDefinition = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis], getDomainDefinition);

/**
 * Under certain circumstances, we can determine the domain without looking at the data at all.
 * This is the case when the domain is explicitly specified as numbers, or when it is specified
 * as 'auto' or 'dataMin'/'dataMax' and data overflow is not allowed.
 *
 * In that case, this function will return the domain, otherwise it returns undefined.
 *
 * This is an optimization to avoid unnecessary data processing.
 * @param state
 * @param axisType
 * @param axisId
 * @param isPanorama
 */
var selectDomainFromUserPreference = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDomainDefinition, selectAllowsDataOverflow], _util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .numericalDomainSpecifiedWithoutRequiringData */ .f5);
var selectDomainOfStackGroups = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectStackGroups, _dataSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectChartDataWithIndexes */ .LF, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, selectDomainFromUserPreference], combineDomainOfStackGroups, {
  memoizeOptions: {
    resultEqualityCheck: _numberDomainEqualityCheck__WEBPACK_IMPORTED_MODULE_25__/* .numberDomainEqualityCheck */ .o
  }
});
var selectAllErrorBarSettings = state => state.errorBars;
var combineRelevantErrorBarSettings = (cartesianItemsSettings, allErrorBarSettings, axisType) => {
  return cartesianItemsSettings.flatMap(item => {
    return allErrorBarSettings[item.id];
  }).filter(Boolean).filter(e => {
    return isErrorBarRelevantForAxisType(axisType, e);
  });
};
var mergeDomains = function mergeDomains() {
  for (var _len = arguments.length, domains = new Array(_len), _key = 0; _key < _len; _key++) {
    domains[_key] = arguments[_key];
  }
  var allDomains = domains.filter(Boolean);
  if (allDomains.length === 0) {
    return undefined;
  }
  var allValues = allDomains.flat();
  var min = Math.min(...allValues);
  var max = Math.max(...allValues);
  return [min, max];
};
var combineDomainOfAllAppliedNumericalValuesIncludingErrorValues = (data, axisSettings, items, errorBars, axisType) => {
  var lowerEnd, upperEnd;
  if (items.length > 0) {
    data.forEach(entry => {
      items.forEach(item => {
        var _errorBars$item$id, _axisSettings$dataKey;
        var relevantErrorBars = (_errorBars$item$id = errorBars[item.id]) === null || _errorBars$item$id === void 0 ? void 0 : _errorBars$item$id.filter(errorBar => isErrorBarRelevantForAxisType(axisType, errorBar));
        var valueByDataKey = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getValueByDataKey */ .kr)(entry, (_axisSettings$dataKey = axisSettings.dataKey) !== null && _axisSettings$dataKey !== void 0 ? _axisSettings$dataKey : item.dataKey);
        var errorDomain = getErrorDomainByDataKey(entry, valueByDataKey, relevantErrorBars);
        if (errorDomain.length >= 2) {
          var localLower = Math.min(...errorDomain);
          var localUpper = Math.max(...errorDomain);
          if (lowerEnd == null || localLower < lowerEnd) {
            lowerEnd = localLower;
          }
          if (upperEnd == null || localUpper > upperEnd) {
            upperEnd = localUpper;
          }
        }
        var dataValueDomain = makeDomain(valueByDataKey);
        if (dataValueDomain != null) {
          lowerEnd = lowerEnd == null ? dataValueDomain[0] : Math.min(lowerEnd, dataValueDomain[0]);
          upperEnd = upperEnd == null ? dataValueDomain[1] : Math.max(upperEnd, dataValueDomain[1]);
        }
      });
    });
  }
  if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null) {
    data.forEach(item => {
      var dataValueDomain = makeDomain((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getValueByDataKey */ .kr)(item, axisSettings.dataKey));
      if (dataValueDomain != null) {
        lowerEnd = lowerEnd == null ? dataValueDomain[0] : Math.min(lowerEnd, dataValueDomain[0]);
        upperEnd = upperEnd == null ? dataValueDomain[1] : Math.max(upperEnd, dataValueDomain[1]);
      }
    });
  }
  if ((0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(lowerEnd) && (0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(upperEnd)) {
    return [lowerEnd, upperEnd];
  }
  return undefined;
};
var selectDomainOfAllAppliedNumericalValuesIncludingErrorValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDisplayedData, selectBaseAxis, selectCartesianItemsSettingsExceptStacked, selectAllErrorBarSettings, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineDomainOfAllAppliedNumericalValuesIncludingErrorValues, {
  memoizeOptions: {
    resultEqualityCheck: _numberDomainEqualityCheck__WEBPACK_IMPORTED_MODULE_25__/* .numberDomainEqualityCheck */ .o
  }
});
function onlyAllowNumbersAndStringsAndDates(item) {
  var {
    value
  } = item;
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .isNumOrStr */ .vh)(value) || value instanceof Date) {
    return value;
  }
  return undefined;
}
var computeDomainOfTypeCategory = (allDataSquished, axisSettings, isCategorical) => {
  var categoricalDomain = allDataSquished.map(onlyAllowNumbersAndStringsAndDates).filter(v => v != null);
  if (isCategorical && (axisSettings.dataKey == null || axisSettings.allowDuplicatedCategory && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .hasDuplicate */ .CG)(categoricalDomain))) {
    /*
     * 1. In an absence of dataKey, Recharts will use array indexes as its categorical domain
     * 2. When category axis has duplicated text, serial numbers are used to generate scale
     */
    return es_toolkit_compat_range__WEBPACK_IMPORTED_MODULE_1___default()(0, allDataSquished.length);
  }
  if (axisSettings.allowDuplicatedCategory) {
    return categoricalDomain;
  }
  return Array.from(new Set(categoricalDomain));
};
var selectReferenceDots = state => state.referenceElements.dots;
var filterReferenceElements = (elements, axisType, axisId) => {
  return elements.filter(el => el.ifOverflow === 'extendDomain').filter(el => {
    if (axisType === 'xAxis') {
      return el.xAxisId === axisId;
    }
    return el.yAxisId === axisId;
  });
};
var selectReferenceDotsByAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectReferenceDots, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, _pickAxisId__WEBPACK_IMPORTED_MODULE_18__/* .pickAxisId */ .E], filterReferenceElements);
var selectReferenceAreas = state => state.referenceElements.areas;
var selectReferenceAreasByAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectReferenceAreas, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, _pickAxisId__WEBPACK_IMPORTED_MODULE_18__/* .pickAxisId */ .E], filterReferenceElements);
var selectReferenceLines = state => state.referenceElements.lines;
var selectReferenceLinesByAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectReferenceLines, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, _pickAxisId__WEBPACK_IMPORTED_MODULE_18__/* .pickAxisId */ .E], filterReferenceElements);
var combineDotsDomain = (dots, axisType) => {
  var allCoords = onlyAllowNumbers(dots.map(dot => axisType === 'xAxis' ? dot.x : dot.y));
  if (allCoords.length === 0) {
    return undefined;
  }
  return [Math.min(...allCoords), Math.max(...allCoords)];
};
var selectReferenceDotsDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectReferenceDotsByAxis, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, combineDotsDomain);
var combineAreasDomain = (areas, axisType) => {
  var allCoords = onlyAllowNumbers(areas.flatMap(area => [axisType === 'xAxis' ? area.x1 : area.y1, axisType === 'xAxis' ? area.x2 : area.y2]));
  if (allCoords.length === 0) {
    return undefined;
  }
  return [Math.min(...allCoords), Math.max(...allCoords)];
};
var selectReferenceAreasDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectReferenceAreasByAxis, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineAreasDomain);
var combineLinesDomain = (lines, axisType) => {
  var allCoords = onlyAllowNumbers(lines.map(line => axisType === 'xAxis' ? line.x : line.y));
  if (allCoords.length === 0) {
    return undefined;
  }
  return [Math.min(...allCoords), Math.max(...allCoords)];
};
var selectReferenceLinesDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectReferenceLinesByAxis, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, combineLinesDomain);
var selectReferenceElementsDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectReferenceDotsDomain, selectReferenceLinesDomain, selectReferenceAreasDomain, (dotsDomain, linesDomain, areasDomain) => {
  return mergeDomains(dotsDomain, areasDomain, linesDomain);
});
var combineNumericalDomain = (axisSettings, domainDefinition, domainFromUserPreference, domainOfStackGroups, dataAndErrorBarsDomain, referenceElementsDomain, layout, axisType) => {
  if (domainFromUserPreference != null) {
    // We're done! No need to compute anything else.
    return domainFromUserPreference;
  }
  var shouldIncludeDomainOfStackGroups = layout === 'vertical' && axisType === 'xAxis' || layout === 'horizontal' && axisType === 'yAxis';
  var mergedDomains = shouldIncludeDomainOfStackGroups ? mergeDomains(domainOfStackGroups, referenceElementsDomain, dataAndErrorBarsDomain) : mergeDomains(referenceElementsDomain, dataAndErrorBarsDomain);
  return (0,_util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .parseNumericalUserDomain */ .v1)(domainDefinition, mergedDomains, axisSettings.allowDataOverflow);
};
var selectNumericalDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, selectDomainDefinition, selectDomainFromUserPreference, selectDomainOfStackGroups, selectDomainOfAllAppliedNumericalValuesIncludingErrorValues, selectReferenceElementsDomain, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineNumericalDomain, {
  memoizeOptions: {
    resultEqualityCheck: _numberDomainEqualityCheck__WEBPACK_IMPORTED_MODULE_25__/* .numberDomainEqualityCheck */ .o
  }
});

/**
 * Expand by design maps everything between 0 and 1,
 * there is nothing to compute.
 * See https://d3js.org/d3-shape/stack#stack-offsets
 */
var expandDomain = [0, 1];
var combineAxisDomain = (axisSettings, layout, displayedData, allAppliedValues, stackOffsetType, axisType, numericalDomain) => {
  if ((axisSettings == null || displayedData == null || displayedData.length === 0) && numericalDomain === undefined) {
    return undefined;
  }
  var {
    dataKey,
    type
  } = axisSettings;
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, axisType);
  if (isCategorical && dataKey == null) {
    return es_toolkit_compat_range__WEBPACK_IMPORTED_MODULE_1___default()(0, displayedData.length);
  }
  if (type === 'category') {
    return computeDomainOfTypeCategory(allAppliedValues, axisSettings, isCategorical);
  }
  if (stackOffsetType === 'expand') {
    return expandDomain;
  }
  return numericalDomain;
};
var selectAxisDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectDisplayedData, selectAllAppliedValues, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_15__/* .selectStackOffsetType */ .eC, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N, selectNumericalDomain], combineAxisDomain);
var combineRealScaleType = (axisConfig, layout, hasBar, chartType, axisType) => {
  if (axisConfig == null) {
    return undefined;
  }
  var {
    scale,
    type
  } = axisConfig;
  if (scale === 'auto') {
    if (layout === 'radial' && axisType === 'radiusAxis') {
      return 'band';
    }
    if (layout === 'radial' && axisType === 'angleAxis') {
      return 'linear';
    }
    if (type === 'category' && chartType && (chartType.indexOf('LineChart') >= 0 || chartType.indexOf('AreaChart') >= 0 || chartType.indexOf('ComposedChart') >= 0 && !hasBar)) {
      return 'point';
    }
    if (type === 'category') {
      return 'band';
    }
    return 'linear';
  }
  if (typeof scale === 'string') {
    var name = "scale".concat((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .upperFirst */ .Zb)(scale));
    return name in victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__ ? name : 'point';
  }
  return undefined;
};
var selectRealScaleType = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectHasBar, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_15__/* .selectChartName */ .iO, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineRealScaleType);
function getD3ScaleFromType(realScaleType) {
  if (realScaleType == null) {
    return undefined;
  }
  if (realScaleType in victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__) {
    // @ts-expect-error we should do better type verification here
    return victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__[realScaleType]();
  }
  var name = "scale".concat((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .upperFirst */ .Zb)(realScaleType));
  if (name in victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__) {
    // @ts-expect-error we should do better type verification here
    return victory_vendor_d3_scale__WEBPACK_IMPORTED_MODULE_2__[name]();
  }
  return undefined;
}
function combineScaleFunction(axis, realScaleType, axisDomain, axisRange) {
  if (axisDomain == null || axisRange == null) {
    return undefined;
  }
  if (typeof axis.scale === 'function') {
    // @ts-expect-error we're going to assume here that if axis.scale is a function then it is a d3Scale function
    return axis.scale.copy().domain(axisDomain).range(axisRange);
  }
  var d3ScaleFunction = getD3ScaleFromType(realScaleType);
  if (d3ScaleFunction == null) {
    return undefined;
  }
  var scale = d3ScaleFunction.domain(axisDomain).range(axisRange);
  // I don't like this function because it mutates the scale. We should come up with a way to compute the domain up front.
  (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .checkDomainOfScale */ .YB)(scale);
  return scale;
}
var combineNiceTicks = (axisDomain, axisSettings, realScaleType) => {
  var domainDefinition = getDomainDefinition(axisSettings);
  if (realScaleType !== 'auto' && realScaleType !== 'linear') {
    return undefined;
  }
  if (axisSettings != null && axisSettings.tickCount && Array.isArray(domainDefinition) && (domainDefinition[0] === 'auto' || domainDefinition[1] === 'auto') && (0,_util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .isWellFormedNumberDomain */ .JH)(axisDomain)) {
    return (0,_util_scale__WEBPACK_IMPORTED_MODULE_10__/* .getNiceTickValues */ .d)(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals);
  }
  if (axisSettings != null && axisSettings.tickCount && axisSettings.type === 'number' && (0,_util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .isWellFormedNumberDomain */ .JH)(axisDomain)) {
    return (0,_util_scale__WEBPACK_IMPORTED_MODULE_10__/* .getTickValuesFixedDomain */ .M)(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals);
  }
  return undefined;
};
var selectNiceTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAxisDomain, selectAxisSettings, selectRealScaleType], combineNiceTicks);
var combineAxisDomainWithNiceTicks = (axisSettings, domain, niceTicks, axisType) => {
  if (
  /*
   * Angle axis for some reason uses nice ticks when rendering axis tick labels,
   * but doesn't use nice ticks for extending domain like all the other axes do.
   * Not really sure why? Is there a good reason,
   * or is it just because someone added support for nice ticks to the other axes and forgot this one?
   */
  axisType !== 'angleAxis' && (axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.type) === 'number' && (0,_util_isDomainSpecifiedByUser__WEBPACK_IMPORTED_MODULE_7__/* .isWellFormedNumberDomain */ .JH)(domain) && Array.isArray(niceTicks) && niceTicks.length > 0) {
    var minFromDomain = domain[0];
    var minFromTicks = niceTicks[0];
    var maxFromDomain = domain[1];
    var maxFromTicks = niceTicks[niceTicks.length - 1];
    return [Math.min(minFromDomain, minFromTicks), Math.max(maxFromDomain, maxFromTicks)];
  }
  return domain;
};
var selectAxisDomainIncludingNiceTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, selectAxisDomain, selectNiceTicks, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineAxisDomainWithNiceTicks);

/**
 * Returns the smallest gap, between two numbers in the data, as a ratio of the whole range (max - min).
 * Ignores domain provided by user and only considers domain from data.
 *
 * The result is a number between 0 and 1.
 */
var selectSmallestDistanceBetweenValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectAllAppliedValues, selectBaseAxis, (allDataSquished, axisSettings) => {
  if (!axisSettings || axisSettings.type !== 'number') {
    return undefined;
  }
  var smallestDistanceBetweenValues = Infinity;
  var sortedValues = Array.from(onlyAllowNumbers(allDataSquished.map(d => d.value))).sort((a, b) => a - b);
  if (sortedValues.length < 2) {
    return Infinity;
  }
  var diff = sortedValues[sortedValues.length - 1] - sortedValues[0];
  if (diff === 0) {
    return Infinity;
  }
  // Only do n - 1 distance calculations because there's only n - 1 distances between n values.
  for (var i = 0; i < sortedValues.length - 1; i++) {
    var distance = sortedValues[i + 1] - sortedValues[i];
    smallestDistanceBetweenValues = Math.min(smallestDistanceBetweenValues, distance);
  }
  return smallestDistanceBetweenValues / diff;
});
var selectCalculatedPadding = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectSmallestDistanceBetweenValues, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_15__/* .selectBarCategoryGap */ .gY, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, (_1, _2, _3, padding) => padding, (smallestDistanceInPercent, layout, barCategoryGap, offset, padding) => {
  if (!(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(smallestDistanceInPercent)) {
    return 0;
  }
  var rangeWidth = layout === 'vertical' ? offset.height : offset.width;
  if (padding === 'gap') {
    return smallestDistanceInPercent * rangeWidth / 2;
  }
  if (padding === 'no-gap') {
    var gap = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .getPercentValue */ .F4)(barCategoryGap, smallestDistanceInPercent * rangeWidth);
    var halfBand = smallestDistanceInPercent * rangeWidth / 2;
    return halfBand - gap - (halfBand - gap) / rangeWidth * gap;
  }
  return 0;
});
var selectCalculatedXAxisPadding = (state, axisId) => {
  var xAxisSettings = selectXAxisSettings(state, axisId);
  if (xAxisSettings == null || typeof xAxisSettings.padding !== 'string') {
    return 0;
  }
  return selectCalculatedPadding(state, 'xAxis', axisId, xAxisSettings.padding);
};
var selectCalculatedYAxisPadding = (state, axisId) => {
  var yAxisSettings = selectYAxisSettings(state, axisId);
  if (yAxisSettings == null || typeof yAxisSettings.padding !== 'string') {
    return 0;
  }
  return selectCalculatedPadding(state, 'yAxis', axisId, yAxisSettings.padding);
};
var selectXAxisPadding = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectXAxisSettings, selectCalculatedXAxisPadding, (xAxisSettings, calculated) => {
  var _padding$left, _padding$right;
  if (xAxisSettings == null) {
    return {
      left: 0,
      right: 0
    };
  }
  var {
    padding
  } = xAxisSettings;
  if (typeof padding === 'string') {
    return {
      left: calculated,
      right: calculated
    };
  }
  return {
    left: ((_padding$left = padding.left) !== null && _padding$left !== void 0 ? _padding$left : 0) + calculated,
    right: ((_padding$right = padding.right) !== null && _padding$right !== void 0 ? _padding$right : 0) + calculated
  };
});
var selectYAxisPadding = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectYAxisSettings, selectCalculatedYAxisPadding, (yAxisSettings, calculated) => {
  var _padding$top, _padding$bottom;
  if (yAxisSettings == null) {
    return {
      top: 0,
      bottom: 0
    };
  }
  var {
    padding
  } = yAxisSettings;
  if (typeof padding === 'string') {
    return {
      top: calculated,
      bottom: calculated
    };
  }
  return {
    top: ((_padding$top = padding.top) !== null && _padding$top !== void 0 ? _padding$top : 0) + calculated,
    bottom: ((_padding$bottom = padding.bottom) !== null && _padding$bottom !== void 0 ? _padding$bottom : 0) + calculated
  };
});
var combineXAxisRange = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectXAxisPadding, _brushSelectors__WEBPACK_IMPORTED_MODULE_14__/* .selectBrushDimensions */ .U, _brushSelectors__WEBPACK_IMPORTED_MODULE_14__/* .selectBrushSettings */ .C, (_state, _axisId, isPanorama) => isPanorama], (offset, padding, brushDimensions, _ref4, isPanorama) => {
  var {
    padding: brushPadding
  } = _ref4;
  if (isPanorama) {
    return [brushPadding.left, brushDimensions.width - brushPadding.right];
  }
  return [offset.left + padding.left, offset.left + offset.width - padding.right];
});
var combineYAxisRange = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectYAxisPadding, _brushSelectors__WEBPACK_IMPORTED_MODULE_14__/* .selectBrushDimensions */ .U, _brushSelectors__WEBPACK_IMPORTED_MODULE_14__/* .selectBrushSettings */ .C, (_state, _axisId, isPanorama) => isPanorama], (offset, layout, padding, brushDimensions, _ref5, isPanorama) => {
  var {
    padding: brushPadding
  } = _ref5;
  if (isPanorama) {
    return [brushDimensions.height - brushPadding.bottom, brushPadding.top];
  }
  if (layout === 'horizontal') {
    return [offset.top + offset.height - padding.bottom, offset.top + padding.top];
  }
  return [offset.top + padding.top, offset.top + offset.height - padding.bottom];
});
var selectAxisRange = (state, axisType, axisId, isPanorama) => {
  var _selectZAxisSettings;
  switch (axisType) {
    case 'xAxis':
      return combineXAxisRange(state, axisId, isPanorama);
    case 'yAxis':
      return combineYAxisRange(state, axisId, isPanorama);
    case 'zAxis':
      return (_selectZAxisSettings = selectZAxisSettings(state, axisId)) === null || _selectZAxisSettings === void 0 ? void 0 : _selectZAxisSettings.range;
    case 'angleAxis':
      return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectAngleAxisRange */ .Cv)(state);
    case 'radiusAxis':
      return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_16__/* .selectRadiusAxisRange */ .Dc)(state, axisId);
    default:
      return undefined;
  }
};
var selectAxisRangeWithReverse = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, selectAxisRange], _combiners_combineAxisRangeWithReverse__WEBPACK_IMPORTED_MODULE_19__/* .combineAxisRangeWithReverse */ .I);
var selectAxisScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, selectRealScaleType, selectAxisDomainIncludingNiceTicks, selectAxisRangeWithReverse], combineScaleFunction);
var selectErrorBarsSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectCartesianItemsSettings, selectAllErrorBarSettings, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineRelevantErrorBarSettings);
function compareIds(a, b) {
  if (a.id < b.id) {
    return -1;
  }
  if (a.id > b.id) {
    return 1;
  }
  return 0;
}
var pickAxisOrientation = (_state, orientation) => orientation;
var pickMirror = (_state, _orientation, mirror) => mirror;
var selectAllXAxesWithOffsetType = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_selectAllAxes__WEBPACK_IMPORTED_MODULE_12__/* .selectAllXAxes */ .h, pickAxisOrientation, pickMirror, (allAxes, orientation, mirror) => allAxes.filter(axis => axis.orientation === orientation).filter(axis => axis.mirror === mirror).sort(compareIds));
var selectAllYAxesWithOffsetType = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_selectAllAxes__WEBPACK_IMPORTED_MODULE_12__/* .selectAllYAxes */ .W, pickAxisOrientation, pickMirror, (allAxes, orientation, mirror) => allAxes.filter(axis => axis.orientation === orientation).filter(axis => axis.mirror === mirror).sort(compareIds));
var getXAxisSize = (offset, axisSettings) => {
  return {
    width: offset.width,
    height: axisSettings.height
  };
};
var getYAxisSize = (offset, axisSettings) => {
  var width = typeof axisSettings.width === 'number' ? axisSettings.width : _util_Constants__WEBPACK_IMPORTED_MODULE_20__/* .DEFAULT_Y_AXIS_WIDTH */ .tQ;
  return {
    width,
    height: offset.height
  };
};
var selectXAxisSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectXAxisSettings, getXAxisSize);
var combineXAxisPositionStartingPoint = (offset, orientation, chartHeight) => {
  switch (orientation) {
    case 'top':
      return offset.top;
    case 'bottom':
      return chartHeight - offset.bottom;
    default:
      return 0;
  }
};
var combineYAxisPositionStartingPoint = (offset, orientation, chartWidth) => {
  switch (orientation) {
    case 'left':
      return offset.left;
    case 'right':
      return chartWidth - offset.right;
    default:
      return 0;
  }
};
var selectAllXAxesOffsetSteps = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_containerSelectors__WEBPACK_IMPORTED_MODULE_11__/* .selectChartHeight */ .A$, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectAllXAxesWithOffsetType, pickAxisOrientation, pickMirror, (chartHeight, offset, allAxesWithSameOffsetType, orientation, mirror) => {
  var steps = {};
  var position;
  allAxesWithSameOffsetType.forEach(axis => {
    var axisSize = getXAxisSize(offset, axis);
    if (position == null) {
      position = combineXAxisPositionStartingPoint(offset, orientation, chartHeight);
    }
    var needSpace = orientation === 'top' && !mirror || orientation === 'bottom' && mirror;
    steps[axis.id] = position - Number(needSpace) * axisSize.height;
    position += (needSpace ? -1 : 1) * axisSize.height;
  });
  return steps;
});
var selectAllYAxesOffsetSteps = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_containerSelectors__WEBPACK_IMPORTED_MODULE_11__/* .selectChartWidth */ .Lp, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectAllYAxesWithOffsetType, pickAxisOrientation, pickMirror, (chartWidth, offset, allAxesWithSameOffsetType, orientation, mirror) => {
  var steps = {};
  var position;
  allAxesWithSameOffsetType.forEach(axis => {
    var axisSize = getYAxisSize(offset, axis);
    if (position == null) {
      position = combineYAxisPositionStartingPoint(offset, orientation, chartWidth);
    }
    var needSpace = orientation === 'left' && !mirror || orientation === 'right' && mirror;
    steps[axis.id] = position - Number(needSpace) * axisSize.width;
    position += (needSpace ? -1 : 1) * axisSize.width;
  });
  return steps;
});
var selectXAxisOffsetSteps = (state, axisId) => {
  var axisSettings = selectXAxisSettings(state, axisId);
  if (axisSettings == null) {
    return undefined;
  }
  return selectAllXAxesOffsetSteps(state, axisSettings.orientation, axisSettings.mirror);
};
var selectXAxisPosition = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectXAxisSettings, selectXAxisOffsetSteps, (_, axisId) => axisId], (offset, axisSettings, allSteps, axisId) => {
  if (axisSettings == null) {
    return undefined;
  }
  var stepOfThisAxis = allSteps === null || allSteps === void 0 ? void 0 : allSteps[axisId];
  if (stepOfThisAxis == null) {
    return {
      x: offset.left,
      y: 0
    };
  }
  return {
    x: offset.left,
    y: stepOfThisAxis
  };
});
var selectYAxisOffsetSteps = (state, axisId) => {
  var axisSettings = selectYAxisSettings(state, axisId);
  if (axisSettings == null) {
    return undefined;
  }
  return selectAllYAxesOffsetSteps(state, axisSettings.orientation, axisSettings.mirror);
};
var selectYAxisPosition = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectYAxisSettings, selectYAxisOffsetSteps, (_, axisId) => axisId], (offset, axisSettings, allSteps, axisId) => {
  if (axisSettings == null) {
    return undefined;
  }
  var stepOfThisAxis = allSteps === null || allSteps === void 0 ? void 0 : allSteps[axisId];
  if (stepOfThisAxis == null) {
    return {
      x: 0,
      y: offset.top
    };
  }
  return {
    x: stepOfThisAxis,
    y: offset.top
  };
});
var selectYAxisSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_13__/* .selectChartOffsetInternal */ .HZ, selectYAxisSettings, (offset, axisSettings) => {
  var width = typeof axisSettings.width === 'number' ? axisSettings.width : _util_Constants__WEBPACK_IMPORTED_MODULE_20__/* .DEFAULT_Y_AXIS_WIDTH */ .tQ;
  return {
    width,
    height: offset.height
  };
});
var selectCartesianAxisSize = (state, axisType, axisId) => {
  switch (axisType) {
    case 'xAxis':
      {
        return selectXAxisSize(state, axisId).width;
      }
    case 'yAxis':
      {
        return selectYAxisSize(state, axisId).height;
      }
    default:
      {
        return undefined;
      }
  }
};
var combineDuplicateDomain = (chartLayout, appliedValues, axis, axisType) => {
  if (axis == null) {
    return undefined;
  }
  var {
    allowDuplicatedCategory,
    type,
    dataKey
  } = axis;
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(chartLayout, axisType);
  var allData = appliedValues.map(av => av.value);
  if (dataKey && isCategorical && type === 'category' && allowDuplicatedCategory && (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .hasDuplicate */ .CG)(allData)) {
    return allData;
  }
  return undefined;
};
var selectDuplicateDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectAllAppliedValues, selectBaseAxis, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineDuplicateDomain);
var combineCategoricalDomain = (layout, appliedValues, axis, axisType) => {
  if (axis == null || axis.dataKey == null) {
    return undefined;
  }
  var {
    type,
    scale
  } = axis;
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, axisType);
  if (isCategorical && (type === 'number' || scale !== 'auto')) {
    return appliedValues.map(d => d.value);
  }
  return undefined;
};
var selectCategoricalDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectAllAppliedValues, selectAxisSettings, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineCategoricalDomain);
var selectAxisPropsNeededForCartesianGridTicksGenerator = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectCartesianAxisSettings, selectRealScaleType, selectAxisScale, selectDuplicateDomain, selectCategoricalDomain, selectAxisRange, selectNiceTicks, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], (layout, axis, realScaleType, scale, duplicateDomain, categoricalDomain, axisRange, niceTicks, axisType) => {
  if (axis == null) {
    return null;
  }
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, axisType);
  return {
    angle: axis.angle,
    interval: axis.interval,
    minTickGap: axis.minTickGap,
    orientation: axis.orientation,
    tick: axis.tick,
    tickCount: axis.tickCount,
    tickFormatter: axis.tickFormatter,
    ticks: axis.ticks,
    type: axis.type,
    unit: axis.unit,
    axisType,
    categoricalDomain,
    duplicateDomain,
    isCategorical,
    niceTicks,
    range: axisRange,
    realScaleType,
    scale
  };
});
var combineAxisTicks = (layout, axis, realScaleType, scale, niceTicks, axisRange, duplicateDomain, categoricalDomain, axisType) => {
  if (axis == null || scale == null) {
    return undefined;
  }
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, axisType);
  var {
    type,
    ticks,
    tickCount
  } = axis;

  // This is testing for `scaleBand` but for band axis the type is reported as `band` so this looks like a dead code with a workaround elsewhere?
  var offsetForBand = realScaleType === 'scaleBand' && typeof scale.bandwidth === 'function' ? scale.bandwidth() / 2 : 2;
  var offset = type === 'category' && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
  offset = axisType === 'angleAxis' && axisRange != null && axisRange.length >= 2 ? (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .mathSign */ .sA)(axisRange[0] - axisRange[1]) * 2 * offset : offset;

  // The ticks set by user should only affect the ticks adjacent to axis line
  var ticksOrNiceTicks = ticks || niceTicks;
  if (ticksOrNiceTicks) {
    var result = ticksOrNiceTicks.map((entry, index) => {
      var scaleContent = duplicateDomain ? duplicateDomain.indexOf(entry) : entry;
      return {
        index,
        // If the scaleContent is not a number, the coordinate will be NaN.
        // That could be the case for example with a PointScale and a string as domain.
        coordinate: scale(scaleContent) + offset,
        value: entry,
        offset
      };
    });
    return result.filter(row => !(0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .isNan */ .M8)(row.coordinate));
  }

  // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
  if (isCategorical && categoricalDomain) {
    return categoricalDomain.map((entry, index) => ({
      coordinate: scale(entry) + offset,
      value: entry,
      index,
      offset
    }));
  }
  if (scale.ticks) {
    return scale.ticks(tickCount)
    // @ts-expect-error why does the offset go here? The type does not require it
    .map(entry => ({
      coordinate: scale(entry) + offset,
      value: entry,
      offset
    }));
  }

  // When axis has duplicated text, serial numbers are used to generate scale
  return scale.domain().map((entry, index) => ({
    coordinate: scale(entry) + offset,
    value: duplicateDomain ? duplicateDomain[entry] : entry,
    index,
    offset
  }));
};
var selectTicksOfAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectAxisSettings, selectRealScaleType, selectAxisScale, selectNiceTicks, selectAxisRange, selectDuplicateDomain, selectCategoricalDomain, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineAxisTicks);
var combineGraphicalItemTicks = (layout, axis, scale, axisRange, duplicateDomain, categoricalDomain, axisType) => {
  if (axis == null || scale == null || axisRange == null || axisRange[0] === axisRange[1]) {
    return undefined;
  }
  var isCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, axisType);
  var {
    tickCount
  } = axis;
  var offset = 0;
  offset = axisType === 'angleAxis' && (axisRange === null || axisRange === void 0 ? void 0 : axisRange.length) >= 2 ? (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_8__/* .mathSign */ .sA)(axisRange[0] - axisRange[1]) * 2 * offset : offset;

  // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
  if (isCategorical && categoricalDomain) {
    return categoricalDomain.map((entry, index) => ({
      coordinate: scale(entry) + offset,
      value: entry,
      index,
      offset
    }));
  }
  if (scale.ticks) {
    return scale.ticks(tickCount)
    // @ts-expect-error why does the offset go here? The type does not require it
    .map(entry => ({
      coordinate: scale(entry) + offset,
      value: entry,
      offset
    }));
  }

  // When axis has duplicated text, serial numbers are used to generate scale
  return scale.domain().map((entry, index) => ({
    coordinate: scale(entry) + offset,
    value: duplicateDomain ? duplicateDomain[entry] : entry,
    index,
    offset
  }));
};
var selectTicksOfGraphicalItem = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, selectAxisSettings, selectAxisScale, selectAxisRange, selectDuplicateDomain, selectCategoricalDomain, _pickAxisType__WEBPACK_IMPORTED_MODULE_17__/* .pickAxisType */ .N], combineGraphicalItemTicks);
var selectAxisWithScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectBaseAxis, selectAxisScale, (axis, scale) => {
  if (axis == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axis), {}, {
    scale
  });
});
var selectZAxisScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBaseAxis, selectRealScaleType, selectAxisDomain, selectAxisRangeWithReverse], combineScaleFunction);
var selectZAxisWithScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)((state, _axisType, axisId) => selectZAxisSettings(state, axisId), selectZAxisScale, (axis, scale) => {
  if (axis == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axis), {}, {
    scale
  });
});

/**
 * We are also going to need to implement polar chart directions if we want to support keyboard controls for those.
 */

var selectChartDirection = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_4__/* .selectChartLayout */ .fz, _selectAllAxes__WEBPACK_IMPORTED_MODULE_12__/* .selectAllXAxes */ .h, _selectAllAxes__WEBPACK_IMPORTED_MODULE_12__/* .selectAllYAxes */ .W], (layout, allXAxes, allYAxes) => {
  switch (layout) {
    case 'horizontal':
      {
        return allXAxes.some(axis => axis.reversed) ? 'right-to-left' : 'left-to-right';
      }
    case 'vertical':
      {
        return allYAxes.some(axis => axis.reversed) ? 'bottom-to-top' : 'top-to-bottom';
      }
    // TODO: make this better. For now, right arrow triggers "forward", left arrow "back"
    // however, the tooltip moves an unintuitive direction because of how the indices are rendered
    case 'centric':
    case 'radial':
      {
        return 'left-to-right';
      }
    default:
      {
        return undefined;
      }
  }
});

/***/ }),

/***/ 15894:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P2: () => (/* binding */ createLabeledScales),
/* harmony export */   bx: () => (/* binding */ getAngledRectangleWidth),
/* harmony export */   sl: () => (/* binding */ rectWithPoints),
/* harmony export */   vh: () => (/* binding */ rectWithCoords)
/* harmony export */ });
/* unused harmony exports ScaleHelper, normalizeAngle */
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var rectWithPoints = (_ref, _ref2) => {
  var {
    x: x1,
    y: y1
  } = _ref;
  var {
    x: x2,
    y: y2
  } = _ref2;
  return {
    x: Math.min(x1, x2),
    y: Math.min(y1, y2),
    width: Math.abs(x2 - x1),
    height: Math.abs(y2 - y1)
  };
};

/**
 * Compute the x, y, width, and height of a box from two reference points.
 * @param  {Object} coords     x1, x2, y1, and y2
 * @return {Object} object
 */
var rectWithCoords = _ref3 => {
  var {
    x1,
    y1,
    x2,
    y2
  } = _ref3;
  return rectWithPoints({
    x: x1,
    y: y1
  }, {
    x: x2,
    y: y2
  });
};
class ScaleHelper {
  static create(obj) {
    return new ScaleHelper(obj);
  }
  constructor(scale) {
    this.scale = scale;
  }
  get domain() {
    return this.scale.domain;
  }
  get range() {
    return this.scale.range;
  }
  get rangeMin() {
    return this.range()[0];
  }
  get rangeMax() {
    return this.range()[1];
  }
  get bandwidth() {
    return this.scale.bandwidth;
  }
  apply(value) {
    var {
      bandAware,
      position
    } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    if (value === undefined) {
      return undefined;
    }
    if (position) {
      switch (position) {
        case 'start':
          {
            return this.scale(value);
          }
        case 'middle':
          {
            var offset = this.bandwidth ? this.bandwidth() / 2 : 0;
            return this.scale(value) + offset;
          }
        case 'end':
          {
            var _offset = this.bandwidth ? this.bandwidth() : 0;
            return this.scale(value) + _offset;
          }
        default:
          {
            return this.scale(value);
          }
      }
    }
    if (bandAware) {
      var _offset2 = this.bandwidth ? this.bandwidth() / 2 : 0;
      return this.scale(value) + _offset2;
    }
    return this.scale(value);
  }
  isInRange(value) {
    var range = this.range();
    var first = range[0];
    var last = range[range.length - 1];
    return first <= last ? value >= first && value <= last : value >= last && value <= first;
  }
}
_defineProperty(ScaleHelper, "EPS", 1e-4);
var createLabeledScales = options => {
  var scales = Object.keys(options).reduce((res, key) => _objectSpread(_objectSpread({}, res), {}, {
    [key]: ScaleHelper.create(options[key])
  }), {});
  return _objectSpread(_objectSpread({}, scales), {}, {
    apply(coord) {
      var {
        bandAware,
        position
      } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return Object.fromEntries(Object.entries(coord).map(_ref4 => {
        var [label, value] = _ref4;
        return [label, scales[label].apply(value, {
          bandAware,
          position
        })];
      }));
    },
    isInRange(coord) {
      return Object.keys(coord).every(label => scales[label].isInRange(coord[label]));
    }
  });
};

/** Normalizes the angle so that 0 <= angle < 180.
 * @param {number} angle Angle in degrees.
 * @return {number} the normalized angle with a value of at least 0 and never greater or equal to 180. */
function normalizeAngle(angle) {
  return (angle % 180 + 180) % 180;
}

/** Calculates the width of the largest horizontal line that fits inside a rectangle that is displayed at an angle.
 * @param {Object} size Width and height of the text in a horizontal position.
 * @param {number} angle Angle in degrees in which the text is displayed.
 * @return {number} The width of the largest horizontal line that fits inside a rectangle that is displayed at an angle.
 */
var getAngledRectangleWidth = function getAngledRectangleWidth(_ref5) {
  var {
    width,
    height
  } = _ref5;
  var angle = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  // Ensure angle is >= 0 && < 180
  var normalizedAngle = normalizeAngle(angle);
  var angleRadians = normalizedAngle * Math.PI / 180;

  /* Depending on the height and width of the rectangle, we may need to use different formulas to calculate the angled
   * width. This threshold defines when each formula should kick in. */
  var angleThreshold = Math.atan(height / width);
  var angledWidth = angleRadians > angleThreshold && angleRadians < Math.PI - angleThreshold ? height / Math.sin(angleRadians) : width / Math.cos(angleRadians);
  return Math.abs(angledWidth);
};

/***/ }),

/***/ 15950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ selectTooltipAxisType)
/* harmony export */ });
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(19287);

var selectTooltipAxisType = state => {
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_0__/* .selectChartLayout */ .fz)(state);
  if (layout === 'horizontal') {
    return 'xAxis';
  }
  if (layout === 'vertical') {
    return 'yAxis';
  }
  if (layout === 'centric') {
    return 'angleAxis';
  }
  return 'radiusAxis';
};

/***/ }),

/***/ 16281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ selectPolarGridAngles),
/* harmony export */   k: () => (/* binding */ selectPolarGridRadii)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _polarScaleSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28871);


var selectAngleAxisTicks = (state, anglexisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectPolarAxisTicks */ .YF)(state, 'angleAxis', anglexisId, false);
var selectPolarGridAngles = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisTicks], ticks => {
  if (!ticks) {
    return undefined;
  }
  return ticks.map(tick => tick.coordinate);
});
var selectRadiusAxisTicks = (state, radiusAxisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectPolarAxisTicks */ .YF)(state, 'radiusAxis', radiusAxisId, false);
var selectPolarGridRadii = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadiusAxisTicks], ticks => {
  if (!ticks) {
    return undefined;
  }
  return ticks.map(tick => tick.coordinate);
});

/***/ }),

/***/ 18351:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ selectTooltipPayloadSearcher)
/* harmony export */ });
var selectTooltipPayloadSearcher = state => state.options.tooltipPayloadSearcher;

/***/ }),

/***/ 18467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EX: () => (/* binding */ selectPieSectors),
/* harmony export */   Ez: () => (/* binding */ selectPieLegend)
/* harmony export */ });
/* unused harmony export selectDisplayedData */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _polar_Pie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63161);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(98453);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36189);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33964);
/* harmony import */ var _polarSelectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19033);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






var pickId = (_state, id) => id;
var selectSynchronisedPieSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_polarSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectUnfilteredPolarItems */ .nz, pickId], (graphicalItems, id) => graphicalItems.filter(item => item.type === 'pie').find(item => item.id === id));

// Keep stable reference to an empty array to prevent re-renders
var emptyArray = [];
var pickCells = (_state, _id, cells) => {
  if ((cells === null || cells === void 0 ? void 0 : cells.length) === 0) {
    return emptyArray;
  }
  return cells;
};
var selectDisplayedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3, selectSynchronisedPieSettings, pickCells], (_ref, pieSettings, cells) => {
  var {
    chartData
  } = _ref;
  if (pieSettings == null) {
    return undefined;
  }
  var displayedData;
  if ((pieSettings === null || pieSettings === void 0 ? void 0 : pieSettings.data) != null && pieSettings.data.length > 0) {
    displayedData = pieSettings.data;
  } else {
    displayedData = chartData;
  }
  if ((!displayedData || !displayedData.length) && cells != null) {
    displayedData = cells.map(cell => _objectSpread(_objectSpread({}, pieSettings.presentationProps), cell.props));
  }
  if (displayedData == null) {
    return undefined;
  }
  return displayedData;
});
var selectPieLegend = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDisplayedData, selectSynchronisedPieSettings, pickCells], (displayedData, pieSettings, cells) => {
  if (displayedData == null || pieSettings == null) {
    return undefined;
  }
  return displayedData.map((entry, i) => {
    var _cells$i;
    var name = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__/* .getValueByDataKey */ .kr)(entry, pieSettings.nameKey, pieSettings.name);
    var color;
    if (cells !== null && cells !== void 0 && (_cells$i = cells[i]) !== null && _cells$i !== void 0 && (_cells$i = _cells$i.props) !== null && _cells$i !== void 0 && _cells$i.fill) {
      color = cells[i].props.fill;
    } else if (typeof entry === 'object' && entry != null && 'fill' in entry) {
      color = entry.fill;
    } else {
      color = pieSettings.fill;
    }
    return {
      value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__/* .getTooltipNameProp */ .uM)(name, pieSettings.dataKey),
      color,
      payload: entry,
      type: pieSettings.legendType
    };
  });
});
var selectPieSectors = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectDisplayedData, selectSynchronisedPieSettings, pickCells, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__/* .selectChartOffsetInternal */ .HZ], (displayedData, pieSettings, cells, offset) => {
  if (pieSettings == null || displayedData == null) {
    return undefined;
  }
  return (0,_polar_Pie__WEBPACK_IMPORTED_MODULE_1__/* .computePieSectors */ .L)({
    offset,
    pieSettings,
    displayedData,
    cells
  });
});

/***/ }),

/***/ 19033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Az: () => (/* binding */ selectPolarNiceTicks),
/* harmony export */   IS: () => (/* binding */ selectPolarAppliedValues),
/* harmony export */   iz: () => (/* binding */ selectPolarAxisDomainIncludingNiceTicks),
/* harmony export */   m8: () => (/* binding */ selectPolarItemsSettings),
/* harmony export */   nz: () => (/* binding */ selectUnfilteredPolarItems)
/* harmony export */ });
/* unused harmony exports selectPolarDisplayedData, selectAllPolarAppliedNumericalValues, selectPolarAxisDomain */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98453);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11114);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19287);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(33964);
/* harmony import */ var _pickAxisType__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41927);
/* harmony import */ var _pickAxisId__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(79926);
/* harmony import */ var _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(82695);








var selectUnfilteredPolarItems = state => state.graphicalItems.polarItems;
var selectAxisPredicate = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N, _pickAxisId__WEBPACK_IMPORTED_MODULE_6__/* .pickAxisId */ .E], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .itemAxisPredicate */ .eo);
var selectPolarItemsSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectUnfilteredPolarItems, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, selectAxisPredicate], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineGraphicalItemsSettings */ .ec);
var selectPolarGraphicalItemsData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarItemsSettings], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineGraphicalItemsData */ .rj);
var selectPolarDisplayedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarGraphicalItemsData, _dataSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineDisplayedData */ .Nk);
var selectPolarAppliedValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarDisplayedData, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, selectPolarItemsSettings], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineAppliedValues */ .fb);
var selectAllPolarAppliedNumericalValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarDisplayedData, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, selectPolarItemsSettings], (data, axisSettings, items) => {
  if (items.length > 0) {
    return data.flatMap(entry => {
      return items.flatMap(item => {
        var _axisSettings$dataKey;
        var valueByDataKey = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__/* .getValueByDataKey */ .kr)(entry, (_axisSettings$dataKey = axisSettings.dataKey) !== null && _axisSettings$dataKey !== void 0 ? _axisSettings$dataKey : item.dataKey);
        return {
          value: valueByDataKey,
          errorDomain: [] // polar charts do not have error bars
        };
      });
    }).filter(Boolean);
  }
  if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null) {
    return data.map(item => ({
      value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_4__/* .getValueByDataKey */ .kr)(item, axisSettings.dataKey),
      errorDomain: []
    }));
  }
  return data.map(entry => ({
    value: entry,
    errorDomain: []
  }));
});
var unsupportedInPolarChart = () => undefined;
var selectDomainOfAllPolarAppliedNumericalValues = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarDisplayedData, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, selectPolarItemsSettings, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectAllErrorBarSettings */ .CH, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineDomainOfAllAppliedNumericalValuesIncludingErrorValues */ .EZ);
var selectPolarNumericalDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectDomainDefinition */ .AV, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectDomainFromUserPreference */ .Lu, unsupportedInPolarChart, selectDomainOfAllPolarAppliedNumericalValues, unsupportedInPolarChart, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineNumericalDomain */ .wL);
var selectPolarAxisDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectPolarDisplayedData, selectPolarAppliedValues, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_7__/* .selectStackOffsetType */ .eC, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N, selectPolarNumericalDomain], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineAxisDomain */ .tP);
var selectPolarNiceTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarAxisDomain, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectRealScaleType */ .xM], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineNiceTicks */ .xp);
var selectPolarAxisDomainIncludingNiceTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectBaseAxis */ .DP, selectPolarAxisDomain, selectPolarNiceTicks, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .combineAxisDomainWithNiceTicks */ .g1);

/***/ }),

/***/ 19495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ combineAxisRangeWithReverse)
/* harmony export */ });
var combineAxisRangeWithReverse = (axisSettings, axisRange) => {
  if (!axisSettings || !axisRange) {
    return undefined;
  }
  if (axisSettings !== null && axisSettings !== void 0 && axisSettings.reversed) {
    return [axisRange[1], axisRange[0]];
  }
  return axisRange;
};

/***/ }),

/***/ 19794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ polarOptionsReducer),
/* harmony export */   U: () => (/* binding */ updatePolarOptions)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);

var polarOptionsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'polarOptions',
  initialState: null,
  reducers: {
    updatePolarOptions: (_state, action) => {
      return action.payload;
    }
  }
});
var {
  updatePolarOptions
} = polarOptionsSlice.actions;
var polarOptionsReducer = polarOptionsSlice.reducer;

/***/ }),

/***/ 19809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ combineTooltipInteractionState)
/* harmony export */ });
/* harmony import */ var _tooltipSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74531);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

function chooseAppropriateMouseInteraction(tooltipState, tooltipEventType, trigger) {
  if (tooltipEventType === 'axis') {
    if (trigger === 'click') {
      return tooltipState.axisInteraction.click;
    }
    return tooltipState.axisInteraction.hover;
  }
  if (trigger === 'click') {
    return tooltipState.itemInteraction.click;
  }
  return tooltipState.itemInteraction.hover;
}
function hasBeenActivePreviously(tooltipInteractionState) {
  return tooltipInteractionState.index != null;
}
var combineTooltipInteractionState = (tooltipState, tooltipEventType, trigger, defaultIndex) => {
  if (tooltipEventType == null) {
    return _tooltipSlice__WEBPACK_IMPORTED_MODULE_0__/* .noInteraction */ .k_;
  }
  var appropriateMouseInteraction = chooseAppropriateMouseInteraction(tooltipState, tooltipEventType, trigger);
  if (appropriateMouseInteraction == null) {
    return _tooltipSlice__WEBPACK_IMPORTED_MODULE_0__/* .noInteraction */ .k_;
  }
  if (appropriateMouseInteraction.active) {
    return appropriateMouseInteraction;
  }
  if (tooltipState.keyboardInteraction.active) {
    return tooltipState.keyboardInteraction;
  }
  if (tooltipState.syncInteraction.active && tooltipState.syncInteraction.index != null) {
    return tooltipState.syncInteraction;
  }
  var activeFromProps = tooltipState.settings.active === true;
  if (hasBeenActivePreviously(appropriateMouseInteraction)) {
    if (activeFromProps) {
      return _objectSpread(_objectSpread({}, appropriateMouseInteraction), {}, {
        active: true
      });
    }
  } else if (defaultIndex != null) {
    return {
      active: true,
      coordinate: undefined,
      dataKey: undefined,
      index: defaultIndex
    };
  }
  return _objectSpread(_objectSpread({}, _tooltipSlice__WEBPACK_IMPORTED_MODULE_0__/* .noInteraction */ .k_), {}, {
    coordinate: appropriateMouseInteraction.coordinate
  });
};

/***/ }),

/***/ 20954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ selectActivePropsFromChartPointer)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19287);
/* harmony import */ var _tooltipSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33032);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36189);
/* harmony import */ var _selectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(87997);
/* harmony import */ var _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(61270);
/* harmony import */ var _selectTooltipAxisType__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(15950);







var pickChartPointer = (_state, chartPointer) => chartPointer;
var selectActivePropsFromChartPointer = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([pickChartPointer, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_1__/* .selectChartLayout */ .fz, _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectPolarViewBox */ .D0, _selectTooltipAxisType__WEBPACK_IMPORTED_MODULE_6__/* .selectTooltipAxisType */ .R, _tooltipSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectTooltipAxisRangeWithReverse */ .gL, _tooltipSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectTooltipAxisTicks */ .R4, _selectors__WEBPACK_IMPORTED_MODULE_4__/* .selectOrderedTooltipTicks */ .r1, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_3__/* .selectChartOffsetInternal */ .HZ], _selectors__WEBPACK_IMPORTED_MODULE_4__/* .combineActiveProps */ .aX);

/***/ }),

/***/ 21077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  e: () => (/* binding */ touchEventAction),
  k: () => (/* binding */ touchEventMiddleware)
});

// EXTERNAL MODULE: ./node_modules/recharts/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs + 2 modules
var redux_toolkit_modern = __webpack_require__(4768);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/tooltipSlice.js
var tooltipSlice = __webpack_require__(74531);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectActivePropsFromChartPointer.js
var selectActivePropsFromChartPointer = __webpack_require__(20954);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/getChartPointer.js
var getChartPointer = __webpack_require__(99516);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipEventType.js
var selectTooltipEventType = __webpack_require__(55978);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/Constants.js
var Constants = __webpack_require__(4364);
// EXTERNAL MODULE: ./node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(25508);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipPayloadSearcher.js
var selectTooltipPayloadSearcher = __webpack_require__(18351);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipState.js
var selectTooltipState = __webpack_require__(23571);
;// ./node_modules/recharts/es6/state/selectors/touchSelectors.js



var selectAllTooltipPayloadConfiguration = (0,reselect/* createSelector */.Mz)([selectTooltipState/* selectTooltipState */.J], tooltipState => tooltipState.tooltipItemPayloads);
var selectTooltipCoordinate = (0,reselect/* createSelector */.Mz)([selectAllTooltipPayloadConfiguration, selectTooltipPayloadSearcher/* selectTooltipPayloadSearcher */.x, (_state, tooltipIndex, _dataKey) => tooltipIndex, (_state, _tooltipIndex, dataKey) => dataKey], (allTooltipConfigurations, tooltipPayloadSearcher, tooltipIndex, dataKey) => {
  var mostRelevantTooltipConfiguration = allTooltipConfigurations.find(tooltipConfiguration => {
    return tooltipConfiguration.settings.dataKey === dataKey;
  });
  if (mostRelevantTooltipConfiguration == null) {
    return undefined;
  }
  var {
    positions
  } = mostRelevantTooltipConfiguration;
  if (positions == null) {
    return undefined;
  }
  // @ts-expect-error tooltipPayloadSearcher is not typed well
  var maybePosition = tooltipPayloadSearcher(positions, tooltipIndex);
  return maybePosition;
});
;// ./node_modules/recharts/es6/state/touchEventsMiddleware.js







var touchEventAction = (0,redux_toolkit_modern/* createAction */.VP)('touchMove');
var touchEventMiddleware = (0,redux_toolkit_modern/* createListenerMiddleware */.Nc)();
touchEventMiddleware.startListening({
  actionCreator: touchEventAction,
  effect: (action, listenerApi) => {
    var touchEvent = action.payload;
    var state = listenerApi.getState();
    var tooltipEventType = (0,selectTooltipEventType/* selectTooltipEventType */.au)(state, state.tooltip.settings.shared);
    if (tooltipEventType === 'axis') {
      var activeProps = (0,selectActivePropsFromChartPointer/* selectActivePropsFromChartPointer */.g)(state, (0,getChartPointer/* getChartPointer */.w)({
        clientX: touchEvent.touches[0].clientX,
        clientY: touchEvent.touches[0].clientY,
        currentTarget: touchEvent.currentTarget
      }));
      if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
        listenerApi.dispatch((0,tooltipSlice/* setMouseOverAxisIndex */.Nt)({
          activeIndex: activeProps.activeIndex,
          activeDataKey: undefined,
          activeCoordinate: activeProps.activeCoordinate
        }));
      }
    } else if (tooltipEventType === 'item') {
      var _target$getAttribute;
      var touch = touchEvent.touches[0];
      var target = document.elementFromPoint(touch.clientX, touch.clientY);
      if (!target || !target.getAttribute) {
        return;
      }
      var itemIndex = target.getAttribute(Constants/* DATA_ITEM_INDEX_ATTRIBUTE_NAME */.F0);
      var dataKey = (_target$getAttribute = target.getAttribute(Constants/* DATA_ITEM_DATAKEY_ATTRIBUTE_NAME */.um)) !== null && _target$getAttribute !== void 0 ? _target$getAttribute : undefined;
      var coordinate = selectTooltipCoordinate(listenerApi.getState(), itemIndex, dataKey);
      listenerApi.dispatch((0,tooltipSlice/* setActiveMouseOverItemIndex */.RD)({
        activeDataKey: dataKey,
        activeIndex: itemIndex,
        activeCoordinate: coordinate
      }));
    }
  }
});

/***/ }),

/***/ 22608:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ arrayEqualityCheck)
/* harmony export */ });
function arrayEqualityCheck(a, b) {
  if (Array.isArray(a) && Array.isArray(b) && a.length === 0 && b.length === 0) {
    // empty arrays are always equal, regardless of reference
    return true;
  }
  return a === b;
}

/***/ }),

/***/ 23571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ selectTooltipState)
/* harmony export */ });
var selectTooltipState = state => state.tooltip;

/***/ }),

/***/ 25386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ selectArea)
/* harmony export */ });
/* unused harmony export selectGraphicalItemStackedData */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _cartesian_Area__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84124);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11114);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19287);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98453);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33964);
/* harmony import */ var _util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(72925);







var selectXAxisWithScale = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
var selectXAxisTicks = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
var selectYAxisWithScale = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
var selectYAxisTicks = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
var selectBandSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectXAxisWithScale, selectYAxisWithScale, selectXAxisTicks, selectYAxisTicks], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks) => {
  if ((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, 'xAxis')) {
    return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getBandSizeOfAxis */ .Hj)(xAxis, xAxisTicks, false);
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getBandSizeOfAxis */ .Hj)(yAxis, yAxisTicks, false);
});
var pickAreaId = (_state, _xAxisId, _yAxisId, _isPanorama, id) => id;

/*
 * There is a race condition problem because we read some data from props and some from the state.
 * The state is updated through a dispatch and is one render behind,
 * and so we have this weird one tick render where the displayedData in one selector have the old dataKey
 * but the new dataKey in another selector.
 *
 * A proper fix is to either move everything into the state, or read the dataKey always from props
 * - but this is a smaller change.
 */
var selectSynchronisedAreaSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectUnfilteredCartesianItems */ .ld, pickAreaId], (graphicalItems, id) => graphicalItems.filter(item => item.type === 'area').find(item => item.id === id));
var selectGraphicalItemStackedData = (state, xAxisId, yAxisId, isPanorama, id) => {
  var _stackGroups$stackId;
  var areaSettings = selectSynchronisedAreaSettings(state, xAxisId, yAxisId, isPanorama, id);
  if (areaSettings == null) {
    return undefined;
  }
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz)(state);
  var isXAxisCategorical = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, 'xAxis');
  var stackGroups;
  if (isXAxisCategorical) {
    stackGroups = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectStackGroups */ .TC)(state, 'yAxis', yAxisId, isPanorama);
  } else {
    stackGroups = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectStackGroups */ .TC)(state, 'xAxis', xAxisId, isPanorama);
  }
  if (stackGroups == null) {
    return undefined;
  }
  var {
    stackId
  } = areaSettings;
  var stackSeriesIdentifier = (0,_util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_6__/* .getStackSeriesIdentifier */ .x)(areaSettings);
  if (stackId == null || stackSeriesIdentifier == null) {
    return undefined;
  }
  var groups = (_stackGroups$stackId = stackGroups[stackId]) === null || _stackGroups$stackId === void 0 ? void 0 : _stackGroups$stackId.stackedData;
  return groups === null || groups === void 0 ? void 0 : groups.find(v => v.key === stackSeriesIdentifier);
};
var selectArea = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectXAxisWithScale, selectYAxisWithScale, selectXAxisTicks, selectYAxisTicks, selectGraphicalItemStackedData, _dataSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS, selectBandSize, selectSynchronisedAreaSettings], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks, stackedData, _ref, bandSize, areaSettings) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref;
  if (areaSettings == null || layout !== 'horizontal' && layout !== 'vertical' || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || xAxisTicks.length === 0 || yAxisTicks.length === 0 || bandSize == null) {
    return undefined;
  }
  var {
    data
  } = areaSettings;
  var displayedData;
  if (data && data.length > 0) {
    displayedData = data;
  } else {
    displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
  }
  if (displayedData == null) {
    return undefined;
  }

  // Where is this supposed to come from? No charts have that as a prop.
  var chartBaseValue = undefined;
  return (0,_cartesian_Area__WEBPACK_IMPORTED_MODULE_1__/* .computeArea */ .Vf)({
    layout,
    xAxis,
    yAxis,
    xAxisTicks,
    yAxisTicks,
    dataStartIndex,
    areaSettings,
    stackedData,
    displayedData,
    chartBaseValue,
    bandSize
  });
});

/***/ }),

/***/ 26314:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $6: () => (/* binding */ addDot),
/* harmony export */   A$: () => (/* binding */ removeArea),
/* harmony export */   Xn: () => (/* binding */ addArea),
/* harmony export */   cG: () => (/* binding */ addLine),
/* harmony export */   fV: () => (/* binding */ referenceElementsReducer),
/* harmony export */   hj: () => (/* binding */ removeLine),
/* harmony export */   sP: () => (/* binding */ removeDot)
/* harmony export */ });
/* unused harmony export referenceElementsSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);

var initialState = {
  dots: [],
  areas: [],
  lines: []
};
var referenceElementsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'referenceElements',
  initialState,
  reducers: {
    addDot: (state, action) => {
      state.dots.push(action.payload);
    },
    removeDot: (state, action) => {
      var index = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .current */ .ss)(state).dots.findIndex(dot => dot === action.payload);
      if (index !== -1) {
        state.dots.splice(index, 1);
      }
    },
    addArea: (state, action) => {
      state.areas.push(action.payload);
    },
    removeArea: (state, action) => {
      var index = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .current */ .ss)(state).areas.findIndex(area => area === action.payload);
      if (index !== -1) {
        state.areas.splice(index, 1);
      }
    },
    addLine: (state, action) => {
      state.lines.push(action.payload);
    },
    removeLine: (state, action) => {
      var index = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .current */ .ss)(state).lines.findIndex(line => line === action.payload);
      if (index !== -1) {
        state.lines.splice(index, 1);
      }
    }
  }
});
var {
  addDot,
  removeDot,
  addArea,
  removeArea,
  addLine,
  removeLine
} = referenceElementsSlice.actions;
var referenceElementsReducer = referenceElementsSlice.reducer;

/***/ }),

/***/ 26960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dl: () => (/* binding */ createEventEmitter),
/* harmony export */   lJ: () => (/* binding */ optionsReducer),
/* harmony export */   uN: () => (/* binding */ arrayTooltipSearcher)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59744);



/**
 * These chart options are decided internally, by Recharts,
 * and will not change during the lifetime of the chart.
 *
 * Changing these options can be done by swapping the root element
 * which will make a brand-new Redux store.
 *
 * If you want to store options that can be changed by the user,
 * use UpdatableChartOptions in rootPropsSlice.ts.
 */

function arrayTooltipSearcher(data, strIndex) {
  if (!strIndex) return undefined;
  var numIndex = Number.parseInt(strIndex, 10);
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_1__/* .isNan */ .M8)(numIndex)) {
    return undefined;
  }
  return data === null || data === void 0 ? void 0 : data[numIndex];
}
var initialState = {
  chartName: '',
  tooltipPayloadSearcher: undefined,
  eventEmitter: undefined,
  defaultTooltipEventType: 'axis'
};
var optionsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'options',
  initialState,
  reducers: {
    createEventEmitter: state => {
      if (state.eventEmitter == null) {
        state.eventEmitter = Symbol('rechartsEventEmitter');
      }
    }
  }
});
var optionsReducer = optionsSlice.reducer;
var {
  createEventEmitter
} = optionsSlice.actions;

/***/ }),

/***/ 28871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Qr: () => (/* binding */ selectPolarAxisScale),
/* harmony export */   YF: () => (/* binding */ selectPolarAxisTicks),
/* harmony export */   yQ: () => (/* binding */ selectPolarGraphicalItemAxisTicks)
/* harmony export */ });
/* unused harmony exports selectPolarAxis, selectPolarCategoricalDomain */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11114);
/* harmony import */ var _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(61270);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19287);
/* harmony import */ var _polarSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19033);
/* harmony import */ var _pickAxisType__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41927);






var selectPolarAxis = (state, axisType, axisId) => {
  switch (axisType) {
    case 'angleAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectAngleAxis */ .Be)(state, axisId);
      }
    case 'radiusAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectRadiusAxis */ .Gl)(state, axisId);
      }
    default:
      {
        throw new Error("Unexpected axis type: ".concat(axisType));
      }
  }
};
var selectPolarAxisRangeWithReversed = (state, axisType, axisId) => {
  switch (axisType) {
    case 'angleAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectAngleAxisRangeWithReversed */ .k5)(state, axisId);
      }
    case 'radiusAxis':
      {
        return (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectRadiusAxisRangeWithReversed */ .nX)(state, axisId);
      }
    default:
      {
        throw new Error("Unexpected axis type: ".concat(axisType));
      }
  }
};
var selectPolarAxisScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarAxis, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectRealScaleType */ .xM, _polarSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectPolarAxisDomainIncludingNiceTicks */ .iz, selectPolarAxisRangeWithReversed], _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .combineScaleFunction */ .Qn);
var selectPolarCategoricalDomain = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, _polarSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectPolarAppliedValues */ .IS, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisSettings */ .Hd, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .combineCategoricalDomain */ .iv);
var selectPolarAxisTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectPolarAxis, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectRealScaleType */ .xM, selectPolarAxisScale, _polarSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectPolarNiceTicks */ .Az, selectPolarAxisRangeWithReversed, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectDuplicateDomain */ .wi, selectPolarCategoricalDomain, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .combineAxisTicks */ .ro);
var selectPolarGraphicalItemAxisTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectPolarAxis, selectPolarAxisScale, selectPolarAxisRangeWithReversed, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectDuplicateDomain */ .wi, selectPolarCategoricalDomain, _pickAxisType__WEBPACK_IMPORTED_MODULE_5__/* .pickAxisType */ .N], _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .combineGraphicalItemTicks */ .UE);

/***/ }),

/***/ 33032:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BZ: () => (/* binding */ selectActiveLabel),
  eE: () => (/* binding */ selectActiveTooltipCoordinate),
  Xb: () => (/* binding */ selectActiveTooltipDataKey),
  JG: () => (/* binding */ selectActiveTooltipDataPoints),
  A2: () => (/* binding */ selectActiveTooltipIndex),
  yn: () => (/* binding */ selectIsTooltipActive),
  gL: () => (/* binding */ selectTooltipAxisRangeWithReverse),
  fl: () => (/* binding */ selectTooltipAxisScale),
  R4: () => (/* binding */ selectTooltipAxisTicks),
  n4: () => (/* binding */ selectTooltipDisplayedData)
});

// UNUSED EXPORTS: selectActiveTooltipPayload, selectAllGraphicalItemsSettings, selectAllUnfilteredGraphicalItems, selectTooltipAxisDomain, selectTooltipAxisDomainIncludingNiceTicks, selectTooltipAxisRealScaleType, selectTooltipCategoricalDomain, selectTooltipGraphicalItemsData

// EXTERNAL MODULE: ./node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(25508);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/axisSelectors.js
var axisSelectors = __webpack_require__(11114);
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/chartLayoutContext.js
var chartLayoutContext = __webpack_require__(19287);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/ChartUtils.js
var ChartUtils = __webpack_require__(33964);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/dataSelectors.js
var dataSelectors = __webpack_require__(98453);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/rootPropsSelectors.js
var rootPropsSelectors = __webpack_require__(82695);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/DataUtils.js
var DataUtils = __webpack_require__(59744);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineAxisRangeWithReverse.js
var combineAxisRangeWithReverse = __webpack_require__(19495);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipEventType.js
var selectTooltipEventType = __webpack_require__(55978);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineActiveLabel.js
var combineActiveLabel = __webpack_require__(75403);
;// ./node_modules/recharts/es6/state/selectors/selectTooltipSettings.js
var selectTooltipSettings = state => state.tooltip.settings;
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineTooltipInteractionState.js
var combineTooltipInteractionState = __webpack_require__(19809);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineActiveTooltipIndex.js
var combineActiveTooltipIndex = __webpack_require__(74544);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineCoordinateForDefaultIndex.js
var combineCoordinateForDefaultIndex = __webpack_require__(4217);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/containerSelectors.js
var containerSelectors = __webpack_require__(5180);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js
var selectChartOffsetInternal = __webpack_require__(36189);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayloadConfigurations.js
var combineTooltipPayloadConfigurations = __webpack_require__(60523);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipPayloadSearcher.js
var selectTooltipPayloadSearcher = __webpack_require__(18351);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipState.js
var selectTooltipState = __webpack_require__(23571);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayload.js
var combineTooltipPayload = __webpack_require__(89596);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipAxisId.js
var selectTooltipAxisId = __webpack_require__(86680);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipAxisType.js
var selectTooltipAxisType = __webpack_require__(15950);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectTooltipAxis.js
var selectTooltipAxis = __webpack_require__(37617);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/combiners/combineDisplayedStackedData.js
var combineDisplayedStackedData = __webpack_require__(86907);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/types/StackedGraphicalItem.js
var StackedGraphicalItem = __webpack_require__(9531);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/isDomainSpecifiedByUser.js
var isDomainSpecifiedByUser = __webpack_require__(93749);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/numberDomainEqualityCheck.js
var numberDomainEqualityCheck = __webpack_require__(6392);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/arrayEqualityCheck.js
var arrayEqualityCheck = __webpack_require__(22608);
;// ./node_modules/recharts/es6/state/selectors/tooltipSelectors.js




























var selectTooltipAxisRealScaleType = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, chartLayoutContext/* selectChartLayout */.fz, axisSelectors/* selectHasBar */.um, rootPropsSelectors/* selectChartName */.iO, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineRealScaleType */.sr);
var selectAllUnfilteredGraphicalItems = (0,reselect/* createSelector */.Mz)([state => state.graphicalItems.cartesianItems, state => state.graphicalItems.polarItems], (cartesianItems, polarItems) => [...cartesianItems, ...polarItems]);
var selectTooltipAxisPredicate = (0,reselect/* createSelector */.Mz)([selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipAxisId/* selectTooltipAxisId */.M], axisSelectors/* itemAxisPredicate */.eo);
var selectAllGraphicalItemsSettings = (0,reselect/* createSelector */.Mz)([selectAllUnfilteredGraphicalItems, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisPredicate], axisSelectors/* combineGraphicalItemsSettings */.ec, {
  memoizeOptions: {
    resultEqualityCheck: arrayEqualityCheck/* arrayEqualityCheck */.I
  }
});
var selectAllStackedGraphicalItemsSettings = (0,reselect/* createSelector */.Mz)([selectAllGraphicalItemsSettings], graphicalItems => graphicalItems.filter(StackedGraphicalItem/* isStacked */.g));
var selectTooltipGraphicalItemsData = (0,reselect/* createSelector */.Mz)([selectAllGraphicalItemsSettings], axisSelectors/* combineGraphicalItemsData */.rj, {
  memoizeOptions: {
    resultEqualityCheck: arrayEqualityCheck/* arrayEqualityCheck */.I
  }
});

/**
 * Data for tooltip always use the data with indexes set by a Brush,
 * and never accept the isPanorama flag:
 * because Tooltip never displays inside the panorama anyway
 * so we don't need to worry what would happen there.
 */
var selectTooltipDisplayedData = (0,reselect/* createSelector */.Mz)([selectTooltipGraphicalItemsData, dataSelectors/* selectChartDataWithIndexes */.LF], axisSelectors/* combineDisplayedData */.Nk);
var selectTooltipStackedData = (0,reselect/* createSelector */.Mz)([selectAllStackedGraphicalItemsSettings, dataSelectors/* selectChartDataWithIndexes */.LF, selectTooltipAxis/* selectTooltipAxis */.D], combineDisplayedStackedData/* combineDisplayedStackedData */.A);
var selectAllTooltipAppliedValues = (0,reselect/* createSelector */.Mz)([selectTooltipDisplayedData, selectTooltipAxis/* selectTooltipAxis */.D, selectAllGraphicalItemsSettings], axisSelectors/* combineAppliedValues */.fb);
var selectTooltipAxisDomainDefinition = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D], axisSelectors/* getDomainDefinition */.S5);
var selectTooltipDataOverflow = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D], axisSettings => axisSettings.allowDataOverflow);
var selectTooltipDomainFromUserPreferences = (0,reselect/* createSelector */.Mz)([selectTooltipAxisDomainDefinition, selectTooltipDataOverflow], isDomainSpecifiedByUser/* numericalDomainSpecifiedWithoutRequiringData */.f5);
var selectAllStackedGraphicalItems = (0,reselect/* createSelector */.Mz)([selectAllGraphicalItemsSettings], graphicalItems => graphicalItems.filter(StackedGraphicalItem/* isStacked */.g));
var selectTooltipStackGroups = (0,reselect/* createSelector */.Mz)([selectTooltipStackedData, selectAllStackedGraphicalItems, rootPropsSelectors/* selectStackOffsetType */.eC], axisSelectors/* combineStackGroups */.MK);
var selectTooltipDomainOfStackGroups = (0,reselect/* createSelector */.Mz)([selectTooltipStackGroups, dataSelectors/* selectChartDataWithIndexes */.LF, selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipDomainFromUserPreferences], axisSelectors/* combineDomainOfStackGroups */.pM);
var selectTooltipItemsSettingsExceptStacked = (0,reselect/* createSelector */.Mz)([selectAllGraphicalItemsSettings], axisSelectors/* filterGraphicalNotStackedItems */.IO);
var selectDomainOfAllAppliedNumericalValuesIncludingErrorValues = (0,reselect/* createSelector */.Mz)([selectTooltipDisplayedData, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipItemsSettingsExceptStacked, axisSelectors/* selectAllErrorBarSettings */.CH, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineDomainOfAllAppliedNumericalValuesIncludingErrorValues */.EZ, {
  memoizeOptions: {
    resultEqualityCheck: numberDomainEqualityCheck/* numberDomainEqualityCheck */.o
  }
});
var selectReferenceDotsByTooltipAxis = (0,reselect/* createSelector */.Mz)([axisSelectors/* selectReferenceDots */.Kr, selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipAxisId/* selectTooltipAxisId */.M], axisSelectors/* filterReferenceElements */.P9);
var selectTooltipReferenceDotsDomain = (0,reselect/* createSelector */.Mz)([selectReferenceDotsByTooltipAxis, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineDotsDomain */.Oz);
var selectReferenceAreasByTooltipAxis = (0,reselect/* createSelector */.Mz)([axisSelectors/* selectReferenceAreas */.gT, selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipAxisId/* selectTooltipAxisId */.M], axisSelectors/* filterReferenceElements */.P9);
var selectTooltipReferenceAreasDomain = (0,reselect/* createSelector */.Mz)([selectReferenceAreasByTooltipAxis, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineAreasDomain */.q);
var selectReferenceLinesByTooltipAxis = (0,reselect/* createSelector */.Mz)([axisSelectors/* selectReferenceLines */.$X, selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipAxisId/* selectTooltipAxisId */.M], axisSelectors/* filterReferenceElements */.P9);
var selectTooltipReferenceLinesDomain = (0,reselect/* createSelector */.Mz)([selectReferenceLinesByTooltipAxis, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineLinesDomain */.bb);
var selectTooltipReferenceElementsDomain = (0,reselect/* createSelector */.Mz)([selectTooltipReferenceDotsDomain, selectTooltipReferenceLinesDomain, selectTooltipReferenceAreasDomain], axisSelectors/* mergeDomains */.yi);
var selectTooltipNumericalDomain = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisDomainDefinition, selectTooltipDomainFromUserPreferences, selectTooltipDomainOfStackGroups, selectDomainOfAllAppliedNumericalValuesIncludingErrorValues, selectTooltipReferenceElementsDomain, chartLayoutContext/* selectChartLayout */.fz, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineNumericalDomain */.wL);
var selectTooltipAxisDomain = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, chartLayoutContext/* selectChartLayout */.fz, selectTooltipDisplayedData, selectAllTooltipAppliedValues, rootPropsSelectors/* selectStackOffsetType */.eC, selectTooltipAxisType/* selectTooltipAxisType */.R, selectTooltipNumericalDomain], axisSelectors/* combineAxisDomain */.tP);
var selectTooltipNiceTicks = (0,reselect/* createSelector */.Mz)([selectTooltipAxisDomain, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisRealScaleType], axisSelectors/* combineNiceTicks */.xp);
var selectTooltipAxisDomainIncludingNiceTicks = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisDomain, selectTooltipNiceTicks, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineAxisDomainWithNiceTicks */.g1);
var selectTooltipAxisRange = state => {
  var axisType = (0,selectTooltipAxisType/* selectTooltipAxisType */.R)(state);
  var axisId = (0,selectTooltipAxisId/* selectTooltipAxisId */.M)(state);
  var isPanorama = false; // Tooltip never displays in panorama so this is safe to assume
  return (0,axisSelectors/* selectAxisRange */.D5)(state, axisType, axisId, isPanorama);
};
var selectTooltipAxisRangeWithReverse = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisRange], combineAxisRangeWithReverse/* combineAxisRangeWithReverse */.I);
var selectTooltipAxisScale = (0,reselect/* createSelector */.Mz)([selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisRealScaleType, selectTooltipAxisDomainIncludingNiceTicks, selectTooltipAxisRangeWithReverse], axisSelectors/* combineScaleFunction */.Qn);
var selectTooltipDuplicateDomain = (0,reselect/* createSelector */.Mz)([chartLayoutContext/* selectChartLayout */.fz, selectAllTooltipAppliedValues, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineDuplicateDomain */.tF);
var selectTooltipCategoricalDomain = (0,reselect/* createSelector */.Mz)([chartLayoutContext/* selectChartLayout */.fz, selectAllTooltipAppliedValues, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisType/* selectTooltipAxisType */.R], axisSelectors/* combineCategoricalDomain */.iv);
var combineTicksOfTooltipAxis = (layout, axis, realScaleType, scale, range, duplicateDomain, categoricalDomain, axisType) => {
  if (!axis) {
    return undefined;
  }
  var {
    type
  } = axis;
  var isCategorical = (0,ChartUtils/* isCategoricalAxis */._L)(layout, axisType);
  if (!scale) {
    return undefined;
  }
  var offsetForBand = realScaleType === 'scaleBand' && scale.bandwidth ? scale.bandwidth() / 2 : 2;
  var offset = type === 'category' && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
  offset = axisType === 'angleAxis' && range != null && (range === null || range === void 0 ? void 0 : range.length) >= 2 ? (0,DataUtils/* mathSign */.sA)(range[0] - range[1]) * 2 * offset : offset;

  // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
  if (isCategorical && categoricalDomain) {
    return categoricalDomain.map((entry, index) => ({
      coordinate: scale(entry) + offset,
      value: entry,
      index,
      offset
    }));
  }

  // When axis has duplicated text, serial numbers are used to generate scale
  return scale.domain().map((entry, index) => ({
    coordinate: scale(entry) + offset,
    value: duplicateDomain ? duplicateDomain[entry] : entry,
    index,
    offset
  }));
};
var selectTooltipAxisTicks = (0,reselect/* createSelector */.Mz)([chartLayoutContext/* selectChartLayout */.fz, selectTooltipAxis/* selectTooltipAxis */.D, selectTooltipAxisRealScaleType, selectTooltipAxisScale, selectTooltipAxisRange, selectTooltipDuplicateDomain, selectTooltipCategoricalDomain, selectTooltipAxisType/* selectTooltipAxisType */.R], combineTicksOfTooltipAxis);
var tooltipSelectors_selectTooltipEventType = (0,reselect/* createSelector */.Mz)([selectTooltipEventType/* selectDefaultTooltipEventType */.xH, selectTooltipEventType/* selectValidateTooltipEventTypes */.Hw, selectTooltipSettings], (defaultTooltipEventType, validateTooltipEventType, settings) => (0,selectTooltipEventType/* combineTooltipEventType */.$g)(settings.shared, defaultTooltipEventType, validateTooltipEventType));
var selectTooltipTrigger = state => state.tooltip.settings.trigger;
var selectDefaultIndex = state => state.tooltip.settings.defaultIndex;
var selectTooltipInteractionState = (0,reselect/* createSelector */.Mz)([selectTooltipState/* selectTooltipState */.J, tooltipSelectors_selectTooltipEventType, selectTooltipTrigger, selectDefaultIndex], combineTooltipInteractionState/* combineTooltipInteractionState */.i);
var selectActiveTooltipIndex = (0,reselect/* createSelector */.Mz)([selectTooltipInteractionState, selectTooltipDisplayedData], combineActiveTooltipIndex/* combineActiveTooltipIndex */.P);
var selectActiveLabel = (0,reselect/* createSelector */.Mz)([selectTooltipAxisTicks, selectActiveTooltipIndex], combineActiveLabel/* combineActiveLabel */.E);
var selectActiveTooltipDataKey = (0,reselect/* createSelector */.Mz)([selectTooltipInteractionState], tooltipInteraction => {
  if (!tooltipInteraction) {
    return undefined;
  }
  return tooltipInteraction.dataKey;
});
var selectTooltipPayloadConfigurations = (0,reselect/* createSelector */.Mz)([selectTooltipState/* selectTooltipState */.J, tooltipSelectors_selectTooltipEventType, selectTooltipTrigger, selectDefaultIndex], combineTooltipPayloadConfigurations/* combineTooltipPayloadConfigurations */.q);
var selectTooltipCoordinateForDefaultIndex = (0,reselect/* createSelector */.Mz)([containerSelectors/* selectChartWidth */.Lp, containerSelectors/* selectChartHeight */.A$, chartLayoutContext/* selectChartLayout */.fz, selectChartOffsetInternal/* selectChartOffsetInternal */.HZ, selectTooltipAxisTicks, selectDefaultIndex, selectTooltipPayloadConfigurations, selectTooltipPayloadSearcher/* selectTooltipPayloadSearcher */.x], combineCoordinateForDefaultIndex/* combineCoordinateForDefaultIndex */.o);
var selectActiveTooltipCoordinate = (0,reselect/* createSelector */.Mz)([selectTooltipInteractionState, selectTooltipCoordinateForDefaultIndex], (tooltipInteractionState, defaultIndexCoordinate) => {
  if (tooltipInteractionState !== null && tooltipInteractionState !== void 0 && tooltipInteractionState.coordinate) {
    return tooltipInteractionState.coordinate;
  }
  return defaultIndexCoordinate;
});
var selectIsTooltipActive = (0,reselect/* createSelector */.Mz)([selectTooltipInteractionState], tooltipInteractionState => tooltipInteractionState.active);
var selectActiveTooltipPayload = (0,reselect/* createSelector */.Mz)([selectTooltipPayloadConfigurations, selectActiveTooltipIndex, dataSelectors/* selectChartDataWithIndexes */.LF, selectTooltipAxis/* selectTooltipAxisDataKey */.K, selectActiveLabel, selectTooltipPayloadSearcher/* selectTooltipPayloadSearcher */.x, tooltipSelectors_selectTooltipEventType], combineTooltipPayload/* combineTooltipPayload */.N);
var selectActiveTooltipDataPoints = (0,reselect/* createSelector */.Mz)([selectActiveTooltipPayload], payload => {
  if (payload == null) {
    return undefined;
  }
  var dataPoints = payload.map(p => p.payload).filter(p => p != null);
  return Array.from(new Set(dataPoints));
});

/***/ }),

/***/ 33964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $8: () => (/* binding */ getNormalizedStackId),
/* harmony export */   DW: () => (/* binding */ getBaseValueOfBar),
/* harmony export */   GF: () => (/* binding */ getTooltipEntry),
/* harmony export */   Hj: () => (/* binding */ getBandSizeOfAxis),
/* harmony export */   IH: () => (/* binding */ MIN_VALUE_REG),
/* harmony export */   Mk: () => (/* binding */ getDomainOfStackGroups),
/* harmony export */   PW: () => (/* binding */ getCoordinatesOfGrid),
/* harmony export */   Rh: () => (/* binding */ getTicksOfAxis),
/* harmony export */   SW: () => (/* binding */ calculateTooltipPos),
/* harmony export */   YB: () => (/* binding */ checkDomainOfScale),
/* harmony export */   _L: () => (/* binding */ isCategoricalAxis),
/* harmony export */   _f: () => (/* binding */ truncateByDomain),
/* harmony export */   bk: () => (/* binding */ getActiveCoordinate),
/* harmony export */   gH: () => (/* binding */ calculateActiveTickIndex),
/* harmony export */   kr: () => (/* binding */ getValueByDataKey),
/* harmony export */   nb: () => (/* binding */ getCateCoordinateOfLine),
/* harmony export */   qx: () => (/* binding */ MAX_VALUE_REG),
/* harmony export */   r4: () => (/* binding */ inRange),
/* harmony export */   s0: () => (/* binding */ appendOffsetOfLegend),
/* harmony export */   uM: () => (/* binding */ getTooltipNameProp),
/* harmony export */   y2: () => (/* binding */ getCateCoordinateOfBar),
/* harmony export */   yy: () => (/* binding */ getStackedData)
/* harmony export */ });
/* unused harmony exports offsetSign, offsetPositive */
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60184);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(80305);
/* harmony import */ var es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4058);
/* harmony import */ var _DataUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59744);
/* harmony import */ var _PolarUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14040);
/* harmony import */ var _getSliced__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(79195);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






function getValueByDataKey(obj, dataKey, defaultValue) {
  if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(obj) || (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(dataKey)) {
    return defaultValue;
  }
  if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumOrStr */ .vh)(dataKey)) {
    return es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_1___default()(obj, dataKey, defaultValue);
  }
  if (typeof dataKey === 'function') {
    return dataKey(obj);
  }
  return defaultValue;
}
var calculateActiveTickIndex = (coordinate, ticks, unsortedTicks, axisType, range) => {
  var _ticks$length;
  var index = -1;
  var len = (_ticks$length = ticks === null || ticks === void 0 ? void 0 : ticks.length) !== null && _ticks$length !== void 0 ? _ticks$length : 0;

  // if there are 1 or fewer ticks or if there is no coordinate then the active tick is at index 0
  if (len <= 1 || coordinate == null) {
    return 0;
  }
  if (axisType === 'angleAxis' && range != null && Math.abs(Math.abs(range[1] - range[0]) - 360) <= 1e-6) {
    // ticks are distributed in a circle
    for (var i = 0; i < len; i++) {
      var before = i > 0 ? unsortedTicks[i - 1].coordinate : unsortedTicks[len - 1].coordinate;
      var cur = unsortedTicks[i].coordinate;
      var after = i >= len - 1 ? unsortedTicks[0].coordinate : unsortedTicks[i + 1].coordinate;
      var sameDirectionCoord = void 0;
      if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(cur - before) !== (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(after - cur)) {
        var diffInterval = [];
        if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(after - cur) === (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(range[1] - range[0])) {
          sameDirectionCoord = after;
          var curInRange = cur + range[1] - range[0];
          diffInterval[0] = Math.min(curInRange, (curInRange + before) / 2);
          diffInterval[1] = Math.max(curInRange, (curInRange + before) / 2);
        } else {
          sameDirectionCoord = before;
          var afterInRange = after + range[1] - range[0];
          diffInterval[0] = Math.min(cur, (afterInRange + cur) / 2);
          diffInterval[1] = Math.max(cur, (afterInRange + cur) / 2);
        }
        var sameInterval = [Math.min(cur, (sameDirectionCoord + cur) / 2), Math.max(cur, (sameDirectionCoord + cur) / 2)];
        if (coordinate > sameInterval[0] && coordinate <= sameInterval[1] || coordinate >= diffInterval[0] && coordinate <= diffInterval[1]) {
          ({
            index
          } = unsortedTicks[i]);
          break;
        }
      } else {
        var minValue = Math.min(before, after);
        var maxValue = Math.max(before, after);
        if (coordinate > (minValue + cur) / 2 && coordinate <= (maxValue + cur) / 2) {
          ({
            index
          } = unsortedTicks[i]);
          break;
        }
      }
    }
  } else if (ticks) {
    // ticks are distributed in a single direction
    for (var _i = 0; _i < len; _i++) {
      if (_i === 0 && coordinate <= (ticks[_i].coordinate + ticks[_i + 1].coordinate) / 2 || _i > 0 && _i < len - 1 && coordinate > (ticks[_i].coordinate + ticks[_i - 1].coordinate) / 2 && coordinate <= (ticks[_i].coordinate + ticks[_i + 1].coordinate) / 2 || _i === len - 1 && coordinate > (ticks[_i].coordinate + ticks[_i - 1].coordinate) / 2) {
        ({
          index
        } = ticks[_i]);
        break;
      }
    }
  }
  return index;
};
var appendOffsetOfLegend = (offset, legendSettings, legendSize) => {
  if (legendSettings && legendSize) {
    var {
      width: boxWidth,
      height: boxHeight
    } = legendSize;
    var {
      align,
      verticalAlign,
      layout
    } = legendSettings;
    if ((layout === 'vertical' || layout === 'horizontal' && verticalAlign === 'middle') && align !== 'center' && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(offset[align])) {
      return _objectSpread(_objectSpread({}, offset), {}, {
        [align]: offset[align] + (boxWidth || 0)
      });
    }
    if ((layout === 'horizontal' || layout === 'vertical' && align === 'center') && verticalAlign !== 'middle' && (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(offset[verticalAlign])) {
      return _objectSpread(_objectSpread({}, offset), {}, {
        [verticalAlign]: offset[verticalAlign] + (boxHeight || 0)
      });
    }
  }
  return offset;
};
var isCategoricalAxis = (layout, axisType) => layout === 'horizontal' && axisType === 'xAxis' || layout === 'vertical' && axisType === 'yAxis' || layout === 'centric' && axisType === 'angleAxis' || layout === 'radial' && axisType === 'radiusAxis';

/**
 * Calculate the Coordinates of grid
 * @param  {Array} ticks           The ticks in axis
 * @param {Number} minValue        The minimum value of axis
 * @param {Number} maxValue        The maximum value of axis
 * @param {boolean} syncWithTicks  Synchronize grid lines with ticks or not
 * @return {Array}                 Coordinates
 */
var getCoordinatesOfGrid = (ticks, minValue, maxValue, syncWithTicks) => {
  if (syncWithTicks) {
    return ticks.map(entry => entry.coordinate);
  }
  var hasMin, hasMax;
  var values = ticks.map(entry => {
    if (entry.coordinate === minValue) {
      hasMin = true;
    }
    if (entry.coordinate === maxValue) {
      hasMax = true;
    }
    return entry.coordinate;
  });
  if (!hasMin) {
    values.push(minValue);
  }
  if (!hasMax) {
    values.push(maxValue);
  }
  return values;
};

/**
 * A subset of d3-scale that Recharts is using
 */

/**
 * Get the ticks of an axis
 * @param  {Object}  axis The configuration of an axis
 * @param {Boolean} isGrid Whether or not are the ticks in grid
 * @param {Boolean} isAll Return the ticks of all the points or not
 * @return {Array}  Ticks
 */
var getTicksOfAxis = (axis, isGrid, isAll) => {
  if (!axis) {
    return null;
  }
  var {
    duplicateDomain,
    type,
    range,
    scale,
    realScaleType,
    isCategorical,
    categoricalDomain,
    tickCount,
    ticks,
    niceTicks,
    axisType
  } = axis;
  if (!scale) {
    return null;
  }
  var offsetForBand = realScaleType === 'scaleBand' && scale.bandwidth ? scale.bandwidth() / 2 : 2;
  var offset = (isGrid || isAll) && type === 'category' && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
  offset = axisType === 'angleAxis' && range && range.length >= 2 ? (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .mathSign */ .sA)(range[0] - range[1]) * 2 * offset : offset;

  // The ticks set by user should only affect the ticks adjacent to axis line
  if (isGrid && (ticks || niceTicks)) {
    var result = (ticks || niceTicks || []).map((entry, index) => {
      var scaleContent = duplicateDomain ? duplicateDomain.indexOf(entry) : entry;
      return {
        // If the scaleContent is not a number, the coordinate will be NaN.
        // That could be the case for example with a PointScale and a string as domain.
        coordinate: scale(scaleContent) + offset,
        value: entry,
        offset,
        index
      };
    });
    return result.filter(row => !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNan */ .M8)(row.coordinate));
  }

  // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
  if (isCategorical && categoricalDomain) {
    return categoricalDomain.map((entry, index) => ({
      coordinate: scale(entry) + offset,
      value: entry,
      index,
      offset
    }));
  }
  if (scale.ticks && !isAll && tickCount != null) {
    return scale.ticks(tickCount).map((entry, index) => ({
      coordinate: scale(entry) + offset,
      value: entry,
      offset,
      index
    }));
  }

  // When axis has duplicated text, serial numbers are used to generate scale
  return scale.domain().map((entry, index) => ({
    coordinate: scale(entry) + offset,
    value: duplicateDomain ? duplicateDomain[entry] : entry,
    index,
    offset
  }));
};
var EPS = 1e-4;
var checkDomainOfScale = scale => {
  var domain = scale.domain();
  if (!domain || domain.length <= 2) {
    return;
  }
  var len = domain.length;
  var range = scale.range();
  var minValue = Math.min(range[0], range[1]) - EPS;
  var maxValue = Math.max(range[0], range[1]) + EPS;
  var first = scale(domain[0]);
  var last = scale(domain[len - 1]);
  if (first < minValue || first > maxValue || last < minValue || last > maxValue) {
    scale.domain([domain[0], domain[len - 1]]);
  }
};

/**
 * Both value and domain are tuples of two numbers
 * - but the type stays as array of numbers until we have better support in rest of the app
 * @param value input that will be truncated
 * @param domain boundaries
 * @returns tuple of two numbers
 */
var truncateByDomain = (value, domain) => {
  if (!domain || domain.length !== 2 || !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(domain[0]) || !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(domain[1])) {
    return value;
  }
  var minValue = Math.min(domain[0], domain[1]);
  var maxValue = Math.max(domain[0], domain[1]);
  var result = [value[0], value[1]];
  if (!(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(value[0]) || value[0] < minValue) {
    result[0] = minValue;
  }
  if (!(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(value[1]) || value[1] > maxValue) {
    result[1] = maxValue;
  }
  if (result[0] > maxValue) {
    result[0] = maxValue;
  }
  if (result[1] < minValue) {
    result[1] = minValue;
  }
  return result;
};

/**
 * Stacks all positive numbers above zero and all negative numbers below zero.
 *
 * If all values in the series are positive then this behaves the same as 'none' stacker.
 *
 * @param {Array} series from d3-shape Stack
 * @return {Array} series with applied offset
 */
var offsetSign = series => {
  var n = series.length;
  if (n <= 0) {
    return;
  }
  for (var j = 0, m = series[0].length; j < m; ++j) {
    var positive = 0;
    var negative = 0;
    for (var i = 0; i < n; ++i) {
      var value = (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNan */ .M8)(series[i][j][1]) ? series[i][j][0] : series[i][j][1];

      /* eslint-disable prefer-destructuring, no-param-reassign */
      if (value >= 0) {
        series[i][j][0] = positive;
        series[i][j][1] = positive + value;
        positive = series[i][j][1];
      } else {
        series[i][j][0] = negative;
        series[i][j][1] = negative + value;
        negative = series[i][j][1];
      }
      /* eslint-enable prefer-destructuring, no-param-reassign */
    }
  }
};

/**
 * Replaces all negative values with zero when stacking data.
 *
 * If all values in the series are positive then this behaves the same as 'none' stacker.
 *
 * @param {Array} series from d3-shape Stack
 * @return {Array} series with applied offset
 */
var offsetPositive = series => {
  var n = series.length;
  if (n <= 0) {
    return;
  }
  for (var j = 0, m = series[0].length; j < m; ++j) {
    var positive = 0;
    for (var i = 0; i < n; ++i) {
      var value = (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNan */ .M8)(series[i][j][1]) ? series[i][j][0] : series[i][j][1];

      /* eslint-disable prefer-destructuring, no-param-reassign */
      if (value >= 0) {
        series[i][j][0] = positive;
        series[i][j][1] = positive + value;
        positive = series[i][j][1];
      } else {
        series[i][j][0] = 0;
        series[i][j][1] = 0;
      }
      /* eslint-enable prefer-destructuring, no-param-reassign */
    }
  }
};

/**
 * Function type to compute offset for stacked data.
 *
 * d3-shape has something fishy going on with its types.
 * In @definitelytyped/d3-shape, this function (the offset accessor) is typed as Series<> => void.
 * However! When I actually open the storybook I can see that the offset accessor actually receives Array<Series<>>.
 * The same I can see in the source code itself:
 * https://github.com/DefinitelyTyped/DefinitelyTyped/discussions/66042
 * That one unfortunately has no types but we can tell it passes three-dimensional array.
 *
 * Which leads me to believe that definitelytyped is wrong on this one.
 * There's open discussion on this topic without much attention:
 * https://github.com/DefinitelyTyped/DefinitelyTyped/discussions/66042
 */

var STACK_OFFSET_MAP = {
  sign: offsetSign,
  // @ts-expect-error definitelytyped types are incorrect
  expand: victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stackOffsetExpand */ .qI,
  // @ts-expect-error definitelytyped types are incorrect
  none: victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stackOffsetNone */ .YW,
  // @ts-expect-error definitelytyped types are incorrect
  silhouette: victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stackOffsetSilhouette */ .e9,
  // @ts-expect-error definitelytyped types are incorrect
  wiggle: victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stackOffsetWiggle */ .Re,
  positive: offsetPositive
};
var getStackedData = (data, dataKeys, offsetType) => {
  var offsetAccessor = STACK_OFFSET_MAP[offsetType];
  var stack = (0,victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stack */ .t$)().keys(dataKeys).value((d, key) => +getValueByDataKey(d, key, 0)).order(victory_vendor_d3_shape__WEBPACK_IMPORTED_MODULE_2__/* .stackOrderNone */ .rM)
  // @ts-expect-error definitelytyped types are incorrect
  .offset(offsetAccessor);
  return stack(data);
};

/**
 * Stack IDs in the external props allow numbers; but internally we use it as an object key
 * and object keys are always strings. Also, it would be kinda confusing if stackId=8 and stackId='8' were different stacks
 * so let's just force a string.
 */

function getNormalizedStackId(publicStackId) {
  return publicStackId == null ? undefined : String(publicStackId);
}
function getCateCoordinateOfLine(_ref) {
  var {
    axis,
    ticks,
    bandSize,
    entry,
    index,
    dataKey
  } = _ref;
  if (axis.type === 'category') {
    // find coordinate of category axis by the value of category
    // @ts-expect-error why does this use direct object access instead of getValueByDataKey?
    if (!axis.allowDuplicatedCategory && axis.dataKey && !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(entry[axis.dataKey])) {
      // @ts-expect-error why does this use direct object access instead of getValueByDataKey?
      var matchedTick = (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .findEntryInArray */ .eP)(ticks, 'value', entry[axis.dataKey]);
      if (matchedTick) {
        return matchedTick.coordinate + bandSize / 2;
      }
    }
    return ticks[index] ? ticks[index].coordinate + bandSize / 2 : null;
  }
  var value = getValueByDataKey(entry, !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(dataKey) ? dataKey : axis.dataKey);

  // @ts-expect-error getValueByDataKey does not validate the output type
  return !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(value) ? axis.scale(value) : null;
}
var getCateCoordinateOfBar = _ref2 => {
  var {
    axis,
    ticks,
    offset,
    bandSize,
    entry,
    index
  } = _ref2;
  if (axis.type === 'category') {
    return ticks[index] ? ticks[index].coordinate + offset : null;
  }
  var value = getValueByDataKey(entry, axis.dataKey, axis.scale.domain()[index]);
  return !(0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(value) ? axis.scale(value) - bandSize / 2 + offset : null;
};
var getBaseValueOfBar = _ref3 => {
  var {
    numericAxis
  } = _ref3;
  var domain = numericAxis.scale.domain();
  if (numericAxis.type === 'number') {
    // @ts-expect-error type number means the domain has numbers in it but this relationship is not known to typescript
    var minValue = Math.min(domain[0], domain[1]);
    // @ts-expect-error type number means the domain has numbers in it but this relationship is not known to typescript
    var maxValue = Math.max(domain[0], domain[1]);
    if (minValue <= 0 && maxValue >= 0) {
      return 0;
    }
    if (maxValue < 0) {
      return maxValue;
    }
    return minValue;
  }
  return domain[0];
};
var getDomainOfSingle = data => {
  var flat = data.flat(2).filter(_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et);
  return [Math.min(...flat), Math.max(...flat)];
};
var makeDomainFinite = domain => {
  return [domain[0] === Infinity ? 0 : domain[0], domain[1] === -Infinity ? 0 : domain[1]];
};
var getDomainOfStackGroups = (stackGroups, startIndex, endIndex) => {
  if (stackGroups == null) {
    return undefined;
  }
  return makeDomainFinite(Object.keys(stackGroups).reduce((result, stackId) => {
    var group = stackGroups[stackId];
    var {
      stackedData
    } = group;
    var domain = stackedData.reduce((res, entry) => {
      var sliced = (0,_getSliced__WEBPACK_IMPORTED_MODULE_5__/* .getSliced */ .v)(entry, startIndex, endIndex);
      var s = getDomainOfSingle(sliced);
      return [Math.min(res[0], s[0]), Math.max(res[1], s[1])];
    }, [Infinity, -Infinity]);
    return [Math.min(domain[0], result[0]), Math.max(domain[1], result[1])];
  }, [Infinity, -Infinity]));
};
var MIN_VALUE_REG = /^dataMin[\s]*-[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/;
var MAX_VALUE_REG = /^dataMax[\s]*\+[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/;

/**
 * Calculate the size between two category
 * @param  {Object} axis  The options of axis
 * @param  {Array}  ticks The ticks of axis
 * @param  {Boolean} isBar if items in axis are bars
 * @return {Number} Size
 */
var getBandSizeOfAxis = (axis, ticks, isBar) => {
  if (axis && axis.scale && axis.scale.bandwidth) {
    var bandWidth = axis.scale.bandwidth();
    if (!isBar || bandWidth > 0) {
      return bandWidth;
    }
  }
  if (axis && ticks && ticks.length >= 2) {
    var orderedTicks = es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_0___default()(ticks, o => o.coordinate);
    var bandSize = Infinity;
    for (var i = 1, len = orderedTicks.length; i < len; i++) {
      var cur = orderedTicks[i];
      var prev = orderedTicks[i - 1];
      bandSize = Math.min((cur.coordinate || 0) - (prev.coordinate || 0), bandSize);
    }
    return bandSize === Infinity ? 0 : bandSize;
  }
  return isBar ? undefined : 0;
};
function getTooltipEntry(_ref4) {
  var {
    tooltipEntrySettings,
    dataKey,
    payload,
    value,
    name
  } = _ref4;
  return _objectSpread(_objectSpread({}, tooltipEntrySettings), {}, {
    dataKey,
    payload,
    value,
    name
  });
}
function getTooltipNameProp(nameFromItem, dataKey) {
  if (nameFromItem) {
    return String(nameFromItem);
  }
  if (typeof dataKey === 'string') {
    return dataKey;
  }
  return undefined;
}
function inRange(x, y, layout, polarViewBox, offset) {
  if (layout === 'horizontal' || layout === 'vertical') {
    var isInRange = x >= offset.left && x <= offset.left + offset.width && y >= offset.top && y <= offset.top + offset.height;
    return isInRange ? {
      x,
      y
    } : null;
  }
  if (polarViewBox) {
    return (0,_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .inRangeOfSector */ .yy)({
      x,
      y
    }, polarViewBox);
  }
  return null;
}
var getActiveCoordinate = (layout, tooltipTicks, activeIndex, rangeObj) => {
  var entry = tooltipTicks.find(tick => tick && tick.index === activeIndex);
  if (entry) {
    if (layout === 'horizontal') {
      return {
        x: entry.coordinate,
        y: rangeObj.y
      };
    }
    if (layout === 'vertical') {
      return {
        x: rangeObj.x,
        y: entry.coordinate
      };
    }
    if (layout === 'centric') {
      var _angle = entry.coordinate;
      var {
        radius: _radius
      } = rangeObj;
      return _objectSpread(_objectSpread(_objectSpread({}, rangeObj), (0,_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(rangeObj.cx, rangeObj.cy, _radius, _angle)), {}, {
        angle: _angle,
        radius: _radius
      });
    }
    var radius = entry.coordinate;
    var {
      angle
    } = rangeObj;
    return _objectSpread(_objectSpread(_objectSpread({}, rangeObj), (0,_PolarUtils__WEBPACK_IMPORTED_MODULE_4__/* .polarToCartesian */ .IZ)(rangeObj.cx, rangeObj.cy, radius, angle)), {}, {
      angle,
      radius
    });
  }
  return {
    x: 0,
    y: 0
  };
};
var calculateTooltipPos = (rangeObj, layout) => {
  if (layout === 'horizontal') {
    return rangeObj.x;
  }
  if (layout === 'vertical') {
    return rangeObj.y;
  }
  if (layout === 'centric') {
    return rangeObj.angle;
  }
  return rangeObj.radius;
};

/***/ }),

/***/ 36189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ds: () => (/* binding */ selectChartViewBox),
/* harmony export */   HZ: () => (/* binding */ selectChartOffsetInternal),
/* harmony export */   c2: () => (/* binding */ selectAxisViewBox)
/* harmony export */ });
/* unused harmony export selectBrushHeight */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _legendSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(47962);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33964);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5180);
/* harmony import */ var _selectAllAxes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68861);
/* harmony import */ var _util_Constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4364);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






var selectBrushHeight = state => state.brush.height;
function selectLeftAxesOffset(state) {
  var yAxes = (0,_selectAllAxes__WEBPACK_IMPORTED_MODULE_4__/* .selectAllYAxes */ .W)(state);
  return yAxes.reduce((result, entry) => {
    if (entry.orientation === 'left' && !entry.mirror && !entry.hide) {
      var width = typeof entry.width === 'number' ? entry.width : _util_Constants__WEBPACK_IMPORTED_MODULE_5__/* .DEFAULT_Y_AXIS_WIDTH */ .tQ;
      return result + width;
    }
    return result;
  }, 0);
}
function selectRightAxesOffset(state) {
  var yAxes = (0,_selectAllAxes__WEBPACK_IMPORTED_MODULE_4__/* .selectAllYAxes */ .W)(state);
  return yAxes.reduce((result, entry) => {
    if (entry.orientation === 'right' && !entry.mirror && !entry.hide) {
      var width = typeof entry.width === 'number' ? entry.width : _util_Constants__WEBPACK_IMPORTED_MODULE_5__/* .DEFAULT_Y_AXIS_WIDTH */ .tQ;
      return result + width;
    }
    return result;
  }, 0);
}
function selectTopAxesOffset(state) {
  var xAxes = (0,_selectAllAxes__WEBPACK_IMPORTED_MODULE_4__/* .selectAllXAxes */ .h)(state);
  return xAxes.reduce((result, entry) => {
    if (entry.orientation === 'top' && !entry.mirror && !entry.hide) {
      return result + entry.height;
    }
    return result;
  }, 0);
}
function selectBottomAxesOffset(state) {
  var xAxes = (0,_selectAllAxes__WEBPACK_IMPORTED_MODULE_4__/* .selectAllXAxes */ .h)(state);
  return xAxes.reduce((result, entry) => {
    if (entry.orientation === 'bottom' && !entry.mirror && !entry.hide) {
      return result + entry.height;
    }
    return result;
  }, 0);
}

/**
 * For internal use only.
 *
 * @param root state
 * @return ChartOffsetInternal
 */
var selectChartOffsetInternal = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_containerSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectChartHeight */ .A$, _containerSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectMargin */ .HK, selectBrushHeight, selectLeftAxesOffset, selectRightAxesOffset, selectTopAxesOffset, selectBottomAxesOffset, _legendSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectLegendSettings */ .ff, _legendSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectLegendSize */ .dc], (chartWidth, chartHeight, margin, brushHeight, leftAxesOffset, rightAxesOffset, topAxesOffset, bottomAxesOffset, legendSettings, legendSize) => {
  var offsetH = {
    left: (margin.left || 0) + leftAxesOffset,
    right: (margin.right || 0) + rightAxesOffset
  };
  var offsetV = {
    top: (margin.top || 0) + topAxesOffset,
    bottom: (margin.bottom || 0) + bottomAxesOffset
  };
  var offset = _objectSpread(_objectSpread({}, offsetV), offsetH);
  var brushBottom = offset.bottom;
  offset.bottom += brushHeight;
  offset = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_2__/* .appendOffsetOfLegend */ .s0)(offset, legendSettings, legendSize);
  var offsetWidth = chartWidth - offset.left - offset.right;
  var offsetHeight = chartHeight - offset.top - offset.bottom;
  return _objectSpread(_objectSpread({
    brushBottom
  }, offset), {}, {
    // never return negative values for height and width
    width: Math.max(offsetWidth, 0),
    height: Math.max(offsetHeight, 0)
  });
});
var selectChartViewBox = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(selectChartOffsetInternal, offset => ({
  x: offset.left,
  y: offset.top,
  width: offset.width,
  height: offset.height
}));
var selectAxisViewBox = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_containerSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectChartHeight */ .A$, (width, height) => ({
  x: 0,
  y: 0,
  width,
  height
}));

/***/ }),

/***/ 37617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ selectTooltipAxis),
/* harmony export */   K: () => (/* binding */ selectTooltipAxisDataKey)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11114);
/* harmony import */ var _selectTooltipAxisType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15950);
/* harmony import */ var _selectTooltipAxisId__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86680);




var selectTooltipAxis = state => {
  var axisType = (0,_selectTooltipAxisType__WEBPACK_IMPORTED_MODULE_2__/* .selectTooltipAxisType */ .R)(state);
  var axisId = (0,_selectTooltipAxisId__WEBPACK_IMPORTED_MODULE_3__/* .selectTooltipAxisId */ .M)(state);
  return (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisSettings */ .Hd)(state, axisType, axisId);
};
var selectTooltipAxisDataKey = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectTooltipAxis], axis => axis === null || axis === void 0 ? void 0 : axis.dataKey);

/***/ }),

/***/ 39375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ selectScatterPoints)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _cartesian_Scatter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14799);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(98453);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11114);




var selectXAxisWithScale = (state, xAxisId, _yAxisId, _zAxisId, _id, _cells, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
var selectXAxisTicks = (state, xAxisId, _yAxisId, _zAxisId, _id, _cells, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
var selectYAxisWithScale = (state, _xAxisId, yAxisId, _zAxisId, _id, _cells, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
var selectYAxisTicks = (state, _xAxisId, yAxisId, _zAxisId, _id, _cells, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
var selectZAxis = (state, _xAxisId, _yAxisId, zAxisId) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectZAxisWithScale */ .Y)(state, 'zAxis', zAxisId, false);
var pickScatterId = (_state, _xAxisId, _yAxisId, _zAxisId, id) => id;
var pickCells = (_state, _xAxisId, _yAxisId, _zAxisId, _id, cells) => cells;
var scatterChartDataSelector = (state, xAxisId, yAxisId, _zAxisId, _id, _cells, isPanorama) => (0,_dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS)(state, xAxisId, yAxisId, isPanorama);
var selectSynchronisedScatterSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectUnfilteredCartesianItems */ .ld, pickScatterId], (graphicalItems, id) => {
  return graphicalItems.filter(item => item.type === 'scatter').find(item => item.id === id);
});
var selectScatterPoints = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([scatterChartDataSelector, selectXAxisWithScale, selectXAxisTicks, selectYAxisWithScale, selectYAxisTicks, selectZAxis, selectSynchronisedScatterSettings, pickCells], (_ref, xAxis, xAxisTicks, yAxis, yAxisTicks, zAxis, scatterSettings, cells) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref;
  if (scatterSettings == null) {
    return undefined;
  }
  var displayedData;
  if ((scatterSettings === null || scatterSettings === void 0 ? void 0 : scatterSettings.data) != null && scatterSettings.data.length > 0) {
    displayedData = scatterSettings.data;
  } else {
    displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
  }
  if (displayedData == null || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || (xAxisTicks === null || xAxisTicks === void 0 ? void 0 : xAxisTicks.length) === 0 || (yAxisTicks === null || yAxisTicks === void 0 ? void 0 : yAxisTicks.length) === 0) {
    return undefined;
  }
  return (0,_cartesian_Scatter__WEBPACK_IMPORTED_MODULE_1__/* .computeScatterPoints */ .J)({
    displayedData,
    xAxis,
    yAxis,
    zAxis,
    scatterSettings,
    xAxisTicks,
    yAxisTicks,
    cells
  });
});

/***/ }),

/***/ 40357:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ selectPlotArea)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _selectChartOffset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(70475);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5180);



var selectPlotArea = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffset__WEBPACK_IMPORTED_MODULE_1__/* .selectChartOffset */ .G, _containerSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartHeight */ .A$], (offset, chartWidth, chartHeight) => {
  if (!offset || chartWidth == null || chartHeight == null) {
    return undefined;
  }
  return {
    x: offset.left,
    y: offset.top,
    width: Math.max(0, chartWidth - offset.left - offset.right),
    height: Math.max(0, chartHeight - offset.top - offset.bottom)
  };
});

/***/ }),

/***/ 41927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ pickAxisType)
/* harmony export */ });
var pickAxisType = (_state, axisType) => axisType;

/***/ }),

/***/ 43337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sb: () => (/* binding */ removeRadiusAxis),
/* harmony export */   Ys: () => (/* binding */ addAngleAxis),
/* harmony export */   jx: () => (/* binding */ removeAngleAxis),
/* harmony export */   w2: () => (/* binding */ polarAxisReducer),
/* harmony export */   zo: () => (/* binding */ addRadiusAxis)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1932);


var initialState = {
  radiusAxis: {},
  angleAxis: {}
};
var polarAxisSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'polarAxis',
  initialState,
  reducers: {
    addRadiusAxis(state, action) {
      state.radiusAxis[action.payload.id] = (0,immer__WEBPACK_IMPORTED_MODULE_1__/* .castDraft */ .h4)(action.payload);
    },
    removeRadiusAxis(state, action) {
      delete state.radiusAxis[action.payload.id];
    },
    addAngleAxis(state, action) {
      state.angleAxis[action.payload.id] = (0,immer__WEBPACK_IMPORTED_MODULE_1__/* .castDraft */ .h4)(action.payload);
    },
    removeAngleAxis(state, action) {
      delete state.angleAxis[action.payload.id];
    }
  }
});
var {
  addRadiusAxis,
  removeRadiusAxis,
  addAngleAxis,
  removeAngleAxis
} = polarAxisSlice.actions;
var polarAxisReducer = polarAxisSlice.reducer;

/***/ }),

/***/ 43416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  E: () => (/* binding */ createRechartsStore)
});

// EXTERNAL MODULE: ./node_modules/recharts/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs + 2 modules
var redux_toolkit_modern = __webpack_require__(4768);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/optionsSlice.js
var optionsSlice = __webpack_require__(26960);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/tooltipSlice.js
var tooltipSlice = __webpack_require__(74531);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/chartDataSlice.js
var chartDataSlice = __webpack_require__(46446);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/layoutSlice.js
var layoutSlice = __webpack_require__(66426);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/mouseEventsMiddleware.js
var mouseEventsMiddleware = __webpack_require__(8596);
;// ./node_modules/recharts/es6/state/reduxDevtoolsJsonStringifyReplacer.js
function reduxDevtoolsJsonStringifyReplacer(_key, value) {
  if (value instanceof HTMLElement) {
    return "HTMLElement <".concat(value.tagName, " class=\"").concat(value.className, "\">");
  }
  if (value === window) {
    return 'global.window';
  }
  return value;
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/cartesianAxisSlice.js
var cartesianAxisSlice = __webpack_require__(94115);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/graphicalItemsSlice.js
var graphicalItemsSlice = __webpack_require__(92617);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/referenceElementsSlice.js
var referenceElementsSlice = __webpack_require__(26314);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/brushSlice.js
var brushSlice = __webpack_require__(2658);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/legendSlice.js
var legendSlice = __webpack_require__(91283);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/rootPropsSlice.js
var rootPropsSlice = __webpack_require__(92476);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/polarAxisSlice.js
var polarAxisSlice = __webpack_require__(43337);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/polarOptionsSlice.js
var polarOptionsSlice = __webpack_require__(19794);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/keyboardEventsMiddleware.js
var keyboardEventsMiddleware = __webpack_require__(77232);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/externalEventsMiddleware.js
var externalEventsMiddleware = __webpack_require__(73102);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/touchEventsMiddleware.js + 1 modules
var touchEventsMiddleware = __webpack_require__(21077);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/errorBarSlice.js
var errorBarSlice = __webpack_require__(32117);
// EXTERNAL MODULE: ./node_modules/recharts/es6/util/Global.js
var Global = __webpack_require__(59938);
;// ./node_modules/recharts/es6/state/store.js




















var rootReducer = (0,redux_toolkit_modern/* combineReducers */.HY)({
  brush: brushSlice/* brushReducer */.rT,
  cartesianAxis: cartesianAxisSlice/* cartesianAxisReducer */.CA,
  chartData: chartDataSlice/* chartDataReducer */.LV,
  errorBars: errorBarSlice/* errorBarReducer */.Qk,
  graphicalItems: graphicalItemsSlice/* graphicalItemsReducer */.iZ,
  layout: layoutSlice/* chartLayoutReducer */.Vp,
  legend: legendSlice/* legendReducer */.CU,
  options: optionsSlice/* optionsReducer */.lJ,
  polarAxis: polarAxisSlice/* polarAxisReducer */.w2,
  polarOptions: polarOptionsSlice/* polarOptionsReducer */.J,
  referenceElements: referenceElementsSlice/* referenceElementsReducer */.fV,
  rootProps: rootPropsSlice/* rootPropsReducer */.vE,
  tooltip: tooltipSlice/* tooltipReducer */.En
});
var createRechartsStore = function createRechartsStore(preloadedState) {
  var chartName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Chart';
  return (0,redux_toolkit_modern/* configureStore */.U1)({
    reducer: rootReducer,
    // redux-toolkit v1 types are unhappy with the preloadedState type. Remove the `as any` when bumping to v2
    preloadedState: preloadedState,
    // @ts-expect-error redux-toolkit v1 types are unhappy with the middleware array. Remove this comment when bumping to v2
    middleware: getDefaultMiddleware => getDefaultMiddleware({
      serializableCheck: false
    }).concat([mouseEventsMiddleware/* mouseClickMiddleware */.YF.middleware, mouseEventsMiddleware/* mouseMoveMiddleware */.fP.middleware, keyboardEventsMiddleware/* keyboardEventsMiddleware */.$7.middleware, externalEventsMiddleware/* externalEventsMiddleware */.x.middleware, touchEventsMiddleware/* touchEventMiddleware */.k.middleware]),
    /*
     * I can't find out how to satisfy typescript here.
     * We return `EnhancerArray<[StoreEnhancer<{}, {}>, StoreEnhancer]>` from this function,
     * but the types say we should return `EnhancerArray<StoreEnhancer<{}, {}>`.
     * Looks like it's badly inferred generics, but it won't allow me to provide the correct type manually either.
     * So let's just ignore the error for now.
     */
    // @ts-expect-error mismatched generics
    enhancers: getDefaultEnhancers => {
      var enhancers = getDefaultEnhancers;
      if (typeof getDefaultEnhancers === 'function') {
        /*
         * In RTK v2 this is always a function, but in v1 it is an array.
         * Because we have @types/redux-toolkit v1 as a dependency, typescript is going to flag this as an error.
         * We support both RTK v1 and v2, so we need to do this check.
         * https://redux-toolkit.js.org/usage/migrating-rtk-2#configurestoreenhancers-must-be-a-callback
         */
        // @ts-expect-error RTK v2 behaviour on RTK v1 types
        enhancers = getDefaultEnhancers();
      }
      return enhancers.concat((0,redux_toolkit_modern/* autoBatchEnhancer */.CF)({
        type: 'raf'
      }));
    },
    devTools: Global/* Global */.m.devToolsEnabled && {
      serialize: {
        replacer: reduxDevtoolsJsonStringifyReplacer
      },
      name: "recharts-".concat(chartName)
    }
  });
};

/***/ }),

/***/ 44747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ selectLinePoints)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _cartesian_Line__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86279);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(98453);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19287);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11114);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33964);






var selectXAxisWithScale = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
var selectXAxisTicks = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
var selectYAxisWithScale = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
var selectYAxisTicks = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
var selectBandSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectXAxisWithScale, selectYAxisWithScale, selectXAxisTicks, selectYAxisTicks], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks) => {
  if ((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .isCategoricalAxis */ ._L)(layout, 'xAxis')) {
    return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getBandSizeOfAxis */ .Hj)(xAxis, xAxisTicks, false);
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_5__/* .getBandSizeOfAxis */ .Hj)(yAxis, yAxisTicks, false);
});
var pickLineId = (_state, _xAxisId, _yAxisId, _isPanorama, id) => id;
function isLineSettings(item) {
  return item.type === 'line';
}

/*
 * There is a race condition problem because we read some data from props and some from the state.
 * The state is updated through a dispatch and is one render behind,
 * and so we have this weird one tick render where the displayedData in one selector have the old dataKey
 * but the new dataKey in another selector.
 *
 * So here instead of reading the dataKey from the props, we always read it from the state.
 */
var selectSynchronisedLineSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectUnfilteredCartesianItems */ .ld, pickLineId], (graphicalItems, id) => graphicalItems.filter(isLineSettings).find(x => x.id === id));
var selectLinePoints = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_3__/* .selectChartLayout */ .fz, selectXAxisWithScale, selectYAxisWithScale, selectXAxisTicks, selectYAxisTicks, selectSynchronisedLineSettings, selectBandSize, _dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks, lineSettings, bandSize, _ref) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref;
  if (lineSettings == null || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || xAxisTicks.length === 0 || yAxisTicks.length === 0 || bandSize == null) {
    return undefined;
  }
  var {
    dataKey,
    data
  } = lineSettings;
  var displayedData;
  if (data != null && data.length > 0) {
    displayedData = data;
  } else {
    displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
  }
  if (displayedData == null) {
    return undefined;
  }
  return (0,_cartesian_Line__WEBPACK_IMPORTED_MODULE_1__/* .computeLinePoints */ .l)({
    layout,
    xAxis,
    yAxis,
    xAxisTicks,
    yAxisTicks,
    dataKey,
    bandSize,
    displayedData
  });
});

/***/ }),

/***/ 47962:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dc: () => (/* binding */ selectLegendSize),
/* harmony export */   ff: () => (/* binding */ selectLegendSettings),
/* harmony export */   g0: () => (/* binding */ selectLegendPayload)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60184);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__);


var selectLegendSettings = state => state.legend.settings;
var selectLegendSize = state => state.legend.size;
var selectAllLegendPayload2DArray = state => state.legend.payload;
var selectLegendPayload = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAllLegendPayload2DArray, selectLegendSettings], (payloads, _ref) => {
  var {
    itemSorter
  } = _ref;
  var flat = payloads.flat(1);
  return itemSorter ? es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default()(flat, itemSorter) : flat;
});

/***/ }),

/***/ 50357:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   t: () => (/* binding */ generatePrefixStyle)
/* harmony export */ });
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var PREFIX_LIST = ['Webkit', 'Moz', 'O', 'ms'];
var generatePrefixStyle = (name, value) => {
  if (!name) {
    return undefined;
  }
  var camelName = name.replace(/(\w)/, v => v.toUpperCase());
  var result = PREFIX_LIST.reduce((res, entry) => _objectSpread(_objectSpread({}, res), {}, {
    [entry + camelName]: value
  }), {});
  result[name] = value;
  return result;
};

/***/ }),

/***/ 53758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cr: () => (/* binding */ selectRadarPoints)
/* harmony export */ });
/* unused harmony exports selectRadiusAxisForBandSize, selectAngleAxisForBandSize, selectAngleAxisWithScaleAndViewport */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _polar_Radar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21567);
/* harmony import */ var _polarScaleSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28871);
/* harmony import */ var _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61270);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98453);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19287);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33964);
/* harmony import */ var _polarSelectors__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19033);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }








var selectRadiusAxisScale = (state, radiusAxisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectPolarAxisScale */ .Qr)(state, 'radiusAxis', radiusAxisId);
var selectRadiusAxisForRadar = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadiusAxisScale], scale => {
  if (scale == null) {
    return undefined;
  }
  return {
    scale
  };
});
var selectRadiusAxisForBandSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectRadiusAxis */ .Gl, selectRadiusAxisScale], (axisSettings, scale) => {
  if (axisSettings == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axisSettings), {}, {
    scale
  });
});
var selectRadiusAxisTicks = (state, radiusAxisId, _angleAxisId, isPanorama) => {
  return (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectPolarAxisTicks */ .YF)(state, 'radiusAxis', radiusAxisId, isPanorama);
};
var selectAngleAxisForRadar = (state, _radiusAxisId, angleAxisId) => (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectAngleAxis */ .Be)(state, angleAxisId);
var selectPolarAxisScaleForRadar = (state, _radiusAxisId, angleAxisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectPolarAxisScale */ .Qr)(state, 'angleAxis', angleAxisId);
var selectAngleAxisForBandSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisForRadar, selectPolarAxisScaleForRadar], (axisSettings, scale) => {
  if (axisSettings == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axisSettings), {}, {
    scale
  });
});
var selectAngleAxisTicks = (state, _radiusAxisId, angleAxisId, isPanorama) => {
  return (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectPolarAxisTicks */ .YF)(state, 'angleAxis', angleAxisId, isPanorama);
};
var selectAngleAxisWithScaleAndViewport = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisForRadar, selectPolarAxisScaleForRadar, _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectPolarViewBox */ .D0], (axisOptions, scale, polarViewBox) => {
  if (polarViewBox == null || scale == null) {
    return undefined;
  }
  return {
    scale,
    type: axisOptions.type,
    dataKey: axisOptions.dataKey,
    cx: polarViewBox.cx,
    cy: polarViewBox.cy
  };
});
var pickId = (_state, _radiusAxisId, _angleAxisId, _isPanorama, radarId) => radarId;
var selectBandSizeOfAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz, selectRadiusAxisForBandSize, selectRadiusAxisTicks, selectAngleAxisForBandSize, selectAngleAxisTicks], (layout, radiusAxis, radiusAxisTicks, angleAxis, angleAxisTicks) => {
  if ((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_6__/* .isCategoricalAxis */ ._L)(layout, 'radiusAxis')) {
    return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_6__/* .getBandSizeOfAxis */ .Hj)(radiusAxis, radiusAxisTicks, false);
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_6__/* .getBandSizeOfAxis */ .Hj)(angleAxis, angleAxisTicks, false);
});
var selectSynchronisedRadarDataKey = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_polarSelectors__WEBPACK_IMPORTED_MODULE_7__/* .selectUnfilteredPolarItems */ .nz, pickId], (graphicalItems, radarId) => {
  if (graphicalItems == null) {
    return undefined;
  }
  // Find the radar item with the given radarId
  var pgis = graphicalItems.find(item => item.type === 'radar' && radarId === item.id);
  // If found, return its dataKey
  return pgis === null || pgis === void 0 ? void 0 : pgis.dataKey;
});
var selectRadarPoints = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadiusAxisForRadar, selectAngleAxisWithScaleAndViewport, _dataSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3, selectSynchronisedRadarDataKey, selectBandSizeOfAxis], (radiusAxis, angleAxis, _ref, dataKey, bandSize) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref;
  if (radiusAxis == null || angleAxis == null || chartData == null || bandSize == null || dataKey == null) {
    return undefined;
  }
  var displayedData = chartData.slice(dataStartIndex, dataEndIndex + 1);
  return (0,_polar_Radar__WEBPACK_IMPORTED_MODULE_1__/* .computeRadarPoints */ .T)({
    radiusAxis,
    angleAxis,
    displayedData,
    dataKey,
    bandSize
  });
});

/***/ }),

/***/ 55978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $g: () => (/* binding */ combineTooltipEventType),
/* harmony export */   Hw: () => (/* binding */ selectValidateTooltipEventTypes),
/* harmony export */   Td: () => (/* binding */ useTooltipEventType),
/* harmony export */   au: () => (/* binding */ selectTooltipEventType),
/* harmony export */   xH: () => (/* binding */ selectDefaultTooltipEventType)
/* harmony export */ });
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49082);

var selectDefaultTooltipEventType = state => state.options.defaultTooltipEventType;
var selectValidateTooltipEventTypes = state => state.options.validateTooltipEventTypes;
function combineTooltipEventType(shared, defaultTooltipEventType, validateTooltipEventTypes) {
  if (shared == null) {
    return defaultTooltipEventType;
  }
  var eventType = shared ? 'axis' : 'item';
  if (validateTooltipEventTypes == null) {
    return defaultTooltipEventType;
  }
  return validateTooltipEventTypes.includes(eventType) ? eventType : defaultTooltipEventType;
}
function selectTooltipEventType(state, shared) {
  var defaultTooltipEventType = selectDefaultTooltipEventType(state);
  var validateTooltipEventTypes = selectValidateTooltipEventTypes(state);
  return combineTooltipEventType(shared, defaultTooltipEventType, validateTooltipEventTypes);
}
function useTooltipEventType(shared) {
  return (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .G)(state => selectTooltipEventType(state, shared));
}

/***/ }),

/***/ 59744:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CG: () => (/* binding */ hasDuplicate),
/* harmony export */   Dj: () => (/* binding */ interpolateNumber),
/* harmony export */   Et: () => (/* binding */ isNumber),
/* harmony export */   F4: () => (/* binding */ getPercentValue),
/* harmony export */   GW: () => (/* binding */ interpolate),
/* harmony export */   M8: () => (/* binding */ isNan),
/* harmony export */   NF: () => (/* binding */ uniqueId),
/* harmony export */   Zb: () => (/* binding */ upperFirst),
/* harmony export */   _3: () => (/* binding */ isPercent),
/* harmony export */   eP: () => (/* binding */ findEntryInArray),
/* harmony export */   jG: () => (/* binding */ getLinearRegression),
/* harmony export */   sA: () => (/* binding */ mathSign),
/* harmony export */   uy: () => (/* binding */ isNullish),
/* harmony export */   vh: () => (/* binding */ isNumOrStr)
/* harmony export */ });
/* harmony import */ var es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(80305);
/* harmony import */ var es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_0__);

var mathSign = value => {
  if (value === 0) {
    return 0;
  }
  if (value > 0) {
    return 1;
  }
  return -1;
};
var isNan = value => {
  // eslint-disable-next-line eqeqeq
  return typeof value == 'number' && value != +value;
};
var isPercent = value => typeof value === 'string' && value.indexOf('%') === value.length - 1;
var isNumber = value => (typeof value === 'number' || value instanceof Number) && !isNan(value);
var isNumOrStr = value => isNumber(value) || typeof value === 'string';
var idCounter = 0;
var uniqueId = prefix => {
  var id = ++idCounter;
  return "".concat(prefix || '').concat(id);
};

/**
 * Get percent value of a total value
 * @param {number|string} percent A percent
 * @param {number} totalValue     Total value
 * @param {number} defaultValue   The value returned when percent is undefined or invalid
 * @param {boolean} validate      If set to be true, the result will be validated
 * @return {number} value
 */
var getPercentValue = function getPercentValue(percent, totalValue) {
  var defaultValue = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var validate = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
  if (!isNumber(percent) && typeof percent !== 'string') {
    return defaultValue;
  }
  var value;
  if (isPercent(percent)) {
    if (totalValue == null) {
      return defaultValue;
    }
    var index = percent.indexOf('%');
    value = totalValue * parseFloat(percent.slice(0, index)) / 100;
  } else {
    value = +percent;
  }
  if (isNan(value)) {
    value = defaultValue;
  }
  if (validate && totalValue != null && value > totalValue) {
    value = totalValue;
  }
  return value;
};
var hasDuplicate = ary => {
  if (!Array.isArray(ary)) {
    return false;
  }
  var len = ary.length;
  var cache = {};
  for (var i = 0; i < len; i++) {
    if (!cache[ary[i]]) {
      cache[ary[i]] = true;
    } else {
      return true;
    }
  }
  return false;
};

/**
 * @deprecated instead use {@link interpolate}
 *  this function returns a function that is called immediately in all use-cases.
 *  Instead, use interpolate which returns a number and skips the anonymous function step.
 *  @param numberA The first number
 *  @param numberB The second number
 *  @return A function that returns the interpolated number
 */
var interpolateNumber = (numberA, numberB) => {
  if (isNumber(numberA) && isNumber(numberB)) {
    return t => numberA + t * (numberB - numberA);
  }
  return () => numberB;
};
function interpolate(start, end, t) {
  if (isNumber(start) && isNumber(end)) {
    return start + t * (end - start);
  }
  return end;
}
function findEntryInArray(ary, specifiedKey, specifiedValue) {
  if (!ary || !ary.length) {
    return undefined;
  }
  return ary.find(entry => entry && (typeof specifiedKey === 'function' ? specifiedKey(entry) : es_toolkit_compat_get__WEBPACK_IMPORTED_MODULE_0___default()(entry, specifiedKey)) === specifiedValue);
}

/**
 * The least square linear regression
 * @param {Array} data The array of points
 * @returns {Object} The domain of x, and the parameter of linear function
 */
var getLinearRegression = data => {
  if (!data || !data.length) {
    return null;
  }
  var len = data.length;
  var xsum = 0;
  var ysum = 0;
  var xysum = 0;
  var xxsum = 0;
  var xmin = Infinity;
  var xmax = -Infinity;
  var xcurrent = 0;
  var ycurrent = 0;
  for (var i = 0; i < len; i++) {
    xcurrent = data[i].cx || 0;
    ycurrent = data[i].cy || 0;
    xsum += xcurrent;
    ysum += ycurrent;
    xysum += xcurrent * ycurrent;
    xxsum += xcurrent * xcurrent;
    xmin = Math.min(xmin, xcurrent);
    xmax = Math.max(xmax, xcurrent);
  }
  var a = len * xxsum !== xsum * xsum ? (len * xysum - xsum * ysum) / (len * xxsum - xsum * xsum) : 0;
  return {
    xmin,
    xmax,
    a,
    b: (ysum - a * xsum) / len
  };
};
/**
 * Checks if the value is null or undefined
 * @param value The value to check
 * @returns true if the value is null or undefined
 */
var isNullish = value => {
  return value === null || typeof value === 'undefined';
};

/**
 *Uppercase the first letter of a string
 * @param {string} value The string to uppercase
 * @returns {string} The uppercased string
 */
var upperFirst = value => {
  if (isNullish(value)) {
    return value;
  }
  return "".concat(value.charAt(0).toUpperCase()).concat(value.slice(1));
};

/***/ }),

/***/ 60523:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   q: () => (/* binding */ combineTooltipPayloadConfigurations)
/* harmony export */ });
var combineTooltipPayloadConfigurations = (tooltipState, tooltipEventType, trigger, defaultIndex) => {
  // if tooltip reacts to axis interaction, then we display all items at the same time.
  if (tooltipEventType === 'axis') {
    return tooltipState.tooltipItemPayloads;
  }
  /*
   * By now we already know that tooltipEventType is 'item', so we can only search in itemInteractions.
   * item means that only the hovered or clicked item will be present in the tooltip.
   */
  if (tooltipState.tooltipItemPayloads.length === 0) {
    // No point filtering if the payload is empty
    return [];
  }
  var filterByDataKey;
  if (trigger === 'hover') {
    filterByDataKey = tooltipState.itemInteraction.hover.dataKey;
  } else {
    filterByDataKey = tooltipState.itemInteraction.click.dataKey;
  }
  if (filterByDataKey == null && defaultIndex != null) {
    /*
     * So when we use `defaultIndex` - we don't have a dataKey to filter by because user did not hover over anything yet.
     * In that case let's display the first item in the tooltip; after all, this is `item` interaction case,
     * so we should display only one item at a time instead of all.
     */
    return [tooltipState.tooltipItemPayloads[0]];
  }
  return tooltipState.tooltipItemPayloads.filter(tpc => {
    var _tpc$settings;
    return ((_tpc$settings = tpc.settings) === null || _tpc$settings === void 0 ? void 0 : _tpc$settings.dataKey) === filterByDataKey;
  });
};

/***/ }),

/***/ 61270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Be: () => (/* binding */ selectAngleAxis),
/* harmony export */   Cv: () => (/* binding */ selectAngleAxisRange),
/* harmony export */   D0: () => (/* binding */ selectPolarViewBox),
/* harmony export */   Dc: () => (/* binding */ selectRadiusAxisRange),
/* harmony export */   Gl: () => (/* binding */ selectRadiusAxis),
/* harmony export */   k5: () => (/* binding */ selectAngleAxisRangeWithReversed),
/* harmony export */   nX: () => (/* binding */ selectRadiusAxisRangeWithReversed)
/* harmony export */ });
/* unused harmony exports implicitAngleAxis, implicitRadiusAxis, implicitRadialBarAngleAxis, implicitRadialBarRadiusAxis, selectPolarOptions, selectMaxRadius, selectOuterRadius */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5180);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36189);
/* harmony import */ var _util_PolarUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14040);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59744);
/* harmony import */ var _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(46344);
/* harmony import */ var _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57777);
/* harmony import */ var _combiners_combineAxisRangeWithReverse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19495);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(19287);









var implicitAngleAxis = {
  allowDataOverflow: false,
  allowDecimals: false,
  allowDuplicatedCategory: false,
  // defaultPolarAngleAxisProps.allowDuplicatedCategory has it set to true but the actual axis rendering ignores the prop because reasons,
  dataKey: undefined,
  domain: undefined,
  id: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.angleAxisId,
  includeHidden: false,
  name: undefined,
  reversed: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.reversed,
  scale: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.scale,
  tick: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.tick,
  tickCount: undefined,
  ticks: undefined,
  type: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.type,
  unit: undefined
};
var implicitRadiusAxis = {
  allowDataOverflow: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.allowDataOverflow,
  allowDecimals: false,
  allowDuplicatedCategory: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.allowDuplicatedCategory,
  dataKey: undefined,
  domain: undefined,
  id: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.radiusAxisId,
  includeHidden: false,
  name: undefined,
  reversed: false,
  scale: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.scale,
  tick: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.tick,
  tickCount: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.tickCount,
  ticks: undefined,
  type: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.type,
  unit: undefined
};
var implicitRadialBarAngleAxis = {
  allowDataOverflow: false,
  allowDecimals: false,
  allowDuplicatedCategory: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.allowDuplicatedCategory,
  dataKey: undefined,
  domain: undefined,
  id: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.angleAxisId,
  includeHidden: false,
  name: undefined,
  reversed: false,
  scale: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.scale,
  tick: _polar_defaultPolarAngleAxisProps__WEBPACK_IMPORTED_MODULE_5__/* .defaultPolarAngleAxisProps */ .c.tick,
  tickCount: undefined,
  ticks: undefined,
  type: 'number',
  unit: undefined
};
var implicitRadialBarRadiusAxis = {
  allowDataOverflow: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.allowDataOverflow,
  allowDecimals: false,
  allowDuplicatedCategory: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.allowDuplicatedCategory,
  dataKey: undefined,
  domain: undefined,
  id: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.radiusAxisId,
  includeHidden: false,
  name: undefined,
  reversed: false,
  scale: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.scale,
  tick: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.tick,
  tickCount: _polar_defaultPolarRadiusAxisProps__WEBPACK_IMPORTED_MODULE_6__/* .defaultPolarRadiusAxisProps */ .j.tickCount,
  ticks: undefined,
  type: 'category',
  unit: undefined
};
var selectAngleAxis = (state, angleAxisId) => {
  if (state.polarAxis.angleAxis[angleAxisId] != null) {
    return state.polarAxis.angleAxis[angleAxisId];
  }
  if (state.layout.layoutType === 'radial') {
    return implicitRadialBarAngleAxis;
  }
  return implicitAngleAxis;
};
var selectRadiusAxis = (state, radiusAxisId) => {
  if (state.polarAxis.radiusAxis[radiusAxisId] != null) {
    return state.polarAxis.radiusAxis[radiusAxisId];
  }
  if (state.layout.layoutType === 'radial') {
    return implicitRadialBarRadiusAxis;
  }
  return implicitRadiusAxis;
};
var selectPolarOptions = state => state.polarOptions;
var selectMaxRadius = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_containerSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectChartHeight */ .A$, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_2__/* .selectChartOffsetInternal */ .HZ], _util_PolarUtils__WEBPACK_IMPORTED_MODULE_3__/* .getMaxRadius */ .lY);
var selectInnerRadius = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarOptions, selectMaxRadius], (polarChartOptions, maxRadius) => {
  if (polarChartOptions == null) {
    return undefined;
  }
  return (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_4__/* .getPercentValue */ .F4)(polarChartOptions.innerRadius, maxRadius, 0);
});
var selectOuterRadius = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarOptions, selectMaxRadius], (polarChartOptions, maxRadius) => {
  if (polarChartOptions == null) {
    return undefined;
  }
  return (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_4__/* .getPercentValue */ .F4)(polarChartOptions.outerRadius, maxRadius, maxRadius * 0.8);
});
var combineAngleAxisRange = polarOptions => {
  if (polarOptions == null) {
    return [0, 0];
  }
  var {
    startAngle,
    endAngle
  } = polarOptions;
  return [startAngle, endAngle];
};
var selectAngleAxisRange = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarOptions], combineAngleAxisRange);
var selectAngleAxisRangeWithReversed = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxis, selectAngleAxisRange], _combiners_combineAxisRangeWithReverse__WEBPACK_IMPORTED_MODULE_7__/* .combineAxisRangeWithReverse */ .I);
var selectRadiusAxisRange = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectMaxRadius, selectInnerRadius, selectOuterRadius], (maxRadius, innerRadius, outerRadius) => {
  if (maxRadius == null || innerRadius == null || outerRadius == null) {
    return undefined;
  }
  return [innerRadius, outerRadius];
});
var selectRadiusAxisRangeWithReversed = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadiusAxis, selectRadiusAxisRange], _combiners_combineAxisRangeWithReverse__WEBPACK_IMPORTED_MODULE_7__/* .combineAxisRangeWithReverse */ .I);
var selectPolarViewBox = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_8__/* .selectChartLayout */ .fz, selectPolarOptions, selectInnerRadius, selectOuterRadius, _containerSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectChartHeight */ .A$], (layout, polarOptions, innerRadius, outerRadius, width, height) => {
  if (layout !== 'centric' && layout !== 'radial' || polarOptions == null || innerRadius == null || outerRadius == null) {
    return undefined;
  }
  var {
    cx,
    cy,
    startAngle,
    endAngle
  } = polarOptions;
  return {
    cx: (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_4__/* .getPercentValue */ .F4)(cx, width, width / 2),
    cy: (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_4__/* .getPercentValue */ .F4)(cy, height, height / 2),
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    clockWise: false // this property look useful, why not use it?
  };
});

/***/ }),

/***/ 63042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  fx: () => (/* binding */ useBrushChartSynchronisation),
  l3: () => (/* binding */ useSynchronisedEventsFromOtherCharts),
  m7: () => (/* binding */ useTooltipChartSynchronisation)
});

// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(96540);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/hooks.js
var hooks = __webpack_require__(49082);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/rootPropsSelectors.js
var rootPropsSelectors = __webpack_require__(82695);
// EXTERNAL MODULE: ./node_modules/recharts/node_modules/eventemitter3/index.mjs
var eventemitter3 = __webpack_require__(39638);
;// ./node_modules/recharts/es6/util/Events.js

var eventCenter = new eventemitter3/* default */.A();

var TOOLTIP_SYNC_EVENT = 'recharts.syncEvent.tooltip';
var BRUSH_SYNC_EVENT = 'recharts.syncEvent.brush';
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/optionsSlice.js
var optionsSlice = __webpack_require__(26960);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/tooltipSlice.js
var tooltipSlice = __webpack_require__(74531);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/selectors.js
var selectors = __webpack_require__(87997);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/selectors/tooltipSelectors.js + 1 modules
var tooltipSelectors = __webpack_require__(33032);
;// ./node_modules/recharts/es6/synchronisation/syncSelectors.js
function selectSynchronisedTooltipState(state) {
  return state.tooltip.syncInteraction;
}
// EXTERNAL MODULE: ./node_modules/recharts/es6/context/chartLayoutContext.js
var chartLayoutContext = __webpack_require__(19287);
// EXTERNAL MODULE: ./node_modules/recharts/es6/state/chartDataSlice.js
var chartDataSlice = __webpack_require__(46446);
;// ./node_modules/recharts/es6/synchronisation/useChartSynchronisation.js
var _excluded = ["x", "y"];
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }











var noop = () => {};
function useTooltipSyncEventsListener() {
  var mySyncId = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncId */.lZ);
  var myEventEmitter = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectEventEmitter */.pH);
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  var syncMethod = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncMethod */.hX);
  var tooltipTicks = (0,hooks/* useAppSelector */.G)(tooltipSelectors/* selectTooltipAxisTicks */.R4);
  var layout = (0,chartLayoutContext/* useChartLayout */.WX)();
  var viewBox = (0,chartLayoutContext/* useViewBox */.sk)();
  var className = (0,hooks/* useAppSelector */.G)(state => state.rootProps.className);
  (0,react.useEffect)(() => {
    if (mySyncId == null) {
      // This chart is not synchronised with any other chart so we don't need to listen for any events.
      return noop;
    }
    var listener = (incomingSyncId, action, emitter) => {
      if (myEventEmitter === emitter) {
        // We don't want to dispatch actions that we sent ourselves.
        return;
      }
      if (mySyncId !== incomingSyncId) {
        // This event is not for this chart
        return;
      }
      if (syncMethod === 'index') {
        var _action$payload;
        if (viewBox && action !== null && action !== void 0 && (_action$payload = action.payload) !== null && _action$payload !== void 0 && _action$payload.coordinate && action.payload.sourceViewBox) {
          var _action$payload$coord = action.payload.coordinate,
            {
              x: _x,
              y: _y
            } = _action$payload$coord,
            otherCoordinateProps = _objectWithoutProperties(_action$payload$coord, _excluded);
          var {
            x: sourceX,
            y: sourceY,
            width: sourceWidth,
            height: sourceHeight
          } = action.payload.sourceViewBox;
          var scaledCoordinate = _objectSpread(_objectSpread({}, otherCoordinateProps), {}, {
            x: viewBox.x + (sourceWidth ? (_x - sourceX) / sourceWidth : 0) * viewBox.width,
            y: viewBox.y + (sourceHeight ? (_y - sourceY) / sourceHeight : 0) * viewBox.height
          });
          dispatch(_objectSpread(_objectSpread({}, action), {}, {
            payload: _objectSpread(_objectSpread({}, action.payload), {}, {
              coordinate: scaledCoordinate
            })
          }));
        } else {
          dispatch(action);
        }
        return;
      }
      if (tooltipTicks == null) {
        // for the other two sync methods, we need the ticks to be available
        return;
      }
      var activeTick;
      if (typeof syncMethod === 'function') {
        /*
         * This is what the data shape in 2.x CategoricalChartState used to look like.
         * In 3.x we store things differently but let's try to keep the old shape for compatibility.
         */
        var syncMethodParam = {
          activeTooltipIndex: action.payload.index == null ? undefined : Number(action.payload.index),
          isTooltipActive: action.payload.active,
          activeIndex: action.payload.index == null ? undefined : Number(action.payload.index),
          activeLabel: action.payload.label,
          activeDataKey: action.payload.dataKey,
          activeCoordinate: action.payload.coordinate
        };
        // Call a callback function. If there is an application specific algorithm
        var activeTooltipIndex = syncMethod(tooltipTicks, syncMethodParam);
        activeTick = tooltipTicks[activeTooltipIndex];
      } else if (syncMethod === 'value') {
        // labels are always strings, tick.value might be a string or a number, depending on axis type
        activeTick = tooltipTicks.find(tick => String(tick.value) === action.payload.label);
      }
      var {
        coordinate
      } = action.payload;
      if (activeTick == null || action.payload.active === false || coordinate == null || viewBox == null) {
        dispatch((0,tooltipSlice/* setSyncInteraction */.E1)({
          active: false,
          coordinate: undefined,
          dataKey: undefined,
          index: null,
          label: undefined,
          sourceViewBox: undefined
        }));
        return;
      }
      var {
        x,
        y
      } = coordinate;
      var validateChartX = Math.min(x, viewBox.x + viewBox.width);
      var validateChartY = Math.min(y, viewBox.y + viewBox.height);
      var activeCoordinate = {
        x: layout === 'horizontal' ? activeTick.coordinate : validateChartX,
        y: layout === 'horizontal' ? validateChartY : activeTick.coordinate
      };
      var syncAction = (0,tooltipSlice/* setSyncInteraction */.E1)({
        active: action.payload.active,
        coordinate: activeCoordinate,
        dataKey: action.payload.dataKey,
        index: String(activeTick.index),
        label: action.payload.label,
        sourceViewBox: action.payload.sourceViewBox
      });
      dispatch(syncAction);
    };
    eventCenter.on(TOOLTIP_SYNC_EVENT, listener);
    return () => {
      eventCenter.off(TOOLTIP_SYNC_EVENT, listener);
    };
  }, [className, dispatch, myEventEmitter, mySyncId, syncMethod, tooltipTicks, layout, viewBox]);
}
function useBrushSyncEventsListener() {
  var mySyncId = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncId */.lZ);
  var myEventEmitter = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectEventEmitter */.pH);
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  (0,react.useEffect)(() => {
    if (mySyncId == null) {
      // This chart is not synchronised with any other chart so we don't need to listen for any events.
      return noop;
    }
    var listener = (incomingSyncId, action, emitter) => {
      if (myEventEmitter === emitter) {
        // We don't want to dispatch actions that we sent ourselves.
        return;
      }
      if (mySyncId === incomingSyncId) {
        dispatch((0,chartDataSlice/* setDataStartEndIndexes */.M)(action));
      }
    };
    eventCenter.on(BRUSH_SYNC_EVENT, listener);
    return () => {
      eventCenter.off(BRUSH_SYNC_EVENT, listener);
    };
  }, [dispatch, myEventEmitter, mySyncId]);
}

/**
 * Will receive synchronisation events from other charts.
 *
 * Reads syncMethod from state and decides how to synchronise the tooltip based on that.
 *
 * @returns void
 */
function useSynchronisedEventsFromOtherCharts() {
  var dispatch = (0,hooks/* useAppDispatch */.j)();
  (0,react.useEffect)(() => {
    dispatch((0,optionsSlice/* createEventEmitter */.dl)());
  }, [dispatch]);
  useTooltipSyncEventsListener();
  useBrushSyncEventsListener();
}

/**
 * Will send events to other charts.
 * If syncId is undefined, no events will be sent.
 *
 * This ignores the syncMethod, because that is set and computed on the receiving end.
 *
 * @param tooltipEventType from Tooltip
 * @param trigger from Tooltip
 * @param activeCoordinate from state
 * @param activeLabel from state
 * @param activeIndex from state
 * @param isTooltipActive from state
 * @returns void
 */
function useTooltipChartSynchronisation(tooltipEventType, trigger, activeCoordinate, activeLabel, activeIndex, isTooltipActive) {
  var activeDataKey = (0,hooks/* useAppSelector */.G)(state => (0,selectors/* selectTooltipDataKey */.dp)(state, tooltipEventType, trigger));
  var eventEmitterSymbol = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectEventEmitter */.pH);
  var syncId = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncId */.lZ);
  var syncMethod = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncMethod */.hX);
  var tooltipState = (0,hooks/* useAppSelector */.G)(selectSynchronisedTooltipState);
  var isReceivingSynchronisation = tooltipState === null || tooltipState === void 0 ? void 0 : tooltipState.active;
  var viewBox = (0,chartLayoutContext/* useViewBox */.sk)();
  (0,react.useEffect)(() => {
    if (isReceivingSynchronisation) {
      /*
       * This chart currently has active tooltip, synchronised from another chart.
       * Let's not send any outgoing synchronisation events while that's happening
       * to avoid infinite loops.
       */
      return;
    }
    if (syncId == null) {
      /*
       * syncId is not set, means that this chart is not synchronised with any other chart,
       * means we don't need to send synchronisation events
       */
      return;
    }
    if (eventEmitterSymbol == null) {
      /*
       * When using Recharts internal hooks and selectors outside charts context,
       * these properties will be undefined. Let's return silently instead of throwing an error.
       */
      return;
    }
    var syncAction = (0,tooltipSlice/* setSyncInteraction */.E1)({
      active: isTooltipActive,
      coordinate: activeCoordinate,
      dataKey: activeDataKey,
      index: activeIndex,
      label: typeof activeLabel === 'number' ? String(activeLabel) : activeLabel,
      sourceViewBox: viewBox
    });
    eventCenter.emit(TOOLTIP_SYNC_EVENT, syncId, syncAction, eventEmitterSymbol);
  }, [isReceivingSynchronisation, activeCoordinate, activeDataKey, activeIndex, activeLabel, eventEmitterSymbol, syncId, syncMethod, isTooltipActive, viewBox]);
}
function useBrushChartSynchronisation() {
  var syncId = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectSyncId */.lZ);
  var eventEmitterSymbol = (0,hooks/* useAppSelector */.G)(rootPropsSelectors/* selectEventEmitter */.pH);
  var brushStartIndex = (0,hooks/* useAppSelector */.G)(state => state.chartData.dataStartIndex);
  var brushEndIndex = (0,hooks/* useAppSelector */.G)(state => state.chartData.dataEndIndex);
  (0,react.useEffect)(() => {
    if (syncId == null || brushStartIndex == null || brushEndIndex == null || eventEmitterSymbol == null) {
      return;
    }
    var syncAction = {
      startIndex: brushStartIndex,
      endIndex: brushEndIndex
    };
    eventCenter.emit(BRUSH_SYNC_EVENT, syncId, syncAction, eventEmitterSymbol);
  }, [brushEndIndex, brushStartIndex, eventEmitterSymbol, syncId]);
}

/***/ }),

/***/ 66297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Wc: () => (/* binding */ selectRadialBarLegendPayload),
/* harmony export */   sq: () => (/* binding */ selectRadialBarSectors)
/* harmony export */ });
/* unused harmony exports selectRadiusAxisWithScale, selectRadiusAxisTicks, selectAngleAxisWithScale, selectBandSizeOfPolarAxis, selectBaseValue, pickMaxBarSize, selectPolarBarSizeList, selectPolarBarBandSize, selectAllPolarBarPositions, selectPolarBarPosition */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _polar_RadialBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(32351);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(98453);
/* harmony import */ var _polarScaleSelectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28871);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11114);
/* harmony import */ var _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(61270);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19287);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33964);
/* harmony import */ var _barSelectors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(76398);
/* harmony import */ var _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(82695);
/* harmony import */ var _polarSelectors__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(19033);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59744);
/* harmony import */ var _combiners_combineDisplayedStackedData__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86907);
/* harmony import */ var _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(37617);
/* harmony import */ var _types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9531);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }















var selectRadiusAxisForRadialBar = (state, radiusAxisId) => (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectRadiusAxis */ .Gl)(state, radiusAxisId);
var selectRadiusAxisScaleForRadar = (state, radiusAxisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectPolarAxisScale */ .Qr)(state, 'radiusAxis', radiusAxisId);
var selectRadiusAxisWithScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadiusAxisForRadialBar, selectRadiusAxisScaleForRadar], (axis, scale) => {
  if (axis == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axis), {}, {
    scale
  });
});
var selectRadiusAxisTicks = (state, radiusAxisId, _angleAxisId, isPanorama) => {
  return (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectPolarGraphicalItemAxisTicks */ .yQ)(state, 'radiusAxis', radiusAxisId, isPanorama);
};
var selectAngleAxisForRadialBar = (state, _radiusAxisId, angleAxisId) => (0,_polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectAngleAxis */ .Be)(state, angleAxisId);
var selectAngleAxisScaleForRadialBar = (state, _radiusAxisId, angleAxisId) => (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectPolarAxisScale */ .Qr)(state, 'angleAxis', angleAxisId);
var selectAngleAxisWithScale = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisForRadialBar, selectAngleAxisScaleForRadialBar], (axis, scale) => {
  if (axis == null || scale == null) {
    return undefined;
  }
  return _objectSpread(_objectSpread({}, axis), {}, {
    scale
  });
});
var selectAngleAxisTicks = (state, _radiusAxisId, angleAxisId, isPanorama) => {
  return (0,_polarScaleSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectPolarAxisTicks */ .YF)(state, 'angleAxis', angleAxisId, isPanorama);
};
var pickRadialBarSettings = (_state, _radiusAxisId, _angleAxisId, radialBarSettings) => radialBarSettings;
var selectSynchronisedRadialBarSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_polarSelectors__WEBPACK_IMPORTED_MODULE_10__/* .selectUnfilteredPolarItems */ .nz, pickRadialBarSettings], (graphicalItems, radialBarSettingsFromProps) => {
  if (graphicalItems.some(pgis => pgis.type === 'radialBar' && radialBarSettingsFromProps.dataKey === pgis.dataKey && radialBarSettingsFromProps.stackId === pgis.stackId)) {
    return radialBarSettingsFromProps;
  }
  return undefined;
});
var selectBandSizeOfPolarAxis = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz, selectRadiusAxisWithScale, selectRadiusAxisTicks, selectAngleAxisWithScale, selectAngleAxisTicks], (layout, radiusAxis, radiusAxisTicks, angleAxis, angleAxisTicks) => {
  if ((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .isCategoricalAxis */ ._L)(layout, 'radiusAxis')) {
    return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .getBandSizeOfAxis */ .Hj)(radiusAxis, radiusAxisTicks, false);
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .getBandSizeOfAxis */ .Hj)(angleAxis, angleAxisTicks, false);
});
var selectBaseValue = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisWithScale, selectRadiusAxisWithScale, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz], (angleAxis, radiusAxis, layout) => {
  var numericAxis = layout === 'radial' ? angleAxis : radiusAxis;
  if (numericAxis == null || numericAxis.scale == null) {
    return undefined;
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .getBaseValueOfBar */ .DW)({
    numericAxis
  });
});
var pickCells = (_state, _radiusAxisId, _angleAxisId, _radialBarSettings, cells) => cells;
var pickAngleAxisId = (_state, _radiusAxisId, angleAxisId, _radialBarSettings, _cells) => angleAxisId;
var pickRadiusAxisId = (_state, radiusAxisId, _angleAxisId, _radialBarSettings, _cells) => radiusAxisId;
var pickMaxBarSize = (_state, _radiusAxisId, _angleAxisId, radialBarSettings, _cells) => radialBarSettings.maxBarSize;
var selectAllVisibleRadialBars = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz, _polarSelectors__WEBPACK_IMPORTED_MODULE_10__/* .selectUnfilteredPolarItems */ .nz, pickAngleAxisId, pickRadiusAxisId], (layout, allItems, angleAxisId, radiusAxisId) => {
  return allItems.filter(i => {
    if (layout === 'centric') {
      return i.angleAxisId === angleAxisId;
    }
    return i.radiusAxisId === radiusAxisId;
  }).filter(i => i.hide === false).filter(i => i.type === 'radialBar');
});

/**
 * The generator never returned the totalSize which means that barSize in polar chart can not support percent values.
 * We can add that if we want to I suppose.
 * @returns undefined - but it should be a total size of numerical axis in polar chart
 */
var selectPolarBarAxisSize = () => undefined;
var selectPolarBarSizeList = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAllVisibleRadialBars, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectRootBarSize */ .x3, selectPolarBarAxisSize], _barSelectors__WEBPACK_IMPORTED_MODULE_8__/* .combineBarSizeList */ .WR);
var selectPolarBarBandSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectRootMaxBarSize */ .JN, selectAngleAxisWithScale, selectAngleAxisTicks, selectRadiusAxisWithScale, selectRadiusAxisTicks, pickMaxBarSize], (layout, globalMaxBarSize, angleAxis, angleAxisTicks, radiusAxis, radiusAxisTicks, childMaxBarSize) => {
  var _ref2, _getBandSizeOfAxis2;
  var maxBarSize = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_11__/* .isNullish */ .uy)(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
  if (layout === 'centric') {
    var _ref, _getBandSizeOfAxis;
    return (_ref = (_getBandSizeOfAxis = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .getBandSizeOfAxis */ .Hj)(angleAxis, angleAxisTicks, true)) !== null && _getBandSizeOfAxis !== void 0 ? _getBandSizeOfAxis : maxBarSize) !== null && _ref !== void 0 ? _ref : 0;
  }
  return (_ref2 = (_getBandSizeOfAxis2 = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_7__/* .getBandSizeOfAxis */ .Hj)(radiusAxis, radiusAxisTicks, true)) !== null && _getBandSizeOfAxis2 !== void 0 ? _getBandSizeOfAxis2 : maxBarSize) !== null && _ref2 !== void 0 ? _ref2 : 0;
});
var selectAllPolarBarPositions = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarBarSizeList, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectRootMaxBarSize */ .JN, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectBarGap */ ._5, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectBarCategoryGap */ .gY, selectPolarBarBandSize, selectBandSizeOfPolarAxis, pickMaxBarSize], _barSelectors__WEBPACK_IMPORTED_MODULE_8__/* .combineAllBarPositions */ .IC);
var selectPolarBarPosition = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAllPolarBarPositions, selectSynchronisedRadialBarSettings], (allBarPositions, barSettings) => {
  if (allBarPositions == null || barSettings == null) {
    return undefined;
  }
  var position = allBarPositions.find(p => p.stackId === barSettings.stackId && barSettings.dataKey != null && p.dataKeys.includes(barSettings.dataKey));
  if (position == null) {
    return undefined;
  }
  return position.position;
});
var selectStackedRadialBars = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_polarSelectors__WEBPACK_IMPORTED_MODULE_10__/* .selectPolarItemsSettings */ .m8], allPolarItems => allPolarItems.filter(item => item.type === 'radialBar').filter(_types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_14__/* .isStacked */ .g));
var selectPolarCombinedStackedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectStackedRadialBars, _dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3, _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_13__/* .selectTooltipAxis */ .D], _combiners_combineDisplayedStackedData__WEBPACK_IMPORTED_MODULE_12__/* .combineDisplayedStackedData */ .A);
var selectStackGroups = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectPolarCombinedStackedData, selectStackedRadialBars, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectStackOffsetType */ .eC], _axisSelectors__WEBPACK_IMPORTED_MODULE_4__/* .combineStackGroups */ .MK);
var selectRadialBarStackGroups = (state, radiusAxisId, angleAxisId) => {
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz)(state);
  if (layout === 'centric') {
    return selectStackGroups(state, 'radiusAxis', radiusAxisId);
  }
  return selectStackGroups(state, 'angleAxis', angleAxisId);
};
var selectPolarStackedData = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectRadialBarStackGroups, selectSynchronisedRadialBarSettings], _barSelectors__WEBPACK_IMPORTED_MODULE_8__/* .combineStackedData */ .p$);
var selectRadialBarSectors = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAngleAxisWithScale, selectAngleAxisTicks, selectRadiusAxisWithScale, selectRadiusAxisTicks, _dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataWithIndexes */ .LF, selectSynchronisedRadialBarSettings, selectBandSizeOfPolarAxis, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_6__/* .selectChartLayout */ .fz, selectBaseValue, _polarAxisSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectPolarViewBox */ .D0, pickCells, selectPolarBarPosition, selectPolarStackedData], (angleAxis, angleAxisTicks, radiusAxis, radiusAxisTicks, _ref3, radialBarSettings, bandSize, layout, baseValue, polarViewBox, cells, pos, stackedData) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref3;
  if (radialBarSettings == null || radiusAxis == null || angleAxis == null || chartData == null || bandSize == null || pos == null || layout !== 'centric' && layout !== 'radial' || radiusAxisTicks == null) {
    return [];
  }
  var {
    dataKey,
    minPointSize
  } = radialBarSettings;
  var {
    cx,
    cy,
    startAngle,
    endAngle
  } = polarViewBox;
  var displayedData = chartData.slice(dataStartIndex, dataEndIndex + 1);
  var numericAxis = layout === 'centric' ? radiusAxis : angleAxis;
  var stackedDomain = stackedData ? numericAxis.scale.domain() : null;
  return (0,_polar_RadialBar__WEBPACK_IMPORTED_MODULE_1__/* .computeRadialBarDataItems */ .s)({
    angleAxis,
    angleAxisTicks,
    bandSize,
    baseValue,
    cells,
    cx,
    cy,
    dataKey,
    dataStartIndex,
    displayedData,
    endAngle,
    layout,
    minPointSize,
    pos,
    radiusAxis,
    radiusAxisTicks,
    stackedData,
    stackedDomain,
    startAngle
  });
});
var selectRadialBarLegendPayload = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_dataSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3, (_s, l) => l], (_ref4, legendType) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref4;
  if (chartData == null) {
    return [];
  }
  var displayedData = chartData.slice(dataStartIndex, dataEndIndex + 1);
  if (displayedData.length === 0) {
    return [];
  }
  return displayedData.map(entry => {
    return {
      type: legendType,
      // @ts-expect-error we need a better typing for our data inputs
      value: entry.name,
      // @ts-expect-error we need a better typing for our data inputs
      color: entry.fill,
      payload: entry
    };
  });
});

/***/ }),

/***/ 66561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ selectFunnelTrapezoids)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _cartesian_Funnel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34429);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36189);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(98453);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }




var pickFunnelSettings = (_state, funnelSettings) => funnelSettings;
var selectFunnelTrapezoids = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_2__/* .selectChartOffsetInternal */ .HZ, pickFunnelSettings, _dataSelectors__WEBPACK_IMPORTED_MODULE_3__/* .selectChartDataAndAlwaysIgnoreIndexes */ .z3], (offset, _ref, _ref2) => {
  var {
    data,
    dataKey,
    nameKey,
    tooltipType,
    lastShapeType,
    reversed,
    customWidth,
    cells,
    presentationProps
  } = _ref;
  var {
    chartData
  } = _ref2;
  var displayedData;
  if (data != null && data.length > 0) {
    displayedData = data;
  } else if (chartData != null && chartData.length > 0) {
    displayedData = chartData;
  }
  if (displayedData && displayedData.length) {
    displayedData = displayedData.map((entry, index) => _objectSpread(_objectSpread(_objectSpread({
      payload: entry
    }, presentationProps), entry), cells && cells[index] && cells[index].props));
  } else if (cells && cells.length) {
    displayedData = cells.map(cell => _objectSpread(_objectSpread({}, presentationProps), cell.props));
  } else {
    return [];
  }
  return (0,_cartesian_Funnel__WEBPACK_IMPORTED_MODULE_1__/* .computeFunnelTrapezoids */ .lf)({
    dataKey,
    nameKey,
    displayedData,
    tooltipType,
    lastShapeType,
    reversed,
    offset,
    customWidth
  });
});

/***/ }),

/***/ 68861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ selectAllYAxes),
/* harmony export */   h: () => (/* binding */ selectAllXAxes)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);

var selectAllXAxes = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(state => state.cartesianAxis.xAxis, xAxisMap => {
  return Object.values(xAxisMap);
});
var selectAllYAxes = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(state => state.cartesianAxis.yAxis, yAxisMap => {
  return Object.values(yAxisMap);
});

/***/ }),

/***/ 69767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ minPointSizeCallback),
/* harmony export */   z: () => (/* binding */ BarRectangle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var tiny_invariant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11561);
/* harmony import */ var _ActiveShapeUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(80489);
/* harmony import */ var _DataUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59744);
var _excluded = ["x", "y"];
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }





// Rectangle props is expecting x, y, height, width as numbers, name as a string, and radius as a custom type
// When props are being spread in from a user defined component in Bar,
// the prop types of an SVGElement have these typed as something else.
// This function will return the passed in props
// along with x, y, height as numbers, name as a string, and radius as number | [number, number, number, number]
function typeguardBarRectangleProps(_ref, props) {
  var {
      x: xProp,
      y: yProp
    } = _ref,
    option = _objectWithoutProperties(_ref, _excluded);
  var xValue = "".concat(xProp);
  var x = parseInt(xValue, 10);
  var yValue = "".concat(yProp);
  var y = parseInt(yValue, 10);
  var heightValue = "".concat(props.height || option.height);
  var height = parseInt(heightValue, 10);
  var widthValue = "".concat(props.width || option.width);
  var width = parseInt(widthValue, 10);
  return _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, props), option), x ? {
    x
  } : {}), y ? {
    y
  } : {}), {}, {
    height,
    width,
    name: props.name,
    radius: props.radius
  });
}
function BarRectangle(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ActiveShapeUtils__WEBPACK_IMPORTED_MODULE_2__/* .Shape */ .y, _extends({
    shapeType: "rectangle",
    propTransformer: typeguardBarRectangleProps,
    activeClassName: "recharts-active-bar"
  }, props));
}
/**
 * Safely gets minPointSize from the minPointSize prop if it is a function
 * @param minPointSize minPointSize as passed to the Bar component
 * @param defaultValue default minPointSize
 * @returns minPointSize
 */
var minPointSizeCallback = function minPointSizeCallback(minPointSize) {
  var defaultValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  return (value, index) => {
    if ((0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(minPointSize)) return minPointSize;
    var isValueNumberOrNil = (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(value) || (0,_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNullish */ .uy)(value);
    if (isValueNumberOrNil) {
      return minPointSize(value, index);
    }
    !isValueNumberOrNil ?  true ? (0,tiny_invariant__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(false, "minPointSize callback function received a value with type of ".concat(typeof value, ". Currently only numbers or null/undefined are supported.")) : 0 : void 0;
    return defaultValue;
  };
};

/***/ }),

/***/ 70475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ selectChartOffset)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36189);


var selectChartOffset = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_1__/* .selectChartOffsetInternal */ .HZ], offsetInternal => {
  if (!offsetInternal) {
    return undefined;
  }
  return {
    top: offsetInternal.top,
    bottom: offsetInternal.bottom,
    left: offsetInternal.left,
    right: offsetInternal.right
  };
});

/***/ }),

/***/ 74531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E1: () => (/* binding */ setSyncInteraction),
/* harmony export */   En: () => (/* binding */ tooltipReducer),
/* harmony export */   Ix: () => (/* binding */ addTooltipEntrySettings),
/* harmony export */   ML: () => (/* binding */ setActiveClickItemIndex),
/* harmony export */   Nt: () => (/* binding */ setMouseOverAxisIndex),
/* harmony export */   RD: () => (/* binding */ setActiveMouseOverItemIndex),
/* harmony export */   UF: () => (/* binding */ setTooltipSettingsState),
/* harmony export */   XB: () => (/* binding */ removeTooltipEntrySettings),
/* harmony export */   jF: () => (/* binding */ setMouseClickAxisIndex),
/* harmony export */   k_: () => (/* binding */ noInteraction),
/* harmony export */   o4: () => (/* binding */ setKeyboardInteraction),
/* harmony export */   oP: () => (/* binding */ mouseLeaveItem),
/* harmony export */   xS: () => (/* binding */ mouseLeaveChart)
/* harmony export */ });
/* unused harmony export initialState */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1932);



/**
 * One Tooltip can display multiple TooltipPayloadEntries at a time.
 */

/**
 * So what happens is that the tooltip payload is decided based on the available data, and the dataKey.
 * The dataKey can either be defined on the graphical element (like Line, or Bar)
 * or on the tooltip itself.
 *
 * The data can be defined in the chart element, or in the graphical item.
 *
 * So this type is all the settings, other than the data + dataKey complications.
 */

/**
 * This is what Tooltip renders.
 */

/**
 * null means no active index
 * string means: whichever index from the chart data it is.
 * Different charts have different requirements on data shapes,
 * and are also responsible for providing a function that will accept this index
 * and return data.
 */

/**
 * Different items have different data shapes so the state has no opinion on what the data shape should be;
 * the only requirement is that the chart also provides a searcher function
 * that accepts the data, and a key, and returns whatever the payload in Tooltip should be.
 */

/**
 * So this informs the "tooltip event type". Tooltip event type can be either "axis" or "item"
 * and it is used for two things:
 * 1. Sets the active area
 * 2. Sets the background and cursor highlights
 *
 * Some charts only allow to have one type of tooltip event type, some allow both.
 * Those charts that allow both will have one default, and the "shared" prop will be used to switch between them.
 * Undefined means "use the chart default".
 *
 * Charts that only allow one tooltip event type, will ignore the shared prop.
 */

/**
 * A generic state for user interaction with the chart.
 * User interaction can come through multiple channels: mouse events, keyboard events, or hardcoded in props, or synchronised from other charts.
 *
 * Each of the interaction states is represented as TooltipInteractionState,
 * and then the selectors and Tooltip will decide which of the interaction states to use.
 */

var noInteraction = {
  active: false,
  index: null,
  dataKey: undefined,
  coordinate: undefined
};

/**
 * The tooltip interaction state stores:
 *
 * - Which graphical item is user interacting with at the moment,
 * - which axis (or, which part of chart background) is user interacting with at the moment
 * - The data that individual graphical items wish to be displayed in case the tooltip gets activated
 */

var initialState = {
  itemInteraction: {
    click: noInteraction,
    hover: noInteraction
  },
  axisInteraction: {
    click: noInteraction,
    hover: noInteraction
  },
  keyboardInteraction: noInteraction,
  syncInteraction: {
    active: false,
    index: null,
    dataKey: undefined,
    label: undefined,
    coordinate: undefined,
    sourceViewBox: undefined
  },
  tooltipItemPayloads: [],
  settings: {
    shared: undefined,
    trigger: 'hover',
    axisId: 0,
    active: false,
    defaultIndex: undefined
  }
};
var tooltipSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'tooltip',
  initialState,
  reducers: {
    addTooltipEntrySettings: {
      reducer(state, action) {
        state.tooltipItemPayloads.push((0,immer__WEBPACK_IMPORTED_MODULE_1__/* .castDraft */ .h4)(action.payload));
      },
      prepare: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .prepareAutoBatched */ .aA)()
    },
    removeTooltipEntrySettings: {
      reducer(state, action) {
        var index = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .current */ .ss)(state).tooltipItemPayloads.indexOf((0,immer__WEBPACK_IMPORTED_MODULE_1__/* .castDraft */ .h4)(action.payload));
        if (index > -1) {
          state.tooltipItemPayloads.splice(index, 1);
        }
      },
      prepare: (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .prepareAutoBatched */ .aA)()
    },
    setTooltipSettingsState(state, action) {
      state.settings = action.payload;
    },
    setActiveMouseOverItemIndex(state, action) {
      state.syncInteraction.active = false;
      state.keyboardInteraction.active = false;
      state.itemInteraction.hover.active = true;
      state.itemInteraction.hover.index = action.payload.activeIndex;
      state.itemInteraction.hover.dataKey = action.payload.activeDataKey;
      state.itemInteraction.hover.coordinate = action.payload.activeCoordinate;
    },
    mouseLeaveChart(state) {
      /*
       * Clear only the active flags. Why?
       * 1. Keep Coordinate to preserve animation - next time the Tooltip appears, we want to render it from
       * the last place where it was when it disappeared.
       * 2. We want to keep all the properties anyway just in case the tooltip has `active=true` prop
       * and continues being visible even after the mouse has left the chart.
       */
      state.itemInteraction.hover.active = false;
      state.axisInteraction.hover.active = false;
    },
    mouseLeaveItem(state) {
      state.itemInteraction.hover.active = false;
    },
    setActiveClickItemIndex(state, action) {
      state.syncInteraction.active = false;
      state.itemInteraction.click.active = true;
      state.keyboardInteraction.active = false;
      state.itemInteraction.click.index = action.payload.activeIndex;
      state.itemInteraction.click.dataKey = action.payload.activeDataKey;
      state.itemInteraction.click.coordinate = action.payload.activeCoordinate;
    },
    setMouseOverAxisIndex(state, action) {
      state.syncInteraction.active = false;
      state.axisInteraction.hover.active = true;
      state.keyboardInteraction.active = false;
      state.axisInteraction.hover.index = action.payload.activeIndex;
      state.axisInteraction.hover.dataKey = action.payload.activeDataKey;
      state.axisInteraction.hover.coordinate = action.payload.activeCoordinate;
    },
    setMouseClickAxisIndex(state, action) {
      state.syncInteraction.active = false;
      state.keyboardInteraction.active = false;
      state.axisInteraction.click.active = true;
      state.axisInteraction.click.index = action.payload.activeIndex;
      state.axisInteraction.click.dataKey = action.payload.activeDataKey;
      state.axisInteraction.click.coordinate = action.payload.activeCoordinate;
    },
    setSyncInteraction(state, action) {
      state.syncInteraction = action.payload;
    },
    setKeyboardInteraction(state, action) {
      state.keyboardInteraction.active = action.payload.active;
      state.keyboardInteraction.index = action.payload.activeIndex;
      state.keyboardInteraction.coordinate = action.payload.activeCoordinate;
      state.keyboardInteraction.dataKey = action.payload.activeDataKey;
    }
  }
});
var {
  addTooltipEntrySettings,
  removeTooltipEntrySettings,
  setTooltipSettingsState,
  setActiveMouseOverItemIndex,
  mouseLeaveItem,
  mouseLeaveChart,
  setActiveClickItemIndex,
  setMouseOverAxisIndex,
  setMouseClickAxisIndex,
  setSyncInteraction,
  setKeyboardInteraction
} = tooltipSlice.actions;
var tooltipReducer = tooltipSlice.reducer;

/***/ }),

/***/ 74544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ combineActiveTooltipIndex)
/* harmony export */ });
/* harmony import */ var _util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8813);

var combineActiveTooltipIndex = (tooltipInteraction, chartData) => {
  var desiredIndex = tooltipInteraction === null || tooltipInteraction === void 0 ? void 0 : tooltipInteraction.index;
  if (desiredIndex == null) {
    return null;
  }
  var indexAsNumber = Number(desiredIndex);
  if (!(0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_0__/* .isWellBehavedNumber */ .H)(indexAsNumber)) {
    // this is for charts like Sankey and Treemap that do not support numerical indexes. We need a proper solution for this before we can start supporting keyboard events on these charts.
    return desiredIndex;
  }

  /*
   * Zero is a trivial limit for single-dimensional charts like Line and Area,
   * but this also needs a support for multidimensional charts like Sankey and Treemap! TODO
   */
  var lowerLimit = 0;
  var upperLimit = +Infinity;
  if (chartData.length > 0) {
    upperLimit = chartData.length - 1;
  }

  // now let's clamp the desiredIndex between the limits
  return String(Math.max(lowerLimit, Math.min(indexAsNumber, upperLimit)));
};

/***/ }),

/***/ 75403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ combineActiveLabel)
/* harmony export */ });
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59744);

var combineActiveLabel = (tooltipTicks, activeIndex) => {
  var _tooltipTicks$n;
  var n = Number(activeIndex);
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_0__/* .isNan */ .M8)(n) || activeIndex == null) {
    return undefined;
  }
  return n >= 0 ? tooltipTicks === null || tooltipTicks === void 0 || (_tooltipTicks$n = tooltipTicks[n]) === null || _tooltipTicks$n === void 0 ? void 0 : _tooltipTicks$n.value : undefined;
};

/***/ }),

/***/ 76398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IC: () => (/* binding */ combineAllBarPositions),
/* harmony export */   OS: () => (/* binding */ selectBarRectangles),
/* harmony export */   WR: () => (/* binding */ combineBarSizeList),
/* harmony export */   p$: () => (/* binding */ combineStackedData)
/* harmony export */ });
/* unused harmony exports selectMaxBarSize, selectAllVisibleBars, selectBarCartesianAxisSize, selectBarSizeList, selectBarBandSize, selectAxisBandSize, selectAllBarPositions, selectBarPosition */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _axisSelectors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11114);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59744);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(33964);
/* harmony import */ var _cartesian_Bar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15344);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19287);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(98453);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(36189);
/* harmony import */ var _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(82695);
/* harmony import */ var _util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8813);
/* harmony import */ var _util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(72925);
/* harmony import */ var _types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9531);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }












var pickXAxisId = (_state, xAxisId) => xAxisId;
var pickYAxisId = (_state, _xAxisId, yAxisId) => yAxisId;
var pickIsPanorama = (_state, _xAxisId, _yAxisId, isPanorama) => isPanorama;
var pickBarId = (_state, _xAxisId, _yAxisId, _isPanorama, id) => id;
var selectSynchronisedBarSettings = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectUnfilteredCartesianItems */ .ld, pickBarId], (graphicalItems, id) => graphicalItems.filter(item => item.type === 'bar').find(item => item.id === id));
var selectMaxBarSize = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectSynchronisedBarSettings], barSettings => barSettings === null || barSettings === void 0 ? void 0 : barSettings.maxBarSize);
var pickCells = (_state, _xAxisId, _yAxisId, _isPanorama, _id, cells) => cells;
var getBarSize = (globalSize, totalSize, selfSize) => {
  var barSize = selfSize !== null && selfSize !== void 0 ? selfSize : globalSize;
  if ((0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNullish */ .uy)(barSize)) {
    return undefined;
  }
  return (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .getPercentValue */ .F4)(barSize, totalSize, 0);
};
var selectAllVisibleBars = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz, _axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectUnfilteredCartesianItems */ .ld, pickXAxisId, pickYAxisId, pickIsPanorama], (layout, allItems, xAxisId, yAxisId, isPanorama) => allItems.filter(i => {
  if (layout === 'horizontal') {
    return i.xAxisId === xAxisId;
  }
  return i.yAxisId === yAxisId;
}).filter(i => i.isPanorama === isPanorama).filter(i => i.hide === false).filter(i => i.type === 'bar'));
var selectBarStackGroups = (state, xAxisId, yAxisId, isPanorama) => {
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz)(state);
  if (layout === 'horizontal') {
    return (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectStackGroups */ .TC)(state, 'yAxis', yAxisId, isPanorama);
  }
  return (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectStackGroups */ .TC)(state, 'xAxis', xAxisId, isPanorama);
};
var selectBarCartesianAxisSize = (state, xAxisId, yAxisId) => {
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz)(state);
  if (layout === 'horizontal') {
    return (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectCartesianAxisSize */ .BQ)(state, 'xAxis', xAxisId);
  }
  return (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectCartesianAxisSize */ .BQ)(state, 'yAxis', yAxisId);
};
var combineBarSizeList = (allBars, globalSize, totalSize) => {
  var initialValue = {};
  var stackedBars = allBars.filter(_types_StackedGraphicalItem__WEBPACK_IMPORTED_MODULE_11__/* .isStacked */ .g);
  var unstackedBars = allBars.filter(b => b.stackId == null);
  var groupByStack = stackedBars.reduce((acc, bar) => {
    if (!acc[bar.stackId]) {
      acc[bar.stackId] = [];
    }
    acc[bar.stackId].push(bar);
    return acc;
  }, initialValue);
  var stackedSizeList = Object.entries(groupByStack).map(_ref => {
    var [stackId, bars] = _ref;
    var dataKeys = bars.map(b => b.dataKey);
    var barSize = getBarSize(globalSize, totalSize, bars[0].barSize);
    return {
      stackId,
      dataKeys,
      barSize
    };
  });
  var unstackedSizeList = unstackedBars.map(b => {
    var dataKeys = [b.dataKey].filter(dk => dk != null);
    var barSize = getBarSize(globalSize, totalSize, b.barSize);
    return {
      stackId: undefined,
      dataKeys,
      barSize
    };
  });
  return [...stackedSizeList, ...unstackedSizeList];
};
var selectBarSizeList = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAllVisibleBars, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__/* .selectRootBarSize */ .x3, selectBarCartesianAxisSize], combineBarSizeList);
var selectBarBandSize = (state, xAxisId, yAxisId, isPanorama, id) => {
  var _ref2, _getBandSizeOfAxis;
  var barSettings = selectSynchronisedBarSettings(state, xAxisId, yAxisId, isPanorama, id);
  if (barSettings == null) {
    return undefined;
  }
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz)(state);
  var globalMaxBarSize = (0,_rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__/* .selectRootMaxBarSize */ .JN)(state);
  var {
    maxBarSize: childMaxBarSize
  } = barSettings;
  var maxBarSize = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNullish */ .uy)(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
  var axis, ticks;
  if (layout === 'horizontal') {
    axis = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
    ticks = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
  } else {
    axis = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
    ticks = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
  }
  return (_ref2 = (_getBandSizeOfAxis = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .getBandSizeOfAxis */ .Hj)(axis, ticks, true)) !== null && _getBandSizeOfAxis !== void 0 ? _getBandSizeOfAxis : maxBarSize) !== null && _ref2 !== void 0 ? _ref2 : 0;
};
var selectAxisBandSize = (state, xAxisId, yAxisId, isPanorama) => {
  var layout = (0,_context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz)(state);
  var axis, ticks;
  if (layout === 'horizontal') {
    axis = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
    ticks = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
  } else {
    axis = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
    ticks = (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
  }
  return (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .getBandSizeOfAxis */ .Hj)(axis, ticks);
};
function getBarPositions(barGap, barCategoryGap, bandSize, sizeList, maxBarSize) {
  var len = sizeList.length;
  if (len < 1) {
    return undefined;
  }
  var realBarGap = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .getPercentValue */ .F4)(barGap, bandSize, 0, true);
  var result;
  var initialValue = [];

  // whether is barSize set by user
  // Okay but why does it check only for the first element? What if the first element is set but others are not?
  if ((0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(sizeList[0].barSize)) {
    var useFull = false;
    var fullBarSize = bandSize / len;
    var sum = sizeList.reduce((res, entry) => res + (entry.barSize || 0), 0);
    sum += (len - 1) * realBarGap;
    if (sum >= bandSize) {
      sum -= (len - 1) * realBarGap;
      realBarGap = 0;
    }
    if (sum >= bandSize && fullBarSize > 0) {
      useFull = true;
      fullBarSize *= 0.9;
      sum = len * fullBarSize;
    }
    var offset = (bandSize - sum) / 2 >> 0;
    var prev = {
      offset: offset - realBarGap,
      size: 0
    };
    result = sizeList.reduce((res, entry) => {
      var _entry$barSize;
      var newPosition = {
        stackId: entry.stackId,
        dataKeys: entry.dataKeys,
        position: {
          offset: prev.offset + prev.size + realBarGap,
          size: useFull ? fullBarSize : (_entry$barSize = entry.barSize) !== null && _entry$barSize !== void 0 ? _entry$barSize : 0
        }
      };
      var newRes = [...res, newPosition];
      prev = newRes[newRes.length - 1].position;
      return newRes;
    }, initialValue);
  } else {
    var _offset = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .getPercentValue */ .F4)(barCategoryGap, bandSize, 0, true);
    if (bandSize - 2 * _offset - (len - 1) * realBarGap <= 0) {
      realBarGap = 0;
    }
    var originalSize = (bandSize - 2 * _offset - (len - 1) * realBarGap) / len;
    if (originalSize > 1) {
      originalSize >>= 0;
    }
    var size = (0,_util_isWellBehavedNumber__WEBPACK_IMPORTED_MODULE_9__/* .isWellBehavedNumber */ .H)(maxBarSize) ? Math.min(originalSize, maxBarSize) : originalSize;
    result = sizeList.reduce((res, entry, i) => [...res, {
      stackId: entry.stackId,
      dataKeys: entry.dataKeys,
      position: {
        offset: _offset + (originalSize + realBarGap) * i + (originalSize - size) / 2,
        size
      }
    }], initialValue);
  }
  return result;
}
var combineAllBarPositions = (sizeList, globalMaxBarSize, barGap, barCategoryGap, barBandSize, bandSize, childMaxBarSize) => {
  var maxBarSize = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_2__/* .isNullish */ .uy)(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
  var allBarPositions = getBarPositions(barGap, barCategoryGap, barBandSize !== bandSize ? barBandSize : bandSize, sizeList, maxBarSize);
  if (barBandSize !== bandSize && allBarPositions != null) {
    allBarPositions = allBarPositions.map(pos => _objectSpread(_objectSpread({}, pos), {}, {
      position: _objectSpread(_objectSpread({}, pos.position), {}, {
        offset: pos.position.offset - barBandSize / 2
      })
    }));
  }
  return allBarPositions;
};
var selectAllBarPositions = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBarSizeList, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__/* .selectRootMaxBarSize */ .JN, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__/* .selectBarGap */ ._5, _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_8__/* .selectBarCategoryGap */ .gY, selectBarBandSize, selectAxisBandSize, selectMaxBarSize], combineAllBarPositions);
var selectXAxisWithScale = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'xAxis', xAxisId, isPanorama);
var selectYAxisWithScale = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectAxisWithScale */ .Gx)(state, 'yAxis', yAxisId, isPanorama);
var selectXAxisTicks = (state, xAxisId, _yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'xAxis', xAxisId, isPanorama);
var selectYAxisTicks = (state, _xAxisId, yAxisId, isPanorama) => (0,_axisSelectors__WEBPACK_IMPORTED_MODULE_1__/* .selectTicksOfGraphicalItem */ .CR)(state, 'yAxis', yAxisId, isPanorama);
var selectBarPosition = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectAllBarPositions, selectSynchronisedBarSettings], (allBarPositions, barSettings) => {
  if (allBarPositions == null || barSettings == null) {
    return undefined;
  }
  var position = allBarPositions.find(p => p.stackId === barSettings.stackId && barSettings.dataKey != null && p.dataKeys.includes(barSettings.dataKey));
  if (position == null) {
    return undefined;
  }
  return position.position;
});
var combineStackedData = (stackGroups, barSettings) => {
  var stackSeriesIdentifier = (0,_util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_10__/* .getStackSeriesIdentifier */ .x)(barSettings);
  if (!stackGroups || stackSeriesIdentifier == null || barSettings == null) {
    return undefined;
  }
  var {
    stackId
  } = barSettings;
  if (stackId == null) {
    return undefined;
  }
  var stackGroup = stackGroups[stackId];
  if (!stackGroup) {
    return undefined;
  }
  var {
    stackedData
  } = stackGroup;
  if (!stackedData) {
    return undefined;
  }
  return stackedData.find(sd => sd.key === stackSeriesIdentifier);
};
var selectStackedDataOfItem = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBarStackGroups, selectSynchronisedBarSettings], combineStackedData);
var selectBarRectangles = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_7__/* .selectChartOffsetInternal */ .HZ, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_7__/* .selectAxisViewBox */ .c2, selectXAxisWithScale, selectYAxisWithScale, selectXAxisTicks, selectYAxisTicks, selectBarPosition, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .selectChartLayout */ .fz, _dataSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectChartDataWithIndexesIfNotInPanorama */ .HS, selectAxisBandSize, selectStackedDataOfItem, selectSynchronisedBarSettings, pickCells], (offset, axisViewBox, xAxis, yAxis, xAxisTicks, yAxisTicks, pos, layout, _ref3, bandSize, stackedData, barSettings, cells) => {
  var {
    chartData,
    dataStartIndex,
    dataEndIndex
  } = _ref3;
  if (barSettings == null || pos == null || axisViewBox == null || layout !== 'horizontal' && layout !== 'vertical' || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || bandSize == null) {
    return undefined;
  }
  var {
    data
  } = barSettings;
  var displayedData;
  if (data != null && data.length > 0) {
    displayedData = data;
  } else {
    displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
  }
  if (displayedData == null) {
    return undefined;
  }
  return (0,_cartesian_Bar__WEBPACK_IMPORTED_MODULE_4__/* .computeBarRectangles */ .L)({
    layout,
    barSettings,
    pos,
    parentViewBox: axisViewBox,
    bandSize,
    xAxis,
    yAxis,
    xAxisTicks,
    yAxisTicks,
    stackedData,
    displayedData,
    offset,
    cells
  });
});

/***/ }),

/***/ 76461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ selectBrushSettings),
/* harmony export */   U: () => (/* binding */ selectBrushDimensions)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36189);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5180);
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59744);




var selectBrushSettings = state => state.brush;
var selectBrushDimensions = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectBrushSettings, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_1__/* .selectChartOffsetInternal */ .HZ, _containerSelectors__WEBPACK_IMPORTED_MODULE_2__/* .selectMargin */ .HK], (brushSettings, offset, margin) => ({
  height: brushSettings.height,
  x: (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(brushSettings.x) ? brushSettings.x : offset.left,
  y: (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(brushSettings.y) ? brushSettings.y : offset.top + offset.height + offset.brushBottom - ((margin === null || margin === void 0 ? void 0 : margin.bottom) || 0),
  width: (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_3__/* .isNumber */ .Et)(brushSettings.width) ? brushSettings.width : offset.width
}));

/***/ }),

/***/ 79926:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ pickAxisId)
/* harmony export */ });
var pickAxisId = (_state, _axisType, axisId) => axisId;

/***/ }),

/***/ 80489:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ getPropsFromShapeOption),
/* harmony export */   y: () => (/* binding */ Shape)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var es_toolkit_compat_isPlainObject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92938);
/* harmony import */ var es_toolkit_compat_isPlainObject__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_isPlainObject__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _shape_Rectangle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34723);
/* harmony import */ var _shape_Trapezoid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(88982);
/* harmony import */ var _shape_Sector__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58522);
/* harmony import */ var _container_Layer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86069);
/* harmony import */ var _shape_Symbols__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65787);
var _excluded = ["option", "shapeType", "propTransformer", "activeClassName", "isActive"];
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }









/**
 * This is an abstraction for rendering a user defined prop for a customized shape in several forms.
 *
 * <Shape /> is the root and will handle taking in:
 *  - an object of svg properties
 *  - a boolean
 *  - a render prop(inline function that returns jsx)
 *  - a React element
 *
 * <ShapeSelector /> is a subcomponent of <Shape /> and used to match a component
 * to the value of props.shapeType that is passed to the root.
 *
 */

function defaultPropTransformer(option, props) {
  return _objectSpread(_objectSpread({}, props), option);
}
function isSymbolsProps(shapeType, _elementProps) {
  return shapeType === 'symbols';
}
function ShapeSelector(_ref) {
  var {
    shapeType,
    elementProps
  } = _ref;
  switch (shapeType) {
    case 'rectangle':
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Rectangle__WEBPACK_IMPORTED_MODULE_2__/* .Rectangle */ .M, elementProps);
    case 'trapezoid':
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Trapezoid__WEBPACK_IMPORTED_MODULE_3__/* .Trapezoid */ .j, elementProps);
    case 'sector':
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Sector__WEBPACK_IMPORTED_MODULE_4__/* .Sector */ .h, elementProps);
    case 'symbols':
      if (isSymbolsProps(shapeType, elementProps)) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_shape_Symbols__WEBPACK_IMPORTED_MODULE_6__/* .Symbols */ .i, elementProps);
      }
      break;
    default:
      return null;
  }
}
function getPropsFromShapeOption(option) {
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(option)) {
    return option.props;
  }
  return option;
}
function Shape(_ref2) {
  var {
      option,
      shapeType,
      propTransformer = defaultPropTransformer,
      activeClassName = 'recharts-active-shape',
      isActive
    } = _ref2,
    props = _objectWithoutProperties(_ref2, _excluded);
  var shape;
  if (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(option)) {
    shape = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(option, _objectSpread(_objectSpread({}, props), getPropsFromShapeOption(option)));
  } else if (typeof option === 'function') {
    shape = option(props);
  } else if (es_toolkit_compat_isPlainObject__WEBPACK_IMPORTED_MODULE_1___default()(option) && typeof option !== 'boolean') {
    var nextProps = propTransformer(option, props);
    shape = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(ShapeSelector, {
      shapeType: shapeType,
      elementProps: nextProps
    });
  } else {
    var elementProps = props;
    shape = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(ShapeSelector, {
      shapeType: shapeType,
      elementProps: elementProps
    });
  }
  if (isActive) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_container_Layer__WEBPACK_IMPORTED_MODULE_5__/* .Layer */ .W, {
      className: activeClassName
    }, shape);
  }
  return shape;
}

/***/ }),

/***/ 81636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Pu: () => (/* binding */ getStringSize)
/* harmony export */ });
/* unused harmony exports configureTextMeasurement, getTextMeasurementConfig, clearStringCache, getStringCacheStats */
/* harmony import */ var _Global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59938);
/* harmony import */ var _LRUCache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(47767);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var defaultConfig = {
  cacheSize: 2000,
  enableCache: true
};
var currentConfig = _objectSpread({}, defaultConfig);
var stringCache = new _LRUCache__WEBPACK_IMPORTED_MODULE_1__/* .LRUCache */ .q(currentConfig.cacheSize);
var SPAN_STYLE = {
  position: 'absolute',
  top: '-20000px',
  left: 0,
  padding: 0,
  margin: 0,
  border: 'none',
  whiteSpace: 'pre'
};
var MEASUREMENT_SPAN_ID = 'recharts_measurement_span';
function createCacheKey(text, style) {
  // Simple string concatenation for better performance than JSON.stringify
  var fontSize = style.fontSize || '';
  var fontFamily = style.fontFamily || '';
  var fontWeight = style.fontWeight || '';
  var fontStyle = style.fontStyle || '';
  var letterSpacing = style.letterSpacing || '';
  var textTransform = style.textTransform || '';
  return "".concat(text, "|").concat(fontSize, "|").concat(fontFamily, "|").concat(fontWeight, "|").concat(fontStyle, "|").concat(letterSpacing, "|").concat(textTransform);
}

/**
 * Measure text using DOM (accurate but slower)
 * @param text - The text to measure
 * @param style - CSS style properties to apply
 * @returns The size of the text
 */
var measureTextWithDOM = (text, style) => {
  try {
    var measurementSpan = document.getElementById(MEASUREMENT_SPAN_ID);
    if (!measurementSpan) {
      measurementSpan = document.createElement('span');
      measurementSpan.setAttribute('id', MEASUREMENT_SPAN_ID);
      measurementSpan.setAttribute('aria-hidden', 'true');
      document.body.appendChild(measurementSpan);
    }

    // Apply styles directly without unnecessary object creation
    Object.assign(measurementSpan.style, SPAN_STYLE, style);
    measurementSpan.textContent = "".concat(text);
    var rect = measurementSpan.getBoundingClientRect();
    return {
      width: rect.width,
      height: rect.height
    };
  } catch (_unused) {
    return {
      width: 0,
      height: 0
    };
  }
};
var getStringSize = function getStringSize(text) {
  var style = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (text === undefined || text === null || _Global__WEBPACK_IMPORTED_MODULE_0__/* .Global */ .m.isSsr) {
    return {
      width: 0,
      height: 0
    };
  }

  // If caching is disabled, measure directly
  if (!currentConfig.enableCache) {
    return measureTextWithDOM(text, style);
  }
  var cacheKey = createCacheKey(text, style);
  var cachedResult = stringCache.get(cacheKey);
  if (cachedResult) {
    return cachedResult;
  }

  // Measure using DOM
  var result = measureTextWithDOM(text, style);

  // Store in LRU cache
  stringCache.set(cacheKey, result);
  return result;
};

/**
 * Configure text measurement behavior
 * @param config - Partial configuration to apply
 * @returns void
 */
var configureTextMeasurement = config => {
  var newConfig = _objectSpread(_objectSpread({}, currentConfig), config);
  if (newConfig.cacheSize !== currentConfig.cacheSize) {
    stringCache = new LRUCache(newConfig.cacheSize);
  }
  currentConfig = newConfig;
};

/**
 * Get current text measurement configuration
 * @returns Current configuration
 */
var getTextMeasurementConfig = () => _objectSpread({}, currentConfig);

/**
 * Clear the string size cache. Useful for testing or memory management.
 * @returns void
 */
var clearStringCache = () => {
  stringCache.clear();
};

/**
 * Get cache statistics for debugging purposes.
 * @returns Cache statistics including size and max size
 */
var getStringCacheStats = () => ({
  size: stringCache.size(),
  maxSize: currentConfig.cacheSize
});

/***/ }),

/***/ 82695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JN: () => (/* binding */ selectRootMaxBarSize),
/* harmony export */   _5: () => (/* binding */ selectBarGap),
/* harmony export */   eC: () => (/* binding */ selectStackOffsetType),
/* harmony export */   gY: () => (/* binding */ selectBarCategoryGap),
/* harmony export */   hX: () => (/* binding */ selectSyncMethod),
/* harmony export */   iO: () => (/* binding */ selectChartName),
/* harmony export */   lZ: () => (/* binding */ selectSyncId),
/* harmony export */   pH: () => (/* binding */ selectEventEmitter),
/* harmony export */   x3: () => (/* binding */ selectRootBarSize)
/* harmony export */ });
var selectRootMaxBarSize = state => state.rootProps.maxBarSize;
var selectBarGap = state => state.rootProps.barGap;
var selectBarCategoryGap = state => state.rootProps.barCategoryGap;
var selectRootBarSize = state => state.rootProps.barSize;
var selectStackOffsetType = state => state.rootProps.stackOffset;
var selectChartName = state => state.options.chartName;
var selectSyncId = state => state.rootProps.syncId;
var selectSyncMethod = state => state.rootProps.syncMethod;
var selectEventEmitter = state => state.options.eventEmitter;

/***/ }),

/***/ 86680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ selectTooltipAxisId)
/* harmony export */ });
var selectTooltipAxisId = state => state.tooltip.settings.axisId;

/***/ }),

/***/ 86907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ combineDisplayedStackedData)
/* harmony export */ });
/* harmony import */ var _util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72925);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33964);



/**
 * In a stacked chart, each graphical item has its own data. That data could be either:
 * - defined on the chart root, in which case the item gets a unique dataKey
 * - or defined on the item itself, in which case multiple items can share the same dataKey
 *
 * That means we cannot use the dataKey as a unique identifier for the item.
 *
 * This type represents a single data point in a stacked chart, where each key is a series identifier
 * and the value is the numeric value for that series using the numerical axis dataKey.
 */

function combineDisplayedStackedData(stackedGraphicalItems, _ref, tooltipAxisSettings) {
  var {
    chartData = []
  } = _ref;
  var {
    allowDuplicatedCategory,
    dataKey: tooltipDataKey
  } = tooltipAxisSettings;

  // A map of tooltip data keys to the stacked data points
  var knownItemsByDataKey = new Map();
  stackedGraphicalItems.forEach(item => {
    var _item$data;
    // If there is no data on the individual item then we use the root chart data
    var resolvedData = (_item$data = item.data) !== null && _item$data !== void 0 ? _item$data : chartData;
    if (resolvedData == null || resolvedData.length === 0) {
      // if that didn't work then we skip this item
      return;
    }
    var stackIdentifier = (0,_util_stacks_getStackSeriesIdentifier__WEBPACK_IMPORTED_MODULE_0__/* .getStackSeriesIdentifier */ .x)(item);
    resolvedData.forEach((entry, index) => {
      var tooltipValue = tooltipDataKey == null || allowDuplicatedCategory ? index : String((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getValueByDataKey */ .kr)(entry, tooltipDataKey, null));
      var numericValue = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getValueByDataKey */ .kr)(entry, item.dataKey, 0);
      var curr;
      if (knownItemsByDataKey.has(tooltipValue)) {
        curr = knownItemsByDataKey.get(tooltipValue);
      } else {
        curr = {};
      }
      Object.assign(curr, {
        [stackIdentifier]: numericValue
      });
      knownItemsByDataKey.set(tooltipValue, curr);
    });
  });
  return Array.from(knownItemsByDataKey.values());
}

/***/ }),

/***/ 87997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BZ: () => (/* binding */ selectActiveLabel),
/* harmony export */   aX: () => (/* binding */ combineActiveProps),
/* harmony export */   dS: () => (/* binding */ selectActiveCoordinate),
/* harmony export */   dp: () => (/* binding */ selectTooltipDataKey),
/* harmony export */   fW: () => (/* binding */ useChartName),
/* harmony export */   pg: () => (/* binding */ selectCoordinateForDefaultIndex),
/* harmony export */   r1: () => (/* binding */ selectOrderedTooltipTicks),
/* harmony export */   rb: () => (/* binding */ selectActiveIndex),
/* harmony export */   u9: () => (/* binding */ selectTooltipPayload),
/* harmony export */   yn: () => (/* binding */ selectIsTooltipActive)
/* harmony export */ });
/* unused harmony exports selectTooltipInteractionState, selectTooltipPayloadConfigurations */
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(60184);
/* harmony import */ var es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49082);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(33964);
/* harmony import */ var _dataSelectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98453);
/* harmony import */ var _tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33032);
/* harmony import */ var _rootPropsSelectors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(82695);
/* harmony import */ var _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(19287);
/* harmony import */ var _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(36189);
/* harmony import */ var _containerSelectors__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5180);
/* harmony import */ var _combiners_combineActiveLabel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(75403);
/* harmony import */ var _combiners_combineTooltipInteractionState__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(19809);
/* harmony import */ var _combiners_combineActiveTooltipIndex__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(74544);
/* harmony import */ var _combiners_combineCoordinateForDefaultIndex__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4217);
/* harmony import */ var _combiners_combineTooltipPayloadConfigurations__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(60523);
/* harmony import */ var _selectTooltipPayloadSearcher__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(18351);
/* harmony import */ var _selectTooltipState__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(23571);
/* harmony import */ var _combiners_combineTooltipPayload__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(89596);
/* harmony import */ var _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(37617);



















var useChartName = () => {
  return (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppSelector */ .G)(_rootPropsSelectors__WEBPACK_IMPORTED_MODULE_6__/* .selectChartName */ .iO);
};
var pickTooltipEventType = (_state, tooltipEventType) => tooltipEventType;
var pickTrigger = (_state, _tooltipEventType, trigger) => trigger;
var pickDefaultIndex = (_state, _tooltipEventType, _trigger, defaultIndex) => defaultIndex;
var selectOrderedTooltipTicks = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectTooltipAxisTicks */ .R4, ticks => es_toolkit_compat_sortBy__WEBPACK_IMPORTED_MODULE_1___default()(ticks, o => o.coordinate));
var selectTooltipInteractionState = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectTooltipState__WEBPACK_IMPORTED_MODULE_16__/* .selectTooltipState */ .J, pickTooltipEventType, pickTrigger, pickDefaultIndex], _combiners_combineTooltipInteractionState__WEBPACK_IMPORTED_MODULE_11__/* .combineTooltipInteractionState */ .i);
var selectActiveIndex = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectTooltipInteractionState, _tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectTooltipDisplayedData */ .n4], _combiners_combineActiveTooltipIndex__WEBPACK_IMPORTED_MODULE_12__/* .combineActiveTooltipIndex */ .P);
var selectTooltipDataKey = (state, tooltipEventType, trigger) => {
  if (tooltipEventType == null) {
    return undefined;
  }
  var tooltipState = (0,_selectTooltipState__WEBPACK_IMPORTED_MODULE_16__/* .selectTooltipState */ .J)(state);
  if (tooltipEventType === 'axis') {
    if (trigger === 'hover') {
      return tooltipState.axisInteraction.hover.dataKey;
    }
    return tooltipState.axisInteraction.click.dataKey;
  }
  if (trigger === 'hover') {
    return tooltipState.itemInteraction.hover.dataKey;
  }
  return tooltipState.itemInteraction.click.dataKey;
};
var selectTooltipPayloadConfigurations = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_selectTooltipState__WEBPACK_IMPORTED_MODULE_16__/* .selectTooltipState */ .J, pickTooltipEventType, pickTrigger, pickDefaultIndex], _combiners_combineTooltipPayloadConfigurations__WEBPACK_IMPORTED_MODULE_14__/* .combineTooltipPayloadConfigurations */ .q);
var selectCoordinateForDefaultIndex = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([_containerSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectChartWidth */ .Lp, _containerSelectors__WEBPACK_IMPORTED_MODULE_9__/* .selectChartHeight */ .A$, _context_chartLayoutContext__WEBPACK_IMPORTED_MODULE_7__/* .selectChartLayout */ .fz, _selectChartOffsetInternal__WEBPACK_IMPORTED_MODULE_8__/* .selectChartOffsetInternal */ .HZ, _tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectTooltipAxisTicks */ .R4, pickDefaultIndex, selectTooltipPayloadConfigurations, _selectTooltipPayloadSearcher__WEBPACK_IMPORTED_MODULE_15__/* .selectTooltipPayloadSearcher */ .x], _combiners_combineCoordinateForDefaultIndex__WEBPACK_IMPORTED_MODULE_13__/* .combineCoordinateForDefaultIndex */ .o);
var selectActiveCoordinate = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectTooltipInteractionState, selectCoordinateForDefaultIndex], (tooltipInteractionState, defaultIndexCoordinate) => {
  var _tooltipInteractionSt;
  return (_tooltipInteractionSt = tooltipInteractionState.coordinate) !== null && _tooltipInteractionSt !== void 0 ? _tooltipInteractionSt : defaultIndexCoordinate;
});
var selectActiveLabel = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)(_tooltipSelectors__WEBPACK_IMPORTED_MODULE_5__/* .selectTooltipAxisTicks */ .R4, selectActiveIndex, _combiners_combineActiveLabel__WEBPACK_IMPORTED_MODULE_10__/* .combineActiveLabel */ .E);
var selectTooltipPayload = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectTooltipPayloadConfigurations, selectActiveIndex, _dataSelectors__WEBPACK_IMPORTED_MODULE_4__/* .selectChartDataWithIndexes */ .LF, _selectTooltipAxis__WEBPACK_IMPORTED_MODULE_18__/* .selectTooltipAxisDataKey */ .K, selectActiveLabel, _selectTooltipPayloadSearcher__WEBPACK_IMPORTED_MODULE_15__/* .selectTooltipPayloadSearcher */ .x, pickTooltipEventType], _combiners_combineTooltipPayload__WEBPACK_IMPORTED_MODULE_17__/* .combineTooltipPayload */ .N);
var selectIsTooltipActive = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectTooltipInteractionState], tooltipInteractionState => {
  return {
    isActive: tooltipInteractionState.active,
    activeIndex: tooltipInteractionState.index
  };
});
var combineActiveProps = (chartEvent, layout, polarViewBox, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks, offset) => {
  if (!chartEvent || !layout || !tooltipAxisType || !tooltipAxisRange || !tooltipTicks) {
    return undefined;
  }
  var rangeObj = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .inRange */ .r4)(chartEvent.chartX, chartEvent.chartY, layout, polarViewBox, offset);
  if (!rangeObj) {
    return undefined;
  }
  var pos = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .calculateTooltipPos */ .SW)(rangeObj, layout);
  var activeIndex = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .calculateActiveTickIndex */ .gH)(pos, orderedTooltipTicks, tooltipTicks, tooltipAxisType, tooltipAxisRange);
  var activeCoordinate = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_3__/* .getActiveCoordinate */ .bk)(layout, tooltipTicks, activeIndex, rangeObj);
  return {
    activeIndex: String(activeIndex),
    activeCoordinate
  };
};

/***/ }),

/***/ 89596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ combineTooltipPayload)
/* harmony export */ });
/* harmony import */ var _util_DataUtils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59744);
/* harmony import */ var _util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(33964);
/* harmony import */ var _util_getSliced__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79195);
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }



function selectFinalData(dataDefinedOnItem, dataDefinedOnChart) {
  /*
   * If a payload has data specified directly from the graphical item, prefer that.
   * Otherwise, fill in data from the chart level, using the same index.
   */
  if (dataDefinedOnItem != null) {
    return dataDefinedOnItem;
  }
  return dataDefinedOnChart;
}
var combineTooltipPayload = (tooltipPayloadConfigurations, activeIndex, chartDataState, tooltipAxisDataKey, activeLabel, tooltipPayloadSearcher, tooltipEventType) => {
  if (activeIndex == null || tooltipPayloadSearcher == null) {
    return undefined;
  }
  var {
    chartData,
    computedData,
    dataStartIndex,
    dataEndIndex
  } = chartDataState;
  var init = [];
  return tooltipPayloadConfigurations.reduce((agg, _ref) => {
    var _settings$dataKey;
    var {
      dataDefinedOnItem,
      settings
    } = _ref;
    var finalData = selectFinalData(dataDefinedOnItem, chartData);
    var sliced = Array.isArray(finalData) ? (0,_util_getSliced__WEBPACK_IMPORTED_MODULE_2__/* .getSliced */ .v)(finalData, dataStartIndex, dataEndIndex) : finalData;
    var finalDataKey = (_settings$dataKey = settings === null || settings === void 0 ? void 0 : settings.dataKey) !== null && _settings$dataKey !== void 0 ? _settings$dataKey : tooltipAxisDataKey;
    // BaseAxisProps does not support nameKey but it could!
    var finalNameKey = settings === null || settings === void 0 ? void 0 : settings.nameKey; // ?? tooltipAxis?.nameKey;
    var tooltipPayload;
    if (tooltipAxisDataKey && Array.isArray(sliced) &&
    /*
     * findEntryInArray won't work for Scatter because Scatter provides an array of arrays
     * as tooltip payloads and findEntryInArray is not prepared to handle that.
     * Sad but also ScatterChart only allows 'item' tooltipEventType
     * and also this is only a problem if there are multiple Scatters and each has its own data array
     * so let's fix that some other time.
     */
    !Array.isArray(sliced[0]) &&
    /*
     * If the tooltipEventType is 'axis', we should search for the dataKey in the sliced data
     * because thanks to allowDuplicatedCategory=false, the order of elements in the array
     * no longer matches the order of elements in the original data
     * and so we need to search by the active dataKey + label rather than by index.
     *
     * The same happens if multiple graphical items are present in the chart
     * and each of them has its own data array. Those arrays get concatenated
     * and again the tooltip index no longer matches the original data.
     *
     * On the other hand the tooltipEventType 'item' should always search by index
     * because we get the index from interacting over the individual elements
     * which is always accurate, irrespective of the allowDuplicatedCategory setting.
     */
    tooltipEventType === 'axis') {
      tooltipPayload = (0,_util_DataUtils__WEBPACK_IMPORTED_MODULE_0__/* .findEntryInArray */ .eP)(sliced, tooltipAxisDataKey, activeLabel);
    } else {
      /*
       * This is a problem because it assumes that the index is pointing to the displayed data
       * which it isn't because the index is pointing to the tooltip ticks array.
       * The above approach (with findEntryInArray) is the correct one, but it only works
       * if the axis dataKey is defined explicitly, and if the data is an array of objects.
       */
      tooltipPayload = tooltipPayloadSearcher(sliced, activeIndex, computedData, finalNameKey);
    }
    if (Array.isArray(tooltipPayload)) {
      tooltipPayload.forEach(item => {
        var newSettings = _objectSpread(_objectSpread({}, settings), {}, {
          name: item.name,
          unit: item.unit,
          // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
          color: undefined,
          // color and fill are erased to keep 100% the identical behaviour to recharts 2.x - but there's nothing stopping us from returning them here. It's technically a breaking change.
          fill: undefined
        });
        agg.push((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getTooltipEntry */ .GF)({
          tooltipEntrySettings: newSettings,
          dataKey: item.dataKey,
          payload: item.payload,
          // @ts-expect-error getValueByDataKey does not validate the output type
          value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getValueByDataKey */ .kr)(item.payload, item.dataKey),
          name: item.name
        }));
      });
    } else {
      var _getValueByDataKey;
      // I am not quite sure why these two branches (Array vs Array of Arrays) have to behave differently - I imagine we should unify these. 3.x breaking change?
      agg.push((0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getTooltipEntry */ .GF)({
        tooltipEntrySettings: settings,
        dataKey: finalDataKey,
        payload: tooltipPayload,
        // @ts-expect-error getValueByDataKey does not validate the output type
        value: (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getValueByDataKey */ .kr)(tooltipPayload, finalDataKey),
        // @ts-expect-error getValueByDataKey does not validate the output type
        name: (_getValueByDataKey = (0,_util_ChartUtils__WEBPACK_IMPORTED_MODULE_1__/* .getValueByDataKey */ .kr)(tooltipPayload, finalNameKey)) !== null && _getValueByDataKey !== void 0 ? _getValueByDataKey : settings === null || settings === void 0 ? void 0 : settings.name
      }));
    }
    return agg;
  }, init);
};

/***/ }),

/***/ 92476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mZ: () => (/* binding */ updateOptions),
/* harmony export */   vE: () => (/* binding */ rootPropsReducer)
/* harmony export */ });
/* unused harmony export initialState */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4768);


/**
 * These are chart options that users can choose - which means they can also
 * choose to change them which should trigger a re-render.
 */

var initialState = {
  accessibilityLayer: true,
  barCategoryGap: '10%',
  barGap: 4,
  barSize: undefined,
  className: undefined,
  maxBarSize: undefined,
  stackOffset: 'none',
  syncId: undefined,
  syncMethod: 'index'
};
var rootPropsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__/* .createSlice */ .Z0)({
  name: 'rootProps',
  initialState,
  reducers: {
    updateOptions: (state, action) => {
      var _action$payload$barGa;
      state.accessibilityLayer = action.payload.accessibilityLayer;
      state.barCategoryGap = action.payload.barCategoryGap;
      state.barGap = (_action$payload$barGa = action.payload.barGap) !== null && _action$payload$barGa !== void 0 ? _action$payload$barGa : initialState.barGap;
      state.barSize = action.payload.barSize;
      state.maxBarSize = action.payload.maxBarSize;
      state.stackOffset = action.payload.stackOffset;
      state.syncId = action.payload.syncId;
      state.syncMethod = action.payload.syncMethod;
      state.className = action.payload.className;
    }
  }
});
var rootPropsReducer = rootPropsSlice.reducer;
var {
  updateOptions
} = rootPropsSlice.actions;

/***/ }),

/***/ 98453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HS: () => (/* binding */ selectChartDataWithIndexesIfNotInPanorama),
/* harmony export */   LF: () => (/* binding */ selectChartDataWithIndexes),
/* harmony export */   z3: () => (/* binding */ selectChartDataAndAlwaysIgnoreIndexes)
/* harmony export */ });
/* harmony import */ var reselect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25508);

/**
 * This selector always returns the data with the indexes set by a Brush.
 * Trouble is, that might or might not be what you want.
 *
 * In charts with Brush, you will sometimes want to select the full range of data, and sometimes the one decided by the Brush
 * - even if the Brush is active, the panorama inside the Brush should show the full range of data.
 *
 * So instead of this selector, consider using either selectChartDataAndAlwaysIgnoreIndexes or selectChartDataWithIndexesIfNotInPanorama
 *
 * @param state RechartsRootState
 * @returns data defined on the chart root element, such as BarChart or ScatterChart
 */
var selectChartDataWithIndexes = state => state.chartData;

/**
 * This selector will always return the full range of data, ignoring the indexes set by a Brush.
 * Useful for when you want to render the full range of data, even if a Brush is active.
 * For example: in the Brush panorama, in Legend, in Tooltip.
 */
var selectChartDataAndAlwaysIgnoreIndexes = (0,reselect__WEBPACK_IMPORTED_MODULE_0__/* .createSelector */ .Mz)([selectChartDataWithIndexes], dataState => {
  var dataEndIndex = dataState.chartData != null ? dataState.chartData.length - 1 : 0;
  return {
    chartData: dataState.chartData,
    computedData: dataState.computedData,
    dataEndIndex,
    dataStartIndex: 0
  };
});
var selectChartDataWithIndexesIfNotInPanorama = (state, _unused1, _unused2, isPanorama) => {
  if (isPanorama) {
    return selectChartDataAndAlwaysIgnoreIndexes(state);
  }
  return selectChartDataWithIndexes(state);
};

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi02YzdkYTc4YS5kZDAzN2Y3MmU5ODlhZTdlZjc0MC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7OztBQ2hDTzs7QUFFUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDQSw4Qjs7Ozs7Ozs7Ozs7OztBQy9CQTtBQUNBO0FBQ0E7QUFDQSxnRDs7Ozs7Ozs7OztBQ0hBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSMEU7QUFDc0I7QUFDRTtBQUN0QjtBQUNsQjtBQUNuRCx1QkFBdUIsd0VBQVk7QUFDbkMsMkJBQTJCLG9GQUF3Qjs7QUFFMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQix3SEFBaUMseUJBQXlCLCtFQUFlO0FBQy9GO0FBQ0EsMkJBQTJCLCtFQUFzQjtBQUNqRDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLENBQUM7QUFDTSxzQkFBc0Isd0VBQVk7QUFDbEMsMEJBQTBCLG9GQUF3QjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLG1HQUFzQjtBQUNqRCxzQkFBc0Isd0hBQWlDLFFBQVEsK0VBQWU7O0FBRTlFO0FBQ0E7QUFDQTtBQUNBLDZCQUE2Qiw4RUFBcUI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULFFBQVE7QUFDUjtBQUNBLDZCQUE2Qix3RUFBZTtBQUM1QztBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7QUMvQ0Q7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYkEseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQy9OO0FBQ0U7QUFDUTtBQUNkO0FBQytCO0FBQ29FO0FBQ2pDO0FBQzhDO0FBQzlCO0FBQ25EO0FBQ1U7QUFDSjtBQUNWO0FBQ087QUFDTTtBQUNzQjtBQUNrQjtBQUN4RTtBQUNKO0FBQzRDO0FBQzFCO0FBQzBCO0FBQzlCO0FBQzhCO0FBQzVCO0FBQ2M7QUFDZDtBQUMxRDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsNEVBQW9CO0FBQzdCO0FBQ087QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsK0VBQWU7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsZUFBZSxnRkFBZ0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLCtFQUFlO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLGVBQWUsZ0ZBQWdCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDTzs7QUFFUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCwwQkFBMEIsa0VBQWMsRUFBRSxpRUFBWSxFQUFFLDZEQUFVO0FBQzNEO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sbUNBQW1DLGtFQUFjO0FBQ3hEO0FBQ0EseUJBQXlCLDZFQUFrQjtBQUMzQztBQUNBLENBQUM7QUFDTSwwQ0FBMEMsa0VBQWM7QUFDL0QsMkZBQTJGLDRFQUFTO0FBQ3BHLENBQUM7QUFDTTtBQUNQLGdEQUFnRCxrRUFBYztBQUN2RDs7QUFFUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyx3Q0FBd0Msa0VBQWM7QUFDN0Q7QUFDQSx5QkFBeUIsNkVBQWtCO0FBQzNDO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDBCQUEwQixrRUFBYyxxQ0FBcUMsK0ZBQXlDO0FBQ3RIO0FBQ1A7QUFDQTtBQUNBLGFBQWEsNkVBQWlCO0FBQzlCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxhQUFhLDZFQUFpQjtBQUM5QixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDZCQUE2QixrRUFBYztBQUMzQztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0scUVBQVU7QUFDaEI7QUFDQSxRQUFRLHVGQUFtQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxpR0FBd0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQywyREFBUTtBQUM3Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLGdFQUFnRSxnRUFBSztBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsNkVBQWlCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsU0FBUyx1RkFBbUIsZUFBZSx1RkFBbUI7QUFDOUQ7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ08saUNBQWlDLGtFQUFjLHVDQUF1QywrRkFBeUMsRUFBRSwyRUFBaUIsR0FBRyx5R0FBMkI7QUFDaEw7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0Esc0NBQXNDLHFHQUF3QjtBQUM5RDtBQUNBO0FBQ0EsbUJBQW1CLDBFQUFjO0FBQ2pDO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sd0JBQXdCLGtFQUFjLG1FQUFtRSxpRkFBcUI7QUFDOUg7QUFDUDtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixrRkFBc0I7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixrRUFBYztBQUN0QztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDZCQUE2QixrRUFBYzs7QUFFbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxxQ0FBcUMsa0VBQWMscURBQXFELGlIQUE0QztBQUNwSixnQ0FBZ0Msa0VBQWMscUJBQXFCLGdGQUEwQixFQUFFLGlFQUFZO0FBQ2xIO0FBQ0EseUJBQXlCLDJGQUF5QjtBQUNsRDtBQUNBLENBQUM7QUFDTTtBQUNQO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNPO0FBQ1AseUVBQXlFLGFBQWE7QUFDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLDZFQUFpQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLDZFQUFpQjtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLE1BQU0sdUZBQW1CLGNBQWMsdUZBQW1CO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0VBQWtFLGtFQUFjLDZHQUE2RyxpRUFBWTtBQUN6TTtBQUNBLHlCQUF5QiwyRkFBeUI7QUFDbEQ7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLE1BQU0scUVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0dBQWdHLHVFQUFZO0FBQzVHO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyw4REFBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNPLGdDQUFnQyxrRUFBYyx1QkFBdUIsaUVBQVksRUFBRSw2REFBVTtBQUM3RjtBQUNBLGlDQUFpQyxrRUFBYyx3QkFBd0IsaUVBQVksRUFBRSw2REFBVTtBQUMvRjtBQUNBLGlDQUFpQyxrRUFBYyx3QkFBd0IsaUVBQVksRUFBRSw2REFBVTtBQUMvRjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxrRUFBYyw0QkFBNEIsaUVBQVk7QUFDL0U7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsa0VBQWMsOEJBQThCLGlFQUFZO0FBQ2xGO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLGtFQUFjLDZCQUE2QixpRUFBWTtBQUN4RixvQ0FBb0Msa0VBQWM7QUFDbEQ7QUFDQSxDQUFDO0FBQ007QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLGlHQUF3QjtBQUNqQztBQUNPLDRCQUE0QixrRUFBYyxpTUFBaU0sb0ZBQWlCLEVBQUUsaUVBQVk7QUFDalI7QUFDQSx5QkFBeUIsMkZBQXlCO0FBQ2xEO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSixzQkFBc0IsNkVBQWlCO0FBQ3ZDO0FBQ0EsV0FBVyw4REFBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyx1QkFBdUIsa0VBQWMsa0JBQWtCLG9GQUFpQiwrQ0FBK0MsaUZBQXFCLEVBQUUsaUVBQVk7QUFDMUo7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIscUVBQVU7QUFDeEMsbUJBQW1CLG9EQUFRO0FBQzNCO0FBQ0E7QUFDQTtBQUNPLDBCQUEwQixrRUFBYyxrQkFBa0Isb0ZBQWlCLGdCQUFnQiwyRUFBZSxFQUFFLGlFQUFZO0FBQy9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLG9EQUFRO0FBQy9CO0FBQ0EsV0FBVyxvREFBUTtBQUNuQjtBQUNBLDRCQUE0QixxRUFBVTtBQUN0QyxjQUFjLG9EQUFRO0FBQ3RCO0FBQ0EsV0FBVyxvREFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRSw4RUFBa0I7QUFDcEI7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpS0FBaUssaUdBQXdCO0FBQ3pMLFdBQVcsd0VBQWlCO0FBQzVCO0FBQ0EsMEZBQTBGLGlHQUF3QjtBQUNsSCxXQUFXLCtFQUF3QjtBQUNuQztBQUNBO0FBQ0E7QUFDTyxzQkFBc0Isa0VBQWM7QUFDcEM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhIQUE4SCxpR0FBd0I7QUFDdEo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHlDQUF5QyxrRUFBYyxxREFBcUQsaUVBQVk7O0FBRS9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDBDQUEwQyxrRUFBYztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiw2QkFBNkI7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsOEJBQThCLGtFQUFjLHNDQUFzQyxvRkFBaUIsRUFBRSxnRkFBb0IsRUFBRSw0RkFBeUI7QUFDcEosT0FBTyx1RkFBbUI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLDBFQUFlO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsa0VBQWM7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELHlCQUF5QixrRUFBYztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sd0JBQXdCLGtFQUFjLEVBQUUsNEZBQXlCLHNCQUFzQiw0RUFBcUIsRUFBRSwwRUFBbUI7QUFDeEk7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTSx3QkFBd0Isa0VBQWMsRUFBRSw0RkFBeUIsRUFBRSxvRkFBaUIsc0JBQXNCLDRFQUFxQixFQUFFLDBFQUFtQjtBQUMzSjtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxvRkFBb0I7QUFDakM7QUFDQSxhQUFhLHFGQUFxQjtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNPLGlDQUFpQyxrRUFBYyxvQ0FBb0MseUdBQTJCO0FBQzlHLHNCQUFzQixrRUFBYztBQUNwQyw4QkFBOEIsa0VBQWMsMkRBQTJELGlFQUFZO0FBQzFIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsa0VBQWMsQ0FBQyxvRUFBYztBQUNoRSxtQ0FBbUMsa0VBQWMsQ0FBQyxvRUFBYztBQUNoRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRFQUE0RSw0RUFBb0I7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLHNCQUFzQixrRUFBYyxDQUFDLDRGQUF5QjtBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZ0NBQWdDLGtFQUFjLENBQUMsNkVBQWlCLEVBQUUsNEZBQXlCO0FBQ2xHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsQ0FBQztBQUNNLGdDQUFnQyxrRUFBYyxDQUFDLDRFQUFnQixFQUFFLDRGQUF5QjtBQUNqRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDBCQUEwQixrRUFBYyxFQUFFLDRGQUF5QjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sMEJBQTBCLGtFQUFjLEVBQUUsNEZBQXlCO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sc0JBQXNCLGtFQUFjLENBQUMsNEZBQXlCO0FBQ3JFLDRFQUE0RSw0RUFBb0I7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ007QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHNCQUFzQiw2RUFBaUI7QUFDdkM7QUFDQSxvRkFBb0YsdUVBQVk7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDTyw0QkFBNEIsa0VBQWMsRUFBRSxvRkFBaUIsMENBQTBDLGlFQUFZO0FBQ25IO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHNCQUFzQiw2RUFBaUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDhCQUE4QixrRUFBYyxFQUFFLG9GQUFpQiw4Q0FBOEMsaUVBQVk7QUFDekgsMERBQTBELGtFQUFjLEVBQUUsb0ZBQWlCLHVKQUF1SixpRUFBWTtBQUNyUTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsNkVBQWlCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ007QUFDUDtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsNkVBQWlCO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTs7QUFFSjtBQUNBO0FBQ0E7QUFDQSxvRkFBb0YsbUVBQVE7O0FBRTVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLGlDQUFpQyxnRUFBSztBQUN0Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNPLHdCQUF3QixrRUFBYyxFQUFFLG9GQUFpQiw4SUFBOEksaUVBQVk7QUFDbk47QUFDUDtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsNkVBQWlCO0FBQ3ZDO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSx1SEFBdUgsbUVBQVE7O0FBRS9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ08saUNBQWlDLGtFQUFjLEVBQUUsb0ZBQWlCLHdHQUF3RyxpRUFBWTtBQUN0TCwwQkFBMEIsa0VBQWM7QUFDL0M7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLFdBQVc7QUFDbEQ7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNELHVCQUF1QixrRUFBYztBQUM5QiwyQkFBMkIsa0VBQWM7QUFDaEQ7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLFdBQVc7QUFDbEQ7QUFDQSxHQUFHO0FBQ0gsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7O0FBRU8sMkJBQTJCLGtFQUFjLEVBQUUsb0ZBQWlCLEVBQUUsb0VBQWMsRUFBRSxvRUFBYztBQUNuRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7O0FDN3ZDRCx5QkFBeUIsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsNEJBQTRCLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0Qsc0RBQXNELDhCQUE4QixtSkFBbUoscUVBQXFFLEtBQUs7QUFDNWEsb0NBQW9DLG9FQUFvRSwwREFBMEQ7QUFDbEssNkJBQTZCLG1DQUFtQztBQUNoRSw4QkFBOEIsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDbFE7QUFDUDtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxZQUFZLFFBQVE7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLHVGQUF1RixVQUFVO0FBQ2pHO0FBQ0EsR0FBRyxLQUFLO0FBQ1IsdUNBQXVDLGFBQWE7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixZQUFZLFFBQVE7QUFDYjtBQUNQO0FBQ0E7O0FBRUE7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFlBQVksUUFBUTtBQUNwQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7OztBQy9KcUU7QUFDOUQ7QUFDUCxlQUFlLHdGQUFpQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7QUNiMEM7QUFDbUI7QUFDN0Qsa0RBQWtELG9GQUFvQjtBQUMvRCw0QkFBNEIsa0VBQWM7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QscURBQXFELG9GQUFvQjtBQUNsRSwyQkFBMkIsa0VBQWM7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7QUNmTSxpRjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQVAseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQy9OO0FBQ1U7QUFDb0I7QUFDQTtBQUNNO0FBQ2hCO0FBQzlEO0FBQ0Esb0NBQW9DLGtFQUFjLEVBQUUsaUZBQTBCOztBQUU5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sMEJBQTBCLGtFQUFjLEVBQUUsMkZBQXFDO0FBQ3RGO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLG9FQUFvRTtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNLHNCQUFzQixrRUFBYztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSw2RUFBaUI7QUFDaEM7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBLGFBQWEsOEVBQWtCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUM7QUFDTSx1QkFBdUIsa0VBQWMsaUVBQWlFLDJGQUF5QjtBQUN0STtBQUNBO0FBQ0E7QUFDQSxTQUFTLHNFQUFpQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUV5QztBQUM4QjtBQUNxVztBQUN4VztBQUNYO0FBQ1o7QUFDSjtBQUNtQjtBQUN0RDtBQUNQLDBCQUEwQixrRUFBYyxFQUFFLGdFQUFZLEVBQUUsNERBQVUsR0FBRyx1RUFBaUI7QUFDL0UsK0JBQStCLGtFQUFjLDhCQUE4QixvRUFBYyx3QkFBd0IsbUZBQTZCO0FBQ3JKLG9DQUFvQyxrRUFBYyw2QkFBNkIsK0VBQXlCO0FBQ2pHLCtCQUErQixrRUFBYyxpQ0FBaUMsMkZBQXFDLEdBQUcsMEVBQW9CO0FBQzFJLCtCQUErQixrRUFBYyw0QkFBNEIsb0VBQWMsNkJBQTZCLDBFQUFvQjtBQUN4SSwyQ0FBMkMsa0VBQWMsNEJBQTRCLG9FQUFjO0FBQzFHO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLDZFQUFpQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsYUFBYSw2RUFBaUI7QUFDOUI7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsbURBQW1ELGtFQUFjLDRCQUE0QixvRUFBYyw0QkFBNEIsK0VBQXlCLEVBQUUsZ0VBQVksR0FBRyxrSEFBNEQ7QUFDN08saUNBQWlDLGtFQUFjLEVBQUUsb0VBQWMsRUFBRSw0RUFBc0IsRUFBRSxvRkFBOEIsa0dBQWtHLG9GQUFpQixFQUFFLGdFQUFZLEdBQUcsNEVBQXNCO0FBQzFRLDRCQUE0QixrRUFBYyxFQUFFLG9FQUFjLEVBQUUsb0ZBQWlCLHNEQUFzRCxnRkFBcUIsRUFBRSxnRUFBWSwrQkFBK0IsdUVBQWlCO0FBQ3ROLDJCQUEyQixrRUFBYyx5QkFBeUIsb0VBQWMsRUFBRSx5RUFBbUIsR0FBRyxzRUFBZ0I7QUFDeEgsOENBQThDLGtFQUFjLEVBQUUsb0VBQWMsK0NBQStDLGdFQUFZLEdBQUcsb0ZBQThCLEU7Ozs7Ozs7Ozs7QUMzQ3hLO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7QUNSK0M7QUFDL0Msd0JBQXdCLHVFQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQSxFQUFFO0FBQ0ssb0Q7Ozs7Ozs7Ozs7O0FDYlAseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3ROO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxXQUFXLGtFQUFhO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBLFdBQVcsa0VBQWE7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsa0NBQWtDO0FBQzdFO0FBQ0EsT0FBTztBQUNQO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLEVBQUUsa0VBQWEsS0FBSztBQUMzRDtBQUNBLEdBQUc7QUFDSCxFOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3hEMEM7QUFDMkI7QUFDMEI7QUFDdkI7QUFDSTtBQUNsQjtBQUNNO0FBQ2hFO0FBQ08sd0NBQXdDLGtFQUFjLG9CQUFvQixvRkFBaUIsRUFBRSw2RUFBa0IsRUFBRSxrRkFBcUIsRUFBRSwwRkFBaUMsRUFBRSwrRUFBc0IsRUFBRSwyRUFBeUIsRUFBRSwyRkFBeUIsR0FBRyxvRUFBa0IsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUnpPO0FBQ29DO0FBQ3BCO0FBQzFELDJDQUEyQyxtQ0FBYyxFQUFFLDRDQUFrQjtBQUN0RSw4QkFBOEIsbUNBQWMsd0NBQXdDLGdFQUE0QjtBQUN2SDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxFOztBQ3BCeUU7QUFDVTtBQUNjO0FBQ3hDO0FBQ2tCO0FBQ3lCO0FBQ2hDO0FBQzlELHVCQUF1Qiw2Q0FBWTtBQUNuQywyQkFBMkIseURBQXdCO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIseURBQXNCO0FBQ2pEO0FBQ0Esd0JBQXdCLDhFQUFpQyxRQUFRLDBDQUFlO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLDZCQUE2Qiw4Q0FBcUI7QUFDbEQ7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyxnREFBOEI7QUFDeEUsZ0VBQWdFLGtEQUFnQztBQUNoRyx1QkFBdUIsdUJBQXVCO0FBQzlDLDJCQUEyQixvREFBMkI7QUFDdEQ7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7QUM3Q007QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQzs7Ozs7Ozs7OztBQ05PLGdEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBbUM7QUFDUztBQUNrRjtBQUNoRTtBQUNPO0FBQ0M7QUFDUztBQUN0RixxRUFBcUUsNkVBQW1CO0FBQ3hGLGlFQUFpRSxvRkFBMEI7QUFDM0YscUVBQXFFLDZFQUFtQjtBQUN4RixpRUFBaUUsb0ZBQTBCO0FBQzNGLHFCQUFxQixrRUFBYyxFQUFFLG9GQUFpQjtBQUN0RCxNQUFNLDZFQUFpQjtBQUN2QixXQUFXLDZFQUFpQjtBQUM1QjtBQUNBLFNBQVMsNkVBQWlCO0FBQzFCLENBQUM7QUFDRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsa0VBQWMsRUFBRSxvRkFBOEI7QUFDNUU7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSx3RkFBaUI7QUFDaEMsMkJBQTJCLDZFQUFpQjtBQUM1QztBQUNBO0FBQ0Esa0JBQWtCLDJFQUFpQjtBQUNuQyxJQUFJO0FBQ0osa0JBQWtCLDJFQUFpQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osOEJBQThCLHdHQUF3QjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxpQkFBaUIsa0VBQWMsRUFBRSxvRkFBaUIsa0hBQWtILCtGQUF5QztBQUNwTjtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTLHNFQUFXO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQyxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3RnVEO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyw2QkFBNkIsdUVBQVc7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQixtRUFBTztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQixtRUFBTztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLGtCQUFrQixtRUFBTztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNLLDhEOzs7Ozs7Ozs7Ozs7OztBQy9Dd0M7QUFDTDs7QUFFMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0EsTUFBTSxnRUFBSztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHVFQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTTtBQUNBO0FBQ1A7QUFDQSxFQUFFLHVCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUN3QztBQUNvSjtBQUNoRDtBQUN6RTtBQUNzRDtBQUM3RTtBQUN2QztBQUNQO0FBQ0E7QUFDQTtBQUNBLGVBQWUsOEVBQWU7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsZUFBZSwrRUFBZ0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsK0ZBQWdDO0FBQy9DO0FBQ0E7QUFDQTtBQUNBLGVBQWUsZ0dBQWlDO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sMkJBQTJCLGtFQUFjLG1CQUFtQix5RUFBbUIsRUFBRSw4RkFBdUMscUNBQXFDLDBFQUFvQjtBQUNqTCxtQ0FBbUMsa0VBQWMsRUFBRSxvRkFBaUIsRUFBRSwrRUFBd0IsRUFBRSx3RUFBa0IsRUFBRSxnRUFBWSxHQUFHLDhFQUF3QjtBQUMzSiwyQkFBMkIsa0VBQWMsRUFBRSxvRkFBaUIsbUJBQW1CLHlFQUFtQix3QkFBd0IsMkVBQW9CLG9DQUFvQywyRUFBcUIsZ0NBQWdDLGdFQUFZLEdBQUcsc0VBQWdCO0FBQ3RRLHdDQUF3QyxrRUFBYyxFQUFFLG9GQUFpQiwyRUFBMkUsMkVBQXFCLGdDQUFnQyxnRUFBWSxHQUFHLCtFQUF5QixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q2pQLDREOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBbUM7QUFDMnFCO0FBQ2hwQjtBQUNYO0FBQ0c7QUFDaUI7QUFDOUI7QUFDc0M7QUFDNkM7QUFDL0Q7QUFDSjtBQUM0QjtBQUNWO0FBQ2M7QUFDckI7QUFDSDtBQUM4QjtBQUN4QjtBQUNwQjtBQUNnQjtBQUNkO0FBQ0k7QUFDa0I7QUFDSTtBQUM1QjtBQUN3QztBQUMxQjtBQUNkO0FBQ25ELHFDQUFxQyxtQ0FBYyxFQUFFLDBDQUFpQixFQUFFLDRDQUFpQixFQUFFLGtDQUFZLEVBQUUsMENBQWUsRUFBRSxrREFBcUIsR0FBRywwQ0FBb0I7QUFDdEssd0NBQXdDLG1DQUFjO0FBQzdELGlDQUFpQyxtQ0FBYyxFQUFFLGtEQUFxQixFQUFFLDhDQUFtQixHQUFHLHVDQUFpQjtBQUN4RyxzQ0FBc0MsbUNBQWMscUNBQXFDLDBDQUFpQiwrQkFBK0IsbURBQTZCO0FBQzdLO0FBQ0EseUJBQXlCLDRDQUFrQjtBQUMzQztBQUNBLENBQUM7QUFDRCw2Q0FBNkMsbUNBQWMsNEVBQTRFLHFDQUFTO0FBQ3pJLHNDQUFzQyxtQ0FBYyxvQ0FBb0MsK0NBQXlCO0FBQ3hIO0FBQ0EseUJBQXlCLDRDQUFrQjtBQUMzQztBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08saUNBQWlDLG1DQUFjLG1DQUFtQyxnREFBMEIsR0FBRywwQ0FBb0I7QUFDMUksK0JBQStCLG1DQUFjLDBDQUEwQyxnREFBMEIsRUFBRSwwQ0FBaUIsR0FBRyw4REFBMkI7QUFDbEssb0NBQW9DLG1DQUFjLDhCQUE4QiwwQ0FBaUIsb0NBQW9DLDBDQUFvQjtBQUN6Six3Q0FBd0MsbUNBQWMsRUFBRSwwQ0FBaUIsR0FBRyx5Q0FBbUI7QUFDL0YsZ0NBQWdDLG1DQUFjLEVBQUUsMENBQWlCO0FBQ2pFLDZDQUE2QyxtQ0FBYyxpRUFBaUUsNEVBQTRDO0FBQ3hLLHFDQUFxQyxtQ0FBYyw0RUFBNEUscUNBQVM7QUFDeEksK0JBQStCLG1DQUFjLDREQUE0RCxnREFBcUIsR0FBRyx3Q0FBa0I7QUFDbkosdUNBQXVDLG1DQUFjLDRCQUE0QixnREFBMEIsRUFBRSxrREFBcUIsMkNBQTJDLGdEQUEwQjtBQUN2TSw4Q0FBOEMsbUNBQWMsb0NBQW9DLG9EQUE4QjtBQUM5SCxrRUFBa0UsbUNBQWMsOEJBQThCLDBDQUFpQiwyQ0FBMkMsK0NBQXlCLEVBQUUsa0RBQXFCLEdBQUcsa0ZBQTREO0FBQ3pSO0FBQ0EseUJBQXlCLDBEQUF5QjtBQUNsRDtBQUNBLENBQUM7QUFDRCx1Q0FBdUMsbUNBQWMsRUFBRSx5Q0FBbUIsRUFBRSxrREFBcUIsRUFBRSw4Q0FBbUIsR0FBRyw2Q0FBdUI7QUFDaEosdUNBQXVDLG1DQUFjLG9DQUFvQyxrREFBcUIsR0FBRyx1Q0FBaUI7QUFDbEksd0NBQXdDLG1DQUFjLEVBQUUsMENBQW9CLEVBQUUsa0RBQXFCLEVBQUUsOENBQW1CLEdBQUcsNkNBQXVCO0FBQ2xKLHdDQUF3QyxtQ0FBYyxxQ0FBcUMsa0RBQXFCLEdBQUcsdUNBQWtCO0FBQ3JJLHdDQUF3QyxtQ0FBYyxFQUFFLDBDQUFvQixFQUFFLGtEQUFxQixFQUFFLDhDQUFtQixHQUFHLDZDQUF1QjtBQUNsSix3Q0FBd0MsbUNBQWMscUNBQXFDLGtEQUFxQixHQUFHLHdDQUFrQjtBQUNySSwyQ0FBMkMsbUNBQWMsMkdBQTJHLGtDQUFZO0FBQ2hMLG1DQUFtQyxtQ0FBYyxFQUFFLDBDQUFpQixrTkFBa04sNENBQWlCLEVBQUUsa0RBQXFCLEdBQUcsNENBQXNCO0FBQ2hWLDhCQUE4QixtQ0FBYyxFQUFFLDBDQUFpQixFQUFFLDRDQUFpQiw2REFBNkQsZ0RBQXFCLEVBQUUsa0RBQXFCLGlDQUFpQyx1Q0FBaUI7QUFDcFAsNkJBQTZCLG1DQUFjLDJCQUEyQiwwQ0FBaUIsbUNBQW1DLHNDQUFnQjtBQUNuSSxnREFBZ0QsbUNBQWMsRUFBRSwwQ0FBaUIsbURBQW1ELGtEQUFxQixHQUFHLG9EQUE4QjtBQUNqTTtBQUNBLGlCQUFpQixzREFBcUI7QUFDdEMsZUFBZSxrREFBbUI7QUFDbEMsMEJBQTBCO0FBQzFCLFNBQVMseUNBQWU7QUFDeEI7QUFDTyx3Q0FBd0MsbUNBQWMsRUFBRSwwQ0FBaUIsMkJBQTJCLDhEQUEyQjtBQUMvSCw2QkFBNkIsbUNBQWMsRUFBRSwwQ0FBaUIsaUhBQWlILDBDQUFvQjtBQUMxTSxtQ0FBbUMsbUNBQWMsRUFBRSw0Q0FBaUIsaUNBQWlDLDBDQUFpQixFQUFFLGtEQUFxQixHQUFHLDRDQUFzQjtBQUMvSixxQ0FBcUMsbUNBQWMsRUFBRSw0Q0FBaUIsaUNBQWlDLDBDQUFpQixFQUFFLGtEQUFxQixHQUFHLDhDQUF3QjtBQUNqTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0osc0JBQXNCLHdDQUFpQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEhBQTRILDhCQUFROztBQUVwSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDTyw2QkFBNkIsbUNBQWMsRUFBRSw0Q0FBaUIsRUFBRSwwQ0FBaUIsZ0pBQWdKLGtEQUFxQjtBQUM3UCxJQUFJLHVDQUFzQixHQUFHLG1DQUFjLEVBQUUsNERBQTZCLEVBQUUsOERBQStCLEVBQUUscUJBQXFCLG9FQUFvRSwwREFBdUI7QUFDN047QUFDQTtBQUNBLG9DQUFvQyxtQ0FBYyxFQUFFLDRDQUFrQixFQUFFLHVDQUFzQiw2Q0FBNkMsb0VBQThCO0FBQ2xLLCtCQUErQixtQ0FBYyw4REFBOEQsMERBQXlCO0FBQ3BJLHdCQUF3QixtQ0FBYyxxREFBcUQsNENBQWtCO0FBQzdHLGlDQUFpQyxtQ0FBYztBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCx5Q0FBeUMsbUNBQWMsRUFBRSw0Q0FBa0IsRUFBRSx1Q0FBc0IsNkNBQTZDLDhFQUFtQztBQUNuTCw2Q0FBNkMsbUNBQWMsRUFBRSwyQ0FBZ0IsRUFBRSw0Q0FBaUIsRUFBRSw0Q0FBaUIsRUFBRSwyREFBeUIsa0ZBQWtGLGdFQUE0QixHQUFHLHdFQUFnQztBQUN4UixvQ0FBb0MsbUNBQWM7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sNEJBQTRCLG1DQUFjO0FBQzFDLGlDQUFpQyxtQ0FBYyxnRUFBZ0UsZ0RBQTBCLEVBQUUsaURBQXdCLHFCQUFxQixnRUFBNEIsRUFBRSx1Q0FBc0IsR0FBRyxrREFBcUI7QUFDcFEsb0NBQW9DLG1DQUFjO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuSkQseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQzNOO0FBQ047QUFDb0g7QUFDM0Q7QUFDaEM7QUFDekI7QUFDakM7QUFDUCxNQUFNLCtEQUFTLFNBQVMsK0RBQVM7QUFDakM7QUFDQTtBQUNBLE1BQU0sZ0VBQVU7QUFDaEIsV0FBVyw0REFBRztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixTQUFTO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSw4REFBUSxtQkFBbUIsOERBQVE7QUFDN0M7QUFDQSxZQUFZLDhEQUFRLGtCQUFrQiw4REFBUTtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EscUJBQXFCLFVBQVU7QUFDL0I7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ04sa0hBQWtILDhEQUFRO0FBQzFILDJDQUEyQyxhQUFhO0FBQ3hEO0FBQ0EsT0FBTztBQUNQO0FBQ0Esa0hBQWtILDhEQUFRO0FBQzFILDJDQUEyQyxhQUFhO0FBQ3hEO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ087O0FBRVA7QUFDQTtBQUNBLFlBQVksT0FBTztBQUNuQixXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsU0FBUztBQUNwQixZQUFZLHVCQUF1QjtBQUNuQztBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxZQUFZLFNBQVM7QUFDckIsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsU0FBUztBQUNwQixZQUFZLFFBQVE7QUFDcEI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0VBQW9FLDhEQUFROztBQUU1RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsaUNBQWlDLDJEQUFLO0FBQ3RDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCx5Q0FBeUMsOERBQVEsZ0JBQWdCLDhEQUFRO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLDhEQUFRO0FBQ2Y7QUFDQTtBQUNBLE9BQU8sOERBQVE7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFlBQVksT0FBTztBQUNuQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsT0FBTztBQUMvQztBQUNBO0FBQ0Esb0JBQW9CLE9BQU87QUFDM0Isa0JBQWtCLDJEQUFLOztBQUV2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixZQUFZLE9BQU87QUFDbkI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLE9BQU87QUFDL0M7QUFDQSxvQkFBb0IsT0FBTztBQUMzQixrQkFBa0IsMkRBQUs7O0FBRXZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLGdGQUFpQjtBQUMzQjtBQUNBLFFBQVEsOEVBQWU7QUFDdkI7QUFDQSxjQUFjLG9GQUFxQjtBQUNuQztBQUNBLFVBQVUsZ0ZBQWlCO0FBQzNCO0FBQ0E7QUFDTztBQUNQO0FBQ0EsY0FBYyx3RUFBVSx5RUFBeUUsNkVBQWM7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxrREFBa0Q7QUFDbEQ7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsMERBQTBELCtEQUFTO0FBQ25FO0FBQ0Esd0JBQXdCLHNFQUFnQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsK0RBQVM7O0FBRWpEO0FBQ0EsVUFBVSwrREFBUztBQUNuQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVLCtEQUFTO0FBQ25CO0FBQ087QUFDUDtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsMERBQVE7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQSxtQkFBbUIsOERBQVM7QUFDNUI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEdBQUc7QUFDSDtBQUNPLG9EQUFvRCxFQUFFLFFBQVEsSUFBSTtBQUNsRSxxREFBcUQsRUFBRSxRQUFRLElBQUk7O0FBRTFFO0FBQ0E7QUFDQSxZQUFZLFFBQVE7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksU0FBUztBQUNyQixZQUFZLFFBQVE7QUFDcEI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLCtEQUFNO0FBQzdCO0FBQ0EsK0NBQStDLFNBQVM7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKLHVDQUF1QywyQkFBMkI7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLFdBQVcsc0VBQWU7QUFDMUI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUix5REFBeUQsYUFBYSx1RUFBZ0IsZ0RBQWdEO0FBQ3RJO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ04sdURBQXVELGFBQWEsdUVBQWdCLDhDQUE4QztBQUNsSTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDamtCQSx5QkFBeUIsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsNEJBQTRCLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0Qsc0RBQXNELDhCQUE4QixtSkFBbUoscUVBQXFFLEtBQUs7QUFDNWEsb0NBQW9DLG9FQUFvRSwwREFBMEQ7QUFDbEssNkJBQTZCLG1DQUFtQztBQUNoRSw4QkFBOEIsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDL047QUFDaUM7QUFDZDtBQUM0QjtBQUN4QjtBQUNMO0FBQ3JEO0FBQ1A7QUFDQSxjQUFjLHVFQUFjO0FBQzVCO0FBQ0E7QUFDQSxrRUFBa0UsMkVBQW9CO0FBQ3RGO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsY0FBYyx1RUFBYztBQUM1QjtBQUNBO0FBQ0Esa0VBQWtFLDJFQUFvQjtBQUN0RjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLGNBQWMsdUVBQWM7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsY0FBYyx1RUFBYztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGdDQUFnQyxrRUFBYyxFQUFFLDJFQUFnQixFQUFFLDRFQUFpQixFQUFFLHVFQUFZLCtHQUErRyw0RUFBb0IsRUFBRSx3RUFBZ0I7QUFDN1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBO0FBQ0EsV0FBVyxnRkFBb0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLGFBQWE7QUFDaEI7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUM7QUFDTSx5QkFBeUIsa0VBQWM7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sd0JBQXdCLGtFQUFjLENBQUMsMkVBQWdCLEVBQUUsNEVBQWlCO0FBQ2pGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxHOzs7Ozs7Ozs7Ozs7Ozs7QUMzRnlDO0FBQ1c7QUFDVztBQUNKO0FBQ3JEO0FBQ1AsaUJBQWlCLHNGQUFxQjtBQUN0QyxlQUFlLGtGQUFtQjtBQUNsQyxTQUFTLDRFQUFrQjtBQUMzQjtBQUNPLCtCQUErQixrRUFBYyx3Rjs7Ozs7Ozs7Ozs7Ozs7QUNUVjtBQUNxQjtBQUNhO0FBQzREO0FBQ3hJLDRGQUE0Riw2RUFBbUI7QUFDL0csd0ZBQXdGLG9GQUEwQjtBQUNsSCw0RkFBNEYsNkVBQW1CO0FBQy9HLHdGQUF3RixvRkFBMEI7QUFDbEgsMERBQTBELDZFQUFvQjtBQUM5RTtBQUNBO0FBQ0EsK0ZBQStGLG1HQUF5QztBQUN4SSx3Q0FBd0Msa0VBQWMsRUFBRSxvRkFBOEI7QUFDdEY7QUFDQSxDQUFDO0FBQ00sMEJBQTBCLGtFQUFjO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxpRkFBb0I7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7QUMzQ3lDO0FBQ2M7QUFDbUI7QUFDcEUscUJBQXFCLGtFQUFjLEVBQUUsMEVBQWlCLEVBQUUsMkVBQWdCLEVBQUUsNEVBQWlCO0FBQ2xHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsRTs7Ozs7Ozs7OztBQ2JNLGtEOzs7Ozs7Ozs7Ozs7Ozs7O0FDQXdDO0FBQ2I7QUFDbEM7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBLHFCQUFxQix1RUFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QywwREFBUztBQUNyRCxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLDJDQUEyQywwREFBUztBQUNwRCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ007QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDSyw4Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5QkE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSc0Y7QUFDdEM7QUFDQTtBQUNJO0FBQ0Q7QUFDaUM7QUFDTTtBQUM5QjtBQUNFO0FBQ007QUFDeEI7QUFDRTtBQUNNO0FBQ0E7QUFDTTtBQUNZO0FBQ0E7QUFDUDtBQUNiO0FBQ1Y7QUFDeEMsa0JBQWtCLGdEQUFlO0FBQ2pDLFNBQVMsK0JBQVk7QUFDckIsaUJBQWlCLCtDQUFvQjtBQUNyQyxhQUFhLHVDQUFnQjtBQUM3QixhQUFhLHFDQUFlO0FBQzVCLGtCQUFrQixpREFBcUI7QUFDdkMsVUFBVSxzQ0FBa0I7QUFDNUIsVUFBVSxpQ0FBYTtBQUN2QixXQUFXLG1DQUFjO0FBQ3pCLGFBQWEsdUNBQWdCO0FBQzdCLGdCQUFnQiw0Q0FBbUI7QUFDbkMscUJBQXFCLHVEQUF3QjtBQUM3QyxhQUFhLHVDQUFnQjtBQUM3QixXQUFXLG1DQUFjO0FBQ3pCLENBQUM7QUFDTTtBQUNQO0FBQ0EsU0FBUywrQ0FBYztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLFVBQVUsa0RBQW9CLGFBQWEsaURBQW1CLGFBQWEseURBQXdCLGFBQWEsd0RBQXdCLGFBQWEsaURBQW9CO0FBQzlLO0FBQ0E7QUFDQSxpREFBaUQsSUFBSTtBQUNyRCx5RUFBeUUsSUFBSTtBQUM3RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QixrREFBaUI7QUFDL0M7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMLGNBQWMsb0JBQU07QUFDcEI7QUFDQSxrQkFBa0Isa0NBQWtDO0FBQ3BELE9BQU87QUFDUDtBQUNBO0FBQ0EsR0FBRztBQUNILEU7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1RTBDO0FBQ2U7QUFDbUI7QUFDUDtBQUM2QztBQUNyQztBQUM3RSxxRUFBcUUsNkVBQW1CO0FBQ3hGLGlFQUFpRSxvRkFBMEI7QUFDM0YscUVBQXFFLDZFQUFtQjtBQUN4RixpRUFBaUUsb0ZBQTBCO0FBQzNGLHFCQUFxQixrRUFBYyxFQUFFLG9GQUFpQjtBQUN0RCxNQUFNLDZFQUFpQjtBQUN2QixXQUFXLDZFQUFpQjtBQUM1QjtBQUNBLFNBQVMsNkVBQWlCO0FBQzFCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLGtFQUFjLEVBQUUsb0ZBQThCO0FBQzVFLHVCQUF1QixrRUFBYyxFQUFFLG9GQUFpQixrSUFBa0ksK0ZBQXlDO0FBQzFPO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsMkVBQWlCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQyxFOzs7Ozs7Ozs7Ozs7Ozs7QUM5RHlDO0FBQ0k7QUFDdkM7QUFDQTtBQUNQO0FBQ08sMEJBQTBCLGtFQUFjO0FBQy9DO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSxzQkFBc0IsK0RBQU07QUFDNUIsQ0FBQyxFOzs7Ozs7Ozs7O0FDWEQseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdGQUFnRixVQUFVO0FBQzFGO0FBQ0EsR0FBRyxLQUFLO0FBQ1I7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQkEseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQy9OO0FBQ2E7QUFDNEI7QUFDVTtBQUNyQjtBQUNIO0FBQ1E7QUFDZjtBQUM5RCxxREFBcUQsb0ZBQW9CO0FBQ3pFLCtCQUErQixrRUFBYztBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ00sa0NBQWtDLGtFQUFjLEVBQUUsMkVBQWdCO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QyxtQkFBbUI7QUFDMUQ7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsU0FBUyxvRkFBb0I7QUFDN0I7QUFDQSxxRUFBcUUsOEVBQWU7QUFDcEYsMEVBQTBFLG9GQUFvQjtBQUN2RixpQ0FBaUMsa0VBQWM7QUFDdEQ7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG1CQUFtQjtBQUMxRDtBQUNBLEdBQUc7QUFDSCxDQUFDO0FBQ0Q7QUFDQSxTQUFTLG9GQUFvQjtBQUM3QjtBQUNPLDBDQUEwQyxrRUFBYyx5REFBeUQsNkVBQWtCO0FBQzFJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0EsMkJBQTJCLGtFQUFjLEVBQUUsb0ZBQWlCO0FBQzVELE1BQU0sNkVBQWlCO0FBQ3ZCLFdBQVcsNkVBQWlCO0FBQzVCO0FBQ0EsU0FBUyw2RUFBaUI7QUFDMUIsQ0FBQztBQUNELHFDQUFxQyxrRUFBYyxFQUFFLGlGQUEwQjtBQUMvRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTSx3QkFBd0Isa0VBQWMsaUVBQWlFLDJGQUFxQztBQUNuSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMseUVBQWtCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQyxFOzs7Ozs7Ozs7Ozs7Ozs7QUMzRnlDO0FBQ25DO0FBQ0E7QUFDQTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLFNBQVMsK0RBQWM7QUFDdkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCd0M7QUFDakM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNBO0FBQ0E7QUFDUDtBQUNPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxXQUFXLGVBQWU7QUFDMUIsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQixXQUFXLFNBQVM7QUFDcEIsWUFBWSxRQUFRO0FBQ3BCO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsU0FBUztBQUMzQjtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSxnR0FBZ0csNERBQUc7QUFDbkc7O0FBRUE7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixhQUFhLFFBQVE7QUFDckI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixTQUFTO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsYUFBYSxRQUFRO0FBQ3JCO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7QUN6Sk87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRTtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9CMEM7QUFDaUM7QUFDSDtBQUNuQjtBQUNFO0FBQzZCO0FBQ0U7QUFDQTtBQUNqQjtBQUM5RDtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sa0dBQTBCO0FBQ2hDO0FBQ0E7QUFDQSxZQUFZLGtHQUEwQjtBQUN0QyxTQUFTLGtHQUEwQjtBQUNuQyxRQUFRLGtHQUEwQjtBQUNsQztBQUNBO0FBQ0EsUUFBUSxrR0FBMEI7QUFDbEM7QUFDQTtBQUNPO0FBQ1AscUJBQXFCLG9HQUEyQjtBQUNoRDtBQUNBLDJCQUEyQixvR0FBMkI7QUFDdEQ7QUFDQTtBQUNBLE1BQU0sb0dBQTJCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBLFNBQVMsb0dBQTJCO0FBQ3BDLFFBQVEsb0dBQTJCO0FBQ25DLGFBQWEsb0dBQTJCO0FBQ3hDO0FBQ0EsUUFBUSxvR0FBMkI7QUFDbkM7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLDJCQUEyQixrR0FBMEI7QUFDckQ7QUFDQTtBQUNBLE1BQU0sa0dBQTBCO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBLFNBQVMsa0dBQTBCO0FBQ25DLFFBQVEsa0dBQTBCO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLHFCQUFxQixvR0FBMkI7QUFDaEQ7QUFDQSwyQkFBMkIsb0dBQTJCO0FBQ3REO0FBQ0E7QUFDQSxNQUFNLG9HQUEyQjtBQUNqQztBQUNBO0FBQ0E7QUFDQSxTQUFTLG9HQUEyQjtBQUNwQyxRQUFRLG9HQUEyQjtBQUNuQyxhQUFhLG9HQUEyQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ0Esc0JBQXNCLGtFQUFjLEVBQUUsMkVBQWdCLEVBQUUsNEVBQWlCLEVBQUUsMkZBQXlCLEdBQUcsb0VBQVk7QUFDMUgsd0JBQXdCLGtFQUFjO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLFNBQVMsMEVBQWU7QUFDeEIsQ0FBQztBQUNNLHdCQUF3QixrRUFBYztBQUM3QztBQUNBO0FBQ0E7QUFDQSxTQUFTLDBFQUFlO0FBQ3hCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ08sMkJBQTJCLGtFQUFjO0FBQ3pDLHVDQUF1QyxrRUFBYywwQ0FBMEMsd0dBQTJCO0FBQzFILDRCQUE0QixrRUFBYztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTSx3Q0FBd0Msa0VBQWMsNENBQTRDLHdHQUEyQjtBQUM3SCx5QkFBeUIsa0VBQWMsRUFBRSxvRkFBaUIsNERBQTRELDJFQUFnQixFQUFFLDRFQUFpQjtBQUNoSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsUUFBUSwwRUFBZTtBQUN2QixRQUFRLDBFQUFlO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEp3QztBQUN6QyxzQkFBc0IsNEJBQVk7QUFDWDtBQUNoQjtBQUNBLGtEOzs7Ozs7Ozs7O0FDSkE7QUFDUDtBQUNBLEM7Ozs7OztBQ0ZBO0FBQ0EseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3pRLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDMUo7QUFDOEI7QUFDMkM7QUFDeEI7QUFDeEI7QUFDQTtBQUNTO0FBQ1M7QUFDWjtBQUNVO0FBQ1Y7QUFDakU7QUFDQTtBQUNBLGlCQUFpQiwrQkFBYyxDQUFDLHVDQUFZO0FBQzVDLHVCQUF1QiwrQkFBYyxDQUFDLDZDQUFrQjtBQUN4RCxpQkFBaUIsK0JBQWM7QUFDL0IsbUJBQW1CLCtCQUFjLENBQUMsMkNBQWdCO0FBQ2xELHFCQUFxQiwrQkFBYyxDQUFDLCtDQUFzQjtBQUMxRCxlQUFlLDZDQUFjO0FBQzdCLGdCQUFnQix5Q0FBVTtBQUMxQixrQkFBa0IsK0JBQWM7QUFDaEMsRUFBRSxtQkFBUztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaLCtEQUErRCwyQkFBMkI7QUFDMUY7QUFDQTtBQUNBLFdBQVc7QUFDWCxpREFBaUQsYUFBYTtBQUM5RCxtREFBbUQscUJBQXFCO0FBQ3hFO0FBQ0EsYUFBYTtBQUNiLFdBQVc7QUFDWCxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBLGlCQUFpQiwyQ0FBa0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLDJDQUFrQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLElBQUksV0FBVyxJQUFJLGtCQUFrQjtBQUNyQztBQUNBLE1BQU0sV0FBVyxLQUFLLGtCQUFrQjtBQUN4QztBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsaUJBQWlCLCtCQUFjLENBQUMsdUNBQVk7QUFDNUMsdUJBQXVCLCtCQUFjLENBQUMsNkNBQWtCO0FBQ3hELGlCQUFpQiwrQkFBYztBQUMvQixFQUFFLG1CQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsZ0RBQXNCO0FBQ3ZDO0FBQ0E7QUFDQSxJQUFJLFdBQVcsSUFBSSxnQkFBZ0I7QUFDbkM7QUFDQSxNQUFNLFdBQVcsS0FBSyxnQkFBZ0I7QUFDdEM7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLGlCQUFpQiwrQkFBYztBQUMvQixFQUFFLG1CQUFTO0FBQ1gsYUFBYSwyQ0FBa0I7QUFDL0IsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxzQkFBc0IsK0JBQWMsVUFBVSwwQ0FBb0I7QUFDbEUsMkJBQTJCLCtCQUFjLENBQUMsNkNBQWtCO0FBQzVELGVBQWUsK0JBQWMsQ0FBQyx1Q0FBWTtBQUMxQyxtQkFBbUIsK0JBQWMsQ0FBQywyQ0FBZ0I7QUFDbEQscUJBQXFCLCtCQUFjLENBQUMsOEJBQThCO0FBQ2xFO0FBQ0EsZ0JBQWdCLHlDQUFVO0FBQzFCLEVBQUUsbUJBQVM7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiwyQ0FBa0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLElBQUksV0FBVyxNQUFNLGtCQUFrQjtBQUN2QyxHQUFHO0FBQ0g7QUFDTztBQUNQLGVBQWUsK0JBQWMsQ0FBQyx1Q0FBWTtBQUMxQywyQkFBMkIsK0JBQWMsQ0FBQyw2Q0FBa0I7QUFDNUQsd0JBQXdCLCtCQUFjO0FBQ3RDLHNCQUFzQiwrQkFBYztBQUNwQyxFQUFFLG1CQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQVcsTUFBTSxnQkFBZ0I7QUFDckMsR0FBRztBQUNILEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pQQSx5QkFBeUIsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsNEJBQTRCLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0Qsc0RBQXNELDhCQUE4QixtSkFBbUoscUVBQXFFLEtBQUs7QUFDNWEsb0NBQW9DLG9FQUFvRSwwREFBMEQ7QUFDbEssNkJBQTZCLG1DQUFtQztBQUNoRSw4QkFBOEIsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDL047QUFDd0I7QUFDa0M7QUFDa0I7QUFDakU7QUFDd0M7QUFDeEI7QUFDMkI7QUFDQTtBQUMwQztBQUNsRDtBQUN2QztBQUNxQztBQUM5QjtBQUNFO0FBQzFELDREQUE0RCwrRUFBZ0I7QUFDNUUsNkRBQTZELG9GQUFvQjtBQUMxRSxnQ0FBZ0Msa0VBQWM7QUFDckQ7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLFdBQVc7QUFDbEQ7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNNO0FBQ1AsU0FBUyxpR0FBaUM7QUFDMUM7QUFDQSx5RUFBeUUsOEVBQWU7QUFDeEYsOEVBQThFLG9GQUFvQjtBQUMzRiwrQkFBK0Isa0VBQWM7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLFdBQVc7QUFDbEQ7QUFDQSxHQUFHO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsU0FBUyxvRkFBb0I7QUFDN0I7QUFDQTtBQUNBLDBDQUEwQyxrRUFBYyxFQUFFLGtGQUEwQjtBQUNwRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTSxnQ0FBZ0Msa0VBQWMsRUFBRSxvRkFBaUI7QUFDeEUsTUFBTSw2RUFBaUI7QUFDdkIsV0FBVyw2RUFBaUI7QUFDNUI7QUFDQSxTQUFTLDZFQUFpQjtBQUMxQixDQUFDO0FBQ00sc0JBQXNCLGtFQUFjLHVEQUF1RCxvRkFBaUI7QUFDbkg7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLDZFQUFpQjtBQUMxQjtBQUNBLEdBQUc7QUFDSCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ087QUFDUCxpQ0FBaUMsa0VBQWMsRUFBRSxvRkFBaUIsRUFBRSxrRkFBMEI7QUFDOUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLDZCQUE2QixrRUFBYyw4QkFBOEIsNEVBQWlCLDJCQUEyQix1RUFBa0I7QUFDdkksNkJBQTZCLGtFQUFjLEVBQUUsb0ZBQWlCLEVBQUUsK0VBQW9CO0FBQzNGO0FBQ0EsbUJBQW1CLHFFQUFTO0FBQzVCO0FBQ0E7QUFDQSx5Q0FBeUMsNkVBQWlCO0FBQzFEO0FBQ0EseUNBQXlDLDZFQUFpQjtBQUMxRCxDQUFDO0FBQ00saUNBQWlDLGtFQUFjLDBCQUEwQiwrRUFBb0IsRUFBRSx1RUFBWSxFQUFFLCtFQUFvQixzRUFBc0UsMkVBQXNCO0FBQzdOLDZCQUE2QixrRUFBYztBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELDhCQUE4QixrRUFBYyxFQUFFLGdGQUF3QixtRkFBbUYsNEVBQVM7QUFDbEsscUNBQXFDLGtFQUFjLDJCQUEyQiwyRkFBcUMsRUFBRSwyRUFBaUIsR0FBRyx5R0FBMkI7QUFDcEssd0JBQXdCLGtFQUFjLDJEQUEyRCxnRkFBcUIsR0FBRyx3RUFBa0I7QUFDM0k7QUFDQSxlQUFlLHdGQUFpQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGtFQUFjLG9FQUFvRSx1RUFBa0I7QUFDMUgsNkJBQTZCLGtFQUFjLG9HQUFvRyxnRkFBMEIsa0VBQWtFLG9GQUFpQixtQkFBbUIsNkVBQWtCO0FBQ3hTO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLFNBQVMsb0ZBQXlCO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILENBQUM7QUFDTSxtQ0FBbUMsa0VBQWMsRUFBRSwyRkFBcUM7QUFDL0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsQ0FBQyxFOzs7Ozs7Ozs7Ozs7OztBQzFMRCx5QkFBeUIsd0JBQXdCLG9DQUFvQyx5Q0FBeUMsa0NBQWtDLDBEQUEwRCwwQkFBMEI7QUFDcFAsNEJBQTRCLGdCQUFnQixzQkFBc0IsT0FBTyxrREFBa0Qsc0RBQXNELDhCQUE4QixtSkFBbUoscUVBQXFFLEtBQUs7QUFDNWEsb0NBQW9DLG9FQUFvRSwwREFBMEQ7QUFDbEssNkJBQTZCLG1DQUFtQztBQUNoRSw4QkFBOEIsMENBQTBDLCtCQUErQixvQkFBb0IsbUNBQW1DLG9DQUFvQyx1RUFBdUU7QUFDL047QUFDdUI7QUFDTztBQUNBO0FBQ3hFO0FBQ08sNkJBQTZCLGtFQUFjLEVBQUUsMkZBQXlCLHNCQUFzQiwyRkFBcUM7QUFDeEk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxJQUFJO0FBQ0osb0VBQW9FO0FBQ3BFLElBQUk7QUFDSjtBQUNBO0FBQ0EsU0FBUyxvRkFBdUI7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7OztBQ2xEeUM7QUFDbkMscUJBQXFCLGtFQUFjO0FBQzFDO0FBQ0EsQ0FBQztBQUNNLHFCQUFxQixrRUFBYztBQUMxQztBQUNBLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7O0FDTkQ7QUFDQSxzQkFBc0Isd0VBQXdFLGdCQUFnQixzQkFBc0IsT0FBTyxzQkFBc0Isb0JBQW9CLGdEQUFnRCxXQUFXO0FBQ2hQLHlCQUF5Qix3QkFBd0Isb0NBQW9DLHlDQUF5QyxrQ0FBa0MsMERBQTBELDBCQUEwQjtBQUNwUCw0QkFBNEIsZ0JBQWdCLHNCQUFzQixPQUFPLGtEQUFrRCxzREFBc0QsOEJBQThCLG1KQUFtSixxRUFBcUUsS0FBSztBQUM1YSxvQ0FBb0Msb0VBQW9FLDBEQUEwRDtBQUNsSyw2QkFBNkIsbUNBQW1DO0FBQ2hFLDhCQUE4QiwwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUN6USwwQ0FBMEMsMEJBQTBCLG1EQUFtRCxvQ0FBb0MseUNBQXlDLFlBQVksY0FBYyx3Q0FBd0MscURBQXFEO0FBQzNULCtDQUErQywwQkFBMEIsWUFBWSx1QkFBdUIsOEJBQThCLG1DQUFtQyxlQUFlO0FBQzdKO0FBQ1E7QUFDSTtBQUNPOztBQUVsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUZBQWlGO0FBQ2pGO0FBQ0EsSUFBSSxJQUFJO0FBQ1I7QUFDQSxJQUFJLElBQUksS0FBSztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ087QUFDUCxzQkFBc0IsZ0RBQW1CLENBQUMsNkRBQUs7QUFDL0M7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsUUFBUSw4REFBUTtBQUNoQiw2QkFBNkIsOERBQVEsV0FBVywrREFBUztBQUN6RDtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsS0FBcUMsR0FBRyxtRUFBUyw2SkFBNkosQ0FBZ0I7QUFDeFA7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7OztBQ3BFMEM7QUFDOEI7QUFDakUsd0JBQXdCLGtFQUFjLEVBQUUsMkZBQXlCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1oyRTtBQUMxQzs7QUFFbEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQix1RUFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLDBEQUFTO0FBQ2hELE9BQU87QUFDUCxlQUFlLDhFQUFrQjtBQUNqQyxLQUFLO0FBQ0w7QUFDQTtBQUNBLG9CQUFvQixtRUFBTyxvQ0FBb0MsMERBQVM7QUFDeEU7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQLGVBQWUsOEVBQWtCO0FBQ2pDLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0ssMEM7Ozs7Ozs7Ozs7O0FDOUxpRTtBQUNqRTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLHVGQUFtQjtBQUMxQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7OztBQ3hCZ0Q7QUFDekM7QUFDUDtBQUNBO0FBQ0EsTUFBTSxnRUFBSztBQUNYO0FBQ0E7QUFDQTtBQUNBLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkEseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQy9OO0FBQ29IO0FBQzVGO0FBQ1I7QUFDQztBQUNVO0FBQ087QUFDZTtBQUN3QjtBQUM5QztBQUNpQjtBQUM1QjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxrRUFBYyxFQUFFLG9GQUE4QjtBQUMzRSx1QkFBdUIsa0VBQWM7QUFDNUM7QUFDQTtBQUNBO0FBQ0EsTUFBTSxvRUFBUztBQUNmO0FBQ0E7QUFDQSxTQUFTLDBFQUFlO0FBQ3hCO0FBQ08sMkJBQTJCLGtFQUFjLEVBQUUsb0ZBQWlCLEVBQUUsb0ZBQThCO0FBQ25HO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0EsZUFBZSx3RkFBaUI7QUFDaEM7QUFDQSxXQUFXLDJFQUFpQjtBQUM1QjtBQUNBLFNBQVMsMkVBQWlCO0FBQzFCO0FBQ087QUFDUCxlQUFlLHdGQUFpQjtBQUNoQztBQUNBLFdBQVcsaUZBQXVCO0FBQ2xDO0FBQ0EsU0FBUyxpRkFBdUI7QUFDaEM7QUFDTztBQUNQO0FBQ0EsbUNBQW1DLDRFQUFTO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDTyx3QkFBd0Isa0VBQWMsd0JBQXdCLDRFQUFpQjtBQUMvRTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHdGQUFpQjtBQUNoQyx5QkFBeUIsbUZBQW9CO0FBQzdDO0FBQ0E7QUFDQSxJQUFJO0FBQ0osbUJBQW1CLG9FQUFTO0FBQzVCO0FBQ0E7QUFDQSxXQUFXLDZFQUFtQjtBQUM5QixZQUFZLG9GQUEwQjtBQUN0QyxJQUFJO0FBQ0osV0FBVyw2RUFBbUI7QUFDOUIsWUFBWSxvRkFBMEI7QUFDdEM7QUFDQSx3Q0FBd0MsNkVBQWlCO0FBQ3pEO0FBQ087QUFDUCxlQUFlLHdGQUFpQjtBQUNoQztBQUNBO0FBQ0EsV0FBVyw2RUFBbUI7QUFDOUIsWUFBWSxvRkFBMEI7QUFDdEMsSUFBSTtBQUNKLFdBQVcsNkVBQW1CO0FBQzlCLFlBQVksb0ZBQTBCO0FBQ3RDO0FBQ0EsU0FBUyw2RUFBaUI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLDBFQUFlO0FBQ2xDO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE1BQU0sdUZBQW1CO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLElBQUk7QUFDSixrQkFBa0IsMEVBQWU7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLHVGQUFtQjtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDTztBQUNQLG1CQUFtQixvRUFBUztBQUM1QjtBQUNBO0FBQ0EsK0VBQStFLFVBQVU7QUFDekYsOENBQThDLG1CQUFtQjtBQUNqRTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ08sNEJBQTRCLGtFQUFjLHFCQUFxQiwrRUFBb0IsRUFBRSx1RUFBWSxFQUFFLCtFQUFvQjtBQUM5SCxxRUFBcUUsNkVBQW1CO0FBQ3hGLHFFQUFxRSw2RUFBbUI7QUFDeEYsaUVBQWlFLG9GQUEwQjtBQUMzRixpRUFBaUUsb0ZBQTBCO0FBQ3BGLHdCQUF3QixrRUFBYztBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1AsOEJBQThCLHlHQUF3QjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLGtFQUFjO0FBQ3JDLDBCQUEwQixrRUFBYyxFQUFFLDJGQUF5QixFQUFFLG1GQUFpQixxR0FBcUcsb0ZBQWlCLEVBQUUsK0ZBQXlDO0FBQzlQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLDZFQUFvQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7OztBQzlReUM7QUFDOEI7QUFDcEI7QUFDSjtBQUN6QztBQUNBLDRCQUE0QixrRUFBYyx1QkFBdUIsMkZBQXlCLEVBQUUsdUVBQVk7QUFDL0c7QUFDQSxLQUFLLG1FQUFRO0FBQ2IsS0FBSyxtRUFBUTtBQUNiLFNBQVMsbUVBQVE7QUFDakIsQ0FBQyxHOzs7Ozs7Ozs7O0FDVk0sdUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBUDtBQUNBLDBDQUEwQywwQkFBMEIsbURBQW1ELG9DQUFvQyx5Q0FBeUMsWUFBWSxjQUFjLHdDQUF3QyxxREFBcUQ7QUFDM1QsK0NBQStDLDBCQUEwQixZQUFZLHVCQUF1Qiw4QkFBOEIsbUNBQW1DLGVBQWU7QUFDNUwseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQzFPO0FBQ3NCO0FBQ087QUFDYjtBQUNBO0FBQ047QUFDRTtBQUNBOztBQUUzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHVDQUF1QztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQSwwQkFBMEIsZ0RBQW1CLENBQUMsZ0VBQVM7QUFDdkQ7QUFDQSwwQkFBMEIsZ0RBQW1CLENBQUMsZ0VBQVM7QUFDdkQ7QUFDQSwwQkFBMEIsZ0RBQW1CLENBQUMsMERBQU07QUFDcEQ7QUFDQTtBQUNBLDRCQUE0QixnREFBbUIsQ0FBQyw0REFBTztBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLG1CQUFtQixxREFBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQSxtQkFBbUIscURBQWM7QUFDakMseUJBQXlCLG1EQUFZLHVDQUF1QztBQUM1RSxJQUFJO0FBQ0o7QUFDQSxJQUFJLFNBQVMsc0VBQWE7QUFDMUI7QUFDQSx5QkFBeUIsZ0RBQW1CO0FBQzVDO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsSUFBSTtBQUNKO0FBQ0EseUJBQXlCLGdEQUFtQjtBQUM1QztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3QkFBd0IsZ0RBQW1CLENBQUMsNERBQUs7QUFDakQ7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEM7Ozs7Ozs7Ozs7Ozs7QUNqR0EseUJBQXlCLHdCQUF3QixvQ0FBb0MseUNBQXlDLGtDQUFrQywwREFBMEQsMEJBQTBCO0FBQ3BQLDRCQUE0QixnQkFBZ0Isc0JBQXNCLE9BQU8sa0RBQWtELHNEQUFzRCw4QkFBOEIsbUpBQW1KLHFFQUFxRSxLQUFLO0FBQzVhLG9DQUFvQyxvRUFBb0UsMERBQTBEO0FBQ2xLLDZCQUE2QixtQ0FBbUM7QUFDaEUsOEJBQThCLDBDQUEwQywrQkFBK0Isb0JBQW9CLG1DQUFtQyxvQ0FBb0MsdUVBQXVFO0FBQ3ZPO0FBQ0k7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0M7QUFDcEMsc0JBQXNCLHdEQUFRO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLDZDQUE2QyxvREFBTTtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08scURBQXFEOztBQUU1RDtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBLENBQUMsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUhNO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2RDs7Ozs7Ozs7OztBQ1JBLGlFOzs7Ozs7Ozs7Ozs7QUNBa0Y7QUFDNUI7O0FBRTdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQSxJQUFJOztBQUVKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLHdHQUF3QjtBQUNsRDtBQUNBLDRGQUE0Riw2RUFBaUI7QUFDN0cseUJBQXlCLDZFQUFpQjtBQUMxQztBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0EsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEMEM7QUFDSTtBQUNKO0FBQzBFO0FBQ3ZEO0FBQzJCO0FBQ2pDO0FBQ2M7QUFDRztBQUNHO0FBQ1A7QUFDd0I7QUFDVjtBQUNjO0FBQ007QUFDeEI7QUFDcEI7QUFDZ0I7QUFDWDtBQUN4RDtBQUNQLFNBQVMsK0RBQWMsQ0FBQywwRUFBZTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNPLGdDQUFnQyxrRUFBYyxDQUFDLCtFQUFzQixXQUFXLCtEQUFNO0FBQ3RGLG9DQUFvQyxrRUFBYyxFQUFFLDZFQUFrQix3REFBd0QsK0dBQThCO0FBQzVKLHdCQUF3QixrRUFBYyxpQ0FBaUMsbUZBQTBCLEdBQUcscUdBQXlCO0FBQzdIO0FBQ1A7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLGlGQUFrQjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08seUNBQXlDLGtFQUFjLEVBQUUsNkVBQWtCLHdEQUF3RCx5SEFBbUM7QUFDdEssc0NBQXNDLGtFQUFjLEVBQUUsMkVBQWdCLEVBQUUsNEVBQWlCLEVBQUUsb0ZBQWlCLEVBQUUsMkZBQXlCLEVBQUUsK0VBQXNCLHdEQUF3RCxpR0FBNEIsR0FBRyxtSEFBZ0M7QUFDdFIsNkJBQTZCLGtFQUFjO0FBQ2xEO0FBQ0E7QUFDQSxDQUFDO0FBQ00sd0JBQXdCLGtFQUFjLENBQUMsK0VBQXNCLHFCQUFxQix1RkFBa0I7QUFDcEcsMkJBQTJCLGtFQUFjLHlEQUF5RCxnRkFBMEIsRUFBRSxrRkFBd0IscUJBQXFCLGlHQUE0Qix5QkFBeUIsNkZBQXFCO0FBQ3JQLDRCQUE0QixrRUFBYztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTTtBQUNQO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixtRUFBTztBQUN4QjtBQUNBO0FBQ0E7QUFDQSxZQUFZLCtFQUFtQjtBQUMvQixvQkFBb0Isb0ZBQXdCO0FBQzVDLHlCQUF5QiwrRUFBbUI7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7O0FDekVBLHlCQUF5Qix3QkFBd0Isb0NBQW9DLHlDQUF5QyxrQ0FBa0MsMERBQTBELDBCQUEwQjtBQUNwUCw0QkFBNEIsZ0JBQWdCLHNCQUFzQixPQUFPLGtEQUFrRCxzREFBc0QsOEJBQThCLG1KQUFtSixxRUFBcUUsS0FBSztBQUM1YSxvQ0FBb0Msb0VBQW9FLDBEQUEwRDtBQUNsSyw2QkFBNkIsbUNBQW1DO0FBQ2hFLDhCQUE4QiwwQ0FBMEMsK0JBQStCLG9CQUFvQixtQ0FBbUMsb0NBQW9DLHVFQUF1RTtBQUM5TTtBQUNtQjtBQUMxQjtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQSw0Q0FBNEMsbUVBQVM7QUFDckQ7QUFDQTtBQUNBLDZGQUE2RjtBQUM3RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QiwyRUFBZ0I7QUFDdkMsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGVBQWU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULGlCQUFpQiwyRUFBZTtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQiw2RUFBaUI7QUFDbEM7QUFDQSxTQUFTO0FBQ1QsT0FBTztBQUNQLE1BQU07QUFDTjtBQUNBO0FBQ0EsZUFBZSwyRUFBZTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsNkVBQWlCO0FBQ2hDO0FBQ0Esb0NBQW9DLDZFQUFpQjtBQUNyRCxPQUFPO0FBQ1A7QUFDQTtBQUNBLEdBQUc7QUFDSCxFOzs7Ozs7Ozs7Ozs7O0FDN0crQzs7QUFFL0M7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQix1RUFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDTTtBQUNBO0FBQ1A7QUFDQSxFQUFFLHlCOzs7Ozs7Ozs7Ozs7O0FDdkN3QztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTzs7QUFFUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sNENBQTRDLGtFQUFjO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNNO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9jb21iaW5lcnMvY29tYmluZUNvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXguanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvQ29uc3RhbnRzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvY29udGFpbmVyU2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvbnVtYmVyRG9tYWluRXF1YWxpdHlDaGVjay5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvbW91c2VFdmVudHNNaWRkbGV3YXJlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS90eXBlcy9TdGFja2VkR3JhcGhpY2FsSXRlbS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL2F4aXNTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvQ2FydGVzaWFuVXRpbHMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwQXhpc1R5cGUuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9wb2xhckdyaWRTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwUGF5bG9hZFNlYXJjaGVyLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvcGllU2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvcG9sYXJTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9jb21iaW5lcnMvY29tYmluZUF4aXNSYW5nZVdpdGhSZXZlcnNlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9wb2xhck9wdGlvbnNTbGljZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL2NvbWJpbmVycy9jb21iaW5lVG9vbHRpcEludGVyYWN0aW9uU3RhdGUuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RBY3RpdmVQcm9wc0Zyb21DaGFydFBvaW50ZXIuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy90b3VjaFNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvdG91Y2hFdmVudHNNaWRkbGV3YXJlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvYXJyYXlFcXVhbGl0eUNoZWNrLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0VG9vbHRpcFN0YXRlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvYXJlYVNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvcmVmZXJlbmNlRWxlbWVudHNTbGljZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvb3B0aW9uc1NsaWNlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvcG9sYXJTY2FsZVNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3NlbGVjdFRvb2x0aXBTZXR0aW5ncy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3Rvb2x0aXBTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvQ2hhcnRVdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwQXhpcy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3NjYXR0ZXJTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9zZWxlY3RQbG90QXJlYS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3BpY2tBeGlzVHlwZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvcG9sYXJBeGlzU2xpY2UuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3JlZHV4RGV2dG9vbHNKc29uU3RyaW5naWZ5UmVwbGFjZXIuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3N0b3JlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvbGluZVNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL2xlZ2VuZFNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9Dc3NQcmVmaXhVdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3JhZGFyU2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0VG9vbHRpcEV2ZW50VHlwZS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9EYXRhVXRpbHMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9jb21iaW5lcnMvY29tYmluZVRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9wb2xhckF4aXNTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvRXZlbnRzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zeW5jaHJvbmlzYXRpb24vc3luY1NlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3luY2hyb25pc2F0aW9uL3VzZUNoYXJ0U3luY2hyb25pc2F0aW9uLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvcmFkaWFsQmFyU2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvZnVubmVsU2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0QWxsQXhlcy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9CYXJVdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3NlbGVjdENoYXJ0T2Zmc2V0LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS90b29sdGlwU2xpY2UuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9jb21iaW5lcnMvY29tYmluZUFjdGl2ZVRvb2x0aXBJbmRleC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL2NvbWJpbmVycy9jb21iaW5lQWN0aXZlTGFiZWwuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9iYXJTZWxlY3RvcnMuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9icnVzaFNlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3BpY2tBeGlzSWQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3V0aWwvQWN0aXZlU2hhcGVVdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvdXRpbC9ET01VdGlscy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3Jvb3RQcm9wc1NlbGVjdG9ycy5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvc2VsZWN0b3JzL3NlbGVjdFRvb2x0aXBBeGlzSWQuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9jb21iaW5lcnMvY29tYmluZURpc3BsYXllZFN0YWNrZWREYXRhLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvc2VsZWN0b3JzLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL3JlY2hhcnRzL2VzNi9zdGF0ZS9zZWxlY3RvcnMvY29tYmluZXJzL2NvbWJpbmVUb29sdGlwUGF5bG9hZC5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9yZWNoYXJ0cy9lczYvc3RhdGUvcm9vdFByb3BzU2xpY2UuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvcmVjaGFydHMvZXM2L3N0YXRlL3NlbGVjdG9ycy9kYXRhU2VsZWN0b3JzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB2YXIgY29tYmluZUNvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXggPSAod2lkdGgsIGhlaWdodCwgbGF5b3V0LCBvZmZzZXQsIHRvb2x0aXBUaWNrcywgZGVmYXVsdEluZGV4LCB0b29sdGlwQ29uZmlndXJhdGlvbnMsIHRvb2x0aXBQYXlsb2FkU2VhcmNoZXIpID0+IHtcbiAgaWYgKGRlZmF1bHRJbmRleCA9PSBudWxsIHx8IHRvb2x0aXBQYXlsb2FkU2VhcmNoZXIgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gV2l0aCBkZWZhdWx0SW5kZXggYWxvbmUsIHdlIGRvbid0IGhhdmUgZW5vdWdoIGluZm9ybWF0aW9uIHRvIGRlY2lkZSBfd2hpY2hfIG9mIHRoZSBtdWx0aXBsZSB0b29sdGlwcyB0byBkaXNwbGF5LiBTbyB3ZSBjaG9vc2UgdGhlIGZpcnN0IG9uZS5cbiAgdmFyIGZpcnN0Q29uZmlndXJhdGlvbiA9IHRvb2x0aXBDb25maWd1cmF0aW9uc1swXTtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB3ZSBuZWVkIHRvIHJldGhpbmsgdGhlIHRvb2x0aXBQYXlsb2FkU2VhcmNoZXIgdHlwZVxuICB2YXIgbWF5YmVQb3NpdGlvbiA9IGZpcnN0Q29uZmlndXJhdGlvbiA9PSBudWxsID8gdW5kZWZpbmVkIDogdG9vbHRpcFBheWxvYWRTZWFyY2hlcihmaXJzdENvbmZpZ3VyYXRpb24ucG9zaXRpb25zLCBkZWZhdWx0SW5kZXgpO1xuICBpZiAobWF5YmVQb3NpdGlvbiAhPSBudWxsKSB7XG4gICAgcmV0dXJuIG1heWJlUG9zaXRpb247XG4gIH1cbiAgdmFyIHRpY2sgPSB0b29sdGlwVGlja3MgPT09IG51bGwgfHwgdG9vbHRpcFRpY2tzID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0b29sdGlwVGlja3NbTnVtYmVyKGRlZmF1bHRJbmRleCldO1xuICBpZiAoIXRpY2spIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHN3aXRjaCAobGF5b3V0KSB7XG4gICAgY2FzZSAnaG9yaXpvbnRhbCc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgeDogdGljay5jb29yZGluYXRlLFxuICAgICAgICAgIHk6IChvZmZzZXQudG9wICsgaGVpZ2h0KSAvIDJcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAge1xuICAgICAgICAvLyBUaGlzIGxvZ2ljIGlzIG5vdCBzdXBlciBzb3VuZCAtIGl0IGNvbmZsYXRlcyB2ZXJ0aWNhbCwgcmFkaWFsLCBjZW50cmljIGxheW91dHMgaW50byBqdXN0IG9uZS4gVE9ETyBpbXByb3ZlIVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHg6IChvZmZzZXQubGVmdCArIHdpZHRoKSAvIDIsXG4gICAgICAgICAgeTogdGljay5jb29yZGluYXRlXG4gICAgICAgIH07XG4gICAgICB9XG4gIH1cbn07IiwiZXhwb3J0IHZhciBDT0xPUl9QQU5FTCA9IFsnIzE4OTBGRicsICcjNjZCNUZGJywgJyM0MUQ5QzcnLCAnIzJGQzI1QicsICcjNkVEQjhGJywgJyM5QUU2NUMnLCAnI0ZBQ0MxNCcsICcjRTY5NjVDJywgJyM1N0FENzEnLCAnIzIyMzI3MycsICcjNzM4QUU2JywgJyM3NTY0Q0MnLCAnIzg1NDNFMCcsICcjQTg3N0VEJywgJyM1QzhFRTYnLCAnIzEzQzJDMicsICcjNzBFMEUwJywgJyM1Q0EzRTYnLCAnIzM0MzZDNycsICcjODA4MkZGJywgJyNERDgxRTYnLCAnI0YwNDg2NCcsICcjRkE3RDkyJywgJyNENTk4RDknXTtcblxuLyoqXG4gKiBXZSB1c2UgdGhpcyBhdHRyaWJ1dGUgdG8gaWRlbnRpZnkgd2hpY2ggZWxlbWVudCBpcyB0aGUgb25lIHRoYXQgdGhlIHVzZXIgaXMgdG91Y2hpbmcuXG4gKiBUaGUgaW5kZXggaXMgdGhlIHBvc2l0aW9uIG9mIHRoZSBlbGVtZW50IGluIHRoZSBkYXRhIGFycmF5LlxuICogVGhpcyBjYW4gYmUgZWl0aGVyIGEgbnVtYmVyIChmb3IgYXJyYXktYmFzZWQgY2hhcnRzKSBvciBhIHN0cmluZyAoZm9yIHRoZSBjaGFydHMgdGhhdCBoYXZlIGEgbWF0cml4LXNoYXBlZCBkYXRhKS5cbiAqL1xuZXhwb3J0IHZhciBEQVRBX0lURU1fSU5ERVhfQVRUUklCVVRFX05BTUUgPSAnZGF0YS1yZWNoYXJ0cy1pdGVtLWluZGV4Jztcbi8qKlxuICogV2UgdXNlIHRoaXMgYXR0cmlidXRlIHRvIGlkZW50aWZ5IHdoaWNoIGVsZW1lbnQgaXMgdGhlIG9uZSB0aGF0IHRoZSB1c2VyIGlzIHRvdWNoaW5nLlxuICogRGF0YUtleSB3b3JrcyBoZXJlIGFzIGEga2luZCBvZiBpZGVudGlmaWVyIGZvciB0aGUgZWxlbWVudC4gSXQncyBub3QgYSBwZXJmZWN0IGlkZW50aWZpZXIgZm9yIH50d29+IHRocmVlIHJlYXNvbnM6XG4gKlxuICogMS4gVGhlcmUgY2FuIGJlIHR3byBkaWZmZXJlbnQgZWxlbWVudHMgd2l0aCB0aGUgc2FtZSBkYXRhS2V5OyB3ZSB3b24ndCBrbm93IHdoaWNoIGlzIGl0XG4gKiAyLiBEYXRhS2V5IGNhbiBiZSBhIGZ1bmN0aW9uLCBhbmQgdGhhdCBzZXJpYWxpemVkIHdpbGwgYmUgYSBgW0Z1bmN0aW9uOiBhbm9ueW1vdXNdYCBzdHJpbmdcbiAqIHdoaWNoIG1lYW5zIHdlIHdpbGwgYmUgYWJsZSB0byBpZGVudGlmeSB0aGF0IGl0IHdhcyBhIGZ1bmN0aW9uIGJ1dCBjYW4ndCB0ZWxsIHdoaWNoIG9uZS5cbiAqIFRoaXMgd2lsbCBsZWFkIHRvIHNvbWUgd2VpcmQgYnVncy4gQSBwcm9wZXIgZml4IHdvdWxkIGJlIHRvIGVpdGhlcjpcbiAqIGEpIHVzZSBhIHVuaXF1ZSBpZGVudGlmaWVyIGZvciBlYWNoIGVsZW1lbnQgKHBhc3NlZCBmcm9tIHByb3BzLCBvciBnZW5lcmF0ZWQpXG4gKiBiKSBmaWd1cmUgb3V0IGhvdyB0byBjb21wYXJlIHRoZSBkYXRhS2V5IG9yIGdyYXBoaWNhbCBpdGVtIGJ5IG9iamVjdCByZWZlcmVuY2VcbiAqXG4gKiBhKSBpcyBhIGZ1c3MgYmVjYXVzZSB3ZSBkb24ndCBoYXZlIHRoZSB1bmlxdWUgaWRlbnRpZmllciBpbiBwcm9wcyxcbiAqIGFuZCBiKSBpcyBwb3NzaWJsZSBtb3N0IG9mIHRoZSB0aW1lIGV4Y2VwdCBmb3IgdG91Y2hNb3ZlIGV2ZW50cyB3aGljaCB3b3JrIGRpZmZlcmVudGx5IGZyb20gbW91c2VFbnRlci9tb3VzZUxlYXZlOlxuICogLSB3aGlsZSBtb3VzZUVudGVyIGlzIGZpcmVkIGZvciB0aGUgZWxlbWVudCB0aGF0IHRoZSBtb3VzZSBpcyBvdmVyLFxuICogdG91Y2hNb3ZlIGlzIGZpcmVkIGZvciB0aGUgZWxlbWVudCB3aGVyZSB1c2VyIGhhcyBzdGFydGVkIHRvdWNoaW5nLiBBcyB0aGUgZmluZ2VyIG1vdmVzLFxuICogd2UgY2FuIGlkZW50aWZ5IHRoZSBlbGVtZW50IHRoYXQgdGhlIHVzZXIgaXMgdG91Y2hpbmcgYnkgdXNpbmcgdGhlIGVsZW1lbnRGcm9tUG9pbnQgbWV0aG9kLFxuICogYnV0IGl0IGtlZXBzIGNhbGxpbmcgdGhlIGhhbmRsZXIgb24gdGhlIGVsZW1lbnQgd2hlcmUgdG91Y2hTdGFydCB3YXMgZmlyZWQuXG4gKlxuICogT2theSBhbmQgbm93IEkgZGlzY292ZXJlZCBhIHRoaXJkIHJlYXNvbjogdGhlIGRhdGFLZXkgY2FuIGJlIHVuZGVmaW5lZCBhbmQgdGhhdCdzIHN0aWxsIGZpbmVcbiAqIGJlY2F1c2UgaWYgZGF0YUtleSBpcyB1bmRlZmluZWQgdGhlbiBncmFwaGljYWwgZWxlbWVudHMgYXNzdW1lIHRoZSBkYXRhS2V5IG9mIHRoZSBheGVzLlxuICogV2hpY2ggbWFrZXMgaXQgYSBjb252ZW5pZW50IHdheSBvZiB1c2luZyByZWNoYXJ0cyB0byByZW5kZXIgYSBjaGFydCBidXQgaG9ycmlibGUgaWRlbnRpZmllci5cbiAqL1xuZXhwb3J0IHZhciBEQVRBX0lURU1fREFUQUtFWV9BVFRSSUJVVEVfTkFNRSA9ICdkYXRhLXJlY2hhcnRzLWl0ZW0tZGF0YS1rZXknO1xuZXhwb3J0IHZhciBERUZBVUxUX1lfQVhJU19XSURUSCA9IDYwOyIsImV4cG9ydCB2YXIgc2VsZWN0Q2hhcnRXaWR0aCA9IHN0YXRlID0+IHN0YXRlLmxheW91dC53aWR0aDtcbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnRIZWlnaHQgPSBzdGF0ZSA9PiBzdGF0ZS5sYXlvdXQuaGVpZ2h0O1xuZXhwb3J0IHZhciBzZWxlY3RDb250YWluZXJTY2FsZSA9IHN0YXRlID0+IHN0YXRlLmxheW91dC5zY2FsZTtcbmV4cG9ydCB2YXIgc2VsZWN0TWFyZ2luID0gc3RhdGUgPT4gc3RhdGUubGF5b3V0Lm1hcmdpbjsiLCJleHBvcnQgdmFyIG51bWJlckRvbWFpbkVxdWFsaXR5Q2hlY2sgPSAoYSwgYikgPT4ge1xuICBpZiAoYSA9PT0gYikge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChhID09IG51bGwgfHwgYiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBhWzBdID09PSBiWzBdICYmIGFbMV0gPT09IGJbMV07XG59OyIsImltcG9ydCB7IGNyZWF0ZUFjdGlvbiwgY3JlYXRlTGlzdGVuZXJNaWRkbGV3YXJlIH0gZnJvbSAnQHJlZHV4anMvdG9vbGtpdCc7XG5pbXBvcnQgeyBtb3VzZUxlYXZlQ2hhcnQsIHNldE1vdXNlQ2xpY2tBeGlzSW5kZXgsIHNldE1vdXNlT3ZlckF4aXNJbmRleCB9IGZyb20gJy4vdG9vbHRpcFNsaWNlJztcbmltcG9ydCB7IHNlbGVjdEFjdGl2ZVByb3BzRnJvbUNoYXJ0UG9pbnRlciB9IGZyb20gJy4vc2VsZWN0b3JzL3NlbGVjdEFjdGl2ZVByb3BzRnJvbUNoYXJ0UG9pbnRlcic7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwRXZlbnRUeXBlIH0gZnJvbSAnLi9zZWxlY3RvcnMvc2VsZWN0VG9vbHRpcEV2ZW50VHlwZSc7XG5pbXBvcnQgeyBnZXRDaGFydFBvaW50ZXIgfSBmcm9tICcuLi91dGlsL2dldENoYXJ0UG9pbnRlcic7XG5leHBvcnQgdmFyIG1vdXNlQ2xpY2tBY3Rpb24gPSBjcmVhdGVBY3Rpb24oJ21vdXNlQ2xpY2snKTtcbmV4cG9ydCB2YXIgbW91c2VDbGlja01pZGRsZXdhcmUgPSBjcmVhdGVMaXN0ZW5lck1pZGRsZXdhcmUoKTtcblxuLy8gVE9ETzogdGhlcmUncyBhIGJ1ZyBoZXJlIHdoZW4geW91IGNsaWNrIHRoZSBjaGFydCB0aGUgYWN0aXZlSW5kZXggcmVzZXRzIHRvIHplcm9cbm1vdXNlQ2xpY2tNaWRkbGV3YXJlLnN0YXJ0TGlzdGVuaW5nKHtcbiAgYWN0aW9uQ3JlYXRvcjogbW91c2VDbGlja0FjdGlvbixcbiAgZWZmZWN0OiAoYWN0aW9uLCBsaXN0ZW5lckFwaSkgPT4ge1xuICAgIHZhciBtb3VzZVBvaW50ZXIgPSBhY3Rpb24ucGF5bG9hZDtcbiAgICB2YXIgYWN0aXZlUHJvcHMgPSBzZWxlY3RBY3RpdmVQcm9wc0Zyb21DaGFydFBvaW50ZXIobGlzdGVuZXJBcGkuZ2V0U3RhdGUoKSwgZ2V0Q2hhcnRQb2ludGVyKG1vdXNlUG9pbnRlcikpO1xuICAgIGlmICgoYWN0aXZlUHJvcHMgPT09IG51bGwgfHwgYWN0aXZlUHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGFjdGl2ZVByb3BzLmFjdGl2ZUluZGV4KSAhPSBudWxsKSB7XG4gICAgICBsaXN0ZW5lckFwaS5kaXNwYXRjaChzZXRNb3VzZUNsaWNrQXhpc0luZGV4KHtcbiAgICAgICAgYWN0aXZlSW5kZXg6IGFjdGl2ZVByb3BzLmFjdGl2ZUluZGV4LFxuICAgICAgICBhY3RpdmVEYXRhS2V5OiB1bmRlZmluZWQsXG4gICAgICAgIGFjdGl2ZUNvb3JkaW5hdGU6IGFjdGl2ZVByb3BzLmFjdGl2ZUNvb3JkaW5hdGVcbiAgICAgIH0pKTtcbiAgICB9XG4gIH1cbn0pO1xuZXhwb3J0IHZhciBtb3VzZU1vdmVBY3Rpb24gPSBjcmVhdGVBY3Rpb24oJ21vdXNlTW92ZScpO1xuZXhwb3J0IHZhciBtb3VzZU1vdmVNaWRkbGV3YXJlID0gY3JlYXRlTGlzdGVuZXJNaWRkbGV3YXJlKCk7XG5tb3VzZU1vdmVNaWRkbGV3YXJlLnN0YXJ0TGlzdGVuaW5nKHtcbiAgYWN0aW9uQ3JlYXRvcjogbW91c2VNb3ZlQWN0aW9uLFxuICBlZmZlY3Q6IChhY3Rpb24sIGxpc3RlbmVyQXBpKSA9PiB7XG4gICAgdmFyIG1vdXNlUG9pbnRlciA9IGFjdGlvbi5wYXlsb2FkO1xuICAgIHZhciBzdGF0ZSA9IGxpc3RlbmVyQXBpLmdldFN0YXRlKCk7XG4gICAgdmFyIHRvb2x0aXBFdmVudFR5cGUgPSBzZWxlY3RUb29sdGlwRXZlbnRUeXBlKHN0YXRlLCBzdGF0ZS50b29sdGlwLnNldHRpbmdzLnNoYXJlZCk7XG4gICAgdmFyIGFjdGl2ZVByb3BzID0gc2VsZWN0QWN0aXZlUHJvcHNGcm9tQ2hhcnRQb2ludGVyKHN0YXRlLCBnZXRDaGFydFBvaW50ZXIobW91c2VQb2ludGVyKSk7XG5cbiAgICAvLyB0aGlzIGZ1bmN0aW9uYWxpdHkgb25seSBhcHBsaWVzIHRvIGNoYXJ0cyB0aGF0IGhhdmUgYXhlc1xuICAgIGlmICh0b29sdGlwRXZlbnRUeXBlID09PSAnYXhpcycpIHtcbiAgICAgIGlmICgoYWN0aXZlUHJvcHMgPT09IG51bGwgfHwgYWN0aXZlUHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGFjdGl2ZVByb3BzLmFjdGl2ZUluZGV4KSAhPSBudWxsKSB7XG4gICAgICAgIGxpc3RlbmVyQXBpLmRpc3BhdGNoKHNldE1vdXNlT3ZlckF4aXNJbmRleCh7XG4gICAgICAgICAgYWN0aXZlSW5kZXg6IGFjdGl2ZVByb3BzLmFjdGl2ZUluZGV4LFxuICAgICAgICAgIGFjdGl2ZURhdGFLZXk6IHVuZGVmaW5lZCxcbiAgICAgICAgICBhY3RpdmVDb29yZGluYXRlOiBhY3RpdmVQcm9wcy5hY3RpdmVDb29yZGluYXRlXG4gICAgICAgIH0pKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIHRoaXMgaXMgbmVlZGVkIHRvIGNsZWFyIHRvb2x0aXAgc3RhdGUgd2hlbiB0aGUgbW91c2UgbW92ZXMgb3V0IG9mIHRoZSBpblJhbmdlIChzdmcgLSBvZmZzZXQpIGZ1bmN0aW9uLCBidXQgbm90IHlldCBvdXQgb2YgdGhlIHN2Z1xuICAgICAgICBsaXN0ZW5lckFwaS5kaXNwYXRjaChtb3VzZUxlYXZlQ2hhcnQoKSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59KTsiLCIvKipcbiAqIFNvbWUgZ3JhcGhpY2FsIGl0ZW1zIGFsbG93IGRhdGEgc3RhY2tpbmcuIFRoZSBzdGFja3MgYXJlIG9wdGlvbmFsLFxuICogc28gYWxsIHByb3BzIGhlcmUgYXJlIG9wdGlvbmFsIHRvby5cbiAqL1xuXG4vKipcbiAqIFNvbWUgZ3JhcGhpY2FsIGl0ZW1zIGFsbG93IGRhdGEgc3RhY2tpbmcuXG4gKiBUaGlzIGludGVyZmFjZSBpcyB1c2VkIHRvIHJlcHJlc2VudCB0aGUgaXRlbXMgdGhhdCBhcmUgc3RhY2tlZFxuICogYmVjYXVzZSB0aGUgdXNlciBoYXMgcHJvdmlkZWQgdGhlIHN0YWNrSWQgYW5kIGRhdGFLZXkgcHJvcGVydGllcy5cbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gaXNTdGFja2VkKGdyYXBoaWNhbEl0ZW0pIHtcbiAgcmV0dXJuIGdyYXBoaWNhbEl0ZW0uc3RhY2tJZCAhPSBudWxsICYmIGdyYXBoaWNhbEl0ZW0uZGF0YUtleSAhPSBudWxsO1xufSIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5pbXBvcnQgcmFuZ2UgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvcmFuZ2UnO1xuaW1wb3J0ICogYXMgZDNTY2FsZXMgZnJvbSAndmljdG9yeS12ZW5kb3IvZDMtc2NhbGUnO1xuaW1wb3J0IHsgaXNOb3ROaWwgfSBmcm9tICdlcy10b29sa2l0JztcbmltcG9ydCB7IHNlbGVjdENoYXJ0TGF5b3V0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9jaGFydExheW91dENvbnRleHQnO1xuaW1wb3J0IHsgY2hlY2tEb21haW5PZlNjYWxlLCBnZXREb21haW5PZlN0YWNrR3JvdXBzLCBnZXRTdGFja2VkRGF0YSwgZ2V0VmFsdWVCeURhdGFLZXksIGlzQ2F0ZWdvcmljYWxBeGlzIH0gZnJvbSAnLi4vLi4vdXRpbC9DaGFydFV0aWxzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzLCBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlc0lmTm90SW5QYW5vcmFtYSB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBpc1dlbGxGb3JtZWROdW1iZXJEb21haW4sIG51bWVyaWNhbERvbWFpblNwZWNpZmllZFdpdGhvdXRSZXF1aXJpbmdEYXRhLCBwYXJzZU51bWVyaWNhbFVzZXJEb21haW4gfSBmcm9tICcuLi8uLi91dGlsL2lzRG9tYWluU3BlY2lmaWVkQnlVc2VyJztcbmltcG9ydCB7IGdldFBlcmNlbnRWYWx1ZSwgaGFzRHVwbGljYXRlLCBpc05hbiwgaXNOdW1iZXIsIGlzTnVtT3JTdHIsIG1hdGhTaWduLCB1cHBlckZpcnN0IH0gZnJvbSAnLi4vLi4vdXRpbC9EYXRhVXRpbHMnO1xuaW1wb3J0IHsgaXNXZWxsQmVoYXZlZE51bWJlciB9IGZyb20gJy4uLy4uL3V0aWwvaXNXZWxsQmVoYXZlZE51bWJlcic7XG5pbXBvcnQgeyBnZXROaWNlVGlja1ZhbHVlcywgZ2V0VGlja1ZhbHVlc0ZpeGVkRG9tYWluIH0gZnJvbSAnLi4vLi4vdXRpbC9zY2FsZSc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydEhlaWdodCwgc2VsZWN0Q2hhcnRXaWR0aCB9IGZyb20gJy4vY29udGFpbmVyU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdEFsbFhBeGVzLCBzZWxlY3RBbGxZQXhlcyB9IGZyb20gJy4vc2VsZWN0QWxsQXhlcyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE9mZnNldEludGVybmFsIH0gZnJvbSAnLi9zZWxlY3RDaGFydE9mZnNldEludGVybmFsJztcbmltcG9ydCB7IHNlbGVjdEJydXNoRGltZW5zaW9ucywgc2VsZWN0QnJ1c2hTZXR0aW5ncyB9IGZyb20gJy4vYnJ1c2hTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0QmFyQ2F0ZWdvcnlHYXAsIHNlbGVjdENoYXJ0TmFtZSwgc2VsZWN0U3RhY2tPZmZzZXRUeXBlIH0gZnJvbSAnLi9yb290UHJvcHNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0QW5nbGVBeGlzLCBzZWxlY3RBbmdsZUF4aXNSYW5nZSwgc2VsZWN0UmFkaXVzQXhpcywgc2VsZWN0UmFkaXVzQXhpc1JhbmdlIH0gZnJvbSAnLi9wb2xhckF4aXNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgcGlja0F4aXNUeXBlIH0gZnJvbSAnLi9waWNrQXhpc1R5cGUnO1xuaW1wb3J0IHsgcGlja0F4aXNJZCB9IGZyb20gJy4vcGlja0F4aXNJZCc7XG5pbXBvcnQgeyBjb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UnO1xuaW1wb3J0IHsgREVGQVVMVF9ZX0FYSVNfV0lEVEggfSBmcm9tICcuLi8uLi91dGlsL0NvbnN0YW50cyc7XG5pbXBvcnQgeyBnZXRTdGFja1Nlcmllc0lkZW50aWZpZXIgfSBmcm9tICcuLi8uLi91dGlsL3N0YWNrcy9nZXRTdGFja1Nlcmllc0lkZW50aWZpZXInO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcEF4aXMgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBBeGlzJztcbmltcG9ydCB7IGNvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSB9IGZyb20gJy4vY29tYmluZXJzL2NvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSc7XG5pbXBvcnQgeyBpc1N0YWNrZWQgfSBmcm9tICcuLi90eXBlcy9TdGFja2VkR3JhcGhpY2FsSXRlbSc7XG5pbXBvcnQgeyBudW1iZXJEb21haW5FcXVhbGl0eUNoZWNrIH0gZnJvbSAnLi9udW1iZXJEb21haW5FcXVhbGl0eUNoZWNrJztcbmltcG9ydCB7IGFycmF5RXF1YWxpdHlDaGVjayB9IGZyb20gJy4vYXJyYXlFcXVhbGl0eUNoZWNrJztcbnZhciBkZWZhdWx0TnVtZXJpY0RvbWFpbiA9IFswLCAnYXV0byddO1xuXG4vKipcbiAqIGFuZ2xlLCByYWRpdXMsIFgsIFksIGFuZCBaIGF4ZXMgYWxsIGhhdmUgZG9tYWluIGFuZCByYW5nZSBhbmQgc2NhbGUgYW5kIGFzc29jaWF0ZWQgc2V0dGluZ3NcbiAqL1xuXG4vKipcbiAqIFggYW5kIFkgYXhlcyBoYXZlIHRpY2tzLiBaIGF4aXMgaXMgbmV2ZXIgZGlzcGxheWVkIGFuZCBzbyBpdCBsYWNrcyB0aWNrc1xuICogYW5kIHRpY2sgc2V0dGluZ3MuXG4gKi9cblxuLyoqXG4gKiBJZiBhbiBheGlzIGlzIG5vdCBleHBsaWNpdGx5IGRlZmluZWQgYXMgYW4gZWxlbWVudCxcbiAqIHdlIHN0aWxsIG5lZWQgdG8gcmVuZGVyIHNvbWV0aGluZyBpbiB0aGUgY2hhcnQgYW5kIHdlIG5lZWRcbiAqIHNvbWUgb2JqZWN0IHRvIGhvbGQgdGhlIGRvbWFpbiBhbmQgZGVmYXVsdCBzZXR0aW5ncy5cbiAqL1xuZXhwb3J0IHZhciBpbXBsaWNpdFhBeGlzID0ge1xuICBhbGxvd0RhdGFPdmVyZmxvdzogZmFsc2UsXG4gIGFsbG93RGVjaW1hbHM6IHRydWUsXG4gIGFsbG93RHVwbGljYXRlZENhdGVnb3J5OiB0cnVlLFxuICBhbmdsZTogMCxcbiAgZGF0YUtleTogdW5kZWZpbmVkLFxuICBkb21haW46IHVuZGVmaW5lZCxcbiAgaGVpZ2h0OiAzMCxcbiAgaGlkZTogdHJ1ZSxcbiAgaWQ6IDAsXG4gIGluY2x1ZGVIaWRkZW46IGZhbHNlLFxuICBpbnRlcnZhbDogJ3ByZXNlcnZlRW5kJyxcbiAgbWluVGlja0dhcDogNSxcbiAgbWlycm9yOiBmYWxzZSxcbiAgbmFtZTogdW5kZWZpbmVkLFxuICBvcmllbnRhdGlvbjogJ2JvdHRvbScsXG4gIHBhZGRpbmc6IHtcbiAgICBsZWZ0OiAwLFxuICAgIHJpZ2h0OiAwXG4gIH0sXG4gIHJldmVyc2VkOiBmYWxzZSxcbiAgc2NhbGU6ICdhdXRvJyxcbiAgdGljazogdHJ1ZSxcbiAgdGlja0NvdW50OiA1LFxuICB0aWNrRm9ybWF0dGVyOiB1bmRlZmluZWQsXG4gIHRpY2tzOiB1bmRlZmluZWQsXG4gIHR5cGU6ICdjYXRlZ29yeScsXG4gIHVuaXQ6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCB2YXIgc2VsZWN0WEF4aXNTZXR0aW5nc05vRGVmYXVsdHMgPSAoc3RhdGUsIGF4aXNJZCkgPT4ge1xuICByZXR1cm4gc3RhdGUuY2FydGVzaWFuQXhpcy54QXhpc1theGlzSWRdO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0WEF4aXNTZXR0aW5ncyA9IChzdGF0ZSwgYXhpc0lkKSA9PiB7XG4gIHZhciBheGlzID0gc2VsZWN0WEF4aXNTZXR0aW5nc05vRGVmYXVsdHMoc3RhdGUsIGF4aXNJZCk7XG4gIGlmIChheGlzID09IG51bGwpIHtcbiAgICByZXR1cm4gaW1wbGljaXRYQXhpcztcbiAgfVxuICByZXR1cm4gYXhpcztcbn07XG5cbi8qKlxuICogSWYgYW4gYXhpcyBpcyBub3QgZXhwbGljaXRseSBkZWZpbmVkIGFzIGFuIGVsZW1lbnQsXG4gKiB3ZSBzdGlsbCBuZWVkIHRvIHJlbmRlciBzb21ldGhpbmcgaW4gdGhlIGNoYXJ0IGFuZCB3ZSBuZWVkXG4gKiBzb21lIG9iamVjdCB0byBob2xkIHRoZSBkb21haW4gYW5kIGRlZmF1bHQgc2V0dGluZ3MuXG4gKi9cbmV4cG9ydCB2YXIgaW1wbGljaXRZQXhpcyA9IHtcbiAgYWxsb3dEYXRhT3ZlcmZsb3c6IGZhbHNlLFxuICBhbGxvd0RlY2ltYWxzOiB0cnVlLFxuICBhbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeTogdHJ1ZSxcbiAgYW5nbGU6IDAsXG4gIGRhdGFLZXk6IHVuZGVmaW5lZCxcbiAgZG9tYWluOiBkZWZhdWx0TnVtZXJpY0RvbWFpbixcbiAgaGlkZTogdHJ1ZSxcbiAgaWQ6IDAsXG4gIGluY2x1ZGVIaWRkZW46IGZhbHNlLFxuICBpbnRlcnZhbDogJ3ByZXNlcnZlRW5kJyxcbiAgbWluVGlja0dhcDogNSxcbiAgbWlycm9yOiBmYWxzZSxcbiAgbmFtZTogdW5kZWZpbmVkLFxuICBvcmllbnRhdGlvbjogJ2xlZnQnLFxuICBwYWRkaW5nOiB7XG4gICAgdG9wOiAwLFxuICAgIGJvdHRvbTogMFxuICB9LFxuICByZXZlcnNlZDogZmFsc2UsXG4gIHNjYWxlOiAnYXV0bycsXG4gIHRpY2s6IHRydWUsXG4gIHRpY2tDb3VudDogNSxcbiAgdGlja0Zvcm1hdHRlcjogdW5kZWZpbmVkLFxuICB0aWNrczogdW5kZWZpbmVkLFxuICB0eXBlOiAnbnVtYmVyJyxcbiAgdW5pdDogdW5kZWZpbmVkLFxuICB3aWR0aDogREVGQVVMVF9ZX0FYSVNfV0lEVEhcbn07XG5leHBvcnQgdmFyIHNlbGVjdFlBeGlzU2V0dGluZ3NOb0RlZmF1bHRzID0gKHN0YXRlLCBheGlzSWQpID0+IHtcbiAgcmV0dXJuIHN0YXRlLmNhcnRlc2lhbkF4aXMueUF4aXNbYXhpc0lkXTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdFlBeGlzU2V0dGluZ3MgPSAoc3RhdGUsIGF4aXNJZCkgPT4ge1xuICB2YXIgYXhpcyA9IHNlbGVjdFlBeGlzU2V0dGluZ3NOb0RlZmF1bHRzKHN0YXRlLCBheGlzSWQpO1xuICBpZiAoYXhpcyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIGltcGxpY2l0WUF4aXM7XG4gIH1cbiAgcmV0dXJuIGF4aXM7XG59O1xuZXhwb3J0IHZhciBpbXBsaWNpdFpBeGlzID0ge1xuICBkb21haW46IFswLCAnYXV0byddLFxuICBpbmNsdWRlSGlkZGVuOiBmYWxzZSxcbiAgcmV2ZXJzZWQ6IGZhbHNlLFxuICBhbGxvd0RhdGFPdmVyZmxvdzogZmFsc2UsXG4gIGFsbG93RHVwbGljYXRlZENhdGVnb3J5OiBmYWxzZSxcbiAgZGF0YUtleTogdW5kZWZpbmVkLFxuICBpZDogMCxcbiAgbmFtZTogJycsXG4gIHJhbmdlOiBbNjQsIDY0XSxcbiAgc2NhbGU6ICdhdXRvJyxcbiAgdHlwZTogJ251bWJlcicsXG4gIHVuaXQ6ICcnXG59O1xuZXhwb3J0IHZhciBzZWxlY3RaQXhpc1NldHRpbmdzID0gKHN0YXRlLCBheGlzSWQpID0+IHtcbiAgdmFyIGF4aXMgPSBzdGF0ZS5jYXJ0ZXNpYW5BeGlzLnpBeGlzW2F4aXNJZF07XG4gIGlmIChheGlzID09IG51bGwpIHtcbiAgICByZXR1cm4gaW1wbGljaXRaQXhpcztcbiAgfVxuICByZXR1cm4gYXhpcztcbn07XG5leHBvcnQgdmFyIHNlbGVjdEJhc2VBeGlzID0gKHN0YXRlLCBheGlzVHlwZSwgYXhpc0lkKSA9PiB7XG4gIHN3aXRjaCAoYXhpc1R5cGUpIHtcbiAgICBjYXNlICd4QXhpcyc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzZWxlY3RYQXhpc1NldHRpbmdzKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGNhc2UgJ3lBeGlzJzpcbiAgICAgIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdFlBeGlzU2V0dGluZ3Moc3RhdGUsIGF4aXNJZCk7XG4gICAgICB9XG4gICAgY2FzZSAnekF4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0WkF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc0lkKTtcbiAgICAgIH1cbiAgICBjYXNlICdhbmdsZUF4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0QW5nbGVBeGlzKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGNhc2UgJ3JhZGl1c0F4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0UmFkaXVzQXhpcyhzdGF0ZSwgYXhpc0lkKTtcbiAgICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5leHBlY3RlZCBheGlzIHR5cGU6IFwiLmNvbmNhdChheGlzVHlwZSkpO1xuICB9XG59O1xudmFyIHNlbGVjdENhcnRlc2lhbkF4aXNTZXR0aW5ncyA9IChzdGF0ZSwgYXhpc1R5cGUsIGF4aXNJZCkgPT4ge1xuICBzd2l0Y2ggKGF4aXNUeXBlKSB7XG4gICAgY2FzZSAneEF4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0WEF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc0lkKTtcbiAgICAgIH1cbiAgICBjYXNlICd5QXhpcyc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzZWxlY3RZQXhpc1NldHRpbmdzKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmV4cGVjdGVkIGF4aXMgdHlwZTogXCIuY29uY2F0KGF4aXNUeXBlKSk7XG4gIH1cbn07XG5cbi8qKlxuICogU2VsZWN0cyBlaXRoZXIgYW4gWCBvciBZIGF4aXMuIERvZXNuJ3Qgd29yayB3aXRoIFogYXhpcyAtIGZvciB0aGF0LCBpbnN0ZWFkIHVzZSBzZWxlY3RCYXNlQXhpcy5cbiAqIEBwYXJhbSBzdGF0ZSBSb290IHN0YXRlXG4gKiBAcGFyYW0gYXhpc1R5cGUgeEF4aXMgfCB5QXhpc1xuICogQHBhcmFtIGF4aXNJZCB4QXhpc0lkIHwgeUF4aXNJZFxuICogQHJldHVybnMgYXhpcyBzZXR0aW5ncyBvYmplY3RcbiAqL1xuZXhwb3J0IHZhciBzZWxlY3RBeGlzU2V0dGluZ3MgPSAoc3RhdGUsIGF4aXNUeXBlLCBheGlzSWQpID0+IHtcbiAgc3dpdGNoIChheGlzVHlwZSkge1xuICAgIGNhc2UgJ3hBeGlzJzpcbiAgICAgIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdFhBeGlzU2V0dGluZ3Moc3RhdGUsIGF4aXNJZCk7XG4gICAgICB9XG4gICAgY2FzZSAneUF4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0WUF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc0lkKTtcbiAgICAgIH1cbiAgICBjYXNlICdhbmdsZUF4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0QW5nbGVBeGlzKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGNhc2UgJ3JhZGl1c0F4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0UmFkaXVzQXhpcyhzdGF0ZSwgYXhpc0lkKTtcbiAgICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5leHBlY3RlZCBheGlzIHR5cGU6IFwiLmNvbmNhdChheGlzVHlwZSkpO1xuICB9XG59O1xuXG4vKipcbiAqIEBwYXJhbSBzdGF0ZSBSZWNoYXJ0c1Jvb3RTdGF0ZVxuICogQHJldHVybiBib29sZWFuIHRydWUgaWYgdGhlcmUgaXMgYXQgbGVhc3Qgb25lIEJhciBvciBSYWRpYWxCYXJcbiAqL1xuZXhwb3J0IHZhciBzZWxlY3RIYXNCYXIgPSBzdGF0ZSA9PiBzdGF0ZS5ncmFwaGljYWxJdGVtcy5jYXJ0ZXNpYW5JdGVtcy5zb21lKGl0ZW0gPT4gaXRlbS50eXBlID09PSAnYmFyJykgfHwgc3RhdGUuZ3JhcGhpY2FsSXRlbXMucG9sYXJJdGVtcy5zb21lKGl0ZW0gPT4gaXRlbS50eXBlID09PSAncmFkaWFsQmFyJyk7XG5cbi8qKlxuICogRmlsdGVycyBDYXJ0ZXNpYW5HcmFwaGljYWxJdGVtU2V0dGluZ3MgYnkgdGhlIHJlbGV2YW50IGF4aXMgSURcbiAqIEBwYXJhbSBheGlzVHlwZSAneEF4aXMnIHwgJ3lBeGlzJyB8ICd6QXhpcycgfCAncmFkaXVzQXhpcycgfCAnYW5nbGVBeGlzJ1xuICogQHBhcmFtIGF4aXNJZCBmcm9tIHByb3BzLCBkZWZhdWx0cyB0byAwXG4gKlxuICogQHJldHVybnMgUHJlZGljYXRlIGZ1bmN0aW9uIHRoYXQgcmV0dXJuIHRydWUgZm9yIENhcnRlc2lhbkdyYXBoaWNhbEl0ZW1TZXR0aW5ncyB0aGF0IGFyZSByZWxldmFudCB0byB0aGUgc3BlY2lmaWVkIGF4aXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGl0ZW1BeGlzUHJlZGljYXRlKGF4aXNUeXBlLCBheGlzSWQpIHtcbiAgcmV0dXJuIGl0ZW0gPT4ge1xuICAgIHN3aXRjaCAoYXhpc1R5cGUpIHtcbiAgICAgIGNhc2UgJ3hBeGlzJzpcbiAgICAgICAgLy8gVGhpcyBpcyBzZW5zaXRpdmUgdG8gdGhlIGRhdGEgdHlwZSwgYXMgMCAhPT0gJzAnLiBJIHdvbmRlciBpZiB3ZSBzaG91bGQgYmUgbW9yZSBmbGV4aWJsZS4gSG93IGRvZXMgMi54IGJyYW5jaCBiZWhhdmU/IFRPRE8gd3JpdGUgdGVzdCBmb3IgdGhhdFxuICAgICAgICByZXR1cm4gJ3hBeGlzSWQnIGluIGl0ZW0gJiYgaXRlbS54QXhpc0lkID09PSBheGlzSWQ7XG4gICAgICBjYXNlICd5QXhpcyc6XG4gICAgICAgIHJldHVybiAneUF4aXNJZCcgaW4gaXRlbSAmJiBpdGVtLnlBeGlzSWQgPT09IGF4aXNJZDtcbiAgICAgIGNhc2UgJ3pBeGlzJzpcbiAgICAgICAgcmV0dXJuICd6QXhpc0lkJyBpbiBpdGVtICYmIGl0ZW0uekF4aXNJZCA9PT0gYXhpc0lkO1xuICAgICAgY2FzZSAnYW5nbGVBeGlzJzpcbiAgICAgICAgcmV0dXJuICdhbmdsZUF4aXNJZCcgaW4gaXRlbSAmJiBpdGVtLmFuZ2xlQXhpc0lkID09PSBheGlzSWQ7XG4gICAgICBjYXNlICdyYWRpdXNBeGlzJzpcbiAgICAgICAgcmV0dXJuICdyYWRpdXNBeGlzSWQnIGluIGl0ZW0gJiYgaXRlbS5yYWRpdXNBeGlzSWQgPT09IGF4aXNJZDtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH07XG59XG5leHBvcnQgdmFyIHNlbGVjdFVuZmlsdGVyZWRDYXJ0ZXNpYW5JdGVtcyA9IHN0YXRlID0+IHN0YXRlLmdyYXBoaWNhbEl0ZW1zLmNhcnRlc2lhbkl0ZW1zO1xudmFyIHNlbGVjdEF4aXNQcmVkaWNhdGUgPSBjcmVhdGVTZWxlY3RvcihbcGlja0F4aXNUeXBlLCBwaWNrQXhpc0lkXSwgaXRlbUF4aXNQcmVkaWNhdGUpO1xuZXhwb3J0IHZhciBjb21iaW5lR3JhcGhpY2FsSXRlbXNTZXR0aW5ncyA9IChncmFwaGljYWxJdGVtcywgYXhpc1NldHRpbmdzLCBheGlzUHJlZGljYXRlKSA9PiBncmFwaGljYWxJdGVtcy5maWx0ZXIoYXhpc1ByZWRpY2F0ZSkuZmlsdGVyKGl0ZW0gPT4ge1xuICBpZiAoKGF4aXNTZXR0aW5ncyA9PT0gbnVsbCB8fCBheGlzU2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGF4aXNTZXR0aW5ncy5pbmNsdWRlSGlkZGVuKSA9PT0gdHJ1ZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiAhaXRlbS5oaWRlO1xufSk7XG5leHBvcnQgdmFyIHNlbGVjdENhcnRlc2lhbkl0ZW1zU2V0dGluZ3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZENhcnRlc2lhbkl0ZW1zLCBzZWxlY3RCYXNlQXhpcywgc2VsZWN0QXhpc1ByZWRpY2F0ZV0sIGNvbWJpbmVHcmFwaGljYWxJdGVtc1NldHRpbmdzLCB7XG4gIG1lbW9pemVPcHRpb25zOiB7XG4gICAgcmVzdWx0RXF1YWxpdHlDaGVjazogYXJyYXlFcXVhbGl0eUNoZWNrXG4gIH1cbn0pO1xuZXhwb3J0IHZhciBzZWxlY3RTdGFja2VkQ2FydGVzaWFuSXRlbXNTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDYXJ0ZXNpYW5JdGVtc1NldHRpbmdzXSwgY2FydGVzaWFuSXRlbXMgPT4ge1xuICByZXR1cm4gY2FydGVzaWFuSXRlbXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS50eXBlID09PSAnYXJlYScgfHwgaXRlbS50eXBlID09PSAnYmFyJykuZmlsdGVyKGlzU3RhY2tlZCk7XG59KTtcbmV4cG9ydCB2YXIgZmlsdGVyR3JhcGhpY2FsTm90U3RhY2tlZEl0ZW1zID0gY2FydGVzaWFuSXRlbXMgPT4gY2FydGVzaWFuSXRlbXMuZmlsdGVyKGl0ZW0gPT4gISgnc3RhY2tJZCcgaW4gaXRlbSkgfHwgaXRlbS5zdGFja0lkID09PSB1bmRlZmluZWQpO1xudmFyIHNlbGVjdENhcnRlc2lhbkl0ZW1zU2V0dGluZ3NFeGNlcHRTdGFja2VkID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENhcnRlc2lhbkl0ZW1zU2V0dGluZ3NdLCBmaWx0ZXJHcmFwaGljYWxOb3RTdGFja2VkSXRlbXMpO1xuZXhwb3J0IHZhciBjb21iaW5lR3JhcGhpY2FsSXRlbXNEYXRhID0gY2FydGVzaWFuSXRlbXMgPT4gY2FydGVzaWFuSXRlbXMubWFwKGl0ZW0gPT4gaXRlbS5kYXRhKS5maWx0ZXIoQm9vbGVhbikuZmxhdCgxKTtcblxuLyoqXG4gKiBUaGlzIGlzIGEgXCJjaGVhcFwiIHNlbGVjdG9yIC0gaXQgcmV0dXJucyB0aGUgZGF0YSBidXQgZG9lc24ndCBpdGVyYXRlIHRoZW0sIHNvIGl0IGlzIG5vdCBzZW5zaXRpdmUgb24gdGhlIGFycmF5IGxlbmd0aC5cbiAqIEFsc28gZG9lcyBub3QgYXBwbHkgZGF0YUtleSB5ZXQuXG4gKiBAcGFyYW0gc3RhdGUgUmVjaGFydHNSb290U3RhdGVcbiAqIEByZXR1cm5zIGRhdGEgZGVmaW5lZCBvbiB0aGUgY2hhcnQgZ3JhcGhpY2FsIGl0ZW1zLCBzdWNoIGFzIExpbmUgb3IgU2NhdHRlciBvciBQaWUsIGFuZCBmaWx0ZXJlZCB3aXRoIGFwcHJvcHJpYXRlIGRhdGFLZXlcbiAqL1xuZXhwb3J0IHZhciBzZWxlY3RDYXJ0ZXNpYW5HcmFwaGljYWxJdGVtc0RhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2FydGVzaWFuSXRlbXNTZXR0aW5nc10sIGNvbWJpbmVHcmFwaGljYWxJdGVtc0RhdGEsIHtcbiAgbWVtb2l6ZU9wdGlvbnM6IHtcbiAgICByZXN1bHRFcXVhbGl0eUNoZWNrOiBhcnJheUVxdWFsaXR5Q2hlY2tcbiAgfVxufSk7XG5leHBvcnQgdmFyIGNvbWJpbmVEaXNwbGF5ZWREYXRhID0gKGdyYXBoaWNhbEl0ZW1zRGF0YSwgX3JlZikgPT4ge1xuICB2YXIge1xuICAgIGNoYXJ0RGF0YSA9IFtdLFxuICAgIGRhdGFTdGFydEluZGV4LFxuICAgIGRhdGFFbmRJbmRleFxuICB9ID0gX3JlZjtcbiAgaWYgKGdyYXBoaWNhbEl0ZW1zRGF0YS5sZW5ndGggPiAwKSB7XG4gICAgLypcbiAgICAgKiBUaGVyZSBpcyBubyBzbGljaW5nIHdoZW4gZGF0YSBpcyBkZWZpbmVkIG9uIGdyYXBoaWNhbCBpdGVtcy4gV2h5P1xuICAgICAqIEJlY2F1c2UgQnJ1c2ggaWdub3JlcyBkYXRhIGRlZmluZWQgb24gZ3JhcGhpY2FsIGl0ZW1zLFxuICAgICAqIGFuZCBkb2VzIG5vdCByZW5kZXIuXG4gICAgICogU28gQnJ1c2ggd2lsbCBuZXZlciBzaG93IHVwIGluIGEgU2NhdHRlciBjaGFydCBmb3IgZXhhbXBsZS5cbiAgICAgKiBUaGlzIGlzIHNvbWV0aGluZyB3ZSB3aWxsIG5lZWQgdG8gZml4LlxuICAgICAqXG4gICAgICogTm93LCB3aGVuIHRoZSByb290IGNoYXJ0IGRhdGEgaXMgbm90IGRlZmluZWQsIHRoZSBkYXRhRW5kSW5kZXggaXMgMCxcbiAgICAgKiB3aGljaCBtZWFucyB0aGUgaXRlbXNEYXRhIHdpbGwgYmUgc2xpY2VkIHRvIGFuIGVtcHR5IGFycmF5IGFueXdheS5cbiAgICAgKiBCdXQgdGhhdCdzIGFuIGltcGxlbWVudGF0aW9uIGRldGFpbCwgYW5kIHdlIGNhbiBmaXggdGhhdCB0b28uXG4gICAgICpcbiAgICAgKiBBbHNvLCBpbiBhYnNlbmNlIG9mIEF4aXMgZGF0YUtleSwgd2UgdXNlIHRoZSBkYXRhS2V5IGZyb20gZWFjaCBpdGVtLCByZXNwZWN0aXZlbHkuXG4gICAgICogVGhpcyBpcyB0aGUgdXN1YWwgcGF0dGVybiBmb3IgbnVtZXJpY2FsIGF4aXMsIHRoYXQgaXMgdGhlIG9uZSB3aGVyZSBiYXJzIGdvIHVwOlxuICAgICAqIHVzZXJzIGRvbid0IHNwZWNpZnkgYW55IGRhdGFLZXkgYnkgZGVmYXVsdCBhbmQgZXhwZWN0IHRoZSBheGlzIHRvIFwianVzdCBtYXRjaCB0aGUgZGF0YVwiLlxuICAgICAqL1xuICAgIHJldHVybiBncmFwaGljYWxJdGVtc0RhdGE7XG4gIH1cbiAgcmV0dXJuIGNoYXJ0RGF0YS5zbGljZShkYXRhU3RhcnRJbmRleCwgZGF0YUVuZEluZGV4ICsgMSk7XG59O1xuXG4vKipcbiAqIFRoaXMgc2VsZWN0b3Igd2lsbCByZXR1cm4gYWxsIGRhdGEgdGhlcmUgaXMgaW4gdGhlIGNoYXJ0OiBncmFwaGljYWwgaXRlbXMsIGNoYXJ0IHJvb3QsIGFsbCB0b2dldGhlci5cbiAqIFVzZWZ1bCBmb3IgZmlndXJpbmcgb3V0IGFuIGF4aXMgZG9tYWluIChiZWNhdXNlIHRoYXQgbmVlZHMgdG8ga25vdyBvZiBldmVyeXRoaW5nKSxcbiAqIG5vdCB1c2VmdWwgZm9yIHJlbmRlcmluZyBpbmRpdmlkdWFsIGdyYXBoaWNhbCBlbGVtZW50cyAoYmVjYXVzZSB0aGV5IG5lZWQgdG8ga25vdyB3aGljaCBkYXRhIGlzIHRoZWlycyBhbmQgd2hpY2ggaXMgbm90KS5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIHdpbGwgZGlzY2FyZCB0aGUgb3JpZ2luYWwgaW5kZXhlcywgc28gaXQgaXMgYWxzbyBub3QgdXNlZnVsIGZvciBhbnl0aGluZyB0aGF0IGRlcGVuZHMgb24gb3JkZXJpbmcuXG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0RGlzcGxheWVkRGF0YSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDYXJ0ZXNpYW5HcmFwaGljYWxJdGVtc0RhdGEsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzSWZOb3RJblBhbm9yYW1hXSwgY29tYmluZURpc3BsYXllZERhdGEpO1xuZXhwb3J0IHZhciBjb21iaW5lQXBwbGllZFZhbHVlcyA9IChkYXRhLCBheGlzU2V0dGluZ3MsIGl0ZW1zKSA9PiB7XG4gIGlmICgoYXhpc1NldHRpbmdzID09PSBudWxsIHx8IGF4aXNTZXR0aW5ncyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYXhpc1NldHRpbmdzLmRhdGFLZXkpICE9IG51bGwpIHtcbiAgICByZXR1cm4gZGF0YS5tYXAoaXRlbSA9PiAoe1xuICAgICAgdmFsdWU6IGdldFZhbHVlQnlEYXRhS2V5KGl0ZW0sIGF4aXNTZXR0aW5ncy5kYXRhS2V5KVxuICAgIH0pKTtcbiAgfVxuICBpZiAoaXRlbXMubGVuZ3RoID4gMCkge1xuICAgIHJldHVybiBpdGVtcy5tYXAoaXRlbSA9PiBpdGVtLmRhdGFLZXkpLmZsYXRNYXAoZGF0YUtleSA9PiBkYXRhLm1hcChlbnRyeSA9PiAoe1xuICAgICAgdmFsdWU6IGdldFZhbHVlQnlEYXRhS2V5KGVudHJ5LCBkYXRhS2V5KVxuICAgIH0pKSk7XG4gIH1cbiAgcmV0dXJuIGRhdGEubWFwKGVudHJ5ID0+ICh7XG4gICAgdmFsdWU6IGVudHJ5XG4gIH0pKTtcbn07XG5cbi8qKlxuICogVGhpcyBzZWxlY3RvciB3aWxsIHJldHVybiBhbGwgdmFsdWVzIHdpdGggdGhlIGFwcHJvcHJpYXRlIGRhdGFLZXkgYXBwbGllZCBvbiB0aGVtLlxuICogV2hpY2ggZGF0YUtleSBpcyBhcHByb3ByaWF0ZSBkZXBlbmRzIG9uIHdoZXJlIGl0IGlzIGRlZmluZWQuXG4gKlxuICogVGhpcyBpcyBhbiBleHBlbnNpdmUgc2VsZWN0b3IgLSBpdCB3aWxsIGl0ZXJhdGUgYWxsIGRhdGEgYW5kIGNvbXB1dGUgdGhlaXIgdmFsdWUgdXNpbmcgdGhlIHByb3ZpZGVkIGRhdGFLZXkuXG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0QWxsQXBwbGllZFZhbHVlcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3REaXNwbGF5ZWREYXRhLCBzZWxlY3RCYXNlQXhpcywgc2VsZWN0Q2FydGVzaWFuSXRlbXNTZXR0aW5nc10sIGNvbWJpbmVBcHBsaWVkVmFsdWVzKTtcbmV4cG9ydCBmdW5jdGlvbiBpc0Vycm9yQmFyUmVsZXZhbnRGb3JBeGlzVHlwZShheGlzVHlwZSwgZXJyb3JCYXIpIHtcbiAgc3dpdGNoIChheGlzVHlwZSkge1xuICAgIGNhc2UgJ3hBeGlzJzpcbiAgICAgIHJldHVybiBlcnJvckJhci5kaXJlY3Rpb24gPT09ICd4JztcbiAgICBjYXNlICd5QXhpcyc6XG4gICAgICByZXR1cm4gZXJyb3JCYXIuZGlyZWN0aW9uID09PSAneSc7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vKipcbiAqIFRoaXMgaXMgdHlwZSBvZiBcImVycm9yXCIgaW4gY2hhcnQuIEl0IGlzIHNldCBieSB1c2luZyBFcnJvckJhciwgYW5kIGl0IGNhbiByZXByZXNlbnQgY29uZmlkZW5jZSBpbnRlcnZhbCxcbiAqIG9yIGdhcCBpbiB0aGUgZGF0YSwgb3Igc3RhbmRhcmQgZGV2aWF0aW9uLCBvciBxdWFydGlsZXMgaW4gYm94cGxvdCwgb3Igd2hpc2tlcnMgb3Igd2hhdGV2ZXIuXG4gKlxuICogV2Ugd2lsbCBpbnRlcm5hbGx5IHJlcHJlc2VudCBpdCBhcyBhIHR1cGxlIG9mIHR3byBudW1iZXJzLCB3aGVyZSB0aGUgZmlyc3QgbnVtYmVyIGlzIHRoZSBsb3dlciBib3VuZCBhbmQgdGhlIHNlY29uZCBudW1iZXIgaXMgdGhlIHVwcGVyIGJvdW5kLlxuICpcbiAqIEl0IGlzIGFsc28gdHJ1ZSB0aGF0IHRoZSBmaXJzdCBudW1iZXIgc2hvdWxkIGJlIGxvd2VyIHRoYW4gb3IgZXF1YWwgdG8gdGhlIGFzc29jaWF0ZWQgXCJtYWluIHZhbHVlXCIsXG4gKiBhbmQgdGhlIHNlY29uZCBudW1iZXIgc2hvdWxkIGJlIGhpZ2hlciB0aGFuIG9yIGVxdWFsIHRvIHRoZSBhc3NvY2lhdGVkIFwibWFpbiB2YWx1ZVwiLlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBmcm9tTWFpblZhbHVlVG9FcnJvcih2YWx1ZSkge1xuICBpZiAoaXNOdW1iZXIodmFsdWUpICYmIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gW3ZhbHVlLCB2YWx1ZV07XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgdmFyIG1pbkVycm9yID0gTWF0aC5taW4oLi4udmFsdWUpO1xuICAgIHZhciBtYXhFcnJvciA9IE1hdGgubWF4KC4uLnZhbHVlKTtcbiAgICBpZiAoIWlzTmFuKG1pbkVycm9yKSAmJiAhaXNOYW4obWF4RXJyb3IpICYmIE51bWJlci5pc0Zpbml0ZShtaW5FcnJvcikgJiYgTnVtYmVyLmlzRmluaXRlKG1heEVycm9yKSkge1xuICAgICAgcmV0dXJuIFttaW5FcnJvciwgbWF4RXJyb3JdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gbWFrZU51bWJlcih2YWwpIHtcbiAgaWYgKGlzTnVtT3JTdHIodmFsKSB8fCB2YWwgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgdmFyIG4gPSBOdW1iZXIodmFsKTtcbiAgICBpZiAoaXNXZWxsQmVoYXZlZE51bWJlcihuKSkge1xuICAgICAgcmV0dXJuIG47XG4gICAgfVxuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBtYWtlRG9tYWluKHZhbCkge1xuICBpZiAoQXJyYXkuaXNBcnJheSh2YWwpKSB7XG4gICAgdmFyIGF0dGVtcHQgPSBbbWFrZU51bWJlcih2YWxbMF0pLCBtYWtlTnVtYmVyKHZhbFsxXSldO1xuICAgIGlmIChpc1dlbGxGb3JtZWROdW1iZXJEb21haW4oYXR0ZW1wdCkpIHtcbiAgICAgIHJldHVybiBhdHRlbXB0O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBuID0gbWFrZU51bWJlcih2YWwpO1xuICBpZiAobiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gW24sIG5dO1xufVxuZnVuY3Rpb24gb25seUFsbG93TnVtYmVycyhkYXRhKSB7XG4gIHJldHVybiBkYXRhLm1hcChtYWtlTnVtYmVyKS5maWx0ZXIoaXNOb3ROaWwpO1xufVxuXG4vKipcbiAqIEBwYXJhbSBlbnRyeSBPbmUgaXRlbSBpbiB0aGUgJ2RhdGEnIGFycmF5LiBDb3VsZCBiZSBhbnl0aGluZyByZWFsbHkgLSB0aGlzIGlzIGRlZmluZWQgZXh0ZXJuYWxseS4gVGhpcyBpcyB0aGUgcmF3LCBiZWZvcmUgZGF0YUtleSBhcHBsaWNhdGlvblxuICogQHBhcmFtIGFwcGxpZWRWYWx1ZSBUaGlzIGlzIHRoZSByZXN1bHQgb2YgYXBwbHlpbmcgdGhlICdtYWluJyBkYXRhS2V5IG9uIHRoZSBgZW50cnlgLlxuICogQHBhcmFtIHJlbGV2YW50RXJyb3JCYXJzIEVycm9yIGJhcnMgdGhhdCBhcmUgcmVsZXZhbnQgZm9yIHRoZSBjdXJyZW50IGF4aXMgYW5kIGxheW91dCBhbmQgYWxsIHRoYXQuXG4gKiBAcmV0dXJuIGVpdGhlciB1bmRlZmluZWQgb3IgYW4gYXJyYXkgb2YgRXJyb3JWYWx1ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXJyb3JEb21haW5CeURhdGFLZXkoZW50cnksIGFwcGxpZWRWYWx1ZSwgcmVsZXZhbnRFcnJvckJhcnMpIHtcbiAgaWYgKCFyZWxldmFudEVycm9yQmFycyB8fCB0eXBlb2YgYXBwbGllZFZhbHVlICE9PSAnbnVtYmVyJyB8fCBpc05hbihhcHBsaWVkVmFsdWUpKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGlmICghcmVsZXZhbnRFcnJvckJhcnMubGVuZ3RoKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHJldHVybiBvbmx5QWxsb3dOdW1iZXJzKHJlbGV2YW50RXJyb3JCYXJzLmZsYXRNYXAoZWIgPT4ge1xuICAgIHZhciBlcnJvclZhbHVlID0gZ2V0VmFsdWVCeURhdGFLZXkoZW50cnksIGViLmRhdGFLZXkpO1xuICAgIHZhciBsb3dCb3VuZCwgaGlnaEJvdW5kO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGVycm9yVmFsdWUpKSB7XG4gICAgICBbbG93Qm91bmQsIGhpZ2hCb3VuZF0gPSBlcnJvclZhbHVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb3dCb3VuZCA9IGhpZ2hCb3VuZCA9IGVycm9yVmFsdWU7XG4gICAgfVxuICAgIGlmICghaXNXZWxsQmVoYXZlZE51bWJlcihsb3dCb3VuZCkgfHwgIWlzV2VsbEJlaGF2ZWROdW1iZXIoaGlnaEJvdW5kKSkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIFthcHBsaWVkVmFsdWUgLSBsb3dCb3VuZCwgYXBwbGllZFZhbHVlICsgaGlnaEJvdW5kXTtcbiAgfSkpO1xufVxuZXhwb3J0IHZhciBzZWxlY3REaXNwbGF5ZWRTdGFja2VkRGF0YSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RTdGFja2VkQ2FydGVzaWFuSXRlbXNTZXR0aW5ncywgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEsIHNlbGVjdFRvb2x0aXBBeGlzXSwgY29tYmluZURpc3BsYXllZFN0YWNrZWREYXRhKTtcbmV4cG9ydCB2YXIgY29tYmluZVN0YWNrR3JvdXBzID0gKGRpc3BsYXllZERhdGEsIGl0ZW1zLCBzdGFja09mZnNldFR5cGUpID0+IHtcbiAgdmFyIGluaXRpYWxJdGVtc0dyb3VwcyA9IHt9O1xuICB2YXIgaXRlbXNHcm91cCA9IGl0ZW1zLnJlZHVjZSgoYWNjLCBpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0uc3RhY2tJZCA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gYWNjO1xuICAgIH1cbiAgICBpZiAoYWNjW2l0ZW0uc3RhY2tJZF0gPT0gbnVsbCkge1xuICAgICAgYWNjW2l0ZW0uc3RhY2tJZF0gPSBbXTtcbiAgICB9XG4gICAgYWNjW2l0ZW0uc3RhY2tJZF0ucHVzaChpdGVtKTtcbiAgICByZXR1cm4gYWNjO1xuICB9LCBpbml0aWFsSXRlbXNHcm91cHMpO1xuICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGl0ZW1zR3JvdXApLm1hcChfcmVmMiA9PiB7XG4gICAgdmFyIFtzdGFja0lkLCBncmFwaGljYWxJdGVtc10gPSBfcmVmMjtcbiAgICB2YXIgZGF0YUtleXMgPSBncmFwaGljYWxJdGVtcy5tYXAoZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyKTtcbiAgICByZXR1cm4gW3N0YWNrSWQsIHtcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgZ2V0U3RhY2tlZERhdGEgcmVxdWlyZXMgdGhhdCB0aGUgaW5wdXQgaXMgYXJyYXkgb2Ygb2JqZWN0cywgUmVjaGFydHMgZG9lcyBub3QgdGVzdCBmb3IgdGhhdFxuICAgICAgc3RhY2tlZERhdGE6IGdldFN0YWNrZWREYXRhKGRpc3BsYXllZERhdGEsIGRhdGFLZXlzLCBzdGFja09mZnNldFR5cGUpLFxuICAgICAgZ3JhcGhpY2FsSXRlbXNcbiAgICB9XTtcbiAgfSkpO1xufTtcblxuLyoqXG4gKiBTdGFjayBncm91cHMgYXJlIGdyb3VwcyBvZiBncmFwaGljYWwgaXRlbXMgdGhhdCBzdGFjayBvbiBlYWNoIG90aGVyLlxuICogU3RhY2sgaXMgYSBmdW5jdGlvbiBvZiBheGlzIHR5cGUgKFgsIFkpLCBheGlzIElELCBhbmQgc3RhY2sgSUQuXG4gKiBHcmFwaGljYWwgaXRlbXMgdGhhdCBkbyBub3QgaGF2ZSBhIHN0YWNrIElEIGFyZSBub3QgZ29pbmcgdG8gYmUgcHJlc2VudCBpbiBzdGFjayBncm91cHMuXG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0U3RhY2tHcm91cHMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0RGlzcGxheWVkU3RhY2tlZERhdGEsIHNlbGVjdFN0YWNrZWRDYXJ0ZXNpYW5JdGVtc1NldHRpbmdzLCBzZWxlY3RTdGFja09mZnNldFR5cGVdLCBjb21iaW5lU3RhY2tHcm91cHMpO1xuZXhwb3J0IHZhciBjb21iaW5lRG9tYWluT2ZTdGFja0dyb3VwcyA9IChzdGFja0dyb3VwcywgX3JlZjMsIGF4aXNUeXBlLCBkb21haW5Gcm9tVXNlclByZWZlcmVuY2UpID0+IHtcbiAgdmFyIHtcbiAgICBkYXRhU3RhcnRJbmRleCxcbiAgICBkYXRhRW5kSW5kZXhcbiAgfSA9IF9yZWYzO1xuICBpZiAoZG9tYWluRnJvbVVzZXJQcmVmZXJlbmNlICE9IG51bGwpIHtcbiAgICAvLyBVc2VyIGhhcyBzcGVjaWZpZWQgYSBkb21haW4sIHNvIHdlIHJlc3BlY3QgdGhhdCBhbmQgd2UgY2FuIHNraXAgY29tcHV0aW5nIGFueXRoaW5nIGVsc2VcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIGlmIChheGlzVHlwZSA9PT0gJ3pBeGlzJykge1xuICAgIC8vIFpBeGlzIGlnbm9yZXMgc3RhY2tzXG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgZG9tYWluT2ZTdGFja0dyb3VwcyA9IGdldERvbWFpbk9mU3RhY2tHcm91cHMoc3RhY2tHcm91cHMsIGRhdGFTdGFydEluZGV4LCBkYXRhRW5kSW5kZXgpO1xuICBpZiAoZG9tYWluT2ZTdGFja0dyb3VwcyAhPSBudWxsICYmIGRvbWFpbk9mU3RhY2tHcm91cHNbMF0gPT09IDAgJiYgZG9tYWluT2ZTdGFja0dyb3Vwc1sxXSA9PT0gMCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGRvbWFpbk9mU3RhY2tHcm91cHM7XG59O1xudmFyIHNlbGVjdEFsbG93c0RhdGFPdmVyZmxvdyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RCYXNlQXhpc10sIGF4aXNTZXR0aW5ncyA9PiBheGlzU2V0dGluZ3MuYWxsb3dEYXRhT3ZlcmZsb3cpO1xuZXhwb3J0IHZhciBnZXREb21haW5EZWZpbml0aW9uID0gYXhpc1NldHRpbmdzID0+IHtcbiAgdmFyIF9heGlzU2V0dGluZ3MkZG9tYWluO1xuICBpZiAoYXhpc1NldHRpbmdzID09IG51bGwgfHwgISgnZG9tYWluJyBpbiBheGlzU2V0dGluZ3MpKSB7XG4gICAgcmV0dXJuIGRlZmF1bHROdW1lcmljRG9tYWluO1xuICB9XG4gIGlmIChheGlzU2V0dGluZ3MuZG9tYWluICE9IG51bGwpIHtcbiAgICByZXR1cm4gYXhpc1NldHRpbmdzLmRvbWFpbjtcbiAgfVxuICBpZiAoYXhpc1NldHRpbmdzLnRpY2tzICE9IG51bGwpIHtcbiAgICBpZiAoYXhpc1NldHRpbmdzLnR5cGUgPT09ICdudW1iZXInKSB7XG4gICAgICB2YXIgYWxsVmFsdWVzID0gb25seUFsbG93TnVtYmVycyhheGlzU2V0dGluZ3MudGlja3MpO1xuICAgICAgcmV0dXJuIFtNYXRoLm1pbiguLi5hbGxWYWx1ZXMpLCBNYXRoLm1heCguLi5hbGxWYWx1ZXMpXTtcbiAgICB9XG4gICAgaWYgKGF4aXNTZXR0aW5ncy50eXBlID09PSAnY2F0ZWdvcnknKSB7XG4gICAgICByZXR1cm4gYXhpc1NldHRpbmdzLnRpY2tzLm1hcChTdHJpbmcpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gKF9heGlzU2V0dGluZ3MkZG9tYWluID0gYXhpc1NldHRpbmdzID09PSBudWxsIHx8IGF4aXNTZXR0aW5ncyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYXhpc1NldHRpbmdzLmRvbWFpbikgIT09IG51bGwgJiYgX2F4aXNTZXR0aW5ncyRkb21haW4gIT09IHZvaWQgMCA/IF9heGlzU2V0dGluZ3MkZG9tYWluIDogZGVmYXVsdE51bWVyaWNEb21haW47XG59O1xuZXhwb3J0IHZhciBzZWxlY3REb21haW5EZWZpbml0aW9uID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzXSwgZ2V0RG9tYWluRGVmaW5pdGlvbik7XG5cbi8qKlxuICogVW5kZXIgY2VydGFpbiBjaXJjdW1zdGFuY2VzLCB3ZSBjYW4gZGV0ZXJtaW5lIHRoZSBkb21haW4gd2l0aG91dCBsb29raW5nIGF0IHRoZSBkYXRhIGF0IGFsbC5cbiAqIFRoaXMgaXMgdGhlIGNhc2Ugd2hlbiB0aGUgZG9tYWluIGlzIGV4cGxpY2l0bHkgc3BlY2lmaWVkIGFzIG51bWJlcnMsIG9yIHdoZW4gaXQgaXMgc3BlY2lmaWVkXG4gKiBhcyAnYXV0bycgb3IgJ2RhdGFNaW4nLydkYXRhTWF4JyBhbmQgZGF0YSBvdmVyZmxvdyBpcyBub3QgYWxsb3dlZC5cbiAqXG4gKiBJbiB0aGF0IGNhc2UsIHRoaXMgZnVuY3Rpb24gd2lsbCByZXR1cm4gdGhlIGRvbWFpbiwgb3RoZXJ3aXNlIGl0IHJldHVybnMgdW5kZWZpbmVkLlxuICpcbiAqIFRoaXMgaXMgYW4gb3B0aW1pemF0aW9uIHRvIGF2b2lkIHVubmVjZXNzYXJ5IGRhdGEgcHJvY2Vzc2luZy5cbiAqIEBwYXJhbSBzdGF0ZVxuICogQHBhcmFtIGF4aXNUeXBlXG4gKiBAcGFyYW0gYXhpc0lkXG4gKiBAcGFyYW0gaXNQYW5vcmFtYVxuICovXG5leHBvcnQgdmFyIHNlbGVjdERvbWFpbkZyb21Vc2VyUHJlZmVyZW5jZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3REb21haW5EZWZpbml0aW9uLCBzZWxlY3RBbGxvd3NEYXRhT3ZlcmZsb3ddLCBudW1lcmljYWxEb21haW5TcGVjaWZpZWRXaXRob3V0UmVxdWlyaW5nRGF0YSk7XG5leHBvcnQgdmFyIHNlbGVjdERvbWFpbk9mU3RhY2tHcm91cHMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0U3RhY2tHcm91cHMsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzLCBwaWNrQXhpc1R5cGUsIHNlbGVjdERvbWFpbkZyb21Vc2VyUHJlZmVyZW5jZV0sIGNvbWJpbmVEb21haW5PZlN0YWNrR3JvdXBzLCB7XG4gIG1lbW9pemVPcHRpb25zOiB7XG4gICAgcmVzdWx0RXF1YWxpdHlDaGVjazogbnVtYmVyRG9tYWluRXF1YWxpdHlDaGVja1xuICB9XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0QWxsRXJyb3JCYXJTZXR0aW5ncyA9IHN0YXRlID0+IHN0YXRlLmVycm9yQmFycztcbnZhciBjb21iaW5lUmVsZXZhbnRFcnJvckJhclNldHRpbmdzID0gKGNhcnRlc2lhbkl0ZW1zU2V0dGluZ3MsIGFsbEVycm9yQmFyU2V0dGluZ3MsIGF4aXNUeXBlKSA9PiB7XG4gIHJldHVybiBjYXJ0ZXNpYW5JdGVtc1NldHRpbmdzLmZsYXRNYXAoaXRlbSA9PiB7XG4gICAgcmV0dXJuIGFsbEVycm9yQmFyU2V0dGluZ3NbaXRlbS5pZF07XG4gIH0pLmZpbHRlcihCb29sZWFuKS5maWx0ZXIoZSA9PiB7XG4gICAgcmV0dXJuIGlzRXJyb3JCYXJSZWxldmFudEZvckF4aXNUeXBlKGF4aXNUeXBlLCBlKTtcbiAgfSk7XG59O1xuZXhwb3J0IHZhciBtZXJnZURvbWFpbnMgPSBmdW5jdGlvbiBtZXJnZURvbWFpbnMoKSB7XG4gIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBkb21haW5zID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgIGRvbWFpbnNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gIH1cbiAgdmFyIGFsbERvbWFpbnMgPSBkb21haW5zLmZpbHRlcihCb29sZWFuKTtcbiAgaWYgKGFsbERvbWFpbnMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgYWxsVmFsdWVzID0gYWxsRG9tYWlucy5mbGF0KCk7XG4gIHZhciBtaW4gPSBNYXRoLm1pbiguLi5hbGxWYWx1ZXMpO1xuICB2YXIgbWF4ID0gTWF0aC5tYXgoLi4uYWxsVmFsdWVzKTtcbiAgcmV0dXJuIFttaW4sIG1heF07XG59O1xuZXhwb3J0IHZhciBjb21iaW5lRG9tYWluT2ZBbGxBcHBsaWVkTnVtZXJpY2FsVmFsdWVzSW5jbHVkaW5nRXJyb3JWYWx1ZXMgPSAoZGF0YSwgYXhpc1NldHRpbmdzLCBpdGVtcywgZXJyb3JCYXJzLCBheGlzVHlwZSkgPT4ge1xuICB2YXIgbG93ZXJFbmQsIHVwcGVyRW5kO1xuICBpZiAoaXRlbXMubGVuZ3RoID4gMCkge1xuICAgIGRhdGEuZm9yRWFjaChlbnRyeSA9PiB7XG4gICAgICBpdGVtcy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgICB2YXIgX2Vycm9yQmFycyRpdGVtJGlkLCBfYXhpc1NldHRpbmdzJGRhdGFLZXk7XG4gICAgICAgIHZhciByZWxldmFudEVycm9yQmFycyA9IChfZXJyb3JCYXJzJGl0ZW0kaWQgPSBlcnJvckJhcnNbaXRlbS5pZF0pID09PSBudWxsIHx8IF9lcnJvckJhcnMkaXRlbSRpZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2Vycm9yQmFycyRpdGVtJGlkLmZpbHRlcihlcnJvckJhciA9PiBpc0Vycm9yQmFyUmVsZXZhbnRGb3JBeGlzVHlwZShheGlzVHlwZSwgZXJyb3JCYXIpKTtcbiAgICAgICAgdmFyIHZhbHVlQnlEYXRhS2V5ID0gZ2V0VmFsdWVCeURhdGFLZXkoZW50cnksIChfYXhpc1NldHRpbmdzJGRhdGFLZXkgPSBheGlzU2V0dGluZ3MuZGF0YUtleSkgIT09IG51bGwgJiYgX2F4aXNTZXR0aW5ncyRkYXRhS2V5ICE9PSB2b2lkIDAgPyBfYXhpc1NldHRpbmdzJGRhdGFLZXkgOiBpdGVtLmRhdGFLZXkpO1xuICAgICAgICB2YXIgZXJyb3JEb21haW4gPSBnZXRFcnJvckRvbWFpbkJ5RGF0YUtleShlbnRyeSwgdmFsdWVCeURhdGFLZXksIHJlbGV2YW50RXJyb3JCYXJzKTtcbiAgICAgICAgaWYgKGVycm9yRG9tYWluLmxlbmd0aCA+PSAyKSB7XG4gICAgICAgICAgdmFyIGxvY2FsTG93ZXIgPSBNYXRoLm1pbiguLi5lcnJvckRvbWFpbik7XG4gICAgICAgICAgdmFyIGxvY2FsVXBwZXIgPSBNYXRoLm1heCguLi5lcnJvckRvbWFpbik7XG4gICAgICAgICAgaWYgKGxvd2VyRW5kID09IG51bGwgfHwgbG9jYWxMb3dlciA8IGxvd2VyRW5kKSB7XG4gICAgICAgICAgICBsb3dlckVuZCA9IGxvY2FsTG93ZXI7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh1cHBlckVuZCA9PSBudWxsIHx8IGxvY2FsVXBwZXIgPiB1cHBlckVuZCkge1xuICAgICAgICAgICAgdXBwZXJFbmQgPSBsb2NhbFVwcGVyO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgZGF0YVZhbHVlRG9tYWluID0gbWFrZURvbWFpbih2YWx1ZUJ5RGF0YUtleSk7XG4gICAgICAgIGlmIChkYXRhVmFsdWVEb21haW4gIT0gbnVsbCkge1xuICAgICAgICAgIGxvd2VyRW5kID0gbG93ZXJFbmQgPT0gbnVsbCA/IGRhdGFWYWx1ZURvbWFpblswXSA6IE1hdGgubWluKGxvd2VyRW5kLCBkYXRhVmFsdWVEb21haW5bMF0pO1xuICAgICAgICAgIHVwcGVyRW5kID0gdXBwZXJFbmQgPT0gbnVsbCA/IGRhdGFWYWx1ZURvbWFpblsxXSA6IE1hdGgubWF4KHVwcGVyRW5kLCBkYXRhVmFsdWVEb21haW5bMV0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICBpZiAoKGF4aXNTZXR0aW5ncyA9PT0gbnVsbCB8fCBheGlzU2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGF4aXNTZXR0aW5ncy5kYXRhS2V5KSAhPSBudWxsKSB7XG4gICAgZGF0YS5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgdmFyIGRhdGFWYWx1ZURvbWFpbiA9IG1ha2VEb21haW4oZ2V0VmFsdWVCeURhdGFLZXkoaXRlbSwgYXhpc1NldHRpbmdzLmRhdGFLZXkpKTtcbiAgICAgIGlmIChkYXRhVmFsdWVEb21haW4gIT0gbnVsbCkge1xuICAgICAgICBsb3dlckVuZCA9IGxvd2VyRW5kID09IG51bGwgPyBkYXRhVmFsdWVEb21haW5bMF0gOiBNYXRoLm1pbihsb3dlckVuZCwgZGF0YVZhbHVlRG9tYWluWzBdKTtcbiAgICAgICAgdXBwZXJFbmQgPSB1cHBlckVuZCA9PSBudWxsID8gZGF0YVZhbHVlRG9tYWluWzFdIDogTWF0aC5tYXgodXBwZXJFbmQsIGRhdGFWYWx1ZURvbWFpblsxXSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgaWYgKGlzV2VsbEJlaGF2ZWROdW1iZXIobG93ZXJFbmQpICYmIGlzV2VsbEJlaGF2ZWROdW1iZXIodXBwZXJFbmQpKSB7XG4gICAgcmV0dXJuIFtsb3dlckVuZCwgdXBwZXJFbmRdO1xuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59O1xudmFyIHNlbGVjdERvbWFpbk9mQWxsQXBwbGllZE51bWVyaWNhbFZhbHVlc0luY2x1ZGluZ0Vycm9yVmFsdWVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdERpc3BsYXllZERhdGEsIHNlbGVjdEJhc2VBeGlzLCBzZWxlY3RDYXJ0ZXNpYW5JdGVtc1NldHRpbmdzRXhjZXB0U3RhY2tlZCwgc2VsZWN0QWxsRXJyb3JCYXJTZXR0aW5ncywgcGlja0F4aXNUeXBlXSwgY29tYmluZURvbWFpbk9mQWxsQXBwbGllZE51bWVyaWNhbFZhbHVlc0luY2x1ZGluZ0Vycm9yVmFsdWVzLCB7XG4gIG1lbW9pemVPcHRpb25zOiB7XG4gICAgcmVzdWx0RXF1YWxpdHlDaGVjazogbnVtYmVyRG9tYWluRXF1YWxpdHlDaGVja1xuICB9XG59KTtcbmZ1bmN0aW9uIG9ubHlBbGxvd051bWJlcnNBbmRTdHJpbmdzQW5kRGF0ZXMoaXRlbSkge1xuICB2YXIge1xuICAgIHZhbHVlXG4gIH0gPSBpdGVtO1xuICBpZiAoaXNOdW1PclN0cih2YWx1ZSkgfHwgdmFsdWUgaW5zdGFuY2VvZiBEYXRlKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG52YXIgY29tcHV0ZURvbWFpbk9mVHlwZUNhdGVnb3J5ID0gKGFsbERhdGFTcXVpc2hlZCwgYXhpc1NldHRpbmdzLCBpc0NhdGVnb3JpY2FsKSA9PiB7XG4gIHZhciBjYXRlZ29yaWNhbERvbWFpbiA9IGFsbERhdGFTcXVpc2hlZC5tYXAob25seUFsbG93TnVtYmVyc0FuZFN0cmluZ3NBbmREYXRlcykuZmlsdGVyKHYgPT4gdiAhPSBudWxsKTtcbiAgaWYgKGlzQ2F0ZWdvcmljYWwgJiYgKGF4aXNTZXR0aW5ncy5kYXRhS2V5ID09IG51bGwgfHwgYXhpc1NldHRpbmdzLmFsbG93RHVwbGljYXRlZENhdGVnb3J5ICYmIGhhc0R1cGxpY2F0ZShjYXRlZ29yaWNhbERvbWFpbikpKSB7XG4gICAgLypcbiAgICAgKiAxLiBJbiBhbiBhYnNlbmNlIG9mIGRhdGFLZXksIFJlY2hhcnRzIHdpbGwgdXNlIGFycmF5IGluZGV4ZXMgYXMgaXRzIGNhdGVnb3JpY2FsIGRvbWFpblxuICAgICAqIDIuIFdoZW4gY2F0ZWdvcnkgYXhpcyBoYXMgZHVwbGljYXRlZCB0ZXh0LCBzZXJpYWwgbnVtYmVycyBhcmUgdXNlZCB0byBnZW5lcmF0ZSBzY2FsZVxuICAgICAqL1xuICAgIHJldHVybiByYW5nZSgwLCBhbGxEYXRhU3F1aXNoZWQubGVuZ3RoKTtcbiAgfVxuICBpZiAoYXhpc1NldHRpbmdzLmFsbG93RHVwbGljYXRlZENhdGVnb3J5KSB7XG4gICAgcmV0dXJuIGNhdGVnb3JpY2FsRG9tYWluO1xuICB9XG4gIHJldHVybiBBcnJheS5mcm9tKG5ldyBTZXQoY2F0ZWdvcmljYWxEb21haW4pKTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdFJlZmVyZW5jZURvdHMgPSBzdGF0ZSA9PiBzdGF0ZS5yZWZlcmVuY2VFbGVtZW50cy5kb3RzO1xuZXhwb3J0IHZhciBmaWx0ZXJSZWZlcmVuY2VFbGVtZW50cyA9IChlbGVtZW50cywgYXhpc1R5cGUsIGF4aXNJZCkgPT4ge1xuICByZXR1cm4gZWxlbWVudHMuZmlsdGVyKGVsID0+IGVsLmlmT3ZlcmZsb3cgPT09ICdleHRlbmREb21haW4nKS5maWx0ZXIoZWwgPT4ge1xuICAgIGlmIChheGlzVHlwZSA9PT0gJ3hBeGlzJykge1xuICAgICAgcmV0dXJuIGVsLnhBeGlzSWQgPT09IGF4aXNJZDtcbiAgICB9XG4gICAgcmV0dXJuIGVsLnlBeGlzSWQgPT09IGF4aXNJZDtcbiAgfSk7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RSZWZlcmVuY2VEb3RzQnlBeGlzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJlZmVyZW5jZURvdHMsIHBpY2tBeGlzVHlwZSwgcGlja0F4aXNJZF0sIGZpbHRlclJlZmVyZW5jZUVsZW1lbnRzKTtcbmV4cG9ydCB2YXIgc2VsZWN0UmVmZXJlbmNlQXJlYXMgPSBzdGF0ZSA9PiBzdGF0ZS5yZWZlcmVuY2VFbGVtZW50cy5hcmVhcztcbmV4cG9ydCB2YXIgc2VsZWN0UmVmZXJlbmNlQXJlYXNCeUF4aXMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmVmZXJlbmNlQXJlYXMsIHBpY2tBeGlzVHlwZSwgcGlja0F4aXNJZF0sIGZpbHRlclJlZmVyZW5jZUVsZW1lbnRzKTtcbmV4cG9ydCB2YXIgc2VsZWN0UmVmZXJlbmNlTGluZXMgPSBzdGF0ZSA9PiBzdGF0ZS5yZWZlcmVuY2VFbGVtZW50cy5saW5lcztcbmV4cG9ydCB2YXIgc2VsZWN0UmVmZXJlbmNlTGluZXNCeUF4aXMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmVmZXJlbmNlTGluZXMsIHBpY2tBeGlzVHlwZSwgcGlja0F4aXNJZF0sIGZpbHRlclJlZmVyZW5jZUVsZW1lbnRzKTtcbmV4cG9ydCB2YXIgY29tYmluZURvdHNEb21haW4gPSAoZG90cywgYXhpc1R5cGUpID0+IHtcbiAgdmFyIGFsbENvb3JkcyA9IG9ubHlBbGxvd051bWJlcnMoZG90cy5tYXAoZG90ID0+IGF4aXNUeXBlID09PSAneEF4aXMnID8gZG90LnggOiBkb3QueSkpO1xuICBpZiAoYWxsQ29vcmRzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIFtNYXRoLm1pbiguLi5hbGxDb29yZHMpLCBNYXRoLm1heCguLi5hbGxDb29yZHMpXTtcbn07XG52YXIgc2VsZWN0UmVmZXJlbmNlRG90c0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdFJlZmVyZW5jZURvdHNCeUF4aXMsIHBpY2tBeGlzVHlwZSwgY29tYmluZURvdHNEb21haW4pO1xuZXhwb3J0IHZhciBjb21iaW5lQXJlYXNEb21haW4gPSAoYXJlYXMsIGF4aXNUeXBlKSA9PiB7XG4gIHZhciBhbGxDb29yZHMgPSBvbmx5QWxsb3dOdW1iZXJzKGFyZWFzLmZsYXRNYXAoYXJlYSA9PiBbYXhpc1R5cGUgPT09ICd4QXhpcycgPyBhcmVhLngxIDogYXJlYS55MSwgYXhpc1R5cGUgPT09ICd4QXhpcycgPyBhcmVhLngyIDogYXJlYS55Ml0pKTtcbiAgaWYgKGFsbENvb3Jkcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBbTWF0aC5taW4oLi4uYWxsQ29vcmRzKSwgTWF0aC5tYXgoLi4uYWxsQ29vcmRzKV07XG59O1xudmFyIHNlbGVjdFJlZmVyZW5jZUFyZWFzRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJlZmVyZW5jZUFyZWFzQnlBeGlzLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lQXJlYXNEb21haW4pO1xuZXhwb3J0IHZhciBjb21iaW5lTGluZXNEb21haW4gPSAobGluZXMsIGF4aXNUeXBlKSA9PiB7XG4gIHZhciBhbGxDb29yZHMgPSBvbmx5QWxsb3dOdW1iZXJzKGxpbmVzLm1hcChsaW5lID0+IGF4aXNUeXBlID09PSAneEF4aXMnID8gbGluZS54IDogbGluZS55KSk7XG4gIGlmIChhbGxDb29yZHMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gW01hdGgubWluKC4uLmFsbENvb3JkcyksIE1hdGgubWF4KC4uLmFsbENvb3JkcyldO1xufTtcbnZhciBzZWxlY3RSZWZlcmVuY2VMaW5lc0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdFJlZmVyZW5jZUxpbmVzQnlBeGlzLCBwaWNrQXhpc1R5cGUsIGNvbWJpbmVMaW5lc0RvbWFpbik7XG52YXIgc2VsZWN0UmVmZXJlbmNlRWxlbWVudHNEb21haW4gPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RSZWZlcmVuY2VEb3RzRG9tYWluLCBzZWxlY3RSZWZlcmVuY2VMaW5lc0RvbWFpbiwgc2VsZWN0UmVmZXJlbmNlQXJlYXNEb21haW4sIChkb3RzRG9tYWluLCBsaW5lc0RvbWFpbiwgYXJlYXNEb21haW4pID0+IHtcbiAgcmV0dXJuIG1lcmdlRG9tYWlucyhkb3RzRG9tYWluLCBhcmVhc0RvbWFpbiwgbGluZXNEb21haW4pO1xufSk7XG5leHBvcnQgdmFyIGNvbWJpbmVOdW1lcmljYWxEb21haW4gPSAoYXhpc1NldHRpbmdzLCBkb21haW5EZWZpbml0aW9uLCBkb21haW5Gcm9tVXNlclByZWZlcmVuY2UsIGRvbWFpbk9mU3RhY2tHcm91cHMsIGRhdGFBbmRFcnJvckJhcnNEb21haW4sIHJlZmVyZW5jZUVsZW1lbnRzRG9tYWluLCBsYXlvdXQsIGF4aXNUeXBlKSA9PiB7XG4gIGlmIChkb21haW5Gcm9tVXNlclByZWZlcmVuY2UgIT0gbnVsbCkge1xuICAgIC8vIFdlJ3JlIGRvbmUhIE5vIG5lZWQgdG8gY29tcHV0ZSBhbnl0aGluZyBlbHNlLlxuICAgIHJldHVybiBkb21haW5Gcm9tVXNlclByZWZlcmVuY2U7XG4gIH1cbiAgdmFyIHNob3VsZEluY2x1ZGVEb21haW5PZlN0YWNrR3JvdXBzID0gbGF5b3V0ID09PSAndmVydGljYWwnICYmIGF4aXNUeXBlID09PSAneEF4aXMnIHx8IGxheW91dCA9PT0gJ2hvcml6b250YWwnICYmIGF4aXNUeXBlID09PSAneUF4aXMnO1xuICB2YXIgbWVyZ2VkRG9tYWlucyA9IHNob3VsZEluY2x1ZGVEb21haW5PZlN0YWNrR3JvdXBzID8gbWVyZ2VEb21haW5zKGRvbWFpbk9mU3RhY2tHcm91cHMsIHJlZmVyZW5jZUVsZW1lbnRzRG9tYWluLCBkYXRhQW5kRXJyb3JCYXJzRG9tYWluKSA6IG1lcmdlRG9tYWlucyhyZWZlcmVuY2VFbGVtZW50c0RvbWFpbiwgZGF0YUFuZEVycm9yQmFyc0RvbWFpbik7XG4gIHJldHVybiBwYXJzZU51bWVyaWNhbFVzZXJEb21haW4oZG9tYWluRGVmaW5pdGlvbiwgbWVyZ2VkRG9tYWlucywgYXhpc1NldHRpbmdzLmFsbG93RGF0YU92ZXJmbG93KTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdE51bWVyaWNhbERvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RCYXNlQXhpcywgc2VsZWN0RG9tYWluRGVmaW5pdGlvbiwgc2VsZWN0RG9tYWluRnJvbVVzZXJQcmVmZXJlbmNlLCBzZWxlY3REb21haW5PZlN0YWNrR3JvdXBzLCBzZWxlY3REb21haW5PZkFsbEFwcGxpZWROdW1lcmljYWxWYWx1ZXNJbmNsdWRpbmdFcnJvclZhbHVlcywgc2VsZWN0UmVmZXJlbmNlRWxlbWVudHNEb21haW4sIHNlbGVjdENoYXJ0TGF5b3V0LCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lTnVtZXJpY2FsRG9tYWluLCB7XG4gIG1lbW9pemVPcHRpb25zOiB7XG4gICAgcmVzdWx0RXF1YWxpdHlDaGVjazogbnVtYmVyRG9tYWluRXF1YWxpdHlDaGVja1xuICB9XG59KTtcblxuLyoqXG4gKiBFeHBhbmQgYnkgZGVzaWduIG1hcHMgZXZlcnl0aGluZyBiZXR3ZWVuIDAgYW5kIDEsXG4gKiB0aGVyZSBpcyBub3RoaW5nIHRvIGNvbXB1dGUuXG4gKiBTZWUgaHR0cHM6Ly9kM2pzLm9yZy9kMy1zaGFwZS9zdGFjayNzdGFjay1vZmZzZXRzXG4gKi9cbnZhciBleHBhbmREb21haW4gPSBbMCwgMV07XG5leHBvcnQgdmFyIGNvbWJpbmVBeGlzRG9tYWluID0gKGF4aXNTZXR0aW5ncywgbGF5b3V0LCBkaXNwbGF5ZWREYXRhLCBhbGxBcHBsaWVkVmFsdWVzLCBzdGFja09mZnNldFR5cGUsIGF4aXNUeXBlLCBudW1lcmljYWxEb21haW4pID0+IHtcbiAgaWYgKChheGlzU2V0dGluZ3MgPT0gbnVsbCB8fCBkaXNwbGF5ZWREYXRhID09IG51bGwgfHwgZGlzcGxheWVkRGF0YS5sZW5ndGggPT09IDApICYmIG51bWVyaWNhbERvbWFpbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIGRhdGFLZXksXG4gICAgdHlwZVxuICB9ID0gYXhpc1NldHRpbmdzO1xuICB2YXIgaXNDYXRlZ29yaWNhbCA9IGlzQ2F0ZWdvcmljYWxBeGlzKGxheW91dCwgYXhpc1R5cGUpO1xuICBpZiAoaXNDYXRlZ29yaWNhbCAmJiBkYXRhS2V5ID09IG51bGwpIHtcbiAgICByZXR1cm4gcmFuZ2UoMCwgZGlzcGxheWVkRGF0YS5sZW5ndGgpO1xuICB9XG4gIGlmICh0eXBlID09PSAnY2F0ZWdvcnknKSB7XG4gICAgcmV0dXJuIGNvbXB1dGVEb21haW5PZlR5cGVDYXRlZ29yeShhbGxBcHBsaWVkVmFsdWVzLCBheGlzU2V0dGluZ3MsIGlzQ2F0ZWdvcmljYWwpO1xuICB9XG4gIGlmIChzdGFja09mZnNldFR5cGUgPT09ICdleHBhbmQnKSB7XG4gICAgcmV0dXJuIGV4cGFuZERvbWFpbjtcbiAgfVxuICByZXR1cm4gbnVtZXJpY2FsRG9tYWluO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0QXhpc0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RCYXNlQXhpcywgc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdERpc3BsYXllZERhdGEsIHNlbGVjdEFsbEFwcGxpZWRWYWx1ZXMsIHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSwgcGlja0F4aXNUeXBlLCBzZWxlY3ROdW1lcmljYWxEb21haW5dLCBjb21iaW5lQXhpc0RvbWFpbik7XG5leHBvcnQgdmFyIGNvbWJpbmVSZWFsU2NhbGVUeXBlID0gKGF4aXNDb25maWcsIGxheW91dCwgaGFzQmFyLCBjaGFydFR5cGUsIGF4aXNUeXBlKSA9PiB7XG4gIGlmIChheGlzQ29uZmlnID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciB7XG4gICAgc2NhbGUsXG4gICAgdHlwZVxuICB9ID0gYXhpc0NvbmZpZztcbiAgaWYgKHNjYWxlID09PSAnYXV0bycpIHtcbiAgICBpZiAobGF5b3V0ID09PSAncmFkaWFsJyAmJiBheGlzVHlwZSA9PT0gJ3JhZGl1c0F4aXMnKSB7XG4gICAgICByZXR1cm4gJ2JhbmQnO1xuICAgIH1cbiAgICBpZiAobGF5b3V0ID09PSAncmFkaWFsJyAmJiBheGlzVHlwZSA9PT0gJ2FuZ2xlQXhpcycpIHtcbiAgICAgIHJldHVybiAnbGluZWFyJztcbiAgICB9XG4gICAgaWYgKHR5cGUgPT09ICdjYXRlZ29yeScgJiYgY2hhcnRUeXBlICYmIChjaGFydFR5cGUuaW5kZXhPZignTGluZUNoYXJ0JykgPj0gMCB8fCBjaGFydFR5cGUuaW5kZXhPZignQXJlYUNoYXJ0JykgPj0gMCB8fCBjaGFydFR5cGUuaW5kZXhPZignQ29tcG9zZWRDaGFydCcpID49IDAgJiYgIWhhc0JhcikpIHtcbiAgICAgIHJldHVybiAncG9pbnQnO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gJ2NhdGVnb3J5Jykge1xuICAgICAgcmV0dXJuICdiYW5kJztcbiAgICB9XG4gICAgcmV0dXJuICdsaW5lYXInO1xuICB9XG4gIGlmICh0eXBlb2Ygc2NhbGUgPT09ICdzdHJpbmcnKSB7XG4gICAgdmFyIG5hbWUgPSBcInNjYWxlXCIuY29uY2F0KHVwcGVyRmlyc3Qoc2NhbGUpKTtcbiAgICByZXR1cm4gbmFtZSBpbiBkM1NjYWxlcyA/IG5hbWUgOiAncG9pbnQnO1xuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RSZWFsU2NhbGVUeXBlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzLCBzZWxlY3RDaGFydExheW91dCwgc2VsZWN0SGFzQmFyLCBzZWxlY3RDaGFydE5hbWUsIHBpY2tBeGlzVHlwZV0sIGNvbWJpbmVSZWFsU2NhbGVUeXBlKTtcbmZ1bmN0aW9uIGdldEQzU2NhbGVGcm9tVHlwZShyZWFsU2NhbGVUeXBlKSB7XG4gIGlmIChyZWFsU2NhbGVUeXBlID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIGlmIChyZWFsU2NhbGVUeXBlIGluIGQzU2NhbGVzKSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3ZSBzaG91bGQgZG8gYmV0dGVyIHR5cGUgdmVyaWZpY2F0aW9uIGhlcmVcbiAgICByZXR1cm4gZDNTY2FsZXNbcmVhbFNjYWxlVHlwZV0oKTtcbiAgfVxuICB2YXIgbmFtZSA9IFwic2NhbGVcIi5jb25jYXQodXBwZXJGaXJzdChyZWFsU2NhbGVUeXBlKSk7XG4gIGlmIChuYW1lIGluIGQzU2NhbGVzKSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3ZSBzaG91bGQgZG8gYmV0dGVyIHR5cGUgdmVyaWZpY2F0aW9uIGhlcmVcbiAgICByZXR1cm4gZDNTY2FsZXNbbmFtZV0oKTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbWJpbmVTY2FsZUZ1bmN0aW9uKGF4aXMsIHJlYWxTY2FsZVR5cGUsIGF4aXNEb21haW4sIGF4aXNSYW5nZSkge1xuICBpZiAoYXhpc0RvbWFpbiA9PSBudWxsIHx8IGF4aXNSYW5nZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBpZiAodHlwZW9mIGF4aXMuc2NhbGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIHdlJ3JlIGdvaW5nIHRvIGFzc3VtZSBoZXJlIHRoYXQgaWYgYXhpcy5zY2FsZSBpcyBhIGZ1bmN0aW9uIHRoZW4gaXQgaXMgYSBkM1NjYWxlIGZ1bmN0aW9uXG4gICAgcmV0dXJuIGF4aXMuc2NhbGUuY29weSgpLmRvbWFpbihheGlzRG9tYWluKS5yYW5nZShheGlzUmFuZ2UpO1xuICB9XG4gIHZhciBkM1NjYWxlRnVuY3Rpb24gPSBnZXREM1NjYWxlRnJvbVR5cGUocmVhbFNjYWxlVHlwZSk7XG4gIGlmIChkM1NjYWxlRnVuY3Rpb24gPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHNjYWxlID0gZDNTY2FsZUZ1bmN0aW9uLmRvbWFpbihheGlzRG9tYWluKS5yYW5nZShheGlzUmFuZ2UpO1xuICAvLyBJIGRvbid0IGxpa2UgdGhpcyBmdW5jdGlvbiBiZWNhdXNlIGl0IG11dGF0ZXMgdGhlIHNjYWxlLiBXZSBzaG91bGQgY29tZSB1cCB3aXRoIGEgd2F5IHRvIGNvbXB1dGUgdGhlIGRvbWFpbiB1cCBmcm9udC5cbiAgY2hlY2tEb21haW5PZlNjYWxlKHNjYWxlKTtcbiAgcmV0dXJuIHNjYWxlO1xufVxuZXhwb3J0IHZhciBjb21iaW5lTmljZVRpY2tzID0gKGF4aXNEb21haW4sIGF4aXNTZXR0aW5ncywgcmVhbFNjYWxlVHlwZSkgPT4ge1xuICB2YXIgZG9tYWluRGVmaW5pdGlvbiA9IGdldERvbWFpbkRlZmluaXRpb24oYXhpc1NldHRpbmdzKTtcbiAgaWYgKHJlYWxTY2FsZVR5cGUgIT09ICdhdXRvJyAmJiByZWFsU2NhbGVUeXBlICE9PSAnbGluZWFyJykge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKGF4aXNTZXR0aW5ncyAhPSBudWxsICYmIGF4aXNTZXR0aW5ncy50aWNrQ291bnQgJiYgQXJyYXkuaXNBcnJheShkb21haW5EZWZpbml0aW9uKSAmJiAoZG9tYWluRGVmaW5pdGlvblswXSA9PT0gJ2F1dG8nIHx8IGRvbWFpbkRlZmluaXRpb25bMV0gPT09ICdhdXRvJykgJiYgaXNXZWxsRm9ybWVkTnVtYmVyRG9tYWluKGF4aXNEb21haW4pKSB7XG4gICAgcmV0dXJuIGdldE5pY2VUaWNrVmFsdWVzKGF4aXNEb21haW4sIGF4aXNTZXR0aW5ncy50aWNrQ291bnQsIGF4aXNTZXR0aW5ncy5hbGxvd0RlY2ltYWxzKTtcbiAgfVxuICBpZiAoYXhpc1NldHRpbmdzICE9IG51bGwgJiYgYXhpc1NldHRpbmdzLnRpY2tDb3VudCAmJiBheGlzU2V0dGluZ3MudHlwZSA9PT0gJ251bWJlcicgJiYgaXNXZWxsRm9ybWVkTnVtYmVyRG9tYWluKGF4aXNEb21haW4pKSB7XG4gICAgcmV0dXJuIGdldFRpY2tWYWx1ZXNGaXhlZERvbWFpbihheGlzRG9tYWluLCBheGlzU2V0dGluZ3MudGlja0NvdW50LCBheGlzU2V0dGluZ3MuYWxsb3dEZWNpbWFscyk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5leHBvcnQgdmFyIHNlbGVjdE5pY2VUaWNrcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBeGlzRG9tYWluLCBzZWxlY3RBeGlzU2V0dGluZ3MsIHNlbGVjdFJlYWxTY2FsZVR5cGVdLCBjb21iaW5lTmljZVRpY2tzKTtcbmV4cG9ydCB2YXIgY29tYmluZUF4aXNEb21haW5XaXRoTmljZVRpY2tzID0gKGF4aXNTZXR0aW5ncywgZG9tYWluLCBuaWNlVGlja3MsIGF4aXNUeXBlKSA9PiB7XG4gIGlmIChcbiAgLypcbiAgICogQW5nbGUgYXhpcyBmb3Igc29tZSByZWFzb24gdXNlcyBuaWNlIHRpY2tzIHdoZW4gcmVuZGVyaW5nIGF4aXMgdGljayBsYWJlbHMsXG4gICAqIGJ1dCBkb2Vzbid0IHVzZSBuaWNlIHRpY2tzIGZvciBleHRlbmRpbmcgZG9tYWluIGxpa2UgYWxsIHRoZSBvdGhlciBheGVzIGRvLlxuICAgKiBOb3QgcmVhbGx5IHN1cmUgd2h5PyBJcyB0aGVyZSBhIGdvb2QgcmVhc29uLFxuICAgKiBvciBpcyBpdCBqdXN0IGJlY2F1c2Ugc29tZW9uZSBhZGRlZCBzdXBwb3J0IGZvciBuaWNlIHRpY2tzIHRvIHRoZSBvdGhlciBheGVzIGFuZCBmb3Jnb3QgdGhpcyBvbmU/XG4gICAqL1xuICBheGlzVHlwZSAhPT0gJ2FuZ2xlQXhpcycgJiYgKGF4aXNTZXR0aW5ncyA9PT0gbnVsbCB8fCBheGlzU2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGF4aXNTZXR0aW5ncy50eXBlKSA9PT0gJ251bWJlcicgJiYgaXNXZWxsRm9ybWVkTnVtYmVyRG9tYWluKGRvbWFpbikgJiYgQXJyYXkuaXNBcnJheShuaWNlVGlja3MpICYmIG5pY2VUaWNrcy5sZW5ndGggPiAwKSB7XG4gICAgdmFyIG1pbkZyb21Eb21haW4gPSBkb21haW5bMF07XG4gICAgdmFyIG1pbkZyb21UaWNrcyA9IG5pY2VUaWNrc1swXTtcbiAgICB2YXIgbWF4RnJvbURvbWFpbiA9IGRvbWFpblsxXTtcbiAgICB2YXIgbWF4RnJvbVRpY2tzID0gbmljZVRpY2tzW25pY2VUaWNrcy5sZW5ndGggLSAxXTtcbiAgICByZXR1cm4gW01hdGgubWluKG1pbkZyb21Eb21haW4sIG1pbkZyb21UaWNrcyksIE1hdGgubWF4KG1heEZyb21Eb21haW4sIG1heEZyb21UaWNrcyldO1xuICB9XG4gIHJldHVybiBkb21haW47XG59O1xuZXhwb3J0IHZhciBzZWxlY3RBeGlzRG9tYWluSW5jbHVkaW5nTmljZVRpY2tzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzLCBzZWxlY3RBeGlzRG9tYWluLCBzZWxlY3ROaWNlVGlja3MsIHBpY2tBeGlzVHlwZV0sIGNvbWJpbmVBeGlzRG9tYWluV2l0aE5pY2VUaWNrcyk7XG5cbi8qKlxuICogUmV0dXJucyB0aGUgc21hbGxlc3QgZ2FwLCBiZXR3ZWVuIHR3byBudW1iZXJzIGluIHRoZSBkYXRhLCBhcyBhIHJhdGlvIG9mIHRoZSB3aG9sZSByYW5nZSAobWF4IC0gbWluKS5cbiAqIElnbm9yZXMgZG9tYWluIHByb3ZpZGVkIGJ5IHVzZXIgYW5kIG9ubHkgY29uc2lkZXJzIGRvbWFpbiBmcm9tIGRhdGEuXG4gKlxuICogVGhlIHJlc3VsdCBpcyBhIG51bWJlciBiZXR3ZWVuIDAgYW5kIDEuXG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0U21hbGxlc3REaXN0YW5jZUJldHdlZW5WYWx1ZXMgPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RBbGxBcHBsaWVkVmFsdWVzLCBzZWxlY3RCYXNlQXhpcywgKGFsbERhdGFTcXVpc2hlZCwgYXhpc1NldHRpbmdzKSA9PiB7XG4gIGlmICghYXhpc1NldHRpbmdzIHx8IGF4aXNTZXR0aW5ncy50eXBlICE9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHNtYWxsZXN0RGlzdGFuY2VCZXR3ZWVuVmFsdWVzID0gSW5maW5pdHk7XG4gIHZhciBzb3J0ZWRWYWx1ZXMgPSBBcnJheS5mcm9tKG9ubHlBbGxvd051bWJlcnMoYWxsRGF0YVNxdWlzaGVkLm1hcChkID0+IGQudmFsdWUpKSkuc29ydCgoYSwgYikgPT4gYSAtIGIpO1xuICBpZiAoc29ydGVkVmFsdWVzLmxlbmd0aCA8IDIpIHtcbiAgICByZXR1cm4gSW5maW5pdHk7XG4gIH1cbiAgdmFyIGRpZmYgPSBzb3J0ZWRWYWx1ZXNbc29ydGVkVmFsdWVzLmxlbmd0aCAtIDFdIC0gc29ydGVkVmFsdWVzWzBdO1xuICBpZiAoZGlmZiA9PT0gMCkge1xuICAgIHJldHVybiBJbmZpbml0eTtcbiAgfVxuICAvLyBPbmx5IGRvIG4gLSAxIGRpc3RhbmNlIGNhbGN1bGF0aW9ucyBiZWNhdXNlIHRoZXJlJ3Mgb25seSBuIC0gMSBkaXN0YW5jZXMgYmV0d2VlbiBuIHZhbHVlcy5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBzb3J0ZWRWYWx1ZXMubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgdmFyIGRpc3RhbmNlID0gc29ydGVkVmFsdWVzW2kgKyAxXSAtIHNvcnRlZFZhbHVlc1tpXTtcbiAgICBzbWFsbGVzdERpc3RhbmNlQmV0d2VlblZhbHVlcyA9IE1hdGgubWluKHNtYWxsZXN0RGlzdGFuY2VCZXR3ZWVuVmFsdWVzLCBkaXN0YW5jZSk7XG4gIH1cbiAgcmV0dXJuIHNtYWxsZXN0RGlzdGFuY2VCZXR3ZWVuVmFsdWVzIC8gZGlmZjtcbn0pO1xudmFyIHNlbGVjdENhbGN1bGF0ZWRQYWRkaW5nID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0U21hbGxlc3REaXN0YW5jZUJldHdlZW5WYWx1ZXMsIHNlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RCYXJDYXRlZ29yeUdhcCwgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCwgKF8xLCBfMiwgXzMsIHBhZGRpbmcpID0+IHBhZGRpbmcsIChzbWFsbGVzdERpc3RhbmNlSW5QZXJjZW50LCBsYXlvdXQsIGJhckNhdGVnb3J5R2FwLCBvZmZzZXQsIHBhZGRpbmcpID0+IHtcbiAgaWYgKCFpc1dlbGxCZWhhdmVkTnVtYmVyKHNtYWxsZXN0RGlzdGFuY2VJblBlcmNlbnQpKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cbiAgdmFyIHJhbmdlV2lkdGggPSBsYXlvdXQgPT09ICd2ZXJ0aWNhbCcgPyBvZmZzZXQuaGVpZ2h0IDogb2Zmc2V0LndpZHRoO1xuICBpZiAocGFkZGluZyA9PT0gJ2dhcCcpIHtcbiAgICByZXR1cm4gc21hbGxlc3REaXN0YW5jZUluUGVyY2VudCAqIHJhbmdlV2lkdGggLyAyO1xuICB9XG4gIGlmIChwYWRkaW5nID09PSAnbm8tZ2FwJykge1xuICAgIHZhciBnYXAgPSBnZXRQZXJjZW50VmFsdWUoYmFyQ2F0ZWdvcnlHYXAsIHNtYWxsZXN0RGlzdGFuY2VJblBlcmNlbnQgKiByYW5nZVdpZHRoKTtcbiAgICB2YXIgaGFsZkJhbmQgPSBzbWFsbGVzdERpc3RhbmNlSW5QZXJjZW50ICogcmFuZ2VXaWR0aCAvIDI7XG4gICAgcmV0dXJuIGhhbGZCYW5kIC0gZ2FwIC0gKGhhbGZCYW5kIC0gZ2FwKSAvIHJhbmdlV2lkdGggKiBnYXA7XG4gIH1cbiAgcmV0dXJuIDA7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0Q2FsY3VsYXRlZFhBeGlzUGFkZGluZyA9IChzdGF0ZSwgYXhpc0lkKSA9PiB7XG4gIHZhciB4QXhpc1NldHRpbmdzID0gc2VsZWN0WEF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc0lkKTtcbiAgaWYgKHhBeGlzU2V0dGluZ3MgPT0gbnVsbCB8fCB0eXBlb2YgeEF4aXNTZXR0aW5ncy5wYWRkaW5nICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiAwO1xuICB9XG4gIHJldHVybiBzZWxlY3RDYWxjdWxhdGVkUGFkZGluZyhzdGF0ZSwgJ3hBeGlzJywgYXhpc0lkLCB4QXhpc1NldHRpbmdzLnBhZGRpbmcpO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0Q2FsY3VsYXRlZFlBeGlzUGFkZGluZyA9IChzdGF0ZSwgYXhpc0lkKSA9PiB7XG4gIHZhciB5QXhpc1NldHRpbmdzID0gc2VsZWN0WUF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc0lkKTtcbiAgaWYgKHlBeGlzU2V0dGluZ3MgPT0gbnVsbCB8fCB0eXBlb2YgeUF4aXNTZXR0aW5ncy5wYWRkaW5nICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiAwO1xuICB9XG4gIHJldHVybiBzZWxlY3RDYWxjdWxhdGVkUGFkZGluZyhzdGF0ZSwgJ3lBeGlzJywgYXhpc0lkLCB5QXhpc1NldHRpbmdzLnBhZGRpbmcpO1xufTtcbnZhciBzZWxlY3RYQXhpc1BhZGRpbmcgPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RYQXhpc1NldHRpbmdzLCBzZWxlY3RDYWxjdWxhdGVkWEF4aXNQYWRkaW5nLCAoeEF4aXNTZXR0aW5ncywgY2FsY3VsYXRlZCkgPT4ge1xuICB2YXIgX3BhZGRpbmckbGVmdCwgX3BhZGRpbmckcmlnaHQ7XG4gIGlmICh4QXhpc1NldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbGVmdDogMCxcbiAgICAgIHJpZ2h0OiAwXG4gICAgfTtcbiAgfVxuICB2YXIge1xuICAgIHBhZGRpbmdcbiAgfSA9IHhBeGlzU2V0dGluZ3M7XG4gIGlmICh0eXBlb2YgcGFkZGluZyA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbGVmdDogY2FsY3VsYXRlZCxcbiAgICAgIHJpZ2h0OiBjYWxjdWxhdGVkXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGxlZnQ6ICgoX3BhZGRpbmckbGVmdCA9IHBhZGRpbmcubGVmdCkgIT09IG51bGwgJiYgX3BhZGRpbmckbGVmdCAhPT0gdm9pZCAwID8gX3BhZGRpbmckbGVmdCA6IDApICsgY2FsY3VsYXRlZCxcbiAgICByaWdodDogKChfcGFkZGluZyRyaWdodCA9IHBhZGRpbmcucmlnaHQpICE9PSBudWxsICYmIF9wYWRkaW5nJHJpZ2h0ICE9PSB2b2lkIDAgPyBfcGFkZGluZyRyaWdodCA6IDApICsgY2FsY3VsYXRlZFxuICB9O1xufSk7XG52YXIgc2VsZWN0WUF4aXNQYWRkaW5nID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0WUF4aXNTZXR0aW5ncywgc2VsZWN0Q2FsY3VsYXRlZFlBeGlzUGFkZGluZywgKHlBeGlzU2V0dGluZ3MsIGNhbGN1bGF0ZWQpID0+IHtcbiAgdmFyIF9wYWRkaW5nJHRvcCwgX3BhZGRpbmckYm90dG9tO1xuICBpZiAoeUF4aXNTZXR0aW5ncyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvcDogMCxcbiAgICAgIGJvdHRvbTogMFxuICAgIH07XG4gIH1cbiAgdmFyIHtcbiAgICBwYWRkaW5nXG4gIH0gPSB5QXhpc1NldHRpbmdzO1xuICBpZiAodHlwZW9mIHBhZGRpbmcgPT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvcDogY2FsY3VsYXRlZCxcbiAgICAgIGJvdHRvbTogY2FsY3VsYXRlZFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB0b3A6ICgoX3BhZGRpbmckdG9wID0gcGFkZGluZy50b3ApICE9PSBudWxsICYmIF9wYWRkaW5nJHRvcCAhPT0gdm9pZCAwID8gX3BhZGRpbmckdG9wIDogMCkgKyBjYWxjdWxhdGVkLFxuICAgIGJvdHRvbTogKChfcGFkZGluZyRib3R0b20gPSBwYWRkaW5nLmJvdHRvbSkgIT09IG51bGwgJiYgX3BhZGRpbmckYm90dG9tICE9PSB2b2lkIDAgPyBfcGFkZGluZyRib3R0b20gOiAwKSArIGNhbGN1bGF0ZWRcbiAgfTtcbn0pO1xuZXhwb3J0IHZhciBjb21iaW5lWEF4aXNSYW5nZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RYQXhpc1BhZGRpbmcsIHNlbGVjdEJydXNoRGltZW5zaW9ucywgc2VsZWN0QnJ1c2hTZXR0aW5ncywgKF9zdGF0ZSwgX2F4aXNJZCwgaXNQYW5vcmFtYSkgPT4gaXNQYW5vcmFtYV0sIChvZmZzZXQsIHBhZGRpbmcsIGJydXNoRGltZW5zaW9ucywgX3JlZjQsIGlzUGFub3JhbWEpID0+IHtcbiAgdmFyIHtcbiAgICBwYWRkaW5nOiBicnVzaFBhZGRpbmdcbiAgfSA9IF9yZWY0O1xuICBpZiAoaXNQYW5vcmFtYSkge1xuICAgIHJldHVybiBbYnJ1c2hQYWRkaW5nLmxlZnQsIGJydXNoRGltZW5zaW9ucy53aWR0aCAtIGJydXNoUGFkZGluZy5yaWdodF07XG4gIH1cbiAgcmV0dXJuIFtvZmZzZXQubGVmdCArIHBhZGRpbmcubGVmdCwgb2Zmc2V0LmxlZnQgKyBvZmZzZXQud2lkdGggLSBwYWRkaW5nLnJpZ2h0XTtcbn0pO1xuZXhwb3J0IHZhciBjb21iaW5lWUF4aXNSYW5nZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RDaGFydExheW91dCwgc2VsZWN0WUF4aXNQYWRkaW5nLCBzZWxlY3RCcnVzaERpbWVuc2lvbnMsIHNlbGVjdEJydXNoU2V0dGluZ3MsIChfc3RhdGUsIF9heGlzSWQsIGlzUGFub3JhbWEpID0+IGlzUGFub3JhbWFdLCAob2Zmc2V0LCBsYXlvdXQsIHBhZGRpbmcsIGJydXNoRGltZW5zaW9ucywgX3JlZjUsIGlzUGFub3JhbWEpID0+IHtcbiAgdmFyIHtcbiAgICBwYWRkaW5nOiBicnVzaFBhZGRpbmdcbiAgfSA9IF9yZWY1O1xuICBpZiAoaXNQYW5vcmFtYSkge1xuICAgIHJldHVybiBbYnJ1c2hEaW1lbnNpb25zLmhlaWdodCAtIGJydXNoUGFkZGluZy5ib3R0b20sIGJydXNoUGFkZGluZy50b3BdO1xuICB9XG4gIGlmIChsYXlvdXQgPT09ICdob3Jpem9udGFsJykge1xuICAgIHJldHVybiBbb2Zmc2V0LnRvcCArIG9mZnNldC5oZWlnaHQgLSBwYWRkaW5nLmJvdHRvbSwgb2Zmc2V0LnRvcCArIHBhZGRpbmcudG9wXTtcbiAgfVxuICByZXR1cm4gW29mZnNldC50b3AgKyBwYWRkaW5nLnRvcCwgb2Zmc2V0LnRvcCArIG9mZnNldC5oZWlnaHQgLSBwYWRkaW5nLmJvdHRvbV07XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0QXhpc1JhbmdlID0gKHN0YXRlLCBheGlzVHlwZSwgYXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiB7XG4gIHZhciBfc2VsZWN0WkF4aXNTZXR0aW5ncztcbiAgc3dpdGNoIChheGlzVHlwZSkge1xuICAgIGNhc2UgJ3hBeGlzJzpcbiAgICAgIHJldHVybiBjb21iaW5lWEF4aXNSYW5nZShzdGF0ZSwgYXhpc0lkLCBpc1Bhbm9yYW1hKTtcbiAgICBjYXNlICd5QXhpcyc6XG4gICAgICByZXR1cm4gY29tYmluZVlBeGlzUmFuZ2Uoc3RhdGUsIGF4aXNJZCwgaXNQYW5vcmFtYSk7XG4gICAgY2FzZSAnekF4aXMnOlxuICAgICAgcmV0dXJuIChfc2VsZWN0WkF4aXNTZXR0aW5ncyA9IHNlbGVjdFpBeGlzU2V0dGluZ3Moc3RhdGUsIGF4aXNJZCkpID09PSBudWxsIHx8IF9zZWxlY3RaQXhpc1NldHRpbmdzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfc2VsZWN0WkF4aXNTZXR0aW5ncy5yYW5nZTtcbiAgICBjYXNlICdhbmdsZUF4aXMnOlxuICAgICAgcmV0dXJuIHNlbGVjdEFuZ2xlQXhpc1JhbmdlKHN0YXRlKTtcbiAgICBjYXNlICdyYWRpdXNBeGlzJzpcbiAgICAgIHJldHVybiBzZWxlY3RSYWRpdXNBeGlzUmFuZ2Uoc3RhdGUsIGF4aXNJZCk7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn07XG5leHBvcnQgdmFyIHNlbGVjdEF4aXNSYW5nZVdpdGhSZXZlcnNlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzLCBzZWxlY3RBeGlzUmFuZ2VdLCBjb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UpO1xuZXhwb3J0IHZhciBzZWxlY3RBeGlzU2NhbGUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QmFzZUF4aXMsIHNlbGVjdFJlYWxTY2FsZVR5cGUsIHNlbGVjdEF4aXNEb21haW5JbmNsdWRpbmdOaWNlVGlja3MsIHNlbGVjdEF4aXNSYW5nZVdpdGhSZXZlcnNlXSwgY29tYmluZVNjYWxlRnVuY3Rpb24pO1xuZXhwb3J0IHZhciBzZWxlY3RFcnJvckJhcnNTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDYXJ0ZXNpYW5JdGVtc1NldHRpbmdzLCBzZWxlY3RBbGxFcnJvckJhclNldHRpbmdzLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lUmVsZXZhbnRFcnJvckJhclNldHRpbmdzKTtcbmZ1bmN0aW9uIGNvbXBhcmVJZHMoYSwgYikge1xuICBpZiAoYS5pZCA8IGIuaWQpIHtcbiAgICByZXR1cm4gLTE7XG4gIH1cbiAgaWYgKGEuaWQgPiBiLmlkKSB7XG4gICAgcmV0dXJuIDE7XG4gIH1cbiAgcmV0dXJuIDA7XG59XG52YXIgcGlja0F4aXNPcmllbnRhdGlvbiA9IChfc3RhdGUsIG9yaWVudGF0aW9uKSA9PiBvcmllbnRhdGlvbjtcbnZhciBwaWNrTWlycm9yID0gKF9zdGF0ZSwgX29yaWVudGF0aW9uLCBtaXJyb3IpID0+IG1pcnJvcjtcbnZhciBzZWxlY3RBbGxYQXhlc1dpdGhPZmZzZXRUeXBlID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0QWxsWEF4ZXMsIHBpY2tBeGlzT3JpZW50YXRpb24sIHBpY2tNaXJyb3IsIChhbGxBeGVzLCBvcmllbnRhdGlvbiwgbWlycm9yKSA9PiBhbGxBeGVzLmZpbHRlcihheGlzID0+IGF4aXMub3JpZW50YXRpb24gPT09IG9yaWVudGF0aW9uKS5maWx0ZXIoYXhpcyA9PiBheGlzLm1pcnJvciA9PT0gbWlycm9yKS5zb3J0KGNvbXBhcmVJZHMpKTtcbnZhciBzZWxlY3RBbGxZQXhlc1dpdGhPZmZzZXRUeXBlID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0QWxsWUF4ZXMsIHBpY2tBeGlzT3JpZW50YXRpb24sIHBpY2tNaXJyb3IsIChhbGxBeGVzLCBvcmllbnRhdGlvbiwgbWlycm9yKSA9PiBhbGxBeGVzLmZpbHRlcihheGlzID0+IGF4aXMub3JpZW50YXRpb24gPT09IG9yaWVudGF0aW9uKS5maWx0ZXIoYXhpcyA9PiBheGlzLm1pcnJvciA9PT0gbWlycm9yKS5zb3J0KGNvbXBhcmVJZHMpKTtcbnZhciBnZXRYQXhpc1NpemUgPSAob2Zmc2V0LCBheGlzU2V0dGluZ3MpID0+IHtcbiAgcmV0dXJuIHtcbiAgICB3aWR0aDogb2Zmc2V0LndpZHRoLFxuICAgIGhlaWdodDogYXhpc1NldHRpbmdzLmhlaWdodFxuICB9O1xufTtcbnZhciBnZXRZQXhpc1NpemUgPSAob2Zmc2V0LCBheGlzU2V0dGluZ3MpID0+IHtcbiAgdmFyIHdpZHRoID0gdHlwZW9mIGF4aXNTZXR0aW5ncy53aWR0aCA9PT0gJ251bWJlcicgPyBheGlzU2V0dGluZ3Mud2lkdGggOiBERUZBVUxUX1lfQVhJU19XSURUSDtcbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQ6IG9mZnNldC5oZWlnaHRcbiAgfTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdFhBeGlzU2l6ZSA9IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwsIHNlbGVjdFhBeGlzU2V0dGluZ3MsIGdldFhBeGlzU2l6ZSk7XG52YXIgY29tYmluZVhBeGlzUG9zaXRpb25TdGFydGluZ1BvaW50ID0gKG9mZnNldCwgb3JpZW50YXRpb24sIGNoYXJ0SGVpZ2h0KSA9PiB7XG4gIHN3aXRjaCAob3JpZW50YXRpb24pIHtcbiAgICBjYXNlICd0b3AnOlxuICAgICAgcmV0dXJuIG9mZnNldC50b3A7XG4gICAgY2FzZSAnYm90dG9tJzpcbiAgICAgIHJldHVybiBjaGFydEhlaWdodCAtIG9mZnNldC5ib3R0b207XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiAwO1xuICB9XG59O1xudmFyIGNvbWJpbmVZQXhpc1Bvc2l0aW9uU3RhcnRpbmdQb2ludCA9IChvZmZzZXQsIG9yaWVudGF0aW9uLCBjaGFydFdpZHRoKSA9PiB7XG4gIHN3aXRjaCAob3JpZW50YXRpb24pIHtcbiAgICBjYXNlICdsZWZ0JzpcbiAgICAgIHJldHVybiBvZmZzZXQubGVmdDtcbiAgICBjYXNlICdyaWdodCc6XG4gICAgICByZXR1cm4gY2hhcnRXaWR0aCAtIG9mZnNldC5yaWdodDtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIDA7XG4gIH1cbn07XG5leHBvcnQgdmFyIHNlbGVjdEFsbFhBeGVzT2Zmc2V0U3RlcHMgPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RDaGFydEhlaWdodCwgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCwgc2VsZWN0QWxsWEF4ZXNXaXRoT2Zmc2V0VHlwZSwgcGlja0F4aXNPcmllbnRhdGlvbiwgcGlja01pcnJvciwgKGNoYXJ0SGVpZ2h0LCBvZmZzZXQsIGFsbEF4ZXNXaXRoU2FtZU9mZnNldFR5cGUsIG9yaWVudGF0aW9uLCBtaXJyb3IpID0+IHtcbiAgdmFyIHN0ZXBzID0ge307XG4gIHZhciBwb3NpdGlvbjtcbiAgYWxsQXhlc1dpdGhTYW1lT2Zmc2V0VHlwZS5mb3JFYWNoKGF4aXMgPT4ge1xuICAgIHZhciBheGlzU2l6ZSA9IGdldFhBeGlzU2l6ZShvZmZzZXQsIGF4aXMpO1xuICAgIGlmIChwb3NpdGlvbiA9PSBudWxsKSB7XG4gICAgICBwb3NpdGlvbiA9IGNvbWJpbmVYQXhpc1Bvc2l0aW9uU3RhcnRpbmdQb2ludChvZmZzZXQsIG9yaWVudGF0aW9uLCBjaGFydEhlaWdodCk7XG4gICAgfVxuICAgIHZhciBuZWVkU3BhY2UgPSBvcmllbnRhdGlvbiA9PT0gJ3RvcCcgJiYgIW1pcnJvciB8fCBvcmllbnRhdGlvbiA9PT0gJ2JvdHRvbScgJiYgbWlycm9yO1xuICAgIHN0ZXBzW2F4aXMuaWRdID0gcG9zaXRpb24gLSBOdW1iZXIobmVlZFNwYWNlKSAqIGF4aXNTaXplLmhlaWdodDtcbiAgICBwb3NpdGlvbiArPSAobmVlZFNwYWNlID8gLTEgOiAxKSAqIGF4aXNTaXplLmhlaWdodDtcbiAgfSk7XG4gIHJldHVybiBzdGVwcztcbn0pO1xuZXhwb3J0IHZhciBzZWxlY3RBbGxZQXhlc09mZnNldFN0ZXBzID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0Q2hhcnRXaWR0aCwgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCwgc2VsZWN0QWxsWUF4ZXNXaXRoT2Zmc2V0VHlwZSwgcGlja0F4aXNPcmllbnRhdGlvbiwgcGlja01pcnJvciwgKGNoYXJ0V2lkdGgsIG9mZnNldCwgYWxsQXhlc1dpdGhTYW1lT2Zmc2V0VHlwZSwgb3JpZW50YXRpb24sIG1pcnJvcikgPT4ge1xuICB2YXIgc3RlcHMgPSB7fTtcbiAgdmFyIHBvc2l0aW9uO1xuICBhbGxBeGVzV2l0aFNhbWVPZmZzZXRUeXBlLmZvckVhY2goYXhpcyA9PiB7XG4gICAgdmFyIGF4aXNTaXplID0gZ2V0WUF4aXNTaXplKG9mZnNldCwgYXhpcyk7XG4gICAgaWYgKHBvc2l0aW9uID09IG51bGwpIHtcbiAgICAgIHBvc2l0aW9uID0gY29tYmluZVlBeGlzUG9zaXRpb25TdGFydGluZ1BvaW50KG9mZnNldCwgb3JpZW50YXRpb24sIGNoYXJ0V2lkdGgpO1xuICAgIH1cbiAgICB2YXIgbmVlZFNwYWNlID0gb3JpZW50YXRpb24gPT09ICdsZWZ0JyAmJiAhbWlycm9yIHx8IG9yaWVudGF0aW9uID09PSAncmlnaHQnICYmIG1pcnJvcjtcbiAgICBzdGVwc1theGlzLmlkXSA9IHBvc2l0aW9uIC0gTnVtYmVyKG5lZWRTcGFjZSkgKiBheGlzU2l6ZS53aWR0aDtcbiAgICBwb3NpdGlvbiArPSAobmVlZFNwYWNlID8gLTEgOiAxKSAqIGF4aXNTaXplLndpZHRoO1xuICB9KTtcbiAgcmV0dXJuIHN0ZXBzO1xufSk7XG52YXIgc2VsZWN0WEF4aXNPZmZzZXRTdGVwcyA9IChzdGF0ZSwgYXhpc0lkKSA9PiB7XG4gIHZhciBheGlzU2V0dGluZ3MgPSBzZWxlY3RYQXhpc1NldHRpbmdzKHN0YXRlLCBheGlzSWQpO1xuICBpZiAoYXhpc1NldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBzZWxlY3RBbGxYQXhlc09mZnNldFN0ZXBzKHN0YXRlLCBheGlzU2V0dGluZ3Mub3JpZW50YXRpb24sIGF4aXNTZXR0aW5ncy5taXJyb3IpO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0WEF4aXNQb3NpdGlvbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RYQXhpc1NldHRpbmdzLCBzZWxlY3RYQXhpc09mZnNldFN0ZXBzLCAoXywgYXhpc0lkKSA9PiBheGlzSWRdLCAob2Zmc2V0LCBheGlzU2V0dGluZ3MsIGFsbFN0ZXBzLCBheGlzSWQpID0+IHtcbiAgaWYgKGF4aXNTZXR0aW5ncyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgc3RlcE9mVGhpc0F4aXMgPSBhbGxTdGVwcyA9PT0gbnVsbCB8fCBhbGxTdGVwcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYWxsU3RlcHNbYXhpc0lkXTtcbiAgaWYgKHN0ZXBPZlRoaXNBeGlzID09IG51bGwpIHtcbiAgICByZXR1cm4ge1xuICAgICAgeDogb2Zmc2V0LmxlZnQsXG4gICAgICB5OiAwXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHg6IG9mZnNldC5sZWZ0LFxuICAgIHk6IHN0ZXBPZlRoaXNBeGlzXG4gIH07XG59KTtcbnZhciBzZWxlY3RZQXhpc09mZnNldFN0ZXBzID0gKHN0YXRlLCBheGlzSWQpID0+IHtcbiAgdmFyIGF4aXNTZXR0aW5ncyA9IHNlbGVjdFlBeGlzU2V0dGluZ3Moc3RhdGUsIGF4aXNJZCk7XG4gIGlmIChheGlzU2V0dGluZ3MgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHNlbGVjdEFsbFlBeGVzT2Zmc2V0U3RlcHMoc3RhdGUsIGF4aXNTZXR0aW5ncy5vcmllbnRhdGlvbiwgYXhpc1NldHRpbmdzLm1pcnJvcik7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RZQXhpc1Bvc2l0aW9uID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwsIHNlbGVjdFlBeGlzU2V0dGluZ3MsIHNlbGVjdFlBeGlzT2Zmc2V0U3RlcHMsIChfLCBheGlzSWQpID0+IGF4aXNJZF0sIChvZmZzZXQsIGF4aXNTZXR0aW5ncywgYWxsU3RlcHMsIGF4aXNJZCkgPT4ge1xuICBpZiAoYXhpc1NldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBzdGVwT2ZUaGlzQXhpcyA9IGFsbFN0ZXBzID09PSBudWxsIHx8IGFsbFN0ZXBzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhbGxTdGVwc1theGlzSWRdO1xuICBpZiAoc3RlcE9mVGhpc0F4aXMgPT0gbnVsbCkge1xuICAgIHJldHVybiB7XG4gICAgICB4OiAwLFxuICAgICAgeTogb2Zmc2V0LnRvcFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4OiBzdGVwT2ZUaGlzQXhpcyxcbiAgICB5OiBvZmZzZXQudG9wXG4gIH07XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0WUF4aXNTaXplID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCwgc2VsZWN0WUF4aXNTZXR0aW5ncywgKG9mZnNldCwgYXhpc1NldHRpbmdzKSA9PiB7XG4gIHZhciB3aWR0aCA9IHR5cGVvZiBheGlzU2V0dGluZ3Mud2lkdGggPT09ICdudW1iZXInID8gYXhpc1NldHRpbmdzLndpZHRoIDogREVGQVVMVF9ZX0FYSVNfV0lEVEg7XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0OiBvZmZzZXQuaGVpZ2h0XG4gIH07XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0Q2FydGVzaWFuQXhpc1NpemUgPSAoc3RhdGUsIGF4aXNUeXBlLCBheGlzSWQpID0+IHtcbiAgc3dpdGNoIChheGlzVHlwZSkge1xuICAgIGNhc2UgJ3hBeGlzJzpcbiAgICAgIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdFhBeGlzU2l6ZShzdGF0ZSwgYXhpc0lkKS53aWR0aDtcbiAgICAgIH1cbiAgICBjYXNlICd5QXhpcyc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzZWxlY3RZQXhpc1NpemUoc3RhdGUsIGF4aXNJZCkuaGVpZ2h0O1xuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gIH1cbn07XG5leHBvcnQgdmFyIGNvbWJpbmVEdXBsaWNhdGVEb21haW4gPSAoY2hhcnRMYXlvdXQsIGFwcGxpZWRWYWx1ZXMsIGF4aXMsIGF4aXNUeXBlKSA9PiB7XG4gIGlmIChheGlzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciB7XG4gICAgYWxsb3dEdXBsaWNhdGVkQ2F0ZWdvcnksXG4gICAgdHlwZSxcbiAgICBkYXRhS2V5XG4gIH0gPSBheGlzO1xuICB2YXIgaXNDYXRlZ29yaWNhbCA9IGlzQ2F0ZWdvcmljYWxBeGlzKGNoYXJ0TGF5b3V0LCBheGlzVHlwZSk7XG4gIHZhciBhbGxEYXRhID0gYXBwbGllZFZhbHVlcy5tYXAoYXYgPT4gYXYudmFsdWUpO1xuICBpZiAoZGF0YUtleSAmJiBpc0NhdGVnb3JpY2FsICYmIHR5cGUgPT09ICdjYXRlZ29yeScgJiYgYWxsb3dEdXBsaWNhdGVkQ2F0ZWdvcnkgJiYgaGFzRHVwbGljYXRlKGFsbERhdGEpKSB7XG4gICAgcmV0dXJuIGFsbERhdGE7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5leHBvcnQgdmFyIHNlbGVjdER1cGxpY2F0ZURvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0QWxsQXBwbGllZFZhbHVlcywgc2VsZWN0QmFzZUF4aXMsIHBpY2tBeGlzVHlwZV0sIGNvbWJpbmVEdXBsaWNhdGVEb21haW4pO1xuZXhwb3J0IHZhciBjb21iaW5lQ2F0ZWdvcmljYWxEb21haW4gPSAobGF5b3V0LCBhcHBsaWVkVmFsdWVzLCBheGlzLCBheGlzVHlwZSkgPT4ge1xuICBpZiAoYXhpcyA9PSBudWxsIHx8IGF4aXMuZGF0YUtleSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIHR5cGUsXG4gICAgc2NhbGVcbiAgfSA9IGF4aXM7XG4gIHZhciBpc0NhdGVnb3JpY2FsID0gaXNDYXRlZ29yaWNhbEF4aXMobGF5b3V0LCBheGlzVHlwZSk7XG4gIGlmIChpc0NhdGVnb3JpY2FsICYmICh0eXBlID09PSAnbnVtYmVyJyB8fCBzY2FsZSAhPT0gJ2F1dG8nKSkge1xuICAgIHJldHVybiBhcHBsaWVkVmFsdWVzLm1hcChkID0+IGQudmFsdWUpO1xuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RDYXRlZ29yaWNhbERvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0QWxsQXBwbGllZFZhbHVlcywgc2VsZWN0QXhpc1NldHRpbmdzLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lQ2F0ZWdvcmljYWxEb21haW4pO1xuZXhwb3J0IHZhciBzZWxlY3RBeGlzUHJvcHNOZWVkZWRGb3JDYXJ0ZXNpYW5HcmlkVGlja3NHZW5lcmF0b3IgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdENhcnRlc2lhbkF4aXNTZXR0aW5ncywgc2VsZWN0UmVhbFNjYWxlVHlwZSwgc2VsZWN0QXhpc1NjYWxlLCBzZWxlY3REdXBsaWNhdGVEb21haW4sIHNlbGVjdENhdGVnb3JpY2FsRG9tYWluLCBzZWxlY3RBeGlzUmFuZ2UsIHNlbGVjdE5pY2VUaWNrcywgcGlja0F4aXNUeXBlXSwgKGxheW91dCwgYXhpcywgcmVhbFNjYWxlVHlwZSwgc2NhbGUsIGR1cGxpY2F0ZURvbWFpbiwgY2F0ZWdvcmljYWxEb21haW4sIGF4aXNSYW5nZSwgbmljZVRpY2tzLCBheGlzVHlwZSkgPT4ge1xuICBpZiAoYXhpcyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIGlzQ2F0ZWdvcmljYWwgPSBpc0NhdGVnb3JpY2FsQXhpcyhsYXlvdXQsIGF4aXNUeXBlKTtcbiAgcmV0dXJuIHtcbiAgICBhbmdsZTogYXhpcy5hbmdsZSxcbiAgICBpbnRlcnZhbDogYXhpcy5pbnRlcnZhbCxcbiAgICBtaW5UaWNrR2FwOiBheGlzLm1pblRpY2tHYXAsXG4gICAgb3JpZW50YXRpb246IGF4aXMub3JpZW50YXRpb24sXG4gICAgdGljazogYXhpcy50aWNrLFxuICAgIHRpY2tDb3VudDogYXhpcy50aWNrQ291bnQsXG4gICAgdGlja0Zvcm1hdHRlcjogYXhpcy50aWNrRm9ybWF0dGVyLFxuICAgIHRpY2tzOiBheGlzLnRpY2tzLFxuICAgIHR5cGU6IGF4aXMudHlwZSxcbiAgICB1bml0OiBheGlzLnVuaXQsXG4gICAgYXhpc1R5cGUsXG4gICAgY2F0ZWdvcmljYWxEb21haW4sXG4gICAgZHVwbGljYXRlRG9tYWluLFxuICAgIGlzQ2F0ZWdvcmljYWwsXG4gICAgbmljZVRpY2tzLFxuICAgIHJhbmdlOiBheGlzUmFuZ2UsXG4gICAgcmVhbFNjYWxlVHlwZSxcbiAgICBzY2FsZVxuICB9O1xufSk7XG5leHBvcnQgdmFyIGNvbWJpbmVBeGlzVGlja3MgPSAobGF5b3V0LCBheGlzLCByZWFsU2NhbGVUeXBlLCBzY2FsZSwgbmljZVRpY2tzLCBheGlzUmFuZ2UsIGR1cGxpY2F0ZURvbWFpbiwgY2F0ZWdvcmljYWxEb21haW4sIGF4aXNUeXBlKSA9PiB7XG4gIGlmIChheGlzID09IG51bGwgfHwgc2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIGlzQ2F0ZWdvcmljYWwgPSBpc0NhdGVnb3JpY2FsQXhpcyhsYXlvdXQsIGF4aXNUeXBlKTtcbiAgdmFyIHtcbiAgICB0eXBlLFxuICAgIHRpY2tzLFxuICAgIHRpY2tDb3VudFxuICB9ID0gYXhpcztcblxuICAvLyBUaGlzIGlzIHRlc3RpbmcgZm9yIGBzY2FsZUJhbmRgIGJ1dCBmb3IgYmFuZCBheGlzIHRoZSB0eXBlIGlzIHJlcG9ydGVkIGFzIGBiYW5kYCBzbyB0aGlzIGxvb2tzIGxpa2UgYSBkZWFkIGNvZGUgd2l0aCBhIHdvcmthcm91bmQgZWxzZXdoZXJlP1xuICB2YXIgb2Zmc2V0Rm9yQmFuZCA9IHJlYWxTY2FsZVR5cGUgPT09ICdzY2FsZUJhbmQnICYmIHR5cGVvZiBzY2FsZS5iYW5kd2lkdGggPT09ICdmdW5jdGlvbicgPyBzY2FsZS5iYW5kd2lkdGgoKSAvIDIgOiAyO1xuICB2YXIgb2Zmc2V0ID0gdHlwZSA9PT0gJ2NhdGVnb3J5JyAmJiBzY2FsZS5iYW5kd2lkdGggPyBzY2FsZS5iYW5kd2lkdGgoKSAvIG9mZnNldEZvckJhbmQgOiAwO1xuICBvZmZzZXQgPSBheGlzVHlwZSA9PT0gJ2FuZ2xlQXhpcycgJiYgYXhpc1JhbmdlICE9IG51bGwgJiYgYXhpc1JhbmdlLmxlbmd0aCA+PSAyID8gbWF0aFNpZ24oYXhpc1JhbmdlWzBdIC0gYXhpc1JhbmdlWzFdKSAqIDIgKiBvZmZzZXQgOiBvZmZzZXQ7XG5cbiAgLy8gVGhlIHRpY2tzIHNldCBieSB1c2VyIHNob3VsZCBvbmx5IGFmZmVjdCB0aGUgdGlja3MgYWRqYWNlbnQgdG8gYXhpcyBsaW5lXG4gIHZhciB0aWNrc09yTmljZVRpY2tzID0gdGlja3MgfHwgbmljZVRpY2tzO1xuICBpZiAodGlja3NPck5pY2VUaWNrcykge1xuICAgIHZhciByZXN1bHQgPSB0aWNrc09yTmljZVRpY2tzLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XG4gICAgICB2YXIgc2NhbGVDb250ZW50ID0gZHVwbGljYXRlRG9tYWluID8gZHVwbGljYXRlRG9tYWluLmluZGV4T2YoZW50cnkpIDogZW50cnk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpbmRleCxcbiAgICAgICAgLy8gSWYgdGhlIHNjYWxlQ29udGVudCBpcyBub3QgYSBudW1iZXIsIHRoZSBjb29yZGluYXRlIHdpbGwgYmUgTmFOLlxuICAgICAgICAvLyBUaGF0IGNvdWxkIGJlIHRoZSBjYXNlIGZvciBleGFtcGxlIHdpdGggYSBQb2ludFNjYWxlIGFuZCBhIHN0cmluZyBhcyBkb21haW4uXG4gICAgICAgIGNvb3JkaW5hdGU6IHNjYWxlKHNjYWxlQ29udGVudCkgKyBvZmZzZXQsXG4gICAgICAgIHZhbHVlOiBlbnRyeSxcbiAgICAgICAgb2Zmc2V0XG4gICAgICB9O1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQuZmlsdGVyKHJvdyA9PiAhaXNOYW4ocm93LmNvb3JkaW5hdGUpKTtcbiAgfVxuXG4gIC8vIFdoZW4gYXhpcyBpcyBhIGNhdGVnb3JpY2FsIGF4aXMsIGJ1dCB0aGUgdHlwZSBvZiBheGlzIGlzIG51bWJlciBvciB0aGUgc2NhbGUgb2YgYXhpcyBpcyBub3QgXCJhdXRvXCJcbiAgaWYgKGlzQ2F0ZWdvcmljYWwgJiYgY2F0ZWdvcmljYWxEb21haW4pIHtcbiAgICByZXR1cm4gY2F0ZWdvcmljYWxEb21haW4ubWFwKChlbnRyeSwgaW5kZXgpID0+ICh7XG4gICAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgICB2YWx1ZTogZW50cnksXG4gICAgICBpbmRleCxcbiAgICAgIG9mZnNldFxuICAgIH0pKTtcbiAgfVxuICBpZiAoc2NhbGUudGlja3MpIHtcbiAgICByZXR1cm4gc2NhbGUudGlja3ModGlja0NvdW50KVxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3Igd2h5IGRvZXMgdGhlIG9mZnNldCBnbyBoZXJlPyBUaGUgdHlwZSBkb2VzIG5vdCByZXF1aXJlIGl0XG4gICAgLm1hcChlbnRyeSA9PiAoe1xuICAgICAgY29vcmRpbmF0ZTogc2NhbGUoZW50cnkpICsgb2Zmc2V0LFxuICAgICAgdmFsdWU6IGVudHJ5LFxuICAgICAgb2Zmc2V0XG4gICAgfSkpO1xuICB9XG5cbiAgLy8gV2hlbiBheGlzIGhhcyBkdXBsaWNhdGVkIHRleHQsIHNlcmlhbCBudW1iZXJzIGFyZSB1c2VkIHRvIGdlbmVyYXRlIHNjYWxlXG4gIHJldHVybiBzY2FsZS5kb21haW4oKS5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKHtcbiAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgdmFsdWU6IGR1cGxpY2F0ZURvbWFpbiA/IGR1cGxpY2F0ZURvbWFpbltlbnRyeV0gOiBlbnRyeSxcbiAgICBpbmRleCxcbiAgICBvZmZzZXRcbiAgfSkpO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0VGlja3NPZkF4aXMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdEF4aXNTZXR0aW5ncywgc2VsZWN0UmVhbFNjYWxlVHlwZSwgc2VsZWN0QXhpc1NjYWxlLCBzZWxlY3ROaWNlVGlja3MsIHNlbGVjdEF4aXNSYW5nZSwgc2VsZWN0RHVwbGljYXRlRG9tYWluLCBzZWxlY3RDYXRlZ29yaWNhbERvbWFpbiwgcGlja0F4aXNUeXBlXSwgY29tYmluZUF4aXNUaWNrcyk7XG5leHBvcnQgdmFyIGNvbWJpbmVHcmFwaGljYWxJdGVtVGlja3MgPSAobGF5b3V0LCBheGlzLCBzY2FsZSwgYXhpc1JhbmdlLCBkdXBsaWNhdGVEb21haW4sIGNhdGVnb3JpY2FsRG9tYWluLCBheGlzVHlwZSkgPT4ge1xuICBpZiAoYXhpcyA9PSBudWxsIHx8IHNjYWxlID09IG51bGwgfHwgYXhpc1JhbmdlID09IG51bGwgfHwgYXhpc1JhbmdlWzBdID09PSBheGlzUmFuZ2VbMV0pIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBpc0NhdGVnb3JpY2FsID0gaXNDYXRlZ29yaWNhbEF4aXMobGF5b3V0LCBheGlzVHlwZSk7XG4gIHZhciB7XG4gICAgdGlja0NvdW50XG4gIH0gPSBheGlzO1xuICB2YXIgb2Zmc2V0ID0gMDtcbiAgb2Zmc2V0ID0gYXhpc1R5cGUgPT09ICdhbmdsZUF4aXMnICYmIChheGlzUmFuZ2UgPT09IG51bGwgfHwgYXhpc1JhbmdlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBheGlzUmFuZ2UubGVuZ3RoKSA+PSAyID8gbWF0aFNpZ24oYXhpc1JhbmdlWzBdIC0gYXhpc1JhbmdlWzFdKSAqIDIgKiBvZmZzZXQgOiBvZmZzZXQ7XG5cbiAgLy8gV2hlbiBheGlzIGlzIGEgY2F0ZWdvcmljYWwgYXhpcywgYnV0IHRoZSB0eXBlIG9mIGF4aXMgaXMgbnVtYmVyIG9yIHRoZSBzY2FsZSBvZiBheGlzIGlzIG5vdCBcImF1dG9cIlxuICBpZiAoaXNDYXRlZ29yaWNhbCAmJiBjYXRlZ29yaWNhbERvbWFpbikge1xuICAgIHJldHVybiBjYXRlZ29yaWNhbERvbWFpbi5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKHtcbiAgICAgIGNvb3JkaW5hdGU6IHNjYWxlKGVudHJ5KSArIG9mZnNldCxcbiAgICAgIHZhbHVlOiBlbnRyeSxcbiAgICAgIGluZGV4LFxuICAgICAgb2Zmc2V0XG4gICAgfSkpO1xuICB9XG4gIGlmIChzY2FsZS50aWNrcykge1xuICAgIHJldHVybiBzY2FsZS50aWNrcyh0aWNrQ291bnQpXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3aHkgZG9lcyB0aGUgb2Zmc2V0IGdvIGhlcmU/IFRoZSB0eXBlIGRvZXMgbm90IHJlcXVpcmUgaXRcbiAgICAubWFwKGVudHJ5ID0+ICh7XG4gICAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgICB2YWx1ZTogZW50cnksXG4gICAgICBvZmZzZXRcbiAgICB9KSk7XG4gIH1cblxuICAvLyBXaGVuIGF4aXMgaGFzIGR1cGxpY2F0ZWQgdGV4dCwgc2VyaWFsIG51bWJlcnMgYXJlIHVzZWQgdG8gZ2VuZXJhdGUgc2NhbGVcbiAgcmV0dXJuIHNjYWxlLmRvbWFpbigpLm1hcCgoZW50cnksIGluZGV4KSA9PiAoe1xuICAgIGNvb3JkaW5hdGU6IHNjYWxlKGVudHJ5KSArIG9mZnNldCxcbiAgICB2YWx1ZTogZHVwbGljYXRlRG9tYWluID8gZHVwbGljYXRlRG9tYWluW2VudHJ5XSA6IGVudHJ5LFxuICAgIGluZGV4LFxuICAgIG9mZnNldFxuICB9KSk7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0QXhpc1NldHRpbmdzLCBzZWxlY3RBeGlzU2NhbGUsIHNlbGVjdEF4aXNSYW5nZSwgc2VsZWN0RHVwbGljYXRlRG9tYWluLCBzZWxlY3RDYXRlZ29yaWNhbERvbWFpbiwgcGlja0F4aXNUeXBlXSwgY29tYmluZUdyYXBoaWNhbEl0ZW1UaWNrcyk7XG5leHBvcnQgdmFyIHNlbGVjdEF4aXNXaXRoU2NhbGUgPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RCYXNlQXhpcywgc2VsZWN0QXhpc1NjYWxlLCAoYXhpcywgc2NhbGUpID0+IHtcbiAgaWYgKGF4aXMgPT0gbnVsbCB8fCBzY2FsZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBheGlzKSwge30sIHtcbiAgICBzY2FsZVxuICB9KTtcbn0pO1xudmFyIHNlbGVjdFpBeGlzU2NhbGUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QmFzZUF4aXMsIHNlbGVjdFJlYWxTY2FsZVR5cGUsIHNlbGVjdEF4aXNEb21haW4sIHNlbGVjdEF4aXNSYW5nZVdpdGhSZXZlcnNlXSwgY29tYmluZVNjYWxlRnVuY3Rpb24pO1xuZXhwb3J0IHZhciBzZWxlY3RaQXhpc1dpdGhTY2FsZSA9IGNyZWF0ZVNlbGVjdG9yKChzdGF0ZSwgX2F4aXNUeXBlLCBheGlzSWQpID0+IHNlbGVjdFpBeGlzU2V0dGluZ3Moc3RhdGUsIGF4aXNJZCksIHNlbGVjdFpBeGlzU2NhbGUsIChheGlzLCBzY2FsZSkgPT4ge1xuICBpZiAoYXhpcyA9PSBudWxsIHx8IHNjYWxlID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIGF4aXMpLCB7fSwge1xuICAgIHNjYWxlXG4gIH0pO1xufSk7XG5cbi8qKlxuICogV2UgYXJlIGFsc28gZ29pbmcgdG8gbmVlZCB0byBpbXBsZW1lbnQgcG9sYXIgY2hhcnQgZGlyZWN0aW9ucyBpZiB3ZSB3YW50IHRvIHN1cHBvcnQga2V5Ym9hcmQgY29udHJvbHMgZm9yIHRob3NlLlxuICovXG5cbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnREaXJlY3Rpb24gPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdEFsbFhBeGVzLCBzZWxlY3RBbGxZQXhlc10sIChsYXlvdXQsIGFsbFhBeGVzLCBhbGxZQXhlcykgPT4ge1xuICBzd2l0Y2ggKGxheW91dCkge1xuICAgIGNhc2UgJ2hvcml6b250YWwnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gYWxsWEF4ZXMuc29tZShheGlzID0+IGF4aXMucmV2ZXJzZWQpID8gJ3JpZ2h0LXRvLWxlZnQnIDogJ2xlZnQtdG8tcmlnaHQnO1xuICAgICAgfVxuICAgIGNhc2UgJ3ZlcnRpY2FsJzpcbiAgICAgIHtcbiAgICAgICAgcmV0dXJuIGFsbFlBeGVzLnNvbWUoYXhpcyA9PiBheGlzLnJldmVyc2VkKSA/ICdib3R0b20tdG8tdG9wJyA6ICd0b3AtdG8tYm90dG9tJztcbiAgICAgIH1cbiAgICAvLyBUT0RPOiBtYWtlIHRoaXMgYmV0dGVyLiBGb3Igbm93LCByaWdodCBhcnJvdyB0cmlnZ2VycyBcImZvcndhcmRcIiwgbGVmdCBhcnJvdyBcImJhY2tcIlxuICAgIC8vIGhvd2V2ZXIsIHRoZSB0b29sdGlwIG1vdmVzIGFuIHVuaW50dWl0aXZlIGRpcmVjdGlvbiBiZWNhdXNlIG9mIGhvdyB0aGUgaW5kaWNlcyBhcmUgcmVuZGVyZWRcbiAgICBjYXNlICdjZW50cmljJzpcbiAgICBjYXNlICdyYWRpYWwnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gJ2xlZnQtdG8tcmlnaHQnO1xuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gIH1cbn0pOyIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuZXhwb3J0IHZhciByZWN0V2l0aFBvaW50cyA9IChfcmVmLCBfcmVmMikgPT4ge1xuICB2YXIge1xuICAgIHg6IHgxLFxuICAgIHk6IHkxXG4gIH0gPSBfcmVmO1xuICB2YXIge1xuICAgIHg6IHgyLFxuICAgIHk6IHkyXG4gIH0gPSBfcmVmMjtcbiAgcmV0dXJuIHtcbiAgICB4OiBNYXRoLm1pbih4MSwgeDIpLFxuICAgIHk6IE1hdGgubWluKHkxLCB5MiksXG4gICAgd2lkdGg6IE1hdGguYWJzKHgyIC0geDEpLFxuICAgIGhlaWdodDogTWF0aC5hYnMoeTIgLSB5MSlcbiAgfTtcbn07XG5cbi8qKlxuICogQ29tcHV0ZSB0aGUgeCwgeSwgd2lkdGgsIGFuZCBoZWlnaHQgb2YgYSBib3ggZnJvbSB0d28gcmVmZXJlbmNlIHBvaW50cy5cbiAqIEBwYXJhbSAge09iamVjdH0gY29vcmRzICAgICB4MSwgeDIsIHkxLCBhbmQgeTJcbiAqIEByZXR1cm4ge09iamVjdH0gb2JqZWN0XG4gKi9cbmV4cG9ydCB2YXIgcmVjdFdpdGhDb29yZHMgPSBfcmVmMyA9PiB7XG4gIHZhciB7XG4gICAgeDEsXG4gICAgeTEsXG4gICAgeDIsXG4gICAgeTJcbiAgfSA9IF9yZWYzO1xuICByZXR1cm4gcmVjdFdpdGhQb2ludHMoe1xuICAgIHg6IHgxLFxuICAgIHk6IHkxXG4gIH0sIHtcbiAgICB4OiB4MixcbiAgICB5OiB5MlxuICB9KTtcbn07XG5leHBvcnQgY2xhc3MgU2NhbGVIZWxwZXIge1xuICBzdGF0aWMgY3JlYXRlKG9iaikge1xuICAgIHJldHVybiBuZXcgU2NhbGVIZWxwZXIob2JqKTtcbiAgfVxuICBjb25zdHJ1Y3RvcihzY2FsZSkge1xuICAgIHRoaXMuc2NhbGUgPSBzY2FsZTtcbiAgfVxuICBnZXQgZG9tYWluKCkge1xuICAgIHJldHVybiB0aGlzLnNjYWxlLmRvbWFpbjtcbiAgfVxuICBnZXQgcmFuZ2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuc2NhbGUucmFuZ2U7XG4gIH1cbiAgZ2V0IHJhbmdlTWluKCkge1xuICAgIHJldHVybiB0aGlzLnJhbmdlKClbMF07XG4gIH1cbiAgZ2V0IHJhbmdlTWF4KCkge1xuICAgIHJldHVybiB0aGlzLnJhbmdlKClbMV07XG4gIH1cbiAgZ2V0IGJhbmR3aWR0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5zY2FsZS5iYW5kd2lkdGg7XG4gIH1cbiAgYXBwbHkodmFsdWUpIHtcbiAgICB2YXIge1xuICAgICAgYmFuZEF3YXJlLFxuICAgICAgcG9zaXRpb25cbiAgICB9ID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB7fTtcbiAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHBvc2l0aW9uKSB7XG4gICAgICBzd2l0Y2ggKHBvc2l0aW9uKSB7XG4gICAgICAgIGNhc2UgJ3N0YXJ0JzpcbiAgICAgICAgICB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zY2FsZSh2YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICBjYXNlICdtaWRkbGUnOlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHZhciBvZmZzZXQgPSB0aGlzLmJhbmR3aWR0aCA/IHRoaXMuYmFuZHdpZHRoKCkgLyAyIDogMDtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNjYWxlKHZhbHVlKSArIG9mZnNldDtcbiAgICAgICAgICB9XG4gICAgICAgIGNhc2UgJ2VuZCc6XG4gICAgICAgICAge1xuICAgICAgICAgICAgdmFyIF9vZmZzZXQgPSB0aGlzLmJhbmR3aWR0aCA/IHRoaXMuYmFuZHdpZHRoKCkgOiAwO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2NhbGUodmFsdWUpICsgX29mZnNldDtcbiAgICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2NhbGUodmFsdWUpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGJhbmRBd2FyZSkge1xuICAgICAgdmFyIF9vZmZzZXQyID0gdGhpcy5iYW5kd2lkdGggPyB0aGlzLmJhbmR3aWR0aCgpIC8gMiA6IDA7XG4gICAgICByZXR1cm4gdGhpcy5zY2FsZSh2YWx1ZSkgKyBfb2Zmc2V0MjtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc2NhbGUodmFsdWUpO1xuICB9XG4gIGlzSW5SYW5nZSh2YWx1ZSkge1xuICAgIHZhciByYW5nZSA9IHRoaXMucmFuZ2UoKTtcbiAgICB2YXIgZmlyc3QgPSByYW5nZVswXTtcbiAgICB2YXIgbGFzdCA9IHJhbmdlW3JhbmdlLmxlbmd0aCAtIDFdO1xuICAgIHJldHVybiBmaXJzdCA8PSBsYXN0ID8gdmFsdWUgPj0gZmlyc3QgJiYgdmFsdWUgPD0gbGFzdCA6IHZhbHVlID49IGxhc3QgJiYgdmFsdWUgPD0gZmlyc3Q7XG4gIH1cbn1cbl9kZWZpbmVQcm9wZXJ0eShTY2FsZUhlbHBlciwgXCJFUFNcIiwgMWUtNCk7XG5leHBvcnQgdmFyIGNyZWF0ZUxhYmVsZWRTY2FsZXMgPSBvcHRpb25zID0+IHtcbiAgdmFyIHNjYWxlcyA9IE9iamVjdC5rZXlzKG9wdGlvbnMpLnJlZHVjZSgocmVzLCBrZXkpID0+IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcmVzKSwge30sIHtcbiAgICBba2V5XTogU2NhbGVIZWxwZXIuY3JlYXRlKG9wdGlvbnNba2V5XSlcbiAgfSksIHt9KTtcbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgc2NhbGVzKSwge30sIHtcbiAgICBhcHBseShjb29yZCkge1xuICAgICAgdmFyIHtcbiAgICAgICAgYmFuZEF3YXJlLFxuICAgICAgICBwb3NpdGlvblxuICAgICAgfSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDoge307XG4gICAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKGNvb3JkKS5tYXAoX3JlZjQgPT4ge1xuICAgICAgICB2YXIgW2xhYmVsLCB2YWx1ZV0gPSBfcmVmNDtcbiAgICAgICAgcmV0dXJuIFtsYWJlbCwgc2NhbGVzW2xhYmVsXS5hcHBseSh2YWx1ZSwge1xuICAgICAgICAgIGJhbmRBd2FyZSxcbiAgICAgICAgICBwb3NpdGlvblxuICAgICAgICB9KV07XG4gICAgICB9KSk7XG4gICAgfSxcbiAgICBpc0luUmFuZ2UoY29vcmQpIHtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyhjb29yZCkuZXZlcnkobGFiZWwgPT4gc2NhbGVzW2xhYmVsXS5pc0luUmFuZ2UoY29vcmRbbGFiZWxdKSk7XG4gICAgfVxuICB9KTtcbn07XG5cbi8qKiBOb3JtYWxpemVzIHRoZSBhbmdsZSBzbyB0aGF0IDAgPD0gYW5nbGUgPCAxODAuXG4gKiBAcGFyYW0ge251bWJlcn0gYW5nbGUgQW5nbGUgaW4gZGVncmVlcy5cbiAqIEByZXR1cm4ge251bWJlcn0gdGhlIG5vcm1hbGl6ZWQgYW5nbGUgd2l0aCBhIHZhbHVlIG9mIGF0IGxlYXN0IDAgYW5kIG5ldmVyIGdyZWF0ZXIgb3IgZXF1YWwgdG8gMTgwLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUFuZ2xlKGFuZ2xlKSB7XG4gIHJldHVybiAoYW5nbGUgJSAxODAgKyAxODApICUgMTgwO1xufVxuXG4vKiogQ2FsY3VsYXRlcyB0aGUgd2lkdGggb2YgdGhlIGxhcmdlc3QgaG9yaXpvbnRhbCBsaW5lIHRoYXQgZml0cyBpbnNpZGUgYSByZWN0YW5nbGUgdGhhdCBpcyBkaXNwbGF5ZWQgYXQgYW4gYW5nbGUuXG4gKiBAcGFyYW0ge09iamVjdH0gc2l6ZSBXaWR0aCBhbmQgaGVpZ2h0IG9mIHRoZSB0ZXh0IGluIGEgaG9yaXpvbnRhbCBwb3NpdGlvbi5cbiAqIEBwYXJhbSB7bnVtYmVyfSBhbmdsZSBBbmdsZSBpbiBkZWdyZWVzIGluIHdoaWNoIHRoZSB0ZXh0IGlzIGRpc3BsYXllZC5cbiAqIEByZXR1cm4ge251bWJlcn0gVGhlIHdpZHRoIG9mIHRoZSBsYXJnZXN0IGhvcml6b250YWwgbGluZSB0aGF0IGZpdHMgaW5zaWRlIGEgcmVjdGFuZ2xlIHRoYXQgaXMgZGlzcGxheWVkIGF0IGFuIGFuZ2xlLlxuICovXG5leHBvcnQgdmFyIGdldEFuZ2xlZFJlY3RhbmdsZVdpZHRoID0gZnVuY3Rpb24gZ2V0QW5nbGVkUmVjdGFuZ2xlV2lkdGgoX3JlZjUpIHtcbiAgdmFyIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHRcbiAgfSA9IF9yZWY1O1xuICB2YXIgYW5nbGUgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IDA7XG4gIC8vIEVuc3VyZSBhbmdsZSBpcyA+PSAwICYmIDwgMTgwXG4gIHZhciBub3JtYWxpemVkQW5nbGUgPSBub3JtYWxpemVBbmdsZShhbmdsZSk7XG4gIHZhciBhbmdsZVJhZGlhbnMgPSBub3JtYWxpemVkQW5nbGUgKiBNYXRoLlBJIC8gMTgwO1xuXG4gIC8qIERlcGVuZGluZyBvbiB0aGUgaGVpZ2h0IGFuZCB3aWR0aCBvZiB0aGUgcmVjdGFuZ2xlLCB3ZSBtYXkgbmVlZCB0byB1c2UgZGlmZmVyZW50IGZvcm11bGFzIHRvIGNhbGN1bGF0ZSB0aGUgYW5nbGVkXG4gICAqIHdpZHRoLiBUaGlzIHRocmVzaG9sZCBkZWZpbmVzIHdoZW4gZWFjaCBmb3JtdWxhIHNob3VsZCBraWNrIGluLiAqL1xuICB2YXIgYW5nbGVUaHJlc2hvbGQgPSBNYXRoLmF0YW4oaGVpZ2h0IC8gd2lkdGgpO1xuICB2YXIgYW5nbGVkV2lkdGggPSBhbmdsZVJhZGlhbnMgPiBhbmdsZVRocmVzaG9sZCAmJiBhbmdsZVJhZGlhbnMgPCBNYXRoLlBJIC0gYW5nbGVUaHJlc2hvbGQgPyBoZWlnaHQgLyBNYXRoLnNpbihhbmdsZVJhZGlhbnMpIDogd2lkdGggLyBNYXRoLmNvcyhhbmdsZVJhZGlhbnMpO1xuICByZXR1cm4gTWF0aC5hYnMoYW5nbGVkV2lkdGgpO1xufTsiLCJpbXBvcnQgeyBzZWxlY3RDaGFydExheW91dCB9IGZyb20gJy4uLy4uL2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0JztcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcEF4aXNUeXBlID0gc3RhdGUgPT4ge1xuICB2YXIgbGF5b3V0ID0gc2VsZWN0Q2hhcnRMYXlvdXQoc3RhdGUpO1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICByZXR1cm4gJ3hBeGlzJztcbiAgfVxuICBpZiAobGF5b3V0ID09PSAndmVydGljYWwnKSB7XG4gICAgcmV0dXJuICd5QXhpcyc7XG4gIH1cbiAgaWYgKGxheW91dCA9PT0gJ2NlbnRyaWMnKSB7XG4gICAgcmV0dXJuICdhbmdsZUF4aXMnO1xuICB9XG4gIHJldHVybiAncmFkaXVzQXhpcyc7XG59OyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0UG9sYXJBeGlzVGlja3MgfSBmcm9tICcuL3BvbGFyU2NhbGVTZWxlY3RvcnMnO1xudmFyIHNlbGVjdEFuZ2xlQXhpc1RpY2tzID0gKHN0YXRlLCBhbmdsZXhpc0lkKSA9PiBzZWxlY3RQb2xhckF4aXNUaWNrcyhzdGF0ZSwgJ2FuZ2xlQXhpcycsIGFuZ2xleGlzSWQsIGZhbHNlKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJHcmlkQW5nbGVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFuZ2xlQXhpc1RpY2tzXSwgdGlja3MgPT4ge1xuICBpZiAoIXRpY2tzKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gdGlja3MubWFwKHRpY2sgPT4gdGljay5jb29yZGluYXRlKTtcbn0pO1xudmFyIHNlbGVjdFJhZGl1c0F4aXNUaWNrcyA9IChzdGF0ZSwgcmFkaXVzQXhpc0lkKSA9PiBzZWxlY3RQb2xhckF4aXNUaWNrcyhzdGF0ZSwgJ3JhZGl1c0F4aXMnLCByYWRpdXNBeGlzSWQsIGZhbHNlKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJHcmlkUmFkaWkgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmFkaXVzQXhpc1RpY2tzXSwgdGlja3MgPT4ge1xuICBpZiAoIXRpY2tzKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gdGlja3MubWFwKHRpY2sgPT4gdGljay5jb29yZGluYXRlKTtcbn0pOyIsImV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciA9IHN0YXRlID0+IHN0YXRlLm9wdGlvbnMudG9vbHRpcFBheWxvYWRTZWFyY2hlcjsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgY29tcHV0ZVBpZVNlY3RvcnMgfSBmcm9tICcuLi8uLi9wb2xhci9QaWUnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcyB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE9mZnNldEludGVybmFsIH0gZnJvbSAnLi9zZWxlY3RDaGFydE9mZnNldEludGVybmFsJztcbmltcG9ydCB7IGdldFRvb2x0aXBOYW1lUHJvcCwgZ2V0VmFsdWVCeURhdGFLZXkgfSBmcm9tICcuLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMgfSBmcm9tICcuL3BvbGFyU2VsZWN0b3JzJztcbnZhciBwaWNrSWQgPSAoX3N0YXRlLCBpZCkgPT4gaWQ7XG52YXIgc2VsZWN0U3luY2hyb25pc2VkUGllU2V0dGluZ3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMsIHBpY2tJZF0sIChncmFwaGljYWxJdGVtcywgaWQpID0+IGdyYXBoaWNhbEl0ZW1zLmZpbHRlcihpdGVtID0+IGl0ZW0udHlwZSA9PT0gJ3BpZScpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBpZCkpO1xuXG4vLyBLZWVwIHN0YWJsZSByZWZlcmVuY2UgdG8gYW4gZW1wdHkgYXJyYXkgdG8gcHJldmVudCByZS1yZW5kZXJzXG52YXIgZW1wdHlBcnJheSA9IFtdO1xudmFyIHBpY2tDZWxscyA9IChfc3RhdGUsIF9pZCwgY2VsbHMpID0+IHtcbiAgaWYgKChjZWxscyA9PT0gbnVsbCB8fCBjZWxscyA9PT0gdm9pZCAwID8gdm9pZCAwIDogY2VsbHMubGVuZ3RoKSA9PT0gMCkge1xuICAgIHJldHVybiBlbXB0eUFycmF5O1xuICB9XG4gIHJldHVybiBjZWxscztcbn07XG5leHBvcnQgdmFyIHNlbGVjdERpc3BsYXllZERhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcywgc2VsZWN0U3luY2hyb25pc2VkUGllU2V0dGluZ3MsIHBpY2tDZWxsc10sIChfcmVmLCBwaWVTZXR0aW5ncywgY2VsbHMpID0+IHtcbiAgdmFyIHtcbiAgICBjaGFydERhdGFcbiAgfSA9IF9yZWY7XG4gIGlmIChwaWVTZXR0aW5ncyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgZGlzcGxheWVkRGF0YTtcbiAgaWYgKChwaWVTZXR0aW5ncyA9PT0gbnVsbCB8fCBwaWVTZXR0aW5ncyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGllU2V0dGluZ3MuZGF0YSkgIT0gbnVsbCAmJiBwaWVTZXR0aW5ncy5kYXRhLmxlbmd0aCA+IDApIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gcGllU2V0dGluZ3MuZGF0YTtcbiAgfSBlbHNlIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gY2hhcnREYXRhO1xuICB9XG4gIGlmICgoIWRpc3BsYXllZERhdGEgfHwgIWRpc3BsYXllZERhdGEubGVuZ3RoKSAmJiBjZWxscyAhPSBudWxsKSB7XG4gICAgZGlzcGxheWVkRGF0YSA9IGNlbGxzLm1hcChjZWxsID0+IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcGllU2V0dGluZ3MucHJlc2VudGF0aW9uUHJvcHMpLCBjZWxsLnByb3BzKSk7XG4gIH1cbiAgaWYgKGRpc3BsYXllZERhdGEgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGRpc3BsYXllZERhdGE7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0UGllTGVnZW5kID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdERpc3BsYXllZERhdGEsIHNlbGVjdFN5bmNocm9uaXNlZFBpZVNldHRpbmdzLCBwaWNrQ2VsbHNdLCAoZGlzcGxheWVkRGF0YSwgcGllU2V0dGluZ3MsIGNlbGxzKSA9PiB7XG4gIGlmIChkaXNwbGF5ZWREYXRhID09IG51bGwgfHwgcGllU2V0dGluZ3MgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGRpc3BsYXllZERhdGEubWFwKChlbnRyeSwgaSkgPT4ge1xuICAgIHZhciBfY2VsbHMkaTtcbiAgICB2YXIgbmFtZSA9IGdldFZhbHVlQnlEYXRhS2V5KGVudHJ5LCBwaWVTZXR0aW5ncy5uYW1lS2V5LCBwaWVTZXR0aW5ncy5uYW1lKTtcbiAgICB2YXIgY29sb3I7XG4gICAgaWYgKGNlbGxzICE9PSBudWxsICYmIGNlbGxzICE9PSB2b2lkIDAgJiYgKF9jZWxscyRpID0gY2VsbHNbaV0pICE9PSBudWxsICYmIF9jZWxscyRpICE9PSB2b2lkIDAgJiYgKF9jZWxscyRpID0gX2NlbGxzJGkucHJvcHMpICE9PSBudWxsICYmIF9jZWxscyRpICE9PSB2b2lkIDAgJiYgX2NlbGxzJGkuZmlsbCkge1xuICAgICAgY29sb3IgPSBjZWxsc1tpXS5wcm9wcy5maWxsO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIGVudHJ5ID09PSAnb2JqZWN0JyAmJiBlbnRyeSAhPSBudWxsICYmICdmaWxsJyBpbiBlbnRyeSkge1xuICAgICAgY29sb3IgPSBlbnRyeS5maWxsO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb2xvciA9IHBpZVNldHRpbmdzLmZpbGw7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICB2YWx1ZTogZ2V0VG9vbHRpcE5hbWVQcm9wKG5hbWUsIHBpZVNldHRpbmdzLmRhdGFLZXkpLFxuICAgICAgY29sb3IsXG4gICAgICBwYXlsb2FkOiBlbnRyeSxcbiAgICAgIHR5cGU6IHBpZVNldHRpbmdzLmxlZ2VuZFR5cGVcbiAgICB9O1xuICB9KTtcbn0pO1xuZXhwb3J0IHZhciBzZWxlY3RQaWVTZWN0b3JzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdERpc3BsYXllZERhdGEsIHNlbGVjdFN5bmNocm9uaXNlZFBpZVNldHRpbmdzLCBwaWNrQ2VsbHMsIHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWxdLCAoZGlzcGxheWVkRGF0YSwgcGllU2V0dGluZ3MsIGNlbGxzLCBvZmZzZXQpID0+IHtcbiAgaWYgKHBpZVNldHRpbmdzID09IG51bGwgfHwgZGlzcGxheWVkRGF0YSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gY29tcHV0ZVBpZVNlY3RvcnMoe1xuICAgIG9mZnNldCxcbiAgICBwaWVTZXR0aW5ncyxcbiAgICBkaXNwbGF5ZWREYXRhLFxuICAgIGNlbGxzXG4gIH0pO1xufSk7IiwiaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydERhdGFBbmRBbHdheXNJZ25vcmVJbmRleGVzIH0gZnJvbSAnLi9kYXRhU2VsZWN0b3JzJztcbmltcG9ydCB7IGNvbWJpbmVBcHBsaWVkVmFsdWVzLCBjb21iaW5lQXhpc0RvbWFpbiwgY29tYmluZUF4aXNEb21haW5XaXRoTmljZVRpY2tzLCBjb21iaW5lRGlzcGxheWVkRGF0YSwgY29tYmluZURvbWFpbk9mQWxsQXBwbGllZE51bWVyaWNhbFZhbHVlc0luY2x1ZGluZ0Vycm9yVmFsdWVzLCBjb21iaW5lR3JhcGhpY2FsSXRlbXNEYXRhLCBjb21iaW5lR3JhcGhpY2FsSXRlbXNTZXR0aW5ncywgY29tYmluZU5pY2VUaWNrcywgY29tYmluZU51bWVyaWNhbERvbWFpbiwgaXRlbUF4aXNQcmVkaWNhdGUsIHNlbGVjdEFsbEVycm9yQmFyU2V0dGluZ3MsIHNlbGVjdEJhc2VBeGlzLCBzZWxlY3REb21haW5EZWZpbml0aW9uLCBzZWxlY3REb21haW5Gcm9tVXNlclByZWZlcmVuY2UsIHNlbGVjdFJlYWxTY2FsZVR5cGUgfSBmcm9tICcuL2F4aXNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBnZXRWYWx1ZUJ5RGF0YUtleSB9IGZyb20gJy4uLy4uL3V0aWwvQ2hhcnRVdGlscyc7XG5pbXBvcnQgeyBwaWNrQXhpc1R5cGUgfSBmcm9tICcuL3BpY2tBeGlzVHlwZSc7XG5pbXBvcnQgeyBwaWNrQXhpc0lkIH0gZnJvbSAnLi9waWNrQXhpc0lkJztcbmltcG9ydCB7IHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSB9IGZyb20gJy4vcm9vdFByb3BzU2VsZWN0b3JzJztcbmV4cG9ydCB2YXIgc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMgPSBzdGF0ZSA9PiBzdGF0ZS5ncmFwaGljYWxJdGVtcy5wb2xhckl0ZW1zO1xudmFyIHNlbGVjdEF4aXNQcmVkaWNhdGUgPSBjcmVhdGVTZWxlY3RvcihbcGlja0F4aXNUeXBlLCBwaWNrQXhpc0lkXSwgaXRlbUF4aXNQcmVkaWNhdGUpO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckl0ZW1zU2V0dGluZ3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMsIHNlbGVjdEJhc2VBeGlzLCBzZWxlY3RBeGlzUHJlZGljYXRlXSwgY29tYmluZUdyYXBoaWNhbEl0ZW1zU2V0dGluZ3MpO1xudmFyIHNlbGVjdFBvbGFyR3JhcGhpY2FsSXRlbXNEYXRhID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFBvbGFySXRlbXNTZXR0aW5nc10sIGNvbWJpbmVHcmFwaGljYWxJdGVtc0RhdGEpO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckRpc3BsYXllZERhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJHcmFwaGljYWxJdGVtc0RhdGEsIHNlbGVjdENoYXJ0RGF0YUFuZEFsd2F5c0lnbm9yZUluZGV4ZXNdLCBjb21iaW5lRGlzcGxheWVkRGF0YSk7XG5leHBvcnQgdmFyIHNlbGVjdFBvbGFyQXBwbGllZFZhbHVlcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RQb2xhckRpc3BsYXllZERhdGEsIHNlbGVjdEJhc2VBeGlzLCBzZWxlY3RQb2xhckl0ZW1zU2V0dGluZ3NdLCBjb21iaW5lQXBwbGllZFZhbHVlcyk7XG5leHBvcnQgdmFyIHNlbGVjdEFsbFBvbGFyQXBwbGllZE51bWVyaWNhbFZhbHVlcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RQb2xhckRpc3BsYXllZERhdGEsIHNlbGVjdEJhc2VBeGlzLCBzZWxlY3RQb2xhckl0ZW1zU2V0dGluZ3NdLCAoZGF0YSwgYXhpc1NldHRpbmdzLCBpdGVtcykgPT4ge1xuICBpZiAoaXRlbXMubGVuZ3RoID4gMCkge1xuICAgIHJldHVybiBkYXRhLmZsYXRNYXAoZW50cnkgPT4ge1xuICAgICAgcmV0dXJuIGl0ZW1zLmZsYXRNYXAoaXRlbSA9PiB7XG4gICAgICAgIHZhciBfYXhpc1NldHRpbmdzJGRhdGFLZXk7XG4gICAgICAgIHZhciB2YWx1ZUJ5RGF0YUtleSA9IGdldFZhbHVlQnlEYXRhS2V5KGVudHJ5LCAoX2F4aXNTZXR0aW5ncyRkYXRhS2V5ID0gYXhpc1NldHRpbmdzLmRhdGFLZXkpICE9PSBudWxsICYmIF9heGlzU2V0dGluZ3MkZGF0YUtleSAhPT0gdm9pZCAwID8gX2F4aXNTZXR0aW5ncyRkYXRhS2V5IDogaXRlbS5kYXRhS2V5KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB2YWx1ZTogdmFsdWVCeURhdGFLZXksXG4gICAgICAgICAgZXJyb3JEb21haW46IFtdIC8vIHBvbGFyIGNoYXJ0cyBkbyBub3QgaGF2ZSBlcnJvciBiYXJzXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9KS5maWx0ZXIoQm9vbGVhbik7XG4gIH1cbiAgaWYgKChheGlzU2V0dGluZ3MgPT09IG51bGwgfHwgYXhpc1NldHRpbmdzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBheGlzU2V0dGluZ3MuZGF0YUtleSkgIT0gbnVsbCkge1xuICAgIHJldHVybiBkYXRhLm1hcChpdGVtID0+ICh7XG4gICAgICB2YWx1ZTogZ2V0VmFsdWVCeURhdGFLZXkoaXRlbSwgYXhpc1NldHRpbmdzLmRhdGFLZXkpLFxuICAgICAgZXJyb3JEb21haW46IFtdXG4gICAgfSkpO1xuICB9XG4gIHJldHVybiBkYXRhLm1hcChlbnRyeSA9PiAoe1xuICAgIHZhbHVlOiBlbnRyeSxcbiAgICBlcnJvckRvbWFpbjogW11cbiAgfSkpO1xufSk7XG52YXIgdW5zdXBwb3J0ZWRJblBvbGFyQ2hhcnQgPSAoKSA9PiB1bmRlZmluZWQ7XG52YXIgc2VsZWN0RG9tYWluT2ZBbGxQb2xhckFwcGxpZWROdW1lcmljYWxWYWx1ZXMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJEaXNwbGF5ZWREYXRhLCBzZWxlY3RCYXNlQXhpcywgc2VsZWN0UG9sYXJJdGVtc1NldHRpbmdzLCBzZWxlY3RBbGxFcnJvckJhclNldHRpbmdzLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lRG9tYWluT2ZBbGxBcHBsaWVkTnVtZXJpY2FsVmFsdWVzSW5jbHVkaW5nRXJyb3JWYWx1ZXMpO1xudmFyIHNlbGVjdFBvbGFyTnVtZXJpY2FsRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzLCBzZWxlY3REb21haW5EZWZpbml0aW9uLCBzZWxlY3REb21haW5Gcm9tVXNlclByZWZlcmVuY2UsIHVuc3VwcG9ydGVkSW5Qb2xhckNoYXJ0LCBzZWxlY3REb21haW5PZkFsbFBvbGFyQXBwbGllZE51bWVyaWNhbFZhbHVlcywgdW5zdXBwb3J0ZWRJblBvbGFyQ2hhcnQsIHNlbGVjdENoYXJ0TGF5b3V0LCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lTnVtZXJpY2FsRG9tYWluKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJBeGlzRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJhc2VBeGlzLCBzZWxlY3RDaGFydExheW91dCwgc2VsZWN0UG9sYXJEaXNwbGF5ZWREYXRhLCBzZWxlY3RQb2xhckFwcGxpZWRWYWx1ZXMsIHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSwgcGlja0F4aXNUeXBlLCBzZWxlY3RQb2xhck51bWVyaWNhbERvbWFpbl0sIGNvbWJpbmVBeGlzRG9tYWluKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJOaWNlVGlja3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJBeGlzRG9tYWluLCBzZWxlY3RCYXNlQXhpcywgc2VsZWN0UmVhbFNjYWxlVHlwZV0sIGNvbWJpbmVOaWNlVGlja3MpO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckF4aXNEb21haW5JbmNsdWRpbmdOaWNlVGlja3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QmFzZUF4aXMsIHNlbGVjdFBvbGFyQXhpc0RvbWFpbiwgc2VsZWN0UG9sYXJOaWNlVGlja3MsIHBpY2tBeGlzVHlwZV0sIGNvbWJpbmVBeGlzRG9tYWluV2l0aE5pY2VUaWNrcyk7IiwiZXhwb3J0IHZhciBjb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UgPSAoYXhpc1NldHRpbmdzLCBheGlzUmFuZ2UpID0+IHtcbiAgaWYgKCFheGlzU2V0dGluZ3MgfHwgIWF4aXNSYW5nZSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKGF4aXNTZXR0aW5ncyAhPT0gbnVsbCAmJiBheGlzU2V0dGluZ3MgIT09IHZvaWQgMCAmJiBheGlzU2V0dGluZ3MucmV2ZXJzZWQpIHtcbiAgICByZXR1cm4gW2F4aXNSYW5nZVsxXSwgYXhpc1JhbmdlWzBdXTtcbiAgfVxuICByZXR1cm4gYXhpc1JhbmdlO1xufTsiLCJpbXBvcnQgeyBjcmVhdGVTbGljZSB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnO1xudmFyIHBvbGFyT3B0aW9uc1NsaWNlID0gY3JlYXRlU2xpY2Uoe1xuICBuYW1lOiAncG9sYXJPcHRpb25zJyxcbiAgaW5pdGlhbFN0YXRlOiBudWxsLFxuICByZWR1Y2Vyczoge1xuICAgIHVwZGF0ZVBvbGFyT3B0aW9uczogKF9zdGF0ZSwgYWN0aW9uKSA9PiB7XG4gICAgICByZXR1cm4gYWN0aW9uLnBheWxvYWQ7XG4gICAgfVxuICB9XG59KTtcbmV4cG9ydCB2YXIge1xuICB1cGRhdGVQb2xhck9wdGlvbnNcbn0gPSBwb2xhck9wdGlvbnNTbGljZS5hY3Rpb25zO1xuZXhwb3J0IHZhciBwb2xhck9wdGlvbnNSZWR1Y2VyID0gcG9sYXJPcHRpb25zU2xpY2UucmVkdWNlcjsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IG5vSW50ZXJhY3Rpb24gfSBmcm9tICcuLi8uLi90b29sdGlwU2xpY2UnO1xuZnVuY3Rpb24gY2hvb3NlQXBwcm9wcmlhdGVNb3VzZUludGVyYWN0aW9uKHRvb2x0aXBTdGF0ZSwgdG9vbHRpcEV2ZW50VHlwZSwgdHJpZ2dlcikge1xuICBpZiAodG9vbHRpcEV2ZW50VHlwZSA9PT0gJ2F4aXMnKSB7XG4gICAgaWYgKHRyaWdnZXIgPT09ICdjbGljaycpIHtcbiAgICAgIHJldHVybiB0b29sdGlwU3RhdGUuYXhpc0ludGVyYWN0aW9uLmNsaWNrO1xuICAgIH1cbiAgICByZXR1cm4gdG9vbHRpcFN0YXRlLmF4aXNJbnRlcmFjdGlvbi5ob3ZlcjtcbiAgfVxuICBpZiAodHJpZ2dlciA9PT0gJ2NsaWNrJykge1xuICAgIHJldHVybiB0b29sdGlwU3RhdGUuaXRlbUludGVyYWN0aW9uLmNsaWNrO1xuICB9XG4gIHJldHVybiB0b29sdGlwU3RhdGUuaXRlbUludGVyYWN0aW9uLmhvdmVyO1xufVxuZnVuY3Rpb24gaGFzQmVlbkFjdGl2ZVByZXZpb3VzbHkodG9vbHRpcEludGVyYWN0aW9uU3RhdGUpIHtcbiAgcmV0dXJuIHRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLmluZGV4ICE9IG51bGw7XG59XG5leHBvcnQgdmFyIGNvbWJpbmVUb29sdGlwSW50ZXJhY3Rpb25TdGF0ZSA9ICh0b29sdGlwU3RhdGUsIHRvb2x0aXBFdmVudFR5cGUsIHRyaWdnZXIsIGRlZmF1bHRJbmRleCkgPT4ge1xuICBpZiAodG9vbHRpcEV2ZW50VHlwZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG5vSW50ZXJhY3Rpb247XG4gIH1cbiAgdmFyIGFwcHJvcHJpYXRlTW91c2VJbnRlcmFjdGlvbiA9IGNob29zZUFwcHJvcHJpYXRlTW91c2VJbnRlcmFjdGlvbih0b29sdGlwU3RhdGUsIHRvb2x0aXBFdmVudFR5cGUsIHRyaWdnZXIpO1xuICBpZiAoYXBwcm9wcmlhdGVNb3VzZUludGVyYWN0aW9uID09IG51bGwpIHtcbiAgICByZXR1cm4gbm9JbnRlcmFjdGlvbjtcbiAgfVxuICBpZiAoYXBwcm9wcmlhdGVNb3VzZUludGVyYWN0aW9uLmFjdGl2ZSkge1xuICAgIHJldHVybiBhcHByb3ByaWF0ZU1vdXNlSW50ZXJhY3Rpb247XG4gIH1cbiAgaWYgKHRvb2x0aXBTdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmFjdGl2ZSkge1xuICAgIHJldHVybiB0b29sdGlwU3RhdGUua2V5Ym9hcmRJbnRlcmFjdGlvbjtcbiAgfVxuICBpZiAodG9vbHRpcFN0YXRlLnN5bmNJbnRlcmFjdGlvbi5hY3RpdmUgJiYgdG9vbHRpcFN0YXRlLnN5bmNJbnRlcmFjdGlvbi5pbmRleCAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHRvb2x0aXBTdGF0ZS5zeW5jSW50ZXJhY3Rpb247XG4gIH1cbiAgdmFyIGFjdGl2ZUZyb21Qcm9wcyA9IHRvb2x0aXBTdGF0ZS5zZXR0aW5ncy5hY3RpdmUgPT09IHRydWU7XG4gIGlmIChoYXNCZWVuQWN0aXZlUHJldmlvdXNseShhcHByb3ByaWF0ZU1vdXNlSW50ZXJhY3Rpb24pKSB7XG4gICAgaWYgKGFjdGl2ZUZyb21Qcm9wcykge1xuICAgICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYXBwcm9wcmlhdGVNb3VzZUludGVyYWN0aW9uKSwge30sIHtcbiAgICAgICAgYWN0aXZlOiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoZGVmYXVsdEluZGV4ICE9IG51bGwpIHtcbiAgICByZXR1cm4ge1xuICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgY29vcmRpbmF0ZTogdW5kZWZpbmVkLFxuICAgICAgZGF0YUtleTogdW5kZWZpbmVkLFxuICAgICAgaW5kZXg6IGRlZmF1bHRJbmRleFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgbm9JbnRlcmFjdGlvbiksIHt9LCB7XG4gICAgY29vcmRpbmF0ZTogYXBwcm9wcmlhdGVNb3VzZUludGVyYWN0aW9uLmNvb3JkaW5hdGVcbiAgfSk7XG59OyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc1JhbmdlV2l0aFJldmVyc2UsIHNlbGVjdFRvb2x0aXBBeGlzVGlja3MgfSBmcm9tICcuL3Rvb2x0aXBTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCB9IGZyb20gJy4vc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCc7XG5pbXBvcnQgeyBjb21iaW5lQWN0aXZlUHJvcHMsIHNlbGVjdE9yZGVyZWRUb29sdGlwVGlja3MgfSBmcm9tICcuL3NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RQb2xhclZpZXdCb3ggfSBmcm9tICcuL3BvbGFyQXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc1R5cGUgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBBeGlzVHlwZSc7XG52YXIgcGlja0NoYXJ0UG9pbnRlciA9IChfc3RhdGUsIGNoYXJ0UG9pbnRlcikgPT4gY2hhcnRQb2ludGVyO1xuZXhwb3J0IHZhciBzZWxlY3RBY3RpdmVQcm9wc0Zyb21DaGFydFBvaW50ZXIgPSBjcmVhdGVTZWxlY3RvcihbcGlja0NoYXJ0UG9pbnRlciwgc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFBvbGFyVmlld0JveCwgc2VsZWN0VG9vbHRpcEF4aXNUeXBlLCBzZWxlY3RUb29sdGlwQXhpc1JhbmdlV2l0aFJldmVyc2UsIHNlbGVjdFRvb2x0aXBBeGlzVGlja3MsIHNlbGVjdE9yZGVyZWRUb29sdGlwVGlja3MsIHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWxdLCBjb21iaW5lQWN0aXZlUHJvcHMpOyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlcic7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwU3RhdGUgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBTdGF0ZSc7XG52YXIgc2VsZWN0QWxsVG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9uID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBTdGF0ZV0sIHRvb2x0aXBTdGF0ZSA9PiB0b29sdGlwU3RhdGUudG9vbHRpcEl0ZW1QYXlsb2Fkcyk7XG5leHBvcnQgdmFyIHNlbGVjdFRvb2x0aXBDb29yZGluYXRlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbFRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbiwgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciwgKF9zdGF0ZSwgdG9vbHRpcEluZGV4LCBfZGF0YUtleSkgPT4gdG9vbHRpcEluZGV4LCAoX3N0YXRlLCBfdG9vbHRpcEluZGV4LCBkYXRhS2V5KSA9PiBkYXRhS2V5XSwgKGFsbFRvb2x0aXBDb25maWd1cmF0aW9ucywgdG9vbHRpcFBheWxvYWRTZWFyY2hlciwgdG9vbHRpcEluZGV4LCBkYXRhS2V5KSA9PiB7XG4gIHZhciBtb3N0UmVsZXZhbnRUb29sdGlwQ29uZmlndXJhdGlvbiA9IGFsbFRvb2x0aXBDb25maWd1cmF0aW9ucy5maW5kKHRvb2x0aXBDb25maWd1cmF0aW9uID0+IHtcbiAgICByZXR1cm4gdG9vbHRpcENvbmZpZ3VyYXRpb24uc2V0dGluZ3MuZGF0YUtleSA9PT0gZGF0YUtleTtcbiAgfSk7XG4gIGlmIChtb3N0UmVsZXZhbnRUb29sdGlwQ29uZmlndXJhdGlvbiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIHBvc2l0aW9uc1xuICB9ID0gbW9zdFJlbGV2YW50VG9vbHRpcENvbmZpZ3VyYXRpb247XG4gIGlmIChwb3NpdGlvbnMgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gQHRzLWV4cGVjdC1lcnJvciB0b29sdGlwUGF5bG9hZFNlYXJjaGVyIGlzIG5vdCB0eXBlZCB3ZWxsXG4gIHZhciBtYXliZVBvc2l0aW9uID0gdG9vbHRpcFBheWxvYWRTZWFyY2hlcihwb3NpdGlvbnMsIHRvb2x0aXBJbmRleCk7XG4gIHJldHVybiBtYXliZVBvc2l0aW9uO1xufSk7IiwiaW1wb3J0IHsgY3JlYXRlQWN0aW9uLCBjcmVhdGVMaXN0ZW5lck1pZGRsZXdhcmUgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0JztcbmltcG9ydCB7IHNldEFjdGl2ZU1vdXNlT3Zlckl0ZW1JbmRleCwgc2V0TW91c2VPdmVyQXhpc0luZGV4IH0gZnJvbSAnLi90b29sdGlwU2xpY2UnO1xuaW1wb3J0IHsgc2VsZWN0QWN0aXZlUHJvcHNGcm9tQ2hhcnRQb2ludGVyIH0gZnJvbSAnLi9zZWxlY3RvcnMvc2VsZWN0QWN0aXZlUHJvcHNGcm9tQ2hhcnRQb2ludGVyJztcbmltcG9ydCB7IGdldENoYXJ0UG9pbnRlciB9IGZyb20gJy4uL3V0aWwvZ2V0Q2hhcnRQb2ludGVyJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBFdmVudFR5cGUgfSBmcm9tICcuL3NlbGVjdG9ycy9zZWxlY3RUb29sdGlwRXZlbnRUeXBlJztcbmltcG9ydCB7IERBVEFfSVRFTV9EQVRBS0VZX0FUVFJJQlVURV9OQU1FLCBEQVRBX0lURU1fSU5ERVhfQVRUUklCVVRFX05BTUUgfSBmcm9tICcuLi91dGlsL0NvbnN0YW50cyc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQ29vcmRpbmF0ZSB9IGZyb20gJy4vc2VsZWN0b3JzL3RvdWNoU2VsZWN0b3JzJztcbmV4cG9ydCB2YXIgdG91Y2hFdmVudEFjdGlvbiA9IGNyZWF0ZUFjdGlvbigndG91Y2hNb3ZlJyk7XG5leHBvcnQgdmFyIHRvdWNoRXZlbnRNaWRkbGV3YXJlID0gY3JlYXRlTGlzdGVuZXJNaWRkbGV3YXJlKCk7XG50b3VjaEV2ZW50TWlkZGxld2FyZS5zdGFydExpc3RlbmluZyh7XG4gIGFjdGlvbkNyZWF0b3I6IHRvdWNoRXZlbnRBY3Rpb24sXG4gIGVmZmVjdDogKGFjdGlvbiwgbGlzdGVuZXJBcGkpID0+IHtcbiAgICB2YXIgdG91Y2hFdmVudCA9IGFjdGlvbi5wYXlsb2FkO1xuICAgIHZhciBzdGF0ZSA9IGxpc3RlbmVyQXBpLmdldFN0YXRlKCk7XG4gICAgdmFyIHRvb2x0aXBFdmVudFR5cGUgPSBzZWxlY3RUb29sdGlwRXZlbnRUeXBlKHN0YXRlLCBzdGF0ZS50b29sdGlwLnNldHRpbmdzLnNoYXJlZCk7XG4gICAgaWYgKHRvb2x0aXBFdmVudFR5cGUgPT09ICdheGlzJykge1xuICAgICAgdmFyIGFjdGl2ZVByb3BzID0gc2VsZWN0QWN0aXZlUHJvcHNGcm9tQ2hhcnRQb2ludGVyKHN0YXRlLCBnZXRDaGFydFBvaW50ZXIoe1xuICAgICAgICBjbGllbnRYOiB0b3VjaEV2ZW50LnRvdWNoZXNbMF0uY2xpZW50WCxcbiAgICAgICAgY2xpZW50WTogdG91Y2hFdmVudC50b3VjaGVzWzBdLmNsaWVudFksXG4gICAgICAgIGN1cnJlbnRUYXJnZXQ6IHRvdWNoRXZlbnQuY3VycmVudFRhcmdldFxuICAgICAgfSkpO1xuICAgICAgaWYgKChhY3RpdmVQcm9wcyA9PT0gbnVsbCB8fCBhY3RpdmVQcm9wcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYWN0aXZlUHJvcHMuYWN0aXZlSW5kZXgpICE9IG51bGwpIHtcbiAgICAgICAgbGlzdGVuZXJBcGkuZGlzcGF0Y2goc2V0TW91c2VPdmVyQXhpc0luZGV4KHtcbiAgICAgICAgICBhY3RpdmVJbmRleDogYWN0aXZlUHJvcHMuYWN0aXZlSW5kZXgsXG4gICAgICAgICAgYWN0aXZlRGF0YUtleTogdW5kZWZpbmVkLFxuICAgICAgICAgIGFjdGl2ZUNvb3JkaW5hdGU6IGFjdGl2ZVByb3BzLmFjdGl2ZUNvb3JkaW5hdGVcbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodG9vbHRpcEV2ZW50VHlwZSA9PT0gJ2l0ZW0nKSB7XG4gICAgICB2YXIgX3RhcmdldCRnZXRBdHRyaWJ1dGU7XG4gICAgICB2YXIgdG91Y2ggPSB0b3VjaEV2ZW50LnRvdWNoZXNbMF07XG4gICAgICB2YXIgdGFyZ2V0ID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludCh0b3VjaC5jbGllbnRYLCB0b3VjaC5jbGllbnRZKTtcbiAgICAgIGlmICghdGFyZ2V0IHx8ICF0YXJnZXQuZ2V0QXR0cmlidXRlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZhciBpdGVtSW5kZXggPSB0YXJnZXQuZ2V0QXR0cmlidXRlKERBVEFfSVRFTV9JTkRFWF9BVFRSSUJVVEVfTkFNRSk7XG4gICAgICB2YXIgZGF0YUtleSA9IChfdGFyZ2V0JGdldEF0dHJpYnV0ZSA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoREFUQV9JVEVNX0RBVEFLRVlfQVRUUklCVVRFX05BTUUpKSAhPT0gbnVsbCAmJiBfdGFyZ2V0JGdldEF0dHJpYnV0ZSAhPT0gdm9pZCAwID8gX3RhcmdldCRnZXRBdHRyaWJ1dGUgOiB1bmRlZmluZWQ7XG4gICAgICB2YXIgY29vcmRpbmF0ZSA9IHNlbGVjdFRvb2x0aXBDb29yZGluYXRlKGxpc3RlbmVyQXBpLmdldFN0YXRlKCksIGl0ZW1JbmRleCwgZGF0YUtleSk7XG4gICAgICBsaXN0ZW5lckFwaS5kaXNwYXRjaChzZXRBY3RpdmVNb3VzZU92ZXJJdGVtSW5kZXgoe1xuICAgICAgICBhY3RpdmVEYXRhS2V5OiBkYXRhS2V5LFxuICAgICAgICBhY3RpdmVJbmRleDogaXRlbUluZGV4LFxuICAgICAgICBhY3RpdmVDb29yZGluYXRlOiBjb29yZGluYXRlXG4gICAgICB9KSk7XG4gICAgfVxuICB9XG59KTsiLCJleHBvcnQgZnVuY3Rpb24gYXJyYXlFcXVhbGl0eUNoZWNrKGEsIGIpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSAmJiBhLmxlbmd0aCA9PT0gMCAmJiBiLmxlbmd0aCA9PT0gMCkge1xuICAgIC8vIGVtcHR5IGFycmF5cyBhcmUgYWx3YXlzIGVxdWFsLCByZWdhcmRsZXNzIG9mIHJlZmVyZW5jZVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBhID09PSBiO1xufSIsImV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcFN0YXRlID0gc3RhdGUgPT4gc3RhdGUudG9vbHRpcDsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IGNvbXB1dGVBcmVhIH0gZnJvbSAnLi4vLi4vY2FydGVzaWFuL0FyZWEnO1xuaW1wb3J0IHsgc2VsZWN0QXhpc1dpdGhTY2FsZSwgc2VsZWN0U3RhY2tHcm91cHMsIHNlbGVjdFRpY2tzT2ZHcmFwaGljYWxJdGVtLCBzZWxlY3RVbmZpbHRlcmVkQ2FydGVzaWFuSXRlbXMgfSBmcm9tICcuL2F4aXNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlc0lmTm90SW5QYW5vcmFtYSB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBnZXRCYW5kU2l6ZU9mQXhpcywgaXNDYXRlZ29yaWNhbEF4aXMgfSBmcm9tICcuLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyIH0gZnJvbSAnLi4vLi4vdXRpbC9zdGFja3MvZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyJztcbnZhciBzZWxlY3RYQXhpc1dpdGhTY2FsZSA9IChzdGF0ZSwgeEF4aXNJZCwgX3lBeGlzSWQsIGlzUGFub3JhbWEpID0+IHNlbGVjdEF4aXNXaXRoU2NhbGUoc3RhdGUsICd4QXhpcycsIHhBeGlzSWQsIGlzUGFub3JhbWEpO1xudmFyIHNlbGVjdFhBeGlzVGlja3MgPSAoc3RhdGUsIHhBeGlzSWQsIF95QXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG52YXIgc2VsZWN0WUF4aXNXaXRoU2NhbGUgPSAoc3RhdGUsIF94QXhpc0lkLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiBzZWxlY3RBeGlzV2l0aFNjYWxlKHN0YXRlLCAneUF4aXMnLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RZQXhpc1RpY2tzID0gKHN0YXRlLCBfeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0oc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xudmFyIHNlbGVjdEJhbmRTaXplID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RYQXhpc1dpdGhTY2FsZSwgc2VsZWN0WUF4aXNXaXRoU2NhbGUsIHNlbGVjdFhBeGlzVGlja3MsIHNlbGVjdFlBeGlzVGlja3NdLCAobGF5b3V0LCB4QXhpcywgeUF4aXMsIHhBeGlzVGlja3MsIHlBeGlzVGlja3MpID0+IHtcbiAgaWYgKGlzQ2F0ZWdvcmljYWxBeGlzKGxheW91dCwgJ3hBeGlzJykpIHtcbiAgICByZXR1cm4gZ2V0QmFuZFNpemVPZkF4aXMoeEF4aXMsIHhBeGlzVGlja3MsIGZhbHNlKTtcbiAgfVxuICByZXR1cm4gZ2V0QmFuZFNpemVPZkF4aXMoeUF4aXMsIHlBeGlzVGlja3MsIGZhbHNlKTtcbn0pO1xudmFyIHBpY2tBcmVhSWQgPSAoX3N0YXRlLCBfeEF4aXNJZCwgX3lBeGlzSWQsIF9pc1Bhbm9yYW1hLCBpZCkgPT4gaWQ7XG5cbi8qXG4gKiBUaGVyZSBpcyBhIHJhY2UgY29uZGl0aW9uIHByb2JsZW0gYmVjYXVzZSB3ZSByZWFkIHNvbWUgZGF0YSBmcm9tIHByb3BzIGFuZCBzb21lIGZyb20gdGhlIHN0YXRlLlxuICogVGhlIHN0YXRlIGlzIHVwZGF0ZWQgdGhyb3VnaCBhIGRpc3BhdGNoIGFuZCBpcyBvbmUgcmVuZGVyIGJlaGluZCxcbiAqIGFuZCBzbyB3ZSBoYXZlIHRoaXMgd2VpcmQgb25lIHRpY2sgcmVuZGVyIHdoZXJlIHRoZSBkaXNwbGF5ZWREYXRhIGluIG9uZSBzZWxlY3RvciBoYXZlIHRoZSBvbGQgZGF0YUtleVxuICogYnV0IHRoZSBuZXcgZGF0YUtleSBpbiBhbm90aGVyIHNlbGVjdG9yLlxuICpcbiAqIEEgcHJvcGVyIGZpeCBpcyB0byBlaXRoZXIgbW92ZSBldmVyeXRoaW5nIGludG8gdGhlIHN0YXRlLCBvciByZWFkIHRoZSBkYXRhS2V5IGFsd2F5cyBmcm9tIHByb3BzXG4gKiAtIGJ1dCB0aGlzIGlzIGEgc21hbGxlciBjaGFuZ2UuXG4gKi9cbnZhciBzZWxlY3RTeW5jaHJvbmlzZWRBcmVhU2V0dGluZ3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZENhcnRlc2lhbkl0ZW1zLCBwaWNrQXJlYUlkXSwgKGdyYXBoaWNhbEl0ZW1zLCBpZCkgPT4gZ3JhcGhpY2FsSXRlbXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS50eXBlID09PSAnYXJlYScpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBpZCkpO1xuZXhwb3J0IHZhciBzZWxlY3RHcmFwaGljYWxJdGVtU3RhY2tlZERhdGEgPSAoc3RhdGUsIHhBeGlzSWQsIHlBeGlzSWQsIGlzUGFub3JhbWEsIGlkKSA9PiB7XG4gIHZhciBfc3RhY2tHcm91cHMkc3RhY2tJZDtcbiAgdmFyIGFyZWFTZXR0aW5ncyA9IHNlbGVjdFN5bmNocm9uaXNlZEFyZWFTZXR0aW5ncyhzdGF0ZSwgeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSwgaWQpO1xuICBpZiAoYXJlYVNldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBsYXlvdXQgPSBzZWxlY3RDaGFydExheW91dChzdGF0ZSk7XG4gIHZhciBpc1hBeGlzQ2F0ZWdvcmljYWwgPSBpc0NhdGVnb3JpY2FsQXhpcyhsYXlvdXQsICd4QXhpcycpO1xuICB2YXIgc3RhY2tHcm91cHM7XG4gIGlmIChpc1hBeGlzQ2F0ZWdvcmljYWwpIHtcbiAgICBzdGFja0dyb3VwcyA9IHNlbGVjdFN0YWNrR3JvdXBzKHN0YXRlLCAneUF4aXMnLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbiAgfSBlbHNlIHtcbiAgICBzdGFja0dyb3VwcyA9IHNlbGVjdFN0YWNrR3JvdXBzKHN0YXRlLCAneEF4aXMnLCB4QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbiAgfVxuICBpZiAoc3RhY2tHcm91cHMgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHtcbiAgICBzdGFja0lkXG4gIH0gPSBhcmVhU2V0dGluZ3M7XG4gIHZhciBzdGFja1Nlcmllc0lkZW50aWZpZXIgPSBnZXRTdGFja1Nlcmllc0lkZW50aWZpZXIoYXJlYVNldHRpbmdzKTtcbiAgaWYgKHN0YWNrSWQgPT0gbnVsbCB8fCBzdGFja1Nlcmllc0lkZW50aWZpZXIgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIGdyb3VwcyA9IChfc3RhY2tHcm91cHMkc3RhY2tJZCA9IHN0YWNrR3JvdXBzW3N0YWNrSWRdKSA9PT0gbnVsbCB8fCBfc3RhY2tHcm91cHMkc3RhY2tJZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3N0YWNrR3JvdXBzJHN0YWNrSWQuc3RhY2tlZERhdGE7XG4gIHJldHVybiBncm91cHMgPT09IG51bGwgfHwgZ3JvdXBzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBncm91cHMuZmluZCh2ID0+IHYua2V5ID09PSBzdGFja1Nlcmllc0lkZW50aWZpZXIpO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0QXJlYSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0WEF4aXNXaXRoU2NhbGUsIHNlbGVjdFlBeGlzV2l0aFNjYWxlLCBzZWxlY3RYQXhpc1RpY2tzLCBzZWxlY3RZQXhpc1RpY2tzLCBzZWxlY3RHcmFwaGljYWxJdGVtU3RhY2tlZERhdGEsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzSWZOb3RJblBhbm9yYW1hLCBzZWxlY3RCYW5kU2l6ZSwgc2VsZWN0U3luY2hyb25pc2VkQXJlYVNldHRpbmdzXSwgKGxheW91dCwgeEF4aXMsIHlBeGlzLCB4QXhpc1RpY2tzLCB5QXhpc1RpY2tzLCBzdGFja2VkRGF0YSwgX3JlZiwgYmFuZFNpemUsIGFyZWFTZXR0aW5ncykgPT4ge1xuICB2YXIge1xuICAgIGNoYXJ0RGF0YSxcbiAgICBkYXRhU3RhcnRJbmRleCxcbiAgICBkYXRhRW5kSW5kZXhcbiAgfSA9IF9yZWY7XG4gIGlmIChhcmVhU2V0dGluZ3MgPT0gbnVsbCB8fCBsYXlvdXQgIT09ICdob3Jpem9udGFsJyAmJiBsYXlvdXQgIT09ICd2ZXJ0aWNhbCcgfHwgeEF4aXMgPT0gbnVsbCB8fCB5QXhpcyA9PSBudWxsIHx8IHhBeGlzVGlja3MgPT0gbnVsbCB8fCB5QXhpc1RpY2tzID09IG51bGwgfHwgeEF4aXNUaWNrcy5sZW5ndGggPT09IDAgfHwgeUF4aXNUaWNrcy5sZW5ndGggPT09IDAgfHwgYmFuZFNpemUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHtcbiAgICBkYXRhXG4gIH0gPSBhcmVhU2V0dGluZ3M7XG4gIHZhciBkaXNwbGF5ZWREYXRhO1xuICBpZiAoZGF0YSAmJiBkYXRhLmxlbmd0aCA+IDApIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gZGF0YTtcbiAgfSBlbHNlIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gY2hhcnREYXRhID09PSBudWxsIHx8IGNoYXJ0RGF0YSA9PT0gdm9pZCAwID8gdm9pZCAwIDogY2hhcnREYXRhLnNsaWNlKGRhdGFTdGFydEluZGV4LCBkYXRhRW5kSW5kZXggKyAxKTtcbiAgfVxuICBpZiAoZGlzcGxheWVkRGF0YSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuXG4gIC8vIFdoZXJlIGlzIHRoaXMgc3VwcG9zZWQgdG8gY29tZSBmcm9tPyBObyBjaGFydHMgaGF2ZSB0aGF0IGFzIGEgcHJvcC5cbiAgdmFyIGNoYXJ0QmFzZVZhbHVlID0gdW5kZWZpbmVkO1xuICByZXR1cm4gY29tcHV0ZUFyZWEoe1xuICAgIGxheW91dCxcbiAgICB4QXhpcyxcbiAgICB5QXhpcyxcbiAgICB4QXhpc1RpY2tzLFxuICAgIHlBeGlzVGlja3MsXG4gICAgZGF0YVN0YXJ0SW5kZXgsXG4gICAgYXJlYVNldHRpbmdzLFxuICAgIHN0YWNrZWREYXRhLFxuICAgIGRpc3BsYXllZERhdGEsXG4gICAgY2hhcnRCYXNlVmFsdWUsXG4gICAgYmFuZFNpemVcbiAgfSk7XG59KTsiLCJpbXBvcnQgeyBjcmVhdGVTbGljZSwgY3VycmVudCB9IGZyb20gJ0ByZWR1eGpzL3Rvb2xraXQnO1xudmFyIGluaXRpYWxTdGF0ZSA9IHtcbiAgZG90czogW10sXG4gIGFyZWFzOiBbXSxcbiAgbGluZXM6IFtdXG59O1xuZXhwb3J0IHZhciByZWZlcmVuY2VFbGVtZW50c1NsaWNlID0gY3JlYXRlU2xpY2Uoe1xuICBuYW1lOiAncmVmZXJlbmNlRWxlbWVudHMnLFxuICBpbml0aWFsU3RhdGUsXG4gIHJlZHVjZXJzOiB7XG4gICAgYWRkRG90OiAoc3RhdGUsIGFjdGlvbikgPT4ge1xuICAgICAgc3RhdGUuZG90cy5wdXNoKGFjdGlvbi5wYXlsb2FkKTtcbiAgICB9LFxuICAgIHJlbW92ZURvdDogKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgICAgIHZhciBpbmRleCA9IGN1cnJlbnQoc3RhdGUpLmRvdHMuZmluZEluZGV4KGRvdCA9PiBkb3QgPT09IGFjdGlvbi5wYXlsb2FkKTtcbiAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgc3RhdGUuZG90cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgfVxuICAgIH0sXG4gICAgYWRkQXJlYTogKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgICAgIHN0YXRlLmFyZWFzLnB1c2goYWN0aW9uLnBheWxvYWQpO1xuICAgIH0sXG4gICAgcmVtb3ZlQXJlYTogKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgICAgIHZhciBpbmRleCA9IGN1cnJlbnQoc3RhdGUpLmFyZWFzLmZpbmRJbmRleChhcmVhID0+IGFyZWEgPT09IGFjdGlvbi5wYXlsb2FkKTtcbiAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgc3RhdGUuYXJlYXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGFkZExpbmU6IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gICAgICBzdGF0ZS5saW5lcy5wdXNoKGFjdGlvbi5wYXlsb2FkKTtcbiAgICB9LFxuICAgIHJlbW92ZUxpbmU6IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gICAgICB2YXIgaW5kZXggPSBjdXJyZW50KHN0YXRlKS5saW5lcy5maW5kSW5kZXgobGluZSA9PiBsaW5lID09PSBhY3Rpb24ucGF5bG9hZCk7XG4gICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgIHN0YXRlLmxpbmVzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59KTtcbmV4cG9ydCB2YXIge1xuICBhZGREb3QsXG4gIHJlbW92ZURvdCxcbiAgYWRkQXJlYSxcbiAgcmVtb3ZlQXJlYSxcbiAgYWRkTGluZSxcbiAgcmVtb3ZlTGluZVxufSA9IHJlZmVyZW5jZUVsZW1lbnRzU2xpY2UuYWN0aW9ucztcbmV4cG9ydCB2YXIgcmVmZXJlbmNlRWxlbWVudHNSZWR1Y2VyID0gcmVmZXJlbmNlRWxlbWVudHNTbGljZS5yZWR1Y2VyOyIsImltcG9ydCB7IGNyZWF0ZVNsaWNlIH0gZnJvbSAnQHJlZHV4anMvdG9vbGtpdCc7XG5pbXBvcnQgeyBpc05hbiB9IGZyb20gJy4uL3V0aWwvRGF0YVV0aWxzJztcblxuLyoqXG4gKiBUaGVzZSBjaGFydCBvcHRpb25zIGFyZSBkZWNpZGVkIGludGVybmFsbHksIGJ5IFJlY2hhcnRzLFxuICogYW5kIHdpbGwgbm90IGNoYW5nZSBkdXJpbmcgdGhlIGxpZmV0aW1lIG9mIHRoZSBjaGFydC5cbiAqXG4gKiBDaGFuZ2luZyB0aGVzZSBvcHRpb25zIGNhbiBiZSBkb25lIGJ5IHN3YXBwaW5nIHRoZSByb290IGVsZW1lbnRcbiAqIHdoaWNoIHdpbGwgbWFrZSBhIGJyYW5kLW5ldyBSZWR1eCBzdG9yZS5cbiAqXG4gKiBJZiB5b3Ugd2FudCB0byBzdG9yZSBvcHRpb25zIHRoYXQgY2FuIGJlIGNoYW5nZWQgYnkgdGhlIHVzZXIsXG4gKiB1c2UgVXBkYXRhYmxlQ2hhcnRPcHRpb25zIGluIHJvb3RQcm9wc1NsaWNlLnRzLlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBhcnJheVRvb2x0aXBTZWFyY2hlcihkYXRhLCBzdHJJbmRleCkge1xuICBpZiAoIXN0ckluZGV4KSByZXR1cm4gdW5kZWZpbmVkO1xuICB2YXIgbnVtSW5kZXggPSBOdW1iZXIucGFyc2VJbnQoc3RySW5kZXgsIDEwKTtcbiAgaWYgKGlzTmFuKG51bUluZGV4KSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGRhdGEgPT09IG51bGwgfHwgZGF0YSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGF0YVtudW1JbmRleF07XG59XG52YXIgaW5pdGlhbFN0YXRlID0ge1xuICBjaGFydE5hbWU6ICcnLFxuICB0b29sdGlwUGF5bG9hZFNlYXJjaGVyOiB1bmRlZmluZWQsXG4gIGV2ZW50RW1pdHRlcjogdW5kZWZpbmVkLFxuICBkZWZhdWx0VG9vbHRpcEV2ZW50VHlwZTogJ2F4aXMnXG59O1xudmFyIG9wdGlvbnNTbGljZSA9IGNyZWF0ZVNsaWNlKHtcbiAgbmFtZTogJ29wdGlvbnMnLFxuICBpbml0aWFsU3RhdGUsXG4gIHJlZHVjZXJzOiB7XG4gICAgY3JlYXRlRXZlbnRFbWl0dGVyOiBzdGF0ZSA9PiB7XG4gICAgICBpZiAoc3RhdGUuZXZlbnRFbWl0dGVyID09IG51bGwpIHtcbiAgICAgICAgc3RhdGUuZXZlbnRFbWl0dGVyID0gU3ltYm9sKCdyZWNoYXJ0c0V2ZW50RW1pdHRlcicpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufSk7XG5leHBvcnQgdmFyIG9wdGlvbnNSZWR1Y2VyID0gb3B0aW9uc1NsaWNlLnJlZHVjZXI7XG5leHBvcnQgdmFyIHtcbiAgY3JlYXRlRXZlbnRFbWl0dGVyXG59ID0gb3B0aW9uc1NsaWNlLmFjdGlvbnM7IiwiaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5pbXBvcnQgeyBjb21iaW5lQXhpc1RpY2tzLCBjb21iaW5lQ2F0ZWdvcmljYWxEb21haW4sIGNvbWJpbmVHcmFwaGljYWxJdGVtVGlja3MsIGNvbWJpbmVTY2FsZUZ1bmN0aW9uLCBzZWxlY3RBeGlzU2V0dGluZ3MsIHNlbGVjdER1cGxpY2F0ZURvbWFpbiwgc2VsZWN0UmVhbFNjYWxlVHlwZSB9IGZyb20gJy4vYXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RBbmdsZUF4aXMsIHNlbGVjdEFuZ2xlQXhpc1JhbmdlV2l0aFJldmVyc2VkLCBzZWxlY3RSYWRpdXNBeGlzLCBzZWxlY3RSYWRpdXNBeGlzUmFuZ2VXaXRoUmV2ZXJzZWQgfSBmcm9tICcuL3BvbGFyQXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydExheW91dCB9IGZyb20gJy4uLy4uL2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0JztcbmltcG9ydCB7IHNlbGVjdFBvbGFyQXBwbGllZFZhbHVlcywgc2VsZWN0UG9sYXJBeGlzRG9tYWluSW5jbHVkaW5nTmljZVRpY2tzLCBzZWxlY3RQb2xhck5pY2VUaWNrcyB9IGZyb20gJy4vcG9sYXJTZWxlY3RvcnMnO1xuaW1wb3J0IHsgcGlja0F4aXNUeXBlIH0gZnJvbSAnLi9waWNrQXhpc1R5cGUnO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckF4aXMgPSAoc3RhdGUsIGF4aXNUeXBlLCBheGlzSWQpID0+IHtcbiAgc3dpdGNoIChheGlzVHlwZSkge1xuICAgIGNhc2UgJ2FuZ2xlQXhpcyc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzZWxlY3RBbmdsZUF4aXMoc3RhdGUsIGF4aXNJZCk7XG4gICAgICB9XG4gICAgY2FzZSAncmFkaXVzQXhpcyc6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzZWxlY3RSYWRpdXNBeGlzKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVuZXhwZWN0ZWQgYXhpcyB0eXBlOiBcIi5jb25jYXQoYXhpc1R5cGUpKTtcbiAgICAgIH1cbiAgfVxufTtcbnZhciBzZWxlY3RQb2xhckF4aXNSYW5nZVdpdGhSZXZlcnNlZCA9IChzdGF0ZSwgYXhpc1R5cGUsIGF4aXNJZCkgPT4ge1xuICBzd2l0Y2ggKGF4aXNUeXBlKSB7XG4gICAgY2FzZSAnYW5nbGVBeGlzJzpcbiAgICAgIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdEFuZ2xlQXhpc1JhbmdlV2l0aFJldmVyc2VkKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGNhc2UgJ3JhZGl1c0F4aXMnOlxuICAgICAge1xuICAgICAgICByZXR1cm4gc2VsZWN0UmFkaXVzQXhpc1JhbmdlV2l0aFJldmVyc2VkKHN0YXRlLCBheGlzSWQpO1xuICAgICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVuZXhwZWN0ZWQgYXhpcyB0eXBlOiBcIi5jb25jYXQoYXhpc1R5cGUpKTtcbiAgICAgIH1cbiAgfVxufTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJBeGlzU2NhbGUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJBeGlzLCBzZWxlY3RSZWFsU2NhbGVUeXBlLCBzZWxlY3RQb2xhckF4aXNEb21haW5JbmNsdWRpbmdOaWNlVGlja3MsIHNlbGVjdFBvbGFyQXhpc1JhbmdlV2l0aFJldmVyc2VkXSwgY29tYmluZVNjYWxlRnVuY3Rpb24pO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckNhdGVnb3JpY2FsRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RQb2xhckFwcGxpZWRWYWx1ZXMsIHNlbGVjdEF4aXNTZXR0aW5ncywgcGlja0F4aXNUeXBlXSwgY29tYmluZUNhdGVnb3JpY2FsRG9tYWluKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJBeGlzVGlja3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFBvbGFyQXhpcywgc2VsZWN0UmVhbFNjYWxlVHlwZSwgc2VsZWN0UG9sYXJBeGlzU2NhbGUsIHNlbGVjdFBvbGFyTmljZVRpY2tzLCBzZWxlY3RQb2xhckF4aXNSYW5nZVdpdGhSZXZlcnNlZCwgc2VsZWN0RHVwbGljYXRlRG9tYWluLCBzZWxlY3RQb2xhckNhdGVnb3JpY2FsRG9tYWluLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lQXhpc1RpY2tzKTtcbmV4cG9ydCB2YXIgc2VsZWN0UG9sYXJHcmFwaGljYWxJdGVtQXhpc1RpY2tzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RQb2xhckF4aXMsIHNlbGVjdFBvbGFyQXhpc1NjYWxlLCBzZWxlY3RQb2xhckF4aXNSYW5nZVdpdGhSZXZlcnNlZCwgc2VsZWN0RHVwbGljYXRlRG9tYWluLCBzZWxlY3RQb2xhckNhdGVnb3JpY2FsRG9tYWluLCBwaWNrQXhpc1R5cGVdLCBjb21iaW5lR3JhcGhpY2FsSXRlbVRpY2tzKTsiLCJleHBvcnQgdmFyIHNlbGVjdFRvb2x0aXBTZXR0aW5ncyA9IHN0YXRlID0+IHN0YXRlLnRvb2x0aXAuc2V0dGluZ3M7IiwiaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5pbXBvcnQgeyBjb21iaW5lQXBwbGllZFZhbHVlcywgY29tYmluZUFyZWFzRG9tYWluLCBjb21iaW5lQXhpc0RvbWFpbiwgY29tYmluZUF4aXNEb21haW5XaXRoTmljZVRpY2tzLCBjb21iaW5lQ2F0ZWdvcmljYWxEb21haW4sIGNvbWJpbmVEaXNwbGF5ZWREYXRhLCBjb21iaW5lRG9tYWluT2ZBbGxBcHBsaWVkTnVtZXJpY2FsVmFsdWVzSW5jbHVkaW5nRXJyb3JWYWx1ZXMsIGNvbWJpbmVEb21haW5PZlN0YWNrR3JvdXBzLCBjb21iaW5lRG90c0RvbWFpbiwgY29tYmluZUR1cGxpY2F0ZURvbWFpbiwgY29tYmluZUdyYXBoaWNhbEl0ZW1zRGF0YSwgY29tYmluZUdyYXBoaWNhbEl0ZW1zU2V0dGluZ3MsIGNvbWJpbmVMaW5lc0RvbWFpbiwgY29tYmluZU5pY2VUaWNrcywgY29tYmluZU51bWVyaWNhbERvbWFpbiwgY29tYmluZVJlYWxTY2FsZVR5cGUsIGNvbWJpbmVTY2FsZUZ1bmN0aW9uLCBjb21iaW5lU3RhY2tHcm91cHMsIGZpbHRlckdyYXBoaWNhbE5vdFN0YWNrZWRJdGVtcywgZmlsdGVyUmVmZXJlbmNlRWxlbWVudHMsIGdldERvbWFpbkRlZmluaXRpb24sIGl0ZW1BeGlzUHJlZGljYXRlLCBtZXJnZURvbWFpbnMsIHNlbGVjdEFsbEVycm9yQmFyU2V0dGluZ3MsIHNlbGVjdEF4aXNSYW5nZSwgc2VsZWN0SGFzQmFyLCBzZWxlY3RSZWZlcmVuY2VBcmVhcywgc2VsZWN0UmVmZXJlbmNlRG90cywgc2VsZWN0UmVmZXJlbmNlTGluZXMgfSBmcm9tICcuL2F4aXNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBpc0NhdGVnb3JpY2FsQXhpcyB9IGZyb20gJy4uLy4uL3V0aWwvQ2hhcnRVdGlscyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlcyB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE5hbWUsIHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSB9IGZyb20gJy4vcm9vdFByb3BzU2VsZWN0b3JzJztcbmltcG9ydCB7IG1hdGhTaWduIH0gZnJvbSAnLi4vLi4vdXRpbC9EYXRhVXRpbHMnO1xuaW1wb3J0IHsgY29tYmluZUF4aXNSYW5nZVdpdGhSZXZlcnNlIH0gZnJvbSAnLi9jb21iaW5lcnMvY29tYmluZUF4aXNSYW5nZVdpdGhSZXZlcnNlJztcbmltcG9ydCB7IGNvbWJpbmVUb29sdGlwRXZlbnRUeXBlLCBzZWxlY3REZWZhdWx0VG9vbHRpcEV2ZW50VHlwZSwgc2VsZWN0VmFsaWRhdGVUb29sdGlwRXZlbnRUeXBlcyB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcEV2ZW50VHlwZSc7XG5pbXBvcnQgeyBjb21iaW5lQWN0aXZlTGFiZWwgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lQWN0aXZlTGFiZWwnO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcFNldHRpbmdzIH0gZnJvbSAnLi9zZWxlY3RUb29sdGlwU2V0dGluZ3MnO1xuaW1wb3J0IHsgY29tYmluZVRvb2x0aXBJbnRlcmFjdGlvblN0YXRlIH0gZnJvbSAnLi9jb21iaW5lcnMvY29tYmluZVRvb2x0aXBJbnRlcmFjdGlvblN0YXRlJztcbmltcG9ydCB7IGNvbWJpbmVBY3RpdmVUb29sdGlwSW5kZXggfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lQWN0aXZlVG9vbHRpcEluZGV4JztcbmltcG9ydCB7IGNvbWJpbmVDb29yZGluYXRlRm9yRGVmYXVsdEluZGV4IH0gZnJvbSAnLi9jb21iaW5lcnMvY29tYmluZUNvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXgnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRIZWlnaHQsIHNlbGVjdENoYXJ0V2lkdGggfSBmcm9tICcuL2NvbnRhaW5lclNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE9mZnNldEludGVybmFsIH0gZnJvbSAnLi9zZWxlY3RDaGFydE9mZnNldEludGVybmFsJztcbmltcG9ydCB7IGNvbWJpbmVUb29sdGlwUGF5bG9hZENvbmZpZ3VyYXRpb25zIH0gZnJvbSAnLi9jb21iaW5lcnMvY29tYmluZVRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMnO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlcic7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwU3RhdGUgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBTdGF0ZSc7XG5pbXBvcnQgeyBjb21iaW5lVG9vbHRpcFBheWxvYWQgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lVG9vbHRpcFBheWxvYWQnO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcEF4aXNJZCB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcEF4aXNJZCc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc1R5cGUgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBBeGlzVHlwZSc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpcywgc2VsZWN0VG9vbHRpcEF4aXNEYXRhS2V5IH0gZnJvbSAnLi9zZWxlY3RUb29sdGlwQXhpcyc7XG5pbXBvcnQgeyBjb21iaW5lRGlzcGxheWVkU3RhY2tlZERhdGEgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lRGlzcGxheWVkU3RhY2tlZERhdGEnO1xuaW1wb3J0IHsgaXNTdGFja2VkIH0gZnJvbSAnLi4vdHlwZXMvU3RhY2tlZEdyYXBoaWNhbEl0ZW0nO1xuaW1wb3J0IHsgbnVtZXJpY2FsRG9tYWluU3BlY2lmaWVkV2l0aG91dFJlcXVpcmluZ0RhdGEgfSBmcm9tICcuLi8uLi91dGlsL2lzRG9tYWluU3BlY2lmaWVkQnlVc2VyJztcbmltcG9ydCB7IG51bWJlckRvbWFpbkVxdWFsaXR5Q2hlY2sgfSBmcm9tICcuL251bWJlckRvbWFpbkVxdWFsaXR5Q2hlY2snO1xuaW1wb3J0IHsgYXJyYXlFcXVhbGl0eUNoZWNrIH0gZnJvbSAnLi9hcnJheUVxdWFsaXR5Q2hlY2snO1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc1JlYWxTY2FsZVR5cGUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEF4aXMsIHNlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RIYXNCYXIsIHNlbGVjdENoYXJ0TmFtZSwgc2VsZWN0VG9vbHRpcEF4aXNUeXBlXSwgY29tYmluZVJlYWxTY2FsZVR5cGUpO1xuZXhwb3J0IHZhciBzZWxlY3RBbGxVbmZpbHRlcmVkR3JhcGhpY2FsSXRlbXMgPSBjcmVhdGVTZWxlY3Rvcihbc3RhdGUgPT4gc3RhdGUuZ3JhcGhpY2FsSXRlbXMuY2FydGVzaWFuSXRlbXMsIHN0YXRlID0+IHN0YXRlLmdyYXBoaWNhbEl0ZW1zLnBvbGFySXRlbXNdLCAoY2FydGVzaWFuSXRlbXMsIHBvbGFySXRlbXMpID0+IFsuLi5jYXJ0ZXNpYW5JdGVtcywgLi4ucG9sYXJJdGVtc10pO1xudmFyIHNlbGVjdFRvb2x0aXBBeGlzUHJlZGljYXRlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBBeGlzVHlwZSwgc2VsZWN0VG9vbHRpcEF4aXNJZF0sIGl0ZW1BeGlzUHJlZGljYXRlKTtcbmV4cG9ydCB2YXIgc2VsZWN0QWxsR3JhcGhpY2FsSXRlbXNTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbGxVbmZpbHRlcmVkR3JhcGhpY2FsSXRlbXMsIHNlbGVjdFRvb2x0aXBBeGlzLCBzZWxlY3RUb29sdGlwQXhpc1ByZWRpY2F0ZV0sIGNvbWJpbmVHcmFwaGljYWxJdGVtc1NldHRpbmdzLCB7XG4gIG1lbW9pemVPcHRpb25zOiB7XG4gICAgcmVzdWx0RXF1YWxpdHlDaGVjazogYXJyYXlFcXVhbGl0eUNoZWNrXG4gIH1cbn0pO1xudmFyIHNlbGVjdEFsbFN0YWNrZWRHcmFwaGljYWxJdGVtc1NldHRpbmdzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbEdyYXBoaWNhbEl0ZW1zU2V0dGluZ3NdLCBncmFwaGljYWxJdGVtcyA9PiBncmFwaGljYWxJdGVtcy5maWx0ZXIoaXNTdGFja2VkKSk7XG5leHBvcnQgdmFyIHNlbGVjdFRvb2x0aXBHcmFwaGljYWxJdGVtc0RhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QWxsR3JhcGhpY2FsSXRlbXNTZXR0aW5nc10sIGNvbWJpbmVHcmFwaGljYWxJdGVtc0RhdGEsIHtcbiAgbWVtb2l6ZU9wdGlvbnM6IHtcbiAgICByZXN1bHRFcXVhbGl0eUNoZWNrOiBhcnJheUVxdWFsaXR5Q2hlY2tcbiAgfVxufSk7XG5cbi8qKlxuICogRGF0YSBmb3IgdG9vbHRpcCBhbHdheXMgdXNlIHRoZSBkYXRhIHdpdGggaW5kZXhlcyBzZXQgYnkgYSBCcnVzaCxcbiAqIGFuZCBuZXZlciBhY2NlcHQgdGhlIGlzUGFub3JhbWEgZmxhZzpcbiAqIGJlY2F1c2UgVG9vbHRpcCBuZXZlciBkaXNwbGF5cyBpbnNpZGUgdGhlIHBhbm9yYW1hIGFueXdheVxuICogc28gd2UgZG9uJ3QgbmVlZCB0byB3b3JyeSB3aGF0IHdvdWxkIGhhcHBlbiB0aGVyZS5cbiAqL1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwRGlzcGxheWVkRGF0YSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwR3JhcGhpY2FsSXRlbXNEYXRhLCBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlc10sIGNvbWJpbmVEaXNwbGF5ZWREYXRhKTtcbnZhciBzZWxlY3RUb29sdGlwU3RhY2tlZERhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QWxsU3RhY2tlZEdyYXBoaWNhbEl0ZW1zU2V0dGluZ3MsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzLCBzZWxlY3RUb29sdGlwQXhpc10sIGNvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSk7XG52YXIgc2VsZWN0QWxsVG9vbHRpcEFwcGxpZWRWYWx1ZXMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcERpc3BsYXllZERhdGEsIHNlbGVjdFRvb2x0aXBBeGlzLCBzZWxlY3RBbGxHcmFwaGljYWxJdGVtc1NldHRpbmdzXSwgY29tYmluZUFwcGxpZWRWYWx1ZXMpO1xudmFyIHNlbGVjdFRvb2x0aXBBeGlzRG9tYWluRGVmaW5pdGlvbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwQXhpc10sIGdldERvbWFpbkRlZmluaXRpb24pO1xudmFyIHNlbGVjdFRvb2x0aXBEYXRhT3ZlcmZsb3cgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEF4aXNdLCBheGlzU2V0dGluZ3MgPT4gYXhpc1NldHRpbmdzLmFsbG93RGF0YU92ZXJmbG93KTtcbnZhciBzZWxlY3RUb29sdGlwRG9tYWluRnJvbVVzZXJQcmVmZXJlbmNlcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwQXhpc0RvbWFpbkRlZmluaXRpb24sIHNlbGVjdFRvb2x0aXBEYXRhT3ZlcmZsb3ddLCBudW1lcmljYWxEb21haW5TcGVjaWZpZWRXaXRob3V0UmVxdWlyaW5nRGF0YSk7XG52YXIgc2VsZWN0QWxsU3RhY2tlZEdyYXBoaWNhbEl0ZW1zID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbEdyYXBoaWNhbEl0ZW1zU2V0dGluZ3NdLCBncmFwaGljYWxJdGVtcyA9PiBncmFwaGljYWxJdGVtcy5maWx0ZXIoaXNTdGFja2VkKSk7XG52YXIgc2VsZWN0VG9vbHRpcFN0YWNrR3JvdXBzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBTdGFja2VkRGF0YSwgc2VsZWN0QWxsU3RhY2tlZEdyYXBoaWNhbEl0ZW1zLCBzZWxlY3RTdGFja09mZnNldFR5cGVdLCBjb21iaW5lU3RhY2tHcm91cHMpO1xudmFyIHNlbGVjdFRvb2x0aXBEb21haW5PZlN0YWNrR3JvdXBzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBTdGFja0dyb3Vwcywgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXMsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZSwgc2VsZWN0VG9vbHRpcERvbWFpbkZyb21Vc2VyUHJlZmVyZW5jZXNdLCBjb21iaW5lRG9tYWluT2ZTdGFja0dyb3Vwcyk7XG52YXIgc2VsZWN0VG9vbHRpcEl0ZW1zU2V0dGluZ3NFeGNlcHRTdGFja2VkID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbEdyYXBoaWNhbEl0ZW1zU2V0dGluZ3NdLCBmaWx0ZXJHcmFwaGljYWxOb3RTdGFja2VkSXRlbXMpO1xudmFyIHNlbGVjdERvbWFpbk9mQWxsQXBwbGllZE51bWVyaWNhbFZhbHVlc0luY2x1ZGluZ0Vycm9yVmFsdWVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBEaXNwbGF5ZWREYXRhLCBzZWxlY3RUb29sdGlwQXhpcywgc2VsZWN0VG9vbHRpcEl0ZW1zU2V0dGluZ3NFeGNlcHRTdGFja2VkLCBzZWxlY3RBbGxFcnJvckJhclNldHRpbmdzLCBzZWxlY3RUb29sdGlwQXhpc1R5cGVdLCBjb21iaW5lRG9tYWluT2ZBbGxBcHBsaWVkTnVtZXJpY2FsVmFsdWVzSW5jbHVkaW5nRXJyb3JWYWx1ZXMsIHtcbiAgbWVtb2l6ZU9wdGlvbnM6IHtcbiAgICByZXN1bHRFcXVhbGl0eUNoZWNrOiBudW1iZXJEb21haW5FcXVhbGl0eUNoZWNrXG4gIH1cbn0pO1xudmFyIHNlbGVjdFJlZmVyZW5jZURvdHNCeVRvb2x0aXBBeGlzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJlZmVyZW5jZURvdHMsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZSwgc2VsZWN0VG9vbHRpcEF4aXNJZF0sIGZpbHRlclJlZmVyZW5jZUVsZW1lbnRzKTtcbnZhciBzZWxlY3RUb29sdGlwUmVmZXJlbmNlRG90c0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RSZWZlcmVuY2VEb3RzQnlUb29sdGlwQXhpcywgc2VsZWN0VG9vbHRpcEF4aXNUeXBlXSwgY29tYmluZURvdHNEb21haW4pO1xudmFyIHNlbGVjdFJlZmVyZW5jZUFyZWFzQnlUb29sdGlwQXhpcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RSZWZlcmVuY2VBcmVhcywgc2VsZWN0VG9vbHRpcEF4aXNUeXBlLCBzZWxlY3RUb29sdGlwQXhpc0lkXSwgZmlsdGVyUmVmZXJlbmNlRWxlbWVudHMpO1xudmFyIHNlbGVjdFRvb2x0aXBSZWZlcmVuY2VBcmVhc0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RSZWZlcmVuY2VBcmVhc0J5VG9vbHRpcEF4aXMsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZV0sIGNvbWJpbmVBcmVhc0RvbWFpbik7XG52YXIgc2VsZWN0UmVmZXJlbmNlTGluZXNCeVRvb2x0aXBBeGlzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJlZmVyZW5jZUxpbmVzLCBzZWxlY3RUb29sdGlwQXhpc1R5cGUsIHNlbGVjdFRvb2x0aXBBeGlzSWRdLCBmaWx0ZXJSZWZlcmVuY2VFbGVtZW50cyk7XG52YXIgc2VsZWN0VG9vbHRpcFJlZmVyZW5jZUxpbmVzRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJlZmVyZW5jZUxpbmVzQnlUb29sdGlwQXhpcywgc2VsZWN0VG9vbHRpcEF4aXNUeXBlXSwgY29tYmluZUxpbmVzRG9tYWluKTtcbnZhciBzZWxlY3RUb29sdGlwUmVmZXJlbmNlRWxlbWVudHNEb21haW4gPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcFJlZmVyZW5jZURvdHNEb21haW4sIHNlbGVjdFRvb2x0aXBSZWZlcmVuY2VMaW5lc0RvbWFpbiwgc2VsZWN0VG9vbHRpcFJlZmVyZW5jZUFyZWFzRG9tYWluXSwgbWVyZ2VEb21haW5zKTtcbnZhciBzZWxlY3RUb29sdGlwTnVtZXJpY2FsRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBBeGlzLCBzZWxlY3RUb29sdGlwQXhpc0RvbWFpbkRlZmluaXRpb24sIHNlbGVjdFRvb2x0aXBEb21haW5Gcm9tVXNlclByZWZlcmVuY2VzLCBzZWxlY3RUb29sdGlwRG9tYWluT2ZTdGFja0dyb3Vwcywgc2VsZWN0RG9tYWluT2ZBbGxBcHBsaWVkTnVtZXJpY2FsVmFsdWVzSW5jbHVkaW5nRXJyb3JWYWx1ZXMsIHNlbGVjdFRvb2x0aXBSZWZlcmVuY2VFbGVtZW50c0RvbWFpbiwgc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZV0sIGNvbWJpbmVOdW1lcmljYWxEb21haW4pO1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc0RvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwQXhpcywgc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFRvb2x0aXBEaXNwbGF5ZWREYXRhLCBzZWxlY3RBbGxUb29sdGlwQXBwbGllZFZhbHVlcywgc2VsZWN0U3RhY2tPZmZzZXRUeXBlLCBzZWxlY3RUb29sdGlwQXhpc1R5cGUsIHNlbGVjdFRvb2x0aXBOdW1lcmljYWxEb21haW5dLCBjb21iaW5lQXhpc0RvbWFpbik7XG52YXIgc2VsZWN0VG9vbHRpcE5pY2VUaWNrcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwQXhpc0RvbWFpbiwgc2VsZWN0VG9vbHRpcEF4aXMsIHNlbGVjdFRvb2x0aXBBeGlzUmVhbFNjYWxlVHlwZV0sIGNvbWJpbmVOaWNlVGlja3MpO1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc0RvbWFpbkluY2x1ZGluZ05pY2VUaWNrcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwQXhpcywgc2VsZWN0VG9vbHRpcEF4aXNEb21haW4sIHNlbGVjdFRvb2x0aXBOaWNlVGlja3MsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZV0sIGNvbWJpbmVBeGlzRG9tYWluV2l0aE5pY2VUaWNrcyk7XG52YXIgc2VsZWN0VG9vbHRpcEF4aXNSYW5nZSA9IHN0YXRlID0+IHtcbiAgdmFyIGF4aXNUeXBlID0gc2VsZWN0VG9vbHRpcEF4aXNUeXBlKHN0YXRlKTtcbiAgdmFyIGF4aXNJZCA9IHNlbGVjdFRvb2x0aXBBeGlzSWQoc3RhdGUpO1xuICB2YXIgaXNQYW5vcmFtYSA9IGZhbHNlOyAvLyBUb29sdGlwIG5ldmVyIGRpc3BsYXlzIGluIHBhbm9yYW1hIHNvIHRoaXMgaXMgc2FmZSB0byBhc3N1bWVcbiAgcmV0dXJuIHNlbGVjdEF4aXNSYW5nZShzdGF0ZSwgYXhpc1R5cGUsIGF4aXNJZCwgaXNQYW5vcmFtYSk7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc1JhbmdlV2l0aFJldmVyc2UgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEF4aXMsIHNlbGVjdFRvb2x0aXBBeGlzUmFuZ2VdLCBjb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UpO1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc1NjYWxlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBBeGlzLCBzZWxlY3RUb29sdGlwQXhpc1JlYWxTY2FsZVR5cGUsIHNlbGVjdFRvb2x0aXBBeGlzRG9tYWluSW5jbHVkaW5nTmljZVRpY2tzLCBzZWxlY3RUb29sdGlwQXhpc1JhbmdlV2l0aFJldmVyc2VdLCBjb21iaW5lU2NhbGVGdW5jdGlvbik7XG52YXIgc2VsZWN0VG9vbHRpcER1cGxpY2F0ZURvbWFpbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0QWxsVG9vbHRpcEFwcGxpZWRWYWx1ZXMsIHNlbGVjdFRvb2x0aXBBeGlzLCBzZWxlY3RUb29sdGlwQXhpc1R5cGVdLCBjb21iaW5lRHVwbGljYXRlRG9tYWluKTtcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcENhdGVnb3JpY2FsRG9tYWluID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RBbGxUb29sdGlwQXBwbGllZFZhbHVlcywgc2VsZWN0VG9vbHRpcEF4aXMsIHNlbGVjdFRvb2x0aXBBeGlzVHlwZV0sIGNvbWJpbmVDYXRlZ29yaWNhbERvbWFpbik7XG52YXIgY29tYmluZVRpY2tzT2ZUb29sdGlwQXhpcyA9IChsYXlvdXQsIGF4aXMsIHJlYWxTY2FsZVR5cGUsIHNjYWxlLCByYW5nZSwgZHVwbGljYXRlRG9tYWluLCBjYXRlZ29yaWNhbERvbWFpbiwgYXhpc1R5cGUpID0+IHtcbiAgaWYgKCFheGlzKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIHR5cGVcbiAgfSA9IGF4aXM7XG4gIHZhciBpc0NhdGVnb3JpY2FsID0gaXNDYXRlZ29yaWNhbEF4aXMobGF5b3V0LCBheGlzVHlwZSk7XG4gIGlmICghc2NhbGUpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBvZmZzZXRGb3JCYW5kID0gcmVhbFNjYWxlVHlwZSA9PT0gJ3NjYWxlQmFuZCcgJiYgc2NhbGUuYmFuZHdpZHRoID8gc2NhbGUuYmFuZHdpZHRoKCkgLyAyIDogMjtcbiAgdmFyIG9mZnNldCA9IHR5cGUgPT09ICdjYXRlZ29yeScgJiYgc2NhbGUuYmFuZHdpZHRoID8gc2NhbGUuYmFuZHdpZHRoKCkgLyBvZmZzZXRGb3JCYW5kIDogMDtcbiAgb2Zmc2V0ID0gYXhpc1R5cGUgPT09ICdhbmdsZUF4aXMnICYmIHJhbmdlICE9IG51bGwgJiYgKHJhbmdlID09PSBudWxsIHx8IHJhbmdlID09PSB2b2lkIDAgPyB2b2lkIDAgOiByYW5nZS5sZW5ndGgpID49IDIgPyBtYXRoU2lnbihyYW5nZVswXSAtIHJhbmdlWzFdKSAqIDIgKiBvZmZzZXQgOiBvZmZzZXQ7XG5cbiAgLy8gV2hlbiBheGlzIGlzIGEgY2F0ZWdvcmljYWwgYXhpcywgYnV0IHRoZSB0eXBlIG9mIGF4aXMgaXMgbnVtYmVyIG9yIHRoZSBzY2FsZSBvZiBheGlzIGlzIG5vdCBcImF1dG9cIlxuICBpZiAoaXNDYXRlZ29yaWNhbCAmJiBjYXRlZ29yaWNhbERvbWFpbikge1xuICAgIHJldHVybiBjYXRlZ29yaWNhbERvbWFpbi5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKHtcbiAgICAgIGNvb3JkaW5hdGU6IHNjYWxlKGVudHJ5KSArIG9mZnNldCxcbiAgICAgIHZhbHVlOiBlbnRyeSxcbiAgICAgIGluZGV4LFxuICAgICAgb2Zmc2V0XG4gICAgfSkpO1xuICB9XG5cbiAgLy8gV2hlbiBheGlzIGhhcyBkdXBsaWNhdGVkIHRleHQsIHNlcmlhbCBudW1iZXJzIGFyZSB1c2VkIHRvIGdlbmVyYXRlIHNjYWxlXG4gIHJldHVybiBzY2FsZS5kb21haW4oKS5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKHtcbiAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgdmFsdWU6IGR1cGxpY2F0ZURvbWFpbiA/IGR1cGxpY2F0ZURvbWFpbltlbnRyeV0gOiBlbnRyeSxcbiAgICBpbmRleCxcbiAgICBvZmZzZXRcbiAgfSkpO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcEF4aXNUaWNrcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0VG9vbHRpcEF4aXMsIHNlbGVjdFRvb2x0aXBBeGlzUmVhbFNjYWxlVHlwZSwgc2VsZWN0VG9vbHRpcEF4aXNTY2FsZSwgc2VsZWN0VG9vbHRpcEF4aXNSYW5nZSwgc2VsZWN0VG9vbHRpcER1cGxpY2F0ZURvbWFpbiwgc2VsZWN0VG9vbHRpcENhdGVnb3JpY2FsRG9tYWluLCBzZWxlY3RUb29sdGlwQXhpc1R5cGVdLCBjb21iaW5lVGlja3NPZlRvb2x0aXBBeGlzKTtcbnZhciBzZWxlY3RUb29sdGlwRXZlbnRUeXBlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdERlZmF1bHRUb29sdGlwRXZlbnRUeXBlLCBzZWxlY3RWYWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzLCBzZWxlY3RUb29sdGlwU2V0dGluZ3NdLCAoZGVmYXVsdFRvb2x0aXBFdmVudFR5cGUsIHZhbGlkYXRlVG9vbHRpcEV2ZW50VHlwZSwgc2V0dGluZ3MpID0+IGNvbWJpbmVUb29sdGlwRXZlbnRUeXBlKHNldHRpbmdzLnNoYXJlZCwgZGVmYXVsdFRvb2x0aXBFdmVudFR5cGUsIHZhbGlkYXRlVG9vbHRpcEV2ZW50VHlwZSkpO1xudmFyIHNlbGVjdFRvb2x0aXBUcmlnZ2VyID0gc3RhdGUgPT4gc3RhdGUudG9vbHRpcC5zZXR0aW5ncy50cmlnZ2VyO1xudmFyIHNlbGVjdERlZmF1bHRJbmRleCA9IHN0YXRlID0+IHN0YXRlLnRvb2x0aXAuc2V0dGluZ3MuZGVmYXVsdEluZGV4O1xudmFyIHNlbGVjdFRvb2x0aXBJbnRlcmFjdGlvblN0YXRlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBTdGF0ZSwgc2VsZWN0VG9vbHRpcEV2ZW50VHlwZSwgc2VsZWN0VG9vbHRpcFRyaWdnZXIsIHNlbGVjdERlZmF1bHRJbmRleF0sIGNvbWJpbmVUb29sdGlwSW50ZXJhY3Rpb25TdGF0ZSk7XG5leHBvcnQgdmFyIHNlbGVjdEFjdGl2ZVRvb2x0aXBJbmRleCA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwSW50ZXJhY3Rpb25TdGF0ZSwgc2VsZWN0VG9vbHRpcERpc3BsYXllZERhdGFdLCBjb21iaW5lQWN0aXZlVG9vbHRpcEluZGV4KTtcbmV4cG9ydCB2YXIgc2VsZWN0QWN0aXZlTGFiZWwgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEF4aXNUaWNrcywgc2VsZWN0QWN0aXZlVG9vbHRpcEluZGV4XSwgY29tYmluZUFjdGl2ZUxhYmVsKTtcbmV4cG9ydCB2YXIgc2VsZWN0QWN0aXZlVG9vbHRpcERhdGFLZXkgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEludGVyYWN0aW9uU3RhdGVdLCB0b29sdGlwSW50ZXJhY3Rpb24gPT4ge1xuICBpZiAoIXRvb2x0aXBJbnRlcmFjdGlvbikge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHRvb2x0aXBJbnRlcmFjdGlvbi5kYXRhS2V5O1xufSk7XG52YXIgc2VsZWN0VG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9ucyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwU3RhdGUsIHNlbGVjdFRvb2x0aXBFdmVudFR5cGUsIHNlbGVjdFRvb2x0aXBUcmlnZ2VyLCBzZWxlY3REZWZhdWx0SW5kZXhdLCBjb21iaW5lVG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9ucyk7XG52YXIgc2VsZWN0VG9vbHRpcENvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXggPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRXaWR0aCwgc2VsZWN0Q2hhcnRIZWlnaHQsIHNlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RUb29sdGlwQXhpc1RpY2tzLCBzZWxlY3REZWZhdWx0SW5kZXgsIHNlbGVjdFRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMsIHNlbGVjdFRvb2x0aXBQYXlsb2FkU2VhcmNoZXJdLCBjb21iaW5lQ29vcmRpbmF0ZUZvckRlZmF1bHRJbmRleCk7XG5leHBvcnQgdmFyIHNlbGVjdEFjdGl2ZVRvb2x0aXBDb29yZGluYXRlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLCBzZWxlY3RUb29sdGlwQ29vcmRpbmF0ZUZvckRlZmF1bHRJbmRleF0sICh0b29sdGlwSW50ZXJhY3Rpb25TdGF0ZSwgZGVmYXVsdEluZGV4Q29vcmRpbmF0ZSkgPT4ge1xuICBpZiAodG9vbHRpcEludGVyYWN0aW9uU3RhdGUgIT09IG51bGwgJiYgdG9vbHRpcEludGVyYWN0aW9uU3RhdGUgIT09IHZvaWQgMCAmJiB0b29sdGlwSW50ZXJhY3Rpb25TdGF0ZS5jb29yZGluYXRlKSB7XG4gICAgcmV0dXJuIHRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLmNvb3JkaW5hdGU7XG4gIH1cbiAgcmV0dXJuIGRlZmF1bHRJbmRleENvb3JkaW5hdGU7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0SXNUb29sdGlwQWN0aXZlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBJbnRlcmFjdGlvblN0YXRlXSwgdG9vbHRpcEludGVyYWN0aW9uU3RhdGUgPT4gdG9vbHRpcEludGVyYWN0aW9uU3RhdGUuYWN0aXZlKTtcbmV4cG9ydCB2YXIgc2VsZWN0QWN0aXZlVG9vbHRpcFBheWxvYWQgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9ucywgc2VsZWN0QWN0aXZlVG9vbHRpcEluZGV4LCBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlcywgc2VsZWN0VG9vbHRpcEF4aXNEYXRhS2V5LCBzZWxlY3RBY3RpdmVMYWJlbCwgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciwgc2VsZWN0VG9vbHRpcEV2ZW50VHlwZV0sIGNvbWJpbmVUb29sdGlwUGF5bG9hZCk7XG5leHBvcnQgdmFyIHNlbGVjdEFjdGl2ZVRvb2x0aXBEYXRhUG9pbnRzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFjdGl2ZVRvb2x0aXBQYXlsb2FkXSwgcGF5bG9hZCA9PiB7XG4gIGlmIChwYXlsb2FkID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBkYXRhUG9pbnRzID0gcGF5bG9hZC5tYXAocCA9PiBwLnBheWxvYWQpLmZpbHRlcihwID0+IHAgIT0gbnVsbCk7XG4gIHJldHVybiBBcnJheS5mcm9tKG5ldyBTZXQoZGF0YVBvaW50cykpO1xufSk7IiwiZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5pbXBvcnQgc29ydEJ5IGZyb20gJ2VzLXRvb2xraXQvY29tcGF0L3NvcnRCeSc7XG5pbXBvcnQgZ2V0IGZyb20gJ2VzLXRvb2xraXQvY29tcGF0L2dldCc7XG5pbXBvcnQgeyBzdGFjayBhcyBzaGFwZVN0YWNrLCBzdGFja09mZnNldEV4cGFuZCwgc3RhY2tPZmZzZXROb25lLCBzdGFja09mZnNldFNpbGhvdWV0dGUsIHN0YWNrT2Zmc2V0V2lnZ2xlLCBzdGFja09yZGVyTm9uZSB9IGZyb20gJ3ZpY3RvcnktdmVuZG9yL2QzLXNoYXBlJztcbmltcG9ydCB7IGZpbmRFbnRyeUluQXJyYXksIGlzTmFuLCBpc051bGxpc2gsIGlzTnVtYmVyLCBpc051bU9yU3RyLCBtYXRoU2lnbiB9IGZyb20gJy4vRGF0YVV0aWxzJztcbmltcG9ydCB7IGluUmFuZ2VPZlNlY3RvciwgcG9sYXJUb0NhcnRlc2lhbiB9IGZyb20gJy4vUG9sYXJVdGlscyc7XG5pbXBvcnQgeyBnZXRTbGljZWQgfSBmcm9tICcuL2dldFNsaWNlZCc7XG5leHBvcnQgZnVuY3Rpb24gZ2V0VmFsdWVCeURhdGFLZXkob2JqLCBkYXRhS2V5LCBkZWZhdWx0VmFsdWUpIHtcbiAgaWYgKGlzTnVsbGlzaChvYmopIHx8IGlzTnVsbGlzaChkYXRhS2V5KSkge1xuICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gIH1cbiAgaWYgKGlzTnVtT3JTdHIoZGF0YUtleSkpIHtcbiAgICByZXR1cm4gZ2V0KG9iaiwgZGF0YUtleSwgZGVmYXVsdFZhbHVlKTtcbiAgfVxuICBpZiAodHlwZW9mIGRhdGFLZXkgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gZGF0YUtleShvYmopO1xuICB9XG4gIHJldHVybiBkZWZhdWx0VmFsdWU7XG59XG5leHBvcnQgdmFyIGNhbGN1bGF0ZUFjdGl2ZVRpY2tJbmRleCA9IChjb29yZGluYXRlLCB0aWNrcywgdW5zb3J0ZWRUaWNrcywgYXhpc1R5cGUsIHJhbmdlKSA9PiB7XG4gIHZhciBfdGlja3MkbGVuZ3RoO1xuICB2YXIgaW5kZXggPSAtMTtcbiAgdmFyIGxlbiA9IChfdGlja3MkbGVuZ3RoID0gdGlja3MgPT09IG51bGwgfHwgdGlja3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRpY2tzLmxlbmd0aCkgIT09IG51bGwgJiYgX3RpY2tzJGxlbmd0aCAhPT0gdm9pZCAwID8gX3RpY2tzJGxlbmd0aCA6IDA7XG5cbiAgLy8gaWYgdGhlcmUgYXJlIDEgb3IgZmV3ZXIgdGlja3Mgb3IgaWYgdGhlcmUgaXMgbm8gY29vcmRpbmF0ZSB0aGVuIHRoZSBhY3RpdmUgdGljayBpcyBhdCBpbmRleCAwXG4gIGlmIChsZW4gPD0gMSB8fCBjb29yZGluYXRlID09IG51bGwpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICBpZiAoYXhpc1R5cGUgPT09ICdhbmdsZUF4aXMnICYmIHJhbmdlICE9IG51bGwgJiYgTWF0aC5hYnMoTWF0aC5hYnMocmFuZ2VbMV0gLSByYW5nZVswXSkgLSAzNjApIDw9IDFlLTYpIHtcbiAgICAvLyB0aWNrcyBhcmUgZGlzdHJpYnV0ZWQgaW4gYSBjaXJjbGVcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICB2YXIgYmVmb3JlID0gaSA+IDAgPyB1bnNvcnRlZFRpY2tzW2kgLSAxXS5jb29yZGluYXRlIDogdW5zb3J0ZWRUaWNrc1tsZW4gLSAxXS5jb29yZGluYXRlO1xuICAgICAgdmFyIGN1ciA9IHVuc29ydGVkVGlja3NbaV0uY29vcmRpbmF0ZTtcbiAgICAgIHZhciBhZnRlciA9IGkgPj0gbGVuIC0gMSA/IHVuc29ydGVkVGlja3NbMF0uY29vcmRpbmF0ZSA6IHVuc29ydGVkVGlja3NbaSArIDFdLmNvb3JkaW5hdGU7XG4gICAgICB2YXIgc2FtZURpcmVjdGlvbkNvb3JkID0gdm9pZCAwO1xuICAgICAgaWYgKG1hdGhTaWduKGN1ciAtIGJlZm9yZSkgIT09IG1hdGhTaWduKGFmdGVyIC0gY3VyKSkge1xuICAgICAgICB2YXIgZGlmZkludGVydmFsID0gW107XG4gICAgICAgIGlmIChtYXRoU2lnbihhZnRlciAtIGN1cikgPT09IG1hdGhTaWduKHJhbmdlWzFdIC0gcmFuZ2VbMF0pKSB7XG4gICAgICAgICAgc2FtZURpcmVjdGlvbkNvb3JkID0gYWZ0ZXI7XG4gICAgICAgICAgdmFyIGN1ckluUmFuZ2UgPSBjdXIgKyByYW5nZVsxXSAtIHJhbmdlWzBdO1xuICAgICAgICAgIGRpZmZJbnRlcnZhbFswXSA9IE1hdGgubWluKGN1ckluUmFuZ2UsIChjdXJJblJhbmdlICsgYmVmb3JlKSAvIDIpO1xuICAgICAgICAgIGRpZmZJbnRlcnZhbFsxXSA9IE1hdGgubWF4KGN1ckluUmFuZ2UsIChjdXJJblJhbmdlICsgYmVmb3JlKSAvIDIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNhbWVEaXJlY3Rpb25Db29yZCA9IGJlZm9yZTtcbiAgICAgICAgICB2YXIgYWZ0ZXJJblJhbmdlID0gYWZ0ZXIgKyByYW5nZVsxXSAtIHJhbmdlWzBdO1xuICAgICAgICAgIGRpZmZJbnRlcnZhbFswXSA9IE1hdGgubWluKGN1ciwgKGFmdGVySW5SYW5nZSArIGN1cikgLyAyKTtcbiAgICAgICAgICBkaWZmSW50ZXJ2YWxbMV0gPSBNYXRoLm1heChjdXIsIChhZnRlckluUmFuZ2UgKyBjdXIpIC8gMik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHNhbWVJbnRlcnZhbCA9IFtNYXRoLm1pbihjdXIsIChzYW1lRGlyZWN0aW9uQ29vcmQgKyBjdXIpIC8gMiksIE1hdGgubWF4KGN1ciwgKHNhbWVEaXJlY3Rpb25Db29yZCArIGN1cikgLyAyKV07XG4gICAgICAgIGlmIChjb29yZGluYXRlID4gc2FtZUludGVydmFsWzBdICYmIGNvb3JkaW5hdGUgPD0gc2FtZUludGVydmFsWzFdIHx8IGNvb3JkaW5hdGUgPj0gZGlmZkludGVydmFsWzBdICYmIGNvb3JkaW5hdGUgPD0gZGlmZkludGVydmFsWzFdKSB7XG4gICAgICAgICAgKHtcbiAgICAgICAgICAgIGluZGV4XG4gICAgICAgICAgfSA9IHVuc29ydGVkVGlja3NbaV0pO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgbWluVmFsdWUgPSBNYXRoLm1pbihiZWZvcmUsIGFmdGVyKTtcbiAgICAgICAgdmFyIG1heFZhbHVlID0gTWF0aC5tYXgoYmVmb3JlLCBhZnRlcik7XG4gICAgICAgIGlmIChjb29yZGluYXRlID4gKG1pblZhbHVlICsgY3VyKSAvIDIgJiYgY29vcmRpbmF0ZSA8PSAobWF4VmFsdWUgKyBjdXIpIC8gMikge1xuICAgICAgICAgICh7XG4gICAgICAgICAgICBpbmRleFxuICAgICAgICAgIH0gPSB1bnNvcnRlZFRpY2tzW2ldKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmICh0aWNrcykge1xuICAgIC8vIHRpY2tzIGFyZSBkaXN0cmlidXRlZCBpbiBhIHNpbmdsZSBkaXJlY3Rpb25cbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgbGVuOyBfaSsrKSB7XG4gICAgICBpZiAoX2kgPT09IDAgJiYgY29vcmRpbmF0ZSA8PSAodGlja3NbX2ldLmNvb3JkaW5hdGUgKyB0aWNrc1tfaSArIDFdLmNvb3JkaW5hdGUpIC8gMiB8fCBfaSA+IDAgJiYgX2kgPCBsZW4gLSAxICYmIGNvb3JkaW5hdGUgPiAodGlja3NbX2ldLmNvb3JkaW5hdGUgKyB0aWNrc1tfaSAtIDFdLmNvb3JkaW5hdGUpIC8gMiAmJiBjb29yZGluYXRlIDw9ICh0aWNrc1tfaV0uY29vcmRpbmF0ZSArIHRpY2tzW19pICsgMV0uY29vcmRpbmF0ZSkgLyAyIHx8IF9pID09PSBsZW4gLSAxICYmIGNvb3JkaW5hdGUgPiAodGlja3NbX2ldLmNvb3JkaW5hdGUgKyB0aWNrc1tfaSAtIDFdLmNvb3JkaW5hdGUpIC8gMikge1xuICAgICAgICAoe1xuICAgICAgICAgIGluZGV4XG4gICAgICAgIH0gPSB0aWNrc1tfaV0pO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGluZGV4O1xufTtcbmV4cG9ydCB2YXIgYXBwZW5kT2Zmc2V0T2ZMZWdlbmQgPSAob2Zmc2V0LCBsZWdlbmRTZXR0aW5ncywgbGVnZW5kU2l6ZSkgPT4ge1xuICBpZiAobGVnZW5kU2V0dGluZ3MgJiYgbGVnZW5kU2l6ZSkge1xuICAgIHZhciB7XG4gICAgICB3aWR0aDogYm94V2lkdGgsXG4gICAgICBoZWlnaHQ6IGJveEhlaWdodFxuICAgIH0gPSBsZWdlbmRTaXplO1xuICAgIHZhciB7XG4gICAgICBhbGlnbixcbiAgICAgIHZlcnRpY2FsQWxpZ24sXG4gICAgICBsYXlvdXRcbiAgICB9ID0gbGVnZW5kU2V0dGluZ3M7XG4gICAgaWYgKChsYXlvdXQgPT09ICd2ZXJ0aWNhbCcgfHwgbGF5b3V0ID09PSAnaG9yaXpvbnRhbCcgJiYgdmVydGljYWxBbGlnbiA9PT0gJ21pZGRsZScpICYmIGFsaWduICE9PSAnY2VudGVyJyAmJiBpc051bWJlcihvZmZzZXRbYWxpZ25dKSkge1xuICAgICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgb2Zmc2V0KSwge30sIHtcbiAgICAgICAgW2FsaWduXTogb2Zmc2V0W2FsaWduXSArIChib3hXaWR0aCB8fCAwKVxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICgobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcgfHwgbGF5b3V0ID09PSAndmVydGljYWwnICYmIGFsaWduID09PSAnY2VudGVyJykgJiYgdmVydGljYWxBbGlnbiAhPT0gJ21pZGRsZScgJiYgaXNOdW1iZXIob2Zmc2V0W3ZlcnRpY2FsQWxpZ25dKSkge1xuICAgICAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgb2Zmc2V0KSwge30sIHtcbiAgICAgICAgW3ZlcnRpY2FsQWxpZ25dOiBvZmZzZXRbdmVydGljYWxBbGlnbl0gKyAoYm94SGVpZ2h0IHx8IDApXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG9mZnNldDtcbn07XG5leHBvcnQgdmFyIGlzQ2F0ZWdvcmljYWxBeGlzID0gKGxheW91dCwgYXhpc1R5cGUpID0+IGxheW91dCA9PT0gJ2hvcml6b250YWwnICYmIGF4aXNUeXBlID09PSAneEF4aXMnIHx8IGxheW91dCA9PT0gJ3ZlcnRpY2FsJyAmJiBheGlzVHlwZSA9PT0gJ3lBeGlzJyB8fCBsYXlvdXQgPT09ICdjZW50cmljJyAmJiBheGlzVHlwZSA9PT0gJ2FuZ2xlQXhpcycgfHwgbGF5b3V0ID09PSAncmFkaWFsJyAmJiBheGlzVHlwZSA9PT0gJ3JhZGl1c0F4aXMnO1xuXG4vKipcbiAqIENhbGN1bGF0ZSB0aGUgQ29vcmRpbmF0ZXMgb2YgZ3JpZFxuICogQHBhcmFtICB7QXJyYXl9IHRpY2tzICAgICAgICAgICBUaGUgdGlja3MgaW4gYXhpc1xuICogQHBhcmFtIHtOdW1iZXJ9IG1pblZhbHVlICAgICAgICBUaGUgbWluaW11bSB2YWx1ZSBvZiBheGlzXG4gKiBAcGFyYW0ge051bWJlcn0gbWF4VmFsdWUgICAgICAgIFRoZSBtYXhpbXVtIHZhbHVlIG9mIGF4aXNcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc3luY1dpdGhUaWNrcyAgU3luY2hyb25pemUgZ3JpZCBsaW5lcyB3aXRoIHRpY2tzIG9yIG5vdFxuICogQHJldHVybiB7QXJyYXl9ICAgICAgICAgICAgICAgICBDb29yZGluYXRlc1xuICovXG5leHBvcnQgdmFyIGdldENvb3JkaW5hdGVzT2ZHcmlkID0gKHRpY2tzLCBtaW5WYWx1ZSwgbWF4VmFsdWUsIHN5bmNXaXRoVGlja3MpID0+IHtcbiAgaWYgKHN5bmNXaXRoVGlja3MpIHtcbiAgICByZXR1cm4gdGlja3MubWFwKGVudHJ5ID0+IGVudHJ5LmNvb3JkaW5hdGUpO1xuICB9XG4gIHZhciBoYXNNaW4sIGhhc01heDtcbiAgdmFyIHZhbHVlcyA9IHRpY2tzLm1hcChlbnRyeSA9PiB7XG4gICAgaWYgKGVudHJ5LmNvb3JkaW5hdGUgPT09IG1pblZhbHVlKSB7XG4gICAgICBoYXNNaW4gPSB0cnVlO1xuICAgIH1cbiAgICBpZiAoZW50cnkuY29vcmRpbmF0ZSA9PT0gbWF4VmFsdWUpIHtcbiAgICAgIGhhc01heCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBlbnRyeS5jb29yZGluYXRlO1xuICB9KTtcbiAgaWYgKCFoYXNNaW4pIHtcbiAgICB2YWx1ZXMucHVzaChtaW5WYWx1ZSk7XG4gIH1cbiAgaWYgKCFoYXNNYXgpIHtcbiAgICB2YWx1ZXMucHVzaChtYXhWYWx1ZSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlcztcbn07XG5cbi8qKlxuICogQSBzdWJzZXQgb2YgZDMtc2NhbGUgdGhhdCBSZWNoYXJ0cyBpcyB1c2luZ1xuICovXG5cbi8qKlxuICogR2V0IHRoZSB0aWNrcyBvZiBhbiBheGlzXG4gKiBAcGFyYW0gIHtPYmplY3R9ICBheGlzIFRoZSBjb25maWd1cmF0aW9uIG9mIGFuIGF4aXNcbiAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNHcmlkIFdoZXRoZXIgb3Igbm90IGFyZSB0aGUgdGlja3MgaW4gZ3JpZFxuICogQHBhcmFtIHtCb29sZWFufSBpc0FsbCBSZXR1cm4gdGhlIHRpY2tzIG9mIGFsbCB0aGUgcG9pbnRzIG9yIG5vdFxuICogQHJldHVybiB7QXJyYXl9ICBUaWNrc1xuICovXG5leHBvcnQgdmFyIGdldFRpY2tzT2ZBeGlzID0gKGF4aXMsIGlzR3JpZCwgaXNBbGwpID0+IHtcbiAgaWYgKCFheGlzKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIHtcbiAgICBkdXBsaWNhdGVEb21haW4sXG4gICAgdHlwZSxcbiAgICByYW5nZSxcbiAgICBzY2FsZSxcbiAgICByZWFsU2NhbGVUeXBlLFxuICAgIGlzQ2F0ZWdvcmljYWwsXG4gICAgY2F0ZWdvcmljYWxEb21haW4sXG4gICAgdGlja0NvdW50LFxuICAgIHRpY2tzLFxuICAgIG5pY2VUaWNrcyxcbiAgICBheGlzVHlwZVxuICB9ID0gYXhpcztcbiAgaWYgKCFzY2FsZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHZhciBvZmZzZXRGb3JCYW5kID0gcmVhbFNjYWxlVHlwZSA9PT0gJ3NjYWxlQmFuZCcgJiYgc2NhbGUuYmFuZHdpZHRoID8gc2NhbGUuYmFuZHdpZHRoKCkgLyAyIDogMjtcbiAgdmFyIG9mZnNldCA9IChpc0dyaWQgfHwgaXNBbGwpICYmIHR5cGUgPT09ICdjYXRlZ29yeScgJiYgc2NhbGUuYmFuZHdpZHRoID8gc2NhbGUuYmFuZHdpZHRoKCkgLyBvZmZzZXRGb3JCYW5kIDogMDtcbiAgb2Zmc2V0ID0gYXhpc1R5cGUgPT09ICdhbmdsZUF4aXMnICYmIHJhbmdlICYmIHJhbmdlLmxlbmd0aCA+PSAyID8gbWF0aFNpZ24ocmFuZ2VbMF0gLSByYW5nZVsxXSkgKiAyICogb2Zmc2V0IDogb2Zmc2V0O1xuXG4gIC8vIFRoZSB0aWNrcyBzZXQgYnkgdXNlciBzaG91bGQgb25seSBhZmZlY3QgdGhlIHRpY2tzIGFkamFjZW50IHRvIGF4aXMgbGluZVxuICBpZiAoaXNHcmlkICYmICh0aWNrcyB8fCBuaWNlVGlja3MpKSB7XG4gICAgdmFyIHJlc3VsdCA9ICh0aWNrcyB8fCBuaWNlVGlja3MgfHwgW10pLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XG4gICAgICB2YXIgc2NhbGVDb250ZW50ID0gZHVwbGljYXRlRG9tYWluID8gZHVwbGljYXRlRG9tYWluLmluZGV4T2YoZW50cnkpIDogZW50cnk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAvLyBJZiB0aGUgc2NhbGVDb250ZW50IGlzIG5vdCBhIG51bWJlciwgdGhlIGNvb3JkaW5hdGUgd2lsbCBiZSBOYU4uXG4gICAgICAgIC8vIFRoYXQgY291bGQgYmUgdGhlIGNhc2UgZm9yIGV4YW1wbGUgd2l0aCBhIFBvaW50U2NhbGUgYW5kIGEgc3RyaW5nIGFzIGRvbWFpbi5cbiAgICAgICAgY29vcmRpbmF0ZTogc2NhbGUoc2NhbGVDb250ZW50KSArIG9mZnNldCxcbiAgICAgICAgdmFsdWU6IGVudHJ5LFxuICAgICAgICBvZmZzZXQsXG4gICAgICAgIGluZGV4XG4gICAgICB9O1xuICAgIH0pO1xuICAgIHJldHVybiByZXN1bHQuZmlsdGVyKHJvdyA9PiAhaXNOYW4ocm93LmNvb3JkaW5hdGUpKTtcbiAgfVxuXG4gIC8vIFdoZW4gYXhpcyBpcyBhIGNhdGVnb3JpY2FsIGF4aXMsIGJ1dCB0aGUgdHlwZSBvZiBheGlzIGlzIG51bWJlciBvciB0aGUgc2NhbGUgb2YgYXhpcyBpcyBub3QgXCJhdXRvXCJcbiAgaWYgKGlzQ2F0ZWdvcmljYWwgJiYgY2F0ZWdvcmljYWxEb21haW4pIHtcbiAgICByZXR1cm4gY2F0ZWdvcmljYWxEb21haW4ubWFwKChlbnRyeSwgaW5kZXgpID0+ICh7XG4gICAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgICB2YWx1ZTogZW50cnksXG4gICAgICBpbmRleCxcbiAgICAgIG9mZnNldFxuICAgIH0pKTtcbiAgfVxuICBpZiAoc2NhbGUudGlja3MgJiYgIWlzQWxsICYmIHRpY2tDb3VudCAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHNjYWxlLnRpY2tzKHRpY2tDb3VudCkubWFwKChlbnRyeSwgaW5kZXgpID0+ICh7XG4gICAgICBjb29yZGluYXRlOiBzY2FsZShlbnRyeSkgKyBvZmZzZXQsXG4gICAgICB2YWx1ZTogZW50cnksXG4gICAgICBvZmZzZXQsXG4gICAgICBpbmRleFxuICAgIH0pKTtcbiAgfVxuXG4gIC8vIFdoZW4gYXhpcyBoYXMgZHVwbGljYXRlZCB0ZXh0LCBzZXJpYWwgbnVtYmVycyBhcmUgdXNlZCB0byBnZW5lcmF0ZSBzY2FsZVxuICByZXR1cm4gc2NhbGUuZG9tYWluKCkubWFwKChlbnRyeSwgaW5kZXgpID0+ICh7XG4gICAgY29vcmRpbmF0ZTogc2NhbGUoZW50cnkpICsgb2Zmc2V0LFxuICAgIHZhbHVlOiBkdXBsaWNhdGVEb21haW4gPyBkdXBsaWNhdGVEb21haW5bZW50cnldIDogZW50cnksXG4gICAgaW5kZXgsXG4gICAgb2Zmc2V0XG4gIH0pKTtcbn07XG52YXIgRVBTID0gMWUtNDtcbmV4cG9ydCB2YXIgY2hlY2tEb21haW5PZlNjYWxlID0gc2NhbGUgPT4ge1xuICB2YXIgZG9tYWluID0gc2NhbGUuZG9tYWluKCk7XG4gIGlmICghZG9tYWluIHx8IGRvbWFpbi5sZW5ndGggPD0gMikge1xuICAgIHJldHVybjtcbiAgfVxuICB2YXIgbGVuID0gZG9tYWluLmxlbmd0aDtcbiAgdmFyIHJhbmdlID0gc2NhbGUucmFuZ2UoKTtcbiAgdmFyIG1pblZhbHVlID0gTWF0aC5taW4ocmFuZ2VbMF0sIHJhbmdlWzFdKSAtIEVQUztcbiAgdmFyIG1heFZhbHVlID0gTWF0aC5tYXgocmFuZ2VbMF0sIHJhbmdlWzFdKSArIEVQUztcbiAgdmFyIGZpcnN0ID0gc2NhbGUoZG9tYWluWzBdKTtcbiAgdmFyIGxhc3QgPSBzY2FsZShkb21haW5bbGVuIC0gMV0pO1xuICBpZiAoZmlyc3QgPCBtaW5WYWx1ZSB8fCBmaXJzdCA+IG1heFZhbHVlIHx8IGxhc3QgPCBtaW5WYWx1ZSB8fCBsYXN0ID4gbWF4VmFsdWUpIHtcbiAgICBzY2FsZS5kb21haW4oW2RvbWFpblswXSwgZG9tYWluW2xlbiAtIDFdXSk7XG4gIH1cbn07XG5cbi8qKlxuICogQm90aCB2YWx1ZSBhbmQgZG9tYWluIGFyZSB0dXBsZXMgb2YgdHdvIG51bWJlcnNcbiAqIC0gYnV0IHRoZSB0eXBlIHN0YXlzIGFzIGFycmF5IG9mIG51bWJlcnMgdW50aWwgd2UgaGF2ZSBiZXR0ZXIgc3VwcG9ydCBpbiByZXN0IG9mIHRoZSBhcHBcbiAqIEBwYXJhbSB2YWx1ZSBpbnB1dCB0aGF0IHdpbGwgYmUgdHJ1bmNhdGVkXG4gKiBAcGFyYW0gZG9tYWluIGJvdW5kYXJpZXNcbiAqIEByZXR1cm5zIHR1cGxlIG9mIHR3byBudW1iZXJzXG4gKi9cbmV4cG9ydCB2YXIgdHJ1bmNhdGVCeURvbWFpbiA9ICh2YWx1ZSwgZG9tYWluKSA9PiB7XG4gIGlmICghZG9tYWluIHx8IGRvbWFpbi5sZW5ndGggIT09IDIgfHwgIWlzTnVtYmVyKGRvbWFpblswXSkgfHwgIWlzTnVtYmVyKGRvbWFpblsxXSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgdmFyIG1pblZhbHVlID0gTWF0aC5taW4oZG9tYWluWzBdLCBkb21haW5bMV0pO1xuICB2YXIgbWF4VmFsdWUgPSBNYXRoLm1heChkb21haW5bMF0sIGRvbWFpblsxXSk7XG4gIHZhciByZXN1bHQgPSBbdmFsdWVbMF0sIHZhbHVlWzFdXTtcbiAgaWYgKCFpc051bWJlcih2YWx1ZVswXSkgfHwgdmFsdWVbMF0gPCBtaW5WYWx1ZSkge1xuICAgIHJlc3VsdFswXSA9IG1pblZhbHVlO1xuICB9XG4gIGlmICghaXNOdW1iZXIodmFsdWVbMV0pIHx8IHZhbHVlWzFdID4gbWF4VmFsdWUpIHtcbiAgICByZXN1bHRbMV0gPSBtYXhWYWx1ZTtcbiAgfVxuICBpZiAocmVzdWx0WzBdID4gbWF4VmFsdWUpIHtcbiAgICByZXN1bHRbMF0gPSBtYXhWYWx1ZTtcbiAgfVxuICBpZiAocmVzdWx0WzFdIDwgbWluVmFsdWUpIHtcbiAgICByZXN1bHRbMV0gPSBtaW5WYWx1ZTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufTtcblxuLyoqXG4gKiBTdGFja3MgYWxsIHBvc2l0aXZlIG51bWJlcnMgYWJvdmUgemVybyBhbmQgYWxsIG5lZ2F0aXZlIG51bWJlcnMgYmVsb3cgemVyby5cbiAqXG4gKiBJZiBhbGwgdmFsdWVzIGluIHRoZSBzZXJpZXMgYXJlIHBvc2l0aXZlIHRoZW4gdGhpcyBiZWhhdmVzIHRoZSBzYW1lIGFzICdub25lJyBzdGFja2VyLlxuICpcbiAqIEBwYXJhbSB7QXJyYXl9IHNlcmllcyBmcm9tIGQzLXNoYXBlIFN0YWNrXG4gKiBAcmV0dXJuIHtBcnJheX0gc2VyaWVzIHdpdGggYXBwbGllZCBvZmZzZXRcbiAqL1xuZXhwb3J0IHZhciBvZmZzZXRTaWduID0gc2VyaWVzID0+IHtcbiAgdmFyIG4gPSBzZXJpZXMubGVuZ3RoO1xuICBpZiAobiA8PSAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAodmFyIGogPSAwLCBtID0gc2VyaWVzWzBdLmxlbmd0aDsgaiA8IG07ICsraikge1xuICAgIHZhciBwb3NpdGl2ZSA9IDA7XG4gICAgdmFyIG5lZ2F0aXZlID0gMDtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IG47ICsraSkge1xuICAgICAgdmFyIHZhbHVlID0gaXNOYW4oc2VyaWVzW2ldW2pdWzFdKSA/IHNlcmllc1tpXVtqXVswXSA6IHNlcmllc1tpXVtqXVsxXTtcblxuICAgICAgLyogZXNsaW50LWRpc2FibGUgcHJlZmVyLWRlc3RydWN0dXJpbmcsIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgICBpZiAodmFsdWUgPj0gMCkge1xuICAgICAgICBzZXJpZXNbaV1bal1bMF0gPSBwb3NpdGl2ZTtcbiAgICAgICAgc2VyaWVzW2ldW2pdWzFdID0gcG9zaXRpdmUgKyB2YWx1ZTtcbiAgICAgICAgcG9zaXRpdmUgPSBzZXJpZXNbaV1bal1bMV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXJpZXNbaV1bal1bMF0gPSBuZWdhdGl2ZTtcbiAgICAgICAgc2VyaWVzW2ldW2pdWzFdID0gbmVnYXRpdmUgKyB2YWx1ZTtcbiAgICAgICAgbmVnYXRpdmUgPSBzZXJpZXNbaV1bal1bMV07XG4gICAgICB9XG4gICAgICAvKiBlc2xpbnQtZW5hYmxlIHByZWZlci1kZXN0cnVjdHVyaW5nLCBuby1wYXJhbS1yZWFzc2lnbiAqL1xuICAgIH1cbiAgfVxufTtcblxuLyoqXG4gKiBSZXBsYWNlcyBhbGwgbmVnYXRpdmUgdmFsdWVzIHdpdGggemVybyB3aGVuIHN0YWNraW5nIGRhdGEuXG4gKlxuICogSWYgYWxsIHZhbHVlcyBpbiB0aGUgc2VyaWVzIGFyZSBwb3NpdGl2ZSB0aGVuIHRoaXMgYmVoYXZlcyB0aGUgc2FtZSBhcyAnbm9uZScgc3RhY2tlci5cbiAqXG4gKiBAcGFyYW0ge0FycmF5fSBzZXJpZXMgZnJvbSBkMy1zaGFwZSBTdGFja1xuICogQHJldHVybiB7QXJyYXl9IHNlcmllcyB3aXRoIGFwcGxpZWQgb2Zmc2V0XG4gKi9cbmV4cG9ydCB2YXIgb2Zmc2V0UG9zaXRpdmUgPSBzZXJpZXMgPT4ge1xuICB2YXIgbiA9IHNlcmllcy5sZW5ndGg7XG4gIGlmIChuIDw9IDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yICh2YXIgaiA9IDAsIG0gPSBzZXJpZXNbMF0ubGVuZ3RoOyBqIDwgbTsgKytqKSB7XG4gICAgdmFyIHBvc2l0aXZlID0gMDtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IG47ICsraSkge1xuICAgICAgdmFyIHZhbHVlID0gaXNOYW4oc2VyaWVzW2ldW2pdWzFdKSA/IHNlcmllc1tpXVtqXVswXSA6IHNlcmllc1tpXVtqXVsxXTtcblxuICAgICAgLyogZXNsaW50LWRpc2FibGUgcHJlZmVyLWRlc3RydWN0dXJpbmcsIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgICBpZiAodmFsdWUgPj0gMCkge1xuICAgICAgICBzZXJpZXNbaV1bal1bMF0gPSBwb3NpdGl2ZTtcbiAgICAgICAgc2VyaWVzW2ldW2pdWzFdID0gcG9zaXRpdmUgKyB2YWx1ZTtcbiAgICAgICAgcG9zaXRpdmUgPSBzZXJpZXNbaV1bal1bMV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXJpZXNbaV1bal1bMF0gPSAwO1xuICAgICAgICBzZXJpZXNbaV1bal1bMV0gPSAwO1xuICAgICAgfVxuICAgICAgLyogZXNsaW50LWVuYWJsZSBwcmVmZXItZGVzdHJ1Y3R1cmluZywgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICB9XG4gIH1cbn07XG5cbi8qKlxuICogRnVuY3Rpb24gdHlwZSB0byBjb21wdXRlIG9mZnNldCBmb3Igc3RhY2tlZCBkYXRhLlxuICpcbiAqIGQzLXNoYXBlIGhhcyBzb21ldGhpbmcgZmlzaHkgZ29pbmcgb24gd2l0aCBpdHMgdHlwZXMuXG4gKiBJbiBAZGVmaW5pdGVseXR5cGVkL2QzLXNoYXBlLCB0aGlzIGZ1bmN0aW9uICh0aGUgb2Zmc2V0IGFjY2Vzc29yKSBpcyB0eXBlZCBhcyBTZXJpZXM8PiA9PiB2b2lkLlxuICogSG93ZXZlciEgV2hlbiBJIGFjdHVhbGx5IG9wZW4gdGhlIHN0b3J5Ym9vayBJIGNhbiBzZWUgdGhhdCB0aGUgb2Zmc2V0IGFjY2Vzc29yIGFjdHVhbGx5IHJlY2VpdmVzIEFycmF5PFNlcmllczw+Pi5cbiAqIFRoZSBzYW1lIEkgY2FuIHNlZSBpbiB0aGUgc291cmNlIGNvZGUgaXRzZWxmOlxuICogaHR0cHM6Ly9naXRodWIuY29tL0RlZmluaXRlbHlUeXBlZC9EZWZpbml0ZWx5VHlwZWQvZGlzY3Vzc2lvbnMvNjYwNDJcbiAqIFRoYXQgb25lIHVuZm9ydHVuYXRlbHkgaGFzIG5vIHR5cGVzIGJ1dCB3ZSBjYW4gdGVsbCBpdCBwYXNzZXMgdGhyZWUtZGltZW5zaW9uYWwgYXJyYXkuXG4gKlxuICogV2hpY2ggbGVhZHMgbWUgdG8gYmVsaWV2ZSB0aGF0IGRlZmluaXRlbHl0eXBlZCBpcyB3cm9uZyBvbiB0aGlzIG9uZS5cbiAqIFRoZXJlJ3Mgb3BlbiBkaXNjdXNzaW9uIG9uIHRoaXMgdG9waWMgd2l0aG91dCBtdWNoIGF0dGVudGlvbjpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9EZWZpbml0ZWx5VHlwZWQvRGVmaW5pdGVseVR5cGVkL2Rpc2N1c3Npb25zLzY2MDQyXG4gKi9cblxudmFyIFNUQUNLX09GRlNFVF9NQVAgPSB7XG4gIHNpZ246IG9mZnNldFNpZ24sXG4gIC8vIEB0cy1leHBlY3QtZXJyb3IgZGVmaW5pdGVseXR5cGVkIHR5cGVzIGFyZSBpbmNvcnJlY3RcbiAgZXhwYW5kOiBzdGFja09mZnNldEV4cGFuZCxcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciBkZWZpbml0ZWx5dHlwZWQgdHlwZXMgYXJlIGluY29ycmVjdFxuICBub25lOiBzdGFja09mZnNldE5vbmUsXG4gIC8vIEB0cy1leHBlY3QtZXJyb3IgZGVmaW5pdGVseXR5cGVkIHR5cGVzIGFyZSBpbmNvcnJlY3RcbiAgc2lsaG91ZXR0ZTogc3RhY2tPZmZzZXRTaWxob3VldHRlLFxuICAvLyBAdHMtZXhwZWN0LWVycm9yIGRlZmluaXRlbHl0eXBlZCB0eXBlcyBhcmUgaW5jb3JyZWN0XG4gIHdpZ2dsZTogc3RhY2tPZmZzZXRXaWdnbGUsXG4gIHBvc2l0aXZlOiBvZmZzZXRQb3NpdGl2ZVxufTtcbmV4cG9ydCB2YXIgZ2V0U3RhY2tlZERhdGEgPSAoZGF0YSwgZGF0YUtleXMsIG9mZnNldFR5cGUpID0+IHtcbiAgdmFyIG9mZnNldEFjY2Vzc29yID0gU1RBQ0tfT0ZGU0VUX01BUFtvZmZzZXRUeXBlXTtcbiAgdmFyIHN0YWNrID0gc2hhcGVTdGFjaygpLmtleXMoZGF0YUtleXMpLnZhbHVlKChkLCBrZXkpID0+ICtnZXRWYWx1ZUJ5RGF0YUtleShkLCBrZXksIDApKS5vcmRlcihzdGFja09yZGVyTm9uZSlcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciBkZWZpbml0ZWx5dHlwZWQgdHlwZXMgYXJlIGluY29ycmVjdFxuICAub2Zmc2V0KG9mZnNldEFjY2Vzc29yKTtcbiAgcmV0dXJuIHN0YWNrKGRhdGEpO1xufTtcblxuLyoqXG4gKiBTdGFjayBJRHMgaW4gdGhlIGV4dGVybmFsIHByb3BzIGFsbG93IG51bWJlcnM7IGJ1dCBpbnRlcm5hbGx5IHdlIHVzZSBpdCBhcyBhbiBvYmplY3Qga2V5XG4gKiBhbmQgb2JqZWN0IGtleXMgYXJlIGFsd2F5cyBzdHJpbmdzLiBBbHNvLCBpdCB3b3VsZCBiZSBraW5kYSBjb25mdXNpbmcgaWYgc3RhY2tJZD04IGFuZCBzdGFja0lkPSc4JyB3ZXJlIGRpZmZlcmVudCBzdGFja3NcbiAqIHNvIGxldCdzIGp1c3QgZm9yY2UgYSBzdHJpbmcuXG4gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRTdGFja0lkKHB1YmxpY1N0YWNrSWQpIHtcbiAgcmV0dXJuIHB1YmxpY1N0YWNrSWQgPT0gbnVsbCA/IHVuZGVmaW5lZCA6IFN0cmluZyhwdWJsaWNTdGFja0lkKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRDYXRlQ29vcmRpbmF0ZU9mTGluZShfcmVmKSB7XG4gIHZhciB7XG4gICAgYXhpcyxcbiAgICB0aWNrcyxcbiAgICBiYW5kU2l6ZSxcbiAgICBlbnRyeSxcbiAgICBpbmRleCxcbiAgICBkYXRhS2V5XG4gIH0gPSBfcmVmO1xuICBpZiAoYXhpcy50eXBlID09PSAnY2F0ZWdvcnknKSB7XG4gICAgLy8gZmluZCBjb29yZGluYXRlIG9mIGNhdGVnb3J5IGF4aXMgYnkgdGhlIHZhbHVlIG9mIGNhdGVnb3J5XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3aHkgZG9lcyB0aGlzIHVzZSBkaXJlY3Qgb2JqZWN0IGFjY2VzcyBpbnN0ZWFkIG9mIGdldFZhbHVlQnlEYXRhS2V5P1xuICAgIGlmICghYXhpcy5hbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeSAmJiBheGlzLmRhdGFLZXkgJiYgIWlzTnVsbGlzaChlbnRyeVtheGlzLmRhdGFLZXldKSkge1xuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3aHkgZG9lcyB0aGlzIHVzZSBkaXJlY3Qgb2JqZWN0IGFjY2VzcyBpbnN0ZWFkIG9mIGdldFZhbHVlQnlEYXRhS2V5P1xuICAgICAgdmFyIG1hdGNoZWRUaWNrID0gZmluZEVudHJ5SW5BcnJheSh0aWNrcywgJ3ZhbHVlJywgZW50cnlbYXhpcy5kYXRhS2V5XSk7XG4gICAgICBpZiAobWF0Y2hlZFRpY2spIHtcbiAgICAgICAgcmV0dXJuIG1hdGNoZWRUaWNrLmNvb3JkaW5hdGUgKyBiYW5kU2l6ZSAvIDI7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aWNrc1tpbmRleF0gPyB0aWNrc1tpbmRleF0uY29vcmRpbmF0ZSArIGJhbmRTaXplIC8gMiA6IG51bGw7XG4gIH1cbiAgdmFyIHZhbHVlID0gZ2V0VmFsdWVCeURhdGFLZXkoZW50cnksICFpc051bGxpc2goZGF0YUtleSkgPyBkYXRhS2V5IDogYXhpcy5kYXRhS2V5KTtcblxuICAvLyBAdHMtZXhwZWN0LWVycm9yIGdldFZhbHVlQnlEYXRhS2V5IGRvZXMgbm90IHZhbGlkYXRlIHRoZSBvdXRwdXQgdHlwZVxuICByZXR1cm4gIWlzTnVsbGlzaCh2YWx1ZSkgPyBheGlzLnNjYWxlKHZhbHVlKSA6IG51bGw7XG59XG5leHBvcnQgdmFyIGdldENhdGVDb29yZGluYXRlT2ZCYXIgPSBfcmVmMiA9PiB7XG4gIHZhciB7XG4gICAgYXhpcyxcbiAgICB0aWNrcyxcbiAgICBvZmZzZXQsXG4gICAgYmFuZFNpemUsXG4gICAgZW50cnksXG4gICAgaW5kZXhcbiAgfSA9IF9yZWYyO1xuICBpZiAoYXhpcy50eXBlID09PSAnY2F0ZWdvcnknKSB7XG4gICAgcmV0dXJuIHRpY2tzW2luZGV4XSA/IHRpY2tzW2luZGV4XS5jb29yZGluYXRlICsgb2Zmc2V0IDogbnVsbDtcbiAgfVxuICB2YXIgdmFsdWUgPSBnZXRWYWx1ZUJ5RGF0YUtleShlbnRyeSwgYXhpcy5kYXRhS2V5LCBheGlzLnNjYWxlLmRvbWFpbigpW2luZGV4XSk7XG4gIHJldHVybiAhaXNOdWxsaXNoKHZhbHVlKSA/IGF4aXMuc2NhbGUodmFsdWUpIC0gYmFuZFNpemUgLyAyICsgb2Zmc2V0IDogbnVsbDtcbn07XG5leHBvcnQgdmFyIGdldEJhc2VWYWx1ZU9mQmFyID0gX3JlZjMgPT4ge1xuICB2YXIge1xuICAgIG51bWVyaWNBeGlzXG4gIH0gPSBfcmVmMztcbiAgdmFyIGRvbWFpbiA9IG51bWVyaWNBeGlzLnNjYWxlLmRvbWFpbigpO1xuICBpZiAobnVtZXJpY0F4aXMudHlwZSA9PT0gJ251bWJlcicpIHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIHR5cGUgbnVtYmVyIG1lYW5zIHRoZSBkb21haW4gaGFzIG51bWJlcnMgaW4gaXQgYnV0IHRoaXMgcmVsYXRpb25zaGlwIGlzIG5vdCBrbm93biB0byB0eXBlc2NyaXB0XG4gICAgdmFyIG1pblZhbHVlID0gTWF0aC5taW4oZG9tYWluWzBdLCBkb21haW5bMV0pO1xuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgdHlwZSBudW1iZXIgbWVhbnMgdGhlIGRvbWFpbiBoYXMgbnVtYmVycyBpbiBpdCBidXQgdGhpcyByZWxhdGlvbnNoaXAgaXMgbm90IGtub3duIHRvIHR5cGVzY3JpcHRcbiAgICB2YXIgbWF4VmFsdWUgPSBNYXRoLm1heChkb21haW5bMF0sIGRvbWFpblsxXSk7XG4gICAgaWYgKG1pblZhbHVlIDw9IDAgJiYgbWF4VmFsdWUgPj0gMCkge1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIGlmIChtYXhWYWx1ZSA8IDApIHtcbiAgICAgIHJldHVybiBtYXhWYWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG1pblZhbHVlO1xuICB9XG4gIHJldHVybiBkb21haW5bMF07XG59O1xudmFyIGdldERvbWFpbk9mU2luZ2xlID0gZGF0YSA9PiB7XG4gIHZhciBmbGF0ID0gZGF0YS5mbGF0KDIpLmZpbHRlcihpc051bWJlcik7XG4gIHJldHVybiBbTWF0aC5taW4oLi4uZmxhdCksIE1hdGgubWF4KC4uLmZsYXQpXTtcbn07XG52YXIgbWFrZURvbWFpbkZpbml0ZSA9IGRvbWFpbiA9PiB7XG4gIHJldHVybiBbZG9tYWluWzBdID09PSBJbmZpbml0eSA/IDAgOiBkb21haW5bMF0sIGRvbWFpblsxXSA9PT0gLUluZmluaXR5ID8gMCA6IGRvbWFpblsxXV07XG59O1xuZXhwb3J0IHZhciBnZXREb21haW5PZlN0YWNrR3JvdXBzID0gKHN0YWNrR3JvdXBzLCBzdGFydEluZGV4LCBlbmRJbmRleCkgPT4ge1xuICBpZiAoc3RhY2tHcm91cHMgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIG1ha2VEb21haW5GaW5pdGUoT2JqZWN0LmtleXMoc3RhY2tHcm91cHMpLnJlZHVjZSgocmVzdWx0LCBzdGFja0lkKSA9PiB7XG4gICAgdmFyIGdyb3VwID0gc3RhY2tHcm91cHNbc3RhY2tJZF07XG4gICAgdmFyIHtcbiAgICAgIHN0YWNrZWREYXRhXG4gICAgfSA9IGdyb3VwO1xuICAgIHZhciBkb21haW4gPSBzdGFja2VkRGF0YS5yZWR1Y2UoKHJlcywgZW50cnkpID0+IHtcbiAgICAgIHZhciBzbGljZWQgPSBnZXRTbGljZWQoZW50cnksIHN0YXJ0SW5kZXgsIGVuZEluZGV4KTtcbiAgICAgIHZhciBzID0gZ2V0RG9tYWluT2ZTaW5nbGUoc2xpY2VkKTtcbiAgICAgIHJldHVybiBbTWF0aC5taW4ocmVzWzBdLCBzWzBdKSwgTWF0aC5tYXgocmVzWzFdLCBzWzFdKV07XG4gICAgfSwgW0luZmluaXR5LCAtSW5maW5pdHldKTtcbiAgICByZXR1cm4gW01hdGgubWluKGRvbWFpblswXSwgcmVzdWx0WzBdKSwgTWF0aC5tYXgoZG9tYWluWzFdLCByZXN1bHRbMV0pXTtcbiAgfSwgW0luZmluaXR5LCAtSW5maW5pdHldKSk7XG59O1xuZXhwb3J0IHZhciBNSU5fVkFMVUVfUkVHID0gL15kYXRhTWluW1xcc10qLVtcXHNdKihbMC05XSsoWy5dezF9WzAtOV0rKXswLDF9KSQvO1xuZXhwb3J0IHZhciBNQVhfVkFMVUVfUkVHID0gL15kYXRhTWF4W1xcc10qXFwrW1xcc10qKFswLTldKyhbLl17MX1bMC05XSspezAsMX0pJC87XG5cbi8qKlxuICogQ2FsY3VsYXRlIHRoZSBzaXplIGJldHdlZW4gdHdvIGNhdGVnb3J5XG4gKiBAcGFyYW0gIHtPYmplY3R9IGF4aXMgIFRoZSBvcHRpb25zIG9mIGF4aXNcbiAqIEBwYXJhbSAge0FycmF5fSAgdGlja3MgVGhlIHRpY2tzIG9mIGF4aXNcbiAqIEBwYXJhbSAge0Jvb2xlYW59IGlzQmFyIGlmIGl0ZW1zIGluIGF4aXMgYXJlIGJhcnNcbiAqIEByZXR1cm4ge051bWJlcn0gU2l6ZVxuICovXG5leHBvcnQgdmFyIGdldEJhbmRTaXplT2ZBeGlzID0gKGF4aXMsIHRpY2tzLCBpc0JhcikgPT4ge1xuICBpZiAoYXhpcyAmJiBheGlzLnNjYWxlICYmIGF4aXMuc2NhbGUuYmFuZHdpZHRoKSB7XG4gICAgdmFyIGJhbmRXaWR0aCA9IGF4aXMuc2NhbGUuYmFuZHdpZHRoKCk7XG4gICAgaWYgKCFpc0JhciB8fCBiYW5kV2lkdGggPiAwKSB7XG4gICAgICByZXR1cm4gYmFuZFdpZHRoO1xuICAgIH1cbiAgfVxuICBpZiAoYXhpcyAmJiB0aWNrcyAmJiB0aWNrcy5sZW5ndGggPj0gMikge1xuICAgIHZhciBvcmRlcmVkVGlja3MgPSBzb3J0QnkodGlja3MsIG8gPT4gby5jb29yZGluYXRlKTtcbiAgICB2YXIgYmFuZFNpemUgPSBJbmZpbml0eTtcbiAgICBmb3IgKHZhciBpID0gMSwgbGVuID0gb3JkZXJlZFRpY2tzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICB2YXIgY3VyID0gb3JkZXJlZFRpY2tzW2ldO1xuICAgICAgdmFyIHByZXYgPSBvcmRlcmVkVGlja3NbaSAtIDFdO1xuICAgICAgYmFuZFNpemUgPSBNYXRoLm1pbigoY3VyLmNvb3JkaW5hdGUgfHwgMCkgLSAocHJldi5jb29yZGluYXRlIHx8IDApLCBiYW5kU2l6ZSk7XG4gICAgfVxuICAgIHJldHVybiBiYW5kU2l6ZSA9PT0gSW5maW5pdHkgPyAwIDogYmFuZFNpemU7XG4gIH1cbiAgcmV0dXJuIGlzQmFyID8gdW5kZWZpbmVkIDogMDtcbn07XG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9vbHRpcEVudHJ5KF9yZWY0KSB7XG4gIHZhciB7XG4gICAgdG9vbHRpcEVudHJ5U2V0dGluZ3MsXG4gICAgZGF0YUtleSxcbiAgICBwYXlsb2FkLFxuICAgIHZhbHVlLFxuICAgIG5hbWVcbiAgfSA9IF9yZWY0O1xuICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCB0b29sdGlwRW50cnlTZXR0aW5ncyksIHt9LCB7XG4gICAgZGF0YUtleSxcbiAgICBwYXlsb2FkLFxuICAgIHZhbHVlLFxuICAgIG5hbWVcbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9vbHRpcE5hbWVQcm9wKG5hbWVGcm9tSXRlbSwgZGF0YUtleSkge1xuICBpZiAobmFtZUZyb21JdGVtKSB7XG4gICAgcmV0dXJuIFN0cmluZyhuYW1lRnJvbUl0ZW0pO1xuICB9XG4gIGlmICh0eXBlb2YgZGF0YUtleSA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZGF0YUtleTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGluUmFuZ2UoeCwgeSwgbGF5b3V0LCBwb2xhclZpZXdCb3gsIG9mZnNldCkge1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcgfHwgbGF5b3V0ID09PSAndmVydGljYWwnKSB7XG4gICAgdmFyIGlzSW5SYW5nZSA9IHggPj0gb2Zmc2V0LmxlZnQgJiYgeCA8PSBvZmZzZXQubGVmdCArIG9mZnNldC53aWR0aCAmJiB5ID49IG9mZnNldC50b3AgJiYgeSA8PSBvZmZzZXQudG9wICsgb2Zmc2V0LmhlaWdodDtcbiAgICByZXR1cm4gaXNJblJhbmdlID8ge1xuICAgICAgeCxcbiAgICAgIHlcbiAgICB9IDogbnVsbDtcbiAgfVxuICBpZiAocG9sYXJWaWV3Qm94KSB7XG4gICAgcmV0dXJuIGluUmFuZ2VPZlNlY3Rvcih7XG4gICAgICB4LFxuICAgICAgeVxuICAgIH0sIHBvbGFyVmlld0JveCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5leHBvcnQgdmFyIGdldEFjdGl2ZUNvb3JkaW5hdGUgPSAobGF5b3V0LCB0b29sdGlwVGlja3MsIGFjdGl2ZUluZGV4LCByYW5nZU9iaikgPT4ge1xuICB2YXIgZW50cnkgPSB0b29sdGlwVGlja3MuZmluZCh0aWNrID0+IHRpY2sgJiYgdGljay5pbmRleCA9PT0gYWN0aXZlSW5kZXgpO1xuICBpZiAoZW50cnkpIHtcbiAgICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IGVudHJ5LmNvb3JkaW5hdGUsXG4gICAgICAgIHk6IHJhbmdlT2JqLnlcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChsYXlvdXQgPT09ICd2ZXJ0aWNhbCcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IHJhbmdlT2JqLngsXG4gICAgICAgIHk6IGVudHJ5LmNvb3JkaW5hdGVcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChsYXlvdXQgPT09ICdjZW50cmljJykge1xuICAgICAgdmFyIF9hbmdsZSA9IGVudHJ5LmNvb3JkaW5hdGU7XG4gICAgICB2YXIge1xuICAgICAgICByYWRpdXM6IF9yYWRpdXNcbiAgICAgIH0gPSByYW5nZU9iajtcbiAgICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcmFuZ2VPYmopLCBwb2xhclRvQ2FydGVzaWFuKHJhbmdlT2JqLmN4LCByYW5nZU9iai5jeSwgX3JhZGl1cywgX2FuZ2xlKSksIHt9LCB7XG4gICAgICAgIGFuZ2xlOiBfYW5nbGUsXG4gICAgICAgIHJhZGl1czogX3JhZGl1c1xuICAgICAgfSk7XG4gICAgfVxuICAgIHZhciByYWRpdXMgPSBlbnRyeS5jb29yZGluYXRlO1xuICAgIHZhciB7XG4gICAgICBhbmdsZVxuICAgIH0gPSByYW5nZU9iajtcbiAgICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHJhbmdlT2JqKSwgcG9sYXJUb0NhcnRlc2lhbihyYW5nZU9iai5jeCwgcmFuZ2VPYmouY3ksIHJhZGl1cywgYW5nbGUpKSwge30sIHtcbiAgICAgIGFuZ2xlLFxuICAgICAgcmFkaXVzXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4OiAwLFxuICAgIHk6IDBcbiAgfTtcbn07XG5leHBvcnQgdmFyIGNhbGN1bGF0ZVRvb2x0aXBQb3MgPSAocmFuZ2VPYmosIGxheW91dCkgPT4ge1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICByZXR1cm4gcmFuZ2VPYmoueDtcbiAgfVxuICBpZiAobGF5b3V0ID09PSAndmVydGljYWwnKSB7XG4gICAgcmV0dXJuIHJhbmdlT2JqLnk7XG4gIH1cbiAgaWYgKGxheW91dCA9PT0gJ2NlbnRyaWMnKSB7XG4gICAgcmV0dXJuIHJhbmdlT2JqLmFuZ2xlO1xuICB9XG4gIHJldHVybiByYW5nZU9iai5yYWRpdXM7XG59OyIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5pbXBvcnQgeyBzZWxlY3RMZWdlbmRTZXR0aW5ncywgc2VsZWN0TGVnZW5kU2l6ZSB9IGZyb20gJy4vbGVnZW5kU2VsZWN0b3JzJztcbmltcG9ydCB7IGFwcGVuZE9mZnNldE9mTGVnZW5kIH0gZnJvbSAnLi4vLi4vdXRpbC9DaGFydFV0aWxzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0SGVpZ2h0LCBzZWxlY3RDaGFydFdpZHRoLCBzZWxlY3RNYXJnaW4gfSBmcm9tICcuL2NvbnRhaW5lclNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RBbGxYQXhlcywgc2VsZWN0QWxsWUF4ZXMgfSBmcm9tICcuL3NlbGVjdEFsbEF4ZXMnO1xuaW1wb3J0IHsgREVGQVVMVF9ZX0FYSVNfV0lEVEggfSBmcm9tICcuLi8uLi91dGlsL0NvbnN0YW50cyc7XG5leHBvcnQgdmFyIHNlbGVjdEJydXNoSGVpZ2h0ID0gc3RhdGUgPT4gc3RhdGUuYnJ1c2guaGVpZ2h0O1xuZnVuY3Rpb24gc2VsZWN0TGVmdEF4ZXNPZmZzZXQoc3RhdGUpIHtcbiAgdmFyIHlBeGVzID0gc2VsZWN0QWxsWUF4ZXMoc3RhdGUpO1xuICByZXR1cm4geUF4ZXMucmVkdWNlKChyZXN1bHQsIGVudHJ5KSA9PiB7XG4gICAgaWYgKGVudHJ5Lm9yaWVudGF0aW9uID09PSAnbGVmdCcgJiYgIWVudHJ5Lm1pcnJvciAmJiAhZW50cnkuaGlkZSkge1xuICAgICAgdmFyIHdpZHRoID0gdHlwZW9mIGVudHJ5LndpZHRoID09PSAnbnVtYmVyJyA/IGVudHJ5LndpZHRoIDogREVGQVVMVF9ZX0FYSVNfV0lEVEg7XG4gICAgICByZXR1cm4gcmVzdWx0ICsgd2lkdGg7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH0sIDApO1xufVxuZnVuY3Rpb24gc2VsZWN0UmlnaHRBeGVzT2Zmc2V0KHN0YXRlKSB7XG4gIHZhciB5QXhlcyA9IHNlbGVjdEFsbFlBeGVzKHN0YXRlKTtcbiAgcmV0dXJuIHlBeGVzLnJlZHVjZSgocmVzdWx0LCBlbnRyeSkgPT4ge1xuICAgIGlmIChlbnRyeS5vcmllbnRhdGlvbiA9PT0gJ3JpZ2h0JyAmJiAhZW50cnkubWlycm9yICYmICFlbnRyeS5oaWRlKSB7XG4gICAgICB2YXIgd2lkdGggPSB0eXBlb2YgZW50cnkud2lkdGggPT09ICdudW1iZXInID8gZW50cnkud2lkdGggOiBERUZBVUxUX1lfQVhJU19XSURUSDtcbiAgICAgIHJldHVybiByZXN1bHQgKyB3aWR0aDtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSwgMCk7XG59XG5mdW5jdGlvbiBzZWxlY3RUb3BBeGVzT2Zmc2V0KHN0YXRlKSB7XG4gIHZhciB4QXhlcyA9IHNlbGVjdEFsbFhBeGVzKHN0YXRlKTtcbiAgcmV0dXJuIHhBeGVzLnJlZHVjZSgocmVzdWx0LCBlbnRyeSkgPT4ge1xuICAgIGlmIChlbnRyeS5vcmllbnRhdGlvbiA9PT0gJ3RvcCcgJiYgIWVudHJ5Lm1pcnJvciAmJiAhZW50cnkuaGlkZSkge1xuICAgICAgcmV0dXJuIHJlc3VsdCArIGVudHJ5LmhlaWdodDtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSwgMCk7XG59XG5mdW5jdGlvbiBzZWxlY3RCb3R0b21BeGVzT2Zmc2V0KHN0YXRlKSB7XG4gIHZhciB4QXhlcyA9IHNlbGVjdEFsbFhBeGVzKHN0YXRlKTtcbiAgcmV0dXJuIHhBeGVzLnJlZHVjZSgocmVzdWx0LCBlbnRyeSkgPT4ge1xuICAgIGlmIChlbnRyeS5vcmllbnRhdGlvbiA9PT0gJ2JvdHRvbScgJiYgIWVudHJ5Lm1pcnJvciAmJiAhZW50cnkuaGlkZSkge1xuICAgICAgcmV0dXJuIHJlc3VsdCArIGVudHJ5LmhlaWdodDtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSwgMCk7XG59XG5cbi8qKlxuICogRm9yIGludGVybmFsIHVzZSBvbmx5LlxuICpcbiAqIEBwYXJhbSByb290IHN0YXRlXG4gKiBAcmV0dXJuIENoYXJ0T2Zmc2V0SW50ZXJuYWxcbiAqL1xuZXhwb3J0IHZhciBzZWxlY3RDaGFydE9mZnNldEludGVybmFsID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0V2lkdGgsIHNlbGVjdENoYXJ0SGVpZ2h0LCBzZWxlY3RNYXJnaW4sIHNlbGVjdEJydXNoSGVpZ2h0LCBzZWxlY3RMZWZ0QXhlc09mZnNldCwgc2VsZWN0UmlnaHRBeGVzT2Zmc2V0LCBzZWxlY3RUb3BBeGVzT2Zmc2V0LCBzZWxlY3RCb3R0b21BeGVzT2Zmc2V0LCBzZWxlY3RMZWdlbmRTZXR0aW5ncywgc2VsZWN0TGVnZW5kU2l6ZV0sIChjaGFydFdpZHRoLCBjaGFydEhlaWdodCwgbWFyZ2luLCBicnVzaEhlaWdodCwgbGVmdEF4ZXNPZmZzZXQsIHJpZ2h0QXhlc09mZnNldCwgdG9wQXhlc09mZnNldCwgYm90dG9tQXhlc09mZnNldCwgbGVnZW5kU2V0dGluZ3MsIGxlZ2VuZFNpemUpID0+IHtcbiAgdmFyIG9mZnNldEggPSB7XG4gICAgbGVmdDogKG1hcmdpbi5sZWZ0IHx8IDApICsgbGVmdEF4ZXNPZmZzZXQsXG4gICAgcmlnaHQ6IChtYXJnaW4ucmlnaHQgfHwgMCkgKyByaWdodEF4ZXNPZmZzZXRcbiAgfTtcbiAgdmFyIG9mZnNldFYgPSB7XG4gICAgdG9wOiAobWFyZ2luLnRvcCB8fCAwKSArIHRvcEF4ZXNPZmZzZXQsXG4gICAgYm90dG9tOiAobWFyZ2luLmJvdHRvbSB8fCAwKSArIGJvdHRvbUF4ZXNPZmZzZXRcbiAgfTtcbiAgdmFyIG9mZnNldCA9IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgb2Zmc2V0ViksIG9mZnNldEgpO1xuICB2YXIgYnJ1c2hCb3R0b20gPSBvZmZzZXQuYm90dG9tO1xuICBvZmZzZXQuYm90dG9tICs9IGJydXNoSGVpZ2h0O1xuICBvZmZzZXQgPSBhcHBlbmRPZmZzZXRPZkxlZ2VuZChvZmZzZXQsIGxlZ2VuZFNldHRpbmdzLCBsZWdlbmRTaXplKTtcbiAgdmFyIG9mZnNldFdpZHRoID0gY2hhcnRXaWR0aCAtIG9mZnNldC5sZWZ0IC0gb2Zmc2V0LnJpZ2h0O1xuICB2YXIgb2Zmc2V0SGVpZ2h0ID0gY2hhcnRIZWlnaHQgLSBvZmZzZXQudG9wIC0gb2Zmc2V0LmJvdHRvbTtcbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7XG4gICAgYnJ1c2hCb3R0b21cbiAgfSwgb2Zmc2V0KSwge30sIHtcbiAgICAvLyBuZXZlciByZXR1cm4gbmVnYXRpdmUgdmFsdWVzIGZvciBoZWlnaHQgYW5kIHdpZHRoXG4gICAgd2lkdGg6IE1hdGgubWF4KG9mZnNldFdpZHRoLCAwKSxcbiAgICBoZWlnaHQ6IE1hdGgubWF4KG9mZnNldEhlaWdodCwgMClcbiAgfSk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnRWaWV3Qm94ID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCwgb2Zmc2V0ID0+ICh7XG4gIHg6IG9mZnNldC5sZWZ0LFxuICB5OiBvZmZzZXQudG9wLFxuICB3aWR0aDogb2Zmc2V0LndpZHRoLFxuICBoZWlnaHQ6IG9mZnNldC5oZWlnaHRcbn0pKTtcbmV4cG9ydCB2YXIgc2VsZWN0QXhpc1ZpZXdCb3ggPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RDaGFydFdpZHRoLCBzZWxlY3RDaGFydEhlaWdodCwgKHdpZHRoLCBoZWlnaHQpID0+ICh7XG4gIHg6IDAsXG4gIHk6IDAsXG4gIHdpZHRoLFxuICBoZWlnaHRcbn0pKTsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IHNlbGVjdEF4aXNTZXR0aW5ncyB9IGZyb20gJy4vYXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc1R5cGUgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBBeGlzVHlwZSc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc0lkIH0gZnJvbSAnLi9zZWxlY3RUb29sdGlwQXhpc0lkJztcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcEF4aXMgPSBzdGF0ZSA9PiB7XG4gIHZhciBheGlzVHlwZSA9IHNlbGVjdFRvb2x0aXBBeGlzVHlwZShzdGF0ZSk7XG4gIHZhciBheGlzSWQgPSBzZWxlY3RUb29sdGlwQXhpc0lkKHN0YXRlKTtcbiAgcmV0dXJuIHNlbGVjdEF4aXNTZXR0aW5ncyhzdGF0ZSwgYXhpc1R5cGUsIGF4aXNJZCk7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc0RhdGFLZXkgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEF4aXNdLCBheGlzID0+IGF4aXMgPT09IG51bGwgfHwgYXhpcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYXhpcy5kYXRhS2V5KTsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IGNvbXB1dGVTY2F0dGVyUG9pbnRzIH0gZnJvbSAnLi4vLi4vY2FydGVzaWFuL1NjYXR0ZXInO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEgfSBmcm9tICcuL2RhdGFTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0QXhpc1dpdGhTY2FsZSwgc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0sIHNlbGVjdFVuZmlsdGVyZWRDYXJ0ZXNpYW5JdGVtcywgc2VsZWN0WkF4aXNXaXRoU2NhbGUgfSBmcm9tICcuL2F4aXNTZWxlY3RvcnMnO1xudmFyIHNlbGVjdFhBeGlzV2l0aFNjYWxlID0gKHN0YXRlLCB4QXhpc0lkLCBfeUF4aXNJZCwgX3pBeGlzSWQsIF9pZCwgX2NlbGxzLCBpc1Bhbm9yYW1hKSA9PiBzZWxlY3RBeGlzV2l0aFNjYWxlKHN0YXRlLCAneEF4aXMnLCB4QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RYQXhpc1RpY2tzID0gKHN0YXRlLCB4QXhpc0lkLCBfeUF4aXNJZCwgX3pBeGlzSWQsIF9pZCwgX2NlbGxzLCBpc1Bhbm9yYW1hKSA9PiBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG52YXIgc2VsZWN0WUF4aXNXaXRoU2NhbGUgPSAoc3RhdGUsIF94QXhpc0lkLCB5QXhpc0lkLCBfekF4aXNJZCwgX2lkLCBfY2VsbHMsIGlzUGFub3JhbWEpID0+IHNlbGVjdEF4aXNXaXRoU2NhbGUoc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xudmFyIHNlbGVjdFlBeGlzVGlja3MgPSAoc3RhdGUsIF94QXhpc0lkLCB5QXhpc0lkLCBfekF4aXNJZCwgX2lkLCBfY2VsbHMsIGlzUGFub3JhbWEpID0+IHNlbGVjdFRpY2tzT2ZHcmFwaGljYWxJdGVtKHN0YXRlLCAneUF4aXMnLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RaQXhpcyA9IChzdGF0ZSwgX3hBeGlzSWQsIF95QXhpc0lkLCB6QXhpc0lkKSA9PiBzZWxlY3RaQXhpc1dpdGhTY2FsZShzdGF0ZSwgJ3pBeGlzJywgekF4aXNJZCwgZmFsc2UpO1xudmFyIHBpY2tTY2F0dGVySWQgPSAoX3N0YXRlLCBfeEF4aXNJZCwgX3lBeGlzSWQsIF96QXhpc0lkLCBpZCkgPT4gaWQ7XG52YXIgcGlja0NlbGxzID0gKF9zdGF0ZSwgX3hBeGlzSWQsIF95QXhpc0lkLCBfekF4aXNJZCwgX2lkLCBjZWxscykgPT4gY2VsbHM7XG52YXIgc2NhdHRlckNoYXJ0RGF0YVNlbGVjdG9yID0gKHN0YXRlLCB4QXhpc0lkLCB5QXhpc0lkLCBfekF4aXNJZCwgX2lkLCBfY2VsbHMsIGlzUGFub3JhbWEpID0+IHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzSWZOb3RJblBhbm9yYW1hKHN0YXRlLCB4QXhpc0lkLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RTeW5jaHJvbmlzZWRTY2F0dGVyU2V0dGluZ3MgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZENhcnRlc2lhbkl0ZW1zLCBwaWNrU2NhdHRlcklkXSwgKGdyYXBoaWNhbEl0ZW1zLCBpZCkgPT4ge1xuICByZXR1cm4gZ3JhcGhpY2FsSXRlbXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS50eXBlID09PSAnc2NhdHRlcicpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBpZCk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0U2NhdHRlclBvaW50cyA9IGNyZWF0ZVNlbGVjdG9yKFtzY2F0dGVyQ2hhcnREYXRhU2VsZWN0b3IsIHNlbGVjdFhBeGlzV2l0aFNjYWxlLCBzZWxlY3RYQXhpc1RpY2tzLCBzZWxlY3RZQXhpc1dpdGhTY2FsZSwgc2VsZWN0WUF4aXNUaWNrcywgc2VsZWN0WkF4aXMsIHNlbGVjdFN5bmNocm9uaXNlZFNjYXR0ZXJTZXR0aW5ncywgcGlja0NlbGxzXSwgKF9yZWYsIHhBeGlzLCB4QXhpc1RpY2tzLCB5QXhpcywgeUF4aXNUaWNrcywgekF4aXMsIHNjYXR0ZXJTZXR0aW5ncywgY2VsbHMpID0+IHtcbiAgdmFyIHtcbiAgICBjaGFydERhdGEsXG4gICAgZGF0YVN0YXJ0SW5kZXgsXG4gICAgZGF0YUVuZEluZGV4XG4gIH0gPSBfcmVmO1xuICBpZiAoc2NhdHRlclNldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBkaXNwbGF5ZWREYXRhO1xuICBpZiAoKHNjYXR0ZXJTZXR0aW5ncyA9PT0gbnVsbCB8fCBzY2F0dGVyU2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjYXR0ZXJTZXR0aW5ncy5kYXRhKSAhPSBudWxsICYmIHNjYXR0ZXJTZXR0aW5ncy5kYXRhLmxlbmd0aCA+IDApIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gc2NhdHRlclNldHRpbmdzLmRhdGE7XG4gIH0gZWxzZSB7XG4gICAgZGlzcGxheWVkRGF0YSA9IGNoYXJ0RGF0YSA9PT0gbnVsbCB8fCBjaGFydERhdGEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGNoYXJ0RGF0YS5zbGljZShkYXRhU3RhcnRJbmRleCwgZGF0YUVuZEluZGV4ICsgMSk7XG4gIH1cbiAgaWYgKGRpc3BsYXllZERhdGEgPT0gbnVsbCB8fCB4QXhpcyA9PSBudWxsIHx8IHlBeGlzID09IG51bGwgfHwgeEF4aXNUaWNrcyA9PSBudWxsIHx8IHlBeGlzVGlja3MgPT0gbnVsbCB8fCAoeEF4aXNUaWNrcyA9PT0gbnVsbCB8fCB4QXhpc1RpY2tzID09PSB2b2lkIDAgPyB2b2lkIDAgOiB4QXhpc1RpY2tzLmxlbmd0aCkgPT09IDAgfHwgKHlBeGlzVGlja3MgPT09IG51bGwgfHwgeUF4aXNUaWNrcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogeUF4aXNUaWNrcy5sZW5ndGgpID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gY29tcHV0ZVNjYXR0ZXJQb2ludHMoe1xuICAgIGRpc3BsYXllZERhdGEsXG4gICAgeEF4aXMsXG4gICAgeUF4aXMsXG4gICAgekF4aXMsXG4gICAgc2NhdHRlclNldHRpbmdzLFxuICAgIHhBeGlzVGlja3MsXG4gICAgeUF4aXNUaWNrcyxcbiAgICBjZWxsc1xuICB9KTtcbn0pOyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRPZmZzZXQgfSBmcm9tICcuL3NlbGVjdENoYXJ0T2Zmc2V0JztcbmltcG9ydCB7IHNlbGVjdENoYXJ0SGVpZ2h0LCBzZWxlY3RDaGFydFdpZHRoIH0gZnJvbSAnLi9jb250YWluZXJTZWxlY3RvcnMnO1xuZXhwb3J0IHZhciBzZWxlY3RQbG90QXJlYSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydE9mZnNldCwgc2VsZWN0Q2hhcnRXaWR0aCwgc2VsZWN0Q2hhcnRIZWlnaHRdLCAob2Zmc2V0LCBjaGFydFdpZHRoLCBjaGFydEhlaWdodCkgPT4ge1xuICBpZiAoIW9mZnNldCB8fCBjaGFydFdpZHRoID09IG51bGwgfHwgY2hhcnRIZWlnaHQgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4OiBvZmZzZXQubGVmdCxcbiAgICB5OiBvZmZzZXQudG9wLFxuICAgIHdpZHRoOiBNYXRoLm1heCgwLCBjaGFydFdpZHRoIC0gb2Zmc2V0LmxlZnQgLSBvZmZzZXQucmlnaHQpLFxuICAgIGhlaWdodDogTWF0aC5tYXgoMCwgY2hhcnRIZWlnaHQgLSBvZmZzZXQudG9wIC0gb2Zmc2V0LmJvdHRvbSlcbiAgfTtcbn0pOyIsImV4cG9ydCB2YXIgcGlja0F4aXNUeXBlID0gKF9zdGF0ZSwgYXhpc1R5cGUpID0+IGF4aXNUeXBlOyIsImltcG9ydCB7IGNyZWF0ZVNsaWNlIH0gZnJvbSAnQHJlZHV4anMvdG9vbGtpdCc7XG5pbXBvcnQgeyBjYXN0RHJhZnQgfSBmcm9tICdpbW1lcic7XG52YXIgaW5pdGlhbFN0YXRlID0ge1xuICByYWRpdXNBeGlzOiB7fSxcbiAgYW5nbGVBeGlzOiB7fVxufTtcbnZhciBwb2xhckF4aXNTbGljZSA9IGNyZWF0ZVNsaWNlKHtcbiAgbmFtZTogJ3BvbGFyQXhpcycsXG4gIGluaXRpYWxTdGF0ZSxcbiAgcmVkdWNlcnM6IHtcbiAgICBhZGRSYWRpdXNBeGlzKHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgIHN0YXRlLnJhZGl1c0F4aXNbYWN0aW9uLnBheWxvYWQuaWRdID0gY2FzdERyYWZ0KGFjdGlvbi5wYXlsb2FkKTtcbiAgICB9LFxuICAgIHJlbW92ZVJhZGl1c0F4aXMoc3RhdGUsIGFjdGlvbikge1xuICAgICAgZGVsZXRlIHN0YXRlLnJhZGl1c0F4aXNbYWN0aW9uLnBheWxvYWQuaWRdO1xuICAgIH0sXG4gICAgYWRkQW5nbGVBeGlzKHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgIHN0YXRlLmFuZ2xlQXhpc1thY3Rpb24ucGF5bG9hZC5pZF0gPSBjYXN0RHJhZnQoYWN0aW9uLnBheWxvYWQpO1xuICAgIH0sXG4gICAgcmVtb3ZlQW5nbGVBeGlzKHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgIGRlbGV0ZSBzdGF0ZS5hbmdsZUF4aXNbYWN0aW9uLnBheWxvYWQuaWRdO1xuICAgIH1cbiAgfVxufSk7XG5leHBvcnQgdmFyIHtcbiAgYWRkUmFkaXVzQXhpcyxcbiAgcmVtb3ZlUmFkaXVzQXhpcyxcbiAgYWRkQW5nbGVBeGlzLFxuICByZW1vdmVBbmdsZUF4aXNcbn0gPSBwb2xhckF4aXNTbGljZS5hY3Rpb25zO1xuZXhwb3J0IHZhciBwb2xhckF4aXNSZWR1Y2VyID0gcG9sYXJBeGlzU2xpY2UucmVkdWNlcjsiLCJleHBvcnQgZnVuY3Rpb24gcmVkdXhEZXZ0b29sc0pzb25TdHJpbmdpZnlSZXBsYWNlcihfa2V5LCB2YWx1ZSkge1xuICBpZiAodmFsdWUgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkge1xuICAgIHJldHVybiBcIkhUTUxFbGVtZW50IDxcIi5jb25jYXQodmFsdWUudGFnTmFtZSwgXCIgY2xhc3M9XFxcIlwiKS5jb25jYXQodmFsdWUuY2xhc3NOYW1lLCBcIlxcXCI+XCIpO1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gd2luZG93KSB7XG4gICAgcmV0dXJuICdnbG9iYWwud2luZG93JztcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59IiwiaW1wb3J0IHsgYXV0b0JhdGNoRW5oYW5jZXIsIGNvbWJpbmVSZWR1Y2VycywgY29uZmlndXJlU3RvcmUgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0JztcbmltcG9ydCB7IG9wdGlvbnNSZWR1Y2VyIH0gZnJvbSAnLi9vcHRpb25zU2xpY2UnO1xuaW1wb3J0IHsgdG9vbHRpcFJlZHVjZXIgfSBmcm9tICcuL3Rvb2x0aXBTbGljZSc7XG5pbXBvcnQgeyBjaGFydERhdGFSZWR1Y2VyIH0gZnJvbSAnLi9jaGFydERhdGFTbGljZSc7XG5pbXBvcnQgeyBjaGFydExheW91dFJlZHVjZXIgfSBmcm9tICcuL2xheW91dFNsaWNlJztcbmltcG9ydCB7IG1vdXNlQ2xpY2tNaWRkbGV3YXJlLCBtb3VzZU1vdmVNaWRkbGV3YXJlIH0gZnJvbSAnLi9tb3VzZUV2ZW50c01pZGRsZXdhcmUnO1xuaW1wb3J0IHsgcmVkdXhEZXZ0b29sc0pzb25TdHJpbmdpZnlSZXBsYWNlciB9IGZyb20gJy4vcmVkdXhEZXZ0b29sc0pzb25TdHJpbmdpZnlSZXBsYWNlcic7XG5pbXBvcnQgeyBjYXJ0ZXNpYW5BeGlzUmVkdWNlciB9IGZyb20gJy4vY2FydGVzaWFuQXhpc1NsaWNlJztcbmltcG9ydCB7IGdyYXBoaWNhbEl0ZW1zUmVkdWNlciB9IGZyb20gJy4vZ3JhcGhpY2FsSXRlbXNTbGljZSc7XG5pbXBvcnQgeyByZWZlcmVuY2VFbGVtZW50c1JlZHVjZXIgfSBmcm9tICcuL3JlZmVyZW5jZUVsZW1lbnRzU2xpY2UnO1xuaW1wb3J0IHsgYnJ1c2hSZWR1Y2VyIH0gZnJvbSAnLi9icnVzaFNsaWNlJztcbmltcG9ydCB7IGxlZ2VuZFJlZHVjZXIgfSBmcm9tICcuL2xlZ2VuZFNsaWNlJztcbmltcG9ydCB7IHJvb3RQcm9wc1JlZHVjZXIgfSBmcm9tICcuL3Jvb3RQcm9wc1NsaWNlJztcbmltcG9ydCB7IHBvbGFyQXhpc1JlZHVjZXIgfSBmcm9tICcuL3BvbGFyQXhpc1NsaWNlJztcbmltcG9ydCB7IHBvbGFyT3B0aW9uc1JlZHVjZXIgfSBmcm9tICcuL3BvbGFyT3B0aW9uc1NsaWNlJztcbmltcG9ydCB7IGtleWJvYXJkRXZlbnRzTWlkZGxld2FyZSB9IGZyb20gJy4va2V5Ym9hcmRFdmVudHNNaWRkbGV3YXJlJztcbmltcG9ydCB7IGV4dGVybmFsRXZlbnRzTWlkZGxld2FyZSB9IGZyb20gJy4vZXh0ZXJuYWxFdmVudHNNaWRkbGV3YXJlJztcbmltcG9ydCB7IHRvdWNoRXZlbnRNaWRkbGV3YXJlIH0gZnJvbSAnLi90b3VjaEV2ZW50c01pZGRsZXdhcmUnO1xuaW1wb3J0IHsgZXJyb3JCYXJSZWR1Y2VyIH0gZnJvbSAnLi9lcnJvckJhclNsaWNlJztcbmltcG9ydCB7IEdsb2JhbCB9IGZyb20gJy4uL3V0aWwvR2xvYmFsJztcbnZhciByb290UmVkdWNlciA9IGNvbWJpbmVSZWR1Y2Vycyh7XG4gIGJydXNoOiBicnVzaFJlZHVjZXIsXG4gIGNhcnRlc2lhbkF4aXM6IGNhcnRlc2lhbkF4aXNSZWR1Y2VyLFxuICBjaGFydERhdGE6IGNoYXJ0RGF0YVJlZHVjZXIsXG4gIGVycm9yQmFyczogZXJyb3JCYXJSZWR1Y2VyLFxuICBncmFwaGljYWxJdGVtczogZ3JhcGhpY2FsSXRlbXNSZWR1Y2VyLFxuICBsYXlvdXQ6IGNoYXJ0TGF5b3V0UmVkdWNlcixcbiAgbGVnZW5kOiBsZWdlbmRSZWR1Y2VyLFxuICBvcHRpb25zOiBvcHRpb25zUmVkdWNlcixcbiAgcG9sYXJBeGlzOiBwb2xhckF4aXNSZWR1Y2VyLFxuICBwb2xhck9wdGlvbnM6IHBvbGFyT3B0aW9uc1JlZHVjZXIsXG4gIHJlZmVyZW5jZUVsZW1lbnRzOiByZWZlcmVuY2VFbGVtZW50c1JlZHVjZXIsXG4gIHJvb3RQcm9wczogcm9vdFByb3BzUmVkdWNlcixcbiAgdG9vbHRpcDogdG9vbHRpcFJlZHVjZXJcbn0pO1xuZXhwb3J0IHZhciBjcmVhdGVSZWNoYXJ0c1N0b3JlID0gZnVuY3Rpb24gY3JlYXRlUmVjaGFydHNTdG9yZShwcmVsb2FkZWRTdGF0ZSkge1xuICB2YXIgY2hhcnROYW1lID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiAnQ2hhcnQnO1xuICByZXR1cm4gY29uZmlndXJlU3RvcmUoe1xuICAgIHJlZHVjZXI6IHJvb3RSZWR1Y2VyLFxuICAgIC8vIHJlZHV4LXRvb2xraXQgdjEgdHlwZXMgYXJlIHVuaGFwcHkgd2l0aCB0aGUgcHJlbG9hZGVkU3RhdGUgdHlwZS4gUmVtb3ZlIHRoZSBgYXMgYW55YCB3aGVuIGJ1bXBpbmcgdG8gdjJcbiAgICBwcmVsb2FkZWRTdGF0ZTogcHJlbG9hZGVkU3RhdGUsXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciByZWR1eC10b29sa2l0IHYxIHR5cGVzIGFyZSB1bmhhcHB5IHdpdGggdGhlIG1pZGRsZXdhcmUgYXJyYXkuIFJlbW92ZSB0aGlzIGNvbW1lbnQgd2hlbiBidW1waW5nIHRvIHYyXG4gICAgbWlkZGxld2FyZTogZ2V0RGVmYXVsdE1pZGRsZXdhcmUgPT4gZ2V0RGVmYXVsdE1pZGRsZXdhcmUoe1xuICAgICAgc2VyaWFsaXphYmxlQ2hlY2s6IGZhbHNlXG4gICAgfSkuY29uY2F0KFttb3VzZUNsaWNrTWlkZGxld2FyZS5taWRkbGV3YXJlLCBtb3VzZU1vdmVNaWRkbGV3YXJlLm1pZGRsZXdhcmUsIGtleWJvYXJkRXZlbnRzTWlkZGxld2FyZS5taWRkbGV3YXJlLCBleHRlcm5hbEV2ZW50c01pZGRsZXdhcmUubWlkZGxld2FyZSwgdG91Y2hFdmVudE1pZGRsZXdhcmUubWlkZGxld2FyZV0pLFxuICAgIC8qXG4gICAgICogSSBjYW4ndCBmaW5kIG91dCBob3cgdG8gc2F0aXNmeSB0eXBlc2NyaXB0IGhlcmUuXG4gICAgICogV2UgcmV0dXJuIGBFbmhhbmNlckFycmF5PFtTdG9yZUVuaGFuY2VyPHt9LCB7fT4sIFN0b3JlRW5oYW5jZXJdPmAgZnJvbSB0aGlzIGZ1bmN0aW9uLFxuICAgICAqIGJ1dCB0aGUgdHlwZXMgc2F5IHdlIHNob3VsZCByZXR1cm4gYEVuaGFuY2VyQXJyYXk8U3RvcmVFbmhhbmNlcjx7fSwge30+YC5cbiAgICAgKiBMb29rcyBsaWtlIGl0J3MgYmFkbHkgaW5mZXJyZWQgZ2VuZXJpY3MsIGJ1dCBpdCB3b24ndCBhbGxvdyBtZSB0byBwcm92aWRlIHRoZSBjb3JyZWN0IHR5cGUgbWFudWFsbHkgZWl0aGVyLlxuICAgICAqIFNvIGxldCdzIGp1c3QgaWdub3JlIHRoZSBlcnJvciBmb3Igbm93LlxuICAgICAqL1xuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgbWlzbWF0Y2hlZCBnZW5lcmljc1xuICAgIGVuaGFuY2VyczogZ2V0RGVmYXVsdEVuaGFuY2VycyA9PiB7XG4gICAgICB2YXIgZW5oYW5jZXJzID0gZ2V0RGVmYXVsdEVuaGFuY2VycztcbiAgICAgIGlmICh0eXBlb2YgZ2V0RGVmYXVsdEVuaGFuY2VycyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAvKlxuICAgICAgICAgKiBJbiBSVEsgdjIgdGhpcyBpcyBhbHdheXMgYSBmdW5jdGlvbiwgYnV0IGluIHYxIGl0IGlzIGFuIGFycmF5LlxuICAgICAgICAgKiBCZWNhdXNlIHdlIGhhdmUgQHR5cGVzL3JlZHV4LXRvb2xraXQgdjEgYXMgYSBkZXBlbmRlbmN5LCB0eXBlc2NyaXB0IGlzIGdvaW5nIHRvIGZsYWcgdGhpcyBhcyBhbiBlcnJvci5cbiAgICAgICAgICogV2Ugc3VwcG9ydCBib3RoIFJUSyB2MSBhbmQgdjIsIHNvIHdlIG5lZWQgdG8gZG8gdGhpcyBjaGVjay5cbiAgICAgICAgICogaHR0cHM6Ly9yZWR1eC10b29sa2l0LmpzLm9yZy91c2FnZS9taWdyYXRpbmctcnRrLTIjY29uZmlndXJlc3RvcmVlbmhhbmNlcnMtbXVzdC1iZS1hLWNhbGxiYWNrXG4gICAgICAgICAqL1xuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIFJUSyB2MiBiZWhhdmlvdXIgb24gUlRLIHYxIHR5cGVzXG4gICAgICAgIGVuaGFuY2VycyA9IGdldERlZmF1bHRFbmhhbmNlcnMoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBlbmhhbmNlcnMuY29uY2F0KGF1dG9CYXRjaEVuaGFuY2VyKHtcbiAgICAgICAgdHlwZTogJ3JhZidcbiAgICAgIH0pKTtcbiAgICB9LFxuICAgIGRldlRvb2xzOiBHbG9iYWwuZGV2VG9vbHNFbmFibGVkICYmIHtcbiAgICAgIHNlcmlhbGl6ZToge1xuICAgICAgICByZXBsYWNlcjogcmVkdXhEZXZ0b29sc0pzb25TdHJpbmdpZnlSZXBsYWNlclxuICAgICAgfSxcbiAgICAgIG5hbWU6IFwicmVjaGFydHMtXCIuY29uY2F0KGNoYXJ0TmFtZSlcbiAgICB9XG4gIH0pO1xufTsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IGNvbXB1dGVMaW5lUG9pbnRzIH0gZnJvbSAnLi4vLi4vY2FydGVzaWFuL0xpbmUnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEgfSBmcm9tICcuL2RhdGFTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBzZWxlY3RBeGlzV2l0aFNjYWxlLCBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbSwgc2VsZWN0VW5maWx0ZXJlZENhcnRlc2lhbkl0ZW1zIH0gZnJvbSAnLi9heGlzU2VsZWN0b3JzJztcbmltcG9ydCB7IGdldEJhbmRTaXplT2ZBeGlzLCBpc0NhdGVnb3JpY2FsQXhpcyB9IGZyb20gJy4uLy4uL3V0aWwvQ2hhcnRVdGlscyc7XG52YXIgc2VsZWN0WEF4aXNXaXRoU2NhbGUgPSAoc3RhdGUsIHhBeGlzSWQsIF95QXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiBzZWxlY3RBeGlzV2l0aFNjYWxlKHN0YXRlLCAneEF4aXMnLCB4QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RYQXhpc1RpY2tzID0gKHN0YXRlLCB4QXhpc0lkLCBfeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0oc3RhdGUsICd4QXhpcycsIHhBeGlzSWQsIGlzUGFub3JhbWEpO1xudmFyIHNlbGVjdFlBeGlzV2l0aFNjYWxlID0gKHN0YXRlLCBfeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gc2VsZWN0QXhpc1dpdGhTY2FsZShzdGF0ZSwgJ3lBeGlzJywgeUF4aXNJZCwgaXNQYW5vcmFtYSk7XG52YXIgc2VsZWN0WUF4aXNUaWNrcyA9IChzdGF0ZSwgX3hBeGlzSWQsIHlBeGlzSWQsIGlzUGFub3JhbWEpID0+IHNlbGVjdFRpY2tzT2ZHcmFwaGljYWxJdGVtKHN0YXRlLCAneUF4aXMnLCB5QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RCYW5kU2l6ZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0WEF4aXNXaXRoU2NhbGUsIHNlbGVjdFlBeGlzV2l0aFNjYWxlLCBzZWxlY3RYQXhpc1RpY2tzLCBzZWxlY3RZQXhpc1RpY2tzXSwgKGxheW91dCwgeEF4aXMsIHlBeGlzLCB4QXhpc1RpY2tzLCB5QXhpc1RpY2tzKSA9PiB7XG4gIGlmIChpc0NhdGVnb3JpY2FsQXhpcyhsYXlvdXQsICd4QXhpcycpKSB7XG4gICAgcmV0dXJuIGdldEJhbmRTaXplT2ZBeGlzKHhBeGlzLCB4QXhpc1RpY2tzLCBmYWxzZSk7XG4gIH1cbiAgcmV0dXJuIGdldEJhbmRTaXplT2ZBeGlzKHlBeGlzLCB5QXhpc1RpY2tzLCBmYWxzZSk7XG59KTtcbnZhciBwaWNrTGluZUlkID0gKF9zdGF0ZSwgX3hBeGlzSWQsIF95QXhpc0lkLCBfaXNQYW5vcmFtYSwgaWQpID0+IGlkO1xuZnVuY3Rpb24gaXNMaW5lU2V0dGluZ3MoaXRlbSkge1xuICByZXR1cm4gaXRlbS50eXBlID09PSAnbGluZSc7XG59XG5cbi8qXG4gKiBUaGVyZSBpcyBhIHJhY2UgY29uZGl0aW9uIHByb2JsZW0gYmVjYXVzZSB3ZSByZWFkIHNvbWUgZGF0YSBmcm9tIHByb3BzIGFuZCBzb21lIGZyb20gdGhlIHN0YXRlLlxuICogVGhlIHN0YXRlIGlzIHVwZGF0ZWQgdGhyb3VnaCBhIGRpc3BhdGNoIGFuZCBpcyBvbmUgcmVuZGVyIGJlaGluZCxcbiAqIGFuZCBzbyB3ZSBoYXZlIHRoaXMgd2VpcmQgb25lIHRpY2sgcmVuZGVyIHdoZXJlIHRoZSBkaXNwbGF5ZWREYXRhIGluIG9uZSBzZWxlY3RvciBoYXZlIHRoZSBvbGQgZGF0YUtleVxuICogYnV0IHRoZSBuZXcgZGF0YUtleSBpbiBhbm90aGVyIHNlbGVjdG9yLlxuICpcbiAqIFNvIGhlcmUgaW5zdGVhZCBvZiByZWFkaW5nIHRoZSBkYXRhS2V5IGZyb20gdGhlIHByb3BzLCB3ZSBhbHdheXMgcmVhZCBpdCBmcm9tIHRoZSBzdGF0ZS5cbiAqL1xudmFyIHNlbGVjdFN5bmNocm9uaXNlZExpbmVTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RVbmZpbHRlcmVkQ2FydGVzaWFuSXRlbXMsIHBpY2tMaW5lSWRdLCAoZ3JhcGhpY2FsSXRlbXMsIGlkKSA9PiBncmFwaGljYWxJdGVtcy5maWx0ZXIoaXNMaW5lU2V0dGluZ3MpLmZpbmQoeCA9PiB4LmlkID09PSBpZCkpO1xuZXhwb3J0IHZhciBzZWxlY3RMaW5lUG9pbnRzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RYQXhpc1dpdGhTY2FsZSwgc2VsZWN0WUF4aXNXaXRoU2NhbGUsIHNlbGVjdFhBeGlzVGlja3MsIHNlbGVjdFlBeGlzVGlja3MsIHNlbGVjdFN5bmNocm9uaXNlZExpbmVTZXR0aW5ncywgc2VsZWN0QmFuZFNpemUsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzSWZOb3RJblBhbm9yYW1hXSwgKGxheW91dCwgeEF4aXMsIHlBeGlzLCB4QXhpc1RpY2tzLCB5QXhpc1RpY2tzLCBsaW5lU2V0dGluZ3MsIGJhbmRTaXplLCBfcmVmKSA9PiB7XG4gIHZhciB7XG4gICAgY2hhcnREYXRhLFxuICAgIGRhdGFTdGFydEluZGV4LFxuICAgIGRhdGFFbmRJbmRleFxuICB9ID0gX3JlZjtcbiAgaWYgKGxpbmVTZXR0aW5ncyA9PSBudWxsIHx8IHhBeGlzID09IG51bGwgfHwgeUF4aXMgPT0gbnVsbCB8fCB4QXhpc1RpY2tzID09IG51bGwgfHwgeUF4aXNUaWNrcyA9PSBudWxsIHx8IHhBeGlzVGlja3MubGVuZ3RoID09PSAwIHx8IHlBeGlzVGlja3MubGVuZ3RoID09PSAwIHx8IGJhbmRTaXplID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciB7XG4gICAgZGF0YUtleSxcbiAgICBkYXRhXG4gIH0gPSBsaW5lU2V0dGluZ3M7XG4gIHZhciBkaXNwbGF5ZWREYXRhO1xuICBpZiAoZGF0YSAhPSBudWxsICYmIGRhdGEubGVuZ3RoID4gMCkge1xuICAgIGRpc3BsYXllZERhdGEgPSBkYXRhO1xuICB9IGVsc2Uge1xuICAgIGRpc3BsYXllZERhdGEgPSBjaGFydERhdGEgPT09IG51bGwgfHwgY2hhcnREYXRhID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjaGFydERhdGEuc2xpY2UoZGF0YVN0YXJ0SW5kZXgsIGRhdGFFbmRJbmRleCArIDEpO1xuICB9XG4gIGlmIChkaXNwbGF5ZWREYXRhID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBjb21wdXRlTGluZVBvaW50cyh7XG4gICAgbGF5b3V0LFxuICAgIHhBeGlzLFxuICAgIHlBeGlzLFxuICAgIHhBeGlzVGlja3MsXG4gICAgeUF4aXNUaWNrcyxcbiAgICBkYXRhS2V5LFxuICAgIGJhbmRTaXplLFxuICAgIGRpc3BsYXllZERhdGFcbiAgfSk7XG59KTsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCBzb3J0QnkgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvc29ydEJ5JztcbmV4cG9ydCB2YXIgc2VsZWN0TGVnZW5kU2V0dGluZ3MgPSBzdGF0ZSA9PiBzdGF0ZS5sZWdlbmQuc2V0dGluZ3M7XG5leHBvcnQgdmFyIHNlbGVjdExlZ2VuZFNpemUgPSBzdGF0ZSA9PiBzdGF0ZS5sZWdlbmQuc2l6ZTtcbnZhciBzZWxlY3RBbGxMZWdlbmRQYXlsb2FkMkRBcnJheSA9IHN0YXRlID0+IHN0YXRlLmxlZ2VuZC5wYXlsb2FkO1xuZXhwb3J0IHZhciBzZWxlY3RMZWdlbmRQYXlsb2FkID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbExlZ2VuZFBheWxvYWQyREFycmF5LCBzZWxlY3RMZWdlbmRTZXR0aW5nc10sIChwYXlsb2FkcywgX3JlZikgPT4ge1xuICB2YXIge1xuICAgIGl0ZW1Tb3J0ZXJcbiAgfSA9IF9yZWY7XG4gIHZhciBmbGF0ID0gcGF5bG9hZHMuZmxhdCgxKTtcbiAgcmV0dXJuIGl0ZW1Tb3J0ZXIgPyBzb3J0QnkoZmxhdCwgaXRlbVNvcnRlcikgOiBmbGF0O1xufSk7IiwiZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG52YXIgUFJFRklYX0xJU1QgPSBbJ1dlYmtpdCcsICdNb3onLCAnTycsICdtcyddO1xuZXhwb3J0IHZhciBnZW5lcmF0ZVByZWZpeFN0eWxlID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gIGlmICghbmFtZSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIGNhbWVsTmFtZSA9IG5hbWUucmVwbGFjZSgvKFxcdykvLCB2ID0+IHYudG9VcHBlckNhc2UoKSk7XG4gIHZhciByZXN1bHQgPSBQUkVGSVhfTElTVC5yZWR1Y2UoKHJlcywgZW50cnkpID0+IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcmVzKSwge30sIHtcbiAgICBbZW50cnkgKyBjYW1lbE5hbWVdOiB2YWx1ZVxuICB9KSwge30pO1xuICByZXN1bHRbbmFtZV0gPSB2YWx1ZTtcbiAgcmV0dXJuIHJlc3VsdDtcbn07IiwiZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5pbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IGNvbXB1dGVSYWRhclBvaW50cyB9IGZyb20gJy4uLy4uL3BvbGFyL1JhZGFyJztcbmltcG9ydCB7IHNlbGVjdFBvbGFyQXhpc1NjYWxlLCBzZWxlY3RQb2xhckF4aXNUaWNrcyB9IGZyb20gJy4vcG9sYXJTY2FsZVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RBbmdsZUF4aXMsIHNlbGVjdFBvbGFyVmlld0JveCwgc2VsZWN0UmFkaXVzQXhpcyB9IGZyb20gJy4vcG9sYXJBeGlzU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0RGF0YUFuZEFsd2F5c0lnbm9yZUluZGV4ZXMgfSBmcm9tICcuL2RhdGFTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5pbXBvcnQgeyBnZXRCYW5kU2l6ZU9mQXhpcywgaXNDYXRlZ29yaWNhbEF4aXMgfSBmcm9tICcuLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMgfSBmcm9tICcuL3BvbGFyU2VsZWN0b3JzJztcbnZhciBzZWxlY3RSYWRpdXNBeGlzU2NhbGUgPSAoc3RhdGUsIHJhZGl1c0F4aXNJZCkgPT4gc2VsZWN0UG9sYXJBeGlzU2NhbGUoc3RhdGUsICdyYWRpdXNBeGlzJywgcmFkaXVzQXhpc0lkKTtcbnZhciBzZWxlY3RSYWRpdXNBeGlzRm9yUmFkYXIgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmFkaXVzQXhpc1NjYWxlXSwgc2NhbGUgPT4ge1xuICBpZiAoc2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzY2FsZVxuICB9O1xufSk7XG5leHBvcnQgdmFyIHNlbGVjdFJhZGl1c0F4aXNGb3JCYW5kU2l6ZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RSYWRpdXNBeGlzLCBzZWxlY3RSYWRpdXNBeGlzU2NhbGVdLCAoYXhpc1NldHRpbmdzLCBzY2FsZSkgPT4ge1xuICBpZiAoYXhpc1NldHRpbmdzID09IG51bGwgfHwgc2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYXhpc1NldHRpbmdzKSwge30sIHtcbiAgICBzY2FsZVxuICB9KTtcbn0pO1xudmFyIHNlbGVjdFJhZGl1c0F4aXNUaWNrcyA9IChzdGF0ZSwgcmFkaXVzQXhpc0lkLCBfYW5nbGVBeGlzSWQsIGlzUGFub3JhbWEpID0+IHtcbiAgcmV0dXJuIHNlbGVjdFBvbGFyQXhpc1RpY2tzKHN0YXRlLCAncmFkaXVzQXhpcycsIHJhZGl1c0F4aXNJZCwgaXNQYW5vcmFtYSk7XG59O1xudmFyIHNlbGVjdEFuZ2xlQXhpc0ZvclJhZGFyID0gKHN0YXRlLCBfcmFkaXVzQXhpc0lkLCBhbmdsZUF4aXNJZCkgPT4gc2VsZWN0QW5nbGVBeGlzKHN0YXRlLCBhbmdsZUF4aXNJZCk7XG52YXIgc2VsZWN0UG9sYXJBeGlzU2NhbGVGb3JSYWRhciA9IChzdGF0ZSwgX3JhZGl1c0F4aXNJZCwgYW5nbGVBeGlzSWQpID0+IHNlbGVjdFBvbGFyQXhpc1NjYWxlKHN0YXRlLCAnYW5nbGVBeGlzJywgYW5nbGVBeGlzSWQpO1xuZXhwb3J0IHZhciBzZWxlY3RBbmdsZUF4aXNGb3JCYW5kU2l6ZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbmdsZUF4aXNGb3JSYWRhciwgc2VsZWN0UG9sYXJBeGlzU2NhbGVGb3JSYWRhcl0sIChheGlzU2V0dGluZ3MsIHNjYWxlKSA9PiB7XG4gIGlmIChheGlzU2V0dGluZ3MgPT0gbnVsbCB8fCBzY2FsZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBheGlzU2V0dGluZ3MpLCB7fSwge1xuICAgIHNjYWxlXG4gIH0pO1xufSk7XG52YXIgc2VsZWN0QW5nbGVBeGlzVGlja3MgPSAoc3RhdGUsIF9yYWRpdXNBeGlzSWQsIGFuZ2xlQXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiB7XG4gIHJldHVybiBzZWxlY3RQb2xhckF4aXNUaWNrcyhzdGF0ZSwgJ2FuZ2xlQXhpcycsIGFuZ2xlQXhpc0lkLCBpc1Bhbm9yYW1hKTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdEFuZ2xlQXhpc1dpdGhTY2FsZUFuZFZpZXdwb3J0ID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFuZ2xlQXhpc0ZvclJhZGFyLCBzZWxlY3RQb2xhckF4aXNTY2FsZUZvclJhZGFyLCBzZWxlY3RQb2xhclZpZXdCb3hdLCAoYXhpc09wdGlvbnMsIHNjYWxlLCBwb2xhclZpZXdCb3gpID0+IHtcbiAgaWYgKHBvbGFyVmlld0JveCA9PSBudWxsIHx8IHNjYWxlID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiB7XG4gICAgc2NhbGUsXG4gICAgdHlwZTogYXhpc09wdGlvbnMudHlwZSxcbiAgICBkYXRhS2V5OiBheGlzT3B0aW9ucy5kYXRhS2V5LFxuICAgIGN4OiBwb2xhclZpZXdCb3guY3gsXG4gICAgY3k6IHBvbGFyVmlld0JveC5jeVxuICB9O1xufSk7XG52YXIgcGlja0lkID0gKF9zdGF0ZSwgX3JhZGl1c0F4aXNJZCwgX2FuZ2xlQXhpc0lkLCBfaXNQYW5vcmFtYSwgcmFkYXJJZCkgPT4gcmFkYXJJZDtcbnZhciBzZWxlY3RCYW5kU2l6ZU9mQXhpcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0UmFkaXVzQXhpc0ZvckJhbmRTaXplLCBzZWxlY3RSYWRpdXNBeGlzVGlja3MsIHNlbGVjdEFuZ2xlQXhpc0ZvckJhbmRTaXplLCBzZWxlY3RBbmdsZUF4aXNUaWNrc10sIChsYXlvdXQsIHJhZGl1c0F4aXMsIHJhZGl1c0F4aXNUaWNrcywgYW5nbGVBeGlzLCBhbmdsZUF4aXNUaWNrcykgPT4ge1xuICBpZiAoaXNDYXRlZ29yaWNhbEF4aXMobGF5b3V0LCAncmFkaXVzQXhpcycpKSB7XG4gICAgcmV0dXJuIGdldEJhbmRTaXplT2ZBeGlzKHJhZGl1c0F4aXMsIHJhZGl1c0F4aXNUaWNrcywgZmFsc2UpO1xuICB9XG4gIHJldHVybiBnZXRCYW5kU2l6ZU9mQXhpcyhhbmdsZUF4aXMsIGFuZ2xlQXhpc1RpY2tzLCBmYWxzZSk7XG59KTtcbnZhciBzZWxlY3RTeW5jaHJvbmlzZWRSYWRhckRhdGFLZXkgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMsIHBpY2tJZF0sIChncmFwaGljYWxJdGVtcywgcmFkYXJJZCkgPT4ge1xuICBpZiAoZ3JhcGhpY2FsSXRlbXMgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gRmluZCB0aGUgcmFkYXIgaXRlbSB3aXRoIHRoZSBnaXZlbiByYWRhcklkXG4gIHZhciBwZ2lzID0gZ3JhcGhpY2FsSXRlbXMuZmluZChpdGVtID0+IGl0ZW0udHlwZSA9PT0gJ3JhZGFyJyAmJiByYWRhcklkID09PSBpdGVtLmlkKTtcbiAgLy8gSWYgZm91bmQsIHJldHVybiBpdHMgZGF0YUtleVxuICByZXR1cm4gcGdpcyA9PT0gbnVsbCB8fCBwZ2lzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwZ2lzLmRhdGFLZXk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0UmFkYXJQb2ludHMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmFkaXVzQXhpc0ZvclJhZGFyLCBzZWxlY3RBbmdsZUF4aXNXaXRoU2NhbGVBbmRWaWV3cG9ydCwgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcywgc2VsZWN0U3luY2hyb25pc2VkUmFkYXJEYXRhS2V5LCBzZWxlY3RCYW5kU2l6ZU9mQXhpc10sIChyYWRpdXNBeGlzLCBhbmdsZUF4aXMsIF9yZWYsIGRhdGFLZXksIGJhbmRTaXplKSA9PiB7XG4gIHZhciB7XG4gICAgY2hhcnREYXRhLFxuICAgIGRhdGFTdGFydEluZGV4LFxuICAgIGRhdGFFbmRJbmRleFxuICB9ID0gX3JlZjtcbiAgaWYgKHJhZGl1c0F4aXMgPT0gbnVsbCB8fCBhbmdsZUF4aXMgPT0gbnVsbCB8fCBjaGFydERhdGEgPT0gbnVsbCB8fCBiYW5kU2l6ZSA9PSBudWxsIHx8IGRhdGFLZXkgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIGRpc3BsYXllZERhdGEgPSBjaGFydERhdGEuc2xpY2UoZGF0YVN0YXJ0SW5kZXgsIGRhdGFFbmRJbmRleCArIDEpO1xuICByZXR1cm4gY29tcHV0ZVJhZGFyUG9pbnRzKHtcbiAgICByYWRpdXNBeGlzLFxuICAgIGFuZ2xlQXhpcyxcbiAgICBkaXNwbGF5ZWREYXRhLFxuICAgIGRhdGFLZXksXG4gICAgYmFuZFNpemVcbiAgfSk7XG59KTsiLCJpbXBvcnQgeyB1c2VBcHBTZWxlY3RvciB9IGZyb20gJy4uL2hvb2tzJztcbmV4cG9ydCB2YXIgc2VsZWN0RGVmYXVsdFRvb2x0aXBFdmVudFR5cGUgPSBzdGF0ZSA9PiBzdGF0ZS5vcHRpb25zLmRlZmF1bHRUb29sdGlwRXZlbnRUeXBlO1xuZXhwb3J0IHZhciBzZWxlY3RWYWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzID0gc3RhdGUgPT4gc3RhdGUub3B0aW9ucy52YWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzO1xuZXhwb3J0IGZ1bmN0aW9uIGNvbWJpbmVUb29sdGlwRXZlbnRUeXBlKHNoYXJlZCwgZGVmYXVsdFRvb2x0aXBFdmVudFR5cGUsIHZhbGlkYXRlVG9vbHRpcEV2ZW50VHlwZXMpIHtcbiAgaWYgKHNoYXJlZCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIGRlZmF1bHRUb29sdGlwRXZlbnRUeXBlO1xuICB9XG4gIHZhciBldmVudFR5cGUgPSBzaGFyZWQgPyAnYXhpcycgOiAnaXRlbSc7XG4gIGlmICh2YWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzID09IG51bGwpIHtcbiAgICByZXR1cm4gZGVmYXVsdFRvb2x0aXBFdmVudFR5cGU7XG4gIH1cbiAgcmV0dXJuIHZhbGlkYXRlVG9vbHRpcEV2ZW50VHlwZXMuaW5jbHVkZXMoZXZlbnRUeXBlKSA/IGV2ZW50VHlwZSA6IGRlZmF1bHRUb29sdGlwRXZlbnRUeXBlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdFRvb2x0aXBFdmVudFR5cGUoc3RhdGUsIHNoYXJlZCkge1xuICB2YXIgZGVmYXVsdFRvb2x0aXBFdmVudFR5cGUgPSBzZWxlY3REZWZhdWx0VG9vbHRpcEV2ZW50VHlwZShzdGF0ZSk7XG4gIHZhciB2YWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzID0gc2VsZWN0VmFsaWRhdGVUb29sdGlwRXZlbnRUeXBlcyhzdGF0ZSk7XG4gIHJldHVybiBjb21iaW5lVG9vbHRpcEV2ZW50VHlwZShzaGFyZWQsIGRlZmF1bHRUb29sdGlwRXZlbnRUeXBlLCB2YWxpZGF0ZVRvb2x0aXBFdmVudFR5cGVzKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1c2VUb29sdGlwRXZlbnRUeXBlKHNoYXJlZCkge1xuICByZXR1cm4gdXNlQXBwU2VsZWN0b3Ioc3RhdGUgPT4gc2VsZWN0VG9vbHRpcEV2ZW50VHlwZShzdGF0ZSwgc2hhcmVkKSk7XG59IiwiaW1wb3J0IGdldCBmcm9tICdlcy10b29sa2l0L2NvbXBhdC9nZXQnO1xuZXhwb3J0IHZhciBtYXRoU2lnbiA9IHZhbHVlID0+IHtcbiAgaWYgKHZhbHVlID09PSAwKSB7XG4gICAgcmV0dXJuIDA7XG4gIH1cbiAgaWYgKHZhbHVlID4gMCkge1xuICAgIHJldHVybiAxO1xuICB9XG4gIHJldHVybiAtMTtcbn07XG5leHBvcnQgdmFyIGlzTmFuID0gdmFsdWUgPT4ge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZXFlcWVxXG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT0gJ251bWJlcicgJiYgdmFsdWUgIT0gK3ZhbHVlO1xufTtcbmV4cG9ydCB2YXIgaXNQZXJjZW50ID0gdmFsdWUgPT4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiB2YWx1ZS5pbmRleE9mKCclJykgPT09IHZhbHVlLmxlbmd0aCAtIDE7XG5leHBvcnQgdmFyIGlzTnVtYmVyID0gdmFsdWUgPT4gKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgfHwgdmFsdWUgaW5zdGFuY2VvZiBOdW1iZXIpICYmICFpc05hbih2YWx1ZSk7XG5leHBvcnQgdmFyIGlzTnVtT3JTdHIgPSB2YWx1ZSA9PiBpc051bWJlcih2YWx1ZSkgfHwgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJztcbnZhciBpZENvdW50ZXIgPSAwO1xuZXhwb3J0IHZhciB1bmlxdWVJZCA9IHByZWZpeCA9PiB7XG4gIHZhciBpZCA9ICsraWRDb3VudGVyO1xuICByZXR1cm4gXCJcIi5jb25jYXQocHJlZml4IHx8ICcnKS5jb25jYXQoaWQpO1xufTtcblxuLyoqXG4gKiBHZXQgcGVyY2VudCB2YWx1ZSBvZiBhIHRvdGFsIHZhbHVlXG4gKiBAcGFyYW0ge251bWJlcnxzdHJpbmd9IHBlcmNlbnQgQSBwZXJjZW50XG4gKiBAcGFyYW0ge251bWJlcn0gdG90YWxWYWx1ZSAgICAgVG90YWwgdmFsdWVcbiAqIEBwYXJhbSB7bnVtYmVyfSBkZWZhdWx0VmFsdWUgICBUaGUgdmFsdWUgcmV0dXJuZWQgd2hlbiBwZXJjZW50IGlzIHVuZGVmaW5lZCBvciBpbnZhbGlkXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHZhbGlkYXRlICAgICAgSWYgc2V0IHRvIGJlIHRydWUsIHRoZSByZXN1bHQgd2lsbCBiZSB2YWxpZGF0ZWRcbiAqIEByZXR1cm4ge251bWJlcn0gdmFsdWVcbiAqL1xuZXhwb3J0IHZhciBnZXRQZXJjZW50VmFsdWUgPSBmdW5jdGlvbiBnZXRQZXJjZW50VmFsdWUocGVyY2VudCwgdG90YWxWYWx1ZSkge1xuICB2YXIgZGVmYXVsdFZhbHVlID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiAwO1xuICB2YXIgdmFsaWRhdGUgPSBhcmd1bWVudHMubGVuZ3RoID4gMyAmJiBhcmd1bWVudHNbM10gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1szXSA6IGZhbHNlO1xuICBpZiAoIWlzTnVtYmVyKHBlcmNlbnQpICYmIHR5cGVvZiBwZXJjZW50ICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gIH1cbiAgdmFyIHZhbHVlO1xuICBpZiAoaXNQZXJjZW50KHBlcmNlbnQpKSB7XG4gICAgaWYgKHRvdGFsVmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgdmFyIGluZGV4ID0gcGVyY2VudC5pbmRleE9mKCclJyk7XG4gICAgdmFsdWUgPSB0b3RhbFZhbHVlICogcGFyc2VGbG9hdChwZXJjZW50LnNsaWNlKDAsIGluZGV4KSkgLyAxMDA7XG4gIH0gZWxzZSB7XG4gICAgdmFsdWUgPSArcGVyY2VudDtcbiAgfVxuICBpZiAoaXNOYW4odmFsdWUpKSB7XG4gICAgdmFsdWUgPSBkZWZhdWx0VmFsdWU7XG4gIH1cbiAgaWYgKHZhbGlkYXRlICYmIHRvdGFsVmFsdWUgIT0gbnVsbCAmJiB2YWx1ZSA+IHRvdGFsVmFsdWUpIHtcbiAgICB2YWx1ZSA9IHRvdGFsVmFsdWU7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufTtcbmV4cG9ydCB2YXIgaGFzRHVwbGljYXRlID0gYXJ5ID0+IHtcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFyeSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgdmFyIGxlbiA9IGFyeS5sZW5ndGg7XG4gIHZhciBjYWNoZSA9IHt9O1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgaWYgKCFjYWNoZVthcnlbaV1dKSB7XG4gICAgICBjYWNoZVthcnlbaV1dID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn07XG5cbi8qKlxuICogQGRlcHJlY2F0ZWQgaW5zdGVhZCB1c2Uge0BsaW5rIGludGVycG9sYXRlfVxuICogIHRoaXMgZnVuY3Rpb24gcmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIGltbWVkaWF0ZWx5IGluIGFsbCB1c2UtY2FzZXMuXG4gKiAgSW5zdGVhZCwgdXNlIGludGVycG9sYXRlIHdoaWNoIHJldHVybnMgYSBudW1iZXIgYW5kIHNraXBzIHRoZSBhbm9ueW1vdXMgZnVuY3Rpb24gc3RlcC5cbiAqICBAcGFyYW0gbnVtYmVyQSBUaGUgZmlyc3QgbnVtYmVyXG4gKiAgQHBhcmFtIG51bWJlckIgVGhlIHNlY29uZCBudW1iZXJcbiAqICBAcmV0dXJuIEEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSBpbnRlcnBvbGF0ZWQgbnVtYmVyXG4gKi9cbmV4cG9ydCB2YXIgaW50ZXJwb2xhdGVOdW1iZXIgPSAobnVtYmVyQSwgbnVtYmVyQikgPT4ge1xuICBpZiAoaXNOdW1iZXIobnVtYmVyQSkgJiYgaXNOdW1iZXIobnVtYmVyQikpIHtcbiAgICByZXR1cm4gdCA9PiBudW1iZXJBICsgdCAqIChudW1iZXJCIC0gbnVtYmVyQSk7XG4gIH1cbiAgcmV0dXJuICgpID0+IG51bWJlckI7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlKHN0YXJ0LCBlbmQsIHQpIHtcbiAgaWYgKGlzTnVtYmVyKHN0YXJ0KSAmJiBpc051bWJlcihlbmQpKSB7XG4gICAgcmV0dXJuIHN0YXJ0ICsgdCAqIChlbmQgLSBzdGFydCk7XG4gIH1cbiAgcmV0dXJuIGVuZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmaW5kRW50cnlJbkFycmF5KGFyeSwgc3BlY2lmaWVkS2V5LCBzcGVjaWZpZWRWYWx1ZSkge1xuICBpZiAoIWFyeSB8fCAhYXJ5Lmxlbmd0aCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGFyeS5maW5kKGVudHJ5ID0+IGVudHJ5ICYmICh0eXBlb2Ygc3BlY2lmaWVkS2V5ID09PSAnZnVuY3Rpb24nID8gc3BlY2lmaWVkS2V5KGVudHJ5KSA6IGdldChlbnRyeSwgc3BlY2lmaWVkS2V5KSkgPT09IHNwZWNpZmllZFZhbHVlKTtcbn1cblxuLyoqXG4gKiBUaGUgbGVhc3Qgc3F1YXJlIGxpbmVhciByZWdyZXNzaW9uXG4gKiBAcGFyYW0ge0FycmF5fSBkYXRhIFRoZSBhcnJheSBvZiBwb2ludHNcbiAqIEByZXR1cm5zIHtPYmplY3R9IFRoZSBkb21haW4gb2YgeCwgYW5kIHRoZSBwYXJhbWV0ZXIgb2YgbGluZWFyIGZ1bmN0aW9uXG4gKi9cbmV4cG9ydCB2YXIgZ2V0TGluZWFyUmVncmVzc2lvbiA9IGRhdGEgPT4ge1xuICBpZiAoIWRhdGEgfHwgIWRhdGEubGVuZ3RoKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIGxlbiA9IGRhdGEubGVuZ3RoO1xuICB2YXIgeHN1bSA9IDA7XG4gIHZhciB5c3VtID0gMDtcbiAgdmFyIHh5c3VtID0gMDtcbiAgdmFyIHh4c3VtID0gMDtcbiAgdmFyIHhtaW4gPSBJbmZpbml0eTtcbiAgdmFyIHhtYXggPSAtSW5maW5pdHk7XG4gIHZhciB4Y3VycmVudCA9IDA7XG4gIHZhciB5Y3VycmVudCA9IDA7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICB4Y3VycmVudCA9IGRhdGFbaV0uY3ggfHwgMDtcbiAgICB5Y3VycmVudCA9IGRhdGFbaV0uY3kgfHwgMDtcbiAgICB4c3VtICs9IHhjdXJyZW50O1xuICAgIHlzdW0gKz0geWN1cnJlbnQ7XG4gICAgeHlzdW0gKz0geGN1cnJlbnQgKiB5Y3VycmVudDtcbiAgICB4eHN1bSArPSB4Y3VycmVudCAqIHhjdXJyZW50O1xuICAgIHhtaW4gPSBNYXRoLm1pbih4bWluLCB4Y3VycmVudCk7XG4gICAgeG1heCA9IE1hdGgubWF4KHhtYXgsIHhjdXJyZW50KTtcbiAgfVxuICB2YXIgYSA9IGxlbiAqIHh4c3VtICE9PSB4c3VtICogeHN1bSA/IChsZW4gKiB4eXN1bSAtIHhzdW0gKiB5c3VtKSAvIChsZW4gKiB4eHN1bSAtIHhzdW0gKiB4c3VtKSA6IDA7XG4gIHJldHVybiB7XG4gICAgeG1pbixcbiAgICB4bWF4LFxuICAgIGEsXG4gICAgYjogKHlzdW0gLSBhICogeHN1bSkgLyBsZW5cbiAgfTtcbn07XG4vKipcbiAqIENoZWNrcyBpZiB0aGUgdmFsdWUgaXMgbnVsbCBvciB1bmRlZmluZWRcbiAqIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2tcbiAqIEByZXR1cm5zIHRydWUgaWYgdGhlIHZhbHVlIGlzIG51bGwgb3IgdW5kZWZpbmVkXG4gKi9cbmV4cG9ydCB2YXIgaXNOdWxsaXNoID0gdmFsdWUgPT4ge1xuICByZXR1cm4gdmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJztcbn07XG5cbi8qKlxuICpVcHBlcmNhc2UgdGhlIGZpcnN0IGxldHRlciBvZiBhIHN0cmluZ1xuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlIFRoZSBzdHJpbmcgdG8gdXBwZXJjYXNlXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgdXBwZXJjYXNlZCBzdHJpbmdcbiAqL1xuZXhwb3J0IHZhciB1cHBlckZpcnN0ID0gdmFsdWUgPT4ge1xuICBpZiAoaXNOdWxsaXNoKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICByZXR1cm4gXCJcIi5jb25jYXQodmFsdWUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkpLmNvbmNhdCh2YWx1ZS5zbGljZSgxKSk7XG59OyIsImV4cG9ydCB2YXIgY29tYmluZVRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMgPSAodG9vbHRpcFN0YXRlLCB0b29sdGlwRXZlbnRUeXBlLCB0cmlnZ2VyLCBkZWZhdWx0SW5kZXgpID0+IHtcbiAgLy8gaWYgdG9vbHRpcCByZWFjdHMgdG8gYXhpcyBpbnRlcmFjdGlvbiwgdGhlbiB3ZSBkaXNwbGF5IGFsbCBpdGVtcyBhdCB0aGUgc2FtZSB0aW1lLlxuICBpZiAodG9vbHRpcEV2ZW50VHlwZSA9PT0gJ2F4aXMnKSB7XG4gICAgcmV0dXJuIHRvb2x0aXBTdGF0ZS50b29sdGlwSXRlbVBheWxvYWRzO1xuICB9XG4gIC8qXG4gICAqIEJ5IG5vdyB3ZSBhbHJlYWR5IGtub3cgdGhhdCB0b29sdGlwRXZlbnRUeXBlIGlzICdpdGVtJywgc28gd2UgY2FuIG9ubHkgc2VhcmNoIGluIGl0ZW1JbnRlcmFjdGlvbnMuXG4gICAqIGl0ZW0gbWVhbnMgdGhhdCBvbmx5IHRoZSBob3ZlcmVkIG9yIGNsaWNrZWQgaXRlbSB3aWxsIGJlIHByZXNlbnQgaW4gdGhlIHRvb2x0aXAuXG4gICAqL1xuICBpZiAodG9vbHRpcFN0YXRlLnRvb2x0aXBJdGVtUGF5bG9hZHMubGVuZ3RoID09PSAwKSB7XG4gICAgLy8gTm8gcG9pbnQgZmlsdGVyaW5nIGlmIHRoZSBwYXlsb2FkIGlzIGVtcHR5XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHZhciBmaWx0ZXJCeURhdGFLZXk7XG4gIGlmICh0cmlnZ2VyID09PSAnaG92ZXInKSB7XG4gICAgZmlsdGVyQnlEYXRhS2V5ID0gdG9vbHRpcFN0YXRlLml0ZW1JbnRlcmFjdGlvbi5ob3Zlci5kYXRhS2V5O1xuICB9IGVsc2Uge1xuICAgIGZpbHRlckJ5RGF0YUtleSA9IHRvb2x0aXBTdGF0ZS5pdGVtSW50ZXJhY3Rpb24uY2xpY2suZGF0YUtleTtcbiAgfVxuICBpZiAoZmlsdGVyQnlEYXRhS2V5ID09IG51bGwgJiYgZGVmYXVsdEluZGV4ICE9IG51bGwpIHtcbiAgICAvKlxuICAgICAqIFNvIHdoZW4gd2UgdXNlIGBkZWZhdWx0SW5kZXhgIC0gd2UgZG9uJ3QgaGF2ZSBhIGRhdGFLZXkgdG8gZmlsdGVyIGJ5IGJlY2F1c2UgdXNlciBkaWQgbm90IGhvdmVyIG92ZXIgYW55dGhpbmcgeWV0LlxuICAgICAqIEluIHRoYXQgY2FzZSBsZXQncyBkaXNwbGF5IHRoZSBmaXJzdCBpdGVtIGluIHRoZSB0b29sdGlwOyBhZnRlciBhbGwsIHRoaXMgaXMgYGl0ZW1gIGludGVyYWN0aW9uIGNhc2UsXG4gICAgICogc28gd2Ugc2hvdWxkIGRpc3BsYXkgb25seSBvbmUgaXRlbSBhdCBhIHRpbWUgaW5zdGVhZCBvZiBhbGwuXG4gICAgICovXG4gICAgcmV0dXJuIFt0b29sdGlwU3RhdGUudG9vbHRpcEl0ZW1QYXlsb2Fkc1swXV07XG4gIH1cbiAgcmV0dXJuIHRvb2x0aXBTdGF0ZS50b29sdGlwSXRlbVBheWxvYWRzLmZpbHRlcih0cGMgPT4ge1xuICAgIHZhciBfdHBjJHNldHRpbmdzO1xuICAgIHJldHVybiAoKF90cGMkc2V0dGluZ3MgPSB0cGMuc2V0dGluZ3MpID09PSBudWxsIHx8IF90cGMkc2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90cGMkc2V0dGluZ3MuZGF0YUtleSkgPT09IGZpbHRlckJ5RGF0YUtleTtcbiAgfSk7XG59OyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRIZWlnaHQsIHNlbGVjdENoYXJ0V2lkdGggfSBmcm9tICcuL2NvbnRhaW5lclNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydE9mZnNldEludGVybmFsIH0gZnJvbSAnLi9zZWxlY3RDaGFydE9mZnNldEludGVybmFsJztcbmltcG9ydCB7IGdldE1heFJhZGl1cyB9IGZyb20gJy4uLy4uL3V0aWwvUG9sYXJVdGlscyc7XG5pbXBvcnQgeyBnZXRQZXJjZW50VmFsdWUgfSBmcm9tICcuLi8uLi91dGlsL0RhdGFVdGlscyc7XG5pbXBvcnQgeyBkZWZhdWx0UG9sYXJBbmdsZUF4aXNQcm9wcyB9IGZyb20gJy4uLy4uL3BvbGFyL2RlZmF1bHRQb2xhckFuZ2xlQXhpc1Byb3BzJztcbmltcG9ydCB7IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcyB9IGZyb20gJy4uLy4uL3BvbGFyL2RlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcyc7XG5pbXBvcnQgeyBjb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lQXhpc1JhbmdlV2l0aFJldmVyc2UnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRMYXlvdXQgfSBmcm9tICcuLi8uLi9jb250ZXh0L2NoYXJ0TGF5b3V0Q29udGV4dCc7XG5leHBvcnQgdmFyIGltcGxpY2l0QW5nbGVBeGlzID0ge1xuICBhbGxvd0RhdGFPdmVyZmxvdzogZmFsc2UsXG4gIGFsbG93RGVjaW1hbHM6IGZhbHNlLFxuICBhbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeTogZmFsc2UsXG4gIC8vIGRlZmF1bHRQb2xhckFuZ2xlQXhpc1Byb3BzLmFsbG93RHVwbGljYXRlZENhdGVnb3J5IGhhcyBpdCBzZXQgdG8gdHJ1ZSBidXQgdGhlIGFjdHVhbCBheGlzIHJlbmRlcmluZyBpZ25vcmVzIHRoZSBwcm9wIGJlY2F1c2UgcmVhc29ucyxcbiAgZGF0YUtleTogdW5kZWZpbmVkLFxuICBkb21haW46IHVuZGVmaW5lZCxcbiAgaWQ6IGRlZmF1bHRQb2xhckFuZ2xlQXhpc1Byb3BzLmFuZ2xlQXhpc0lkLFxuICBpbmNsdWRlSGlkZGVuOiBmYWxzZSxcbiAgbmFtZTogdW5kZWZpbmVkLFxuICByZXZlcnNlZDogZGVmYXVsdFBvbGFyQW5nbGVBeGlzUHJvcHMucmV2ZXJzZWQsXG4gIHNjYWxlOiBkZWZhdWx0UG9sYXJBbmdsZUF4aXNQcm9wcy5zY2FsZSxcbiAgdGljazogZGVmYXVsdFBvbGFyQW5nbGVBeGlzUHJvcHMudGljayxcbiAgdGlja0NvdW50OiB1bmRlZmluZWQsXG4gIHRpY2tzOiB1bmRlZmluZWQsXG4gIHR5cGU6IGRlZmF1bHRQb2xhckFuZ2xlQXhpc1Byb3BzLnR5cGUsXG4gIHVuaXQ6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCB2YXIgaW1wbGljaXRSYWRpdXNBeGlzID0ge1xuICBhbGxvd0RhdGFPdmVyZmxvdzogZGVmYXVsdFBvbGFyUmFkaXVzQXhpc1Byb3BzLmFsbG93RGF0YU92ZXJmbG93LFxuICBhbGxvd0RlY2ltYWxzOiBmYWxzZSxcbiAgYWxsb3dEdXBsaWNhdGVkQ2F0ZWdvcnk6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy5hbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeSxcbiAgZGF0YUtleTogdW5kZWZpbmVkLFxuICBkb21haW46IHVuZGVmaW5lZCxcbiAgaWQ6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy5yYWRpdXNBeGlzSWQsXG4gIGluY2x1ZGVIaWRkZW46IGZhbHNlLFxuICBuYW1lOiB1bmRlZmluZWQsXG4gIHJldmVyc2VkOiBmYWxzZSxcbiAgc2NhbGU6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy5zY2FsZSxcbiAgdGljazogZGVmYXVsdFBvbGFyUmFkaXVzQXhpc1Byb3BzLnRpY2ssXG4gIHRpY2tDb3VudDogZGVmYXVsdFBvbGFyUmFkaXVzQXhpc1Byb3BzLnRpY2tDb3VudCxcbiAgdGlja3M6IHVuZGVmaW5lZCxcbiAgdHlwZTogZGVmYXVsdFBvbGFyUmFkaXVzQXhpc1Byb3BzLnR5cGUsXG4gIHVuaXQ6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCB2YXIgaW1wbGljaXRSYWRpYWxCYXJBbmdsZUF4aXMgPSB7XG4gIGFsbG93RGF0YU92ZXJmbG93OiBmYWxzZSxcbiAgYWxsb3dEZWNpbWFsczogZmFsc2UsXG4gIGFsbG93RHVwbGljYXRlZENhdGVnb3J5OiBkZWZhdWx0UG9sYXJBbmdsZUF4aXNQcm9wcy5hbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeSxcbiAgZGF0YUtleTogdW5kZWZpbmVkLFxuICBkb21haW46IHVuZGVmaW5lZCxcbiAgaWQ6IGRlZmF1bHRQb2xhckFuZ2xlQXhpc1Byb3BzLmFuZ2xlQXhpc0lkLFxuICBpbmNsdWRlSGlkZGVuOiBmYWxzZSxcbiAgbmFtZTogdW5kZWZpbmVkLFxuICByZXZlcnNlZDogZmFsc2UsXG4gIHNjYWxlOiBkZWZhdWx0UG9sYXJBbmdsZUF4aXNQcm9wcy5zY2FsZSxcbiAgdGljazogZGVmYXVsdFBvbGFyQW5nbGVBeGlzUHJvcHMudGljayxcbiAgdGlja0NvdW50OiB1bmRlZmluZWQsXG4gIHRpY2tzOiB1bmRlZmluZWQsXG4gIHR5cGU6ICdudW1iZXInLFxuICB1bml0OiB1bmRlZmluZWRcbn07XG5leHBvcnQgdmFyIGltcGxpY2l0UmFkaWFsQmFyUmFkaXVzQXhpcyA9IHtcbiAgYWxsb3dEYXRhT3ZlcmZsb3c6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy5hbGxvd0RhdGFPdmVyZmxvdyxcbiAgYWxsb3dEZWNpbWFsczogZmFsc2UsXG4gIGFsbG93RHVwbGljYXRlZENhdGVnb3J5OiBkZWZhdWx0UG9sYXJSYWRpdXNBeGlzUHJvcHMuYWxsb3dEdXBsaWNhdGVkQ2F0ZWdvcnksXG4gIGRhdGFLZXk6IHVuZGVmaW5lZCxcbiAgZG9tYWluOiB1bmRlZmluZWQsXG4gIGlkOiBkZWZhdWx0UG9sYXJSYWRpdXNBeGlzUHJvcHMucmFkaXVzQXhpc0lkLFxuICBpbmNsdWRlSGlkZGVuOiBmYWxzZSxcbiAgbmFtZTogdW5kZWZpbmVkLFxuICByZXZlcnNlZDogZmFsc2UsXG4gIHNjYWxlOiBkZWZhdWx0UG9sYXJSYWRpdXNBeGlzUHJvcHMuc2NhbGUsXG4gIHRpY2s6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy50aWNrLFxuICB0aWNrQ291bnQ6IGRlZmF1bHRQb2xhclJhZGl1c0F4aXNQcm9wcy50aWNrQ291bnQsXG4gIHRpY2tzOiB1bmRlZmluZWQsXG4gIHR5cGU6ICdjYXRlZ29yeScsXG4gIHVuaXQ6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCB2YXIgc2VsZWN0QW5nbGVBeGlzID0gKHN0YXRlLCBhbmdsZUF4aXNJZCkgPT4ge1xuICBpZiAoc3RhdGUucG9sYXJBeGlzLmFuZ2xlQXhpc1thbmdsZUF4aXNJZF0gIT0gbnVsbCkge1xuICAgIHJldHVybiBzdGF0ZS5wb2xhckF4aXMuYW5nbGVBeGlzW2FuZ2xlQXhpc0lkXTtcbiAgfVxuICBpZiAoc3RhdGUubGF5b3V0LmxheW91dFR5cGUgPT09ICdyYWRpYWwnKSB7XG4gICAgcmV0dXJuIGltcGxpY2l0UmFkaWFsQmFyQW5nbGVBeGlzO1xuICB9XG4gIHJldHVybiBpbXBsaWNpdEFuZ2xlQXhpcztcbn07XG5leHBvcnQgdmFyIHNlbGVjdFJhZGl1c0F4aXMgPSAoc3RhdGUsIHJhZGl1c0F4aXNJZCkgPT4ge1xuICBpZiAoc3RhdGUucG9sYXJBeGlzLnJhZGl1c0F4aXNbcmFkaXVzQXhpc0lkXSAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHN0YXRlLnBvbGFyQXhpcy5yYWRpdXNBeGlzW3JhZGl1c0F4aXNJZF07XG4gIH1cbiAgaWYgKHN0YXRlLmxheW91dC5sYXlvdXRUeXBlID09PSAncmFkaWFsJykge1xuICAgIHJldHVybiBpbXBsaWNpdFJhZGlhbEJhclJhZGl1c0F4aXM7XG4gIH1cbiAgcmV0dXJuIGltcGxpY2l0UmFkaXVzQXhpcztcbn07XG5leHBvcnQgdmFyIHNlbGVjdFBvbGFyT3B0aW9ucyA9IHN0YXRlID0+IHN0YXRlLnBvbGFyT3B0aW9ucztcbmV4cG9ydCB2YXIgc2VsZWN0TWF4UmFkaXVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0V2lkdGgsIHNlbGVjdENoYXJ0SGVpZ2h0LCBzZWxlY3RDaGFydE9mZnNldEludGVybmFsXSwgZ2V0TWF4UmFkaXVzKTtcbnZhciBzZWxlY3RJbm5lclJhZGl1cyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RQb2xhck9wdGlvbnMsIHNlbGVjdE1heFJhZGl1c10sIChwb2xhckNoYXJ0T3B0aW9ucywgbWF4UmFkaXVzKSA9PiB7XG4gIGlmIChwb2xhckNoYXJ0T3B0aW9ucyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gZ2V0UGVyY2VudFZhbHVlKHBvbGFyQ2hhcnRPcHRpb25zLmlubmVyUmFkaXVzLCBtYXhSYWRpdXMsIDApO1xufSk7XG5leHBvcnQgdmFyIHNlbGVjdE91dGVyUmFkaXVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFBvbGFyT3B0aW9ucywgc2VsZWN0TWF4UmFkaXVzXSwgKHBvbGFyQ2hhcnRPcHRpb25zLCBtYXhSYWRpdXMpID0+IHtcbiAgaWYgKHBvbGFyQ2hhcnRPcHRpb25zID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBnZXRQZXJjZW50VmFsdWUocG9sYXJDaGFydE9wdGlvbnMub3V0ZXJSYWRpdXMsIG1heFJhZGl1cywgbWF4UmFkaXVzICogMC44KTtcbn0pO1xudmFyIGNvbWJpbmVBbmdsZUF4aXNSYW5nZSA9IHBvbGFyT3B0aW9ucyA9PiB7XG4gIGlmIChwb2xhck9wdGlvbnMgPT0gbnVsbCkge1xuICAgIHJldHVybiBbMCwgMF07XG4gIH1cbiAgdmFyIHtcbiAgICBzdGFydEFuZ2xlLFxuICAgIGVuZEFuZ2xlXG4gIH0gPSBwb2xhck9wdGlvbnM7XG4gIHJldHVybiBbc3RhcnRBbmdsZSwgZW5kQW5nbGVdO1xufTtcbmV4cG9ydCB2YXIgc2VsZWN0QW5nbGVBeGlzUmFuZ2UgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJPcHRpb25zXSwgY29tYmluZUFuZ2xlQXhpc1JhbmdlKTtcbmV4cG9ydCB2YXIgc2VsZWN0QW5nbGVBeGlzUmFuZ2VXaXRoUmV2ZXJzZWQgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QW5nbGVBeGlzLCBzZWxlY3RBbmdsZUF4aXNSYW5nZV0sIGNvbWJpbmVBeGlzUmFuZ2VXaXRoUmV2ZXJzZSk7XG5leHBvcnQgdmFyIHNlbGVjdFJhZGl1c0F4aXNSYW5nZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RNYXhSYWRpdXMsIHNlbGVjdElubmVyUmFkaXVzLCBzZWxlY3RPdXRlclJhZGl1c10sIChtYXhSYWRpdXMsIGlubmVyUmFkaXVzLCBvdXRlclJhZGl1cykgPT4ge1xuICBpZiAobWF4UmFkaXVzID09IG51bGwgfHwgaW5uZXJSYWRpdXMgPT0gbnVsbCB8fCBvdXRlclJhZGl1cyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gW2lubmVyUmFkaXVzLCBvdXRlclJhZGl1c107XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0UmFkaXVzQXhpc1JhbmdlV2l0aFJldmVyc2VkID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJhZGl1c0F4aXMsIHNlbGVjdFJhZGl1c0F4aXNSYW5nZV0sIGNvbWJpbmVBeGlzUmFuZ2VXaXRoUmV2ZXJzZSk7XG5leHBvcnQgdmFyIHNlbGVjdFBvbGFyVmlld0JveCA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydExheW91dCwgc2VsZWN0UG9sYXJPcHRpb25zLCBzZWxlY3RJbm5lclJhZGl1cywgc2VsZWN0T3V0ZXJSYWRpdXMsIHNlbGVjdENoYXJ0V2lkdGgsIHNlbGVjdENoYXJ0SGVpZ2h0XSwgKGxheW91dCwgcG9sYXJPcHRpb25zLCBpbm5lclJhZGl1cywgb3V0ZXJSYWRpdXMsIHdpZHRoLCBoZWlnaHQpID0+IHtcbiAgaWYgKGxheW91dCAhPT0gJ2NlbnRyaWMnICYmIGxheW91dCAhPT0gJ3JhZGlhbCcgfHwgcG9sYXJPcHRpb25zID09IG51bGwgfHwgaW5uZXJSYWRpdXMgPT0gbnVsbCB8fCBvdXRlclJhZGl1cyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIGN4LFxuICAgIGN5LFxuICAgIHN0YXJ0QW5nbGUsXG4gICAgZW5kQW5nbGVcbiAgfSA9IHBvbGFyT3B0aW9ucztcbiAgcmV0dXJuIHtcbiAgICBjeDogZ2V0UGVyY2VudFZhbHVlKGN4LCB3aWR0aCwgd2lkdGggLyAyKSxcbiAgICBjeTogZ2V0UGVyY2VudFZhbHVlKGN5LCBoZWlnaHQsIGhlaWdodCAvIDIpLFxuICAgIGlubmVyUmFkaXVzLFxuICAgIG91dGVyUmFkaXVzLFxuICAgIHN0YXJ0QW5nbGUsXG4gICAgZW5kQW5nbGUsXG4gICAgY2xvY2tXaXNlOiBmYWxzZSAvLyB0aGlzIHByb3BlcnR5IGxvb2sgdXNlZnVsLCB3aHkgbm90IHVzZSBpdD9cbiAgfTtcbn0pOyIsImltcG9ydCBFdmVudEVtaXR0ZXIgZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG52YXIgZXZlbnRDZW50ZXIgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5leHBvcnQgeyBldmVudENlbnRlciB9O1xuZXhwb3J0IHZhciBUT09MVElQX1NZTkNfRVZFTlQgPSAncmVjaGFydHMuc3luY0V2ZW50LnRvb2x0aXAnO1xuZXhwb3J0IHZhciBCUlVTSF9TWU5DX0VWRU5UID0gJ3JlY2hhcnRzLnN5bmNFdmVudC5icnVzaCc7IiwiZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdFN5bmNocm9uaXNlZFRvb2x0aXBTdGF0ZShzdGF0ZSkge1xuICByZXR1cm4gc3RhdGUudG9vbHRpcC5zeW5jSW50ZXJhY3Rpb247XG59IiwidmFyIF9leGNsdWRlZCA9IFtcInhcIiwgXCJ5XCJdO1xuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2gsIHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vc3RhdGUvaG9va3MnO1xuaW1wb3J0IHsgc2VsZWN0RXZlbnRFbWl0dGVyLCBzZWxlY3RTeW5jSWQsIHNlbGVjdFN5bmNNZXRob2QgfSBmcm9tICcuLi9zdGF0ZS9zZWxlY3RvcnMvcm9vdFByb3BzU2VsZWN0b3JzJztcbmltcG9ydCB7IEJSVVNIX1NZTkNfRVZFTlQsIGV2ZW50Q2VudGVyLCBUT09MVElQX1NZTkNfRVZFTlQgfSBmcm9tICcuLi91dGlsL0V2ZW50cyc7XG5pbXBvcnQgeyBjcmVhdGVFdmVudEVtaXR0ZXIgfSBmcm9tICcuLi9zdGF0ZS9vcHRpb25zU2xpY2UnO1xuaW1wb3J0IHsgc2V0U3luY0ludGVyYWN0aW9uIH0gZnJvbSAnLi4vc3RhdGUvdG9vbHRpcFNsaWNlJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBEYXRhS2V5IH0gZnJvbSAnLi4vc3RhdGUvc2VsZWN0b3JzL3NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpc1RpY2tzIH0gZnJvbSAnLi4vc3RhdGUvc2VsZWN0b3JzL3Rvb2x0aXBTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0U3luY2hyb25pc2VkVG9vbHRpcFN0YXRlIH0gZnJvbSAnLi9zeW5jU2VsZWN0b3JzJztcbmltcG9ydCB7IHVzZUNoYXJ0TGF5b3V0LCB1c2VWaWV3Qm94IH0gZnJvbSAnLi4vY29udGV4dC9jaGFydExheW91dENvbnRleHQnO1xuaW1wb3J0IHsgc2V0RGF0YVN0YXJ0RW5kSW5kZXhlcyB9IGZyb20gJy4uL3N0YXRlL2NoYXJ0RGF0YVNsaWNlJztcbnZhciBub29wID0gKCkgPT4ge307XG5mdW5jdGlvbiB1c2VUb29sdGlwU3luY0V2ZW50c0xpc3RlbmVyKCkge1xuICB2YXIgbXlTeW5jSWQgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RTeW5jSWQpO1xuICB2YXIgbXlFdmVudEVtaXR0ZXIgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RFdmVudEVtaXR0ZXIpO1xuICB2YXIgZGlzcGF0Y2ggPSB1c2VBcHBEaXNwYXRjaCgpO1xuICB2YXIgc3luY01ldGhvZCA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdFN5bmNNZXRob2QpO1xuICB2YXIgdG9vbHRpcFRpY2tzID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0VG9vbHRpcEF4aXNUaWNrcyk7XG4gIHZhciBsYXlvdXQgPSB1c2VDaGFydExheW91dCgpO1xuICB2YXIgdmlld0JveCA9IHVzZVZpZXdCb3goKTtcbiAgdmFyIGNsYXNzTmFtZSA9IHVzZUFwcFNlbGVjdG9yKHN0YXRlID0+IHN0YXRlLnJvb3RQcm9wcy5jbGFzc05hbWUpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChteVN5bmNJZCA9PSBudWxsKSB7XG4gICAgICAvLyBUaGlzIGNoYXJ0IGlzIG5vdCBzeW5jaHJvbmlzZWQgd2l0aCBhbnkgb3RoZXIgY2hhcnQgc28gd2UgZG9uJ3QgbmVlZCB0byBsaXN0ZW4gZm9yIGFueSBldmVudHMuXG4gICAgICByZXR1cm4gbm9vcDtcbiAgICB9XG4gICAgdmFyIGxpc3RlbmVyID0gKGluY29taW5nU3luY0lkLCBhY3Rpb24sIGVtaXR0ZXIpID0+IHtcbiAgICAgIGlmIChteUV2ZW50RW1pdHRlciA9PT0gZW1pdHRlcikge1xuICAgICAgICAvLyBXZSBkb24ndCB3YW50IHRvIGRpc3BhdGNoIGFjdGlvbnMgdGhhdCB3ZSBzZW50IG91cnNlbHZlcy5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKG15U3luY0lkICE9PSBpbmNvbWluZ1N5bmNJZCkge1xuICAgICAgICAvLyBUaGlzIGV2ZW50IGlzIG5vdCBmb3IgdGhpcyBjaGFydFxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoc3luY01ldGhvZCA9PT0gJ2luZGV4Jykge1xuICAgICAgICB2YXIgX2FjdGlvbiRwYXlsb2FkO1xuICAgICAgICBpZiAodmlld0JveCAmJiBhY3Rpb24gIT09IG51bGwgJiYgYWN0aW9uICE9PSB2b2lkIDAgJiYgKF9hY3Rpb24kcGF5bG9hZCA9IGFjdGlvbi5wYXlsb2FkKSAhPT0gbnVsbCAmJiBfYWN0aW9uJHBheWxvYWQgIT09IHZvaWQgMCAmJiBfYWN0aW9uJHBheWxvYWQuY29vcmRpbmF0ZSAmJiBhY3Rpb24ucGF5bG9hZC5zb3VyY2VWaWV3Qm94KSB7XG4gICAgICAgICAgdmFyIF9hY3Rpb24kcGF5bG9hZCRjb29yZCA9IGFjdGlvbi5wYXlsb2FkLmNvb3JkaW5hdGUsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHg6IF94LFxuICAgICAgICAgICAgICB5OiBfeVxuICAgICAgICAgICAgfSA9IF9hY3Rpb24kcGF5bG9hZCRjb29yZCxcbiAgICAgICAgICAgIG90aGVyQ29vcmRpbmF0ZVByb3BzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKF9hY3Rpb24kcGF5bG9hZCRjb29yZCwgX2V4Y2x1ZGVkKTtcbiAgICAgICAgICB2YXIge1xuICAgICAgICAgICAgeDogc291cmNlWCxcbiAgICAgICAgICAgIHk6IHNvdXJjZVksXG4gICAgICAgICAgICB3aWR0aDogc291cmNlV2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IHNvdXJjZUhlaWdodFxuICAgICAgICAgIH0gPSBhY3Rpb24ucGF5bG9hZC5zb3VyY2VWaWV3Qm94O1xuICAgICAgICAgIHZhciBzY2FsZWRDb29yZGluYXRlID0gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBvdGhlckNvb3JkaW5hdGVQcm9wcyksIHt9LCB7XG4gICAgICAgICAgICB4OiB2aWV3Qm94LnggKyAoc291cmNlV2lkdGggPyAoX3ggLSBzb3VyY2VYKSAvIHNvdXJjZVdpZHRoIDogMCkgKiB2aWV3Qm94LndpZHRoLFxuICAgICAgICAgICAgeTogdmlld0JveC55ICsgKHNvdXJjZUhlaWdodCA/IChfeSAtIHNvdXJjZVkpIC8gc291cmNlSGVpZ2h0IDogMCkgKiB2aWV3Qm94LmhlaWdodFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGRpc3BhdGNoKF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYWN0aW9uKSwge30sIHtcbiAgICAgICAgICAgIHBheWxvYWQ6IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYWN0aW9uLnBheWxvYWQpLCB7fSwge1xuICAgICAgICAgICAgICBjb29yZGluYXRlOiBzY2FsZWRDb29yZGluYXRlXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH0pKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkaXNwYXRjaChhY3Rpb24pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh0b29sdGlwVGlja3MgPT0gbnVsbCkge1xuICAgICAgICAvLyBmb3IgdGhlIG90aGVyIHR3byBzeW5jIG1ldGhvZHMsIHdlIG5lZWQgdGhlIHRpY2tzIHRvIGJlIGF2YWlsYWJsZVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgYWN0aXZlVGljaztcbiAgICAgIGlmICh0eXBlb2Ygc3luY01ldGhvZCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAvKlxuICAgICAgICAgKiBUaGlzIGlzIHdoYXQgdGhlIGRhdGEgc2hhcGUgaW4gMi54IENhdGVnb3JpY2FsQ2hhcnRTdGF0ZSB1c2VkIHRvIGxvb2sgbGlrZS5cbiAgICAgICAgICogSW4gMy54IHdlIHN0b3JlIHRoaW5ncyBkaWZmZXJlbnRseSBidXQgbGV0J3MgdHJ5IHRvIGtlZXAgdGhlIG9sZCBzaGFwZSBmb3IgY29tcGF0aWJpbGl0eS5cbiAgICAgICAgICovXG4gICAgICAgIHZhciBzeW5jTWV0aG9kUGFyYW0gPSB7XG4gICAgICAgICAgYWN0aXZlVG9vbHRpcEluZGV4OiBhY3Rpb24ucGF5bG9hZC5pbmRleCA9PSBudWxsID8gdW5kZWZpbmVkIDogTnVtYmVyKGFjdGlvbi5wYXlsb2FkLmluZGV4KSxcbiAgICAgICAgICBpc1Rvb2x0aXBBY3RpdmU6IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZSxcbiAgICAgICAgICBhY3RpdmVJbmRleDogYWN0aW9uLnBheWxvYWQuaW5kZXggPT0gbnVsbCA/IHVuZGVmaW5lZCA6IE51bWJlcihhY3Rpb24ucGF5bG9hZC5pbmRleCksXG4gICAgICAgICAgYWN0aXZlTGFiZWw6IGFjdGlvbi5wYXlsb2FkLmxhYmVsLFxuICAgICAgICAgIGFjdGl2ZURhdGFLZXk6IGFjdGlvbi5wYXlsb2FkLmRhdGFLZXksXG4gICAgICAgICAgYWN0aXZlQ29vcmRpbmF0ZTogYWN0aW9uLnBheWxvYWQuY29vcmRpbmF0ZVxuICAgICAgICB9O1xuICAgICAgICAvLyBDYWxsIGEgY2FsbGJhY2sgZnVuY3Rpb24uIElmIHRoZXJlIGlzIGFuIGFwcGxpY2F0aW9uIHNwZWNpZmljIGFsZ29yaXRobVxuICAgICAgICB2YXIgYWN0aXZlVG9vbHRpcEluZGV4ID0gc3luY01ldGhvZCh0b29sdGlwVGlja3MsIHN5bmNNZXRob2RQYXJhbSk7XG4gICAgICAgIGFjdGl2ZVRpY2sgPSB0b29sdGlwVGlja3NbYWN0aXZlVG9vbHRpcEluZGV4XTtcbiAgICAgIH0gZWxzZSBpZiAoc3luY01ldGhvZCA9PT0gJ3ZhbHVlJykge1xuICAgICAgICAvLyBsYWJlbHMgYXJlIGFsd2F5cyBzdHJpbmdzLCB0aWNrLnZhbHVlIG1pZ2h0IGJlIGEgc3RyaW5nIG9yIGEgbnVtYmVyLCBkZXBlbmRpbmcgb24gYXhpcyB0eXBlXG4gICAgICAgIGFjdGl2ZVRpY2sgPSB0b29sdGlwVGlja3MuZmluZCh0aWNrID0+IFN0cmluZyh0aWNrLnZhbHVlKSA9PT0gYWN0aW9uLnBheWxvYWQubGFiZWwpO1xuICAgICAgfVxuICAgICAgdmFyIHtcbiAgICAgICAgY29vcmRpbmF0ZVxuICAgICAgfSA9IGFjdGlvbi5wYXlsb2FkO1xuICAgICAgaWYgKGFjdGl2ZVRpY2sgPT0gbnVsbCB8fCBhY3Rpb24ucGF5bG9hZC5hY3RpdmUgPT09IGZhbHNlIHx8IGNvb3JkaW5hdGUgPT0gbnVsbCB8fCB2aWV3Qm94ID09IG51bGwpIHtcbiAgICAgICAgZGlzcGF0Y2goc2V0U3luY0ludGVyYWN0aW9uKHtcbiAgICAgICAgICBhY3RpdmU6IGZhbHNlLFxuICAgICAgICAgIGNvb3JkaW5hdGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICBkYXRhS2V5OiB1bmRlZmluZWQsXG4gICAgICAgICAgaW5kZXg6IG51bGwsXG4gICAgICAgICAgbGFiZWw6IHVuZGVmaW5lZCxcbiAgICAgICAgICBzb3VyY2VWaWV3Qm94OiB1bmRlZmluZWRcbiAgICAgICAgfSkpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIge1xuICAgICAgICB4LFxuICAgICAgICB5XG4gICAgICB9ID0gY29vcmRpbmF0ZTtcbiAgICAgIHZhciB2YWxpZGF0ZUNoYXJ0WCA9IE1hdGgubWluKHgsIHZpZXdCb3gueCArIHZpZXdCb3gud2lkdGgpO1xuICAgICAgdmFyIHZhbGlkYXRlQ2hhcnRZID0gTWF0aC5taW4oeSwgdmlld0JveC55ICsgdmlld0JveC5oZWlnaHQpO1xuICAgICAgdmFyIGFjdGl2ZUNvb3JkaW5hdGUgPSB7XG4gICAgICAgIHg6IGxheW91dCA9PT0gJ2hvcml6b250YWwnID8gYWN0aXZlVGljay5jb29yZGluYXRlIDogdmFsaWRhdGVDaGFydFgsXG4gICAgICAgIHk6IGxheW91dCA9PT0gJ2hvcml6b250YWwnID8gdmFsaWRhdGVDaGFydFkgOiBhY3RpdmVUaWNrLmNvb3JkaW5hdGVcbiAgICAgIH07XG4gICAgICB2YXIgc3luY0FjdGlvbiA9IHNldFN5bmNJbnRlcmFjdGlvbih7XG4gICAgICAgIGFjdGl2ZTogYWN0aW9uLnBheWxvYWQuYWN0aXZlLFxuICAgICAgICBjb29yZGluYXRlOiBhY3RpdmVDb29yZGluYXRlLFxuICAgICAgICBkYXRhS2V5OiBhY3Rpb24ucGF5bG9hZC5kYXRhS2V5LFxuICAgICAgICBpbmRleDogU3RyaW5nKGFjdGl2ZVRpY2suaW5kZXgpLFxuICAgICAgICBsYWJlbDogYWN0aW9uLnBheWxvYWQubGFiZWwsXG4gICAgICAgIHNvdXJjZVZpZXdCb3g6IGFjdGlvbi5wYXlsb2FkLnNvdXJjZVZpZXdCb3hcbiAgICAgIH0pO1xuICAgICAgZGlzcGF0Y2goc3luY0FjdGlvbik7XG4gICAgfTtcbiAgICBldmVudENlbnRlci5vbihUT09MVElQX1NZTkNfRVZFTlQsIGxpc3RlbmVyKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRDZW50ZXIub2ZmKFRPT0xUSVBfU1lOQ19FVkVOVCwgbGlzdGVuZXIpO1xuICAgIH07XG4gIH0sIFtjbGFzc05hbWUsIGRpc3BhdGNoLCBteUV2ZW50RW1pdHRlciwgbXlTeW5jSWQsIHN5bmNNZXRob2QsIHRvb2x0aXBUaWNrcywgbGF5b3V0LCB2aWV3Qm94XSk7XG59XG5mdW5jdGlvbiB1c2VCcnVzaFN5bmNFdmVudHNMaXN0ZW5lcigpIHtcbiAgdmFyIG15U3luY0lkID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0U3luY0lkKTtcbiAgdmFyIG15RXZlbnRFbWl0dGVyID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0RXZlbnRFbWl0dGVyKTtcbiAgdmFyIGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAobXlTeW5jSWQgPT0gbnVsbCkge1xuICAgICAgLy8gVGhpcyBjaGFydCBpcyBub3Qgc3luY2hyb25pc2VkIHdpdGggYW55IG90aGVyIGNoYXJ0IHNvIHdlIGRvbid0IG5lZWQgdG8gbGlzdGVuIGZvciBhbnkgZXZlbnRzLlxuICAgICAgcmV0dXJuIG5vb3A7XG4gICAgfVxuICAgIHZhciBsaXN0ZW5lciA9IChpbmNvbWluZ1N5bmNJZCwgYWN0aW9uLCBlbWl0dGVyKSA9PiB7XG4gICAgICBpZiAobXlFdmVudEVtaXR0ZXIgPT09IGVtaXR0ZXIpIHtcbiAgICAgICAgLy8gV2UgZG9uJ3Qgd2FudCB0byBkaXNwYXRjaCBhY3Rpb25zIHRoYXQgd2Ugc2VudCBvdXJzZWx2ZXMuXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChteVN5bmNJZCA9PT0gaW5jb21pbmdTeW5jSWQpIHtcbiAgICAgICAgZGlzcGF0Y2goc2V0RGF0YVN0YXJ0RW5kSW5kZXhlcyhhY3Rpb24pKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGV2ZW50Q2VudGVyLm9uKEJSVVNIX1NZTkNfRVZFTlQsIGxpc3RlbmVyKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRDZW50ZXIub2ZmKEJSVVNIX1NZTkNfRVZFTlQsIGxpc3RlbmVyKTtcbiAgICB9O1xuICB9LCBbZGlzcGF0Y2gsIG15RXZlbnRFbWl0dGVyLCBteVN5bmNJZF0pO1xufVxuXG4vKipcbiAqIFdpbGwgcmVjZWl2ZSBzeW5jaHJvbmlzYXRpb24gZXZlbnRzIGZyb20gb3RoZXIgY2hhcnRzLlxuICpcbiAqIFJlYWRzIHN5bmNNZXRob2QgZnJvbSBzdGF0ZSBhbmQgZGVjaWRlcyBob3cgdG8gc3luY2hyb25pc2UgdGhlIHRvb2x0aXAgYmFzZWQgb24gdGhhdC5cbiAqXG4gKiBAcmV0dXJucyB2b2lkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTeW5jaHJvbmlzZWRFdmVudHNGcm9tT3RoZXJDaGFydHMoKSB7XG4gIHZhciBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZGlzcGF0Y2goY3JlYXRlRXZlbnRFbWl0dGVyKCkpO1xuICB9LCBbZGlzcGF0Y2hdKTtcbiAgdXNlVG9vbHRpcFN5bmNFdmVudHNMaXN0ZW5lcigpO1xuICB1c2VCcnVzaFN5bmNFdmVudHNMaXN0ZW5lcigpO1xufVxuXG4vKipcbiAqIFdpbGwgc2VuZCBldmVudHMgdG8gb3RoZXIgY2hhcnRzLlxuICogSWYgc3luY0lkIGlzIHVuZGVmaW5lZCwgbm8gZXZlbnRzIHdpbGwgYmUgc2VudC5cbiAqXG4gKiBUaGlzIGlnbm9yZXMgdGhlIHN5bmNNZXRob2QsIGJlY2F1c2UgdGhhdCBpcyBzZXQgYW5kIGNvbXB1dGVkIG9uIHRoZSByZWNlaXZpbmcgZW5kLlxuICpcbiAqIEBwYXJhbSB0b29sdGlwRXZlbnRUeXBlIGZyb20gVG9vbHRpcFxuICogQHBhcmFtIHRyaWdnZXIgZnJvbSBUb29sdGlwXG4gKiBAcGFyYW0gYWN0aXZlQ29vcmRpbmF0ZSBmcm9tIHN0YXRlXG4gKiBAcGFyYW0gYWN0aXZlTGFiZWwgZnJvbSBzdGF0ZVxuICogQHBhcmFtIGFjdGl2ZUluZGV4IGZyb20gc3RhdGVcbiAqIEBwYXJhbSBpc1Rvb2x0aXBBY3RpdmUgZnJvbSBzdGF0ZVxuICogQHJldHVybnMgdm9pZFxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9vbHRpcENoYXJ0U3luY2hyb25pc2F0aW9uKHRvb2x0aXBFdmVudFR5cGUsIHRyaWdnZXIsIGFjdGl2ZUNvb3JkaW5hdGUsIGFjdGl2ZUxhYmVsLCBhY3RpdmVJbmRleCwgaXNUb29sdGlwQWN0aXZlKSB7XG4gIHZhciBhY3RpdmVEYXRhS2V5ID0gdXNlQXBwU2VsZWN0b3Ioc3RhdGUgPT4gc2VsZWN0VG9vbHRpcERhdGFLZXkoc3RhdGUsIHRvb2x0aXBFdmVudFR5cGUsIHRyaWdnZXIpKTtcbiAgdmFyIGV2ZW50RW1pdHRlclN5bWJvbCA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdEV2ZW50RW1pdHRlcik7XG4gIHZhciBzeW5jSWQgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RTeW5jSWQpO1xuICB2YXIgc3luY01ldGhvZCA9IHVzZUFwcFNlbGVjdG9yKHNlbGVjdFN5bmNNZXRob2QpO1xuICB2YXIgdG9vbHRpcFN0YXRlID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0U3luY2hyb25pc2VkVG9vbHRpcFN0YXRlKTtcbiAgdmFyIGlzUmVjZWl2aW5nU3luY2hyb25pc2F0aW9uID0gdG9vbHRpcFN0YXRlID09PSBudWxsIHx8IHRvb2x0aXBTdGF0ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogdG9vbHRpcFN0YXRlLmFjdGl2ZTtcbiAgdmFyIHZpZXdCb3ggPSB1c2VWaWV3Qm94KCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzUmVjZWl2aW5nU3luY2hyb25pc2F0aW9uKSB7XG4gICAgICAvKlxuICAgICAgICogVGhpcyBjaGFydCBjdXJyZW50bHkgaGFzIGFjdGl2ZSB0b29sdGlwLCBzeW5jaHJvbmlzZWQgZnJvbSBhbm90aGVyIGNoYXJ0LlxuICAgICAgICogTGV0J3Mgbm90IHNlbmQgYW55IG91dGdvaW5nIHN5bmNocm9uaXNhdGlvbiBldmVudHMgd2hpbGUgdGhhdCdzIGhhcHBlbmluZ1xuICAgICAgICogdG8gYXZvaWQgaW5maW5pdGUgbG9vcHMuXG4gICAgICAgKi9cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHN5bmNJZCA9PSBudWxsKSB7XG4gICAgICAvKlxuICAgICAgICogc3luY0lkIGlzIG5vdCBzZXQsIG1lYW5zIHRoYXQgdGhpcyBjaGFydCBpcyBub3Qgc3luY2hyb25pc2VkIHdpdGggYW55IG90aGVyIGNoYXJ0LFxuICAgICAgICogbWVhbnMgd2UgZG9uJ3QgbmVlZCB0byBzZW5kIHN5bmNocm9uaXNhdGlvbiBldmVudHNcbiAgICAgICAqL1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoZXZlbnRFbWl0dGVyU3ltYm9sID09IG51bGwpIHtcbiAgICAgIC8qXG4gICAgICAgKiBXaGVuIHVzaW5nIFJlY2hhcnRzIGludGVybmFsIGhvb2tzIGFuZCBzZWxlY3RvcnMgb3V0c2lkZSBjaGFydHMgY29udGV4dCxcbiAgICAgICAqIHRoZXNlIHByb3BlcnRpZXMgd2lsbCBiZSB1bmRlZmluZWQuIExldCdzIHJldHVybiBzaWxlbnRseSBpbnN0ZWFkIG9mIHRocm93aW5nIGFuIGVycm9yLlxuICAgICAgICovXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciBzeW5jQWN0aW9uID0gc2V0U3luY0ludGVyYWN0aW9uKHtcbiAgICAgIGFjdGl2ZTogaXNUb29sdGlwQWN0aXZlLFxuICAgICAgY29vcmRpbmF0ZTogYWN0aXZlQ29vcmRpbmF0ZSxcbiAgICAgIGRhdGFLZXk6IGFjdGl2ZURhdGFLZXksXG4gICAgICBpbmRleDogYWN0aXZlSW5kZXgsXG4gICAgICBsYWJlbDogdHlwZW9mIGFjdGl2ZUxhYmVsID09PSAnbnVtYmVyJyA/IFN0cmluZyhhY3RpdmVMYWJlbCkgOiBhY3RpdmVMYWJlbCxcbiAgICAgIHNvdXJjZVZpZXdCb3g6IHZpZXdCb3hcbiAgICB9KTtcbiAgICBldmVudENlbnRlci5lbWl0KFRPT0xUSVBfU1lOQ19FVkVOVCwgc3luY0lkLCBzeW5jQWN0aW9uLCBldmVudEVtaXR0ZXJTeW1ib2wpO1xuICB9LCBbaXNSZWNlaXZpbmdTeW5jaHJvbmlzYXRpb24sIGFjdGl2ZUNvb3JkaW5hdGUsIGFjdGl2ZURhdGFLZXksIGFjdGl2ZUluZGV4LCBhY3RpdmVMYWJlbCwgZXZlbnRFbWl0dGVyU3ltYm9sLCBzeW5jSWQsIHN5bmNNZXRob2QsIGlzVG9vbHRpcEFjdGl2ZSwgdmlld0JveF0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZUJydXNoQ2hhcnRTeW5jaHJvbmlzYXRpb24oKSB7XG4gIHZhciBzeW5jSWQgPSB1c2VBcHBTZWxlY3RvcihzZWxlY3RTeW5jSWQpO1xuICB2YXIgZXZlbnRFbWl0dGVyU3ltYm9sID0gdXNlQXBwU2VsZWN0b3Ioc2VsZWN0RXZlbnRFbWl0dGVyKTtcbiAgdmFyIGJydXNoU3RhcnRJbmRleCA9IHVzZUFwcFNlbGVjdG9yKHN0YXRlID0+IHN0YXRlLmNoYXJ0RGF0YS5kYXRhU3RhcnRJbmRleCk7XG4gIHZhciBicnVzaEVuZEluZGV4ID0gdXNlQXBwU2VsZWN0b3Ioc3RhdGUgPT4gc3RhdGUuY2hhcnREYXRhLmRhdGFFbmRJbmRleCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHN5bmNJZCA9PSBudWxsIHx8IGJydXNoU3RhcnRJbmRleCA9PSBudWxsIHx8IGJydXNoRW5kSW5kZXggPT0gbnVsbCB8fCBldmVudEVtaXR0ZXJTeW1ib2wgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgc3luY0FjdGlvbiA9IHtcbiAgICAgIHN0YXJ0SW5kZXg6IGJydXNoU3RhcnRJbmRleCxcbiAgICAgIGVuZEluZGV4OiBicnVzaEVuZEluZGV4XG4gICAgfTtcbiAgICBldmVudENlbnRlci5lbWl0KEJSVVNIX1NZTkNfRVZFTlQsIHN5bmNJZCwgc3luY0FjdGlvbiwgZXZlbnRFbWl0dGVyU3ltYm9sKTtcbiAgfSwgW2JydXNoRW5kSW5kZXgsIGJydXNoU3RhcnRJbmRleCwgZXZlbnRFbWl0dGVyU3ltYm9sLCBzeW5jSWRdKTtcbn0iLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgY29tcHV0ZVJhZGlhbEJhckRhdGFJdGVtcyB9IGZyb20gJy4uLy4uL3BvbGFyL1JhZGlhbEJhcic7XG5pbXBvcnQgeyBzZWxlY3RDaGFydERhdGFBbmRBbHdheXNJZ25vcmVJbmRleGVzLCBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlcyB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RQb2xhckF4aXNTY2FsZSwgc2VsZWN0UG9sYXJBeGlzVGlja3MsIHNlbGVjdFBvbGFyR3JhcGhpY2FsSXRlbUF4aXNUaWNrcyB9IGZyb20gJy4vcG9sYXJTY2FsZVNlbGVjdG9ycyc7XG5pbXBvcnQgeyBjb21iaW5lU3RhY2tHcm91cHMgfSBmcm9tICcuL2F4aXNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0QW5nbGVBeGlzLCBzZWxlY3RQb2xhclZpZXdCb3gsIHNlbGVjdFJhZGl1c0F4aXMgfSBmcm9tICcuL3BvbGFyQXhpc1NlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydExheW91dCB9IGZyb20gJy4uLy4uL2NvbnRleHQvY2hhcnRMYXlvdXRDb250ZXh0JztcbmltcG9ydCB7IGdldEJhbmRTaXplT2ZBeGlzLCBnZXRCYXNlVmFsdWVPZkJhciwgaXNDYXRlZ29yaWNhbEF4aXMgfSBmcm9tICcuLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgY29tYmluZUFsbEJhclBvc2l0aW9ucywgY29tYmluZUJhclNpemVMaXN0LCBjb21iaW5lU3RhY2tlZERhdGEgfSBmcm9tICcuL2JhclNlbGVjdG9ycyc7XG5pbXBvcnQgeyBzZWxlY3RCYXJDYXRlZ29yeUdhcCwgc2VsZWN0QmFyR2FwLCBzZWxlY3RSb290QmFyU2l6ZSwgc2VsZWN0Um9vdE1heEJhclNpemUsIHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSB9IGZyb20gJy4vcm9vdFByb3BzU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdFBvbGFySXRlbXNTZXR0aW5ncywgc2VsZWN0VW5maWx0ZXJlZFBvbGFySXRlbXMgfSBmcm9tICcuL3BvbGFyU2VsZWN0b3JzJztcbmltcG9ydCB7IGlzTnVsbGlzaCB9IGZyb20gJy4uLy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IGNvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSB9IGZyb20gJy4vY29tYmluZXJzL2NvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSc7XG5pbXBvcnQgeyBzZWxlY3RUb29sdGlwQXhpcyB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcEF4aXMnO1xuaW1wb3J0IHsgaXNTdGFja2VkIH0gZnJvbSAnLi4vdHlwZXMvU3RhY2tlZEdyYXBoaWNhbEl0ZW0nO1xudmFyIHNlbGVjdFJhZGl1c0F4aXNGb3JSYWRpYWxCYXIgPSAoc3RhdGUsIHJhZGl1c0F4aXNJZCkgPT4gc2VsZWN0UmFkaXVzQXhpcyhzdGF0ZSwgcmFkaXVzQXhpc0lkKTtcbnZhciBzZWxlY3RSYWRpdXNBeGlzU2NhbGVGb3JSYWRhciA9IChzdGF0ZSwgcmFkaXVzQXhpc0lkKSA9PiBzZWxlY3RQb2xhckF4aXNTY2FsZShzdGF0ZSwgJ3JhZGl1c0F4aXMnLCByYWRpdXNBeGlzSWQpO1xuZXhwb3J0IHZhciBzZWxlY3RSYWRpdXNBeGlzV2l0aFNjYWxlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFJhZGl1c0F4aXNGb3JSYWRpYWxCYXIsIHNlbGVjdFJhZGl1c0F4aXNTY2FsZUZvclJhZGFyXSwgKGF4aXMsIHNjYWxlKSA9PiB7XG4gIGlmIChheGlzID09IG51bGwgfHwgc2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYXhpcyksIHt9LCB7XG4gICAgc2NhbGVcbiAgfSk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0UmFkaXVzQXhpc1RpY2tzID0gKHN0YXRlLCByYWRpdXNBeGlzSWQsIF9hbmdsZUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4ge1xuICByZXR1cm4gc2VsZWN0UG9sYXJHcmFwaGljYWxJdGVtQXhpc1RpY2tzKHN0YXRlLCAncmFkaXVzQXhpcycsIHJhZGl1c0F4aXNJZCwgaXNQYW5vcmFtYSk7XG59O1xudmFyIHNlbGVjdEFuZ2xlQXhpc0ZvclJhZGlhbEJhciA9IChzdGF0ZSwgX3JhZGl1c0F4aXNJZCwgYW5nbGVBeGlzSWQpID0+IHNlbGVjdEFuZ2xlQXhpcyhzdGF0ZSwgYW5nbGVBeGlzSWQpO1xudmFyIHNlbGVjdEFuZ2xlQXhpc1NjYWxlRm9yUmFkaWFsQmFyID0gKHN0YXRlLCBfcmFkaXVzQXhpc0lkLCBhbmdsZUF4aXNJZCkgPT4gc2VsZWN0UG9sYXJBeGlzU2NhbGUoc3RhdGUsICdhbmdsZUF4aXMnLCBhbmdsZUF4aXNJZCk7XG5leHBvcnQgdmFyIHNlbGVjdEFuZ2xlQXhpc1dpdGhTY2FsZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbmdsZUF4aXNGb3JSYWRpYWxCYXIsIHNlbGVjdEFuZ2xlQXhpc1NjYWxlRm9yUmFkaWFsQmFyXSwgKGF4aXMsIHNjYWxlKSA9PiB7XG4gIGlmIChheGlzID09IG51bGwgfHwgc2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgYXhpcyksIHt9LCB7XG4gICAgc2NhbGVcbiAgfSk7XG59KTtcbnZhciBzZWxlY3RBbmdsZUF4aXNUaWNrcyA9IChzdGF0ZSwgX3JhZGl1c0F4aXNJZCwgYW5nbGVBeGlzSWQsIGlzUGFub3JhbWEpID0+IHtcbiAgcmV0dXJuIHNlbGVjdFBvbGFyQXhpc1RpY2tzKHN0YXRlLCAnYW5nbGVBeGlzJywgYW5nbGVBeGlzSWQsIGlzUGFub3JhbWEpO1xufTtcbnZhciBwaWNrUmFkaWFsQmFyU2V0dGluZ3MgPSAoX3N0YXRlLCBfcmFkaXVzQXhpc0lkLCBfYW5nbGVBeGlzSWQsIHJhZGlhbEJhclNldHRpbmdzKSA9PiByYWRpYWxCYXJTZXR0aW5ncztcbnZhciBzZWxlY3RTeW5jaHJvbmlzZWRSYWRpYWxCYXJTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RVbmZpbHRlcmVkUG9sYXJJdGVtcywgcGlja1JhZGlhbEJhclNldHRpbmdzXSwgKGdyYXBoaWNhbEl0ZW1zLCByYWRpYWxCYXJTZXR0aW5nc0Zyb21Qcm9wcykgPT4ge1xuICBpZiAoZ3JhcGhpY2FsSXRlbXMuc29tZShwZ2lzID0+IHBnaXMudHlwZSA9PT0gJ3JhZGlhbEJhcicgJiYgcmFkaWFsQmFyU2V0dGluZ3NGcm9tUHJvcHMuZGF0YUtleSA9PT0gcGdpcy5kYXRhS2V5ICYmIHJhZGlhbEJhclNldHRpbmdzRnJvbVByb3BzLnN0YWNrSWQgPT09IHBnaXMuc3RhY2tJZCkpIHtcbiAgICByZXR1cm4gcmFkaWFsQmFyU2V0dGluZ3NGcm9tUHJvcHM7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn0pO1xuZXhwb3J0IHZhciBzZWxlY3RCYW5kU2l6ZU9mUG9sYXJBeGlzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RSYWRpdXNBeGlzV2l0aFNjYWxlLCBzZWxlY3RSYWRpdXNBeGlzVGlja3MsIHNlbGVjdEFuZ2xlQXhpc1dpdGhTY2FsZSwgc2VsZWN0QW5nbGVBeGlzVGlja3NdLCAobGF5b3V0LCByYWRpdXNBeGlzLCByYWRpdXNBeGlzVGlja3MsIGFuZ2xlQXhpcywgYW5nbGVBeGlzVGlja3MpID0+IHtcbiAgaWYgKGlzQ2F0ZWdvcmljYWxBeGlzKGxheW91dCwgJ3JhZGl1c0F4aXMnKSkge1xuICAgIHJldHVybiBnZXRCYW5kU2l6ZU9mQXhpcyhyYWRpdXNBeGlzLCByYWRpdXNBeGlzVGlja3MsIGZhbHNlKTtcbiAgfVxuICByZXR1cm4gZ2V0QmFuZFNpemVPZkF4aXMoYW5nbGVBeGlzLCBhbmdsZUF4aXNUaWNrcywgZmFsc2UpO1xufSk7XG5leHBvcnQgdmFyIHNlbGVjdEJhc2VWYWx1ZSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbmdsZUF4aXNXaXRoU2NhbGUsIHNlbGVjdFJhZGl1c0F4aXNXaXRoU2NhbGUsIHNlbGVjdENoYXJ0TGF5b3V0XSwgKGFuZ2xlQXhpcywgcmFkaXVzQXhpcywgbGF5b3V0KSA9PiB7XG4gIHZhciBudW1lcmljQXhpcyA9IGxheW91dCA9PT0gJ3JhZGlhbCcgPyBhbmdsZUF4aXMgOiByYWRpdXNBeGlzO1xuICBpZiAobnVtZXJpY0F4aXMgPT0gbnVsbCB8fCBudW1lcmljQXhpcy5zY2FsZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gZ2V0QmFzZVZhbHVlT2ZCYXIoe1xuICAgIG51bWVyaWNBeGlzXG4gIH0pO1xufSk7XG52YXIgcGlja0NlbGxzID0gKF9zdGF0ZSwgX3JhZGl1c0F4aXNJZCwgX2FuZ2xlQXhpc0lkLCBfcmFkaWFsQmFyU2V0dGluZ3MsIGNlbGxzKSA9PiBjZWxscztcbnZhciBwaWNrQW5nbGVBeGlzSWQgPSAoX3N0YXRlLCBfcmFkaXVzQXhpc0lkLCBhbmdsZUF4aXNJZCwgX3JhZGlhbEJhclNldHRpbmdzLCBfY2VsbHMpID0+IGFuZ2xlQXhpc0lkO1xudmFyIHBpY2tSYWRpdXNBeGlzSWQgPSAoX3N0YXRlLCByYWRpdXNBeGlzSWQsIF9hbmdsZUF4aXNJZCwgX3JhZGlhbEJhclNldHRpbmdzLCBfY2VsbHMpID0+IHJhZGl1c0F4aXNJZDtcbmV4cG9ydCB2YXIgcGlja01heEJhclNpemUgPSAoX3N0YXRlLCBfcmFkaXVzQXhpc0lkLCBfYW5nbGVBeGlzSWQsIHJhZGlhbEJhclNldHRpbmdzLCBfY2VsbHMpID0+IHJhZGlhbEJhclNldHRpbmdzLm1heEJhclNpemU7XG52YXIgc2VsZWN0QWxsVmlzaWJsZVJhZGlhbEJhcnMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFVuZmlsdGVyZWRQb2xhckl0ZW1zLCBwaWNrQW5nbGVBeGlzSWQsIHBpY2tSYWRpdXNBeGlzSWRdLCAobGF5b3V0LCBhbGxJdGVtcywgYW5nbGVBeGlzSWQsIHJhZGl1c0F4aXNJZCkgPT4ge1xuICByZXR1cm4gYWxsSXRlbXMuZmlsdGVyKGkgPT4ge1xuICAgIGlmIChsYXlvdXQgPT09ICdjZW50cmljJykge1xuICAgICAgcmV0dXJuIGkuYW5nbGVBeGlzSWQgPT09IGFuZ2xlQXhpc0lkO1xuICAgIH1cbiAgICByZXR1cm4gaS5yYWRpdXNBeGlzSWQgPT09IHJhZGl1c0F4aXNJZDtcbiAgfSkuZmlsdGVyKGkgPT4gaS5oaWRlID09PSBmYWxzZSkuZmlsdGVyKGkgPT4gaS50eXBlID09PSAncmFkaWFsQmFyJyk7XG59KTtcblxuLyoqXG4gKiBUaGUgZ2VuZXJhdG9yIG5ldmVyIHJldHVybmVkIHRoZSB0b3RhbFNpemUgd2hpY2ggbWVhbnMgdGhhdCBiYXJTaXplIGluIHBvbGFyIGNoYXJ0IGNhbiBub3Qgc3VwcG9ydCBwZXJjZW50IHZhbHVlcy5cbiAqIFdlIGNhbiBhZGQgdGhhdCBpZiB3ZSB3YW50IHRvIEkgc3VwcG9zZS5cbiAqIEByZXR1cm5zIHVuZGVmaW5lZCAtIGJ1dCBpdCBzaG91bGQgYmUgYSB0b3RhbCBzaXplIG9mIG51bWVyaWNhbCBheGlzIGluIHBvbGFyIGNoYXJ0XG4gKi9cbnZhciBzZWxlY3RQb2xhckJhckF4aXNTaXplID0gKCkgPT4gdW5kZWZpbmVkO1xuZXhwb3J0IHZhciBzZWxlY3RQb2xhckJhclNpemVMaXN0ID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbFZpc2libGVSYWRpYWxCYXJzLCBzZWxlY3RSb290QmFyU2l6ZSwgc2VsZWN0UG9sYXJCYXJBeGlzU2l6ZV0sIGNvbWJpbmVCYXJTaXplTGlzdCk7XG5leHBvcnQgdmFyIHNlbGVjdFBvbGFyQmFyQmFuZFNpemUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdFJvb3RNYXhCYXJTaXplLCBzZWxlY3RBbmdsZUF4aXNXaXRoU2NhbGUsIHNlbGVjdEFuZ2xlQXhpc1RpY2tzLCBzZWxlY3RSYWRpdXNBeGlzV2l0aFNjYWxlLCBzZWxlY3RSYWRpdXNBeGlzVGlja3MsIHBpY2tNYXhCYXJTaXplXSwgKGxheW91dCwgZ2xvYmFsTWF4QmFyU2l6ZSwgYW5nbGVBeGlzLCBhbmdsZUF4aXNUaWNrcywgcmFkaXVzQXhpcywgcmFkaXVzQXhpc1RpY2tzLCBjaGlsZE1heEJhclNpemUpID0+IHtcbiAgdmFyIF9yZWYyLCBfZ2V0QmFuZFNpemVPZkF4aXMyO1xuICB2YXIgbWF4QmFyU2l6ZSA9IGlzTnVsbGlzaChjaGlsZE1heEJhclNpemUpID8gZ2xvYmFsTWF4QmFyU2l6ZSA6IGNoaWxkTWF4QmFyU2l6ZTtcbiAgaWYgKGxheW91dCA9PT0gJ2NlbnRyaWMnKSB7XG4gICAgdmFyIF9yZWYsIF9nZXRCYW5kU2l6ZU9mQXhpcztcbiAgICByZXR1cm4gKF9yZWYgPSAoX2dldEJhbmRTaXplT2ZBeGlzID0gZ2V0QmFuZFNpemVPZkF4aXMoYW5nbGVBeGlzLCBhbmdsZUF4aXNUaWNrcywgdHJ1ZSkpICE9PSBudWxsICYmIF9nZXRCYW5kU2l6ZU9mQXhpcyAhPT0gdm9pZCAwID8gX2dldEJhbmRTaXplT2ZBeGlzIDogbWF4QmFyU2l6ZSkgIT09IG51bGwgJiYgX3JlZiAhPT0gdm9pZCAwID8gX3JlZiA6IDA7XG4gIH1cbiAgcmV0dXJuIChfcmVmMiA9IChfZ2V0QmFuZFNpemVPZkF4aXMyID0gZ2V0QmFuZFNpemVPZkF4aXMocmFkaXVzQXhpcywgcmFkaXVzQXhpc1RpY2tzLCB0cnVlKSkgIT09IG51bGwgJiYgX2dldEJhbmRTaXplT2ZBeGlzMiAhPT0gdm9pZCAwID8gX2dldEJhbmRTaXplT2ZBeGlzMiA6IG1heEJhclNpemUpICE9PSBudWxsICYmIF9yZWYyICE9PSB2b2lkIDAgPyBfcmVmMiA6IDA7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0QWxsUG9sYXJCYXJQb3NpdGlvbnMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJCYXJTaXplTGlzdCwgc2VsZWN0Um9vdE1heEJhclNpemUsIHNlbGVjdEJhckdhcCwgc2VsZWN0QmFyQ2F0ZWdvcnlHYXAsIHNlbGVjdFBvbGFyQmFyQmFuZFNpemUsIHNlbGVjdEJhbmRTaXplT2ZQb2xhckF4aXMsIHBpY2tNYXhCYXJTaXplXSwgY29tYmluZUFsbEJhclBvc2l0aW9ucyk7XG5leHBvcnQgdmFyIHNlbGVjdFBvbGFyQmFyUG9zaXRpb24gPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0QWxsUG9sYXJCYXJQb3NpdGlvbnMsIHNlbGVjdFN5bmNocm9uaXNlZFJhZGlhbEJhclNldHRpbmdzXSwgKGFsbEJhclBvc2l0aW9ucywgYmFyU2V0dGluZ3MpID0+IHtcbiAgaWYgKGFsbEJhclBvc2l0aW9ucyA9PSBudWxsIHx8IGJhclNldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBwb3NpdGlvbiA9IGFsbEJhclBvc2l0aW9ucy5maW5kKHAgPT4gcC5zdGFja0lkID09PSBiYXJTZXR0aW5ncy5zdGFja0lkICYmIGJhclNldHRpbmdzLmRhdGFLZXkgIT0gbnVsbCAmJiBwLmRhdGFLZXlzLmluY2x1ZGVzKGJhclNldHRpbmdzLmRhdGFLZXkpKTtcbiAgaWYgKHBvc2l0aW9uID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBwb3NpdGlvbi5wb3NpdGlvbjtcbn0pO1xudmFyIHNlbGVjdFN0YWNrZWRSYWRpYWxCYXJzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFBvbGFySXRlbXNTZXR0aW5nc10sIGFsbFBvbGFySXRlbXMgPT4gYWxsUG9sYXJJdGVtcy5maWx0ZXIoaXRlbSA9PiBpdGVtLnR5cGUgPT09ICdyYWRpYWxCYXInKS5maWx0ZXIoaXNTdGFja2VkKSk7XG52YXIgc2VsZWN0UG9sYXJDb21iaW5lZFN0YWNrZWREYXRhID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFN0YWNrZWRSYWRpYWxCYXJzLCBzZWxlY3RDaGFydERhdGFBbmRBbHdheXNJZ25vcmVJbmRleGVzLCBzZWxlY3RUb29sdGlwQXhpc10sIGNvbWJpbmVEaXNwbGF5ZWRTdGFja2VkRGF0YSk7XG52YXIgc2VsZWN0U3RhY2tHcm91cHMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UG9sYXJDb21iaW5lZFN0YWNrZWREYXRhLCBzZWxlY3RTdGFja2VkUmFkaWFsQmFycywgc2VsZWN0U3RhY2tPZmZzZXRUeXBlXSwgY29tYmluZVN0YWNrR3JvdXBzKTtcbnZhciBzZWxlY3RSYWRpYWxCYXJTdGFja0dyb3VwcyA9IChzdGF0ZSwgcmFkaXVzQXhpc0lkLCBhbmdsZUF4aXNJZCkgPT4ge1xuICB2YXIgbGF5b3V0ID0gc2VsZWN0Q2hhcnRMYXlvdXQoc3RhdGUpO1xuICBpZiAobGF5b3V0ID09PSAnY2VudHJpYycpIHtcbiAgICByZXR1cm4gc2VsZWN0U3RhY2tHcm91cHMoc3RhdGUsICdyYWRpdXNBeGlzJywgcmFkaXVzQXhpc0lkKTtcbiAgfVxuICByZXR1cm4gc2VsZWN0U3RhY2tHcm91cHMoc3RhdGUsICdhbmdsZUF4aXMnLCBhbmdsZUF4aXNJZCk7XG59O1xudmFyIHNlbGVjdFBvbGFyU3RhY2tlZERhdGEgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0UmFkaWFsQmFyU3RhY2tHcm91cHMsIHNlbGVjdFN5bmNocm9uaXNlZFJhZGlhbEJhclNldHRpbmdzXSwgY29tYmluZVN0YWNrZWREYXRhKTtcbmV4cG9ydCB2YXIgc2VsZWN0UmFkaWFsQmFyU2VjdG9ycyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbmdsZUF4aXNXaXRoU2NhbGUsIHNlbGVjdEFuZ2xlQXhpc1RpY2tzLCBzZWxlY3RSYWRpdXNBeGlzV2l0aFNjYWxlLCBzZWxlY3RSYWRpdXNBeGlzVGlja3MsIHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzLCBzZWxlY3RTeW5jaHJvbmlzZWRSYWRpYWxCYXJTZXR0aW5ncywgc2VsZWN0QmFuZFNpemVPZlBvbGFyQXhpcywgc2VsZWN0Q2hhcnRMYXlvdXQsIHNlbGVjdEJhc2VWYWx1ZSwgc2VsZWN0UG9sYXJWaWV3Qm94LCBwaWNrQ2VsbHMsIHNlbGVjdFBvbGFyQmFyUG9zaXRpb24sIHNlbGVjdFBvbGFyU3RhY2tlZERhdGFdLCAoYW5nbGVBeGlzLCBhbmdsZUF4aXNUaWNrcywgcmFkaXVzQXhpcywgcmFkaXVzQXhpc1RpY2tzLCBfcmVmMywgcmFkaWFsQmFyU2V0dGluZ3MsIGJhbmRTaXplLCBsYXlvdXQsIGJhc2VWYWx1ZSwgcG9sYXJWaWV3Qm94LCBjZWxscywgcG9zLCBzdGFja2VkRGF0YSkgPT4ge1xuICB2YXIge1xuICAgIGNoYXJ0RGF0YSxcbiAgICBkYXRhU3RhcnRJbmRleCxcbiAgICBkYXRhRW5kSW5kZXhcbiAgfSA9IF9yZWYzO1xuICBpZiAocmFkaWFsQmFyU2V0dGluZ3MgPT0gbnVsbCB8fCByYWRpdXNBeGlzID09IG51bGwgfHwgYW5nbGVBeGlzID09IG51bGwgfHwgY2hhcnREYXRhID09IG51bGwgfHwgYmFuZFNpemUgPT0gbnVsbCB8fCBwb3MgPT0gbnVsbCB8fCBsYXlvdXQgIT09ICdjZW50cmljJyAmJiBsYXlvdXQgIT09ICdyYWRpYWwnIHx8IHJhZGl1c0F4aXNUaWNrcyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHZhciB7XG4gICAgZGF0YUtleSxcbiAgICBtaW5Qb2ludFNpemVcbiAgfSA9IHJhZGlhbEJhclNldHRpbmdzO1xuICB2YXIge1xuICAgIGN4LFxuICAgIGN5LFxuICAgIHN0YXJ0QW5nbGUsXG4gICAgZW5kQW5nbGVcbiAgfSA9IHBvbGFyVmlld0JveDtcbiAgdmFyIGRpc3BsYXllZERhdGEgPSBjaGFydERhdGEuc2xpY2UoZGF0YVN0YXJ0SW5kZXgsIGRhdGFFbmRJbmRleCArIDEpO1xuICB2YXIgbnVtZXJpY0F4aXMgPSBsYXlvdXQgPT09ICdjZW50cmljJyA/IHJhZGl1c0F4aXMgOiBhbmdsZUF4aXM7XG4gIHZhciBzdGFja2VkRG9tYWluID0gc3RhY2tlZERhdGEgPyBudW1lcmljQXhpcy5zY2FsZS5kb21haW4oKSA6IG51bGw7XG4gIHJldHVybiBjb21wdXRlUmFkaWFsQmFyRGF0YUl0ZW1zKHtcbiAgICBhbmdsZUF4aXMsXG4gICAgYW5nbGVBeGlzVGlja3MsXG4gICAgYmFuZFNpemUsXG4gICAgYmFzZVZhbHVlLFxuICAgIGNlbGxzLFxuICAgIGN4LFxuICAgIGN5LFxuICAgIGRhdGFLZXksXG4gICAgZGF0YVN0YXJ0SW5kZXgsXG4gICAgZGlzcGxheWVkRGF0YSxcbiAgICBlbmRBbmdsZSxcbiAgICBsYXlvdXQsXG4gICAgbWluUG9pbnRTaXplLFxuICAgIHBvcyxcbiAgICByYWRpdXNBeGlzLFxuICAgIHJhZGl1c0F4aXNUaWNrcyxcbiAgICBzdGFja2VkRGF0YSxcbiAgICBzdGFja2VkRG9tYWluLFxuICAgIHN0YXJ0QW5nbGVcbiAgfSk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0UmFkaWFsQmFyTGVnZW5kUGF5bG9hZCA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydERhdGFBbmRBbHdheXNJZ25vcmVJbmRleGVzLCAoX3MsIGwpID0+IGxdLCAoX3JlZjQsIGxlZ2VuZFR5cGUpID0+IHtcbiAgdmFyIHtcbiAgICBjaGFydERhdGEsXG4gICAgZGF0YVN0YXJ0SW5kZXgsXG4gICAgZGF0YUVuZEluZGV4XG4gIH0gPSBfcmVmNDtcbiAgaWYgKGNoYXJ0RGF0YSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHZhciBkaXNwbGF5ZWREYXRhID0gY2hhcnREYXRhLnNsaWNlKGRhdGFTdGFydEluZGV4LCBkYXRhRW5kSW5kZXggKyAxKTtcbiAgaWYgKGRpc3BsYXllZERhdGEubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHJldHVybiBkaXNwbGF5ZWREYXRhLm1hcChlbnRyeSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHR5cGU6IGxlZ2VuZFR5cGUsXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIHdlIG5lZWQgYSBiZXR0ZXIgdHlwaW5nIGZvciBvdXIgZGF0YSBpbnB1dHNcbiAgICAgIHZhbHVlOiBlbnRyeS5uYW1lLFxuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciB3ZSBuZWVkIGEgYmV0dGVyIHR5cGluZyBmb3Igb3VyIGRhdGEgaW5wdXRzXG4gICAgICBjb2xvcjogZW50cnkuZmlsbCxcbiAgICAgIHBheWxvYWQ6IGVudHJ5XG4gICAgfTtcbiAgfSk7XG59KTsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgY29tcHV0ZUZ1bm5lbFRyYXBlem9pZHMgfSBmcm9tICcuLi8uLi9jYXJ0ZXNpYW4vRnVubmVsJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwgfSBmcm9tICcuL3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcyB9IGZyb20gJy4vZGF0YVNlbGVjdG9ycyc7XG52YXIgcGlja0Z1bm5lbFNldHRpbmdzID0gKF9zdGF0ZSwgZnVubmVsU2V0dGluZ3MpID0+IGZ1bm5lbFNldHRpbmdzO1xuZXhwb3J0IHZhciBzZWxlY3RGdW5uZWxUcmFwZXpvaWRzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwsIHBpY2tGdW5uZWxTZXR0aW5ncywgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlc10sIChvZmZzZXQsIF9yZWYsIF9yZWYyKSA9PiB7XG4gIHZhciB7XG4gICAgZGF0YSxcbiAgICBkYXRhS2V5LFxuICAgIG5hbWVLZXksXG4gICAgdG9vbHRpcFR5cGUsXG4gICAgbGFzdFNoYXBlVHlwZSxcbiAgICByZXZlcnNlZCxcbiAgICBjdXN0b21XaWR0aCxcbiAgICBjZWxscyxcbiAgICBwcmVzZW50YXRpb25Qcm9wc1xuICB9ID0gX3JlZjtcbiAgdmFyIHtcbiAgICBjaGFydERhdGFcbiAgfSA9IF9yZWYyO1xuICB2YXIgZGlzcGxheWVkRGF0YTtcbiAgaWYgKGRhdGEgIT0gbnVsbCAmJiBkYXRhLmxlbmd0aCA+IDApIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gZGF0YTtcbiAgfSBlbHNlIGlmIChjaGFydERhdGEgIT0gbnVsbCAmJiBjaGFydERhdGEubGVuZ3RoID4gMCkge1xuICAgIGRpc3BsYXllZERhdGEgPSBjaGFydERhdGE7XG4gIH1cbiAgaWYgKGRpc3BsYXllZERhdGEgJiYgZGlzcGxheWVkRGF0YS5sZW5ndGgpIHtcbiAgICBkaXNwbGF5ZWREYXRhID0gZGlzcGxheWVkRGF0YS5tYXAoKGVudHJ5LCBpbmRleCkgPT4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe1xuICAgICAgcGF5bG9hZDogZW50cnlcbiAgICB9LCBwcmVzZW50YXRpb25Qcm9wcyksIGVudHJ5KSwgY2VsbHMgJiYgY2VsbHNbaW5kZXhdICYmIGNlbGxzW2luZGV4XS5wcm9wcykpO1xuICB9IGVsc2UgaWYgKGNlbGxzICYmIGNlbGxzLmxlbmd0aCkge1xuICAgIGRpc3BsYXllZERhdGEgPSBjZWxscy5tYXAoY2VsbCA9PiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHByZXNlbnRhdGlvblByb3BzKSwgY2VsbC5wcm9wcykpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICByZXR1cm4gY29tcHV0ZUZ1bm5lbFRyYXBlem9pZHMoe1xuICAgIGRhdGFLZXksXG4gICAgbmFtZUtleSxcbiAgICBkaXNwbGF5ZWREYXRhLFxuICAgIHRvb2x0aXBUeXBlLFxuICAgIGxhc3RTaGFwZVR5cGUsXG4gICAgcmV2ZXJzZWQsXG4gICAgb2Zmc2V0LFxuICAgIGN1c3RvbVdpZHRoXG4gIH0pO1xufSk7IiwiaW1wb3J0IHsgY3JlYXRlU2VsZWN0b3IgfSBmcm9tICdyZXNlbGVjdCc7XG5leHBvcnQgdmFyIHNlbGVjdEFsbFhBeGVzID0gY3JlYXRlU2VsZWN0b3Ioc3RhdGUgPT4gc3RhdGUuY2FydGVzaWFuQXhpcy54QXhpcywgeEF4aXNNYXAgPT4ge1xuICByZXR1cm4gT2JqZWN0LnZhbHVlcyh4QXhpc01hcCk7XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0QWxsWUF4ZXMgPSBjcmVhdGVTZWxlY3RvcihzdGF0ZSA9PiBzdGF0ZS5jYXJ0ZXNpYW5BeGlzLnlBeGlzLCB5QXhpc01hcCA9PiB7XG4gIHJldHVybiBPYmplY3QudmFsdWVzKHlBeGlzTWFwKTtcbn0pOyIsInZhciBfZXhjbHVkZWQgPSBbXCJ4XCIsIFwieVwiXTtcbmZ1bmN0aW9uIF9leHRlbmRzKCkgeyByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikgeyBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykgeyB2YXIgdCA9IGFyZ3VtZW50c1tlXTsgZm9yICh2YXIgciBpbiB0KSAoe30pLmhhc093blByb3BlcnR5LmNhbGwodCwgcikgJiYgKG5bcl0gPSB0W3JdKTsgfSByZXR1cm4gbjsgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IGludmFyaWFudCBmcm9tICd0aW55LWludmFyaWFudCc7XG5pbXBvcnQgeyBTaGFwZSB9IGZyb20gJy4vQWN0aXZlU2hhcGVVdGlscyc7XG5pbXBvcnQgeyBpc051bGxpc2gsIGlzTnVtYmVyIH0gZnJvbSAnLi9EYXRhVXRpbHMnO1xuXG4vLyBSZWN0YW5nbGUgcHJvcHMgaXMgZXhwZWN0aW5nIHgsIHksIGhlaWdodCwgd2lkdGggYXMgbnVtYmVycywgbmFtZSBhcyBhIHN0cmluZywgYW5kIHJhZGl1cyBhcyBhIGN1c3RvbSB0eXBlXG4vLyBXaGVuIHByb3BzIGFyZSBiZWluZyBzcHJlYWQgaW4gZnJvbSBhIHVzZXIgZGVmaW5lZCBjb21wb25lbnQgaW4gQmFyLFxuLy8gdGhlIHByb3AgdHlwZXMgb2YgYW4gU1ZHRWxlbWVudCBoYXZlIHRoZXNlIHR5cGVkIGFzIHNvbWV0aGluZyBlbHNlLlxuLy8gVGhpcyBmdW5jdGlvbiB3aWxsIHJldHVybiB0aGUgcGFzc2VkIGluIHByb3BzXG4vLyBhbG9uZyB3aXRoIHgsIHksIGhlaWdodCBhcyBudW1iZXJzLCBuYW1lIGFzIGEgc3RyaW5nLCBhbmQgcmFkaXVzIGFzIG51bWJlciB8IFtudW1iZXIsIG51bWJlciwgbnVtYmVyLCBudW1iZXJdXG5mdW5jdGlvbiB0eXBlZ3VhcmRCYXJSZWN0YW5nbGVQcm9wcyhfcmVmLCBwcm9wcykge1xuICB2YXIge1xuICAgICAgeDogeFByb3AsXG4gICAgICB5OiB5UHJvcFxuICAgIH0gPSBfcmVmLFxuICAgIG9wdGlvbiA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmLCBfZXhjbHVkZWQpO1xuICB2YXIgeFZhbHVlID0gXCJcIi5jb25jYXQoeFByb3ApO1xuICB2YXIgeCA9IHBhcnNlSW50KHhWYWx1ZSwgMTApO1xuICB2YXIgeVZhbHVlID0gXCJcIi5jb25jYXQoeVByb3ApO1xuICB2YXIgeSA9IHBhcnNlSW50KHlWYWx1ZSwgMTApO1xuICB2YXIgaGVpZ2h0VmFsdWUgPSBcIlwiLmNvbmNhdChwcm9wcy5oZWlnaHQgfHwgb3B0aW9uLmhlaWdodCk7XG4gIHZhciBoZWlnaHQgPSBwYXJzZUludChoZWlnaHRWYWx1ZSwgMTApO1xuICB2YXIgd2lkdGhWYWx1ZSA9IFwiXCIuY29uY2F0KHByb3BzLndpZHRoIHx8IG9wdGlvbi53aWR0aCk7XG4gIHZhciB3aWR0aCA9IHBhcnNlSW50KHdpZHRoVmFsdWUsIDEwKTtcbiAgcmV0dXJuIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcHJvcHMpLCBvcHRpb24pLCB4ID8ge1xuICAgIHhcbiAgfSA6IHt9KSwgeSA/IHtcbiAgICB5XG4gIH0gOiB7fSksIHt9LCB7XG4gICAgaGVpZ2h0LFxuICAgIHdpZHRoLFxuICAgIG5hbWU6IHByb3BzLm5hbWUsXG4gICAgcmFkaXVzOiBwcm9wcy5yYWRpdXNcbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gQmFyUmVjdGFuZ2xlKHByb3BzKSB7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChTaGFwZSwgX2V4dGVuZHMoe1xuICAgIHNoYXBlVHlwZTogXCJyZWN0YW5nbGVcIixcbiAgICBwcm9wVHJhbnNmb3JtZXI6IHR5cGVndWFyZEJhclJlY3RhbmdsZVByb3BzLFxuICAgIGFjdGl2ZUNsYXNzTmFtZTogXCJyZWNoYXJ0cy1hY3RpdmUtYmFyXCJcbiAgfSwgcHJvcHMpKTtcbn1cbi8qKlxuICogU2FmZWx5IGdldHMgbWluUG9pbnRTaXplIGZyb20gdGhlIG1pblBvaW50U2l6ZSBwcm9wIGlmIGl0IGlzIGEgZnVuY3Rpb25cbiAqIEBwYXJhbSBtaW5Qb2ludFNpemUgbWluUG9pbnRTaXplIGFzIHBhc3NlZCB0byB0aGUgQmFyIGNvbXBvbmVudFxuICogQHBhcmFtIGRlZmF1bHRWYWx1ZSBkZWZhdWx0IG1pblBvaW50U2l6ZVxuICogQHJldHVybnMgbWluUG9pbnRTaXplXG4gKi9cbmV4cG9ydCB2YXIgbWluUG9pbnRTaXplQ2FsbGJhY2sgPSBmdW5jdGlvbiBtaW5Qb2ludFNpemVDYWxsYmFjayhtaW5Qb2ludFNpemUpIHtcbiAgdmFyIGRlZmF1bHRWYWx1ZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogMDtcbiAgcmV0dXJuICh2YWx1ZSwgaW5kZXgpID0+IHtcbiAgICBpZiAoaXNOdW1iZXIobWluUG9pbnRTaXplKSkgcmV0dXJuIG1pblBvaW50U2l6ZTtcbiAgICB2YXIgaXNWYWx1ZU51bWJlck9yTmlsID0gaXNOdW1iZXIodmFsdWUpIHx8IGlzTnVsbGlzaCh2YWx1ZSk7XG4gICAgaWYgKGlzVmFsdWVOdW1iZXJPck5pbCkge1xuICAgICAgcmV0dXJuIG1pblBvaW50U2l6ZSh2YWx1ZSwgaW5kZXgpO1xuICAgIH1cbiAgICAhaXNWYWx1ZU51bWJlck9yTmlsID8gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gaW52YXJpYW50KGZhbHNlLCBcIm1pblBvaW50U2l6ZSBjYWxsYmFjayBmdW5jdGlvbiByZWNlaXZlZCBhIHZhbHVlIHdpdGggdHlwZSBvZiBcIi5jb25jYXQodHlwZW9mIHZhbHVlLCBcIi4gQ3VycmVudGx5IG9ubHkgbnVtYmVycyBvciBudWxsL3VuZGVmaW5lZCBhcmUgc3VwcG9ydGVkLlwiKSkgOiBpbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG4gIH07XG59OyIsImltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCB9IGZyb20gJy4vc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCc7XG5leHBvcnQgdmFyIHNlbGVjdENoYXJ0T2Zmc2V0ID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWxdLCBvZmZzZXRJbnRlcm5hbCA9PiB7XG4gIGlmICghb2Zmc2V0SW50ZXJuYWwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiB7XG4gICAgdG9wOiBvZmZzZXRJbnRlcm5hbC50b3AsXG4gICAgYm90dG9tOiBvZmZzZXRJbnRlcm5hbC5ib3R0b20sXG4gICAgbGVmdDogb2Zmc2V0SW50ZXJuYWwubGVmdCxcbiAgICByaWdodDogb2Zmc2V0SW50ZXJuYWwucmlnaHRcbiAgfTtcbn0pOyIsImltcG9ydCB7IGNyZWF0ZVNsaWNlLCBjdXJyZW50LCBwcmVwYXJlQXV0b0JhdGNoZWQgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0JztcbmltcG9ydCB7IGNhc3REcmFmdCB9IGZyb20gJ2ltbWVyJztcblxuLyoqXG4gKiBPbmUgVG9vbHRpcCBjYW4gZGlzcGxheSBtdWx0aXBsZSBUb29sdGlwUGF5bG9hZEVudHJpZXMgYXQgYSB0aW1lLlxuICovXG5cbi8qKlxuICogU28gd2hhdCBoYXBwZW5zIGlzIHRoYXQgdGhlIHRvb2x0aXAgcGF5bG9hZCBpcyBkZWNpZGVkIGJhc2VkIG9uIHRoZSBhdmFpbGFibGUgZGF0YSwgYW5kIHRoZSBkYXRhS2V5LlxuICogVGhlIGRhdGFLZXkgY2FuIGVpdGhlciBiZSBkZWZpbmVkIG9uIHRoZSBncmFwaGljYWwgZWxlbWVudCAobGlrZSBMaW5lLCBvciBCYXIpXG4gKiBvciBvbiB0aGUgdG9vbHRpcCBpdHNlbGYuXG4gKlxuICogVGhlIGRhdGEgY2FuIGJlIGRlZmluZWQgaW4gdGhlIGNoYXJ0IGVsZW1lbnQsIG9yIGluIHRoZSBncmFwaGljYWwgaXRlbS5cbiAqXG4gKiBTbyB0aGlzIHR5cGUgaXMgYWxsIHRoZSBzZXR0aW5ncywgb3RoZXIgdGhhbiB0aGUgZGF0YSArIGRhdGFLZXkgY29tcGxpY2F0aW9ucy5cbiAqL1xuXG4vKipcbiAqIFRoaXMgaXMgd2hhdCBUb29sdGlwIHJlbmRlcnMuXG4gKi9cblxuLyoqXG4gKiBudWxsIG1lYW5zIG5vIGFjdGl2ZSBpbmRleFxuICogc3RyaW5nIG1lYW5zOiB3aGljaGV2ZXIgaW5kZXggZnJvbSB0aGUgY2hhcnQgZGF0YSBpdCBpcy5cbiAqIERpZmZlcmVudCBjaGFydHMgaGF2ZSBkaWZmZXJlbnQgcmVxdWlyZW1lbnRzIG9uIGRhdGEgc2hhcGVzLFxuICogYW5kIGFyZSBhbHNvIHJlc3BvbnNpYmxlIGZvciBwcm92aWRpbmcgYSBmdW5jdGlvbiB0aGF0IHdpbGwgYWNjZXB0IHRoaXMgaW5kZXhcbiAqIGFuZCByZXR1cm4gZGF0YS5cbiAqL1xuXG4vKipcbiAqIERpZmZlcmVudCBpdGVtcyBoYXZlIGRpZmZlcmVudCBkYXRhIHNoYXBlcyBzbyB0aGUgc3RhdGUgaGFzIG5vIG9waW5pb24gb24gd2hhdCB0aGUgZGF0YSBzaGFwZSBzaG91bGQgYmU7XG4gKiB0aGUgb25seSByZXF1aXJlbWVudCBpcyB0aGF0IHRoZSBjaGFydCBhbHNvIHByb3ZpZGVzIGEgc2VhcmNoZXIgZnVuY3Rpb25cbiAqIHRoYXQgYWNjZXB0cyB0aGUgZGF0YSwgYW5kIGEga2V5LCBhbmQgcmV0dXJucyB3aGF0ZXZlciB0aGUgcGF5bG9hZCBpbiBUb29sdGlwIHNob3VsZCBiZS5cbiAqL1xuXG4vKipcbiAqIFNvIHRoaXMgaW5mb3JtcyB0aGUgXCJ0b29sdGlwIGV2ZW50IHR5cGVcIi4gVG9vbHRpcCBldmVudCB0eXBlIGNhbiBiZSBlaXRoZXIgXCJheGlzXCIgb3IgXCJpdGVtXCJcbiAqIGFuZCBpdCBpcyB1c2VkIGZvciB0d28gdGhpbmdzOlxuICogMS4gU2V0cyB0aGUgYWN0aXZlIGFyZWFcbiAqIDIuIFNldHMgdGhlIGJhY2tncm91bmQgYW5kIGN1cnNvciBoaWdobGlnaHRzXG4gKlxuICogU29tZSBjaGFydHMgb25seSBhbGxvdyB0byBoYXZlIG9uZSB0eXBlIG9mIHRvb2x0aXAgZXZlbnQgdHlwZSwgc29tZSBhbGxvdyBib3RoLlxuICogVGhvc2UgY2hhcnRzIHRoYXQgYWxsb3cgYm90aCB3aWxsIGhhdmUgb25lIGRlZmF1bHQsIGFuZCB0aGUgXCJzaGFyZWRcIiBwcm9wIHdpbGwgYmUgdXNlZCB0byBzd2l0Y2ggYmV0d2VlbiB0aGVtLlxuICogVW5kZWZpbmVkIG1lYW5zIFwidXNlIHRoZSBjaGFydCBkZWZhdWx0XCIuXG4gKlxuICogQ2hhcnRzIHRoYXQgb25seSBhbGxvdyBvbmUgdG9vbHRpcCBldmVudCB0eXBlLCB3aWxsIGlnbm9yZSB0aGUgc2hhcmVkIHByb3AuXG4gKi9cblxuLyoqXG4gKiBBIGdlbmVyaWMgc3RhdGUgZm9yIHVzZXIgaW50ZXJhY3Rpb24gd2l0aCB0aGUgY2hhcnQuXG4gKiBVc2VyIGludGVyYWN0aW9uIGNhbiBjb21lIHRocm91Z2ggbXVsdGlwbGUgY2hhbm5lbHM6IG1vdXNlIGV2ZW50cywga2V5Ym9hcmQgZXZlbnRzLCBvciBoYXJkY29kZWQgaW4gcHJvcHMsIG9yIHN5bmNocm9uaXNlZCBmcm9tIG90aGVyIGNoYXJ0cy5cbiAqXG4gKiBFYWNoIG9mIHRoZSBpbnRlcmFjdGlvbiBzdGF0ZXMgaXMgcmVwcmVzZW50ZWQgYXMgVG9vbHRpcEludGVyYWN0aW9uU3RhdGUsXG4gKiBhbmQgdGhlbiB0aGUgc2VsZWN0b3JzIGFuZCBUb29sdGlwIHdpbGwgZGVjaWRlIHdoaWNoIG9mIHRoZSBpbnRlcmFjdGlvbiBzdGF0ZXMgdG8gdXNlLlxuICovXG5cbmV4cG9ydCB2YXIgbm9JbnRlcmFjdGlvbiA9IHtcbiAgYWN0aXZlOiBmYWxzZSxcbiAgaW5kZXg6IG51bGwsXG4gIGRhdGFLZXk6IHVuZGVmaW5lZCxcbiAgY29vcmRpbmF0ZTogdW5kZWZpbmVkXG59O1xuXG4vKipcbiAqIFRoZSB0b29sdGlwIGludGVyYWN0aW9uIHN0YXRlIHN0b3JlczpcbiAqXG4gKiAtIFdoaWNoIGdyYXBoaWNhbCBpdGVtIGlzIHVzZXIgaW50ZXJhY3Rpbmcgd2l0aCBhdCB0aGUgbW9tZW50LFxuICogLSB3aGljaCBheGlzIChvciwgd2hpY2ggcGFydCBvZiBjaGFydCBiYWNrZ3JvdW5kKSBpcyB1c2VyIGludGVyYWN0aW5nIHdpdGggYXQgdGhlIG1vbWVudFxuICogLSBUaGUgZGF0YSB0aGF0IGluZGl2aWR1YWwgZ3JhcGhpY2FsIGl0ZW1zIHdpc2ggdG8gYmUgZGlzcGxheWVkIGluIGNhc2UgdGhlIHRvb2x0aXAgZ2V0cyBhY3RpdmF0ZWRcbiAqL1xuXG5leHBvcnQgdmFyIGluaXRpYWxTdGF0ZSA9IHtcbiAgaXRlbUludGVyYWN0aW9uOiB7XG4gICAgY2xpY2s6IG5vSW50ZXJhY3Rpb24sXG4gICAgaG92ZXI6IG5vSW50ZXJhY3Rpb25cbiAgfSxcbiAgYXhpc0ludGVyYWN0aW9uOiB7XG4gICAgY2xpY2s6IG5vSW50ZXJhY3Rpb24sXG4gICAgaG92ZXI6IG5vSW50ZXJhY3Rpb25cbiAgfSxcbiAga2V5Ym9hcmRJbnRlcmFjdGlvbjogbm9JbnRlcmFjdGlvbixcbiAgc3luY0ludGVyYWN0aW9uOiB7XG4gICAgYWN0aXZlOiBmYWxzZSxcbiAgICBpbmRleDogbnVsbCxcbiAgICBkYXRhS2V5OiB1bmRlZmluZWQsXG4gICAgbGFiZWw6IHVuZGVmaW5lZCxcbiAgICBjb29yZGluYXRlOiB1bmRlZmluZWQsXG4gICAgc291cmNlVmlld0JveDogdW5kZWZpbmVkXG4gIH0sXG4gIHRvb2x0aXBJdGVtUGF5bG9hZHM6IFtdLFxuICBzZXR0aW5nczoge1xuICAgIHNoYXJlZDogdW5kZWZpbmVkLFxuICAgIHRyaWdnZXI6ICdob3ZlcicsXG4gICAgYXhpc0lkOiAwLFxuICAgIGFjdGl2ZTogZmFsc2UsXG4gICAgZGVmYXVsdEluZGV4OiB1bmRlZmluZWRcbiAgfVxufTtcbnZhciB0b29sdGlwU2xpY2UgPSBjcmVhdGVTbGljZSh7XG4gIG5hbWU6ICd0b29sdGlwJyxcbiAgaW5pdGlhbFN0YXRlLFxuICByZWR1Y2Vyczoge1xuICAgIGFkZFRvb2x0aXBFbnRyeVNldHRpbmdzOiB7XG4gICAgICByZWR1Y2VyKHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgICAgc3RhdGUudG9vbHRpcEl0ZW1QYXlsb2Fkcy5wdXNoKGNhc3REcmFmdChhY3Rpb24ucGF5bG9hZCkpO1xuICAgICAgfSxcbiAgICAgIHByZXBhcmU6IHByZXBhcmVBdXRvQmF0Y2hlZCgpXG4gICAgfSxcbiAgICByZW1vdmVUb29sdGlwRW50cnlTZXR0aW5nczoge1xuICAgICAgcmVkdWNlcihzdGF0ZSwgYWN0aW9uKSB7XG4gICAgICAgIHZhciBpbmRleCA9IGN1cnJlbnQoc3RhdGUpLnRvb2x0aXBJdGVtUGF5bG9hZHMuaW5kZXhPZihjYXN0RHJhZnQoYWN0aW9uLnBheWxvYWQpKTtcbiAgICAgICAgaWYgKGluZGV4ID4gLTEpIHtcbiAgICAgICAgICBzdGF0ZS50b29sdGlwSXRlbVBheWxvYWRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBwcmVwYXJlOiBwcmVwYXJlQXV0b0JhdGNoZWQoKVxuICAgIH0sXG4gICAgc2V0VG9vbHRpcFNldHRpbmdzU3RhdGUoc3RhdGUsIGFjdGlvbikge1xuICAgICAgc3RhdGUuc2V0dGluZ3MgPSBhY3Rpb24ucGF5bG9hZDtcbiAgICB9LFxuICAgIHNldEFjdGl2ZU1vdXNlT3Zlckl0ZW1JbmRleChzdGF0ZSwgYWN0aW9uKSB7XG4gICAgICBzdGF0ZS5zeW5jSW50ZXJhY3Rpb24uYWN0aXZlID0gZmFsc2U7XG4gICAgICBzdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgc3RhdGUuaXRlbUludGVyYWN0aW9uLmhvdmVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICBzdGF0ZS5pdGVtSW50ZXJhY3Rpb24uaG92ZXIuaW5kZXggPSBhY3Rpb24ucGF5bG9hZC5hY3RpdmVJbmRleDtcbiAgICAgIHN0YXRlLml0ZW1JbnRlcmFjdGlvbi5ob3Zlci5kYXRhS2V5ID0gYWN0aW9uLnBheWxvYWQuYWN0aXZlRGF0YUtleTtcbiAgICAgIHN0YXRlLml0ZW1JbnRlcmFjdGlvbi5ob3Zlci5jb29yZGluYXRlID0gYWN0aW9uLnBheWxvYWQuYWN0aXZlQ29vcmRpbmF0ZTtcbiAgICB9LFxuICAgIG1vdXNlTGVhdmVDaGFydChzdGF0ZSkge1xuICAgICAgLypcbiAgICAgICAqIENsZWFyIG9ubHkgdGhlIGFjdGl2ZSBmbGFncy4gV2h5P1xuICAgICAgICogMS4gS2VlcCBDb29yZGluYXRlIHRvIHByZXNlcnZlIGFuaW1hdGlvbiAtIG5leHQgdGltZSB0aGUgVG9vbHRpcCBhcHBlYXJzLCB3ZSB3YW50IHRvIHJlbmRlciBpdCBmcm9tXG4gICAgICAgKiB0aGUgbGFzdCBwbGFjZSB3aGVyZSBpdCB3YXMgd2hlbiBpdCBkaXNhcHBlYXJlZC5cbiAgICAgICAqIDIuIFdlIHdhbnQgdG8ga2VlcCBhbGwgdGhlIHByb3BlcnRpZXMgYW55d2F5IGp1c3QgaW4gY2FzZSB0aGUgdG9vbHRpcCBoYXMgYGFjdGl2ZT10cnVlYCBwcm9wXG4gICAgICAgKiBhbmQgY29udGludWVzIGJlaW5nIHZpc2libGUgZXZlbiBhZnRlciB0aGUgbW91c2UgaGFzIGxlZnQgdGhlIGNoYXJ0LlxuICAgICAgICovXG4gICAgICBzdGF0ZS5pdGVtSW50ZXJhY3Rpb24uaG92ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICBzdGF0ZS5heGlzSW50ZXJhY3Rpb24uaG92ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgfSxcbiAgICBtb3VzZUxlYXZlSXRlbShzdGF0ZSkge1xuICAgICAgc3RhdGUuaXRlbUludGVyYWN0aW9uLmhvdmVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG4gICAgc2V0QWN0aXZlQ2xpY2tJdGVtSW5kZXgoc3RhdGUsIGFjdGlvbikge1xuICAgICAgc3RhdGUuc3luY0ludGVyYWN0aW9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgc3RhdGUuaXRlbUludGVyYWN0aW9uLmNsaWNrLmFjdGl2ZSA9IHRydWU7XG4gICAgICBzdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgc3RhdGUuaXRlbUludGVyYWN0aW9uLmNsaWNrLmluZGV4ID0gYWN0aW9uLnBheWxvYWQuYWN0aXZlSW5kZXg7XG4gICAgICBzdGF0ZS5pdGVtSW50ZXJhY3Rpb24uY2xpY2suZGF0YUtleSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZURhdGFLZXk7XG4gICAgICBzdGF0ZS5pdGVtSW50ZXJhY3Rpb24uY2xpY2suY29vcmRpbmF0ZSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZUNvb3JkaW5hdGU7XG4gICAgfSxcbiAgICBzZXRNb3VzZU92ZXJBeGlzSW5kZXgoc3RhdGUsIGFjdGlvbikge1xuICAgICAgc3RhdGUuc3luY0ludGVyYWN0aW9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgc3RhdGUuYXhpc0ludGVyYWN0aW9uLmhvdmVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICBzdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgc3RhdGUuYXhpc0ludGVyYWN0aW9uLmhvdmVyLmluZGV4ID0gYWN0aW9uLnBheWxvYWQuYWN0aXZlSW5kZXg7XG4gICAgICBzdGF0ZS5heGlzSW50ZXJhY3Rpb24uaG92ZXIuZGF0YUtleSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZURhdGFLZXk7XG4gICAgICBzdGF0ZS5heGlzSW50ZXJhY3Rpb24uaG92ZXIuY29vcmRpbmF0ZSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZUNvb3JkaW5hdGU7XG4gICAgfSxcbiAgICBzZXRNb3VzZUNsaWNrQXhpc0luZGV4KHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgIHN0YXRlLnN5bmNJbnRlcmFjdGlvbi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgIHN0YXRlLmtleWJvYXJkSW50ZXJhY3Rpb24uYWN0aXZlID0gZmFsc2U7XG4gICAgICBzdGF0ZS5heGlzSW50ZXJhY3Rpb24uY2xpY2suYWN0aXZlID0gdHJ1ZTtcbiAgICAgIHN0YXRlLmF4aXNJbnRlcmFjdGlvbi5jbGljay5pbmRleCA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZUluZGV4O1xuICAgICAgc3RhdGUuYXhpc0ludGVyYWN0aW9uLmNsaWNrLmRhdGFLZXkgPSBhY3Rpb24ucGF5bG9hZC5hY3RpdmVEYXRhS2V5O1xuICAgICAgc3RhdGUuYXhpc0ludGVyYWN0aW9uLmNsaWNrLmNvb3JkaW5hdGUgPSBhY3Rpb24ucGF5bG9hZC5hY3RpdmVDb29yZGluYXRlO1xuICAgIH0sXG4gICAgc2V0U3luY0ludGVyYWN0aW9uKHN0YXRlLCBhY3Rpb24pIHtcbiAgICAgIHN0YXRlLnN5bmNJbnRlcmFjdGlvbiA9IGFjdGlvbi5wYXlsb2FkO1xuICAgIH0sXG4gICAgc2V0S2V5Ym9hcmRJbnRlcmFjdGlvbihzdGF0ZSwgYWN0aW9uKSB7XG4gICAgICBzdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmFjdGl2ZSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZTtcbiAgICAgIHN0YXRlLmtleWJvYXJkSW50ZXJhY3Rpb24uaW5kZXggPSBhY3Rpb24ucGF5bG9hZC5hY3RpdmVJbmRleDtcbiAgICAgIHN0YXRlLmtleWJvYXJkSW50ZXJhY3Rpb24uY29vcmRpbmF0ZSA9IGFjdGlvbi5wYXlsb2FkLmFjdGl2ZUNvb3JkaW5hdGU7XG4gICAgICBzdGF0ZS5rZXlib2FyZEludGVyYWN0aW9uLmRhdGFLZXkgPSBhY3Rpb24ucGF5bG9hZC5hY3RpdmVEYXRhS2V5O1xuICAgIH1cbiAgfVxufSk7XG5leHBvcnQgdmFyIHtcbiAgYWRkVG9vbHRpcEVudHJ5U2V0dGluZ3MsXG4gIHJlbW92ZVRvb2x0aXBFbnRyeVNldHRpbmdzLFxuICBzZXRUb29sdGlwU2V0dGluZ3NTdGF0ZSxcbiAgc2V0QWN0aXZlTW91c2VPdmVySXRlbUluZGV4LFxuICBtb3VzZUxlYXZlSXRlbSxcbiAgbW91c2VMZWF2ZUNoYXJ0LFxuICBzZXRBY3RpdmVDbGlja0l0ZW1JbmRleCxcbiAgc2V0TW91c2VPdmVyQXhpc0luZGV4LFxuICBzZXRNb3VzZUNsaWNrQXhpc0luZGV4LFxuICBzZXRTeW5jSW50ZXJhY3Rpb24sXG4gIHNldEtleWJvYXJkSW50ZXJhY3Rpb25cbn0gPSB0b29sdGlwU2xpY2UuYWN0aW9ucztcbmV4cG9ydCB2YXIgdG9vbHRpcFJlZHVjZXIgPSB0b29sdGlwU2xpY2UucmVkdWNlcjsiLCJpbXBvcnQgeyBpc1dlbGxCZWhhdmVkTnVtYmVyIH0gZnJvbSAnLi4vLi4vLi4vdXRpbC9pc1dlbGxCZWhhdmVkTnVtYmVyJztcbmV4cG9ydCB2YXIgY29tYmluZUFjdGl2ZVRvb2x0aXBJbmRleCA9ICh0b29sdGlwSW50ZXJhY3Rpb24sIGNoYXJ0RGF0YSkgPT4ge1xuICB2YXIgZGVzaXJlZEluZGV4ID0gdG9vbHRpcEludGVyYWN0aW9uID09PSBudWxsIHx8IHRvb2x0aXBJbnRlcmFjdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogdG9vbHRpcEludGVyYWN0aW9uLmluZGV4O1xuICBpZiAoZGVzaXJlZEluZGV4ID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgaW5kZXhBc051bWJlciA9IE51bWJlcihkZXNpcmVkSW5kZXgpO1xuICBpZiAoIWlzV2VsbEJlaGF2ZWROdW1iZXIoaW5kZXhBc051bWJlcikpIHtcbiAgICAvLyB0aGlzIGlzIGZvciBjaGFydHMgbGlrZSBTYW5rZXkgYW5kIFRyZWVtYXAgdGhhdCBkbyBub3Qgc3VwcG9ydCBudW1lcmljYWwgaW5kZXhlcy4gV2UgbmVlZCBhIHByb3BlciBzb2x1dGlvbiBmb3IgdGhpcyBiZWZvcmUgd2UgY2FuIHN0YXJ0IHN1cHBvcnRpbmcga2V5Ym9hcmQgZXZlbnRzIG9uIHRoZXNlIGNoYXJ0cy5cbiAgICByZXR1cm4gZGVzaXJlZEluZGV4O1xuICB9XG5cbiAgLypcbiAgICogWmVybyBpcyBhIHRyaXZpYWwgbGltaXQgZm9yIHNpbmdsZS1kaW1lbnNpb25hbCBjaGFydHMgbGlrZSBMaW5lIGFuZCBBcmVhLFxuICAgKiBidXQgdGhpcyBhbHNvIG5lZWRzIGEgc3VwcG9ydCBmb3IgbXVsdGlkaW1lbnNpb25hbCBjaGFydHMgbGlrZSBTYW5rZXkgYW5kIFRyZWVtYXAhIFRPRE9cbiAgICovXG4gIHZhciBsb3dlckxpbWl0ID0gMDtcbiAgdmFyIHVwcGVyTGltaXQgPSArSW5maW5pdHk7XG4gIGlmIChjaGFydERhdGEubGVuZ3RoID4gMCkge1xuICAgIHVwcGVyTGltaXQgPSBjaGFydERhdGEubGVuZ3RoIC0gMTtcbiAgfVxuXG4gIC8vIG5vdyBsZXQncyBjbGFtcCB0aGUgZGVzaXJlZEluZGV4IGJldHdlZW4gdGhlIGxpbWl0c1xuICByZXR1cm4gU3RyaW5nKE1hdGgubWF4KGxvd2VyTGltaXQsIE1hdGgubWluKGluZGV4QXNOdW1iZXIsIHVwcGVyTGltaXQpKSk7XG59OyIsImltcG9ydCB7IGlzTmFuIH0gZnJvbSAnLi4vLi4vLi4vdXRpbC9EYXRhVXRpbHMnO1xuZXhwb3J0IHZhciBjb21iaW5lQWN0aXZlTGFiZWwgPSAodG9vbHRpcFRpY2tzLCBhY3RpdmVJbmRleCkgPT4ge1xuICB2YXIgX3Rvb2x0aXBUaWNrcyRuO1xuICB2YXIgbiA9IE51bWJlcihhY3RpdmVJbmRleCk7XG4gIGlmIChpc05hbihuKSB8fCBhY3RpdmVJbmRleCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gbiA+PSAwID8gdG9vbHRpcFRpY2tzID09PSBudWxsIHx8IHRvb2x0aXBUaWNrcyA9PT0gdm9pZCAwIHx8IChfdG9vbHRpcFRpY2tzJG4gPSB0b29sdGlwVGlja3Nbbl0pID09PSBudWxsIHx8IF90b29sdGlwVGlja3MkbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3Rvb2x0aXBUaWNrcyRuLnZhbHVlIDogdW5kZWZpbmVkO1xufTsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gdHlwZW9mIGkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiB0IHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7IGlmIChcIm9iamVjdFwiICE9IHR5cGVvZiBpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yIH0gZnJvbSAncmVzZWxlY3QnO1xuaW1wb3J0IHsgc2VsZWN0QXhpc1dpdGhTY2FsZSwgc2VsZWN0Q2FydGVzaWFuQXhpc1NpemUsIHNlbGVjdFN0YWNrR3JvdXBzLCBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbSwgc2VsZWN0VW5maWx0ZXJlZENhcnRlc2lhbkl0ZW1zIH0gZnJvbSAnLi9heGlzU2VsZWN0b3JzJztcbmltcG9ydCB7IGdldFBlcmNlbnRWYWx1ZSwgaXNOdWxsaXNoIH0gZnJvbSAnLi4vLi4vdXRpbC9EYXRhVXRpbHMnO1xuaW1wb3J0IHsgZ2V0QmFuZFNpemVPZkF4aXMgfSBmcm9tICcuLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgY29tcHV0ZUJhclJlY3RhbmdsZXMgfSBmcm9tICcuLi8uLi9jYXJ0ZXNpYW4vQmFyJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0TGF5b3V0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9jaGFydExheW91dENvbnRleHQnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEgfSBmcm9tICcuL2RhdGFTZWxlY3RvcnMnO1xuaW1wb3J0IHsgc2VsZWN0QXhpc1ZpZXdCb3gsIHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwgfSBmcm9tICcuL3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwnO1xuaW1wb3J0IHsgc2VsZWN0QmFyQ2F0ZWdvcnlHYXAsIHNlbGVjdEJhckdhcCwgc2VsZWN0Um9vdEJhclNpemUsIHNlbGVjdFJvb3RNYXhCYXJTaXplIH0gZnJvbSAnLi9yb290UHJvcHNTZWxlY3RvcnMnO1xuaW1wb3J0IHsgaXNXZWxsQmVoYXZlZE51bWJlciB9IGZyb20gJy4uLy4uL3V0aWwvaXNXZWxsQmVoYXZlZE51bWJlcic7XG5pbXBvcnQgeyBnZXRTdGFja1Nlcmllc0lkZW50aWZpZXIgfSBmcm9tICcuLi8uLi91dGlsL3N0YWNrcy9nZXRTdGFja1Nlcmllc0lkZW50aWZpZXInO1xuaW1wb3J0IHsgaXNTdGFja2VkIH0gZnJvbSAnLi4vdHlwZXMvU3RhY2tlZEdyYXBoaWNhbEl0ZW0nO1xudmFyIHBpY2tYQXhpc0lkID0gKF9zdGF0ZSwgeEF4aXNJZCkgPT4geEF4aXNJZDtcbnZhciBwaWNrWUF4aXNJZCA9IChfc3RhdGUsIF94QXhpc0lkLCB5QXhpc0lkKSA9PiB5QXhpc0lkO1xudmFyIHBpY2tJc1Bhbm9yYW1hID0gKF9zdGF0ZSwgX3hBeGlzSWQsIF95QXhpc0lkLCBpc1Bhbm9yYW1hKSA9PiBpc1Bhbm9yYW1hO1xudmFyIHBpY2tCYXJJZCA9IChfc3RhdGUsIF94QXhpc0lkLCBfeUF4aXNJZCwgX2lzUGFub3JhbWEsIGlkKSA9PiBpZDtcbnZhciBzZWxlY3RTeW5jaHJvbmlzZWRCYXJTZXR0aW5ncyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RVbmZpbHRlcmVkQ2FydGVzaWFuSXRlbXMsIHBpY2tCYXJJZF0sIChncmFwaGljYWxJdGVtcywgaWQpID0+IGdyYXBoaWNhbEl0ZW1zLmZpbHRlcihpdGVtID0+IGl0ZW0udHlwZSA9PT0gJ2JhcicpLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBpZCkpO1xuZXhwb3J0IHZhciBzZWxlY3RNYXhCYXJTaXplID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFN5bmNocm9uaXNlZEJhclNldHRpbmdzXSwgYmFyU2V0dGluZ3MgPT4gYmFyU2V0dGluZ3MgPT09IG51bGwgfHwgYmFyU2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGJhclNldHRpbmdzLm1heEJhclNpemUpO1xudmFyIHBpY2tDZWxscyA9IChfc3RhdGUsIF94QXhpc0lkLCBfeUF4aXNJZCwgX2lzUGFub3JhbWEsIF9pZCwgY2VsbHMpID0+IGNlbGxzO1xudmFyIGdldEJhclNpemUgPSAoZ2xvYmFsU2l6ZSwgdG90YWxTaXplLCBzZWxmU2l6ZSkgPT4ge1xuICB2YXIgYmFyU2l6ZSA9IHNlbGZTaXplICE9PSBudWxsICYmIHNlbGZTaXplICE9PSB2b2lkIDAgPyBzZWxmU2l6ZSA6IGdsb2JhbFNpemU7XG4gIGlmIChpc051bGxpc2goYmFyU2l6ZSkpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBnZXRQZXJjZW50VmFsdWUoYmFyU2l6ZSwgdG90YWxTaXplLCAwKTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdEFsbFZpc2libGVCYXJzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RVbmZpbHRlcmVkQ2FydGVzaWFuSXRlbXMsIHBpY2tYQXhpc0lkLCBwaWNrWUF4aXNJZCwgcGlja0lzUGFub3JhbWFdLCAobGF5b3V0LCBhbGxJdGVtcywgeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gYWxsSXRlbXMuZmlsdGVyKGkgPT4ge1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICByZXR1cm4gaS54QXhpc0lkID09PSB4QXhpc0lkO1xuICB9XG4gIHJldHVybiBpLnlBeGlzSWQgPT09IHlBeGlzSWQ7XG59KS5maWx0ZXIoaSA9PiBpLmlzUGFub3JhbWEgPT09IGlzUGFub3JhbWEpLmZpbHRlcihpID0+IGkuaGlkZSA9PT0gZmFsc2UpLmZpbHRlcihpID0+IGkudHlwZSA9PT0gJ2JhcicpKTtcbnZhciBzZWxlY3RCYXJTdGFja0dyb3VwcyA9IChzdGF0ZSwgeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4ge1xuICB2YXIgbGF5b3V0ID0gc2VsZWN0Q2hhcnRMYXlvdXQoc3RhdGUpO1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICByZXR1cm4gc2VsZWN0U3RhY2tHcm91cHMoc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuICB9XG4gIHJldHVybiBzZWxlY3RTdGFja0dyb3VwcyhzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RCYXJDYXJ0ZXNpYW5BeGlzU2l6ZSA9IChzdGF0ZSwgeEF4aXNJZCwgeUF4aXNJZCkgPT4ge1xuICB2YXIgbGF5b3V0ID0gc2VsZWN0Q2hhcnRMYXlvdXQoc3RhdGUpO1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICByZXR1cm4gc2VsZWN0Q2FydGVzaWFuQXhpc1NpemUoc3RhdGUsICd4QXhpcycsIHhBeGlzSWQpO1xuICB9XG4gIHJldHVybiBzZWxlY3RDYXJ0ZXNpYW5BeGlzU2l6ZShzdGF0ZSwgJ3lBeGlzJywgeUF4aXNJZCk7XG59O1xuZXhwb3J0IHZhciBjb21iaW5lQmFyU2l6ZUxpc3QgPSAoYWxsQmFycywgZ2xvYmFsU2l6ZSwgdG90YWxTaXplKSA9PiB7XG4gIHZhciBpbml0aWFsVmFsdWUgPSB7fTtcbiAgdmFyIHN0YWNrZWRCYXJzID0gYWxsQmFycy5maWx0ZXIoaXNTdGFja2VkKTtcbiAgdmFyIHVuc3RhY2tlZEJhcnMgPSBhbGxCYXJzLmZpbHRlcihiID0+IGIuc3RhY2tJZCA9PSBudWxsKTtcbiAgdmFyIGdyb3VwQnlTdGFjayA9IHN0YWNrZWRCYXJzLnJlZHVjZSgoYWNjLCBiYXIpID0+IHtcbiAgICBpZiAoIWFjY1tiYXIuc3RhY2tJZF0pIHtcbiAgICAgIGFjY1tiYXIuc3RhY2tJZF0gPSBbXTtcbiAgICB9XG4gICAgYWNjW2Jhci5zdGFja0lkXS5wdXNoKGJhcik7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwgaW5pdGlhbFZhbHVlKTtcbiAgdmFyIHN0YWNrZWRTaXplTGlzdCA9IE9iamVjdC5lbnRyaWVzKGdyb3VwQnlTdGFjaykubWFwKF9yZWYgPT4ge1xuICAgIHZhciBbc3RhY2tJZCwgYmFyc10gPSBfcmVmO1xuICAgIHZhciBkYXRhS2V5cyA9IGJhcnMubWFwKGIgPT4gYi5kYXRhS2V5KTtcbiAgICB2YXIgYmFyU2l6ZSA9IGdldEJhclNpemUoZ2xvYmFsU2l6ZSwgdG90YWxTaXplLCBiYXJzWzBdLmJhclNpemUpO1xuICAgIHJldHVybiB7XG4gICAgICBzdGFja0lkLFxuICAgICAgZGF0YUtleXMsXG4gICAgICBiYXJTaXplXG4gICAgfTtcbiAgfSk7XG4gIHZhciB1bnN0YWNrZWRTaXplTGlzdCA9IHVuc3RhY2tlZEJhcnMubWFwKGIgPT4ge1xuICAgIHZhciBkYXRhS2V5cyA9IFtiLmRhdGFLZXldLmZpbHRlcihkayA9PiBkayAhPSBudWxsKTtcbiAgICB2YXIgYmFyU2l6ZSA9IGdldEJhclNpemUoZ2xvYmFsU2l6ZSwgdG90YWxTaXplLCBiLmJhclNpemUpO1xuICAgIHJldHVybiB7XG4gICAgICBzdGFja0lkOiB1bmRlZmluZWQsXG4gICAgICBkYXRhS2V5cyxcbiAgICAgIGJhclNpemVcbiAgICB9O1xuICB9KTtcbiAgcmV0dXJuIFsuLi5zdGFja2VkU2l6ZUxpc3QsIC4uLnVuc3RhY2tlZFNpemVMaXN0XTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdEJhclNpemVMaXN0ID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEFsbFZpc2libGVCYXJzLCBzZWxlY3RSb290QmFyU2l6ZSwgc2VsZWN0QmFyQ2FydGVzaWFuQXhpc1NpemVdLCBjb21iaW5lQmFyU2l6ZUxpc3QpO1xuZXhwb3J0IHZhciBzZWxlY3RCYXJCYW5kU2l6ZSA9IChzdGF0ZSwgeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSwgaWQpID0+IHtcbiAgdmFyIF9yZWYyLCBfZ2V0QmFuZFNpemVPZkF4aXM7XG4gIHZhciBiYXJTZXR0aW5ncyA9IHNlbGVjdFN5bmNocm9uaXNlZEJhclNldHRpbmdzKHN0YXRlLCB4QXhpc0lkLCB5QXhpc0lkLCBpc1Bhbm9yYW1hLCBpZCk7XG4gIGlmIChiYXJTZXR0aW5ncyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgbGF5b3V0ID0gc2VsZWN0Q2hhcnRMYXlvdXQoc3RhdGUpO1xuICB2YXIgZ2xvYmFsTWF4QmFyU2l6ZSA9IHNlbGVjdFJvb3RNYXhCYXJTaXplKHN0YXRlKTtcbiAgdmFyIHtcbiAgICBtYXhCYXJTaXplOiBjaGlsZE1heEJhclNpemVcbiAgfSA9IGJhclNldHRpbmdzO1xuICB2YXIgbWF4QmFyU2l6ZSA9IGlzTnVsbGlzaChjaGlsZE1heEJhclNpemUpID8gZ2xvYmFsTWF4QmFyU2l6ZSA6IGNoaWxkTWF4QmFyU2l6ZTtcbiAgdmFyIGF4aXMsIHRpY2tzO1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICBheGlzID0gc2VsZWN0QXhpc1dpdGhTY2FsZShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG4gICAgdGlja3MgPSBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG4gIH0gZWxzZSB7XG4gICAgYXhpcyA9IHNlbGVjdEF4aXNXaXRoU2NhbGUoc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuICAgIHRpY2tzID0gc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0oc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuICB9XG4gIHJldHVybiAoX3JlZjIgPSAoX2dldEJhbmRTaXplT2ZBeGlzID0gZ2V0QmFuZFNpemVPZkF4aXMoYXhpcywgdGlja3MsIHRydWUpKSAhPT0gbnVsbCAmJiBfZ2V0QmFuZFNpemVPZkF4aXMgIT09IHZvaWQgMCA/IF9nZXRCYW5kU2l6ZU9mQXhpcyA6IG1heEJhclNpemUpICE9PSBudWxsICYmIF9yZWYyICE9PSB2b2lkIDAgPyBfcmVmMiA6IDA7XG59O1xuZXhwb3J0IHZhciBzZWxlY3RBeGlzQmFuZFNpemUgPSAoc3RhdGUsIHhBeGlzSWQsIHlBeGlzSWQsIGlzUGFub3JhbWEpID0+IHtcbiAgdmFyIGxheW91dCA9IHNlbGVjdENoYXJ0TGF5b3V0KHN0YXRlKTtcbiAgdmFyIGF4aXMsIHRpY2tzO1xuICBpZiAobGF5b3V0ID09PSAnaG9yaXpvbnRhbCcpIHtcbiAgICBheGlzID0gc2VsZWN0QXhpc1dpdGhTY2FsZShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG4gICAgdGlja3MgPSBzZWxlY3RUaWNrc09mR3JhcGhpY2FsSXRlbShzdGF0ZSwgJ3hBeGlzJywgeEF4aXNJZCwgaXNQYW5vcmFtYSk7XG4gIH0gZWxzZSB7XG4gICAgYXhpcyA9IHNlbGVjdEF4aXNXaXRoU2NhbGUoc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuICAgIHRpY2tzID0gc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0oc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuICB9XG4gIHJldHVybiBnZXRCYW5kU2l6ZU9mQXhpcyhheGlzLCB0aWNrcyk7XG59O1xuZnVuY3Rpb24gZ2V0QmFyUG9zaXRpb25zKGJhckdhcCwgYmFyQ2F0ZWdvcnlHYXAsIGJhbmRTaXplLCBzaXplTGlzdCwgbWF4QmFyU2l6ZSkge1xuICB2YXIgbGVuID0gc2l6ZUxpc3QubGVuZ3RoO1xuICBpZiAobGVuIDwgMSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHJlYWxCYXJHYXAgPSBnZXRQZXJjZW50VmFsdWUoYmFyR2FwLCBiYW5kU2l6ZSwgMCwgdHJ1ZSk7XG4gIHZhciByZXN1bHQ7XG4gIHZhciBpbml0aWFsVmFsdWUgPSBbXTtcblxuICAvLyB3aGV0aGVyIGlzIGJhclNpemUgc2V0IGJ5IHVzZXJcbiAgLy8gT2theSBidXQgd2h5IGRvZXMgaXQgY2hlY2sgb25seSBmb3IgdGhlIGZpcnN0IGVsZW1lbnQ/IFdoYXQgaWYgdGhlIGZpcnN0IGVsZW1lbnQgaXMgc2V0IGJ1dCBvdGhlcnMgYXJlIG5vdD9cbiAgaWYgKGlzV2VsbEJlaGF2ZWROdW1iZXIoc2l6ZUxpc3RbMF0uYmFyU2l6ZSkpIHtcbiAgICB2YXIgdXNlRnVsbCA9IGZhbHNlO1xuICAgIHZhciBmdWxsQmFyU2l6ZSA9IGJhbmRTaXplIC8gbGVuO1xuICAgIHZhciBzdW0gPSBzaXplTGlzdC5yZWR1Y2UoKHJlcywgZW50cnkpID0+IHJlcyArIChlbnRyeS5iYXJTaXplIHx8IDApLCAwKTtcbiAgICBzdW0gKz0gKGxlbiAtIDEpICogcmVhbEJhckdhcDtcbiAgICBpZiAoc3VtID49IGJhbmRTaXplKSB7XG4gICAgICBzdW0gLT0gKGxlbiAtIDEpICogcmVhbEJhckdhcDtcbiAgICAgIHJlYWxCYXJHYXAgPSAwO1xuICAgIH1cbiAgICBpZiAoc3VtID49IGJhbmRTaXplICYmIGZ1bGxCYXJTaXplID4gMCkge1xuICAgICAgdXNlRnVsbCA9IHRydWU7XG4gICAgICBmdWxsQmFyU2l6ZSAqPSAwLjk7XG4gICAgICBzdW0gPSBsZW4gKiBmdWxsQmFyU2l6ZTtcbiAgICB9XG4gICAgdmFyIG9mZnNldCA9IChiYW5kU2l6ZSAtIHN1bSkgLyAyID4+IDA7XG4gICAgdmFyIHByZXYgPSB7XG4gICAgICBvZmZzZXQ6IG9mZnNldCAtIHJlYWxCYXJHYXAsXG4gICAgICBzaXplOiAwXG4gICAgfTtcbiAgICByZXN1bHQgPSBzaXplTGlzdC5yZWR1Y2UoKHJlcywgZW50cnkpID0+IHtcbiAgICAgIHZhciBfZW50cnkkYmFyU2l6ZTtcbiAgICAgIHZhciBuZXdQb3NpdGlvbiA9IHtcbiAgICAgICAgc3RhY2tJZDogZW50cnkuc3RhY2tJZCxcbiAgICAgICAgZGF0YUtleXM6IGVudHJ5LmRhdGFLZXlzLFxuICAgICAgICBwb3NpdGlvbjoge1xuICAgICAgICAgIG9mZnNldDogcHJldi5vZmZzZXQgKyBwcmV2LnNpemUgKyByZWFsQmFyR2FwLFxuICAgICAgICAgIHNpemU6IHVzZUZ1bGwgPyBmdWxsQmFyU2l6ZSA6IChfZW50cnkkYmFyU2l6ZSA9IGVudHJ5LmJhclNpemUpICE9PSBudWxsICYmIF9lbnRyeSRiYXJTaXplICE9PSB2b2lkIDAgPyBfZW50cnkkYmFyU2l6ZSA6IDBcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHZhciBuZXdSZXMgPSBbLi4ucmVzLCBuZXdQb3NpdGlvbl07XG4gICAgICBwcmV2ID0gbmV3UmVzW25ld1Jlcy5sZW5ndGggLSAxXS5wb3NpdGlvbjtcbiAgICAgIHJldHVybiBuZXdSZXM7XG4gICAgfSwgaW5pdGlhbFZhbHVlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgX29mZnNldCA9IGdldFBlcmNlbnRWYWx1ZShiYXJDYXRlZ29yeUdhcCwgYmFuZFNpemUsIDAsIHRydWUpO1xuICAgIGlmIChiYW5kU2l6ZSAtIDIgKiBfb2Zmc2V0IC0gKGxlbiAtIDEpICogcmVhbEJhckdhcCA8PSAwKSB7XG4gICAgICByZWFsQmFyR2FwID0gMDtcbiAgICB9XG4gICAgdmFyIG9yaWdpbmFsU2l6ZSA9IChiYW5kU2l6ZSAtIDIgKiBfb2Zmc2V0IC0gKGxlbiAtIDEpICogcmVhbEJhckdhcCkgLyBsZW47XG4gICAgaWYgKG9yaWdpbmFsU2l6ZSA+IDEpIHtcbiAgICAgIG9yaWdpbmFsU2l6ZSA+Pj0gMDtcbiAgICB9XG4gICAgdmFyIHNpemUgPSBpc1dlbGxCZWhhdmVkTnVtYmVyKG1heEJhclNpemUpID8gTWF0aC5taW4ob3JpZ2luYWxTaXplLCBtYXhCYXJTaXplKSA6IG9yaWdpbmFsU2l6ZTtcbiAgICByZXN1bHQgPSBzaXplTGlzdC5yZWR1Y2UoKHJlcywgZW50cnksIGkpID0+IFsuLi5yZXMsIHtcbiAgICAgIHN0YWNrSWQ6IGVudHJ5LnN0YWNrSWQsXG4gICAgICBkYXRhS2V5czogZW50cnkuZGF0YUtleXMsXG4gICAgICBwb3NpdGlvbjoge1xuICAgICAgICBvZmZzZXQ6IF9vZmZzZXQgKyAob3JpZ2luYWxTaXplICsgcmVhbEJhckdhcCkgKiBpICsgKG9yaWdpbmFsU2l6ZSAtIHNpemUpIC8gMixcbiAgICAgICAgc2l6ZVxuICAgICAgfVxuICAgIH1dLCBpbml0aWFsVmFsdWUpO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5leHBvcnQgdmFyIGNvbWJpbmVBbGxCYXJQb3NpdGlvbnMgPSAoc2l6ZUxpc3QsIGdsb2JhbE1heEJhclNpemUsIGJhckdhcCwgYmFyQ2F0ZWdvcnlHYXAsIGJhckJhbmRTaXplLCBiYW5kU2l6ZSwgY2hpbGRNYXhCYXJTaXplKSA9PiB7XG4gIHZhciBtYXhCYXJTaXplID0gaXNOdWxsaXNoKGNoaWxkTWF4QmFyU2l6ZSkgPyBnbG9iYWxNYXhCYXJTaXplIDogY2hpbGRNYXhCYXJTaXplO1xuICB2YXIgYWxsQmFyUG9zaXRpb25zID0gZ2V0QmFyUG9zaXRpb25zKGJhckdhcCwgYmFyQ2F0ZWdvcnlHYXAsIGJhckJhbmRTaXplICE9PSBiYW5kU2l6ZSA/IGJhckJhbmRTaXplIDogYmFuZFNpemUsIHNpemVMaXN0LCBtYXhCYXJTaXplKTtcbiAgaWYgKGJhckJhbmRTaXplICE9PSBiYW5kU2l6ZSAmJiBhbGxCYXJQb3NpdGlvbnMgIT0gbnVsbCkge1xuICAgIGFsbEJhclBvc2l0aW9ucyA9IGFsbEJhclBvc2l0aW9ucy5tYXAocG9zID0+IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcG9zKSwge30sIHtcbiAgICAgIHBvc2l0aW9uOiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHBvcy5wb3NpdGlvbiksIHt9LCB7XG4gICAgICAgIG9mZnNldDogcG9zLnBvc2l0aW9uLm9mZnNldCAtIGJhckJhbmRTaXplIC8gMlxuICAgICAgfSlcbiAgICB9KSk7XG4gIH1cbiAgcmV0dXJuIGFsbEJhclBvc2l0aW9ucztcbn07XG5leHBvcnQgdmFyIHNlbGVjdEFsbEJhclBvc2l0aW9ucyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RCYXJTaXplTGlzdCwgc2VsZWN0Um9vdE1heEJhclNpemUsIHNlbGVjdEJhckdhcCwgc2VsZWN0QmFyQ2F0ZWdvcnlHYXAsIHNlbGVjdEJhckJhbmRTaXplLCBzZWxlY3RBeGlzQmFuZFNpemUsIHNlbGVjdE1heEJhclNpemVdLCBjb21iaW5lQWxsQmFyUG9zaXRpb25zKTtcbnZhciBzZWxlY3RYQXhpc1dpdGhTY2FsZSA9IChzdGF0ZSwgeEF4aXNJZCwgX3lBeGlzSWQsIGlzUGFub3JhbWEpID0+IHNlbGVjdEF4aXNXaXRoU2NhbGUoc3RhdGUsICd4QXhpcycsIHhBeGlzSWQsIGlzUGFub3JhbWEpO1xudmFyIHNlbGVjdFlBeGlzV2l0aFNjYWxlID0gKHN0YXRlLCBfeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gc2VsZWN0QXhpc1dpdGhTY2FsZShzdGF0ZSwgJ3lBeGlzJywgeUF4aXNJZCwgaXNQYW5vcmFtYSk7XG52YXIgc2VsZWN0WEF4aXNUaWNrcyA9IChzdGF0ZSwgeEF4aXNJZCwgX3lBeGlzSWQsIGlzUGFub3JhbWEpID0+IHNlbGVjdFRpY2tzT2ZHcmFwaGljYWxJdGVtKHN0YXRlLCAneEF4aXMnLCB4QXhpc0lkLCBpc1Bhbm9yYW1hKTtcbnZhciBzZWxlY3RZQXhpc1RpY2tzID0gKHN0YXRlLCBfeEF4aXNJZCwgeUF4aXNJZCwgaXNQYW5vcmFtYSkgPT4gc2VsZWN0VGlja3NPZkdyYXBoaWNhbEl0ZW0oc3RhdGUsICd5QXhpcycsIHlBeGlzSWQsIGlzUGFub3JhbWEpO1xuZXhwb3J0IHZhciBzZWxlY3RCYXJQb3NpdGlvbiA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RBbGxCYXJQb3NpdGlvbnMsIHNlbGVjdFN5bmNocm9uaXNlZEJhclNldHRpbmdzXSwgKGFsbEJhclBvc2l0aW9ucywgYmFyU2V0dGluZ3MpID0+IHtcbiAgaWYgKGFsbEJhclBvc2l0aW9ucyA9PSBudWxsIHx8IGJhclNldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBwb3NpdGlvbiA9IGFsbEJhclBvc2l0aW9ucy5maW5kKHAgPT4gcC5zdGFja0lkID09PSBiYXJTZXR0aW5ncy5zdGFja0lkICYmIGJhclNldHRpbmdzLmRhdGFLZXkgIT0gbnVsbCAmJiBwLmRhdGFLZXlzLmluY2x1ZGVzKGJhclNldHRpbmdzLmRhdGFLZXkpKTtcbiAgaWYgKHBvc2l0aW9uID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBwb3NpdGlvbi5wb3NpdGlvbjtcbn0pO1xuZXhwb3J0IHZhciBjb21iaW5lU3RhY2tlZERhdGEgPSAoc3RhY2tHcm91cHMsIGJhclNldHRpbmdzKSA9PiB7XG4gIHZhciBzdGFja1Nlcmllc0lkZW50aWZpZXIgPSBnZXRTdGFja1Nlcmllc0lkZW50aWZpZXIoYmFyU2V0dGluZ3MpO1xuICBpZiAoIXN0YWNrR3JvdXBzIHx8IHN0YWNrU2VyaWVzSWRlbnRpZmllciA9PSBudWxsIHx8IGJhclNldHRpbmdzID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciB7XG4gICAgc3RhY2tJZFxuICB9ID0gYmFyU2V0dGluZ3M7XG4gIGlmIChzdGFja0lkID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBzdGFja0dyb3VwID0gc3RhY2tHcm91cHNbc3RhY2tJZF07XG4gIGlmICghc3RhY2tHcm91cCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHtcbiAgICBzdGFja2VkRGF0YVxuICB9ID0gc3RhY2tHcm91cDtcbiAgaWYgKCFzdGFja2VkRGF0YSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHN0YWNrZWREYXRhLmZpbmQoc2QgPT4gc2Qua2V5ID09PSBzdGFja1Nlcmllc0lkZW50aWZpZXIpO1xufTtcbnZhciBzZWxlY3RTdGFja2VkRGF0YU9mSXRlbSA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RCYXJTdGFja0dyb3Vwcywgc2VsZWN0U3luY2hyb25pc2VkQmFyU2V0dGluZ3NdLCBjb21iaW5lU3RhY2tlZERhdGEpO1xuZXhwb3J0IHZhciBzZWxlY3RCYXJSZWN0YW5nbGVzID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwsIHNlbGVjdEF4aXNWaWV3Qm94LCBzZWxlY3RYQXhpc1dpdGhTY2FsZSwgc2VsZWN0WUF4aXNXaXRoU2NhbGUsIHNlbGVjdFhBeGlzVGlja3MsIHNlbGVjdFlBeGlzVGlja3MsIHNlbGVjdEJhclBvc2l0aW9uLCBzZWxlY3RDaGFydExheW91dCwgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEsIHNlbGVjdEF4aXNCYW5kU2l6ZSwgc2VsZWN0U3RhY2tlZERhdGFPZkl0ZW0sIHNlbGVjdFN5bmNocm9uaXNlZEJhclNldHRpbmdzLCBwaWNrQ2VsbHNdLCAob2Zmc2V0LCBheGlzVmlld0JveCwgeEF4aXMsIHlBeGlzLCB4QXhpc1RpY2tzLCB5QXhpc1RpY2tzLCBwb3MsIGxheW91dCwgX3JlZjMsIGJhbmRTaXplLCBzdGFja2VkRGF0YSwgYmFyU2V0dGluZ3MsIGNlbGxzKSA9PiB7XG4gIHZhciB7XG4gICAgY2hhcnREYXRhLFxuICAgIGRhdGFTdGFydEluZGV4LFxuICAgIGRhdGFFbmRJbmRleFxuICB9ID0gX3JlZjM7XG4gIGlmIChiYXJTZXR0aW5ncyA9PSBudWxsIHx8IHBvcyA9PSBudWxsIHx8IGF4aXNWaWV3Qm94ID09IG51bGwgfHwgbGF5b3V0ICE9PSAnaG9yaXpvbnRhbCcgJiYgbGF5b3V0ICE9PSAndmVydGljYWwnIHx8IHhBeGlzID09IG51bGwgfHwgeUF4aXMgPT0gbnVsbCB8fCB4QXhpc1RpY2tzID09IG51bGwgfHwgeUF4aXNUaWNrcyA9PSBudWxsIHx8IGJhbmRTaXplID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciB7XG4gICAgZGF0YVxuICB9ID0gYmFyU2V0dGluZ3M7XG4gIHZhciBkaXNwbGF5ZWREYXRhO1xuICBpZiAoZGF0YSAhPSBudWxsICYmIGRhdGEubGVuZ3RoID4gMCkge1xuICAgIGRpc3BsYXllZERhdGEgPSBkYXRhO1xuICB9IGVsc2Uge1xuICAgIGRpc3BsYXllZERhdGEgPSBjaGFydERhdGEgPT09IG51bGwgfHwgY2hhcnREYXRhID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjaGFydERhdGEuc2xpY2UoZGF0YVN0YXJ0SW5kZXgsIGRhdGFFbmRJbmRleCArIDEpO1xuICB9XG4gIGlmIChkaXNwbGF5ZWREYXRhID09IG51bGwpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBjb21wdXRlQmFyUmVjdGFuZ2xlcyh7XG4gICAgbGF5b3V0LFxuICAgIGJhclNldHRpbmdzLFxuICAgIHBvcyxcbiAgICBwYXJlbnRWaWV3Qm94OiBheGlzVmlld0JveCxcbiAgICBiYW5kU2l6ZSxcbiAgICB4QXhpcyxcbiAgICB5QXhpcyxcbiAgICB4QXhpc1RpY2tzLFxuICAgIHlBeGlzVGlja3MsXG4gICAgc3RhY2tlZERhdGEsXG4gICAgZGlzcGxheWVkRGF0YSxcbiAgICBvZmZzZXQsXG4gICAgY2VsbHNcbiAgfSk7XG59KTsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCB7IHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwgfSBmcm9tICcuL3NlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwnO1xuaW1wb3J0IHsgc2VsZWN0TWFyZ2luIH0gZnJvbSAnLi9jb250YWluZXJTZWxlY3RvcnMnO1xuaW1wb3J0IHsgaXNOdW1iZXIgfSBmcm9tICcuLi8uLi91dGlsL0RhdGFVdGlscyc7XG5leHBvcnQgdmFyIHNlbGVjdEJydXNoU2V0dGluZ3MgPSBzdGF0ZSA9PiBzdGF0ZS5icnVzaDtcbmV4cG9ydCB2YXIgc2VsZWN0QnJ1c2hEaW1lbnNpb25zID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdEJydXNoU2V0dGluZ3MsIHNlbGVjdENoYXJ0T2Zmc2V0SW50ZXJuYWwsIHNlbGVjdE1hcmdpbl0sIChicnVzaFNldHRpbmdzLCBvZmZzZXQsIG1hcmdpbikgPT4gKHtcbiAgaGVpZ2h0OiBicnVzaFNldHRpbmdzLmhlaWdodCxcbiAgeDogaXNOdW1iZXIoYnJ1c2hTZXR0aW5ncy54KSA/IGJydXNoU2V0dGluZ3MueCA6IG9mZnNldC5sZWZ0LFxuICB5OiBpc051bWJlcihicnVzaFNldHRpbmdzLnkpID8gYnJ1c2hTZXR0aW5ncy55IDogb2Zmc2V0LnRvcCArIG9mZnNldC5oZWlnaHQgKyBvZmZzZXQuYnJ1c2hCb3R0b20gLSAoKG1hcmdpbiA9PT0gbnVsbCB8fCBtYXJnaW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IG1hcmdpbi5ib3R0b20pIHx8IDApLFxuICB3aWR0aDogaXNOdW1iZXIoYnJ1c2hTZXR0aW5ncy53aWR0aCkgPyBicnVzaFNldHRpbmdzLndpZHRoIDogb2Zmc2V0LndpZHRoXG59KSk7IiwiZXhwb3J0IHZhciBwaWNrQXhpc0lkID0gKF9zdGF0ZSwgX2F4aXNUeXBlLCBheGlzSWQpID0+IGF4aXNJZDsiLCJ2YXIgX2V4Y2x1ZGVkID0gW1wib3B0aW9uXCIsIFwic2hhcGVUeXBlXCIsIFwicHJvcFRyYW5zZm9ybWVyXCIsIFwiYWN0aXZlQ2xhc3NOYW1lXCIsIFwiaXNBY3RpdmVcIl07XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoZSwgdCkgeyBpZiAobnVsbCA9PSBlKSByZXR1cm4ge307IHZhciBvLCByLCBpID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoZSwgdCk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBuID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgZm9yIChyID0gMDsgciA8IG4ubGVuZ3RoOyByKyspIG8gPSBuW3JdLCAtMSA9PT0gdC5pbmRleE9mKG8pICYmIHt9LnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoZSwgbykgJiYgKGlbb10gPSBlW29dKTsgfSByZXR1cm4gaTsgfVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkgeyBpZiAobnVsbCA9PSByKSByZXR1cm4ge307IHZhciB0ID0ge307IGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHsgaWYgKC0xICE9PSBlLmluZGV4T2YobikpIGNvbnRpbnVlOyB0W25dID0gcltuXTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCAhMCkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IHR5cGVvZiBpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgdCB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpOyBpZiAoXCJvYmplY3RcIiAhPSB0eXBlb2YgaSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjbG9uZUVsZW1lbnQsIGlzVmFsaWRFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGlzUGxhaW5PYmplY3QgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvaXNQbGFpbk9iamVjdCc7XG5pbXBvcnQgeyBSZWN0YW5nbGUgfSBmcm9tICcuLi9zaGFwZS9SZWN0YW5nbGUnO1xuaW1wb3J0IHsgVHJhcGV6b2lkIH0gZnJvbSAnLi4vc2hhcGUvVHJhcGV6b2lkJztcbmltcG9ydCB7IFNlY3RvciB9IGZyb20gJy4uL3NoYXBlL1NlY3Rvcic7XG5pbXBvcnQgeyBMYXllciB9IGZyb20gJy4uL2NvbnRhaW5lci9MYXllcic7XG5pbXBvcnQgeyBTeW1ib2xzIH0gZnJvbSAnLi4vc2hhcGUvU3ltYm9scyc7XG5cbi8qKlxuICogVGhpcyBpcyBhbiBhYnN0cmFjdGlvbiBmb3IgcmVuZGVyaW5nIGEgdXNlciBkZWZpbmVkIHByb3AgZm9yIGEgY3VzdG9taXplZCBzaGFwZSBpbiBzZXZlcmFsIGZvcm1zLlxuICpcbiAqIDxTaGFwZSAvPiBpcyB0aGUgcm9vdCBhbmQgd2lsbCBoYW5kbGUgdGFraW5nIGluOlxuICogIC0gYW4gb2JqZWN0IG9mIHN2ZyBwcm9wZXJ0aWVzXG4gKiAgLSBhIGJvb2xlYW5cbiAqICAtIGEgcmVuZGVyIHByb3AoaW5saW5lIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBqc3gpXG4gKiAgLSBhIFJlYWN0IGVsZW1lbnRcbiAqXG4gKiA8U2hhcGVTZWxlY3RvciAvPiBpcyBhIHN1YmNvbXBvbmVudCBvZiA8U2hhcGUgLz4gYW5kIHVzZWQgdG8gbWF0Y2ggYSBjb21wb25lbnRcbiAqIHRvIHRoZSB2YWx1ZSBvZiBwcm9wcy5zaGFwZVR5cGUgdGhhdCBpcyBwYXNzZWQgdG8gdGhlIHJvb3QuXG4gKlxuICovXG5cbmZ1bmN0aW9uIGRlZmF1bHRQcm9wVHJhbnNmb3JtZXIob3B0aW9uLCBwcm9wcykge1xuICByZXR1cm4gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBwcm9wcyksIG9wdGlvbik7XG59XG5mdW5jdGlvbiBpc1N5bWJvbHNQcm9wcyhzaGFwZVR5cGUsIF9lbGVtZW50UHJvcHMpIHtcbiAgcmV0dXJuIHNoYXBlVHlwZSA9PT0gJ3N5bWJvbHMnO1xufVxuZnVuY3Rpb24gU2hhcGVTZWxlY3RvcihfcmVmKSB7XG4gIHZhciB7XG4gICAgc2hhcGVUeXBlLFxuICAgIGVsZW1lbnRQcm9wc1xuICB9ID0gX3JlZjtcbiAgc3dpdGNoIChzaGFwZVR5cGUpIHtcbiAgICBjYXNlICdyZWN0YW5nbGUnOlxuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJlY3RhbmdsZSwgZWxlbWVudFByb3BzKTtcbiAgICBjYXNlICd0cmFwZXpvaWQnOlxuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFRyYXBlem9pZCwgZWxlbWVudFByb3BzKTtcbiAgICBjYXNlICdzZWN0b3InOlxuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFNlY3RvciwgZWxlbWVudFByb3BzKTtcbiAgICBjYXNlICdzeW1ib2xzJzpcbiAgICAgIGlmIChpc1N5bWJvbHNQcm9wcyhzaGFwZVR5cGUsIGVsZW1lbnRQcm9wcykpIHtcbiAgICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFN5bWJvbHMsIGVsZW1lbnRQcm9wcyk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcm9wc0Zyb21TaGFwZU9wdGlvbihvcHRpb24pIHtcbiAgaWYgKC8qI19fUFVSRV9fKi9pc1ZhbGlkRWxlbWVudChvcHRpb24pKSB7XG4gICAgcmV0dXJuIG9wdGlvbi5wcm9wcztcbiAgfVxuICByZXR1cm4gb3B0aW9uO1xufVxuZXhwb3J0IGZ1bmN0aW9uIFNoYXBlKF9yZWYyKSB7XG4gIHZhciB7XG4gICAgICBvcHRpb24sXG4gICAgICBzaGFwZVR5cGUsXG4gICAgICBwcm9wVHJhbnNmb3JtZXIgPSBkZWZhdWx0UHJvcFRyYW5zZm9ybWVyLFxuICAgICAgYWN0aXZlQ2xhc3NOYW1lID0gJ3JlY2hhcnRzLWFjdGl2ZS1zaGFwZScsXG4gICAgICBpc0FjdGl2ZVxuICAgIH0gPSBfcmVmMixcbiAgICBwcm9wcyA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllcyhfcmVmMiwgX2V4Y2x1ZGVkKTtcbiAgdmFyIHNoYXBlO1xuICBpZiAoLyojX19QVVJFX18qL2lzVmFsaWRFbGVtZW50KG9wdGlvbikpIHtcbiAgICBzaGFwZSA9IC8qI19fUFVSRV9fKi9jbG9uZUVsZW1lbnQob3B0aW9uLCBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHByb3BzKSwgZ2V0UHJvcHNGcm9tU2hhcGVPcHRpb24ob3B0aW9uKSkpO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBvcHRpb24gPT09ICdmdW5jdGlvbicpIHtcbiAgICBzaGFwZSA9IG9wdGlvbihwcm9wcyk7XG4gIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdChvcHRpb24pICYmIHR5cGVvZiBvcHRpb24gIT09ICdib29sZWFuJykge1xuICAgIHZhciBuZXh0UHJvcHMgPSBwcm9wVHJhbnNmb3JtZXIob3B0aW9uLCBwcm9wcyk7XG4gICAgc2hhcGUgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChTaGFwZVNlbGVjdG9yLCB7XG4gICAgICBzaGFwZVR5cGU6IHNoYXBlVHlwZSxcbiAgICAgIGVsZW1lbnRQcm9wczogbmV4dFByb3BzXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIGVsZW1lbnRQcm9wcyA9IHByb3BzO1xuICAgIHNoYXBlID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoU2hhcGVTZWxlY3Rvciwge1xuICAgICAgc2hhcGVUeXBlOiBzaGFwZVR5cGUsXG4gICAgICBlbGVtZW50UHJvcHM6IGVsZW1lbnRQcm9wc1xuICAgIH0pO1xuICB9XG4gIGlmIChpc0FjdGl2ZSkge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMYXllciwge1xuICAgICAgY2xhc3NOYW1lOiBhY3RpdmVDbGFzc05hbWVcbiAgICB9LCBzaGFwZSk7XG4gIH1cbiAgcmV0dXJuIHNoYXBlO1xufSIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuaW1wb3J0IHsgR2xvYmFsIH0gZnJvbSAnLi9HbG9iYWwnO1xuaW1wb3J0IHsgTFJVQ2FjaGUgfSBmcm9tICcuL0xSVUNhY2hlJztcbnZhciBkZWZhdWx0Q29uZmlnID0ge1xuICBjYWNoZVNpemU6IDIwMDAsXG4gIGVuYWJsZUNhY2hlOiB0cnVlXG59O1xudmFyIGN1cnJlbnRDb25maWcgPSBfb2JqZWN0U3ByZWFkKHt9LCBkZWZhdWx0Q29uZmlnKTtcbnZhciBzdHJpbmdDYWNoZSA9IG5ldyBMUlVDYWNoZShjdXJyZW50Q29uZmlnLmNhY2hlU2l6ZSk7XG52YXIgU1BBTl9TVFlMRSA9IHtcbiAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gIHRvcDogJy0yMDAwMHB4JyxcbiAgbGVmdDogMCxcbiAgcGFkZGluZzogMCxcbiAgbWFyZ2luOiAwLFxuICBib3JkZXI6ICdub25lJyxcbiAgd2hpdGVTcGFjZTogJ3ByZSdcbn07XG52YXIgTUVBU1VSRU1FTlRfU1BBTl9JRCA9ICdyZWNoYXJ0c19tZWFzdXJlbWVudF9zcGFuJztcbmZ1bmN0aW9uIGNyZWF0ZUNhY2hlS2V5KHRleHQsIHN0eWxlKSB7XG4gIC8vIFNpbXBsZSBzdHJpbmcgY29uY2F0ZW5hdGlvbiBmb3IgYmV0dGVyIHBlcmZvcm1hbmNlIHRoYW4gSlNPTi5zdHJpbmdpZnlcbiAgdmFyIGZvbnRTaXplID0gc3R5bGUuZm9udFNpemUgfHwgJyc7XG4gIHZhciBmb250RmFtaWx5ID0gc3R5bGUuZm9udEZhbWlseSB8fCAnJztcbiAgdmFyIGZvbnRXZWlnaHQgPSBzdHlsZS5mb250V2VpZ2h0IHx8ICcnO1xuICB2YXIgZm9udFN0eWxlID0gc3R5bGUuZm9udFN0eWxlIHx8ICcnO1xuICB2YXIgbGV0dGVyU3BhY2luZyA9IHN0eWxlLmxldHRlclNwYWNpbmcgfHwgJyc7XG4gIHZhciB0ZXh0VHJhbnNmb3JtID0gc3R5bGUudGV4dFRyYW5zZm9ybSB8fCAnJztcbiAgcmV0dXJuIFwiXCIuY29uY2F0KHRleHQsIFwifFwiKS5jb25jYXQoZm9udFNpemUsIFwifFwiKS5jb25jYXQoZm9udEZhbWlseSwgXCJ8XCIpLmNvbmNhdChmb250V2VpZ2h0LCBcInxcIikuY29uY2F0KGZvbnRTdHlsZSwgXCJ8XCIpLmNvbmNhdChsZXR0ZXJTcGFjaW5nLCBcInxcIikuY29uY2F0KHRleHRUcmFuc2Zvcm0pO1xufVxuXG4vKipcbiAqIE1lYXN1cmUgdGV4dCB1c2luZyBET00gKGFjY3VyYXRlIGJ1dCBzbG93ZXIpXG4gKiBAcGFyYW0gdGV4dCAtIFRoZSB0ZXh0IHRvIG1lYXN1cmVcbiAqIEBwYXJhbSBzdHlsZSAtIENTUyBzdHlsZSBwcm9wZXJ0aWVzIHRvIGFwcGx5XG4gKiBAcmV0dXJucyBUaGUgc2l6ZSBvZiB0aGUgdGV4dFxuICovXG52YXIgbWVhc3VyZVRleHRXaXRoRE9NID0gKHRleHQsIHN0eWxlKSA9PiB7XG4gIHRyeSB7XG4gICAgdmFyIG1lYXN1cmVtZW50U3BhbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKE1FQVNVUkVNRU5UX1NQQU5fSUQpO1xuICAgIGlmICghbWVhc3VyZW1lbnRTcGFuKSB7XG4gICAgICBtZWFzdXJlbWVudFNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgICBtZWFzdXJlbWVudFNwYW4uc2V0QXR0cmlidXRlKCdpZCcsIE1FQVNVUkVNRU5UX1NQQU5fSUQpO1xuICAgICAgbWVhc3VyZW1lbnRTcGFuLnNldEF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nLCAndHJ1ZScpO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChtZWFzdXJlbWVudFNwYW4pO1xuICAgIH1cblxuICAgIC8vIEFwcGx5IHN0eWxlcyBkaXJlY3RseSB3aXRob3V0IHVubmVjZXNzYXJ5IG9iamVjdCBjcmVhdGlvblxuICAgIE9iamVjdC5hc3NpZ24obWVhc3VyZW1lbnRTcGFuLnN0eWxlLCBTUEFOX1NUWUxFLCBzdHlsZSk7XG4gICAgbWVhc3VyZW1lbnRTcGFuLnRleHRDb250ZW50ID0gXCJcIi5jb25jYXQodGV4dCk7XG4gICAgdmFyIHJlY3QgPSBtZWFzdXJlbWVudFNwYW4uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHdpZHRoOiByZWN0LndpZHRoLFxuICAgICAgaGVpZ2h0OiByZWN0LmhlaWdodFxuICAgIH07XG4gIH0gY2F0Y2ggKF91bnVzZWQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgd2lkdGg6IDAsXG4gICAgICBoZWlnaHQ6IDBcbiAgICB9O1xuICB9XG59O1xuZXhwb3J0IHZhciBnZXRTdHJpbmdTaXplID0gZnVuY3Rpb24gZ2V0U3RyaW5nU2l6ZSh0ZXh0KSB7XG4gIHZhciBzdHlsZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDoge307XG4gIGlmICh0ZXh0ID09PSB1bmRlZmluZWQgfHwgdGV4dCA9PT0gbnVsbCB8fCBHbG9iYWwuaXNTc3IpIHtcbiAgICByZXR1cm4ge1xuICAgICAgd2lkdGg6IDAsXG4gICAgICBoZWlnaHQ6IDBcbiAgICB9O1xuICB9XG5cbiAgLy8gSWYgY2FjaGluZyBpcyBkaXNhYmxlZCwgbWVhc3VyZSBkaXJlY3RseVxuICBpZiAoIWN1cnJlbnRDb25maWcuZW5hYmxlQ2FjaGUpIHtcbiAgICByZXR1cm4gbWVhc3VyZVRleHRXaXRoRE9NKHRleHQsIHN0eWxlKTtcbiAgfVxuICB2YXIgY2FjaGVLZXkgPSBjcmVhdGVDYWNoZUtleSh0ZXh0LCBzdHlsZSk7XG4gIHZhciBjYWNoZWRSZXN1bHQgPSBzdHJpbmdDYWNoZS5nZXQoY2FjaGVLZXkpO1xuICBpZiAoY2FjaGVkUmVzdWx0KSB7XG4gICAgcmV0dXJuIGNhY2hlZFJlc3VsdDtcbiAgfVxuXG4gIC8vIE1lYXN1cmUgdXNpbmcgRE9NXG4gIHZhciByZXN1bHQgPSBtZWFzdXJlVGV4dFdpdGhET00odGV4dCwgc3R5bGUpO1xuXG4gIC8vIFN0b3JlIGluIExSVSBjYWNoZVxuICBzdHJpbmdDYWNoZS5zZXQoY2FjaGVLZXksIHJlc3VsdCk7XG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG4vKipcbiAqIENvbmZpZ3VyZSB0ZXh0IG1lYXN1cmVtZW50IGJlaGF2aW9yXG4gKiBAcGFyYW0gY29uZmlnIC0gUGFydGlhbCBjb25maWd1cmF0aW9uIHRvIGFwcGx5XG4gKiBAcmV0dXJucyB2b2lkXG4gKi9cbmV4cG9ydCB2YXIgY29uZmlndXJlVGV4dE1lYXN1cmVtZW50ID0gY29uZmlnID0+IHtcbiAgdmFyIG5ld0NvbmZpZyA9IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgY3VycmVudENvbmZpZyksIGNvbmZpZyk7XG4gIGlmIChuZXdDb25maWcuY2FjaGVTaXplICE9PSBjdXJyZW50Q29uZmlnLmNhY2hlU2l6ZSkge1xuICAgIHN0cmluZ0NhY2hlID0gbmV3IExSVUNhY2hlKG5ld0NvbmZpZy5jYWNoZVNpemUpO1xuICB9XG4gIGN1cnJlbnRDb25maWcgPSBuZXdDb25maWc7XG59O1xuXG4vKipcbiAqIEdldCBjdXJyZW50IHRleHQgbWVhc3VyZW1lbnQgY29uZmlndXJhdGlvblxuICogQHJldHVybnMgQ3VycmVudCBjb25maWd1cmF0aW9uXG4gKi9cbmV4cG9ydCB2YXIgZ2V0VGV4dE1lYXN1cmVtZW50Q29uZmlnID0gKCkgPT4gX29iamVjdFNwcmVhZCh7fSwgY3VycmVudENvbmZpZyk7XG5cbi8qKlxuICogQ2xlYXIgdGhlIHN0cmluZyBzaXplIGNhY2hlLiBVc2VmdWwgZm9yIHRlc3Rpbmcgb3IgbWVtb3J5IG1hbmFnZW1lbnQuXG4gKiBAcmV0dXJucyB2b2lkXG4gKi9cbmV4cG9ydCB2YXIgY2xlYXJTdHJpbmdDYWNoZSA9ICgpID0+IHtcbiAgc3RyaW5nQ2FjaGUuY2xlYXIoKTtcbn07XG5cbi8qKlxuICogR2V0IGNhY2hlIHN0YXRpc3RpY3MgZm9yIGRlYnVnZ2luZyBwdXJwb3Nlcy5cbiAqIEByZXR1cm5zIENhY2hlIHN0YXRpc3RpY3MgaW5jbHVkaW5nIHNpemUgYW5kIG1heCBzaXplXG4gKi9cbmV4cG9ydCB2YXIgZ2V0U3RyaW5nQ2FjaGVTdGF0cyA9ICgpID0+ICh7XG4gIHNpemU6IHN0cmluZ0NhY2hlLnNpemUoKSxcbiAgbWF4U2l6ZTogY3VycmVudENvbmZpZy5jYWNoZVNpemVcbn0pOyIsImV4cG9ydCB2YXIgc2VsZWN0Um9vdE1heEJhclNpemUgPSBzdGF0ZSA9PiBzdGF0ZS5yb290UHJvcHMubWF4QmFyU2l6ZTtcbmV4cG9ydCB2YXIgc2VsZWN0QmFyR2FwID0gc3RhdGUgPT4gc3RhdGUucm9vdFByb3BzLmJhckdhcDtcbmV4cG9ydCB2YXIgc2VsZWN0QmFyQ2F0ZWdvcnlHYXAgPSBzdGF0ZSA9PiBzdGF0ZS5yb290UHJvcHMuYmFyQ2F0ZWdvcnlHYXA7XG5leHBvcnQgdmFyIHNlbGVjdFJvb3RCYXJTaXplID0gc3RhdGUgPT4gc3RhdGUucm9vdFByb3BzLmJhclNpemU7XG5leHBvcnQgdmFyIHNlbGVjdFN0YWNrT2Zmc2V0VHlwZSA9IHN0YXRlID0+IHN0YXRlLnJvb3RQcm9wcy5zdGFja09mZnNldDtcbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnROYW1lID0gc3RhdGUgPT4gc3RhdGUub3B0aW9ucy5jaGFydE5hbWU7XG5leHBvcnQgdmFyIHNlbGVjdFN5bmNJZCA9IHN0YXRlID0+IHN0YXRlLnJvb3RQcm9wcy5zeW5jSWQ7XG5leHBvcnQgdmFyIHNlbGVjdFN5bmNNZXRob2QgPSBzdGF0ZSA9PiBzdGF0ZS5yb290UHJvcHMuc3luY01ldGhvZDtcbmV4cG9ydCB2YXIgc2VsZWN0RXZlbnRFbWl0dGVyID0gc3RhdGUgPT4gc3RhdGUub3B0aW9ucy5ldmVudEVtaXR0ZXI7IiwiZXhwb3J0IHZhciBzZWxlY3RUb29sdGlwQXhpc0lkID0gc3RhdGUgPT4gc3RhdGUudG9vbHRpcC5zZXR0aW5ncy5heGlzSWQ7IiwiaW1wb3J0IHsgZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyIH0gZnJvbSAnLi4vLi4vLi4vdXRpbC9zdGFja3MvZ2V0U3RhY2tTZXJpZXNJZGVudGlmaWVyJztcbmltcG9ydCB7IGdldFZhbHVlQnlEYXRhS2V5IH0gZnJvbSAnLi4vLi4vLi4vdXRpbC9DaGFydFV0aWxzJztcblxuLyoqXG4gKiBJbiBhIHN0YWNrZWQgY2hhcnQsIGVhY2ggZ3JhcGhpY2FsIGl0ZW0gaGFzIGl0cyBvd24gZGF0YS4gVGhhdCBkYXRhIGNvdWxkIGJlIGVpdGhlcjpcbiAqIC0gZGVmaW5lZCBvbiB0aGUgY2hhcnQgcm9vdCwgaW4gd2hpY2ggY2FzZSB0aGUgaXRlbSBnZXRzIGEgdW5pcXVlIGRhdGFLZXlcbiAqIC0gb3IgZGVmaW5lZCBvbiB0aGUgaXRlbSBpdHNlbGYsIGluIHdoaWNoIGNhc2UgbXVsdGlwbGUgaXRlbXMgY2FuIHNoYXJlIHRoZSBzYW1lIGRhdGFLZXlcbiAqXG4gKiBUaGF0IG1lYW5zIHdlIGNhbm5vdCB1c2UgdGhlIGRhdGFLZXkgYXMgYSB1bmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIGl0ZW0uXG4gKlxuICogVGhpcyB0eXBlIHJlcHJlc2VudHMgYSBzaW5nbGUgZGF0YSBwb2ludCBpbiBhIHN0YWNrZWQgY2hhcnQsIHdoZXJlIGVhY2gga2V5IGlzIGEgc2VyaWVzIGlkZW50aWZpZXJcbiAqIGFuZCB0aGUgdmFsdWUgaXMgdGhlIG51bWVyaWMgdmFsdWUgZm9yIHRoYXQgc2VyaWVzIHVzaW5nIHRoZSBudW1lcmljYWwgYXhpcyBkYXRhS2V5LlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lRGlzcGxheWVkU3RhY2tlZERhdGEoc3RhY2tlZEdyYXBoaWNhbEl0ZW1zLCBfcmVmLCB0b29sdGlwQXhpc1NldHRpbmdzKSB7XG4gIHZhciB7XG4gICAgY2hhcnREYXRhID0gW11cbiAgfSA9IF9yZWY7XG4gIHZhciB7XG4gICAgYWxsb3dEdXBsaWNhdGVkQ2F0ZWdvcnksXG4gICAgZGF0YUtleTogdG9vbHRpcERhdGFLZXlcbiAgfSA9IHRvb2x0aXBBeGlzU2V0dGluZ3M7XG5cbiAgLy8gQSBtYXAgb2YgdG9vbHRpcCBkYXRhIGtleXMgdG8gdGhlIHN0YWNrZWQgZGF0YSBwb2ludHNcbiAgdmFyIGtub3duSXRlbXNCeURhdGFLZXkgPSBuZXcgTWFwKCk7XG4gIHN0YWNrZWRHcmFwaGljYWxJdGVtcy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgIHZhciBfaXRlbSRkYXRhO1xuICAgIC8vIElmIHRoZXJlIGlzIG5vIGRhdGEgb24gdGhlIGluZGl2aWR1YWwgaXRlbSB0aGVuIHdlIHVzZSB0aGUgcm9vdCBjaGFydCBkYXRhXG4gICAgdmFyIHJlc29sdmVkRGF0YSA9IChfaXRlbSRkYXRhID0gaXRlbS5kYXRhKSAhPT0gbnVsbCAmJiBfaXRlbSRkYXRhICE9PSB2b2lkIDAgPyBfaXRlbSRkYXRhIDogY2hhcnREYXRhO1xuICAgIGlmIChyZXNvbHZlZERhdGEgPT0gbnVsbCB8fCByZXNvbHZlZERhdGEubGVuZ3RoID09PSAwKSB7XG4gICAgICAvLyBpZiB0aGF0IGRpZG4ndCB3b3JrIHRoZW4gd2Ugc2tpcCB0aGlzIGl0ZW1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIHN0YWNrSWRlbnRpZmllciA9IGdldFN0YWNrU2VyaWVzSWRlbnRpZmllcihpdGVtKTtcbiAgICByZXNvbHZlZERhdGEuZm9yRWFjaCgoZW50cnksIGluZGV4KSA9PiB7XG4gICAgICB2YXIgdG9vbHRpcFZhbHVlID0gdG9vbHRpcERhdGFLZXkgPT0gbnVsbCB8fCBhbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeSA/IGluZGV4IDogU3RyaW5nKGdldFZhbHVlQnlEYXRhS2V5KGVudHJ5LCB0b29sdGlwRGF0YUtleSwgbnVsbCkpO1xuICAgICAgdmFyIG51bWVyaWNWYWx1ZSA9IGdldFZhbHVlQnlEYXRhS2V5KGVudHJ5LCBpdGVtLmRhdGFLZXksIDApO1xuICAgICAgdmFyIGN1cnI7XG4gICAgICBpZiAoa25vd25JdGVtc0J5RGF0YUtleS5oYXModG9vbHRpcFZhbHVlKSkge1xuICAgICAgICBjdXJyID0ga25vd25JdGVtc0J5RGF0YUtleS5nZXQodG9vbHRpcFZhbHVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGN1cnIgPSB7fTtcbiAgICAgIH1cbiAgICAgIE9iamVjdC5hc3NpZ24oY3Vyciwge1xuICAgICAgICBbc3RhY2tJZGVudGlmaWVyXTogbnVtZXJpY1ZhbHVlXG4gICAgICB9KTtcbiAgICAgIGtub3duSXRlbXNCeURhdGFLZXkuc2V0KHRvb2x0aXBWYWx1ZSwgY3Vycik7XG4gICAgfSk7XG4gIH0pO1xuICByZXR1cm4gQXJyYXkuZnJvbShrbm93bkl0ZW1zQnlEYXRhS2V5LnZhbHVlcygpKTtcbn0iLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0JztcbmltcG9ydCBzb3J0QnkgZnJvbSAnZXMtdG9vbGtpdC9jb21wYXQvc29ydEJ5JztcbmltcG9ydCB7IHVzZUFwcFNlbGVjdG9yIH0gZnJvbSAnLi4vaG9va3MnO1xuaW1wb3J0IHsgY2FsY3VsYXRlQWN0aXZlVGlja0luZGV4LCBjYWxjdWxhdGVUb29sdGlwUG9zLCBnZXRBY3RpdmVDb29yZGluYXRlLCBpblJhbmdlIH0gZnJvbSAnLi4vLi4vdXRpbC9DaGFydFV0aWxzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0RGF0YVdpdGhJbmRleGVzIH0gZnJvbSAnLi9kYXRhU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBBeGlzVGlja3MsIHNlbGVjdFRvb2x0aXBEaXNwbGF5ZWREYXRhIH0gZnJvbSAnLi90b29sdGlwU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0TmFtZSB9IGZyb20gJy4vcm9vdFByb3BzU2VsZWN0b3JzJztcbmltcG9ydCB7IHNlbGVjdENoYXJ0TGF5b3V0IH0gZnJvbSAnLi4vLi4vY29udGV4dC9jaGFydExheW91dENvbnRleHQnO1xuaW1wb3J0IHsgc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCB9IGZyb20gJy4vc2VsZWN0Q2hhcnRPZmZzZXRJbnRlcm5hbCc7XG5pbXBvcnQgeyBzZWxlY3RDaGFydEhlaWdodCwgc2VsZWN0Q2hhcnRXaWR0aCB9IGZyb20gJy4vY29udGFpbmVyU2VsZWN0b3JzJztcbmltcG9ydCB7IGNvbWJpbmVBY3RpdmVMYWJlbCB9IGZyb20gJy4vY29tYmluZXJzL2NvbWJpbmVBY3RpdmVMYWJlbCc7XG5pbXBvcnQgeyBjb21iaW5lVG9vbHRpcEludGVyYWN0aW9uU3RhdGUgfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lVG9vbHRpcEludGVyYWN0aW9uU3RhdGUnO1xuaW1wb3J0IHsgY29tYmluZUFjdGl2ZVRvb2x0aXBJbmRleCB9IGZyb20gJy4vY29tYmluZXJzL2NvbWJpbmVBY3RpdmVUb29sdGlwSW5kZXgnO1xuaW1wb3J0IHsgY29tYmluZUNvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXggfSBmcm9tICcuL2NvbWJpbmVycy9jb21iaW5lQ29vcmRpbmF0ZUZvckRlZmF1bHRJbmRleCc7XG5pbXBvcnQgeyBjb21iaW5lVG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9ucyB9IGZyb20gJy4vY29tYmluZXJzL2NvbWJpbmVUb29sdGlwUGF5bG9hZENvbmZpZ3VyYXRpb25zJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBQYXlsb2FkU2VhcmNoZXIgfSBmcm9tICcuL3NlbGVjdFRvb2x0aXBQYXlsb2FkU2VhcmNoZXInO1xuaW1wb3J0IHsgc2VsZWN0VG9vbHRpcFN0YXRlIH0gZnJvbSAnLi9zZWxlY3RUb29sdGlwU3RhdGUnO1xuaW1wb3J0IHsgY29tYmluZVRvb2x0aXBQYXlsb2FkIH0gZnJvbSAnLi9jb21iaW5lcnMvY29tYmluZVRvb2x0aXBQYXlsb2FkJztcbmltcG9ydCB7IHNlbGVjdFRvb2x0aXBBeGlzRGF0YUtleSB9IGZyb20gJy4vc2VsZWN0VG9vbHRpcEF4aXMnO1xuZXhwb3J0IHZhciB1c2VDaGFydE5hbWUgPSAoKSA9PiB7XG4gIHJldHVybiB1c2VBcHBTZWxlY3RvcihzZWxlY3RDaGFydE5hbWUpO1xufTtcbnZhciBwaWNrVG9vbHRpcEV2ZW50VHlwZSA9IChfc3RhdGUsIHRvb2x0aXBFdmVudFR5cGUpID0+IHRvb2x0aXBFdmVudFR5cGU7XG52YXIgcGlja1RyaWdnZXIgPSAoX3N0YXRlLCBfdG9vbHRpcEV2ZW50VHlwZSwgdHJpZ2dlcikgPT4gdHJpZ2dlcjtcbnZhciBwaWNrRGVmYXVsdEluZGV4ID0gKF9zdGF0ZSwgX3Rvb2x0aXBFdmVudFR5cGUsIF90cmlnZ2VyLCBkZWZhdWx0SW5kZXgpID0+IGRlZmF1bHRJbmRleDtcbmV4cG9ydCB2YXIgc2VsZWN0T3JkZXJlZFRvb2x0aXBUaWNrcyA9IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdFRvb2x0aXBBeGlzVGlja3MsIHRpY2tzID0+IHNvcnRCeSh0aWNrcywgbyA9PiBvLmNvb3JkaW5hdGUpKTtcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcEludGVyYWN0aW9uU3RhdGUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcFN0YXRlLCBwaWNrVG9vbHRpcEV2ZW50VHlwZSwgcGlja1RyaWdnZXIsIHBpY2tEZWZhdWx0SW5kZXhdLCBjb21iaW5lVG9vbHRpcEludGVyYWN0aW9uU3RhdGUpO1xuZXhwb3J0IHZhciBzZWxlY3RBY3RpdmVJbmRleCA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RUb29sdGlwSW50ZXJhY3Rpb25TdGF0ZSwgc2VsZWN0VG9vbHRpcERpc3BsYXllZERhdGFdLCBjb21iaW5lQWN0aXZlVG9vbHRpcEluZGV4KTtcbmV4cG9ydCB2YXIgc2VsZWN0VG9vbHRpcERhdGFLZXkgPSAoc3RhdGUsIHRvb2x0aXBFdmVudFR5cGUsIHRyaWdnZXIpID0+IHtcbiAgaWYgKHRvb2x0aXBFdmVudFR5cGUgPT0gbnVsbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgdmFyIHRvb2x0aXBTdGF0ZSA9IHNlbGVjdFRvb2x0aXBTdGF0ZShzdGF0ZSk7XG4gIGlmICh0b29sdGlwRXZlbnRUeXBlID09PSAnYXhpcycpIHtcbiAgICBpZiAodHJpZ2dlciA9PT0gJ2hvdmVyJykge1xuICAgICAgcmV0dXJuIHRvb2x0aXBTdGF0ZS5heGlzSW50ZXJhY3Rpb24uaG92ZXIuZGF0YUtleTtcbiAgICB9XG4gICAgcmV0dXJuIHRvb2x0aXBTdGF0ZS5heGlzSW50ZXJhY3Rpb24uY2xpY2suZGF0YUtleTtcbiAgfVxuICBpZiAodHJpZ2dlciA9PT0gJ2hvdmVyJykge1xuICAgIHJldHVybiB0b29sdGlwU3RhdGUuaXRlbUludGVyYWN0aW9uLmhvdmVyLmRhdGFLZXk7XG4gIH1cbiAgcmV0dXJuIHRvb2x0aXBTdGF0ZS5pdGVtSW50ZXJhY3Rpb24uY2xpY2suZGF0YUtleTtcbn07XG5leHBvcnQgdmFyIHNlbGVjdFRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcFN0YXRlLCBwaWNrVG9vbHRpcEV2ZW50VHlwZSwgcGlja1RyaWdnZXIsIHBpY2tEZWZhdWx0SW5kZXhdLCBjb21iaW5lVG9vbHRpcFBheWxvYWRDb25maWd1cmF0aW9ucyk7XG5leHBvcnQgdmFyIHNlbGVjdENvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXggPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0Q2hhcnRXaWR0aCwgc2VsZWN0Q2hhcnRIZWlnaHQsIHNlbGVjdENoYXJ0TGF5b3V0LCBzZWxlY3RDaGFydE9mZnNldEludGVybmFsLCBzZWxlY3RUb29sdGlwQXhpc1RpY2tzLCBwaWNrRGVmYXVsdEluZGV4LCBzZWxlY3RUb29sdGlwUGF5bG9hZENvbmZpZ3VyYXRpb25zLCBzZWxlY3RUb29sdGlwUGF5bG9hZFNlYXJjaGVyXSwgY29tYmluZUNvb3JkaW5hdGVGb3JEZWZhdWx0SW5kZXgpO1xuZXhwb3J0IHZhciBzZWxlY3RBY3RpdmVDb29yZGluYXRlID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLCBzZWxlY3RDb29yZGluYXRlRm9yRGVmYXVsdEluZGV4XSwgKHRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLCBkZWZhdWx0SW5kZXhDb29yZGluYXRlKSA9PiB7XG4gIHZhciBfdG9vbHRpcEludGVyYWN0aW9uU3Q7XG4gIHJldHVybiAoX3Rvb2x0aXBJbnRlcmFjdGlvblN0ID0gdG9vbHRpcEludGVyYWN0aW9uU3RhdGUuY29vcmRpbmF0ZSkgIT09IG51bGwgJiYgX3Rvb2x0aXBJbnRlcmFjdGlvblN0ICE9PSB2b2lkIDAgPyBfdG9vbHRpcEludGVyYWN0aW9uU3QgOiBkZWZhdWx0SW5kZXhDb29yZGluYXRlO1xufSk7XG5leHBvcnQgdmFyIHNlbGVjdEFjdGl2ZUxhYmVsID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0VG9vbHRpcEF4aXNUaWNrcywgc2VsZWN0QWN0aXZlSW5kZXgsIGNvbWJpbmVBY3RpdmVMYWJlbCk7XG5leHBvcnQgdmFyIHNlbGVjdFRvb2x0aXBQYXlsb2FkID0gY3JlYXRlU2VsZWN0b3IoW3NlbGVjdFRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMsIHNlbGVjdEFjdGl2ZUluZGV4LCBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlcywgc2VsZWN0VG9vbHRpcEF4aXNEYXRhS2V5LCBzZWxlY3RBY3RpdmVMYWJlbCwgc2VsZWN0VG9vbHRpcFBheWxvYWRTZWFyY2hlciwgcGlja1Rvb2x0aXBFdmVudFR5cGVdLCBjb21iaW5lVG9vbHRpcFBheWxvYWQpO1xuZXhwb3J0IHZhciBzZWxlY3RJc1Rvb2x0aXBBY3RpdmUgPSBjcmVhdGVTZWxlY3Rvcihbc2VsZWN0VG9vbHRpcEludGVyYWN0aW9uU3RhdGVdLCB0b29sdGlwSW50ZXJhY3Rpb25TdGF0ZSA9PiB7XG4gIHJldHVybiB7XG4gICAgaXNBY3RpdmU6IHRvb2x0aXBJbnRlcmFjdGlvblN0YXRlLmFjdGl2ZSxcbiAgICBhY3RpdmVJbmRleDogdG9vbHRpcEludGVyYWN0aW9uU3RhdGUuaW5kZXhcbiAgfTtcbn0pO1xuZXhwb3J0IHZhciBjb21iaW5lQWN0aXZlUHJvcHMgPSAoY2hhcnRFdmVudCwgbGF5b3V0LCBwb2xhclZpZXdCb3gsIHRvb2x0aXBBeGlzVHlwZSwgdG9vbHRpcEF4aXNSYW5nZSwgdG9vbHRpcFRpY2tzLCBvcmRlcmVkVG9vbHRpcFRpY2tzLCBvZmZzZXQpID0+IHtcbiAgaWYgKCFjaGFydEV2ZW50IHx8ICFsYXlvdXQgfHwgIXRvb2x0aXBBeGlzVHlwZSB8fCAhdG9vbHRpcEF4aXNSYW5nZSB8fCAhdG9vbHRpcFRpY2tzKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIgcmFuZ2VPYmogPSBpblJhbmdlKGNoYXJ0RXZlbnQuY2hhcnRYLCBjaGFydEV2ZW50LmNoYXJ0WSwgbGF5b3V0LCBwb2xhclZpZXdCb3gsIG9mZnNldCk7XG4gIGlmICghcmFuZ2VPYmopIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHZhciBwb3MgPSBjYWxjdWxhdGVUb29sdGlwUG9zKHJhbmdlT2JqLCBsYXlvdXQpO1xuICB2YXIgYWN0aXZlSW5kZXggPSBjYWxjdWxhdGVBY3RpdmVUaWNrSW5kZXgocG9zLCBvcmRlcmVkVG9vbHRpcFRpY2tzLCB0b29sdGlwVGlja3MsIHRvb2x0aXBBeGlzVHlwZSwgdG9vbHRpcEF4aXNSYW5nZSk7XG4gIHZhciBhY3RpdmVDb29yZGluYXRlID0gZ2V0QWN0aXZlQ29vcmRpbmF0ZShsYXlvdXQsIHRvb2x0aXBUaWNrcywgYWN0aXZlSW5kZXgsIHJhbmdlT2JqKTtcbiAgcmV0dXJuIHtcbiAgICBhY3RpdmVJbmRleDogU3RyaW5nKGFjdGl2ZUluZGV4KSxcbiAgICBhY3RpdmVDb29yZGluYXRlXG4gIH07XG59OyIsImZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAsIHdyaXRhYmxlOiAhMCB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSB0eXBlb2YgaSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIHQgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTsgaWYgKFwib2JqZWN0XCIgIT0gdHlwZW9mIGkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuaW1wb3J0IHsgZmluZEVudHJ5SW5BcnJheSB9IGZyb20gJy4uLy4uLy4uL3V0aWwvRGF0YVV0aWxzJztcbmltcG9ydCB7IGdldFRvb2x0aXBFbnRyeSwgZ2V0VmFsdWVCeURhdGFLZXkgfSBmcm9tICcuLi8uLi8uLi91dGlsL0NoYXJ0VXRpbHMnO1xuaW1wb3J0IHsgZ2V0U2xpY2VkIH0gZnJvbSAnLi4vLi4vLi4vdXRpbC9nZXRTbGljZWQnO1xuZnVuY3Rpb24gc2VsZWN0RmluYWxEYXRhKGRhdGFEZWZpbmVkT25JdGVtLCBkYXRhRGVmaW5lZE9uQ2hhcnQpIHtcbiAgLypcbiAgICogSWYgYSBwYXlsb2FkIGhhcyBkYXRhIHNwZWNpZmllZCBkaXJlY3RseSBmcm9tIHRoZSBncmFwaGljYWwgaXRlbSwgcHJlZmVyIHRoYXQuXG4gICAqIE90aGVyd2lzZSwgZmlsbCBpbiBkYXRhIGZyb20gdGhlIGNoYXJ0IGxldmVsLCB1c2luZyB0aGUgc2FtZSBpbmRleC5cbiAgICovXG4gIGlmIChkYXRhRGVmaW5lZE9uSXRlbSAhPSBudWxsKSB7XG4gICAgcmV0dXJuIGRhdGFEZWZpbmVkT25JdGVtO1xuICB9XG4gIHJldHVybiBkYXRhRGVmaW5lZE9uQ2hhcnQ7XG59XG5leHBvcnQgdmFyIGNvbWJpbmVUb29sdGlwUGF5bG9hZCA9ICh0b29sdGlwUGF5bG9hZENvbmZpZ3VyYXRpb25zLCBhY3RpdmVJbmRleCwgY2hhcnREYXRhU3RhdGUsIHRvb2x0aXBBeGlzRGF0YUtleSwgYWN0aXZlTGFiZWwsIHRvb2x0aXBQYXlsb2FkU2VhcmNoZXIsIHRvb2x0aXBFdmVudFR5cGUpID0+IHtcbiAgaWYgKGFjdGl2ZUluZGV4ID09IG51bGwgfHwgdG9vbHRpcFBheWxvYWRTZWFyY2hlciA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICB2YXIge1xuICAgIGNoYXJ0RGF0YSxcbiAgICBjb21wdXRlZERhdGEsXG4gICAgZGF0YVN0YXJ0SW5kZXgsXG4gICAgZGF0YUVuZEluZGV4XG4gIH0gPSBjaGFydERhdGFTdGF0ZTtcbiAgdmFyIGluaXQgPSBbXTtcbiAgcmV0dXJuIHRvb2x0aXBQYXlsb2FkQ29uZmlndXJhdGlvbnMucmVkdWNlKChhZ2csIF9yZWYpID0+IHtcbiAgICB2YXIgX3NldHRpbmdzJGRhdGFLZXk7XG4gICAgdmFyIHtcbiAgICAgIGRhdGFEZWZpbmVkT25JdGVtLFxuICAgICAgc2V0dGluZ3NcbiAgICB9ID0gX3JlZjtcbiAgICB2YXIgZmluYWxEYXRhID0gc2VsZWN0RmluYWxEYXRhKGRhdGFEZWZpbmVkT25JdGVtLCBjaGFydERhdGEpO1xuICAgIHZhciBzbGljZWQgPSBBcnJheS5pc0FycmF5KGZpbmFsRGF0YSkgPyBnZXRTbGljZWQoZmluYWxEYXRhLCBkYXRhU3RhcnRJbmRleCwgZGF0YUVuZEluZGV4KSA6IGZpbmFsRGF0YTtcbiAgICB2YXIgZmluYWxEYXRhS2V5ID0gKF9zZXR0aW5ncyRkYXRhS2V5ID0gc2V0dGluZ3MgPT09IG51bGwgfHwgc2V0dGluZ3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNldHRpbmdzLmRhdGFLZXkpICE9PSBudWxsICYmIF9zZXR0aW5ncyRkYXRhS2V5ICE9PSB2b2lkIDAgPyBfc2V0dGluZ3MkZGF0YUtleSA6IHRvb2x0aXBBeGlzRGF0YUtleTtcbiAgICAvLyBCYXNlQXhpc1Byb3BzIGRvZXMgbm90IHN1cHBvcnQgbmFtZUtleSBidXQgaXQgY291bGQhXG4gICAgdmFyIGZpbmFsTmFtZUtleSA9IHNldHRpbmdzID09PSBudWxsIHx8IHNldHRpbmdzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzZXR0aW5ncy5uYW1lS2V5OyAvLyA/PyB0b29sdGlwQXhpcz8ubmFtZUtleTtcbiAgICB2YXIgdG9vbHRpcFBheWxvYWQ7XG4gICAgaWYgKHRvb2x0aXBBeGlzRGF0YUtleSAmJiBBcnJheS5pc0FycmF5KHNsaWNlZCkgJiZcbiAgICAvKlxuICAgICAqIGZpbmRFbnRyeUluQXJyYXkgd29uJ3Qgd29yayBmb3IgU2NhdHRlciBiZWNhdXNlIFNjYXR0ZXIgcHJvdmlkZXMgYW4gYXJyYXkgb2YgYXJyYXlzXG4gICAgICogYXMgdG9vbHRpcCBwYXlsb2FkcyBhbmQgZmluZEVudHJ5SW5BcnJheSBpcyBub3QgcHJlcGFyZWQgdG8gaGFuZGxlIHRoYXQuXG4gICAgICogU2FkIGJ1dCBhbHNvIFNjYXR0ZXJDaGFydCBvbmx5IGFsbG93cyAnaXRlbScgdG9vbHRpcEV2ZW50VHlwZVxuICAgICAqIGFuZCBhbHNvIHRoaXMgaXMgb25seSBhIHByb2JsZW0gaWYgdGhlcmUgYXJlIG11bHRpcGxlIFNjYXR0ZXJzIGFuZCBlYWNoIGhhcyBpdHMgb3duIGRhdGEgYXJyYXlcbiAgICAgKiBzbyBsZXQncyBmaXggdGhhdCBzb21lIG90aGVyIHRpbWUuXG4gICAgICovXG4gICAgIUFycmF5LmlzQXJyYXkoc2xpY2VkWzBdKSAmJlxuICAgIC8qXG4gICAgICogSWYgdGhlIHRvb2x0aXBFdmVudFR5cGUgaXMgJ2F4aXMnLCB3ZSBzaG91bGQgc2VhcmNoIGZvciB0aGUgZGF0YUtleSBpbiB0aGUgc2xpY2VkIGRhdGFcbiAgICAgKiBiZWNhdXNlIHRoYW5rcyB0byBhbGxvd0R1cGxpY2F0ZWRDYXRlZ29yeT1mYWxzZSwgdGhlIG9yZGVyIG9mIGVsZW1lbnRzIGluIHRoZSBhcnJheVxuICAgICAqIG5vIGxvbmdlciBtYXRjaGVzIHRoZSBvcmRlciBvZiBlbGVtZW50cyBpbiB0aGUgb3JpZ2luYWwgZGF0YVxuICAgICAqIGFuZCBzbyB3ZSBuZWVkIHRvIHNlYXJjaCBieSB0aGUgYWN0aXZlIGRhdGFLZXkgKyBsYWJlbCByYXRoZXIgdGhhbiBieSBpbmRleC5cbiAgICAgKlxuICAgICAqIFRoZSBzYW1lIGhhcHBlbnMgaWYgbXVsdGlwbGUgZ3JhcGhpY2FsIGl0ZW1zIGFyZSBwcmVzZW50IGluIHRoZSBjaGFydFxuICAgICAqIGFuZCBlYWNoIG9mIHRoZW0gaGFzIGl0cyBvd24gZGF0YSBhcnJheS4gVGhvc2UgYXJyYXlzIGdldCBjb25jYXRlbmF0ZWRcbiAgICAgKiBhbmQgYWdhaW4gdGhlIHRvb2x0aXAgaW5kZXggbm8gbG9uZ2VyIG1hdGNoZXMgdGhlIG9yaWdpbmFsIGRhdGEuXG4gICAgICpcbiAgICAgKiBPbiB0aGUgb3RoZXIgaGFuZCB0aGUgdG9vbHRpcEV2ZW50VHlwZSAnaXRlbScgc2hvdWxkIGFsd2F5cyBzZWFyY2ggYnkgaW5kZXhcbiAgICAgKiBiZWNhdXNlIHdlIGdldCB0aGUgaW5kZXggZnJvbSBpbnRlcmFjdGluZyBvdmVyIHRoZSBpbmRpdmlkdWFsIGVsZW1lbnRzXG4gICAgICogd2hpY2ggaXMgYWx3YXlzIGFjY3VyYXRlLCBpcnJlc3BlY3RpdmUgb2YgdGhlIGFsbG93RHVwbGljYXRlZENhdGVnb3J5IHNldHRpbmcuXG4gICAgICovXG4gICAgdG9vbHRpcEV2ZW50VHlwZSA9PT0gJ2F4aXMnKSB7XG4gICAgICB0b29sdGlwUGF5bG9hZCA9IGZpbmRFbnRyeUluQXJyYXkoc2xpY2VkLCB0b29sdGlwQXhpc0RhdGFLZXksIGFjdGl2ZUxhYmVsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLypcbiAgICAgICAqIFRoaXMgaXMgYSBwcm9ibGVtIGJlY2F1c2UgaXQgYXNzdW1lcyB0aGF0IHRoZSBpbmRleCBpcyBwb2ludGluZyB0byB0aGUgZGlzcGxheWVkIGRhdGFcbiAgICAgICAqIHdoaWNoIGl0IGlzbid0IGJlY2F1c2UgdGhlIGluZGV4IGlzIHBvaW50aW5nIHRvIHRoZSB0b29sdGlwIHRpY2tzIGFycmF5LlxuICAgICAgICogVGhlIGFib3ZlIGFwcHJvYWNoICh3aXRoIGZpbmRFbnRyeUluQXJyYXkpIGlzIHRoZSBjb3JyZWN0IG9uZSwgYnV0IGl0IG9ubHkgd29ya3NcbiAgICAgICAqIGlmIHRoZSBheGlzIGRhdGFLZXkgaXMgZGVmaW5lZCBleHBsaWNpdGx5LCBhbmQgaWYgdGhlIGRhdGEgaXMgYW4gYXJyYXkgb2Ygb2JqZWN0cy5cbiAgICAgICAqL1xuICAgICAgdG9vbHRpcFBheWxvYWQgPSB0b29sdGlwUGF5bG9hZFNlYXJjaGVyKHNsaWNlZCwgYWN0aXZlSW5kZXgsIGNvbXB1dGVkRGF0YSwgZmluYWxOYW1lS2V5KTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodG9vbHRpcFBheWxvYWQpKSB7XG4gICAgICB0b29sdGlwUGF5bG9hZC5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgICB2YXIgbmV3U2V0dGluZ3MgPSBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHNldHRpbmdzKSwge30sIHtcbiAgICAgICAgICBuYW1lOiBpdGVtLm5hbWUsXG4gICAgICAgICAgdW5pdDogaXRlbS51bml0LFxuICAgICAgICAgIC8vIGNvbG9yIGFuZCBmaWxsIGFyZSBlcmFzZWQgdG8ga2VlcCAxMDAlIHRoZSBpZGVudGljYWwgYmVoYXZpb3VyIHRvIHJlY2hhcnRzIDIueCAtIGJ1dCB0aGVyZSdzIG5vdGhpbmcgc3RvcHBpbmcgdXMgZnJvbSByZXR1cm5pbmcgdGhlbSBoZXJlLiBJdCdzIHRlY2huaWNhbGx5IGEgYnJlYWtpbmcgY2hhbmdlLlxuICAgICAgICAgIGNvbG9yOiB1bmRlZmluZWQsXG4gICAgICAgICAgLy8gY29sb3IgYW5kIGZpbGwgYXJlIGVyYXNlZCB0byBrZWVwIDEwMCUgdGhlIGlkZW50aWNhbCBiZWhhdmlvdXIgdG8gcmVjaGFydHMgMi54IC0gYnV0IHRoZXJlJ3Mgbm90aGluZyBzdG9wcGluZyB1cyBmcm9tIHJldHVybmluZyB0aGVtIGhlcmUuIEl0J3MgdGVjaG5pY2FsbHkgYSBicmVha2luZyBjaGFuZ2UuXG4gICAgICAgICAgZmlsbDogdW5kZWZpbmVkXG4gICAgICAgIH0pO1xuICAgICAgICBhZ2cucHVzaChnZXRUb29sdGlwRW50cnkoe1xuICAgICAgICAgIHRvb2x0aXBFbnRyeVNldHRpbmdzOiBuZXdTZXR0aW5ncyxcbiAgICAgICAgICBkYXRhS2V5OiBpdGVtLmRhdGFLZXksXG4gICAgICAgICAgcGF5bG9hZDogaXRlbS5wYXlsb2FkLFxuICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgZ2V0VmFsdWVCeURhdGFLZXkgZG9lcyBub3QgdmFsaWRhdGUgdGhlIG91dHB1dCB0eXBlXG4gICAgICAgICAgdmFsdWU6IGdldFZhbHVlQnlEYXRhS2V5KGl0ZW0ucGF5bG9hZCwgaXRlbS5kYXRhS2V5KSxcbiAgICAgICAgICBuYW1lOiBpdGVtLm5hbWVcbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBfZ2V0VmFsdWVCeURhdGFLZXk7XG4gICAgICAvLyBJIGFtIG5vdCBxdWl0ZSBzdXJlIHdoeSB0aGVzZSB0d28gYnJhbmNoZXMgKEFycmF5IHZzIEFycmF5IG9mIEFycmF5cykgaGF2ZSB0byBiZWhhdmUgZGlmZmVyZW50bHkgLSBJIGltYWdpbmUgd2Ugc2hvdWxkIHVuaWZ5IHRoZXNlLiAzLnggYnJlYWtpbmcgY2hhbmdlP1xuICAgICAgYWdnLnB1c2goZ2V0VG9vbHRpcEVudHJ5KHtcbiAgICAgICAgdG9vbHRpcEVudHJ5U2V0dGluZ3M6IHNldHRpbmdzLFxuICAgICAgICBkYXRhS2V5OiBmaW5hbERhdGFLZXksXG4gICAgICAgIHBheWxvYWQ6IHRvb2x0aXBQYXlsb2FkLFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGdldFZhbHVlQnlEYXRhS2V5IGRvZXMgbm90IHZhbGlkYXRlIHRoZSBvdXRwdXQgdHlwZVxuICAgICAgICB2YWx1ZTogZ2V0VmFsdWVCeURhdGFLZXkodG9vbHRpcFBheWxvYWQsIGZpbmFsRGF0YUtleSksXG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgZ2V0VmFsdWVCeURhdGFLZXkgZG9lcyBub3QgdmFsaWRhdGUgdGhlIG91dHB1dCB0eXBlXG4gICAgICAgIG5hbWU6IChfZ2V0VmFsdWVCeURhdGFLZXkgPSBnZXRWYWx1ZUJ5RGF0YUtleSh0b29sdGlwUGF5bG9hZCwgZmluYWxOYW1lS2V5KSkgIT09IG51bGwgJiYgX2dldFZhbHVlQnlEYXRhS2V5ICE9PSB2b2lkIDAgPyBfZ2V0VmFsdWVCeURhdGFLZXkgOiBzZXR0aW5ncyA9PT0gbnVsbCB8fCBzZXR0aW5ncyA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2V0dGluZ3MubmFtZVxuICAgICAgfSkpO1xuICAgIH1cbiAgICByZXR1cm4gYWdnO1xuICB9LCBpbml0KTtcbn07IiwiaW1wb3J0IHsgY3JlYXRlU2xpY2UgfSBmcm9tICdAcmVkdXhqcy90b29sa2l0JztcblxuLyoqXG4gKiBUaGVzZSBhcmUgY2hhcnQgb3B0aW9ucyB0aGF0IHVzZXJzIGNhbiBjaG9vc2UgLSB3aGljaCBtZWFucyB0aGV5IGNhbiBhbHNvXG4gKiBjaG9vc2UgdG8gY2hhbmdlIHRoZW0gd2hpY2ggc2hvdWxkIHRyaWdnZXIgYSByZS1yZW5kZXIuXG4gKi9cblxuZXhwb3J0IHZhciBpbml0aWFsU3RhdGUgPSB7XG4gIGFjY2Vzc2liaWxpdHlMYXllcjogdHJ1ZSxcbiAgYmFyQ2F0ZWdvcnlHYXA6ICcxMCUnLFxuICBiYXJHYXA6IDQsXG4gIGJhclNpemU6IHVuZGVmaW5lZCxcbiAgY2xhc3NOYW1lOiB1bmRlZmluZWQsXG4gIG1heEJhclNpemU6IHVuZGVmaW5lZCxcbiAgc3RhY2tPZmZzZXQ6ICdub25lJyxcbiAgc3luY0lkOiB1bmRlZmluZWQsXG4gIHN5bmNNZXRob2Q6ICdpbmRleCdcbn07XG52YXIgcm9vdFByb3BzU2xpY2UgPSBjcmVhdGVTbGljZSh7XG4gIG5hbWU6ICdyb290UHJvcHMnLFxuICBpbml0aWFsU3RhdGUsXG4gIHJlZHVjZXJzOiB7XG4gICAgdXBkYXRlT3B0aW9uczogKHN0YXRlLCBhY3Rpb24pID0+IHtcbiAgICAgIHZhciBfYWN0aW9uJHBheWxvYWQkYmFyR2E7XG4gICAgICBzdGF0ZS5hY2Nlc3NpYmlsaXR5TGF5ZXIgPSBhY3Rpb24ucGF5bG9hZC5hY2Nlc3NpYmlsaXR5TGF5ZXI7XG4gICAgICBzdGF0ZS5iYXJDYXRlZ29yeUdhcCA9IGFjdGlvbi5wYXlsb2FkLmJhckNhdGVnb3J5R2FwO1xuICAgICAgc3RhdGUuYmFyR2FwID0gKF9hY3Rpb24kcGF5bG9hZCRiYXJHYSA9IGFjdGlvbi5wYXlsb2FkLmJhckdhcCkgIT09IG51bGwgJiYgX2FjdGlvbiRwYXlsb2FkJGJhckdhICE9PSB2b2lkIDAgPyBfYWN0aW9uJHBheWxvYWQkYmFyR2EgOiBpbml0aWFsU3RhdGUuYmFyR2FwO1xuICAgICAgc3RhdGUuYmFyU2l6ZSA9IGFjdGlvbi5wYXlsb2FkLmJhclNpemU7XG4gICAgICBzdGF0ZS5tYXhCYXJTaXplID0gYWN0aW9uLnBheWxvYWQubWF4QmFyU2l6ZTtcbiAgICAgIHN0YXRlLnN0YWNrT2Zmc2V0ID0gYWN0aW9uLnBheWxvYWQuc3RhY2tPZmZzZXQ7XG4gICAgICBzdGF0ZS5zeW5jSWQgPSBhY3Rpb24ucGF5bG9hZC5zeW5jSWQ7XG4gICAgICBzdGF0ZS5zeW5jTWV0aG9kID0gYWN0aW9uLnBheWxvYWQuc3luY01ldGhvZDtcbiAgICAgIHN0YXRlLmNsYXNzTmFtZSA9IGFjdGlvbi5wYXlsb2FkLmNsYXNzTmFtZTtcbiAgICB9XG4gIH1cbn0pO1xuZXhwb3J0IHZhciByb290UHJvcHNSZWR1Y2VyID0gcm9vdFByb3BzU2xpY2UucmVkdWNlcjtcbmV4cG9ydCB2YXIge1xuICB1cGRhdGVPcHRpb25zXG59ID0gcm9vdFByb3BzU2xpY2UuYWN0aW9uczsiLCJpbXBvcnQgeyBjcmVhdGVTZWxlY3RvciB9IGZyb20gJ3Jlc2VsZWN0Jztcbi8qKlxuICogVGhpcyBzZWxlY3RvciBhbHdheXMgcmV0dXJucyB0aGUgZGF0YSB3aXRoIHRoZSBpbmRleGVzIHNldCBieSBhIEJydXNoLlxuICogVHJvdWJsZSBpcywgdGhhdCBtaWdodCBvciBtaWdodCBub3QgYmUgd2hhdCB5b3Ugd2FudC5cbiAqXG4gKiBJbiBjaGFydHMgd2l0aCBCcnVzaCwgeW91IHdpbGwgc29tZXRpbWVzIHdhbnQgdG8gc2VsZWN0IHRoZSBmdWxsIHJhbmdlIG9mIGRhdGEsIGFuZCBzb21ldGltZXMgdGhlIG9uZSBkZWNpZGVkIGJ5IHRoZSBCcnVzaFxuICogLSBldmVuIGlmIHRoZSBCcnVzaCBpcyBhY3RpdmUsIHRoZSBwYW5vcmFtYSBpbnNpZGUgdGhlIEJydXNoIHNob3VsZCBzaG93IHRoZSBmdWxsIHJhbmdlIG9mIGRhdGEuXG4gKlxuICogU28gaW5zdGVhZCBvZiB0aGlzIHNlbGVjdG9yLCBjb25zaWRlciB1c2luZyBlaXRoZXIgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcyBvciBzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlc0lmTm90SW5QYW5vcmFtYVxuICpcbiAqIEBwYXJhbSBzdGF0ZSBSZWNoYXJ0c1Jvb3RTdGF0ZVxuICogQHJldHVybnMgZGF0YSBkZWZpbmVkIG9uIHRoZSBjaGFydCByb290IGVsZW1lbnQsIHN1Y2ggYXMgQmFyQ2hhcnQgb3IgU2NhdHRlckNoYXJ0XG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXMgPSBzdGF0ZSA9PiBzdGF0ZS5jaGFydERhdGE7XG5cbi8qKlxuICogVGhpcyBzZWxlY3RvciB3aWxsIGFsd2F5cyByZXR1cm4gdGhlIGZ1bGwgcmFuZ2Ugb2YgZGF0YSwgaWdub3JpbmcgdGhlIGluZGV4ZXMgc2V0IGJ5IGEgQnJ1c2guXG4gKiBVc2VmdWwgZm9yIHdoZW4geW91IHdhbnQgdG8gcmVuZGVyIHRoZSBmdWxsIHJhbmdlIG9mIGRhdGEsIGV2ZW4gaWYgYSBCcnVzaCBpcyBhY3RpdmUuXG4gKiBGb3IgZXhhbXBsZTogaW4gdGhlIEJydXNoIHBhbm9yYW1hLCBpbiBMZWdlbmQsIGluIFRvb2x0aXAuXG4gKi9cbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnREYXRhQW5kQWx3YXlzSWdub3JlSW5kZXhlcyA9IGNyZWF0ZVNlbGVjdG9yKFtzZWxlY3RDaGFydERhdGFXaXRoSW5kZXhlc10sIGRhdGFTdGF0ZSA9PiB7XG4gIHZhciBkYXRhRW5kSW5kZXggPSBkYXRhU3RhdGUuY2hhcnREYXRhICE9IG51bGwgPyBkYXRhU3RhdGUuY2hhcnREYXRhLmxlbmd0aCAtIDEgOiAwO1xuICByZXR1cm4ge1xuICAgIGNoYXJ0RGF0YTogZGF0YVN0YXRlLmNoYXJ0RGF0YSxcbiAgICBjb21wdXRlZERhdGE6IGRhdGFTdGF0ZS5jb21wdXRlZERhdGEsXG4gICAgZGF0YUVuZEluZGV4LFxuICAgIGRhdGFTdGFydEluZGV4OiAwXG4gIH07XG59KTtcbmV4cG9ydCB2YXIgc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXNJZk5vdEluUGFub3JhbWEgPSAoc3RhdGUsIF91bnVzZWQxLCBfdW51c2VkMiwgaXNQYW5vcmFtYSkgPT4ge1xuICBpZiAoaXNQYW5vcmFtYSkge1xuICAgIHJldHVybiBzZWxlY3RDaGFydERhdGFBbmRBbHdheXNJZ25vcmVJbmRleGVzKHN0YXRlKTtcbiAgfVxuICByZXR1cm4gc2VsZWN0Q2hhcnREYXRhV2l0aEluZGV4ZXMoc3RhdGUpO1xufTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=