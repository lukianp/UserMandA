(global["webpackChunkguiv2"] = global["webpackChunkguiv2"] || []).push([[8270],{

/***/ 22555:
/***/ (() => {

"use strict";

// UNUSED EXPORTS: default

;// ./node_modules/@babel/runtime/helpers/esm/typeof.js
function typeof_typeof(o) {
  "@babel/helpers - typeof";

  return typeof_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, typeof_typeof(o);
}

;// ./node_modules/@babel/runtime/helpers/esm/toPrimitive.js

function toPrimitive_toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}

;// ./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js


function toPropertyKey_toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}

;// ./node_modules/@babel/runtime/helpers/esm/defineProperty.js

function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}

;// ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js

function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}


/***/ }),

/***/ 29293:
/***/ ((module) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 32949:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71354);
/* harmony import */ var _css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76314);
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4417);
/* harmony import */ var _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
// Imports



var ___CSS_LOADER_URL_IMPORT_0___ = new URL(/* asset import */ __webpack_require__(50221), __webpack_require__.b);
var ___CSS_LOADER_EXPORT___ = _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()(___CSS_LOADER_URL_IMPORT_0___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `@font-face {
  font-family: "agGridAlpine";
  src: url(${___CSS_LOADER_URL_REPLACEMENT_0___});
  font-weight: normal;
  font-style: normal;
}
.ag-theme-alpine,
.ag-theme-alpine-dark,
.ag-theme-alpine-auto-dark {
  --ag-alpine-active-color: #2196f3;
  --ag-selected-row-background-color: rgba(33, 150, 243, 0.3);
  --ag-row-hover-color: rgba(33, 150, 243, 0.1);
  --ag-column-hover-color: rgba(33, 150, 243, 0.1);
  --ag-input-focus-border-color: rgba(33, 150, 243, 0.4);
  --ag-range-selection-background-color: rgba(33, 150, 243, 0.2);
  --ag-range-selection-background-color-2: rgba(33, 150, 243, 0.36);
  --ag-range-selection-background-color-3: rgba(33, 150, 243, 0.49);
  --ag-range-selection-background-color-4: rgba(33, 150, 243, 0.59);
  --ag-row-numbers-selected-color: color-mix(in srgb, transparent, var(--ag-alpine-active-color) 50%);
  --ag-background-color: #fff;
  --ag-foreground-color: #181d1f;
  --ag-border-color: #babfc7;
  --ag-secondary-border-color: #dde2eb;
  --ag-header-background-color: #f8f8f8;
  --ag-tooltip-background-color: #f8f8f8;
  --ag-odd-row-background-color: #fcfcfc;
  --ag-control-panel-background-color: #f8f8f8;
  --ag-subheader-background-color: #fff;
  --ag-invalid-color: #e02525;
  --ag-checkbox-unchecked-color: #999;
  --ag-advanced-filter-join-pill-color: #f08e8d;
  --ag-advanced-filter-column-pill-color: #a6e194;
  --ag-advanced-filter-option-pill-color: #f3c08b;
  --ag-advanced-filter-value-pill-color: #85c0e4;
  --ag-find-match-color: var(--ag-foreground-color);
  --ag-find-match-background-color: #ffff00;
  --ag-find-active-match-color: var(--ag-foreground-color);
  --ag-find-active-match-background-color: #ffa500;
  --ag-checkbox-background-color: var(--ag-background-color);
  --ag-checkbox-checked-color: var(--ag-alpine-active-color);
  --ag-range-selection-border-color: var(--ag-alpine-active-color);
  --ag-secondary-foreground-color: var(--ag-foreground-color);
  --ag-input-border-color: var(--ag-border-color);
  --ag-input-border-color-invalid: var(--ag-invalid-color);
  --ag-input-focus-box-shadow: 0 0 2px 0.1rem var(--ag-input-focus-border-color);
  --ag-input-error-focus-box-shadow: 0 0 2px 0.1rem var(--ag-invalid-color);
  --ag-panel-background-color: var(--ag-header-background-color);
  --ag-menu-background-color: var(--ag-header-background-color);
  --ag-filter-panel-apply-button-color: var(--ag-background-color);
  --ag-filter-panel-apply-button-background-color: var(--ag-alpine-active-color);
  --ag-disabled-foreground-color: rgba(24, 29, 31, 0.5);
  --ag-chip-background-color: rgba(24, 29, 31, 0.07);
  --ag-input-disabled-border-color: rgba(186, 191, 199, 0.3);
  --ag-input-disabled-background-color: rgba(186, 191, 199, 0.15);
  --ag-borders: solid 1px;
  --ag-border-radius: 3px;
  --ag-borders-side-button: none;
  --ag-side-button-selected-background-color: transparent;
  --ag-header-column-resize-handle-display: block;
  --ag-header-column-resize-handle-width: 2px;
  --ag-header-column-resize-handle-height: 30%;
  --ag-grid-size: 6px;
  --ag-icon-size: 16px;
  --ag-row-height: calc(var(--ag-grid-size) * 7);
  --ag-header-height: calc(var(--ag-grid-size) * 8);
  --ag-list-item-height: calc(var(--ag-grid-size) * 4);
  --ag-column-select-indent-size: var(--ag-icon-size);
  --ag-set-filter-indent-size: var(--ag-icon-size);
  --ag-advanced-filter-builder-indent-size: calc(var(--ag-icon-size) + var(--ag-grid-size) * 2);
  --ag-cell-horizontal-padding: calc(var(--ag-grid-size) * 3);
  --ag-cell-widget-spacing: calc(var(--ag-grid-size) * 2);
  --ag-widget-container-vertical-padding: calc(var(--ag-grid-size) * 2);
  --ag-widget-container-horizontal-padding: calc(var(--ag-grid-size) * 2);
  --ag-widget-vertical-spacing: calc(var(--ag-grid-size) * 1.5);
  --ag-toggle-button-height: 18px;
  --ag-toggle-button-width: 28px;
  --ag-font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell,
      "Helvetica Neue", sans-serif;
  --ag-font-size: 13px;
  --ag-icon-font-family: agGridAlpine;
  --ag-selected-tab-underline-color: var(--ag-alpine-active-color);
  --ag-selected-tab-underline-width: 2px;
  --ag-selected-tab-underline-transition-speed: 0.3s;
  --ag-tab-min-width: 240px;
  --ag-card-shadow: 0 1px 4px 1px rgba(186, 191, 199, 0.4);
  --ag-popup-shadow: var(--ag-card-shadow);
  --ag-side-bar-panel-width: 250px;
}

.ag-theme-alpine-dark {
  --ag-background-color: #181d1f;
  --ag-foreground-color: #fff;
  --ag-border-color: #68686e;
  --ag-secondary-border-color: rgba(88, 86, 82, 0.5);
  --ag-modal-overlay-background-color: rgba(24, 29, 31, 0.66);
  --ag-header-background-color: #222628;
  --ag-tooltip-background-color: #222628;
  --ag-odd-row-background-color: #222628;
  --ag-control-panel-background-color: #222628;
  --ag-subheader-background-color: #000;
  --ag-input-disabled-background-color: #282c2f;
  --ag-input-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5), 0 0 4px 3px var(--ag-input-focus-border-color);
  --ag-input-error-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5),
      0 0 4px 3px color-mix(in srgb, var(--ag-background-color), var(--ag-invalid-color) 0.5%);
  --ag-card-shadow: 0 1px 20px 1px black;
  --ag-disabled-foreground-color: rgba(255, 255, 255, 0.5);
  --ag-chip-background-color: rgba(255, 255, 255, 0.07);
  --ag-input-disabled-border-color: rgba(104, 104, 110, 0.3);
  --ag-input-disabled-background-color: rgba(104, 104, 110, 0.07);
  --ag-advanced-filter-join-pill-color: #7a3a37;
  --ag-advanced-filter-column-pill-color: #355f2d;
  --ag-advanced-filter-option-pill-color: #5a3168;
  --ag-advanced-filter-value-pill-color: #374c86;
  --ag-find-match-color: var(--ag-background-color);
  --ag-find-active-match-color: var(--ag-background-color);
  --ag-filter-panel-apply-button-color: var(--ag-foreground-color);
  --ag-row-loading-skeleton-effect-color: rgba(202, 203, 204, 0.4);
  --ag-cell-batch-edit-text-color: #f3d0b3;
  color-scheme: dark;
}

@media (prefers-color-scheme: dark) {
  .ag-theme-alpine-auto-dark {
    --ag-background-color: #181d1f;
    --ag-foreground-color: #fff;
    --ag-border-color: #68686e;
    --ag-secondary-border-color: rgba(88, 86, 82, 0.5);
    --ag-modal-overlay-background-color: rgba(24, 29, 31, 0.66);
    --ag-header-background-color: #222628;
    --ag-tooltip-background-color: #222628;
    --ag-odd-row-background-color: #222628;
    --ag-control-panel-background-color: #222628;
    --ag-subheader-background-color: #000;
    --ag-input-disabled-background-color: #282c2f;
    --ag-input-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5), 0 0 4px 3px var(--ag-input-focus-border-color);
    --ag-input-error-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5),
        0 0 4px 3px color-mix(in srgb, var(--ag-background-color), var(--ag-invalid-color) 0.5%);
    --ag-card-shadow: 0 1px 20px 1px black;
    --ag-disabled-foreground-color: rgba(255, 255, 255, 0.5);
    --ag-chip-background-color: rgba(255, 255, 255, 0.07);
    --ag-input-disabled-border-color: rgba(104, 104, 110, 0.3);
    --ag-input-disabled-background-color: rgba(104, 104, 110, 0.07);
    --ag-advanced-filter-join-pill-color: #7a3a37;
    --ag-advanced-filter-column-pill-color: #355f2d;
    --ag-advanced-filter-option-pill-color: #5a3168;
    --ag-advanced-filter-value-pill-color: #374c86;
    --ag-find-match-color: var(--ag-background-color);
    --ag-find-active-match-color: var(--ag-background-color);
    --ag-filter-panel-apply-button-color: var(--ag-foreground-color);
    --ag-row-loading-skeleton-effect-color: rgba(202, 203, 204, 0.4);
    --ag-cell-batch-edit-text-color: #f3d0b3;
    color-scheme: dark;
  }
}
.ag-theme-alpine .ag-filter-toolpanel-header,
.ag-theme-alpine .ag-filter-toolpanel-search,
.ag-theme-alpine .ag-status-bar,
.ag-theme-alpine .ag-header-row,
.ag-theme-alpine .ag-row-number-cell,
.ag-theme-alpine .ag-panel-title-bar-title,
.ag-theme-alpine .ag-multi-filter-group-title-bar,
.ag-theme-alpine .ag-filter-card-title,
.ag-theme-alpine-dark .ag-filter-toolpanel-header,
.ag-theme-alpine-dark .ag-filter-toolpanel-search,
.ag-theme-alpine-dark .ag-status-bar,
.ag-theme-alpine-dark .ag-header-row,
.ag-theme-alpine-dark .ag-row-number-cell,
.ag-theme-alpine-dark .ag-panel-title-bar-title,
.ag-theme-alpine-dark .ag-multi-filter-group-title-bar,
.ag-theme-alpine-dark .ag-filter-card-title,
.ag-theme-alpine-auto-dark .ag-filter-toolpanel-header,
.ag-theme-alpine-auto-dark .ag-filter-toolpanel-search,
.ag-theme-alpine-auto-dark .ag-status-bar,
.ag-theme-alpine-auto-dark .ag-header-row,
.ag-theme-alpine-auto-dark .ag-row-number-cell,
.ag-theme-alpine-auto-dark .ag-panel-title-bar-title,
.ag-theme-alpine-auto-dark .ag-multi-filter-group-title-bar,
.ag-theme-alpine-auto-dark .ag-filter-card-title {
  font-weight: 700;
  color: var(--ag-header-foreground-color);
}
.ag-theme-alpine .ag-row,
.ag-theme-alpine-dark .ag-row,
.ag-theme-alpine-auto-dark .ag-row {
  font-size: calc(var(--ag-font-size) + 1px);
}
.ag-theme-alpine input[class^=ag-]:not([type]),
.ag-theme-alpine input[class^=ag-][type=text],
.ag-theme-alpine input[class^=ag-][type=number],
.ag-theme-alpine input[class^=ag-][type=tel],
.ag-theme-alpine input[class^=ag-][type=date],
.ag-theme-alpine input[class^=ag-][type=datetime-local],
.ag-theme-alpine textarea[class^=ag-],
.ag-theme-alpine-dark input[class^=ag-]:not([type]),
.ag-theme-alpine-dark input[class^=ag-][type=text],
.ag-theme-alpine-dark input[class^=ag-][type=number],
.ag-theme-alpine-dark input[class^=ag-][type=tel],
.ag-theme-alpine-dark input[class^=ag-][type=date],
.ag-theme-alpine-dark input[class^=ag-][type=datetime-local],
.ag-theme-alpine-dark textarea[class^=ag-],
.ag-theme-alpine-auto-dark input[class^=ag-]:not([type]),
.ag-theme-alpine-auto-dark input[class^=ag-][type=text],
.ag-theme-alpine-auto-dark input[class^=ag-][type=number],
.ag-theme-alpine-auto-dark input[class^=ag-][type=tel],
.ag-theme-alpine-auto-dark input[class^=ag-][type=date],
.ag-theme-alpine-auto-dark input[class^=ag-][type=datetime-local],
.ag-theme-alpine-auto-dark textarea[class^=ag-] {
  min-height: calc(var(--ag-grid-size) * 4);
  border-radius: var(--ag-border-radius);
}
.ag-theme-alpine .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine .ag-ltr textarea[class^=ag-], .ag-theme-alpine-dark .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine-dark .ag-ltr textarea[class^=ag-], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine-auto-dark .ag-ltr textarea[class^=ag-] {
  padding-left: var(--ag-grid-size);
}

.ag-theme-alpine .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine .ag-rtl textarea[class^=ag-], .ag-theme-alpine-dark .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine-dark .ag-rtl textarea[class^=ag-], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine-auto-dark .ag-rtl textarea[class^=ag-] {
  padding-right: var(--ag-grid-size);
}

.ag-theme-alpine .ag-tab,
.ag-theme-alpine-dark .ag-tab,
.ag-theme-alpine-auto-dark .ag-tab {
  padding: calc(var(--ag-grid-size) * 1.5);
  transition: color 0.4s;
  flex: 1 1 auto;
}
.ag-theme-alpine .ag-tab-selected,
.ag-theme-alpine-dark .ag-tab-selected,
.ag-theme-alpine-auto-dark .ag-tab-selected {
  color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-menu,
.ag-theme-alpine-dark .ag-menu,
.ag-theme-alpine-auto-dark .ag-menu {
  background-color: var(--ag-control-panel-background-color);
}
.ag-theme-alpine .ag-panel-content-wrapper .ag-column-select,
.ag-theme-alpine-dark .ag-panel-content-wrapper .ag-column-select,
.ag-theme-alpine-auto-dark .ag-panel-content-wrapper .ag-column-select {
  background-color: var(--ag-control-panel-background-color);
}
.ag-theme-alpine .ag-menu-header,
.ag-theme-alpine-dark .ag-menu-header,
.ag-theme-alpine-auto-dark .ag-menu-header {
  background-color: var(--ag-control-panel-background-color);
  padding-top: 1px;
}
.ag-theme-alpine .ag-tabs-header,
.ag-theme-alpine-dark .ag-tabs-header,
.ag-theme-alpine-auto-dark .ag-tabs-header {
  border-bottom: var(--ag-borders) var(--ag-border-color);
}
.ag-theme-alpine .ag-charts-settings-group-title-bar,
.ag-theme-alpine .ag-charts-data-group-title-bar,
.ag-theme-alpine .ag-charts-format-top-level-group-title-bar,
.ag-theme-alpine .ag-charts-advanced-settings-top-level-group-title-bar,
.ag-theme-alpine-dark .ag-charts-settings-group-title-bar,
.ag-theme-alpine-dark .ag-charts-data-group-title-bar,
.ag-theme-alpine-dark .ag-charts-format-top-level-group-title-bar,
.ag-theme-alpine-dark .ag-charts-advanced-settings-top-level-group-title-bar,
.ag-theme-alpine-auto-dark .ag-charts-settings-group-title-bar,
.ag-theme-alpine-auto-dark .ag-charts-data-group-title-bar,
.ag-theme-alpine-auto-dark .ag-charts-format-top-level-group-title-bar,
.ag-theme-alpine-auto-dark .ag-charts-advanced-settings-top-level-group-title-bar {
  padding: var(--ag-grid-size) calc(var(--ag-grid-size) * 2);
  line-height: calc(var(--ag-icon-size) + var(--ag-grid-size) - 2px);
}
.ag-theme-alpine .ag-chart-mini-thumbnail,
.ag-theme-alpine-dark .ag-chart-mini-thumbnail,
.ag-theme-alpine-auto-dark .ag-chart-mini-thumbnail {
  background-color: var(--ag-background-color);
}
.ag-theme-alpine .ag-chart-settings-nav-bar,
.ag-theme-alpine-dark .ag-chart-settings-nav-bar,
.ag-theme-alpine-auto-dark .ag-chart-settings-nav-bar {
  border-top: var(--ag-borders-secondary) var(--ag-secondary-border-color);
}
.ag-theme-alpine .ag-ltr .ag-group-title-bar-icon, .ag-theme-alpine-dark .ag-ltr .ag-group-title-bar-icon, .ag-theme-alpine-auto-dark .ag-ltr .ag-group-title-bar-icon {
  margin-right: var(--ag-grid-size);
}

.ag-theme-alpine .ag-rtl .ag-group-title-bar-icon, .ag-theme-alpine-dark .ag-rtl .ag-group-title-bar-icon, .ag-theme-alpine-auto-dark .ag-rtl .ag-group-title-bar-icon {
  margin-left: var(--ag-grid-size);
}

.ag-theme-alpine .ag-charts-format-top-level-group-toolbar,
.ag-theme-alpine .ag-charts-advanced-settings-top-level-group-toolbar,
.ag-theme-alpine-dark .ag-charts-format-top-level-group-toolbar,
.ag-theme-alpine-dark .ag-charts-advanced-settings-top-level-group-toolbar,
.ag-theme-alpine-auto-dark .ag-charts-format-top-level-group-toolbar,
.ag-theme-alpine-auto-dark .ag-charts-advanced-settings-top-level-group-toolbar {
  margin-top: var(--ag-grid-size);
}
.ag-theme-alpine .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-dark .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-dark .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar {
  padding-left: calc(var(--ag-icon-size) * 0.5 + var(--ag-grid-size) * 2);
}

.ag-theme-alpine .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-dark .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-dark .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar {
  padding-right: calc(var(--ag-icon-size) * 0.5 + var(--ag-grid-size) * 2);
}

.ag-theme-alpine .ag-charts-format-sub-level-group,
.ag-theme-alpine-dark .ag-charts-format-sub-level-group,
.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group {
  border-left: dashed 1px;
  border-left-color: var(--ag-border-color);
  padding-left: var(--ag-grid-size);
  margin-bottom: calc(var(--ag-grid-size) * 2);
}
.ag-theme-alpine .ag-charts-format-sub-level-group-title-bar,
.ag-theme-alpine-dark .ag-charts-format-sub-level-group-title-bar,
.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-title-bar {
  padding-top: 0;
  padding-bottom: 0;
  background: none;
  font-weight: 700;
}
.ag-theme-alpine .ag-charts-format-sub-level-group-container,
.ag-theme-alpine-dark .ag-charts-format-sub-level-group-container,
.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-container {
  padding-bottom: 0;
}
.ag-theme-alpine .ag-charts-format-sub-level-group-item:last-child,
.ag-theme-alpine-dark .ag-charts-format-sub-level-group-item:last-child,
.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-item:last-child {
  margin-bottom: 0;
}
.ag-theme-alpine.ag-dnd-ghost,
.ag-theme-alpine-dark.ag-dnd-ghost,
.ag-theme-alpine-auto-dark.ag-dnd-ghost {
  font-size: calc(var(--ag-font-size) - 1px);
  font-weight: 700;
}
.ag-theme-alpine .ag-side-buttons,
.ag-theme-alpine-dark .ag-side-buttons,
.ag-theme-alpine-auto-dark .ag-side-buttons {
  width: calc(var(--ag-grid-size) * 5);
}
.ag-theme-alpine .ag-standard-button,
.ag-theme-alpine-dark .ag-standard-button,
.ag-theme-alpine-auto-dark .ag-standard-button {
  font-family: inherit;
  -moz-appearance: none;
       appearance: none;
  -webkit-appearance: none;
  border-radius: var(--ag-border-radius);
  border: 1px solid;
  border-color: var(--ag-alpine-active-color);
  color: var(--ag-alpine-active-color);
  background-color: var(--ag-background-color);
  font-weight: 600;
  padding: var(--ag-grid-size) calc(var(--ag-grid-size) * 2);
}
.ag-theme-alpine .ag-standard-button:hover,
.ag-theme-alpine-dark .ag-standard-button:hover,
.ag-theme-alpine-auto-dark .ag-standard-button:hover {
  border-color: var(--ag-alpine-active-color);
  background-color: var(--ag-row-hover-color);
}
.ag-theme-alpine .ag-standard-button:active,
.ag-theme-alpine-dark .ag-standard-button:active,
.ag-theme-alpine-auto-dark .ag-standard-button:active {
  border-color: var(--ag-alpine-active-color);
  background-color: var(--ag-alpine-active-color);
  color: var(--ag-background-color);
}
.ag-theme-alpine .ag-standard-button:disabled,
.ag-theme-alpine-dark .ag-standard-button:disabled,
.ag-theme-alpine-auto-dark .ag-standard-button:disabled {
  color: var(--ag-disabled-foreground-color);
  background-color: var(--ag-input-disabled-background-color);
  border-color: var(--ag-input-disabled-border-color);
}
.ag-theme-alpine .ag-column-drop-vertical,
.ag-theme-alpine-dark .ag-column-drop-vertical,
.ag-theme-alpine-auto-dark .ag-column-drop-vertical {
  min-height: 75px;
}
.ag-theme-alpine .ag-column-drop-vertical-title-bar,
.ag-theme-alpine-dark .ag-column-drop-vertical-title-bar,
.ag-theme-alpine-auto-dark .ag-column-drop-vertical-title-bar {
  padding: calc(var(--ag-grid-size) * 2);
  padding-bottom: 0px;
}
.ag-theme-alpine .ag-column-drop-vertical-empty-message,
.ag-theme-alpine-dark .ag-column-drop-vertical-empty-message,
.ag-theme-alpine-auto-dark .ag-column-drop-vertical-empty-message {
  display: flex;
  align-items: center;
  border: dashed 1px;
  border-color: var(--ag-border-color);
  margin: calc(var(--ag-grid-size) * 2);
  padding: calc(var(--ag-grid-size) * 2);
}
.ag-theme-alpine .ag-column-drop-empty-message,
.ag-theme-alpine-dark .ag-column-drop-empty-message,
.ag-theme-alpine-auto-dark .ag-column-drop-empty-message {
  color: var(--ag-foreground-color);
  opacity: 0.75;
}
.ag-theme-alpine .ag-pill-select .ag-column-drop,
.ag-theme-alpine-dark .ag-pill-select .ag-column-drop,
.ag-theme-alpine-auto-dark .ag-pill-select .ag-column-drop {
  min-height: unset;
}
.ag-theme-alpine .ag-status-bar,
.ag-theme-alpine-dark .ag-status-bar,
.ag-theme-alpine-auto-dark .ag-status-bar {
  font-weight: normal;
}
.ag-theme-alpine .ag-status-name-value-value,
.ag-theme-alpine-dark .ag-status-name-value-value,
.ag-theme-alpine-auto-dark .ag-status-name-value-value {
  font-weight: 700;
}
.ag-theme-alpine .ag-paging-number,
.ag-theme-alpine .ag-paging-row-summary-panel-number,
.ag-theme-alpine-dark .ag-paging-number,
.ag-theme-alpine-dark .ag-paging-row-summary-panel-number,
.ag-theme-alpine-auto-dark .ag-paging-number,
.ag-theme-alpine-auto-dark .ag-paging-row-summary-panel-number {
  font-weight: 700;
}
.ag-theme-alpine .ag-column-drop-cell-button,
.ag-theme-alpine-dark .ag-column-drop-cell-button,
.ag-theme-alpine-auto-dark .ag-column-drop-cell-button {
  opacity: 0.5;
}
.ag-theme-alpine .ag-column-drop-cell-button:hover,
.ag-theme-alpine-dark .ag-column-drop-cell-button:hover,
.ag-theme-alpine-auto-dark .ag-column-drop-cell-button:hover {
  opacity: 0.75;
}
.ag-theme-alpine .ag-column-select-column-readonly.ag-icon-grip,
.ag-theme-alpine .ag-column-select-column-readonly .ag-icon-grip,
.ag-theme-alpine-dark .ag-column-select-column-readonly.ag-icon-grip,
.ag-theme-alpine-dark .ag-column-select-column-readonly .ag-icon-grip,
.ag-theme-alpine-auto-dark .ag-column-select-column-readonly.ag-icon-grip,
.ag-theme-alpine-auto-dark .ag-column-select-column-readonly .ag-icon-grip {
  opacity: 0.35;
}
.ag-theme-alpine .ag-header-cell-menu-button:hover,
.ag-theme-alpine .ag-header-cell-filter-button:hover,
.ag-theme-alpine .ag-side-button-button:hover,
.ag-theme-alpine .ag-tab:hover,
.ag-theme-alpine .ag-panel-title-bar-button:hover,
.ag-theme-alpine .ag-header-expand-icon:hover,
.ag-theme-alpine .ag-column-group-icons:hover,
.ag-theme-alpine .ag-set-filter-group-icons:hover,
.ag-theme-alpine .ag-group-expanded .ag-icon:hover,
.ag-theme-alpine .ag-group-contracted .ag-icon:hover,
.ag-theme-alpine .ag-chart-settings-prev:hover,
.ag-theme-alpine .ag-chart-settings-next:hover,
.ag-theme-alpine .ag-group-title-bar-icon:hover,
.ag-theme-alpine .ag-column-select-header-icon:hover,
.ag-theme-alpine .ag-floating-filter-button-button:hover,
.ag-theme-alpine .ag-filter-toolpanel-expand:hover,
.ag-theme-alpine .ag-chart-menu-icon:hover,
.ag-theme-alpine-dark .ag-header-cell-menu-button:hover,
.ag-theme-alpine-dark .ag-header-cell-filter-button:hover,
.ag-theme-alpine-dark .ag-side-button-button:hover,
.ag-theme-alpine-dark .ag-tab:hover,
.ag-theme-alpine-dark .ag-panel-title-bar-button:hover,
.ag-theme-alpine-dark .ag-header-expand-icon:hover,
.ag-theme-alpine-dark .ag-column-group-icons:hover,
.ag-theme-alpine-dark .ag-set-filter-group-icons:hover,
.ag-theme-alpine-dark .ag-group-expanded .ag-icon:hover,
.ag-theme-alpine-dark .ag-group-contracted .ag-icon:hover,
.ag-theme-alpine-dark .ag-chart-settings-prev:hover,
.ag-theme-alpine-dark .ag-chart-settings-next:hover,
.ag-theme-alpine-dark .ag-group-title-bar-icon:hover,
.ag-theme-alpine-dark .ag-column-select-header-icon:hover,
.ag-theme-alpine-dark .ag-floating-filter-button-button:hover,
.ag-theme-alpine-dark .ag-filter-toolpanel-expand:hover,
.ag-theme-alpine-dark .ag-chart-menu-icon:hover,
.ag-theme-alpine-auto-dark .ag-header-cell-menu-button:hover,
.ag-theme-alpine-auto-dark .ag-header-cell-filter-button:hover,
.ag-theme-alpine-auto-dark .ag-side-button-button:hover,
.ag-theme-alpine-auto-dark .ag-tab:hover,
.ag-theme-alpine-auto-dark .ag-panel-title-bar-button:hover,
.ag-theme-alpine-auto-dark .ag-header-expand-icon:hover,
.ag-theme-alpine-auto-dark .ag-column-group-icons:hover,
.ag-theme-alpine-auto-dark .ag-set-filter-group-icons:hover,
.ag-theme-alpine-auto-dark .ag-group-expanded .ag-icon:hover,
.ag-theme-alpine-auto-dark .ag-group-contracted .ag-icon:hover,
.ag-theme-alpine-auto-dark .ag-chart-settings-prev:hover,
.ag-theme-alpine-auto-dark .ag-chart-settings-next:hover,
.ag-theme-alpine-auto-dark .ag-group-title-bar-icon:hover,
.ag-theme-alpine-auto-dark .ag-column-select-header-icon:hover,
.ag-theme-alpine-auto-dark .ag-floating-filter-button-button:hover,
.ag-theme-alpine-auto-dark .ag-filter-toolpanel-expand:hover,
.ag-theme-alpine-auto-dark .ag-chart-menu-icon:hover {
  color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-header-cell-menu-button:hover .ag-icon,
.ag-theme-alpine .ag-header-cell-filter-button:hover .ag-icon,
.ag-theme-alpine .ag-side-button-button:hover .ag-icon,
.ag-theme-alpine .ag-panel-title-bar-button:hover .ag-icon,
.ag-theme-alpine .ag-floating-filter-button-button:hover .ag-icon,
.ag-theme-alpine-dark .ag-header-cell-menu-button:hover .ag-icon,
.ag-theme-alpine-dark .ag-header-cell-filter-button:hover .ag-icon,
.ag-theme-alpine-dark .ag-side-button-button:hover .ag-icon,
.ag-theme-alpine-dark .ag-panel-title-bar-button:hover .ag-icon,
.ag-theme-alpine-dark .ag-floating-filter-button-button:hover .ag-icon,
.ag-theme-alpine-auto-dark .ag-header-cell-menu-button:hover .ag-icon,
.ag-theme-alpine-auto-dark .ag-header-cell-filter-button:hover .ag-icon,
.ag-theme-alpine-auto-dark .ag-side-button-button:hover .ag-icon,
.ag-theme-alpine-auto-dark .ag-panel-title-bar-button:hover .ag-icon,
.ag-theme-alpine-auto-dark .ag-floating-filter-button-button:hover .ag-icon {
  color: inherit;
}
.ag-theme-alpine .ag-filter-active .ag-icon-filter,
.ag-theme-alpine-dark .ag-filter-active .ag-icon-filter,
.ag-theme-alpine-auto-dark .ag-filter-active .ag-icon-filter {
  color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-chart-settings-card-item.ag-not-selected:hover,
.ag-theme-alpine-dark .ag-chart-settings-card-item.ag-not-selected:hover,
.ag-theme-alpine-auto-dark .ag-chart-settings-card-item.ag-not-selected:hover {
  opacity: 0.35;
}
.ag-theme-alpine .ag-ltr .ag-panel-title-bar-button, .ag-theme-alpine-dark .ag-ltr .ag-panel-title-bar-button, .ag-theme-alpine-auto-dark .ag-ltr .ag-panel-title-bar-button {
  margin-left: calc(var(--ag-grid-size) * 2);
  margin-right: var(--ag-grid-size);
}

.ag-theme-alpine .ag-rtl .ag-panel-title-bar-button, .ag-theme-alpine-dark .ag-rtl .ag-panel-title-bar-button, .ag-theme-alpine-auto-dark .ag-rtl .ag-panel-title-bar-button {
  margin-right: calc(var(--ag-grid-size) * 2);
  margin-left: var(--ag-grid-size);
}

.ag-theme-alpine .ag-ltr .ag-filter-toolpanel-group-container, .ag-theme-alpine-dark .ag-ltr .ag-filter-toolpanel-group-container, .ag-theme-alpine-auto-dark .ag-ltr .ag-filter-toolpanel-group-container {
  padding-left: var(--ag-grid-size);
}

.ag-theme-alpine .ag-rtl .ag-filter-toolpanel-group-container, .ag-theme-alpine-dark .ag-rtl .ag-filter-toolpanel-group-container, .ag-theme-alpine-auto-dark .ag-rtl .ag-filter-toolpanel-group-container {
  padding-right: var(--ag-grid-size);
}

.ag-theme-alpine .ag-filter-toolpanel-instance-filter,
.ag-theme-alpine-dark .ag-filter-toolpanel-instance-filter,
.ag-theme-alpine-auto-dark .ag-filter-toolpanel-instance-filter {
  border: none;
  background-color: var(--ag-control-panel-background-color);
}
.ag-theme-alpine .ag-ltr .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-dark .ag-ltr .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-auto-dark .ag-ltr .ag-filter-toolpanel-instance-filter {
  border-left: dashed 1px;
  border-left-color: var(--ag-border-color);
  margin-left: calc(var(--ag-icon-size) * 0.5);
}

.ag-theme-alpine .ag-rtl .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-dark .ag-rtl .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-auto-dark .ag-rtl .ag-filter-toolpanel-instance-filter {
  border-right: dashed 1px;
  border-right-color: var(--ag-border-color);
  margin-right: calc(var(--ag-icon-size) * 0.5);
}

.ag-theme-alpine .ag-set-filter-list,
.ag-theme-alpine-dark .ag-set-filter-list,
.ag-theme-alpine-auto-dark .ag-set-filter-list {
  padding-top: calc(var(--ag-grid-size) * 0.5);
  padding-bottom: calc(var(--ag-grid-size) * 0.5);
}
.ag-theme-alpine .ag-filter-add-button .ag-icon,
.ag-theme-alpine-dark .ag-filter-add-button .ag-icon,
.ag-theme-alpine-auto-dark .ag-filter-add-button .ag-icon {
  color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-layout-auto-height .ag-center-cols-viewport,
.ag-theme-alpine .ag-layout-auto-height .ag-center-cols-container,
.ag-theme-alpine .ag-layout-print .ag-center-cols-viewport,
.ag-theme-alpine .ag-layout-print .ag-center-cols-container,
.ag-theme-alpine-dark .ag-layout-auto-height .ag-center-cols-viewport,
.ag-theme-alpine-dark .ag-layout-auto-height .ag-center-cols-container,
.ag-theme-alpine-dark .ag-layout-print .ag-center-cols-viewport,
.ag-theme-alpine-dark .ag-layout-print .ag-center-cols-container,
.ag-theme-alpine-auto-dark .ag-layout-auto-height .ag-center-cols-viewport,
.ag-theme-alpine-auto-dark .ag-layout-auto-height .ag-center-cols-container,
.ag-theme-alpine-auto-dark .ag-layout-print .ag-center-cols-viewport,
.ag-theme-alpine-auto-dark .ag-layout-print .ag-center-cols-container {
  min-height: 150px;
}
.ag-theme-alpine .ag-date-time-list-page-entry-is-current,
.ag-theme-alpine-dark .ag-date-time-list-page-entry-is-current,
.ag-theme-alpine-auto-dark .ag-date-time-list-page-entry-is-current {
  background-color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-advanced-filter-builder-button,
.ag-theme-alpine-dark .ag-advanced-filter-builder-button,
.ag-theme-alpine-auto-dark .ag-advanced-filter-builder-button {
  padding: var(--ag-grid-size);
  font-weight: 600;
}
.ag-theme-alpine .ag-list-item-hovered::after,
.ag-theme-alpine-dark .ag-list-item-hovered::after,
.ag-theme-alpine-auto-dark .ag-list-item-hovered::after {
  background-color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-pill .ag-pill-button:hover,
.ag-theme-alpine-dark .ag-pill .ag-pill-button:hover,
.ag-theme-alpine-auto-dark .ag-pill .ag-pill-button:hover {
  color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-header-highlight-before::after,
.ag-theme-alpine .ag-header-highlight-after::after,
.ag-theme-alpine-dark .ag-header-highlight-before::after,
.ag-theme-alpine-dark .ag-header-highlight-after::after,
.ag-theme-alpine-auto-dark .ag-header-highlight-before::after,
.ag-theme-alpine-auto-dark .ag-header-highlight-after::after {
  background-color: var(--ag-alpine-active-color);
}
.ag-theme-alpine .ag-advanced-filter-builder-item-button-disabled .ag-icon,
.ag-theme-alpine .ag-disabled .ag-icon,
.ag-theme-alpine .ag-column-select-column-group-readonly .ag-icon,
.ag-theme-alpine [disabled] .ag-icon,
.ag-theme-alpine-dark .ag-advanced-filter-builder-item-button-disabled .ag-icon,
.ag-theme-alpine-dark .ag-disabled .ag-icon,
.ag-theme-alpine-dark .ag-column-select-column-group-readonly .ag-icon,
.ag-theme-alpine-dark [disabled] .ag-icon,
.ag-theme-alpine-auto-dark .ag-advanced-filter-builder-item-button-disabled .ag-icon,
.ag-theme-alpine-auto-dark .ag-disabled .ag-icon,
.ag-theme-alpine-auto-dark .ag-column-select-column-group-readonly .ag-icon,
.ag-theme-alpine-auto-dark [disabled] .ag-icon {
  color: var(--ag-disabled-foreground-color);
}
`, "",{"version":3,"sources":["webpack://./node_modules/ag-grid-community/styles/ag-theme-alpine.css"],"names":[],"mappings":"AAAA;EACE,2BAA2B;EAC3B,4CAA+6O;EAC/6O,mBAAmB;EACnB,kBAAkB;AACpB;AACA;;;EAGE,iCAAiC;EACjC,2DAA2D;EAC3D,6CAA6C;EAC7C,gDAAgD;EAChD,sDAAsD;EACtD,8DAA8D;EAC9D,iEAAiE;EACjE,iEAAiE;EACjE,iEAAiE;EACjE,mGAAmG;EACnG,2BAA2B;EAC3B,8BAA8B;EAC9B,0BAA0B;EAC1B,oCAAoC;EACpC,qCAAqC;EACrC,sCAAsC;EACtC,sCAAsC;EACtC,4CAA4C;EAC5C,qCAAqC;EACrC,2BAA2B;EAC3B,mCAAmC;EACnC,6CAA6C;EAC7C,+CAA+C;EAC/C,+CAA+C;EAC/C,8CAA8C;EAC9C,iDAAiD;EACjD,yCAAyC;EACzC,wDAAwD;EACxD,gDAAgD;EAChD,0DAA0D;EAC1D,0DAA0D;EAC1D,gEAAgE;EAChE,2DAA2D;EAC3D,+CAA+C;EAC/C,wDAAwD;EACxD,8EAA8E;EAC9E,yEAAyE;EACzE,8DAA8D;EAC9D,6DAA6D;EAC7D,gEAAgE;EAChE,8EAA8E;EAC9E,qDAAqD;EACrD,kDAAkD;EAClD,0DAA0D;EAC1D,+DAA+D;EAC/D,uBAAuB;EACvB,uBAAuB;EACvB,8BAA8B;EAC9B,uDAAuD;EACvD,+CAA+C;EAC/C,2CAA2C;EAC3C,4CAA4C;EAC5C,mBAAmB;EACnB,oBAAoB;EACpB,8CAA8C;EAC9C,iDAAiD;EACjD,oDAAoD;EACpD,mDAAmD;EACnD,gDAAgD;EAChD,6FAA6F;EAC7F,2DAA2D;EAC3D,uDAAuD;EACvD,qEAAqE;EACrE,uEAAuE;EACvE,6DAA6D;EAC7D,+BAA+B;EAC/B,8BAA8B;EAC9B;kCACgC;EAChC,oBAAoB;EACpB,mCAAmC;EACnC,gEAAgE;EAChE,sCAAsC;EACtC,kDAAkD;EAClD,yBAAyB;EACzB,wDAAwD;EACxD,wCAAwC;EACxC,gCAAgC;AAClC;;AAEA;EACE,8BAA8B;EAC9B,2BAA2B;EAC3B,0BAA0B;EAC1B,kDAAkD;EAClD,2DAA2D;EAC3D,qCAAqC;EACrC,sCAAsC;EACtC,sCAAsC;EACtC,4CAA4C;EAC5C,qCAAqC;EACrC,6CAA6C;EAC7C,mHAAmH;EACnH;8FAC4F;EAC5F,sCAAsC;EACtC,wDAAwD;EACxD,qDAAqD;EACrD,0DAA0D;EAC1D,+DAA+D;EAC/D,6CAA6C;EAC7C,+CAA+C;EAC/C,+CAA+C;EAC/C,8CAA8C;EAC9C,iDAAiD;EACjD,wDAAwD;EACxD,gEAAgE;EAChE,gEAAgE;EAChE,wCAAwC;EACxC,kBAAkB;AACpB;;AAEA;EACE;IACE,8BAA8B;IAC9B,2BAA2B;IAC3B,0BAA0B;IAC1B,kDAAkD;IAClD,2DAA2D;IAC3D,qCAAqC;IACrC,sCAAsC;IACtC,sCAAsC;IACtC,4CAA4C;IAC5C,qCAAqC;IACrC,6CAA6C;IAC7C,mHAAmH;IACnH;gGAC4F;IAC5F,sCAAsC;IACtC,wDAAwD;IACxD,qDAAqD;IACrD,0DAA0D;IAC1D,+DAA+D;IAC/D,6CAA6C;IAC7C,+CAA+C;IAC/C,+CAA+C;IAC/C,8CAA8C;IAC9C,iDAAiD;IACjD,wDAAwD;IACxD,gEAAgE;IAChE,gEAAgE;IAChE,wCAAwC;IACxC,kBAAkB;EACpB;AACF;AACA;;;;;;;;;;;;;;;;;;;;;;;;EAwBE,gBAAgB;EAChB,wCAAwC;AAC1C;AACA;;;EAGE,0CAA0C;AAC5C;AACA;;;;;;;;;;;;;;;;;;;;;EAqBE,yCAAyC;EACzC,sCAAsC;AACxC;AACA;EACE,iCAAiC;AACnC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;;;EAGE,wCAAwC;EACxC,sBAAsB;EACtB,cAAc;AAChB;AACA;;;EAGE,oCAAoC;AACtC;AACA;;;EAGE,0DAA0D;AAC5D;AACA;;;EAGE,0DAA0D;AAC5D;AACA;;;EAGE,0DAA0D;EAC1D,gBAAgB;AAClB;AACA;;;EAGE,uDAAuD;AACzD;AACA;;;;;;;;;;;;EAYE,0DAA0D;EAC1D,kEAAkE;AACpE;AACA;;;EAGE,4CAA4C;AAC9C;AACA;;;EAGE,wEAAwE;AAC1E;AACA;EACE,iCAAiC;AACnC;;AAEA;EACE,gCAAgC;AAClC;;AAEA;;;;;;EAME,+BAA+B;AACjC;AACA;EACE,uEAAuE;AACzE;;AAEA;EACE,wEAAwE;AAC1E;;AAEA;;;EAGE,uBAAuB;EACvB,yCAAyC;EACzC,iCAAiC;EACjC,4CAA4C;AAC9C;AACA;;;EAGE,cAAc;EACd,iBAAiB;EACjB,gBAAgB;EAChB,gBAAgB;AAClB;AACA;;;EAGE,iBAAiB;AACnB;AACA;;;EAGE,gBAAgB;AAClB;AACA;;;EAGE,0CAA0C;EAC1C,gBAAgB;AAClB;AACA;;;EAGE,oCAAoC;AACtC;AACA;;;EAGE,oBAAoB;EACpB,qBAAgB;OAAhB,gBAAgB;EAChB,wBAAwB;EACxB,sCAAsC;EACtC,iBAAiB;EACjB,2CAA2C;EAC3C,oCAAoC;EACpC,4CAA4C;EAC5C,gBAAgB;EAChB,0DAA0D;AAC5D;AACA;;;EAGE,2CAA2C;EAC3C,2CAA2C;AAC7C;AACA;;;EAGE,2CAA2C;EAC3C,+CAA+C;EAC/C,iCAAiC;AACnC;AACA;;;EAGE,0CAA0C;EAC1C,2DAA2D;EAC3D,mDAAmD;AACrD;AACA;;;EAGE,gBAAgB;AAClB;AACA;;;EAGE,sCAAsC;EACtC,mBAAmB;AACrB;AACA;;;EAGE,aAAa;EACb,mBAAmB;EACnB,kBAAkB;EAClB,oCAAoC;EACpC,qCAAqC;EACrC,sCAAsC;AACxC;AACA;;;EAGE,iCAAiC;EACjC,aAAa;AACf;AACA;;;EAGE,iBAAiB;AACnB;AACA;;;EAGE,mBAAmB;AACrB;AACA;;;EAGE,gBAAgB;AAClB;AACA;;;;;;EAME,gBAAgB;AAClB;AACA;;;EAGE,YAAY;AACd;AACA;;;EAGE,aAAa;AACf;AACA;;;;;;EAME,aAAa;AACf;AACA;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;EAmDE,oCAAoC;AACtC;AACA;;;;;;;;;;;;;;;EAeE,cAAc;AAChB;AACA;;;EAGE,oCAAoC;AACtC;AACA;;;EAGE,aAAa;AACf;AACA;EACE,0CAA0C;EAC1C,iCAAiC;AACnC;;AAEA;EACE,2CAA2C;EAC3C,gCAAgC;AAClC;;AAEA;EACE,iCAAiC;AACnC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;;;EAGE,YAAY;EACZ,0DAA0D;AAC5D;AACA;EACE,uBAAuB;EACvB,yCAAyC;EACzC,4CAA4C;AAC9C;;AAEA;EACE,wBAAwB;EACxB,0CAA0C;EAC1C,6CAA6C;AAC/C;;AAEA;;;EAGE,4CAA4C;EAC5C,+CAA+C;AACjD;AACA;;;EAGE,oCAAoC;AACtC;AACA;;;;;;;;;;;;EAYE,iBAAiB;AACnB;AACA;;;EAGE,+CAA+C;AACjD;AACA;;;EAGE,4BAA4B;EAC5B,gBAAgB;AAClB;AACA;;;EAGE,+CAA+C;AACjD;AACA;;;EAGE,oCAAoC;AACtC;AACA;;;;;;EAME,+CAA+C;AACjD;AACA;;;;;;;;;;;;EAYE,0CAA0C;AAC5C","sourcesContent":["@font-face {\n  font-family: \"agGridAlpine\";\n  src: url(data:font/woff2;charset=utf-8;base64,d09GMgABAAAAABYgAAsAAAAALyQAABXQAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHItKBmAAjRIKsnypPAE2AiQDgmgLgTYABCAFhEYHhkUb5ChlBGwcAPHYSUAUJXMzElFBKc7+/0OCNkaI+HHamlJAkxnRpkST9u5ev/XGo7HZ035fr+JSYjDQIxFCWGJJ+6YxMUvnue2AIcfQec/9TxyzDZTDDklCkyCaI2eTPIFCoQglYwnoVTWgkdWvqzSBuxL6oJvfK4Q2Nf1e/WIGJBCkhlRO1KbxhvmW4Tb7g7b1D1aMZi3Qw8JCGxAFdZeoOfPrYmIHRh1cVOFV4EV6tVcV/NCL1F8BMAPPRvjg6LaLSWM0WLep3KputKobOSFhZkUdODWgZfeY8cias1X5JN/kS4KsGbImgtTdy+Qruj9T33KtSeYblnPKmO33ve4YdJiEk3hCnEsE/J/Osl0dIM8RF9311HWj0ayt769Zr+yj2VkirY50rAPiMFTE1vryYh97Q6gAVUmZVMBluiv69KmpaFKWVzRtsJRDGT6AzS4lSHGaK8KIXfb4FbnoxjTweISSY6tjbNUNbLWRhCgWYOTFR74dASptuyRNzbgBMmcPfXqDacTsugHPq8fZU0/vg3aTyJIugYZcck9G08gn/6MlxsdGNphfLyrJfKEv+ktayai6TRFJ2jw3HaNRcQaTIInSqzFNFpusbE7CLZikJNMHQhMInSHMlm6VbUmOysuxfl9XgONjp880mt/YZdmlYQorFAZNG6dIqdt1SSiKG2D6bC6VXb31AqonpBI8jCdP0eNgXNfIV7hcibwdknClcOsWC394MdNnbLkix+j816h2yuqSa6zocJnsLyjbEU9d3BRihC2EwdEJtuuq5vomrk/lbtncSl9HMD1cA/m7r4yJylh0zvPIFxuS/C2wHy6P4sw1iRR62a4rrI++rYsZ4TbRasVA6BD9g8j/XJDGtopQDas3ljfP883PAzd9jCJSDX6MjvyoifbiSXcnnrBS0cbGD77L1Ivt+qnCmloQdxIPnfFE5dbYxtLul9I4LLi9RRRuXIoZ6mJdXxj9YkZ3lFQBf/24Wspwbhu5IhHu+yIZiVElJd5NxulUjofGeM4k1pWBcLxn7EtdGxEtTV6OoMD2Dynh0gfRaDZbCpgdNZA50NyhLPmwSEckTFu2azYrP2wcQTODPfKIcKoelY2fLvhPRilazL0Gu8Ee+d/UlPNXbdN0zKFUPUbdOWNMrXOmQbzTDjQmgkJW3P4hyhrKVs3Onktk9IfemxLcnwbHhKihbIJMEorJWadV69/zyhcn0ktQrI39YuAnhvv6TiXSLOGGFtGDEIenklUDthYlAsUs/DwcZlB7SI0sts2Tv35FqmrdVVbhli/2w1WecrCRBFayoJ5zcUSGesJEXr8rOlwev+5fzgjJ/sQjNMjWs6PAvfsfPp7rCyqQUXLMXtHacf4Iv3Ulnpuxu5BSTu1bUA2QOHsOOkEBWf/yqugkP7J7TKSQtFUtWgZvZcNz7/xIf+L//+ty30sfEkzY6y1mMmTm61ctO/YLAlFdzmGOowPPNXS45V1iCkPJJTBk6RkYi5DIiGxRMVRcQlJKupNbVk5eQVFJWcWESVNjmGn8CXFOVU1dQ1PLvAWLlixbsWrNug2bttRt27FLlrNn34FDR46dOHXm3IVLV64hSjGbyZv8nz++6nhspLUNdJZ8YYbQF3gwtHqDMarpqoHioMV7Qdc12QQOkXFwmKyCI2QRHCWbwTEyBY6TneAEmQAnyTI4RWbAGbICzpIlcI5sAefJHLhAZsFFsg1cJpPgClkAV8k0uEa2gutkB7hB5sFNsgZuke1gPXi7IAG5BwqQAAuIgAqYgAuEQAqUQAuMwAqcwAuCIAqSIAuKoAqaoAuGYAqWYAuO4Aqe4AuBEAqREAuJkAqZkAuFUAqVUAuN0Aqd0PufbpD3RmESZiOHtIx6SGvWswm7cAincAkP4Sm8hLcxBOkzhiF9s72f8OceoAq7b8+zAZ5CWRdUtpmVxGsP8ygXBJTmrozg42KFpY/8FV+C1U1GlK/Nt2INUfnMt9tqzvELDn+OJFk73rWP8mrGiMtVNQRFhZVsKQcCWZmMJBVx4npYwQ5xoUL/zWazUzZZKr9dtBojspEykZTSNhnXrjbdJD03A6kmVSRnlM3qYLAtAzDWlXsyqUb7fFZbhqeddiXVH5NuQwDpESLHXvH4lrUAoAQEYYCzYDehixhflaAkzvsoYYspjxHWHee8DJkkd2E3TSuSZpI6u+i00cXirS4Ga/4Bdn7BSIqzNOVJomEPYhggFbuQ9op57xjw6cfv41ethyeh3zjxYIvCqUrvT7MjBMOa7xX/PoQNyhdUkr/klOYi5bZDQH9uvYTGlNIELeQN9yAXzlhe7EYuTZaMSKMFzGfAg71B6lfoz3FQNsBrvECdAW9whVpNMFEkpipcc1hT7LmAL4MW/ty7ENziD9KCUMS4s08vlMvIPFAtlXZAY+/Ri9g6fxjoOdMRS1VkHgP69opVG5jPWzbVD51D5hjnqBOZi0UbWzVolA6IB6pHjKO1pfZXirma5pTMMtBtWxi9X7ArRU55PgoLe20dREgul+44IhPFMvzFFYqzs3ZaWKbygo2GXq+bzSY03makchwQTTRaLWzN7jXPHdIPn7cuHjWOXFhpPuuZDMYLlWbyO6qnIlqKuNddYV/IakNtzgzzGwexVWmnPNoiXWMP0McRahvt7DMPiEy3c+9DZhUaaxQ1SeiKVIK29LpiKkSO1RfFFqXqqN5sMjF6skXP1ac1ugJbPNUnzOTKBEtebEL9JNrizao2N1gtX9brRKqwr0VeDtabJZnYK0Rjk6dfXY0A4mYwvJKCNOQbGE8RqmAX4ghiah3ManJKDQRgPwjBJRoEBrCOBYIg6FV0U5JcCWzmBgd4SpLTLJgxbj7FGbkWRlDx5AakS6axfgSw9fh649ojBIauDSiM3Hgt+Fd9wdL9ARhcaQGPYBULPckU0o3B9PNgLehC8GgjbdYLaMUznGgW+EKfH17NMhLjlBKWoHwBJiQj1Eei8Zh0pSmbzbh6uQH0TBtpaMcT89EgtAxahHMLWBW9bFaN2rKQF4MgxCqL5p/fhKPvn32X75haW3gwKo87NO7cHCLY7bsnHZo3ipH4in2RgtBO7sy6NU6O1oZuHTGACza2owcHMu10ozH4q8Xb6vVZ3/SdaTaHfJ3Z2WrN/b435Gnwsy+Htlbqwvbns0dDNfJxEhNnr5yFhI+bDzkWuT337sTa0NX6cAxZfRiG3DSfDSIY4n6Ah+x4MadvH5oFML+DAM6OB2s93/It3+rbxBazH4xNzOobo/HWilHjY3PoWD6942UABI9JZcPFvzYMQiuwB3WvpGyS3K8qGVVWVbpR4d2JiSxZYlZ2RqwDttdnJR+24O6JCaJ4Pb1XB5NnqHHy6VgK9FWZ3qw9049t2XadplmXAQJodlLtDwiKAlBd4GyhF3C/1RKpoT0ZYJjRsDtH+pG4x3xhvLSe68/WYkqftoYwgfo5TNCgWRXgmQv6tCisSdZniD41bLSaaiQT9oS6PUFvL/taaOimCVabHucb4AzMj43GEmxUeVy5rTAhPr9JhbYcWCJwOvbi1KMjSqLITy+sTZ3I0nFpEYllaWFUTjRFkbTvbts2LsI2KAnqxi4eWzvt+2TlRaxJbhLfEALhjGNEed4SqL2tbH7kOKZm6xHXFtmHoTwrUAGuIZjM+qcr2yOE2romzcA5U90R5YJM2YAuVJKN8ZcHg8/h1om6CrVEAox7Ni4HAOGtEY5YTTUnXIEwiHFXZ+FYTUkEZvMHrf1C8p0vsBDZuGJCcsr3k//A/31Uxv/AHE86fvuYpmx78UYyNtH1XXScHZwv5rAg4Rd0mhgLBgd+L73/5X/y+525+glkAEPfttf1zOuaM6drXs93prn/rjk9875j6F5YtHOCIhTYwesAA/uDvmbgGshhw4ihs9PQZYC4RWZb74jb3qfsdoQ3/Hj82LZubqmpF85v2pSalu7MDgtvCU8u7LHtG4pe25yaGv44tXbtyrIyKjUp8YLe2IXzF3Ylbd8+5w8N0x8U4M8k/pwD/TdHdDzdgN6MBNlp53XVg0dbRHx3jXs2fCUwETn+jQ3+KkL1TZ95xR/Yqt3W/8pCFRuUcuUV1RX4HJubJ5Xmlb7VgUUUZi5yAsHtD9WVHc0T5HsowdXBMcFVwQLr2qqYvu+m15vO7hmUu9YhYufHlOa19+3nsm67OlfHjKyRu/mf7UBcPBKCUJvVDj2J7Twnj31c3yOVvjk5zLGOq3Y7Mhlu7izHy99QuzmOvTUtf9rTs1HHtR7fBeuh2/W1O6q36HJb41ArSnvljTrY5G+VurtvPI/2JcwJPcIhGaHg1mPXmWJLY/DvMJqWOR0qZHCvRVrbrkF1sMM+duxxwYOs63ckYg5PE8PVVLmLhlv14jEaHiYu7S5sCy7w5bFmFd6AJoYXxFqb7HmpL9Z4KfawMbbvMEIJ7krvSsMeWnXC6BF+ZQ+h/DgM0r/NoV3SMZ/d7Qu53aPr5jSMdsed6P4/E/LwvNW3iLPWTlH29JTUhqzu44vROQxXRmzO2Oye2Gk0aydfJxRayLhOxg8N31cnuuEqqVJpQoqzjbK23lHpnFCBTHv6Glmp5dZng1He1uOVLhImp1aUWF+VZcYwxSVl4wXq39Rs0+rYMDWHowyLtbUq7uJlRYEqgqdSpYrY+QxxqUT9HMgZqtCP3nxvznN1SRlTXHxj0Vuv9LZeo2yHyiM4o+IreKULpxpDK6OmiWsCCYK9Opf3HSFzpx7f9Rv2uNce7Hv0GL7xTxxXrL81nstfiW8ErOlNDRipxw34EX1wPC7GziBJryGDDovH4kici+sHDLihKzDDsN737uzE43H9cBwGhGXwaa/CWNdmeT7q/bfZbBo9MA1lRtjzle25l705fbOwOC6uqNU0ICTOxt7ryTZx0oi0zk1vZaAIzdK+WJcCPFP4KdMDf/yoqlioPUVVXiI/hb8vOaFtI5N/CAQ272amVDCAdXXlPqNQJJK9wTOrOy5dXXlPiaCn0H9LqMN0Bh0O98Z0gA0IzhTsvp/LA41ZEf3/PsY0xcfBW9antuTZBWFTwl3y4fZaj60tCE8JS04OSwkvEFaz192+7cmuTnGBuFCUDWIm1e+8+2/Gv2d3+YO/0bLUnkdJn8ae5g9ffv6g2kgY1hoIyDAsWGDtKUqbdWGlua6sZP7WRMz7IYuVPPBaqayuoFkwAkTp5+uWLHnzhnw7N2reXsN3o7GwFbVlMjvK3a3a6IuXtC2ye3nf4/OdO9DnYmqRczhyK2SUTCvSH1r8/SBsiD1/C+OGaIPWfjzUevDnVboTyvP7NOaw43KSILIIcnpLCEepCNW1TyfjIRHkik9894X3bAQspZV+bO8xmLcwjMN+8ZM7LKCrF8ePjtH3Ugqfm0XdLZyvH3dc36IaOw52fO7/QJWmf//t3NTmKm1QbuDMmYG5QdqrpimcOfO+YW3Q1YTUluWTG7WCPD4/T6B9XLTuP4+vFTxm1oavg/JWqbR1Oinj04P/nGxYTZWPTGJ6L8tfCGXw1jx5Mo3K3Y3vjh/EuBi8XemYqgrg7EPc/o7wydvkDykJTav1/PlTKhUJvb0lEiAluiIdfN4xL+2Vcb1UAmfOLKI0dgL5yqsirDRRuGZ+S8gmbVaWtap+wvhlqhqxcLm9Dr8H0q8ajQ/RWlSoVm/ezDt0GKrveK3El2/2kPb25fhmmq2IJWYBcecO2km59UYI+LokuCrtuSBoOGj19XWBaP3QhE0aZQuhHDiEHTpAKFo0is0TmFiIIgN5mpLuzvGi8sP44YFQ+JWbxjOSQjQZBF5bA26T6h3oDrs3ejq2HYPQnn/NUYdnUOPnAG3cIW7SLt0BHf1xRwe5ft369SQ8c6qsvJySakudWGg0fjfsnRflfPVKRkZSKTrz4GBPWUmdeeWFk4pQa3otbNu2eHHd+XRRAMOCVl2hVL4eSO7pppOnTmr27CETRJmZnz3uv7Rb1LZ4Cb3Nyr28o70dbPhOTkO6cAI24axLxlxwwV3AZhFdfmY8Nh5FJLoVUjzUXAu+Njz8NPgplr1G6w968uBh0+e2EP1lEbdjxtOKBY+eBX13EXt2Gu9pxgratYfFbuVOiNlRoE9oUD/YSu/uyZAkzp5nMfF5ll3k8P/9Z1tLMkt6uu3byFmwFXRM2+puYeCceQGK3ae0uLYGr3Gow4FTp3jXr6M3rsu7FisV01d4zTBRTDM8VyxXKFaEz0BBP+7///+subcfy1CHkIj/f6sNHhwNACBSwzOXID8NHUnVjVSAGVFGkrXb64+MR06Y87ke+P8PbkL+QmesQZ5UtQVEi4hZVUY8UQ/df2ZDIgK2mRQ1zaaew+7//ANiBrNfWxcxb8IAsbPodd4hzm2ahzSYrPTIGDB3aivZqAqVgtRDN4RqpHMUgniRpBpkE+KiWsiQ2Klq73qV+aiGmomkmMzTxGoUMcXywlE0B4u6biB1LeKNrKSSGcjMNon6/5x4dQBtzeYWOyV+t7ZDzICSb/Pm+Hi85XiXWIPr95gC9KNlTtnWX+jyfxfK0tmOe/+yrL/+Eyk9ba3+C5cxNmCLjwDw18wSZziPkCLBI0kF/54DIIF4HTSLlkMJDTBMJJYQgDlgmyCkcHE7eB0aAQFoYQMQ2mD8G3FBCArgvrbcDB5oeZx4QYT74IOWfxEEjGLxu2EYQ8nvMf6XBPclpkD4G32JRuit0Hf5j5IDU/Xa3ct7fb+QUIyiq063Knf+TbWpGuG2+sm0XlGMXCXhD7R6PKum9+ee4/gNHy23PeN/SXBfYgqEv3H/yJVoRGKHkPyPO8jwY2OqXo8vktov5jEVoOB11enm+HPn3/Qpm8pyhNsAf1bKJCE+gS+Ykp0PtFgdzwWc9P783Fcjq462Er7m7wSVj/NH75YijyJKojTKojwqfv+gqqPml4HX9npBlGRF1XTDtGzH9fwgjOIkzfKirOqm7fphnOZl3fbjvG73x/Olajrjhiks23HbnW6v7/lBOBiOxjdubtGrMt4LeqOBaWxE+JIHJtuxNWQxjuzZiG5nRbSfJ77Wfhm6J+oygRwqShvIKO558wpJ+ZeWI0udQqytTEIsLeW5ZVIxVtENLafbyArnPLC5G9iiQ4fZjvBatzkdO5nKA90Mb1jnaPJ5EFSMmxBrNEfJJlmHXkIaeeGShsIAHUZsdBwDKc51Etm4QH7ammtowx2HLVKZGsqJXAmvOiQmXBBrbWLkC7pRqiBHHKRAoxQ61mkS7AKXvJWSvh+uT0WVqeam2VDZaCTBn3WYTYfz3F4X144vFDKdrAUYWazpWTcYtGPuZ6+C2JM4o1fmhDQt1BbPMMWSRyI6sWkrdH31KiSqtm9uXvYs1gMox4U63KaV9UKErj6xKrdzokI5zcfG7sTg0pKWIdM0emXXghUYV2ve419sbZwbogsKBjwIICgEYCC4QAYLEc7wCSe4Qu2ghQIJbtBBA/ce);\n  font-weight: normal;\n  font-style: normal;\n}\n.ag-theme-alpine,\n.ag-theme-alpine-dark,\n.ag-theme-alpine-auto-dark {\n  --ag-alpine-active-color: #2196f3;\n  --ag-selected-row-background-color: rgba(33, 150, 243, 0.3);\n  --ag-row-hover-color: rgba(33, 150, 243, 0.1);\n  --ag-column-hover-color: rgba(33, 150, 243, 0.1);\n  --ag-input-focus-border-color: rgba(33, 150, 243, 0.4);\n  --ag-range-selection-background-color: rgba(33, 150, 243, 0.2);\n  --ag-range-selection-background-color-2: rgba(33, 150, 243, 0.36);\n  --ag-range-selection-background-color-3: rgba(33, 150, 243, 0.49);\n  --ag-range-selection-background-color-4: rgba(33, 150, 243, 0.59);\n  --ag-row-numbers-selected-color: color-mix(in srgb, transparent, var(--ag-alpine-active-color) 50%);\n  --ag-background-color: #fff;\n  --ag-foreground-color: #181d1f;\n  --ag-border-color: #babfc7;\n  --ag-secondary-border-color: #dde2eb;\n  --ag-header-background-color: #f8f8f8;\n  --ag-tooltip-background-color: #f8f8f8;\n  --ag-odd-row-background-color: #fcfcfc;\n  --ag-control-panel-background-color: #f8f8f8;\n  --ag-subheader-background-color: #fff;\n  --ag-invalid-color: #e02525;\n  --ag-checkbox-unchecked-color: #999;\n  --ag-advanced-filter-join-pill-color: #f08e8d;\n  --ag-advanced-filter-column-pill-color: #a6e194;\n  --ag-advanced-filter-option-pill-color: #f3c08b;\n  --ag-advanced-filter-value-pill-color: #85c0e4;\n  --ag-find-match-color: var(--ag-foreground-color);\n  --ag-find-match-background-color: #ffff00;\n  --ag-find-active-match-color: var(--ag-foreground-color);\n  --ag-find-active-match-background-color: #ffa500;\n  --ag-checkbox-background-color: var(--ag-background-color);\n  --ag-checkbox-checked-color: var(--ag-alpine-active-color);\n  --ag-range-selection-border-color: var(--ag-alpine-active-color);\n  --ag-secondary-foreground-color: var(--ag-foreground-color);\n  --ag-input-border-color: var(--ag-border-color);\n  --ag-input-border-color-invalid: var(--ag-invalid-color);\n  --ag-input-focus-box-shadow: 0 0 2px 0.1rem var(--ag-input-focus-border-color);\n  --ag-input-error-focus-box-shadow: 0 0 2px 0.1rem var(--ag-invalid-color);\n  --ag-panel-background-color: var(--ag-header-background-color);\n  --ag-menu-background-color: var(--ag-header-background-color);\n  --ag-filter-panel-apply-button-color: var(--ag-background-color);\n  --ag-filter-panel-apply-button-background-color: var(--ag-alpine-active-color);\n  --ag-disabled-foreground-color: rgba(24, 29, 31, 0.5);\n  --ag-chip-background-color: rgba(24, 29, 31, 0.07);\n  --ag-input-disabled-border-color: rgba(186, 191, 199, 0.3);\n  --ag-input-disabled-background-color: rgba(186, 191, 199, 0.15);\n  --ag-borders: solid 1px;\n  --ag-border-radius: 3px;\n  --ag-borders-side-button: none;\n  --ag-side-button-selected-background-color: transparent;\n  --ag-header-column-resize-handle-display: block;\n  --ag-header-column-resize-handle-width: 2px;\n  --ag-header-column-resize-handle-height: 30%;\n  --ag-grid-size: 6px;\n  --ag-icon-size: 16px;\n  --ag-row-height: calc(var(--ag-grid-size) * 7);\n  --ag-header-height: calc(var(--ag-grid-size) * 8);\n  --ag-list-item-height: calc(var(--ag-grid-size) * 4);\n  --ag-column-select-indent-size: var(--ag-icon-size);\n  --ag-set-filter-indent-size: var(--ag-icon-size);\n  --ag-advanced-filter-builder-indent-size: calc(var(--ag-icon-size) + var(--ag-grid-size) * 2);\n  --ag-cell-horizontal-padding: calc(var(--ag-grid-size) * 3);\n  --ag-cell-widget-spacing: calc(var(--ag-grid-size) * 2);\n  --ag-widget-container-vertical-padding: calc(var(--ag-grid-size) * 2);\n  --ag-widget-container-horizontal-padding: calc(var(--ag-grid-size) * 2);\n  --ag-widget-vertical-spacing: calc(var(--ag-grid-size) * 1.5);\n  --ag-toggle-button-height: 18px;\n  --ag-toggle-button-width: 28px;\n  --ag-font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen-Sans, Ubuntu, Cantarell,\n      \"Helvetica Neue\", sans-serif;\n  --ag-font-size: 13px;\n  --ag-icon-font-family: agGridAlpine;\n  --ag-selected-tab-underline-color: var(--ag-alpine-active-color);\n  --ag-selected-tab-underline-width: 2px;\n  --ag-selected-tab-underline-transition-speed: 0.3s;\n  --ag-tab-min-width: 240px;\n  --ag-card-shadow: 0 1px 4px 1px rgba(186, 191, 199, 0.4);\n  --ag-popup-shadow: var(--ag-card-shadow);\n  --ag-side-bar-panel-width: 250px;\n}\n\n.ag-theme-alpine-dark {\n  --ag-background-color: #181d1f;\n  --ag-foreground-color: #fff;\n  --ag-border-color: #68686e;\n  --ag-secondary-border-color: rgba(88, 86, 82, 0.5);\n  --ag-modal-overlay-background-color: rgba(24, 29, 31, 0.66);\n  --ag-header-background-color: #222628;\n  --ag-tooltip-background-color: #222628;\n  --ag-odd-row-background-color: #222628;\n  --ag-control-panel-background-color: #222628;\n  --ag-subheader-background-color: #000;\n  --ag-input-disabled-background-color: #282c2f;\n  --ag-input-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5), 0 0 4px 3px var(--ag-input-focus-border-color);\n  --ag-input-error-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5),\n      0 0 4px 3px color-mix(in srgb, var(--ag-background-color), var(--ag-invalid-color) 0.5%);\n  --ag-card-shadow: 0 1px 20px 1px black;\n  --ag-disabled-foreground-color: rgba(255, 255, 255, 0.5);\n  --ag-chip-background-color: rgba(255, 255, 255, 0.07);\n  --ag-input-disabled-border-color: rgba(104, 104, 110, 0.3);\n  --ag-input-disabled-background-color: rgba(104, 104, 110, 0.07);\n  --ag-advanced-filter-join-pill-color: #7a3a37;\n  --ag-advanced-filter-column-pill-color: #355f2d;\n  --ag-advanced-filter-option-pill-color: #5a3168;\n  --ag-advanced-filter-value-pill-color: #374c86;\n  --ag-find-match-color: var(--ag-background-color);\n  --ag-find-active-match-color: var(--ag-background-color);\n  --ag-filter-panel-apply-button-color: var(--ag-foreground-color);\n  --ag-row-loading-skeleton-effect-color: rgba(202, 203, 204, 0.4);\n  --ag-cell-batch-edit-text-color: #f3d0b3;\n  color-scheme: dark;\n}\n\n@media (prefers-color-scheme: dark) {\n  .ag-theme-alpine-auto-dark {\n    --ag-background-color: #181d1f;\n    --ag-foreground-color: #fff;\n    --ag-border-color: #68686e;\n    --ag-secondary-border-color: rgba(88, 86, 82, 0.5);\n    --ag-modal-overlay-background-color: rgba(24, 29, 31, 0.66);\n    --ag-header-background-color: #222628;\n    --ag-tooltip-background-color: #222628;\n    --ag-odd-row-background-color: #222628;\n    --ag-control-panel-background-color: #222628;\n    --ag-subheader-background-color: #000;\n    --ag-input-disabled-background-color: #282c2f;\n    --ag-input-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5), 0 0 4px 3px var(--ag-input-focus-border-color);\n    --ag-input-error-focus-box-shadow: 0 0 2px 0.5px rgba(255, 255, 255, 0.5),\n        0 0 4px 3px color-mix(in srgb, var(--ag-background-color), var(--ag-invalid-color) 0.5%);\n    --ag-card-shadow: 0 1px 20px 1px black;\n    --ag-disabled-foreground-color: rgba(255, 255, 255, 0.5);\n    --ag-chip-background-color: rgba(255, 255, 255, 0.07);\n    --ag-input-disabled-border-color: rgba(104, 104, 110, 0.3);\n    --ag-input-disabled-background-color: rgba(104, 104, 110, 0.07);\n    --ag-advanced-filter-join-pill-color: #7a3a37;\n    --ag-advanced-filter-column-pill-color: #355f2d;\n    --ag-advanced-filter-option-pill-color: #5a3168;\n    --ag-advanced-filter-value-pill-color: #374c86;\n    --ag-find-match-color: var(--ag-background-color);\n    --ag-find-active-match-color: var(--ag-background-color);\n    --ag-filter-panel-apply-button-color: var(--ag-foreground-color);\n    --ag-row-loading-skeleton-effect-color: rgba(202, 203, 204, 0.4);\n    --ag-cell-batch-edit-text-color: #f3d0b3;\n    color-scheme: dark;\n  }\n}\n.ag-theme-alpine .ag-filter-toolpanel-header,\n.ag-theme-alpine .ag-filter-toolpanel-search,\n.ag-theme-alpine .ag-status-bar,\n.ag-theme-alpine .ag-header-row,\n.ag-theme-alpine .ag-row-number-cell,\n.ag-theme-alpine .ag-panel-title-bar-title,\n.ag-theme-alpine .ag-multi-filter-group-title-bar,\n.ag-theme-alpine .ag-filter-card-title,\n.ag-theme-alpine-dark .ag-filter-toolpanel-header,\n.ag-theme-alpine-dark .ag-filter-toolpanel-search,\n.ag-theme-alpine-dark .ag-status-bar,\n.ag-theme-alpine-dark .ag-header-row,\n.ag-theme-alpine-dark .ag-row-number-cell,\n.ag-theme-alpine-dark .ag-panel-title-bar-title,\n.ag-theme-alpine-dark .ag-multi-filter-group-title-bar,\n.ag-theme-alpine-dark .ag-filter-card-title,\n.ag-theme-alpine-auto-dark .ag-filter-toolpanel-header,\n.ag-theme-alpine-auto-dark .ag-filter-toolpanel-search,\n.ag-theme-alpine-auto-dark .ag-status-bar,\n.ag-theme-alpine-auto-dark .ag-header-row,\n.ag-theme-alpine-auto-dark .ag-row-number-cell,\n.ag-theme-alpine-auto-dark .ag-panel-title-bar-title,\n.ag-theme-alpine-auto-dark .ag-multi-filter-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-filter-card-title {\n  font-weight: 700;\n  color: var(--ag-header-foreground-color);\n}\n.ag-theme-alpine .ag-row,\n.ag-theme-alpine-dark .ag-row,\n.ag-theme-alpine-auto-dark .ag-row {\n  font-size: calc(var(--ag-font-size) + 1px);\n}\n.ag-theme-alpine input[class^=ag-]:not([type]),\n.ag-theme-alpine input[class^=ag-][type=text],\n.ag-theme-alpine input[class^=ag-][type=number],\n.ag-theme-alpine input[class^=ag-][type=tel],\n.ag-theme-alpine input[class^=ag-][type=date],\n.ag-theme-alpine input[class^=ag-][type=datetime-local],\n.ag-theme-alpine textarea[class^=ag-],\n.ag-theme-alpine-dark input[class^=ag-]:not([type]),\n.ag-theme-alpine-dark input[class^=ag-][type=text],\n.ag-theme-alpine-dark input[class^=ag-][type=number],\n.ag-theme-alpine-dark input[class^=ag-][type=tel],\n.ag-theme-alpine-dark input[class^=ag-][type=date],\n.ag-theme-alpine-dark input[class^=ag-][type=datetime-local],\n.ag-theme-alpine-dark textarea[class^=ag-],\n.ag-theme-alpine-auto-dark input[class^=ag-]:not([type]),\n.ag-theme-alpine-auto-dark input[class^=ag-][type=text],\n.ag-theme-alpine-auto-dark input[class^=ag-][type=number],\n.ag-theme-alpine-auto-dark input[class^=ag-][type=tel],\n.ag-theme-alpine-auto-dark input[class^=ag-][type=date],\n.ag-theme-alpine-auto-dark input[class^=ag-][type=datetime-local],\n.ag-theme-alpine-auto-dark textarea[class^=ag-] {\n  min-height: calc(var(--ag-grid-size) * 4);\n  border-radius: var(--ag-border-radius);\n}\n.ag-theme-alpine .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine .ag-ltr textarea[class^=ag-], .ag-theme-alpine-dark .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine-dark .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine-dark .ag-ltr textarea[class^=ag-], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-]:not([type]), .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=text], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=number], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=tel], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=date], .ag-theme-alpine-auto-dark .ag-ltr input[class^=ag-][type=datetime-local], .ag-theme-alpine-auto-dark .ag-ltr textarea[class^=ag-] {\n  padding-left: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine .ag-rtl textarea[class^=ag-], .ag-theme-alpine-dark .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine-dark .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine-dark .ag-rtl textarea[class^=ag-], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-]:not([type]), .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=text], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=number], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=tel], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=date], .ag-theme-alpine-auto-dark .ag-rtl input[class^=ag-][type=datetime-local], .ag-theme-alpine-auto-dark .ag-rtl textarea[class^=ag-] {\n  padding-right: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-tab,\n.ag-theme-alpine-dark .ag-tab,\n.ag-theme-alpine-auto-dark .ag-tab {\n  padding: calc(var(--ag-grid-size) * 1.5);\n  transition: color 0.4s;\n  flex: 1 1 auto;\n}\n.ag-theme-alpine .ag-tab-selected,\n.ag-theme-alpine-dark .ag-tab-selected,\n.ag-theme-alpine-auto-dark .ag-tab-selected {\n  color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-menu,\n.ag-theme-alpine-dark .ag-menu,\n.ag-theme-alpine-auto-dark .ag-menu {\n  background-color: var(--ag-control-panel-background-color);\n}\n.ag-theme-alpine .ag-panel-content-wrapper .ag-column-select,\n.ag-theme-alpine-dark .ag-panel-content-wrapper .ag-column-select,\n.ag-theme-alpine-auto-dark .ag-panel-content-wrapper .ag-column-select {\n  background-color: var(--ag-control-panel-background-color);\n}\n.ag-theme-alpine .ag-menu-header,\n.ag-theme-alpine-dark .ag-menu-header,\n.ag-theme-alpine-auto-dark .ag-menu-header {\n  background-color: var(--ag-control-panel-background-color);\n  padding-top: 1px;\n}\n.ag-theme-alpine .ag-tabs-header,\n.ag-theme-alpine-dark .ag-tabs-header,\n.ag-theme-alpine-auto-dark .ag-tabs-header {\n  border-bottom: var(--ag-borders) var(--ag-border-color);\n}\n.ag-theme-alpine .ag-charts-settings-group-title-bar,\n.ag-theme-alpine .ag-charts-data-group-title-bar,\n.ag-theme-alpine .ag-charts-format-top-level-group-title-bar,\n.ag-theme-alpine .ag-charts-advanced-settings-top-level-group-title-bar,\n.ag-theme-alpine-dark .ag-charts-settings-group-title-bar,\n.ag-theme-alpine-dark .ag-charts-data-group-title-bar,\n.ag-theme-alpine-dark .ag-charts-format-top-level-group-title-bar,\n.ag-theme-alpine-dark .ag-charts-advanced-settings-top-level-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-charts-settings-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-charts-data-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-charts-format-top-level-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-charts-advanced-settings-top-level-group-title-bar {\n  padding: var(--ag-grid-size) calc(var(--ag-grid-size) * 2);\n  line-height: calc(var(--ag-icon-size) + var(--ag-grid-size) - 2px);\n}\n.ag-theme-alpine .ag-chart-mini-thumbnail,\n.ag-theme-alpine-dark .ag-chart-mini-thumbnail,\n.ag-theme-alpine-auto-dark .ag-chart-mini-thumbnail {\n  background-color: var(--ag-background-color);\n}\n.ag-theme-alpine .ag-chart-settings-nav-bar,\n.ag-theme-alpine-dark .ag-chart-settings-nav-bar,\n.ag-theme-alpine-auto-dark .ag-chart-settings-nav-bar {\n  border-top: var(--ag-borders-secondary) var(--ag-secondary-border-color);\n}\n.ag-theme-alpine .ag-ltr .ag-group-title-bar-icon, .ag-theme-alpine-dark .ag-ltr .ag-group-title-bar-icon, .ag-theme-alpine-auto-dark .ag-ltr .ag-group-title-bar-icon {\n  margin-right: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-rtl .ag-group-title-bar-icon, .ag-theme-alpine-dark .ag-rtl .ag-group-title-bar-icon, .ag-theme-alpine-auto-dark .ag-rtl .ag-group-title-bar-icon {\n  margin-left: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-charts-format-top-level-group-toolbar,\n.ag-theme-alpine .ag-charts-advanced-settings-top-level-group-toolbar,\n.ag-theme-alpine-dark .ag-charts-format-top-level-group-toolbar,\n.ag-theme-alpine-dark .ag-charts-advanced-settings-top-level-group-toolbar,\n.ag-theme-alpine-auto-dark .ag-charts-format-top-level-group-toolbar,\n.ag-theme-alpine-auto-dark .ag-charts-advanced-settings-top-level-group-toolbar {\n  margin-top: var(--ag-grid-size);\n}\n.ag-theme-alpine .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-dark .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-dark .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-ltr .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-ltr .ag-charts-advanced-settings-top-level-group-toolbar {\n  padding-left: calc(var(--ag-icon-size) * 0.5 + var(--ag-grid-size) * 2);\n}\n\n.ag-theme-alpine .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-dark .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-dark .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-rtl .ag-charts-format-top-level-group-toolbar, .ag-theme-alpine-auto-dark .ag-rtl .ag-charts-advanced-settings-top-level-group-toolbar {\n  padding-right: calc(var(--ag-icon-size) * 0.5 + var(--ag-grid-size) * 2);\n}\n\n.ag-theme-alpine .ag-charts-format-sub-level-group,\n.ag-theme-alpine-dark .ag-charts-format-sub-level-group,\n.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group {\n  border-left: dashed 1px;\n  border-left-color: var(--ag-border-color);\n  padding-left: var(--ag-grid-size);\n  margin-bottom: calc(var(--ag-grid-size) * 2);\n}\n.ag-theme-alpine .ag-charts-format-sub-level-group-title-bar,\n.ag-theme-alpine-dark .ag-charts-format-sub-level-group-title-bar,\n.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-title-bar {\n  padding-top: 0;\n  padding-bottom: 0;\n  background: none;\n  font-weight: 700;\n}\n.ag-theme-alpine .ag-charts-format-sub-level-group-container,\n.ag-theme-alpine-dark .ag-charts-format-sub-level-group-container,\n.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-container {\n  padding-bottom: 0;\n}\n.ag-theme-alpine .ag-charts-format-sub-level-group-item:last-child,\n.ag-theme-alpine-dark .ag-charts-format-sub-level-group-item:last-child,\n.ag-theme-alpine-auto-dark .ag-charts-format-sub-level-group-item:last-child {\n  margin-bottom: 0;\n}\n.ag-theme-alpine.ag-dnd-ghost,\n.ag-theme-alpine-dark.ag-dnd-ghost,\n.ag-theme-alpine-auto-dark.ag-dnd-ghost {\n  font-size: calc(var(--ag-font-size) - 1px);\n  font-weight: 700;\n}\n.ag-theme-alpine .ag-side-buttons,\n.ag-theme-alpine-dark .ag-side-buttons,\n.ag-theme-alpine-auto-dark .ag-side-buttons {\n  width: calc(var(--ag-grid-size) * 5);\n}\n.ag-theme-alpine .ag-standard-button,\n.ag-theme-alpine-dark .ag-standard-button,\n.ag-theme-alpine-auto-dark .ag-standard-button {\n  font-family: inherit;\n  appearance: none;\n  -webkit-appearance: none;\n  border-radius: var(--ag-border-radius);\n  border: 1px solid;\n  border-color: var(--ag-alpine-active-color);\n  color: var(--ag-alpine-active-color);\n  background-color: var(--ag-background-color);\n  font-weight: 600;\n  padding: var(--ag-grid-size) calc(var(--ag-grid-size) * 2);\n}\n.ag-theme-alpine .ag-standard-button:hover,\n.ag-theme-alpine-dark .ag-standard-button:hover,\n.ag-theme-alpine-auto-dark .ag-standard-button:hover {\n  border-color: var(--ag-alpine-active-color);\n  background-color: var(--ag-row-hover-color);\n}\n.ag-theme-alpine .ag-standard-button:active,\n.ag-theme-alpine-dark .ag-standard-button:active,\n.ag-theme-alpine-auto-dark .ag-standard-button:active {\n  border-color: var(--ag-alpine-active-color);\n  background-color: var(--ag-alpine-active-color);\n  color: var(--ag-background-color);\n}\n.ag-theme-alpine .ag-standard-button:disabled,\n.ag-theme-alpine-dark .ag-standard-button:disabled,\n.ag-theme-alpine-auto-dark .ag-standard-button:disabled {\n  color: var(--ag-disabled-foreground-color);\n  background-color: var(--ag-input-disabled-background-color);\n  border-color: var(--ag-input-disabled-border-color);\n}\n.ag-theme-alpine .ag-column-drop-vertical,\n.ag-theme-alpine-dark .ag-column-drop-vertical,\n.ag-theme-alpine-auto-dark .ag-column-drop-vertical {\n  min-height: 75px;\n}\n.ag-theme-alpine .ag-column-drop-vertical-title-bar,\n.ag-theme-alpine-dark .ag-column-drop-vertical-title-bar,\n.ag-theme-alpine-auto-dark .ag-column-drop-vertical-title-bar {\n  padding: calc(var(--ag-grid-size) * 2);\n  padding-bottom: 0px;\n}\n.ag-theme-alpine .ag-column-drop-vertical-empty-message,\n.ag-theme-alpine-dark .ag-column-drop-vertical-empty-message,\n.ag-theme-alpine-auto-dark .ag-column-drop-vertical-empty-message {\n  display: flex;\n  align-items: center;\n  border: dashed 1px;\n  border-color: var(--ag-border-color);\n  margin: calc(var(--ag-grid-size) * 2);\n  padding: calc(var(--ag-grid-size) * 2);\n}\n.ag-theme-alpine .ag-column-drop-empty-message,\n.ag-theme-alpine-dark .ag-column-drop-empty-message,\n.ag-theme-alpine-auto-dark .ag-column-drop-empty-message {\n  color: var(--ag-foreground-color);\n  opacity: 0.75;\n}\n.ag-theme-alpine .ag-pill-select .ag-column-drop,\n.ag-theme-alpine-dark .ag-pill-select .ag-column-drop,\n.ag-theme-alpine-auto-dark .ag-pill-select .ag-column-drop {\n  min-height: unset;\n}\n.ag-theme-alpine .ag-status-bar,\n.ag-theme-alpine-dark .ag-status-bar,\n.ag-theme-alpine-auto-dark .ag-status-bar {\n  font-weight: normal;\n}\n.ag-theme-alpine .ag-status-name-value-value,\n.ag-theme-alpine-dark .ag-status-name-value-value,\n.ag-theme-alpine-auto-dark .ag-status-name-value-value {\n  font-weight: 700;\n}\n.ag-theme-alpine .ag-paging-number,\n.ag-theme-alpine .ag-paging-row-summary-panel-number,\n.ag-theme-alpine-dark .ag-paging-number,\n.ag-theme-alpine-dark .ag-paging-row-summary-panel-number,\n.ag-theme-alpine-auto-dark .ag-paging-number,\n.ag-theme-alpine-auto-dark .ag-paging-row-summary-panel-number {\n  font-weight: 700;\n}\n.ag-theme-alpine .ag-column-drop-cell-button,\n.ag-theme-alpine-dark .ag-column-drop-cell-button,\n.ag-theme-alpine-auto-dark .ag-column-drop-cell-button {\n  opacity: 0.5;\n}\n.ag-theme-alpine .ag-column-drop-cell-button:hover,\n.ag-theme-alpine-dark .ag-column-drop-cell-button:hover,\n.ag-theme-alpine-auto-dark .ag-column-drop-cell-button:hover {\n  opacity: 0.75;\n}\n.ag-theme-alpine .ag-column-select-column-readonly.ag-icon-grip,\n.ag-theme-alpine .ag-column-select-column-readonly .ag-icon-grip,\n.ag-theme-alpine-dark .ag-column-select-column-readonly.ag-icon-grip,\n.ag-theme-alpine-dark .ag-column-select-column-readonly .ag-icon-grip,\n.ag-theme-alpine-auto-dark .ag-column-select-column-readonly.ag-icon-grip,\n.ag-theme-alpine-auto-dark .ag-column-select-column-readonly .ag-icon-grip {\n  opacity: 0.35;\n}\n.ag-theme-alpine .ag-header-cell-menu-button:hover,\n.ag-theme-alpine .ag-header-cell-filter-button:hover,\n.ag-theme-alpine .ag-side-button-button:hover,\n.ag-theme-alpine .ag-tab:hover,\n.ag-theme-alpine .ag-panel-title-bar-button:hover,\n.ag-theme-alpine .ag-header-expand-icon:hover,\n.ag-theme-alpine .ag-column-group-icons:hover,\n.ag-theme-alpine .ag-set-filter-group-icons:hover,\n.ag-theme-alpine .ag-group-expanded .ag-icon:hover,\n.ag-theme-alpine .ag-group-contracted .ag-icon:hover,\n.ag-theme-alpine .ag-chart-settings-prev:hover,\n.ag-theme-alpine .ag-chart-settings-next:hover,\n.ag-theme-alpine .ag-group-title-bar-icon:hover,\n.ag-theme-alpine .ag-column-select-header-icon:hover,\n.ag-theme-alpine .ag-floating-filter-button-button:hover,\n.ag-theme-alpine .ag-filter-toolpanel-expand:hover,\n.ag-theme-alpine .ag-chart-menu-icon:hover,\n.ag-theme-alpine-dark .ag-header-cell-menu-button:hover,\n.ag-theme-alpine-dark .ag-header-cell-filter-button:hover,\n.ag-theme-alpine-dark .ag-side-button-button:hover,\n.ag-theme-alpine-dark .ag-tab:hover,\n.ag-theme-alpine-dark .ag-panel-title-bar-button:hover,\n.ag-theme-alpine-dark .ag-header-expand-icon:hover,\n.ag-theme-alpine-dark .ag-column-group-icons:hover,\n.ag-theme-alpine-dark .ag-set-filter-group-icons:hover,\n.ag-theme-alpine-dark .ag-group-expanded .ag-icon:hover,\n.ag-theme-alpine-dark .ag-group-contracted .ag-icon:hover,\n.ag-theme-alpine-dark .ag-chart-settings-prev:hover,\n.ag-theme-alpine-dark .ag-chart-settings-next:hover,\n.ag-theme-alpine-dark .ag-group-title-bar-icon:hover,\n.ag-theme-alpine-dark .ag-column-select-header-icon:hover,\n.ag-theme-alpine-dark .ag-floating-filter-button-button:hover,\n.ag-theme-alpine-dark .ag-filter-toolpanel-expand:hover,\n.ag-theme-alpine-dark .ag-chart-menu-icon:hover,\n.ag-theme-alpine-auto-dark .ag-header-cell-menu-button:hover,\n.ag-theme-alpine-auto-dark .ag-header-cell-filter-button:hover,\n.ag-theme-alpine-auto-dark .ag-side-button-button:hover,\n.ag-theme-alpine-auto-dark .ag-tab:hover,\n.ag-theme-alpine-auto-dark .ag-panel-title-bar-button:hover,\n.ag-theme-alpine-auto-dark .ag-header-expand-icon:hover,\n.ag-theme-alpine-auto-dark .ag-column-group-icons:hover,\n.ag-theme-alpine-auto-dark .ag-set-filter-group-icons:hover,\n.ag-theme-alpine-auto-dark .ag-group-expanded .ag-icon:hover,\n.ag-theme-alpine-auto-dark .ag-group-contracted .ag-icon:hover,\n.ag-theme-alpine-auto-dark .ag-chart-settings-prev:hover,\n.ag-theme-alpine-auto-dark .ag-chart-settings-next:hover,\n.ag-theme-alpine-auto-dark .ag-group-title-bar-icon:hover,\n.ag-theme-alpine-auto-dark .ag-column-select-header-icon:hover,\n.ag-theme-alpine-auto-dark .ag-floating-filter-button-button:hover,\n.ag-theme-alpine-auto-dark .ag-filter-toolpanel-expand:hover,\n.ag-theme-alpine-auto-dark .ag-chart-menu-icon:hover {\n  color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-header-cell-menu-button:hover .ag-icon,\n.ag-theme-alpine .ag-header-cell-filter-button:hover .ag-icon,\n.ag-theme-alpine .ag-side-button-button:hover .ag-icon,\n.ag-theme-alpine .ag-panel-title-bar-button:hover .ag-icon,\n.ag-theme-alpine .ag-floating-filter-button-button:hover .ag-icon,\n.ag-theme-alpine-dark .ag-header-cell-menu-button:hover .ag-icon,\n.ag-theme-alpine-dark .ag-header-cell-filter-button:hover .ag-icon,\n.ag-theme-alpine-dark .ag-side-button-button:hover .ag-icon,\n.ag-theme-alpine-dark .ag-panel-title-bar-button:hover .ag-icon,\n.ag-theme-alpine-dark .ag-floating-filter-button-button:hover .ag-icon,\n.ag-theme-alpine-auto-dark .ag-header-cell-menu-button:hover .ag-icon,\n.ag-theme-alpine-auto-dark .ag-header-cell-filter-button:hover .ag-icon,\n.ag-theme-alpine-auto-dark .ag-side-button-button:hover .ag-icon,\n.ag-theme-alpine-auto-dark .ag-panel-title-bar-button:hover .ag-icon,\n.ag-theme-alpine-auto-dark .ag-floating-filter-button-button:hover .ag-icon {\n  color: inherit;\n}\n.ag-theme-alpine .ag-filter-active .ag-icon-filter,\n.ag-theme-alpine-dark .ag-filter-active .ag-icon-filter,\n.ag-theme-alpine-auto-dark .ag-filter-active .ag-icon-filter {\n  color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-chart-settings-card-item.ag-not-selected:hover,\n.ag-theme-alpine-dark .ag-chart-settings-card-item.ag-not-selected:hover,\n.ag-theme-alpine-auto-dark .ag-chart-settings-card-item.ag-not-selected:hover {\n  opacity: 0.35;\n}\n.ag-theme-alpine .ag-ltr .ag-panel-title-bar-button, .ag-theme-alpine-dark .ag-ltr .ag-panel-title-bar-button, .ag-theme-alpine-auto-dark .ag-ltr .ag-panel-title-bar-button {\n  margin-left: calc(var(--ag-grid-size) * 2);\n  margin-right: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-rtl .ag-panel-title-bar-button, .ag-theme-alpine-dark .ag-rtl .ag-panel-title-bar-button, .ag-theme-alpine-auto-dark .ag-rtl .ag-panel-title-bar-button {\n  margin-right: calc(var(--ag-grid-size) * 2);\n  margin-left: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-ltr .ag-filter-toolpanel-group-container, .ag-theme-alpine-dark .ag-ltr .ag-filter-toolpanel-group-container, .ag-theme-alpine-auto-dark .ag-ltr .ag-filter-toolpanel-group-container {\n  padding-left: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-rtl .ag-filter-toolpanel-group-container, .ag-theme-alpine-dark .ag-rtl .ag-filter-toolpanel-group-container, .ag-theme-alpine-auto-dark .ag-rtl .ag-filter-toolpanel-group-container {\n  padding-right: var(--ag-grid-size);\n}\n\n.ag-theme-alpine .ag-filter-toolpanel-instance-filter,\n.ag-theme-alpine-dark .ag-filter-toolpanel-instance-filter,\n.ag-theme-alpine-auto-dark .ag-filter-toolpanel-instance-filter {\n  border: none;\n  background-color: var(--ag-control-panel-background-color);\n}\n.ag-theme-alpine .ag-ltr .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-dark .ag-ltr .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-auto-dark .ag-ltr .ag-filter-toolpanel-instance-filter {\n  border-left: dashed 1px;\n  border-left-color: var(--ag-border-color);\n  margin-left: calc(var(--ag-icon-size) * 0.5);\n}\n\n.ag-theme-alpine .ag-rtl .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-dark .ag-rtl .ag-filter-toolpanel-instance-filter, .ag-theme-alpine-auto-dark .ag-rtl .ag-filter-toolpanel-instance-filter {\n  border-right: dashed 1px;\n  border-right-color: var(--ag-border-color);\n  margin-right: calc(var(--ag-icon-size) * 0.5);\n}\n\n.ag-theme-alpine .ag-set-filter-list,\n.ag-theme-alpine-dark .ag-set-filter-list,\n.ag-theme-alpine-auto-dark .ag-set-filter-list {\n  padding-top: calc(var(--ag-grid-size) * 0.5);\n  padding-bottom: calc(var(--ag-grid-size) * 0.5);\n}\n.ag-theme-alpine .ag-filter-add-button .ag-icon,\n.ag-theme-alpine-dark .ag-filter-add-button .ag-icon,\n.ag-theme-alpine-auto-dark .ag-filter-add-button .ag-icon {\n  color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-layout-auto-height .ag-center-cols-viewport,\n.ag-theme-alpine .ag-layout-auto-height .ag-center-cols-container,\n.ag-theme-alpine .ag-layout-print .ag-center-cols-viewport,\n.ag-theme-alpine .ag-layout-print .ag-center-cols-container,\n.ag-theme-alpine-dark .ag-layout-auto-height .ag-center-cols-viewport,\n.ag-theme-alpine-dark .ag-layout-auto-height .ag-center-cols-container,\n.ag-theme-alpine-dark .ag-layout-print .ag-center-cols-viewport,\n.ag-theme-alpine-dark .ag-layout-print .ag-center-cols-container,\n.ag-theme-alpine-auto-dark .ag-layout-auto-height .ag-center-cols-viewport,\n.ag-theme-alpine-auto-dark .ag-layout-auto-height .ag-center-cols-container,\n.ag-theme-alpine-auto-dark .ag-layout-print .ag-center-cols-viewport,\n.ag-theme-alpine-auto-dark .ag-layout-print .ag-center-cols-container {\n  min-height: 150px;\n}\n.ag-theme-alpine .ag-date-time-list-page-entry-is-current,\n.ag-theme-alpine-dark .ag-date-time-list-page-entry-is-current,\n.ag-theme-alpine-auto-dark .ag-date-time-list-page-entry-is-current {\n  background-color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-advanced-filter-builder-button,\n.ag-theme-alpine-dark .ag-advanced-filter-builder-button,\n.ag-theme-alpine-auto-dark .ag-advanced-filter-builder-button {\n  padding: var(--ag-grid-size);\n  font-weight: 600;\n}\n.ag-theme-alpine .ag-list-item-hovered::after,\n.ag-theme-alpine-dark .ag-list-item-hovered::after,\n.ag-theme-alpine-auto-dark .ag-list-item-hovered::after {\n  background-color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-pill .ag-pill-button:hover,\n.ag-theme-alpine-dark .ag-pill .ag-pill-button:hover,\n.ag-theme-alpine-auto-dark .ag-pill .ag-pill-button:hover {\n  color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-header-highlight-before::after,\n.ag-theme-alpine .ag-header-highlight-after::after,\n.ag-theme-alpine-dark .ag-header-highlight-before::after,\n.ag-theme-alpine-dark .ag-header-highlight-after::after,\n.ag-theme-alpine-auto-dark .ag-header-highlight-before::after,\n.ag-theme-alpine-auto-dark .ag-header-highlight-after::after {\n  background-color: var(--ag-alpine-active-color);\n}\n.ag-theme-alpine .ag-advanced-filter-builder-item-button-disabled .ag-icon,\n.ag-theme-alpine .ag-disabled .ag-icon,\n.ag-theme-alpine .ag-column-select-column-group-readonly .ag-icon,\n.ag-theme-alpine [disabled] .ag-icon,\n.ag-theme-alpine-dark .ag-advanced-filter-builder-item-button-disabled .ag-icon,\n.ag-theme-alpine-dark .ag-disabled .ag-icon,\n.ag-theme-alpine-dark .ag-column-select-column-group-readonly .ag-icon,\n.ag-theme-alpine-dark [disabled] .ag-icon,\n.ag-theme-alpine-auto-dark .ag-advanced-filter-builder-item-button-disabled .ag-icon,\n.ag-theme-alpine-auto-dark .ag-disabled .ag-icon,\n.ag-theme-alpine-auto-dark .ag-column-select-column-group-readonly .ag-icon,\n.ag-theme-alpine-auto-dark [disabled] .ag-icon {\n  color: var(--ag-disabled-foreground-color);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 43693:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPropertyKey = __webpack_require__(77736);
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}
module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 46479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85072);
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97825);
/* harmony import */ var _style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77659);
/* harmony import */ var _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55056);
/* harmony import */ var _style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(10540);
/* harmony import */ var _style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41113);
/* harmony import */ var _style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_grid_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(31856);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_grid_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_grid_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A && _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_grid_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A.locals ? _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_grid_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A.locals : undefined);


/***/ }),

/***/ 64010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85072);
/* harmony import */ var _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97825);
/* harmony import */ var _style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77659);
/* harmony import */ var _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55056);
/* harmony import */ var _style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(10540);
/* harmony import */ var _style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41113);
/* harmony import */ var _style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_theme_alpine_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32949);

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_theme_alpine_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_theme_alpine_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A && _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_theme_alpine_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A.locals ? _css_loader_dist_cjs_js_postcss_loader_dist_cjs_js_ag_theme_alpine_css__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A.locals : undefined);


/***/ }),

/***/ 66875:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W6: () => (/* binding */ AgGridReact)
/* harmony export */ });
/* unused harmony exports CustomComponentContext, getInstance, useGridCellEditor, useGridDate, useGridFilter, useGridFilterDisplay, useGridFloatingFilter, useGridMenuItem, warnReactiveCustomComponents */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96540);
/* harmony import */ var ag_grid_community__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(80346);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(40961);
// packages/ag-grid-react/src/agGridReact.tsx


// packages/ag-grid-react/src/reactUi/agGridReactUi.tsx



// packages/ag-grid-react/src/reactUi/cellRenderer/groupCellRenderer.tsx



// packages/ag-grid-react/src/reactUi/beansContext.tsx

var BeansContext = react__WEBPACK_IMPORTED_MODULE_0__.createContext({});
var RenderModeContext = react__WEBPACK_IMPORTED_MODULE_0__.createContext("default");

// packages/ag-grid-react/src/reactUi/jsComp.tsx
var showJsComp = (compDetails, context, eParent, ref) => {
  const doNothing = !compDetails || compDetails.componentFromFramework || context.isDestroyed();
  if (doNothing) {
    return;
  }
  const promise = compDetails.newAgStackInstance();
  let comp;
  let compGui;
  let destroyed = false;
  promise.then((c) => {
    if (destroyed) {
      context.destroyBean(c);
      return;
    }
    comp = c;
    compGui = comp.getGui();
    eParent.appendChild(compGui);
    setRef(ref, comp);
  });
  return () => {
    destroyed = true;
    if (!comp) {
      return;
    }
    compGui?.remove();
    context.destroyBean(comp);
    if (ref) {
      setRef(ref, void 0);
    }
  };
};
var setRef = (ref, value) => {
  if (!ref) {
    return;
  }
  if (ref instanceof Function) {
    const refCallback = ref;
    refCallback(value);
  } else {
    const refObj = ref;
    refObj.current = value;
  }
};

// packages/ag-grid-react/src/reactUi/utils.tsx


var classesList = (...list) => {
  const filtered = list.filter((s) => s != null && s !== "");
  return filtered.join(" ");
};
var CssClasses = class _CssClasses {
  constructor(...initialClasses) {
    this.classesMap = {};
    for (const className of initialClasses) {
      this.classesMap[className] = true;
    }
  }
  setClass(className, on) {
    const nothingHasChanged = !!this.classesMap[className] == on;
    if (nothingHasChanged) {
      return this;
    }
    const res = new _CssClasses();
    res.classesMap = { ...this.classesMap };
    res.classesMap[className] = on;
    return res;
  }
  toString() {
    const res = Object.keys(this.classesMap).filter((key) => this.classesMap[key]).join(" ");
    return res;
  }
};
var isComponentStateless = (Component2) => {
  const hasSymbol = () => typeof Symbol === "function" && Symbol.for;
  const getMemoType = () => hasSymbol() ? Symbol.for("react.memo") : 60115;
  return typeof Component2 === "function" && !(Component2.prototype && Component2.prototype.isReactComponent) || typeof Component2 === "object" && Component2.$$typeof === getMemoType();
};
var reactVersion = react__WEBPACK_IMPORTED_MODULE_0__.version?.split(".")[0];
var isReactVersion17Minus = reactVersion === "16" || reactVersion === "17";
function isReact19() {
  return reactVersion === "19";
}
var disableFlushSync = false;
function runWithoutFlushSync(func) {
  if (!disableFlushSync) {
    setTimeout(() => disableFlushSync = false, 0);
  }
  disableFlushSync = true;
  return func();
}
var agFlushSync = (useFlushSync, fn) => {
  if (!isReactVersion17Minus && useFlushSync && !disableFlushSync) {
    react_dom__WEBPACK_IMPORTED_MODULE_2__.flushSync(fn);
  } else {
    fn();
  }
};
var agStartTransition = (fn) => {
  if (!isReactVersion17Minus) {
    react__WEBPACK_IMPORTED_MODULE_0__.startTransition(fn);
  } else {
    fn();
  }
};
function agUseSyncExternalStore(subscribe, getSnapshot, defaultSnapshot) {
  if (react__WEBPACK_IMPORTED_MODULE_0__.useSyncExternalStore) {
    return react__WEBPACK_IMPORTED_MODULE_0__.useSyncExternalStore(subscribe, getSnapshot);
  } else {
    return defaultSnapshot;
  }
}
function getNextValueIfDifferent(prev, next, maintainOrder) {
  if (next == null || prev == null) {
    return next;
  }
  if (prev === next || next.length === 0 && prev.length === 0) {
    return prev;
  }
  if (maintainOrder || prev.length === 0 && next.length > 0 || prev.length > 0 && next.length === 0) {
    return next;
  }
  const oldValues = [];
  const newValues = [];
  const prevMap = /* @__PURE__ */ new Map();
  const nextMap = /* @__PURE__ */ new Map();
  for (let i = 0; i < next.length; i++) {
    const c = next[i];
    nextMap.set(c.instanceId, c);
  }
  for (let i = 0; i < prev.length; i++) {
    const c = prev[i];
    prevMap.set(c.instanceId, c);
    if (nextMap.has(c.instanceId)) {
      oldValues.push(c);
    }
  }
  for (let i = 0; i < next.length; i++) {
    const c = next[i];
    const instanceId = c.instanceId;
    if (!prevMap.has(instanceId)) {
      newValues.push(c);
    }
  }
  if (oldValues.length === prev.length && newValues.length === 0) {
    return prev;
  }
  if (oldValues.length === 0 && newValues.length === next.length) {
    return next;
  }
  if (oldValues.length === 0) {
    return newValues;
  }
  if (newValues.length === 0) {
    return oldValues;
  }
  return [...oldValues, ...newValues];
}

// packages/ag-grid-react/src/reactUi/cellRenderer/groupCellRenderer.tsx
var GroupCellRenderer = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((props, ref) => {
  const { registry, context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eValueRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eCheckboxRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eExpandedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eContractedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const ctrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const [innerCompDetails, setInnerCompDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [childCount, setChildCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [cssClasses, setCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [expandedCssClasses, setExpandedCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses("ag-hidden"));
  const [contractedCssClasses, setContractedCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses("ag-hidden"));
  const [checkboxCssClasses, setCheckboxCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses("ag-invisible"));
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(ref, () => {
    return {
      // force new instance when grid tries to refresh
      refresh() {
        return false;
      }
    };
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    return showJsComp(innerCompDetails, context, eValueRef.current);
  }, [innerCompDetails]);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || context.isDestroyed()) {
      ctrlRef.current = context.destroyBean(ctrlRef.current);
      return;
    }
    const compProxy = {
      setInnerRenderer: (details, valueToDisplay) => {
        setInnerCompDetails(details);
        setValue(valueToDisplay);
      },
      setChildCount: (count) => setChildCount(count),
      toggleCss: (name, on) => setCssClasses((prev) => prev.setClass(name, on)),
      setContractedDisplayed: (displayed) => setContractedCssClasses((prev) => prev.setClass("ag-hidden", !displayed)),
      setExpandedDisplayed: (displayed) => setExpandedCssClasses((prev) => prev.setClass("ag-hidden", !displayed)),
      setCheckboxVisible: (visible) => setCheckboxCssClasses((prev) => prev.setClass("ag-invisible", !visible)),
      setCheckboxSpacing: (add) => setCheckboxCssClasses((prev) => prev.setClass("ag-group-checkbox-spacing", add))
    };
    const groupCellRendererCtrl = registry.createDynamicBean("groupCellRendererCtrl", true);
    if (groupCellRendererCtrl) {
      ctrlRef.current = context.createBean(groupCellRendererCtrl);
      ctrlRef.current.init(
        compProxy,
        eRef,
        eCheckboxRef.current,
        eExpandedRef.current,
        eContractedRef.current,
        GroupCellRenderer,
        props
      );
    }
  }, []);
  const className = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => `ag-cell-wrapper ${cssClasses.toString()}`, [cssClasses]);
  const expandedClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => `ag-group-expanded ${expandedCssClasses.toString()}`, [expandedCssClasses]);
  const contractedClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => `ag-group-contracted ${contractedCssClasses.toString()}`,
    [contractedCssClasses]
  );
  const checkboxClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => `ag-group-checkbox ${checkboxCssClasses.toString()}`, [checkboxCssClasses]);
  const useFwRenderer = innerCompDetails?.componentFromFramework;
  const FwRenderer = useFwRenderer ? innerCompDetails.componentClass : void 0;
  const useValue = innerCompDetails == null && value != null;
  const escapedValue = (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._toString */ .SjP)(value);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    "span",
    {
      className,
      ref: setRef2,
      ...!props.colDef ? { role: ctrlRef.current?.getCellAriaRole() } : {}
    },
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: expandedClassName, ref: eExpandedRef }),
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: contractedClassName, ref: eContractedRef }),
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: checkboxClassName, ref: eCheckboxRef }),
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "ag-group-value", ref: eValueRef }, useValue ? escapedValue : useFwRenderer ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(FwRenderer, { ...innerCompDetails.params }) : null),
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "ag-group-child-count" }, childCount)
  );
});
var groupCellRenderer_default = GroupCellRenderer;

// packages/ag-grid-react/src/shared/customComp/customComponentWrapper.ts


// packages/ag-grid-react/src/reactUi/customComp/customWrapperComp.tsx


// packages/ag-grid-react/src/shared/customComp/customContext.ts

var CustomContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
  setMethods: () => {
  }
});

// packages/ag-grid-react/src/reactUi/customComp/customWrapperComp.tsx
var CustomWrapperComp = (params) => {
  const { initialProps, addUpdateCallback, CustomComponentClass, setMethods } = params;
  const [{ key, ...props }, setProps] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialProps);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    addUpdateCallback((newProps) => setProps(newProps));
  }, []);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CustomContext.Provider, { value: { setMethods } }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CustomComponentClass, { key, ...props }));
};
var customWrapperComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(CustomWrapperComp);

// packages/ag-grid-react/src/shared/reactComponent.ts




// packages/ag-grid-react/src/shared/keyGenerator.ts
var counter = 0;
function generateNewKey() {
  return `agPortalKey_${++counter}`;
}

// packages/ag-grid-react/src/shared/reactComponent.ts
var ReactComponent = class {
  constructor(reactComponent, portalManager, componentType, suppressFallbackMethods) {
    this.portal = null;
    this.oldPortal = null;
    this.reactComponent = reactComponent;
    this.portalManager = portalManager;
    this.componentType = componentType;
    this.suppressFallbackMethods = !!suppressFallbackMethods;
    this.statelessComponent = this.isStateless(this.reactComponent);
    this.key = generateNewKey();
    this.portalKey = generateNewKey();
    this.instanceCreated = this.isStatelessComponent() ? ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$.resolve(false) : new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveInstanceCreated = resolve;
    });
  }
  getGui() {
    return this.eParentElement;
  }
  /** `getGui()` returns the parent element. This returns the actual root element. */
  getRootElement() {
    const firstChild = this.eParentElement.firstChild;
    return firstChild;
  }
  destroy() {
    if (this.componentInstance && typeof this.componentInstance.destroy == "function") {
      this.componentInstance.destroy();
    }
    const portal = this.portal;
    if (portal) {
      this.portalManager.destroyPortal(portal);
    }
  }
  createParentElement(params) {
    const componentWrappingElement = this.portalManager.getComponentWrappingElement();
    const eParentElement = document.createElement(componentWrappingElement || "div");
    eParentElement.classList.add("ag-react-container");
    params.reactContainer = eParentElement;
    return eParentElement;
  }
  statelessComponentRendered() {
    return this.eParentElement.childElementCount > 0 || this.eParentElement.childNodes.length > 0;
  }
  getFrameworkComponentInstance() {
    return this.componentInstance;
  }
  isStatelessComponent() {
    return this.statelessComponent;
  }
  getReactComponentName() {
    return this.reactComponent.name;
  }
  getMemoType() {
    return this.hasSymbol() ? Symbol.for("react.memo") : 60115;
  }
  hasSymbol() {
    return typeof Symbol === "function" && Symbol.for;
  }
  isStateless(Component2) {
    return typeof Component2 === "function" && !(Component2.prototype && Component2.prototype.isReactComponent) || typeof Component2 === "object" && Component2.$$typeof === this.getMemoType();
  }
  hasMethod(name) {
    const frameworkComponentInstance = this.getFrameworkComponentInstance();
    return !!frameworkComponentInstance && frameworkComponentInstance[name] != null || this.fallbackMethodAvailable(name);
  }
  callMethod(name, args) {
    const frameworkComponentInstance = this.getFrameworkComponentInstance();
    if (this.isStatelessComponent()) {
      return this.fallbackMethod(name, !!args && args[0] ? args[0] : {});
    } else if (!frameworkComponentInstance) {
      setTimeout(() => this.callMethod(name, args));
      return;
    }
    const method = frameworkComponentInstance[name];
    if (method) {
      return method.apply(frameworkComponentInstance, args);
    }
    if (this.fallbackMethodAvailable(name)) {
      return this.fallbackMethod(name, !!args && args[0] ? args[0] : {});
    }
  }
  addMethod(name, callback) {
    this[name] = callback;
  }
  init(params) {
    this.eParentElement = this.createParentElement(params);
    this.createOrUpdatePortal(params);
    return new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => this.createReactComponent(resolve));
  }
  createOrUpdatePortal(params) {
    if (!this.isStatelessComponent()) {
      this.ref = (element) => {
        this.componentInstance = element;
        this.resolveInstanceCreated?.(true);
        this.resolveInstanceCreated = void 0;
      };
      params.ref = this.ref;
    }
    this.reactElement = this.createElement(this.reactComponent, { ...params, key: this.key });
    this.portal = (0,react_dom__WEBPACK_IMPORTED_MODULE_2__.createPortal)(
      this.reactElement,
      this.eParentElement,
      this.portalKey
      // fixed deltaRowModeRefreshCompRenderer
    );
  }
  createElement(reactComponent, props) {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(reactComponent, props);
  }
  createReactComponent(resolve) {
    this.portalManager.mountReactPortal(this.portal, this, resolve);
  }
  rendered() {
    return this.isStatelessComponent() && this.statelessComponentRendered() || !!(!this.isStatelessComponent() && this.getFrameworkComponentInstance());
  }
  /*
   * fallback methods - these will be invoked if a corresponding instance method is not present
   * for example if refresh is called and is not available on the component instance, then refreshComponent on this
   * class will be invoked instead
   *
   * Currently only refresh is supported
   */
  refreshComponent(args) {
    this.oldPortal = this.portal;
    this.createOrUpdatePortal(args);
    this.portalManager.updateReactPortal(this.oldPortal, this.portal);
  }
  fallbackMethod(name, params) {
    const method = this[`${name}Component`];
    if (!this.suppressFallbackMethods && !!method) {
      return method.bind(this)(params);
    }
  }
  fallbackMethodAvailable(name) {
    if (this.suppressFallbackMethods) {
      return false;
    }
    const method = this[`${name}Component`];
    return !!method;
  }
};

// packages/ag-grid-react/src/shared/customComp/customComponentWrapper.ts
function addOptionalMethods(optionalMethodNames, providedMethods, component) {
  for (const methodName of optionalMethodNames) {
    const providedMethod = providedMethods[methodName];
    if (providedMethod) {
      component[methodName] = providedMethod;
    }
  }
}
var CustomComponentWrapper = class extends ReactComponent {
  constructor() {
    super(...arguments);
    this.awaitUpdateCallback = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveUpdateCallback = resolve;
    });
    this.wrapperComponent = customWrapperComp_default;
  }
  init(params) {
    this.sourceParams = params;
    return super.init(this.getProps());
  }
  addMethod() {
  }
  getInstance() {
    return this.instanceCreated.then(() => this.componentInstance);
  }
  getFrameworkComponentInstance() {
    return this;
  }
  createElement(reactComponent, props) {
    return super.createElement(this.wrapperComponent, {
      initialProps: props,
      CustomComponentClass: reactComponent,
      setMethods: (methods) => this.setMethods(methods),
      addUpdateCallback: (callback) => {
        this.updateCallback = () => {
          callback(this.getProps());
          return new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
            setTimeout(() => {
              resolve();
            });
          });
        };
        this.resolveUpdateCallback();
      }
    });
  }
  setMethods(methods) {
    this.providedMethods = methods;
    addOptionalMethods(this.getOptionalMethods(), this.providedMethods, this);
  }
  getOptionalMethods() {
    return [];
  }
  getProps() {
    return {
      ...this.sourceParams,
      key: this.key,
      ref: this.ref
    };
  }
  refreshProps() {
    if (this.updateCallback) {
      return this.updateCallback();
    }
    return new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$(
      (resolve) => this.awaitUpdateCallback.then(() => {
        this.updateCallback().then(() => resolve());
      })
    );
  }
};

// packages/ag-grid-react/src/shared/customComp/cellRendererComponentWrapper.ts
var CellRendererComponentWrapper = class extends CustomComponentWrapper {
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
    return true;
  }
};

// packages/ag-grid-react/src/shared/customComp/dateComponentWrapper.ts
var DateComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.date = null;
    this.onDateChange = (date) => this.updateDate(date);
  }
  getDate() {
    return this.date;
  }
  setDate(date) {
    this.date = date;
    this.refreshProps();
  }
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
  }
  getOptionalMethods() {
    return ["afterGuiAttached", "setInputPlaceholder", "setInputAriaLabel", "setDisabled"];
  }
  updateDate(date) {
    this.setDate(date);
    this.sourceParams.onDateChanged();
  }
  getProps() {
    const props = super.getProps();
    props.date = this.date;
    props.onDateChange = this.onDateChange;
    delete props.onDateChanged;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/dragAndDropImageComponentWrapper.ts
var DragAndDropImageComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.label = "";
    this.icon = null;
    this.shake = false;
  }
  setIcon(iconName, shake) {
    this.icon = iconName;
    this.shake = shake;
    this.refreshProps();
  }
  setLabel(label) {
    this.label = label;
    this.refreshProps();
  }
  getProps() {
    const props = super.getProps();
    const { label, icon, shake } = this;
    props.label = label;
    props.icon = icon;
    props.shake = shake;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/filterComponentWrapper.ts

var FilterComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.model = null;
    this.onModelChange = (model) => this.updateModel(model);
    this.onUiChange = () => this.sourceParams.filterModifiedCallback();
    this.expectingNewMethods = true;
    this.hasBeenActive = false;
    this.awaitSetMethodsCallback = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveSetMethodsCallback = resolve;
    });
  }
  isFilterActive() {
    return this.model != null;
  }
  doesFilterPass(params) {
    return this.providedMethods.doesFilterPass(params);
  }
  getModel() {
    return this.model;
  }
  setModel(model) {
    this.expectingNewMethods = true;
    this.model = model;
    this.hasBeenActive || (this.hasBeenActive = this.isFilterActive());
    return this.refreshProps();
  }
  refresh(newParams) {
    this.sourceParams = newParams;
    this.refreshProps();
    return true;
  }
  afterGuiAttached(params) {
    const providedMethods = this.providedMethods;
    if (!providedMethods) {
      this.awaitSetMethodsCallback.then(() => this.providedMethods?.afterGuiAttached?.(params));
    } else {
      providedMethods.afterGuiAttached?.(params);
    }
  }
  getOptionalMethods() {
    return ["afterGuiDetached", "onNewRowsLoaded", "getModelAsString", "onAnyFilterChanged"];
  }
  setMethods(methods) {
    if (this.expectingNewMethods === false && this.hasBeenActive && this.providedMethods?.doesFilterPass !== methods?.doesFilterPass) {
      setTimeout(() => {
        this.sourceParams.filterChangedCallback();
      });
    }
    this.expectingNewMethods = false;
    super.setMethods(methods);
    this.resolveSetMethodsCallback();
    this.resolveFilterPassCallback?.();
    this.resolveFilterPassCallback = void 0;
  }
  updateModel(model) {
    this.resolveFilterPassCallback?.();
    const awaitFilterPassCallback = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveFilterPassCallback = resolve;
    });
    this.setModel(model).then(() => {
      awaitFilterPassCallback.then(() => {
        this.sourceParams.filterChangedCallback();
      });
    });
  }
  getProps() {
    const props = super.getProps();
    props.model = this.model;
    props.onModelChange = this.onModelChange;
    props.onUiChange = this.onUiChange;
    delete props.filterChangedCallback;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/filterDisplayComponentWrapper.ts

var FilterDisplayComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.awaitSetMethodsCallback = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveSetMethodsCallback = resolve;
    });
  }
  refresh(newParams) {
    this.sourceParams = newParams;
    this.refreshProps();
    return true;
  }
  afterGuiAttached(params) {
    const providedMethods = this.providedMethods;
    if (!providedMethods) {
      this.awaitSetMethodsCallback.then(() => this.providedMethods?.afterGuiAttached?.(params));
    } else {
      providedMethods.afterGuiAttached?.(params);
    }
  }
  getOptionalMethods() {
    return ["afterGuiDetached", "onNewRowsLoaded", "onAnyFilterChanged"];
  }
  setMethods(methods) {
    super.setMethods(methods);
    this.resolveSetMethodsCallback();
  }
};

// packages/ag-grid-react/src/shared/customComp/floatingFilterComponentProxy.ts

function updateFloatingFilterParent(params, model) {
  params.parentFilterInstance((instance) => {
    (instance.setModel(model) || ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$.resolve()).then(() => {
      params.filterParams.filterChangedCallback();
    });
  });
}
var FloatingFilterComponentProxy = class {
  constructor(floatingFilterParams, refreshProps) {
    this.floatingFilterParams = floatingFilterParams;
    this.refreshProps = refreshProps;
    this.model = null;
    this.onModelChange = (model) => this.updateModel(model);
  }
  getProps() {
    return {
      ...this.floatingFilterParams,
      model: this.model,
      onModelChange: this.onModelChange
    };
  }
  onParentModelChanged(parentModel) {
    this.model = parentModel;
    this.refreshProps();
  }
  refresh(params) {
    this.floatingFilterParams = params;
    this.refreshProps();
  }
  setMethods(methods) {
    addOptionalMethods(this.getOptionalMethods(), methods, this);
  }
  getOptionalMethods() {
    return ["afterGuiAttached"];
  }
  updateModel(model) {
    this.model = model;
    this.refreshProps();
    updateFloatingFilterParent(this.floatingFilterParams, model);
  }
};

// packages/ag-grid-react/src/shared/customComp/floatingFilterComponentWrapper.ts
var FloatingFilterComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.model = null;
    this.onModelChange = (model) => this.updateModel(model);
  }
  onParentModelChanged(parentModel) {
    this.model = parentModel;
    this.refreshProps();
  }
  refresh(newParams) {
    this.sourceParams = newParams;
    this.refreshProps();
  }
  getOptionalMethods() {
    return ["afterGuiAttached"];
  }
  updateModel(model) {
    this.model = model;
    this.refreshProps();
    updateFloatingFilterParent(this.sourceParams, model);
  }
  getProps() {
    const props = super.getProps();
    props.model = this.model;
    props.onModelChange = this.onModelChange;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/floatingFilterDisplayComponentWrapper.ts
var FloatingFilterDisplayComponentWrapper = class extends CustomComponentWrapper {
  refresh(newParams) {
    this.sourceParams = newParams;
    this.refreshProps();
  }
  getOptionalMethods() {
    return ["afterGuiAttached"];
  }
};

// packages/ag-grid-react/src/shared/customComp/innerHeaderComponentWrapper.ts
var InnerHeaderComponentWrapper = class extends CustomComponentWrapper {
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
    return true;
  }
};

// packages/ag-grid-react/src/shared/customComp/loadingOverlayComponentWrapper.ts
var LoadingOverlayComponentWrapper = class extends CustomComponentWrapper {
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
  }
};

// packages/ag-grid-react/src/shared/customComp/menuItemComponentWrapper.ts
var MenuItemComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.active = false;
    this.expanded = false;
    this.onActiveChange = (active) => this.updateActive(active);
  }
  setActive(active) {
    this.awaitSetActive(active);
  }
  setExpanded(expanded) {
    this.expanded = expanded;
    this.refreshProps();
  }
  getOptionalMethods() {
    return ["select", "configureDefaults"];
  }
  awaitSetActive(active) {
    this.active = active;
    return this.refreshProps();
  }
  updateActive(active) {
    const result = this.awaitSetActive(active);
    if (active) {
      result.then(() => this.sourceParams.onItemActivated());
    }
  }
  getProps() {
    const props = super.getProps();
    props.active = this.active;
    props.expanded = this.expanded;
    props.onActiveChange = this.onActiveChange;
    delete props.onItemActivated;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/noRowsOverlayComponentWrapper.ts
var NoRowsOverlayComponentWrapper = class extends CustomComponentWrapper {
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
  }
};

// packages/ag-grid-react/src/shared/customComp/statusPanelComponentWrapper.ts
var StatusPanelComponentWrapper = class extends CustomComponentWrapper {
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
    return true;
  }
};

// packages/ag-grid-react/src/shared/customComp/toolPanelComponentWrapper.ts
var ToolPanelComponentWrapper = class extends CustomComponentWrapper {
  constructor() {
    super(...arguments);
    this.onStateChange = (state) => this.updateState(state);
  }
  refresh(params) {
    this.sourceParams = params;
    this.refreshProps();
    return true;
  }
  getState() {
    return this.state;
  }
  updateState(state) {
    this.state = state;
    this.refreshProps();
    this.sourceParams.onStateUpdated();
  }
  getProps() {
    const props = super.getProps();
    props.state = this.state;
    props.onStateChange = this.onStateChange;
    return props;
  }
};

// packages/ag-grid-react/src/shared/customComp/util.ts

function getInstance(wrapperComponent, callback) {
  const promise = wrapperComponent?.getInstance?.() ?? AgPromise6.resolve(void 0);
  promise.then((comp) => callback(comp));
}
function warnReactiveCustomComponents() {
  (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._warn */ .ujB)(231);
}

// packages/ag-grid-react/src/shared/portalManager.ts
var MAX_COMPONENT_CREATION_TIME_IN_MS = 1e3;
var PortalManager = class {
  constructor(refresher, wrappingElement, maxComponentCreationTimeMs) {
    this.destroyed = false;
    this.portals = [];
    this.hasPendingPortalUpdate = false;
    this.wrappingElement = wrappingElement ? wrappingElement : "div";
    this.refresher = refresher;
    this.maxComponentCreationTimeMs = maxComponentCreationTimeMs ? maxComponentCreationTimeMs : MAX_COMPONENT_CREATION_TIME_IN_MS;
  }
  getPortals() {
    return this.portals;
  }
  destroy() {
    this.destroyed = true;
  }
  destroyPortal(portal) {
    this.portals = this.portals.filter((curPortal) => curPortal !== portal);
    this.batchUpdate();
  }
  getComponentWrappingElement() {
    return this.wrappingElement;
  }
  mountReactPortal(portal, reactComponent, resolve) {
    this.portals = [...this.portals, portal];
    this.waitForInstance(reactComponent, resolve);
    this.batchUpdate();
  }
  updateReactPortal(oldPortal, newPortal) {
    this.portals[this.portals.indexOf(oldPortal)] = newPortal;
    this.batchUpdate();
  }
  batchUpdate() {
    if (this.hasPendingPortalUpdate) {
      return;
    }
    setTimeout(() => {
      if (!this.destroyed) {
        this.refresher();
        this.hasPendingPortalUpdate = false;
      }
    });
    this.hasPendingPortalUpdate = true;
  }
  waitForInstance(reactComponent, resolve, startTime = Date.now()) {
    if (this.destroyed) {
      resolve(null);
      return;
    }
    if (reactComponent.rendered()) {
      resolve(reactComponent);
    } else {
      if (Date.now() - startTime >= this.maxComponentCreationTimeMs && !this.hasPendingPortalUpdate) {
        agFlushSync(true, () => this.refresher());
        if (reactComponent.rendered()) {
          resolve(reactComponent);
        }
        return;
      }
      window.setTimeout(() => {
        this.waitForInstance(reactComponent, resolve, startTime);
      });
    }
  }
};

// packages/ag-grid-react/src/reactUi/gridComp.tsx



// packages/ag-grid-react/src/reactUi/gridBodyComp.tsx



// packages/ag-grid-react/src/reactUi/header/gridHeaderComp.tsx



// packages/ag-grid-react/src/reactUi/header/headerRowContainerComp.tsx



// packages/ag-grid-react/src/reactUi/header/headerRowComp.tsx



// packages/ag-grid-react/src/reactUi/header/headerCellComp.tsx


var HeaderCellComp = ({ ctrl }) => {
  const isAlive = ctrl.isAlive();
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const [userCompDetails, setUserCompDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [userStyles, setUserStyles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eResize = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eHeaderCompWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const userCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const cssManager = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  if (isAlive && !cssManager.current) {
    cssManager.current = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .CssClassManager */ .hv8(() => eGui.current);
  }
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || !ctrl.isAlive() || context.isDestroyed()) {
      compBean.current = context.destroyBean(compBean.current);
      return;
    }
    compBean.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD());
    const refreshSelectAllGui = () => {
      const selectAllGui = ctrl.getSelectAllGui();
      if (selectAllGui) {
        eResize.current?.insertAdjacentElement("afterend", selectAllGui);
        compBean.current.addDestroyFunc(() => selectAllGui.remove());
      }
    };
    const compProxy = {
      setWidth: (width) => {
        if (eGui.current) {
          eGui.current.style.width = width;
        }
      },
      toggleCss: (name, on) => cssManager.current.toggleCss(name, on),
      setUserStyles: (styles) => setUserStyles(styles),
      setAriaSort: (sort) => {
        if (eGui.current) {
          sort ? (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._setAriaSort */ .JJT)(eGui.current, sort) : (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._removeAriaSort */ .T2p)(eGui.current);
        }
      },
      setUserCompDetails: (compDetails) => setUserCompDetails(compDetails),
      getUserCompInstance: () => userCompRef.current || void 0,
      refreshSelectAllGui,
      removeSelectAllGui: () => ctrl.getSelectAllGui()?.remove()
    };
    ctrl.setComp(compProxy, eRef, eResize.current, eHeaderCompWrapper.current, compBean.current);
    refreshSelectAllGui();
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(
    () => showJsComp(userCompDetails, context, eHeaderCompWrapper.current, userCompRef),
    [userCompDetails]
  );
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ctrl.setDragSource(eGui.current);
  }, [userCompDetails]);
  const userCompStateless = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = userCompDetails?.componentFromFramework && isComponentStateless(userCompDetails.componentClass);
    return !!res;
  }, [userCompDetails]);
  const reactUserComp = userCompDetails?.componentFromFramework;
  const UserCompClass = userCompDetails?.componentClass;
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, style: userStyles, className: "ag-header-cell", role: "columnheader" }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eResize, className: "ag-header-cell-resize", role: "presentation" }), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eHeaderCompWrapper, className: "ag-header-cell-comp-wrapper", role: "presentation" }, reactUserComp ? userCompStateless ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...userCompDetails.params }) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...userCompDetails.params, ref: userCompRef }) : null));
};
var headerCellComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(HeaderCellComp);

// packages/ag-grid-react/src/reactUi/header/headerFilterCellComp.tsx



// packages/ag-grid-react/src/shared/customComp/floatingFilterDisplayComponentProxy.ts
var FloatingFilterDisplayComponentProxy = class {
  constructor(floatingFilterParams, refreshProps) {
    this.floatingFilterParams = floatingFilterParams;
    this.refreshProps = refreshProps;
  }
  getProps() {
    return this.floatingFilterParams;
  }
  refresh(params) {
    this.floatingFilterParams = params;
    this.refreshProps();
  }
  setMethods(methods) {
    addOptionalMethods(this.getOptionalMethods(), methods, this);
  }
  getOptionalMethods() {
    return ["afterGuiAttached"];
  }
};

// packages/ag-grid-react/src/reactUi/header/headerFilterCellComp.tsx
var HeaderFilterCellComp = ({ ctrl }) => {
  const { context, gos } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const [userStyles, setUserStyles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [cssClasses, setCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => new CssClasses("ag-header-cell", "ag-floating-filter")
  );
  const [cssBodyClasses, setBodyCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [cssButtonWrapperClasses, setButtonWrapperCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => new CssClasses("ag-floating-filter-button", "ag-hidden")
  );
  const [buttonWrapperAriaHidden, setButtonWrapperAriaHidden] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("false");
  const [userCompDetails, setUserCompDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [, setRenderKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eFloatingFilterBody = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eButtonWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eButtonShowMainFilter = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const userCompResolve = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const userCompPromise = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const userCompRef = (value) => {
    if (value == null) {
      return;
    }
    userCompResolve.current && userCompResolve.current(value);
  };
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || !ctrl.isAlive() || context.isDestroyed()) {
      compBean.current = context.destroyBean(compBean.current);
      return;
    }
    compBean.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD());
    userCompPromise.current = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      userCompResolve.current = resolve;
    });
    const compProxy = {
      toggleCss: (name, on) => setCssClasses((prev) => prev.setClass(name, on)),
      setUserStyles: (styles) => setUserStyles(styles),
      addOrRemoveBodyCssClass: (name, on) => setBodyCssClasses((prev) => prev.setClass(name, on)),
      setButtonWrapperDisplayed: (displayed) => {
        setButtonWrapperCssClasses((prev) => prev.setClass("ag-hidden", !displayed));
        setButtonWrapperAriaHidden(!displayed ? "true" : "false");
      },
      setWidth: (width) => {
        if (eGui.current) {
          eGui.current.style.width = width;
        }
      },
      setCompDetails: (compDetails) => setUserCompDetails(compDetails),
      getFloatingFilterComp: () => userCompPromise.current ? userCompPromise.current : null,
      setMenuIcon: (eIcon) => eButtonShowMainFilter.current?.appendChild(eIcon)
    };
    ctrl.setComp(compProxy, eRef, eButtonShowMainFilter.current, eFloatingFilterBody.current, compBean.current);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(
    () => showJsComp(userCompDetails, context, eFloatingFilterBody.current, userCompRef),
    [userCompDetails]
  );
  const className = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cssClasses.toString(), [cssClasses]);
  const bodyClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cssBodyClasses.toString(), [cssBodyClasses]);
  const buttonWrapperClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cssButtonWrapperClasses.toString(), [cssButtonWrapperClasses]);
  const userCompStateless = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = userCompDetails && userCompDetails.componentFromFramework && isComponentStateless(userCompDetails.componentClass);
    return !!res;
  }, [userCompDetails]);
  const reactiveCustomComponents = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => gos.get("reactiveCustomComponents"), []);
  const enableFilterHandlers = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => gos.get("enableFilterHandlers"), []);
  const [floatingFilterCompProxy, setFloatingFilterCompProxy] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (userCompDetails?.componentFromFramework) {
      if (reactiveCustomComponents) {
        const ProxyClass = enableFilterHandlers ? FloatingFilterDisplayComponentProxy : FloatingFilterComponentProxy;
        const compProxy = new ProxyClass(userCompDetails.params, () => setRenderKey((prev) => prev + 1));
        userCompRef(compProxy);
        setFloatingFilterCompProxy(compProxy);
      } else {
        warnReactiveCustomComponents();
      }
    }
  }, [userCompDetails]);
  const floatingFilterProps = floatingFilterCompProxy?.getProps();
  const reactUserComp = userCompDetails?.componentFromFramework;
  const UserCompClass = userCompDetails?.componentClass;
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, style: userStyles, className, role: "gridcell" }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eFloatingFilterBody, className: bodyClassName, role: "presentation" }, reactUserComp ? reactiveCustomComponents ? floatingFilterProps && /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    CustomContext.Provider,
    {
      value: {
        setMethods: (methods) => floatingFilterCompProxy.setMethods(methods)
      }
    },
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...floatingFilterProps })
  ) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...userCompDetails.params, ref: userCompStateless ? () => {
  } : userCompRef }) : null), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    "div",
    {
      ref: eButtonWrapper,
      "aria-hidden": buttonWrapperAriaHidden,
      className: buttonWrapperClassName,
      role: "presentation"
    },
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
      "button",
      {
        ref: eButtonShowMainFilter,
        type: "button",
        className: "ag-button ag-floating-filter-button-button",
        tabIndex: -1
      }
    )
  ));
};
var headerFilterCellComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(HeaderFilterCellComp);

// packages/ag-grid-react/src/reactUi/header/headerGroupCellComp.tsx


var HeaderGroupCellComp = ({ ctrl }) => {
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const [userStyles, setUserStyles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [cssClasses, setCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [cssResizableClasses, setResizableCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [resizableAriaHidden, setResizableAriaHidden] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("false");
  const [ariaExpanded, setAriaExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [userCompDetails, setUserCompDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eResize = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eHeaderCompWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const userCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || !ctrl.isAlive() || context.isDestroyed()) {
      compBean.current = context.destroyBean(compBean.current);
      return;
    }
    compBean.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD());
    const compProxy = {
      setWidth: (width) => {
        if (eGui.current) {
          eGui.current.style.width = width;
        }
      },
      toggleCss: (name, on) => setCssClasses((prev) => prev.setClass(name, on)),
      setUserStyles: (styles) => setUserStyles(styles),
      setHeaderWrapperHidden: (hidden) => {
        const headerCompWrapper = eHeaderCompWrapper.current;
        if (!headerCompWrapper) {
          return;
        }
        if (hidden) {
          headerCompWrapper.style.setProperty("display", "none");
        } else {
          headerCompWrapper.style.removeProperty("display");
        }
      },
      setHeaderWrapperMaxHeight: (value) => {
        const headerCompWrapper = eHeaderCompWrapper.current;
        if (!headerCompWrapper) {
          return;
        }
        if (value != null) {
          headerCompWrapper.style.setProperty("max-height", `${value}px`);
        } else {
          headerCompWrapper.style.removeProperty("max-height");
        }
        headerCompWrapper.classList.toggle("ag-header-cell-comp-wrapper-limited-height", value != null);
      },
      setUserCompDetails: (compDetails) => setUserCompDetails(compDetails),
      setResizableDisplayed: (displayed) => {
        setResizableCssClasses((prev) => prev.setClass("ag-hidden", !displayed));
        setResizableAriaHidden(!displayed ? "true" : "false");
      },
      setAriaExpanded: (expanded) => setAriaExpanded(expanded),
      getUserCompInstance: () => userCompRef.current || void 0
    };
    ctrl.setComp(compProxy, eRef, eResize.current, eHeaderCompWrapper.current, compBean.current);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => showJsComp(userCompDetails, context, eHeaderCompWrapper.current), [userCompDetails]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (eGui.current) {
      ctrl.setDragSource(eGui.current);
    }
  }, [userCompDetails]);
  const userCompStateless = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = userCompDetails?.componentFromFramework && isComponentStateless(userCompDetails.componentClass);
    return !!res;
  }, [userCompDetails]);
  const className = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => "ag-header-group-cell " + cssClasses.toString(), [cssClasses]);
  const resizableClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => "ag-header-cell-resize " + cssResizableClasses.toString(),
    [cssResizableClasses]
  );
  const reactUserComp = userCompDetails?.componentFromFramework;
  const UserCompClass = userCompDetails?.componentClass;
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, style: userStyles, className, role: "columnheader", "aria-expanded": ariaExpanded }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eHeaderCompWrapper, className: "ag-header-cell-comp-wrapper", role: "presentation" }, reactUserComp ? userCompStateless ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...userCompDetails.params }) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(UserCompClass, { ...userCompDetails.params, ref: userCompRef }) : null), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eResize, "aria-hidden": resizableAriaHidden, className: resizableClassName }));
};
var headerGroupCellComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(HeaderGroupCellComp);

// packages/ag-grid-react/src/reactUi/header/headerRowComp.tsx
var HeaderRowComp = ({ ctrl }) => {
  const { gos, context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const { topOffset, rowHeight } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ctrl.getTopAndHeight(), []);
  const tabIndex = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => gos.get("tabIndex"), []);
  const [ariaRowIndex, setAriaRowIndex] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => ctrl.getAriaRowIndex());
  const className = ctrl.headerRowClass;
  const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => rowHeight + "px");
  const [top, setTop] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => topOffset + "px");
  const cellCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const [cellCtrls, setCellCtrls] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => ctrl.getUpdatedHeaderCtrls());
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || !ctrl.isAlive() || context.isDestroyed()) {
      compBean.current = context.destroyBean(compBean.current);
      return;
    }
    compBean.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD());
    const compProxy = {
      setHeight: (height2) => setHeight(height2),
      setTop: (top2) => setTop(top2),
      setHeaderCtrls: (ctrls, forceOrder, afterScroll) => {
        const prevCellCtrls = cellCtrlsRef.current;
        const nextCells = getNextValueIfDifferent(prevCellCtrls, ctrls, forceOrder);
        if (nextCells !== prevCellCtrls) {
          cellCtrlsRef.current = nextCells;
          agFlushSync(afterScroll, () => setCellCtrls(nextCells));
        }
      },
      setWidth: (width) => {
        if (eGui.current) {
          eGui.current.style.width = width;
        }
      },
      setRowIndex: (rowIndex) => {
        setAriaRowIndex(rowIndex);
      }
    };
    ctrl.setComp(compProxy, compBean.current, false);
  }, []);
  const style = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height,
      top
    }),
    [height, top]
  );
  const createCellJsx = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((cellCtrl) => {
    switch (ctrl.type) {
      case "group":
        return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerGroupCellComp_default, { ctrl: cellCtrl, key: cellCtrl.instanceId });
      case "filter":
        return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerFilterCellComp_default, { ctrl: cellCtrl, key: cellCtrl.instanceId });
      default:
        return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerCellComp_default, { ctrl: cellCtrl, key: cellCtrl.instanceId });
    }
  }, []);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    "div",
    {
      ref: setRef2,
      className,
      role: "row",
      style,
      tabIndex,
      "aria-rowindex": ariaRowIndex
    },
    cellCtrls.map(createCellJsx)
  );
};
var headerRowComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(HeaderRowComp);

// packages/ag-grid-react/src/reactUi/header/headerRowContainerComp.tsx
var HeaderRowContainerComp = ({ pinned }) => {
  const [displayed, setDisplayed] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const [headerRowCtrls, setHeaderRowCtrls] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eCenterContainer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const headerRowCtrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const pinnedLeft = pinned === "left";
  const pinnedRight = pinned === "right";
  const centre = !pinnedLeft && !pinnedRight;
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || context.isDestroyed()) {
      headerRowCtrlRef.current = context.destroyBean(headerRowCtrlRef.current);
      return;
    }
    headerRowCtrlRef.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .HeaderRowContainerCtrl */ .OPU(pinned));
    const compProxy = {
      setDisplayed,
      setCtrls: (ctrls) => setHeaderRowCtrls(ctrls),
      // centre only
      setCenterWidth: (width) => {
        if (eCenterContainer.current) {
          eCenterContainer.current.style.width = width;
        }
      },
      setViewportScrollLeft: (left) => {
        if (eGui.current) {
          eGui.current.scrollLeft = left;
        }
      },
      // pinned only
      setPinnedContainerWidth: (width) => {
        if (eGui.current) {
          eGui.current.style.width = width;
          eGui.current.style.minWidth = width;
          eGui.current.style.maxWidth = width;
        }
      }
    };
    headerRowCtrlRef.current.setComp(compProxy, eGui.current);
  }, []);
  const className = !displayed ? "ag-hidden" : "";
  const insertRowsJsx = () => headerRowCtrls.map((ctrl) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerRowComp_default, { ctrl, key: ctrl.instanceId }));
  return pinnedLeft ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className: "ag-pinned-left-header " + className, "aria-hidden": !displayed, role: "rowgroup" }, insertRowsJsx()) : pinnedRight ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className: "ag-pinned-right-header " + className, "aria-hidden": !displayed, role: "rowgroup" }, insertRowsJsx()) : centre ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className: "ag-header-viewport " + className, role: "rowgroup", tabIndex: -1 }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: eCenterContainer, className: "ag-header-container", role: "presentation" }, insertRowsJsx())) : null;
};
var headerRowContainerComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(HeaderRowContainerComp);

// packages/ag-grid-react/src/reactUi/header/gridHeaderComp.tsx
var GridHeaderComp = () => {
  const [cssClasses, setCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [height, setHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const gridCtrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef || context.isDestroyed()) {
      gridCtrlRef.current = context.destroyBean(gridCtrlRef.current);
      return;
    }
    gridCtrlRef.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .GridHeaderCtrl */ .vBt());
    const compProxy = {
      toggleCss: (name, on) => setCssClasses((prev) => prev.setClass(name, on)),
      setHeightAndMinHeight: (height2) => setHeight(height2)
    };
    gridCtrlRef.current.setComp(compProxy, eRef, eRef);
  }, []);
  const className = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = cssClasses.toString();
    return "ag-header " + res;
  }, [cssClasses]);
  const style = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height,
      minHeight: height
    }),
    [height]
  );
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className, style, role: "presentation" }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerRowContainerComp_default, { pinned: "left" }), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerRowContainerComp_default, { pinned: null }), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(headerRowContainerComp_default, { pinned: "right" }));
};
var gridHeaderComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(GridHeaderComp);

// packages/ag-grid-react/src/reactUi/reactComment.tsx

var useReactCommentEffect = (comment, eForCommentRef) => {
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const eForComment = eForCommentRef.current;
    if (eForComment) {
      const eParent = eForComment.parentElement;
      if (eParent) {
        const eComment = document.createComment(comment);
        eParent.insertBefore(eComment, eForComment);
        return () => {
          eComment.remove();
        };
      }
    }
  }, [comment]);
};
var reactComment_default = useReactCommentEffect;

// packages/ag-grid-react/src/reactUi/rows/rowContainerComp.tsx



// packages/ag-grid-react/src/reactUi/rows/rowComp.tsx



// packages/ag-grid-react/src/reactUi/cells/cellComp.tsx



// packages/ag-grid-react/src/shared/customComp/cellEditorComponentProxy.ts

var CellEditorComponentProxy = class {
  constructor(cellEditorParams, refreshProps) {
    this.cellEditorParams = cellEditorParams;
    this.refreshProps = refreshProps;
    this.instanceCreated = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .AgPromise */ .oY$((resolve) => {
      this.resolveInstanceCreated = resolve;
    });
    this.onValueChange = (value) => this.updateValue(value);
    this.value = cellEditorParams.value;
  }
  getProps() {
    return {
      ...this.cellEditorParams,
      initialValue: this.cellEditorParams.value,
      value: this.value,
      onValueChange: this.onValueChange
    };
  }
  getValue() {
    return this.value;
  }
  refresh(params) {
    this.cellEditorParams = params;
    this.refreshProps();
  }
  setMethods(methods) {
    addOptionalMethods(this.getOptionalMethods(), methods, this);
  }
  getInstance() {
    return this.instanceCreated.then(() => this.componentInstance);
  }
  setRef(componentInstance) {
    this.componentInstance = componentInstance;
    this.resolveInstanceCreated?.();
    this.resolveInstanceCreated = void 0;
  }
  getOptionalMethods() {
    return [
      "isCancelBeforeStart",
      "isCancelAfterEnd",
      "focusIn",
      "focusOut",
      "afterGuiAttached",
      "getValidationErrors",
      "getValidationElement"
    ];
  }
  updateValue(value) {
    this.value = value;
    this.refreshProps();
  }
};

// packages/ag-grid-react/src/reactUi/cells/cellEditorComp.tsx


// packages/ag-grid-react/src/reactUi/cells/popupEditorComp.tsx




// packages/ag-grid-react/src/reactUi/useEffectOnce.tsx

var useEffectOnce = (effect) => {
  const effectFn = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(effect);
  const destroyFn = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const effectCalled = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const rendered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const [, setVal] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  if (effectCalled.current) {
    rendered.current = true;
  }
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (!effectCalled.current) {
      destroyFn.current = effectFn.current();
      effectCalled.current = true;
    }
    setVal((val) => val + 1);
    return () => {
      if (!rendered.current) {
        return;
      }
      destroyFn.current?.();
    };
  }, []);
};

// packages/ag-grid-react/src/reactUi/cells/popupEditorComp.tsx
var PopupEditorComp = (props) => {
  const [popupEditorWrapper, setPopupEditorWrapper] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const beans = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const { context, popupSvc, gos, editSvc } = beans;
  const { editDetails, cellCtrl, eParentCell } = props;
  useEffectOnce(() => {
    const { compDetails } = editDetails;
    const useModelPopup = gos.get("stopEditingWhenCellsLoseFocus");
    let hideEditorPopup = void 0;
    let wrapper;
    if (!context.isDestroyed()) {
      wrapper = context.createBean(editSvc.createPopupEditorWrapper(compDetails.params));
      const ePopupGui = wrapper.getGui();
      if (props.jsChildComp) {
        const eChildGui = props.jsChildComp.getGui();
        if (eChildGui) {
          ePopupGui.appendChild(eChildGui);
        }
      }
      const { column, rowNode } = cellCtrl;
      const positionParams = {
        column,
        rowNode,
        type: "popupCellEditor",
        eventSource: eParentCell,
        ePopup: ePopupGui,
        position: editDetails.popupPosition,
        keepWithinBounds: true
      };
      const positionCallback = popupSvc?.positionPopupByComponent.bind(popupSvc, positionParams);
      const addPopupRes = popupSvc?.addPopup({
        modal: useModelPopup,
        eChild: ePopupGui,
        closeOnEsc: true,
        closedCallback: () => {
          cellCtrl.onPopupEditorClosed();
        },
        anchorToElement: eParentCell,
        positionCallback,
        ariaOwns: eParentCell
      });
      hideEditorPopup = addPopupRes ? addPopupRes.hideFunc : void 0;
      setPopupEditorWrapper(wrapper);
      props.jsChildComp?.afterGuiAttached?.();
    }
    return () => {
      hideEditorPopup?.();
      context.destroyBean(wrapper);
    };
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    return () => {
      if (cellCtrl.isCellFocused() && popupEditorWrapper?.getGui().contains((0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getActiveDomElement */ .UlD)(beans))) {
        eParentCell.focus({ preventScroll: true });
      }
    };
  }, [popupEditorWrapper]);
  return popupEditorWrapper && props.wrappedContent ? (0,react_dom__WEBPACK_IMPORTED_MODULE_2__.createPortal)(props.wrappedContent, popupEditorWrapper.getGui()) : null;
};
var popupEditorComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(PopupEditorComp);

// packages/ag-grid-react/src/reactUi/cells/cellEditorComp.tsx
var jsxEditorProxy = (editDetails, CellEditorClass, setRef2) => {
  const { compProxy } = editDetails;
  setRef2(compProxy);
  const props = compProxy.getProps();
  const isStateless = isComponentStateless(CellEditorClass);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    CustomContext.Provider,
    {
      value: {
        setMethods: (methods) => compProxy.setMethods(methods)
      }
    },
    isStateless ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellEditorClass, { ...props }) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellEditorClass, { ...props, ref: (ref) => compProxy.setRef(ref) })
  );
};
var jsxEditor = (editDetails, CellEditorClass, setRef2) => {
  const newFormat = editDetails.compProxy;
  return newFormat ? jsxEditorProxy(editDetails, CellEditorClass, setRef2) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellEditorClass, { ...editDetails.compDetails.params, ref: setRef2 });
};
var jsxEditValue = (editDetails, setCellEditorRef, eGui, cellCtrl, jsEditorComp) => {
  const compDetails = editDetails.compDetails;
  const CellEditorClass = compDetails.componentClass;
  const reactInlineEditor = compDetails.componentFromFramework && !editDetails.popup;
  const reactPopupEditor = compDetails.componentFromFramework && editDetails.popup;
  const jsPopupEditor = !compDetails.componentFromFramework && editDetails.popup;
  return reactInlineEditor ? jsxEditor(editDetails, CellEditorClass, setCellEditorRef) : reactPopupEditor ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    popupEditorComp_default,
    {
      editDetails,
      cellCtrl,
      eParentCell: eGui,
      wrappedContent: jsxEditor(editDetails, CellEditorClass, setCellEditorRef)
    }
  ) : jsPopupEditor && jsEditorComp ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(popupEditorComp_default, { editDetails, cellCtrl, eParentCell: eGui, jsChildComp: jsEditorComp }) : null;
};

// packages/ag-grid-react/src/reactUi/cells/showJsRenderer.tsx

var useJsCellRenderer = (showDetails, showTools, eCellValue, cellValueVersion, jsCellRendererRef, eGui) => {
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const destroyCellRenderer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    const comp = jsCellRendererRef.current;
    if (!comp) {
      return;
    }
    const compGui = comp.getGui();
    if (compGui && compGui.parentElement) {
      compGui.remove();
    }
    context.destroyBean(comp);
    jsCellRendererRef.current = void 0;
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const showValue = showDetails != null;
    const jsCompDetails = showDetails?.compDetails && !showDetails.compDetails.componentFromFramework;
    const waitingForToolsSetup = showTools && eCellValue == null;
    const showComp = showValue && jsCompDetails && !waitingForToolsSetup;
    if (!showComp) {
      destroyCellRenderer();
      return;
    }
    const compDetails = showDetails.compDetails;
    if (jsCellRendererRef.current) {
      const comp = jsCellRendererRef.current;
      const attemptRefresh = comp.refresh != null && showDetails.force == false;
      const refreshResult = attemptRefresh ? comp.refresh(compDetails.params) : false;
      const refreshWorked = refreshResult === true || refreshResult === void 0;
      if (refreshWorked) {
        return;
      }
      destroyCellRenderer();
    }
    const promise = compDetails.newAgStackInstance();
    promise.then((comp) => {
      if (!comp) {
        return;
      }
      const compGui = comp.getGui();
      if (!compGui) {
        return;
      }
      const parent = showTools ? eCellValue : eGui.current;
      parent.appendChild(compGui);
      jsCellRendererRef.current = comp;
    });
  }, [showDetails, showTools, cellValueVersion]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    return destroyCellRenderer;
  }, []);
};
var showJsRenderer_default = useJsCellRenderer;

// packages/ag-grid-react/src/reactUi/cells/skeletonCellComp.tsx

var SkeletonCellRenderer = ({
  cellCtrl,
  parent
}) => {
  const jsCellRendererRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const renderDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const { loadingComp } = cellCtrl.getDeferLoadingCellRenderer();
    return loadingComp ? {
      value: void 0,
      compDetails: loadingComp,
      force: false
    } : void 0;
  }, [cellCtrl]);
  showJsRenderer_default(renderDetails, false, void 0, 1, jsCellRendererRef, parent);
  if (renderDetails?.compDetails?.componentFromFramework) {
    const CellRendererClass = renderDetails.compDetails.componentClass;
    return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellRendererClass, { ...renderDetails.compDetails.params });
  }
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null);
};

// packages/ag-grid-react/src/reactUi/cells/cellComp.tsx
var CellComp = ({
  cellCtrl,
  printLayout,
  editingCell
}) => {
  const beans = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const { context } = beans;
  const {
    column: { colIdSanitised },
    instanceId
  } = cellCtrl;
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const [renderDetails, setRenderDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => cellCtrl.isCellRenderer() ? void 0 : { compDetails: void 0, value: cellCtrl.getValueToDisplay(), force: false }
  );
  const [editDetails, setEditDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [renderKey, setRenderKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const [userStyles, setUserStyles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [includeSelection, setIncludeSelection] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [includeRowDrag, setIncludeRowDrag] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [includeDndSource, setIncludeDndSource] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [jsEditorComp, setJsEditorComp] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const forceWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cellCtrl.isForceWrapper(), [cellCtrl]);
  const cellAriaRole = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cellCtrl.getCellAriaRole(), [cellCtrl]);
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const cellRendererRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const jsCellRendererRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const cellEditorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eCellWrapper = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const cellWrapperDestroyFuncs = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const rowDragCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eCellValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const [cellValueVersion, setCellValueVersion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const setCellValueRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((ref) => {
    eCellValue.current = ref;
    setCellValueVersion((v) => v + 1);
  }, []);
  const showTools = renderDetails != null && (includeSelection || includeDndSource || includeRowDrag) && (editDetails == null || !!editDetails.popup);
  const showCellWrapper = forceWrapper || showTools;
  const cellValueClass = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    return cellCtrl.getCellValueClass();
  }, [cellCtrl]);
  const setCellEditorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (cellEditor) => {
      cellEditorRef.current = cellEditor;
      if (cellEditor) {
        const editingCancelledByUserComp = cellEditor.isCancelBeforeStart && cellEditor.isCancelBeforeStart();
        setTimeout(() => {
          if (editingCancelledByUserComp) {
            cellCtrl.stopEditing(true);
            cellCtrl.focusCell(true);
          } else {
            cellCtrl.cellEditorAttached();
            cellCtrl.enableEditorTooltipFeature(cellEditor);
          }
        });
      }
    },
    [cellCtrl]
  );
  const cssManager = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  if (!cssManager.current) {
    cssManager.current = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .CssClassManager */ .hv8(() => eGui.current);
  }
  showJsRenderer_default(renderDetails, showCellWrapper, eCellValue.current, cellValueVersion, jsCellRendererRef, eGui);
  const lastRenderDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const oldDetails = lastRenderDetails.current;
    const newDetails = renderDetails;
    lastRenderDetails.current = renderDetails;
    if (oldDetails == null || oldDetails.compDetails == null || newDetails == null || newDetails.compDetails == null) {
      return;
    }
    rowDragCompRef.current?.refreshVisibility();
    const oldCompDetails = oldDetails.compDetails;
    const newCompDetails = newDetails.compDetails;
    if (oldCompDetails.componentClass != newCompDetails.componentClass) {
      return;
    }
    if (cellRendererRef.current?.refresh == null) {
      return;
    }
    const result = cellRendererRef.current.refresh(newCompDetails.params);
    if (result != true) {
      setRenderKey((prev) => prev + 1);
    }
  }, [renderDetails]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    const doingJsEditor = editDetails && !editDetails.compDetails.componentFromFramework;
    if (!doingJsEditor || context.isDestroyed()) {
      return;
    }
    const compDetails = editDetails.compDetails;
    const isPopup = editDetails.popup === true;
    const cellEditorPromise = compDetails.newAgStackInstance();
    cellEditorPromise.then((cellEditor) => {
      if (!cellEditor) {
        return;
      }
      const compGui = cellEditor.getGui();
      setCellEditorRef(cellEditor);
      if (!isPopup) {
        const parentEl = (forceWrapper ? eCellWrapper : eGui).current;
        parentEl?.appendChild(compGui);
        cellEditor.afterGuiAttached?.();
      }
      setJsEditorComp(cellEditor);
    });
    return () => {
      cellEditorPromise.then((cellEditor) => {
        const compGui = cellEditor.getGui();
        cellCtrl.disableEditorTooltipFeature();
        context.destroyBean(cellEditor);
        setCellEditorRef(void 0);
        setJsEditorComp(void 0);
        compGui?.remove();
      });
    };
  }, [editDetails]);
  const setCellWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (eRef) => {
      eCellWrapper.current = eRef;
      if (!eRef || context.isDestroyed() || !cellCtrl.isAlive()) {
        const callbacks = cellWrapperDestroyFuncs.current;
        cellWrapperDestroyFuncs.current = [];
        for (const cb of callbacks) {
          cb();
        }
        return;
      }
      let rowDragComp;
      const addComp = (comp) => {
        if (comp) {
          eRef.insertAdjacentElement("afterbegin", comp.getGui());
          cellWrapperDestroyFuncs.current.push(() => {
            (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._removeFromParent */ .MwW)(comp.getGui());
            context.destroyBean(comp);
            if (rowDragCompRef.current === rowDragComp) {
              rowDragCompRef.current = void 0;
            }
          });
        }
      };
      if (includeSelection) {
        addComp(cellCtrl.createSelectionCheckbox());
      }
      if (includeDndSource) {
        addComp(cellCtrl.createDndSource());
      }
      if (includeRowDrag) {
        rowDragComp = cellCtrl.createRowDragComp();
        rowDragCompRef.current = rowDragComp;
        if (rowDragComp) {
          addComp(rowDragComp);
          rowDragComp.refreshVisibility();
        }
      }
    },
    [cellCtrl, context, includeDndSource, includeRowDrag, includeSelection]
  );
  const init = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    const spanReady = !cellCtrl.isCellSpanning() || eWrapper.current;
    const eRef = eGui.current;
    if (!eRef || !spanReady || !cellCtrl || !cellCtrl.isAlive() || context.isDestroyed()) {
      compBean.current = context.destroyBean(compBean.current);
      return;
    }
    compBean.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD());
    const compProxy = {
      toggleCss: (name, on) => cssManager.current.toggleCss(name, on),
      setUserStyles: (styles) => setUserStyles(styles),
      getFocusableElement: () => eGui.current,
      setIncludeSelection: (include) => setIncludeSelection(include),
      setIncludeRowDrag: (include) => setIncludeRowDrag(include),
      setIncludeDndSource: (include) => setIncludeDndSource(include),
      getCellEditor: () => cellEditorRef.current ?? null,
      getCellRenderer: () => cellRendererRef.current ?? jsCellRendererRef.current,
      getParentOfValue: () => eCellValue.current ?? eCellWrapper.current ?? eGui.current,
      setRenderDetails: (compDetails, value, force) => {
        const setDetails = () => {
          setRenderDetails((prev) => {
            if (prev?.compDetails !== compDetails || prev?.value !== value || prev?.force !== force) {
              return {
                value,
                compDetails,
                force
              };
            } else {
              return prev;
            }
          });
        };
        if (compDetails?.params?.deferRender && !cellCtrl.rowNode.group) {
          const { loadingComp, onReady } = cellCtrl.getDeferLoadingCellRenderer();
          if (loadingComp) {
            setRenderDetails({
              value: void 0,
              compDetails: loadingComp,
              force: false
            });
            onReady.then(() => agStartTransition(setDetails));
            return;
          }
        }
        setDetails();
      },
      setEditDetails: (compDetails, popup, popupPosition, reactiveCustomComponents) => {
        if (compDetails) {
          let compProxy2 = void 0;
          if (compDetails.componentFromFramework) {
            if (reactiveCustomComponents) {
              compProxy2 = new CellEditorComponentProxy(
                compDetails.params,
                () => setRenderKey((prev) => prev + 1)
              );
            } else {
              warnReactiveCustomComponents();
            }
          }
          setEditDetails({
            compDetails,
            popup,
            popupPosition,
            compProxy: compProxy2
          });
          if (!popup) {
            setRenderDetails(void 0);
          }
        } else {
          const recoverFocus = cellCtrl.hasBrowserFocus();
          if (recoverFocus) {
            compProxy.getFocusableElement().focus({ preventScroll: true });
          }
          cellEditorRef.current = void 0;
          setEditDetails(void 0);
        }
      },
      refreshEditStyles: (editing, isPopup) => {
        if (!eGui.current) {
          return;
        }
        const { current } = cssManager;
        current.toggleCss("ag-cell-value", !showCellWrapper);
        current.toggleCss("ag-cell-inline-editing", !!editing && !isPopup);
        current.toggleCss("ag-cell-popup-editing", !!editing && !!isPopup);
        current.toggleCss("ag-cell-not-inline-editing", !editing || !!isPopup);
      }
    };
    const cellWrapperOrUndefined = eCellWrapper.current || void 0;
    cellCtrl.setComp(
      compProxy,
      eRef,
      eWrapper.current ?? void 0,
      cellWrapperOrUndefined,
      printLayout,
      editingCell,
      compBean.current
    );
  }, []);
  const setGuiRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((ref) => {
    eGui.current = ref;
    init();
  }, []);
  const setWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((ref) => {
    eWrapper.current = ref;
    init();
  }, []);
  const reactCellRendererStateless = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = renderDetails?.compDetails?.componentFromFramework && isComponentStateless(renderDetails.compDetails.componentClass);
    return !!res;
  }, [renderDetails]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(() => {
    if (!eGui.current) {
      return;
    }
    const { current } = cssManager;
    current.toggleCss("ag-cell-value", !showCellWrapper);
    current.toggleCss("ag-cell-inline-editing", !!editDetails && !editDetails.popup);
    current.toggleCss("ag-cell-popup-editing", !!editDetails && !!editDetails.popup);
    current.toggleCss("ag-cell-not-inline-editing", !editDetails || !!editDetails.popup);
  });
  const valueOrCellComp = () => {
    const { compDetails, value } = renderDetails;
    if (!compDetails) {
      return value?.toString?.() ?? value;
    }
    if (compDetails.componentFromFramework) {
      const CellRendererClass = compDetails.componentClass;
      return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Suspense, { fallback: /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(SkeletonCellRenderer, { cellCtrl, parent: eGui }) }, reactCellRendererStateless ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellRendererClass, { ...compDetails.params, key: renderKey }) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(CellRendererClass, { ...compDetails.params, key: renderKey, ref: cellRendererRef }));
    }
  };
  const showCellOrEditor = () => {
    const showCellValue = () => {
      if (renderDetails == null) {
        return null;
      }
      return showCellWrapper ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { role: "presentation", id: `cell-${instanceId}`, className: cellValueClass, ref: setCellValueRef }, valueOrCellComp()) : valueOrCellComp();
    };
    const showEditValue = (details) => jsxEditValue(details, setCellEditorRef, eGui.current, cellCtrl, jsEditorComp);
    if (editDetails != null) {
      if (editDetails.popup) {
        return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, showCellValue(), showEditValue(editDetails));
      }
      return showEditValue(editDetails);
    }
    return showCellValue();
  };
  const renderCell = () => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setGuiRef, style: userStyles, role: cellAriaRole, "col-id": colIdSanitised }, showCellWrapper ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "ag-cell-wrapper", role: "presentation", ref: setCellWrapperRef }, showCellOrEditor()) : showCellOrEditor());
  if (cellCtrl.isCellSpanning()) {
    return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setWrapperRef, className: "ag-spanned-cell-wrapper", role: "presentation" }, renderCell());
  }
  return renderCell();
};
var cellComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(CellComp);

// packages/ag-grid-react/src/reactUi/rows/rowComp.tsx
var RowComp = ({ rowCtrl, containerType }) => {
  const { context, gos, editSvc } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const enableUses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(RenderModeContext) === "default";
  const compBean = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const domOrderRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(rowCtrl.getDomOrder());
  const isFullWidth = rowCtrl.isFullWidth();
  const isDisplayed = rowCtrl.rowNode.displayed;
  const [rowIndex, setRowIndex] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => isDisplayed ? rowCtrl.rowNode.getRowIndexString() : null
  );
  const [rowId, setRowId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => rowCtrl.rowId);
  const [rowBusinessKey, setRowBusinessKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => rowCtrl.businessKey);
  const [userStyles, setUserStyles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => rowCtrl.rowStyles);
  const cellCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const [cellCtrlsFlushSync, setCellCtrlsFlushSync] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => null);
  const [fullWidthCompDetails, setFullWidthCompDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [top, setTop] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => isDisplayed ? rowCtrl.getInitialRowTop(containerType) : void 0
  );
  const [transform, setTransform] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(
    () => isDisplayed ? rowCtrl.getInitialTransform(containerType) : void 0
  );
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const fullWidthCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const fullWidthParamsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const autoHeightSetup = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const [autoHeightSetupAttempt, setAutoHeightSetupAttempt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (autoHeightSetup.current || !fullWidthCompDetails || autoHeightSetupAttempt > 10) {
      return;
    }
    const eChild = eGui.current?.firstChild;
    if (eChild) {
      rowCtrl.setupDetailRowAutoHeight(eChild);
      autoHeightSetup.current = true;
    } else {
      setAutoHeightSetupAttempt((prev) => prev + 1);
    }
  }, [fullWidthCompDetails, autoHeightSetupAttempt]);
  const cssManager = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  if (!cssManager.current) {
    cssManager.current = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .CssClassManager */ .hv8(() => eGui.current);
  }
  const cellsChanged = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(() => {
  });
  const sub = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((onStoreChange) => {
    cellsChanged.current = onStoreChange;
    return () => {
      cellsChanged.current = () => {
      };
    };
  }, []);
  const cellCtrlsUses = agUseSyncExternalStore(
    sub,
    () => {
      return cellCtrlsRef.current;
    },
    []
  );
  const cellCtrlsMerged = enableUses ? cellCtrlsUses : cellCtrlsFlushSync;
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    compBean.current = eRef ? context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._EmptyBean */ .dQD()) : context.destroyBean(compBean.current);
    if (!eRef) {
      rowCtrl.unsetComp(containerType);
      return;
    }
    if (!rowCtrl.isAlive() || context.isDestroyed()) {
      return;
    }
    const compProxy = {
      // the rowTop is managed by state, instead of direct style manipulation by rowCtrl (like all the other styles)
      // as we need to have an initial value when it's placed into he DOM for the first time, for animation to work.
      setTop,
      setTransform,
      // i found using React for managing classes at the row level was to slow, as modifying classes caused a lot of
      // React code to execute, so avoiding React for managing CSS Classes made the grid go much faster.
      toggleCss: (name, on) => cssManager.current.toggleCss(name, on),
      setDomOrder: (domOrder) => domOrderRef.current = domOrder,
      setRowIndex,
      setRowId,
      setRowBusinessKey,
      setUserStyles,
      // if we don't maintain the order, then cols will be ripped out and into the dom
      // when cols reordered, which would stop the CSS transitions from working
      setCellCtrls: (next, useFlushSync) => {
        const prevCellCtrls = cellCtrlsRef.current;
        const nextCells = getNextValueIfDifferent(prevCellCtrls, next, domOrderRef.current);
        if (nextCells !== prevCellCtrls) {
          cellCtrlsRef.current = nextCells;
          if (enableUses) {
            cellsChanged.current();
          } else {
            agFlushSync(useFlushSync, () => setCellCtrlsFlushSync(nextCells));
          }
        }
      },
      showFullWidth: (compDetails) => {
        fullWidthParamsRef.current = compDetails.params;
        setFullWidthCompDetails(compDetails);
      },
      getFullWidthCellRenderer: () => fullWidthCompRef.current,
      getFullWidthCellRendererParams: () => fullWidthParamsRef.current,
      refreshFullWidth: (getUpdatedParams) => {
        const fullWidthParams = getUpdatedParams();
        fullWidthParamsRef.current = fullWidthParams;
        if (canRefreshFullWidthRef.current) {
          setFullWidthCompDetails((prevFullWidthCompDetails) => ({
            ...prevFullWidthCompDetails,
            params: fullWidthParams
          }));
          return true;
        } else {
          if (!fullWidthCompRef.current || !fullWidthCompRef.current.refresh) {
            return false;
          }
          return fullWidthCompRef.current.refresh(fullWidthParams);
        }
      }
    };
    rowCtrl.setComp(compProxy, eRef, containerType, compBean.current);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect)(
    () => showJsComp(fullWidthCompDetails, context, eGui.current, fullWidthCompRef),
    [fullWidthCompDetails]
  );
  const rowStyles = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = { top, transform };
    Object.assign(res, userStyles);
    return res;
  }, [top, transform, userStyles]);
  const showFullWidthFramework = isFullWidth && fullWidthCompDetails?.componentFromFramework;
  const showCells = !isFullWidth && cellCtrlsMerged != null;
  const reactFullWidthCellRendererStateless = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    const res = fullWidthCompDetails?.componentFromFramework && isComponentStateless(fullWidthCompDetails.componentClass);
    return !!res;
  }, [fullWidthCompDetails]);
  const canRefreshFullWidthRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    canRefreshFullWidthRef.current = reactFullWidthCellRendererStateless && !!fullWidthCompDetails && !!gos.get("reactiveCustomComponents");
  }, [reactFullWidthCellRendererStateless, fullWidthCompDetails]);
  const showCellsJsx = () => cellCtrlsMerged?.map((cellCtrl) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    cellComp_default,
    {
      cellCtrl,
      editingCell: editSvc?.isEditing(cellCtrl, { withOpenEditor: true }) ?? false,
      printLayout: rowCtrl.printLayout,
      key: cellCtrl.instanceId
    }
  ));
  const showFullWidthFrameworkJsx = () => {
    const FullWidthComp = fullWidthCompDetails.componentClass;
    return reactFullWidthCellRendererStateless ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(FullWidthComp, { ...fullWidthCompDetails.params }) : /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(FullWidthComp, { ...fullWidthCompDetails.params, ref: fullWidthCompRef });
  };
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    "div",
    {
      ref: setRef2,
      role: "row",
      style: rowStyles,
      "row-index": rowIndex,
      "row-id": rowId,
      "row-business-key": rowBusinessKey
    },
    showCells ? showCellsJsx() : showFullWidthFramework ? showFullWidthFrameworkJsx() : null
  );
};
var rowComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(RowComp);

// packages/ag-grid-react/src/reactUi/rows/rowContainerComp.tsx
var RowContainerComp = ({ name }) => {
  const { context, gos } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const containerOptions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getRowContainerOptions */ .BEv)(name), [name]);
  const eViewport = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eContainer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eSpanContainer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const rowCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const prevRowCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const [rowCtrlsOrdered, setRowCtrlsOrdered] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => []);
  const isSpanning = !!gos.get("enableCellSpan") && !!containerOptions.getSpannedRowCtrls;
  const spannedRowCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const prevSpannedRowCtrlsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const [spannedRowCtrlsOrdered, setSpannedRowCtrlsOrdered] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => []);
  const domOrderRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const rowContainerCtrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const viewportClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList("ag-viewport", (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getRowViewportClass */ ._oP)(name)), [name]);
  const containerClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList((0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getRowContainerClass */ .Hky)(name)), [name]);
  const spanClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList("ag-spanning-container", (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getRowSpanContainerClass */ .bUh)(name)), [name]);
  const shouldRenderViewport = containerOptions.type === "center" || isSpanning;
  const topLevelRef = shouldRenderViewport ? eViewport : eContainer;
  reactComment_default(" AG Row Container " + name + " ", topLevelRef);
  const areElementsReady = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    const viewportReady = !shouldRenderViewport || eViewport.current != null;
    const containerReady = eContainer.current != null;
    const spanContainerReady = !isSpanning || eSpanContainer.current != null;
    return viewportReady && containerReady && spanContainerReady;
  }, []);
  const areElementsRemoved = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    return eViewport.current == null && eContainer.current == null && eSpanContainer.current == null;
  }, []);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    if (areElementsRemoved()) {
      rowContainerCtrlRef.current = context.destroyBean(rowContainerCtrlRef.current);
    }
    if (context.isDestroyed()) {
      return;
    }
    if (areElementsReady()) {
      const updateRowCtrlsOrdered = (useFlushSync) => {
        const next = getNextValueIfDifferent(
          prevRowCtrlsRef.current,
          rowCtrlsRef.current,
          domOrderRef.current
        );
        if (next !== prevRowCtrlsRef.current) {
          prevRowCtrlsRef.current = next;
          agFlushSync(useFlushSync, () => setRowCtrlsOrdered(next));
        }
      };
      const updateSpannedRowCtrlsOrdered = (useFlushSync) => {
        const next = getNextValueIfDifferent(
          prevSpannedRowCtrlsRef.current,
          spannedRowCtrlsRef.current,
          domOrderRef.current
        );
        if (next !== prevSpannedRowCtrlsRef.current) {
          prevSpannedRowCtrlsRef.current = next;
          agFlushSync(useFlushSync, () => setSpannedRowCtrlsOrdered(next));
        }
      };
      const compProxy = {
        setHorizontalScroll: (offset) => {
          if (eViewport.current) {
            eViewport.current.scrollLeft = offset;
          }
        },
        setViewportHeight: (height) => {
          if (eViewport.current) {
            eViewport.current.style.height = height;
          }
        },
        setRowCtrls: ({ rowCtrls, useFlushSync }) => {
          const useFlush = !!useFlushSync && rowCtrlsRef.current.length > 0 && rowCtrls.length > 0;
          rowCtrlsRef.current = rowCtrls;
          updateRowCtrlsOrdered(useFlush);
        },
        setSpannedRowCtrls: (rowCtrls, useFlushSync) => {
          const useFlush = !!useFlushSync && spannedRowCtrlsRef.current.length > 0 && rowCtrls.length > 0;
          spannedRowCtrlsRef.current = rowCtrls;
          updateSpannedRowCtrlsOrdered(useFlush);
        },
        setDomOrder: (domOrder) => {
          if (domOrderRef.current != domOrder) {
            domOrderRef.current = domOrder;
            updateRowCtrlsOrdered(false);
          }
        },
        setContainerWidth: (width) => {
          if (eContainer.current) {
            eContainer.current.style.width = width;
          }
        },
        setOffsetTop: (offset) => {
          if (eContainer.current) {
            eContainer.current.style.transform = `translateY(${offset})`;
          }
        }
      };
      rowContainerCtrlRef.current = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .RowContainerCtrl */ .Rlq(name));
      rowContainerCtrlRef.current.setComp(
        compProxy,
        eContainer.current,
        eSpanContainer.current ?? void 0,
        eViewport.current
      );
    }
  }, [areElementsReady, areElementsRemoved]);
  const setContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (e) => {
      eContainer.current = e;
      setRef2();
    },
    [setRef2]
  );
  const setSpanContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (e) => {
      eSpanContainer.current = e;
      setRef2();
    },
    [setRef2]
  );
  const setViewportRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (e) => {
      eViewport.current = e;
      setRef2();
    },
    [setRef2]
  );
  const buildContainer = () => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    "div",
    {
      className: containerClasses,
      ref: setContainerRef,
      role: shouldRenderViewport ? "presentation" : "rowgroup"
    },
    rowCtrlsOrdered.map((rowCtrl) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(rowComp_default, { rowCtrl, containerType: containerOptions.type, key: rowCtrl.instanceId }))
  );
  if (!shouldRenderViewport) {
    return buildContainer();
  }
  const buildSpanContainer = () => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: spanClasses, ref: setSpanContainerRef, role: "presentation" }, spannedRowCtrlsOrdered.map((rowCtrl) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(rowComp_default, { rowCtrl, containerType: containerOptions.type, key: rowCtrl.instanceId })));
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: viewportClasses, ref: setViewportRef, role: "rowgroup" }, buildContainer(), isSpanning ? buildSpanContainer() : null);
};
var rowContainerComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(RowContainerComp);

// packages/ag-grid-react/src/reactUi/gridBodyComp.tsx
var GridBodyComp = () => {
  const beans = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const { context, overlays } = beans;
  const [rowAnimationClass, setRowAnimationClass] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const [topHeight, setTopHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const [bottomHeight, setBottomHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const [stickyTopHeight, setStickyTopHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0px");
  const [stickyTopTop, setStickyTopTop] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0px");
  const [stickyTopWidth, setStickyTopWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("100%");
  const [stickyBottomHeight, setStickyBottomHeight] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0px");
  const [stickyBottomBottom, setStickyBottomBottom] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0px");
  const [stickyBottomWidth, setStickyBottomWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("100%");
  const [topInvisible, setTopInvisible] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const [bottomInvisible, setBottomInvisible] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const [forceVerticalScrollClass, setForceVerticalScrollClass] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [topAndBottomOverflowY, setTopAndBottomOverflowY] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const [cellSelectableCss, setCellSelectableCss] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [layoutClass, setLayoutClass] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("ag-layout-normal");
  const cssManager = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  if (!cssManager.current) {
    cssManager.current = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .CssClassManager */ .hv8(() => eRoot.current);
  }
  const eRoot = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eTop = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eStickyTop = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eStickyBottom = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eBody = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eBodyViewport = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const eBottom = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const beansToDestroy = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const destroyFuncs = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  reactComment_default(" AG Grid Body ", eRoot);
  reactComment_default(" AG Pinned Top ", eTop);
  reactComment_default(" AG Sticky Top ", eStickyTop);
  reactComment_default(" AG Middle ", eBodyViewport);
  reactComment_default(" AG Pinned Bottom ", eBottom);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eRoot.current = eRef;
    if (!eRef || context.isDestroyed()) {
      beansToDestroy.current = context.destroyBeans(beansToDestroy.current);
      for (const f of destroyFuncs.current) {
        f();
      }
      destroyFuncs.current = [];
      return;
    }
    const attachToDom = (eParent, eChild) => {
      eParent.appendChild(eChild);
      destroyFuncs.current.push(() => eChild.remove());
    };
    const newComp = (compClass) => {
      const comp = context.createBean(new compClass());
      beansToDestroy.current.push(comp);
      return comp;
    };
    const addComp = (eParent, compClass, comment) => {
      attachToDom(eParent, document.createComment(comment));
      attachToDom(eParent, newComp(compClass).getGui());
    };
    addComp(eRef, ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .FakeHScrollComp */ .ifX, " AG Fake Horizontal Scroll ");
    const overlayComp = overlays?.getOverlayWrapperCompClass();
    if (overlayComp) {
      addComp(eRef, overlayComp, " AG Overlay Wrapper ");
    }
    if (eBody.current) {
      addComp(eBody.current, ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .FakeVScrollComp */ .AR_, " AG Fake Vertical Scroll ");
    }
    const compProxy = {
      setRowAnimationCssOnBodyViewport: setRowAnimationClass,
      setColumnCount: (count) => {
        if (eRoot.current) {
          (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._setAriaColCount */ .Aag)(eRoot.current, count);
        }
      },
      setRowCount: (count) => {
        if (eRoot.current) {
          (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._setAriaRowCount */ .cBy)(eRoot.current, count);
        }
      },
      setTopHeight,
      setBottomHeight,
      setStickyTopHeight,
      setStickyTopTop,
      setStickyTopWidth,
      setTopInvisible,
      setBottomInvisible,
      setColumnMovingCss: (cssClass, flag) => cssManager.current.toggleCss(cssClass, flag),
      updateLayoutClasses: setLayoutClass,
      setAlwaysVerticalScrollClass: setForceVerticalScrollClass,
      setPinnedTopBottomOverflowY: setTopAndBottomOverflowY,
      setCellSelectableCss: (cssClass, flag) => setCellSelectableCss(flag ? cssClass : null),
      setBodyViewportWidth: (width) => {
        if (eBodyViewport.current) {
          eBodyViewport.current.style.width = width;
        }
      },
      registerBodyViewportResizeListener: (listener) => {
        if (eBodyViewport.current) {
          const unsubscribeFromResize = (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._observeResize */ .QSI)(beans, eBodyViewport.current, listener);
          destroyFuncs.current.push(() => unsubscribeFromResize());
        }
      },
      setStickyBottomHeight,
      setStickyBottomBottom,
      setStickyBottomWidth,
      setGridRootRole: (role) => eRef.setAttribute("role", role)
    };
    const ctrl = context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .GridBodyCtrl */ .m20());
    beansToDestroy.current.push(ctrl);
    ctrl.setComp(
      compProxy,
      eRef,
      eBodyViewport.current,
      eTop.current,
      eBottom.current,
      eStickyTop.current,
      eStickyBottom.current
    );
  }, []);
  const rootClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList("ag-root", "ag-unselectable", layoutClass), [layoutClass]);
  const bodyViewportClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList(
      "ag-body-viewport",
      rowAnimationClass,
      layoutClass,
      forceVerticalScrollClass,
      cellSelectableCss
    ),
    [rowAnimationClass, layoutClass, forceVerticalScrollClass, cellSelectableCss]
  );
  const bodyClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList("ag-body", layoutClass), [layoutClass]);
  const topClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList("ag-floating-top", topInvisible ? "ag-invisible" : null, cellSelectableCss),
    [cellSelectableCss, topInvisible]
  );
  const stickyTopClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => classesList("ag-sticky-top", cellSelectableCss), [cellSelectableCss]);
  const stickyBottomClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList("ag-sticky-bottom", stickyBottomHeight === "0px" ? "ag-invisible" : null, cellSelectableCss),
    [cellSelectableCss, stickyBottomHeight]
  );
  const bottomClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList("ag-floating-bottom", bottomInvisible ? "ag-invisible" : null, cellSelectableCss),
    [cellSelectableCss, bottomInvisible]
  );
  const topStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height: topHeight,
      minHeight: topHeight,
      overflowY: topAndBottomOverflowY
    }),
    [topHeight, topAndBottomOverflowY]
  );
  const stickyTopStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height: stickyTopHeight,
      top: stickyTopTop,
      width: stickyTopWidth
    }),
    [stickyTopHeight, stickyTopTop, stickyTopWidth]
  );
  const stickyBottomStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height: stickyBottomHeight,
      bottom: stickyBottomBottom,
      width: stickyBottomWidth
    }),
    [stickyBottomHeight, stickyBottomBottom, stickyBottomWidth]
  );
  const bottomStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      height: bottomHeight,
      minHeight: bottomHeight,
      overflowY: topAndBottomOverflowY
    }),
    [bottomHeight, topAndBottomOverflowY]
  );
  const createRowContainer = (container) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(rowContainerComp_default, { name: container, key: `${container}-container` });
  const createSection = ({
    section,
    children,
    className,
    style
  }) => /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: section, className, role: "presentation", style }, children.map(createRowContainer));
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className: rootClasses }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(gridHeaderComp_default, null), createSection({
    section: eTop,
    className: topClasses,
    style: topStyle,
    children: ["topLeft", "topCenter", "topRight", "topFullWidth"]
  }), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: bodyClasses, ref: eBody, role: "presentation" }, createSection({
    section: eBodyViewport,
    className: bodyViewportClasses,
    children: ["left", "center", "right", "fullWidth"]
  })), createSection({
    section: eStickyTop,
    className: stickyTopClasses,
    style: stickyTopStyle,
    children: ["stickyTopLeft", "stickyTopCenter", "stickyTopRight", "stickyTopFullWidth"]
  }), createSection({
    section: eStickyBottom,
    className: stickyBottomClasses,
    style: stickyBottomStyle,
    children: ["stickyBottomLeft", "stickyBottomCenter", "stickyBottomRight", "stickyBottomFullWidth"]
  }), createSection({
    section: eBottom,
    className: bottomClasses,
    style: bottomStyle,
    children: ["bottomLeft", "bottomCenter", "bottomRight", "bottomFullWidth"]
  }));
};
var gridBodyComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(GridBodyComp);

// packages/ag-grid-react/src/reactUi/tabGuardComp.tsx


var TabGuardCompRef = (props, forwardRef4) => {
  const { children, eFocusableElement, onTabKeyDown, gridCtrl, forceFocusOutWhenTabGuardsAreEmpty, isEmpty } = props;
  const { context } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const topTabGuardRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const bottomTabGuardRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const tabGuardCtrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const setTabIndex = (value) => {
    const processedValue = value == null ? void 0 : parseInt(value, 10).toString();
    for (const tabGuard of [topTabGuardRef, bottomTabGuardRef]) {
      if (processedValue === void 0) {
        tabGuard.current?.removeAttribute("tabindex");
      } else {
        tabGuard.current?.setAttribute("tabindex", processedValue);
      }
    }
  };
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(forwardRef4, () => ({
    forceFocusOutOfContainer(up) {
      tabGuardCtrlRef.current?.forceFocusOutOfContainer(up);
    }
  }));
  const setupCtrl = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
    const topTabGuard = topTabGuardRef.current;
    const bottomTabGuard = bottomTabGuardRef.current;
    if (!topTabGuard && !bottomTabGuard || context.isDestroyed()) {
      tabGuardCtrlRef.current = context.destroyBean(tabGuardCtrlRef.current);
      return;
    }
    if (topTabGuard && bottomTabGuard) {
      const compProxy = {
        setTabIndex
      };
      tabGuardCtrlRef.current = context.createBean(
        new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .TabGuardCtrl */ .Udn({
          comp: compProxy,
          eTopGuard: topTabGuard,
          eBottomGuard: bottomTabGuard,
          eFocusableElement,
          onTabKeyDown,
          forceFocusOutWhenTabGuardsAreEmpty,
          focusInnerElement: (fromBottom) => gridCtrl.focusInnerElement(fromBottom),
          isEmpty
        })
      );
    }
  }, []);
  const setTopRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (e) => {
      topTabGuardRef.current = e;
      setupCtrl();
    },
    [setupCtrl]
  );
  const setBottomRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(
    (e) => {
      bottomTabGuardRef.current = e;
      setupCtrl();
    },
    [setupCtrl]
  );
  const createTabGuard = (side) => {
    const className = side === "top" ? ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .TabGuardClassNames */ .pA9.TAB_GUARD_TOP : ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .TabGuardClassNames */ .pA9.TAB_GUARD_BOTTOM;
    return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
      "div",
      {
        className: `${ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .TabGuardClassNames */ .pA9.TAB_GUARD} ${className}`,
        role: "presentation",
        ref: side === "top" ? setTopRef : setBottomRef
      }
    );
  };
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, createTabGuard("top"), children, createTabGuard("bottom"));
};
var TabGuardComp = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(TabGuardCompRef);
var tabGuardComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(TabGuardComp);

// packages/ag-grid-react/src/reactUi/gridComp.tsx
var GridComp = ({ context }) => {
  const [rtlClass, setRtlClass] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const [layoutClass, setLayoutClass] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const [cursor, setCursor] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [userSelect, setUserSelect] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const [initialised, setInitialised] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const [tabGuardReady, setTabGuardReady] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const gridCtrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eRootWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const tabGuardRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const [eGridBodyParent, setGridBodyParent] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
  const focusInnerElementRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(() => void 0);
  const paginationCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const focusableContainersRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const onTabKeyDown = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => void 0, []);
  reactComment_default(" AG Grid ", eRootWrapperRef);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eRootWrapperRef.current = eRef;
    gridCtrlRef.current = eRef ? context.createBean(new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .GridCtrl */ .s1r()) : context.destroyBean(gridCtrlRef.current);
    if (!eRef || context.isDestroyed()) {
      return;
    }
    const gridCtrl = gridCtrlRef.current;
    focusInnerElementRef.current = gridCtrl.focusInnerElement.bind(gridCtrl);
    const compProxy = {
      destroyGridUi: () => {
      },
      // do nothing, as framework users destroy grid by removing the comp
      setRtlClass,
      forceFocusOutOfContainer: (up) => {
        if (!up && paginationCompRef.current?.isDisplayed()) {
          paginationCompRef.current.forceFocusOutOfContainer(up);
          return;
        }
        tabGuardRef.current?.forceFocusOutOfContainer(up);
      },
      updateLayoutClasses: setLayoutClass,
      getFocusableContainers: () => {
        const comps = [];
        const gridBodyCompEl = eRootWrapperRef.current?.querySelector(".ag-root");
        if (gridBodyCompEl) {
          comps.push({ getGui: () => gridBodyCompEl });
        }
        for (const comp of focusableContainersRef.current) {
          if (comp.isDisplayed()) {
            comps.push(comp);
          }
        }
        return comps;
      },
      setCursor,
      setUserSelect
    };
    gridCtrl.setComp(compProxy, eRef, eRef);
    setInitialised(true);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const gridCtrl = gridCtrlRef.current;
    const eRootWrapper = eRootWrapperRef.current;
    if (!tabGuardReady || !gridCtrl || !eGridBodyParent || !eRootWrapper || context.isDestroyed()) {
      return;
    }
    const beansToDestroy = [];
    const {
      watermarkSelector,
      paginationSelector,
      sideBarSelector,
      statusBarSelector,
      gridHeaderDropZonesSelector
    } = gridCtrl.getOptionalSelectors();
    const additionalEls = [];
    if (gridHeaderDropZonesSelector) {
      const headerDropZonesComp = context.createBean(new gridHeaderDropZonesSelector.component());
      const eGui = headerDropZonesComp.getGui();
      eRootWrapper.insertAdjacentElement("afterbegin", eGui);
      additionalEls.push(eGui);
      beansToDestroy.push(headerDropZonesComp);
    }
    if (sideBarSelector) {
      const sideBarComp = context.createBean(new sideBarSelector.component());
      const eGui = sideBarComp.getGui();
      const bottomTabGuard = eGridBodyParent.querySelector(".ag-tab-guard-bottom");
      if (bottomTabGuard) {
        bottomTabGuard.insertAdjacentElement("beforebegin", eGui);
        additionalEls.push(eGui);
      }
      beansToDestroy.push(sideBarComp);
      focusableContainersRef.current.push(sideBarComp);
    }
    const addComponentToDom = (component) => {
      const comp = context.createBean(new component());
      const eGui = comp.getGui();
      eRootWrapper.insertAdjacentElement("beforeend", eGui);
      additionalEls.push(eGui);
      beansToDestroy.push(comp);
      return comp;
    };
    if (statusBarSelector) {
      addComponentToDom(statusBarSelector.component);
    }
    if (paginationSelector) {
      const paginationComp = addComponentToDom(paginationSelector.component);
      paginationCompRef.current = paginationComp;
      focusableContainersRef.current.push(paginationComp);
    }
    if (watermarkSelector) {
      addComponentToDom(watermarkSelector.component);
    }
    return () => {
      context.destroyBeans(beansToDestroy);
      for (const el of additionalEls) {
        el.remove();
      }
    };
  }, [tabGuardReady, eGridBodyParent, context]);
  const rootWrapperClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList("ag-root-wrapper", rtlClass, layoutClass),
    [rtlClass, layoutClass]
  );
  const rootWrapperBodyClasses = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => classesList("ag-root-wrapper-body", "ag-focus-managed", layoutClass),
    [layoutClass]
  );
  const topStyle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => ({
      userSelect: userSelect != null ? userSelect : "",
      WebkitUserSelect: userSelect != null ? userSelect : "",
      cursor: cursor != null ? cursor : ""
    }),
    [userSelect, cursor]
  );
  const setTabGuardCompRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((ref) => {
    tabGuardRef.current = ref;
    setTabGuardReady(ref !== null);
  }, []);
  const isFocusable = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => !gridCtrlRef.current?.isFocusable(), []);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { ref: setRef2, className: rootWrapperClasses, style: topStyle, role: "presentation" }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: rootWrapperBodyClasses, ref: setGridBodyParent, role: "presentation" }, initialised && eGridBodyParent && !context.isDestroyed() && /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(BeansContext.Provider, { value: context.getBeans() }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    tabGuardComp_default,
    {
      ref: setTabGuardCompRef,
      eFocusableElement: eGridBodyParent,
      onTabKeyDown,
      gridCtrl: gridCtrlRef.current,
      forceFocusOutWhenTabGuardsAreEmpty: true,
      isEmpty: isFocusable
    },
    // we wait for initialised before rending the children, so GridComp has created and registered with it's
    // GridCtrl before we create the child GridBodyComp. Otherwise the GridBodyComp would initialise first,
    // before we have set the the Layout CSS classes, causing the GridBodyComp to render rows to a grid that
    // doesn't have it's height specified, which would result if all the rows getting rendered (and if many rows,
    // hangs the UI)
    /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(gridBodyComp_default, null)
  ))));
};
var gridComp_default = (0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(GridComp);

// packages/ag-grid-react/src/reactUi/renderStatusService.tsx

var RenderStatusService = class extends ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .BeanStub */ .XQb {
  postConstruct() {
    if (this.beans.colAutosize) {
      const queueResizeOperationsForTick = this.queueResizeOperationsForTick.bind(this);
      this.addManagedEventListeners({
        rowExpansionStateChanged: queueResizeOperationsForTick,
        expandOrCollapseAll: queueResizeOperationsForTick,
        // Enable devs to resize after they updated via the API
        cellValueChanged: queueResizeOperationsForTick,
        rowNodeDataChanged: queueResizeOperationsForTick,
        rowDataUpdated: queueResizeOperationsForTick
      });
    }
  }
  queueResizeOperationsForTick() {
    const colAutosize = this.beans.colAutosize;
    colAutosize.shouldQueueResizeOperations = true;
    setTimeout(() => {
      colAutosize.processResizeOperations();
    }, 0);
  }
  areHeaderCellsRendered() {
    return this.beans.ctrlsSvc.getHeaderRowContainerCtrls().every((container) => container.getAllCtrls().every((ctrl) => ctrl.areCellsRendered()));
  }
  areCellsRendered() {
    return this.beans.rowRenderer.getAllRowCtrls().every((row) => row.isRowRendered() && row.getAllCellCtrls().every((cellCtrl) => !!cellCtrl.eGui));
  }
};

// packages/ag-grid-react/src/reactUi/agGridReactUi.tsx
var deprecatedProps = {
  setGridApi: void 0,
  maxComponentCreationTimeMs: void 0,
  children: void 0
};
var reactPropsNotGridOptions = {
  gridOptions: void 0,
  modules: void 0,
  containerStyle: void 0,
  className: void 0,
  passGridApi: void 0,
  componentWrappingElement: void 0,
  ...deprecatedProps
};
var excludeReactCompProps = new Set(Object.keys(reactPropsNotGridOptions));
var deprecatedReactCompProps = new Set(Object.keys(deprecatedProps));
var AgGridReactUi = (props) => {
  const apiRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGui = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const portalManager = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const destroyFuncs = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const whenReadyFuncs = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
  const prevProps = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(props);
  const frameworkOverridesRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const gridIdRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const ready = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
  const [context, setContext] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(void 0);
  const [, setPortalRefresher] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGui.current = eRef;
    if (!eRef) {
      for (const f of destroyFuncs.current) {
        f();
      }
      destroyFuncs.current.length = 0;
      return;
    }
    const modules = props.modules || [];
    if (!portalManager.current) {
      portalManager.current = new PortalManager(
        () => setPortalRefresher((prev) => prev + 1),
        props.componentWrappingElement,
        props.maxComponentCreationTimeMs
      );
      destroyFuncs.current.push(() => {
        portalManager.current?.destroy();
        portalManager.current = null;
      });
    }
    const mergedGridOps = (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._combineAttributesAndGridOptions */ .zsR)(
      props.gridOptions,
      props,
      Object.keys(props).filter((key) => !excludeReactCompProps.has(key))
    );
    const processQueuedUpdates = () => {
      if (ready.current) {
        const getFn = () => frameworkOverridesRef.current?.shouldQueueUpdates() ? void 0 : whenReadyFuncs.current.shift();
        let fn = getFn();
        while (fn) {
          fn();
          fn = getFn();
        }
      }
    };
    const frameworkOverrides = new ReactFrameworkOverrides(processQueuedUpdates);
    frameworkOverridesRef.current = frameworkOverrides;
    const renderStatus = new RenderStatusService();
    const gridParams = {
      providedBeanInstances: {
        frameworkCompWrapper: new ReactFrameworkComponentWrapper(portalManager.current, mergedGridOps),
        renderStatus
      },
      modules,
      frameworkOverrides,
      setThemeOnGridDiv: true
    };
    const createUiCallback = (ctx) => {
      setContext(ctx);
      ctx.createBean(renderStatus);
      destroyFuncs.current.push(() => {
        ctx.destroy();
      });
      ctx.getBean("ctrlsSvc").whenReady(
        {
          addDestroyFunc: (func) => {
            destroyFuncs.current.push(func);
          }
        },
        () => {
          if (ctx.isDestroyed()) {
            return;
          }
          const api = apiRef.current;
          if (api) {
            props.passGridApi?.(api);
          }
        }
      );
    };
    const acceptChangesCallback = (context2) => {
      context2.getBean("ctrlsSvc").whenReady(
        {
          addDestroyFunc: (func) => {
            destroyFuncs.current.push(func);
          }
        },
        () => {
          for (const f of whenReadyFuncs.current) {
            f();
          }
          whenReadyFuncs.current.length = 0;
          ready.current = true;
        }
      );
    };
    const gridCoreCreator = new ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .GridCoreCreator */ .Ug$();
    mergedGridOps.gridId ?? (mergedGridOps.gridId = gridIdRef.current);
    apiRef.current = gridCoreCreator.create(
      eRef,
      mergedGridOps,
      createUiCallback,
      acceptChangesCallback,
      gridParams
    );
    destroyFuncs.current.push(() => {
      apiRef.current = void 0;
    });
    if (apiRef.current) {
      gridIdRef.current = apiRef.current.getGridId();
    }
  }, []);
  const style = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    return {
      height: "100%",
      ...props.containerStyle || {}
    };
  }, [props.containerStyle]);
  const processWhenReady = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((func) => {
    if (ready.current && !frameworkOverridesRef.current?.shouldQueueUpdates()) {
      func();
    } else {
      whenReadyFuncs.current.push(func);
    }
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const changes = extractGridPropertyChanges(prevProps.current, props);
    prevProps.current = props;
    processWhenReady(() => {
      if (apiRef.current) {
        (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._processOnChange */ .Y6t)(changes, apiRef.current);
      }
    });
  }, [props]);
  const renderMode = !react__WEBPACK_IMPORTED_MODULE_0__.useSyncExternalStore || (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getGridOption */ .Fzc)(props, "renderingMode") === "legacy" ? "legacy" : "default";
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style, className: props.className, ref: setRef2 }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(RenderModeContext.Provider, { value: renderMode }, context && !context.isDestroyed() ? /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(gridComp_default, { key: context.instanceId, context }) : null, portalManager.current?.getPortals() ?? null));
};
function extractGridPropertyChanges(prevProps, nextProps) {
  const changes = {};
  for (const propKey of Object.keys(nextProps)) {
    if (excludeReactCompProps.has(propKey)) {
      if (deprecatedReactCompProps.has(propKey)) {
        (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._warn */ .ujB)(274, { prop: propKey });
      }
      continue;
    }
    const propValue = nextProps[propKey];
    if (prevProps[propKey] !== propValue) {
      changes[propKey] = propValue;
    }
  }
  return changes;
}
var ReactFrameworkComponentWrapper = class extends ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .BaseComponentWrapper */ .Cf3 {
  constructor(parent, gridOptions) {
    super();
    this.parent = parent;
    this.gridOptions = gridOptions;
  }
  createWrapper(UserReactComponent, componentType) {
    const gridOptions = this.gridOptions;
    const reactiveCustomComponents = (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getGridOption */ .Fzc)(gridOptions, "reactiveCustomComponents");
    if (reactiveCustomComponents) {
      const getComponentClass = (propertyName) => {
        switch (propertyName) {
          case "filter":
            return (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getGridOption */ .Fzc)(gridOptions, "enableFilterHandlers") ? FilterDisplayComponentWrapper : FilterComponentWrapper;
          case "floatingFilterComponent":
            return (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getGridOption */ .Fzc)(gridOptions, "enableFilterHandlers") ? FloatingFilterDisplayComponentWrapper : FloatingFilterComponentWrapper;
          case "dateComponent":
            return DateComponentWrapper;
          case "dragAndDropImageComponent":
            return DragAndDropImageComponentWrapper;
          case "loadingOverlayComponent":
            return LoadingOverlayComponentWrapper;
          case "noRowsOverlayComponent":
            return NoRowsOverlayComponentWrapper;
          case "statusPanel":
            return StatusPanelComponentWrapper;
          case "toolPanel":
            return ToolPanelComponentWrapper;
          case "menuItem":
            return MenuItemComponentWrapper;
          case "cellRenderer":
            return CellRendererComponentWrapper;
          case "innerHeaderComponent":
            return InnerHeaderComponentWrapper;
        }
      };
      const ComponentClass = getComponentClass(componentType.name);
      if (ComponentClass) {
        return new ComponentClass(UserReactComponent, this.parent, componentType);
      }
    } else {
      switch (componentType.name) {
        case "filter":
        case "floatingFilterComponent":
        case "dateComponent":
        case "dragAndDropImageComponent":
        case "loadingOverlayComponent":
        case "noRowsOverlayComponent":
        case "statusPanel":
        case "toolPanel":
        case "menuItem":
        case "cellRenderer":
          warnReactiveCustomComponents();
          break;
      }
    }
    const suppressFallbackMethods = !componentType.cellRenderer && componentType.name !== "toolPanel";
    return new ReactComponent(UserReactComponent, this.parent, componentType, suppressFallbackMethods);
  }
};
var DetailCellRenderer = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)((props, ref) => {
  const beans = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(BeansContext);
  const { registry, context, gos, rowModel } = beans;
  const [cssClasses, setCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [gridCssClasses, setGridCssClasses] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => new CssClasses());
  const [detailGridOptions, setDetailGridOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const [detailRowData, setDetailRowData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const ctrlRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const eGuiRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const resizeObserverDestroyFunc = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  const parentModules = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(
    () => (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._getGridRegisteredModules */ .Dii)(props.api.getGridId(), detailGridOptions?.rowModelType ?? "clientSide"),
    [props]
  );
  const topClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => cssClasses.toString() + " ag-details-row", [cssClasses]);
  const gridClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => gridCssClasses.toString() + " ag-details-grid", [gridCssClasses]);
  if (ref) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(ref, () => ({
      refresh() {
        return ctrlRef.current?.refresh() ?? false;
      }
    }));
  }
  if (props.template) {
    (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._warn */ .ujB)(230);
  }
  const setRef2 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((eRef) => {
    eGuiRef.current = eRef;
    if (!eRef || context.isDestroyed()) {
      ctrlRef.current = context.destroyBean(ctrlRef.current);
      resizeObserverDestroyFunc.current?.();
      return;
    }
    const compProxy = {
      toggleCss: (name, on) => setCssClasses((prev) => prev.setClass(name, on)),
      toggleDetailGridCss: (name, on) => setGridCssClasses((prev) => prev.setClass(name, on)),
      setDetailGrid: (gridOptions) => setDetailGridOptions(gridOptions),
      setRowData: (rowData) => setDetailRowData(rowData),
      getGui: () => eGuiRef.current
    };
    const ctrl = registry.createDynamicBean("detailCellRendererCtrl", true);
    if (!ctrl) {
      return;
    }
    context.createBean(ctrl);
    ctrl.init(compProxy, props);
    ctrlRef.current = ctrl;
    if (gos.get("detailRowAutoHeight")) {
      const checkRowSizeFunc = () => {
        if (eGuiRef.current == null) {
          return;
        }
        const clientHeight = eGuiRef.current.clientHeight;
        if (clientHeight != null && clientHeight > 0) {
          const updateRowHeightFunc = () => {
            props.node.setRowHeight(clientHeight);
            if ((0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._isClientSideRowModel */ .dbY)(gos, rowModel) || (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._isServerSideRowModel */ .TiQ)(gos, rowModel)) {
              rowModel.onRowHeightChanged();
            }
          };
          setTimeout(updateRowHeightFunc, 0);
        }
      };
      resizeObserverDestroyFunc.current = (0,ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* ._observeResize */ .QSI)(beans, eRef, checkRowSizeFunc);
      checkRowSizeFunc();
    }
  }, []);
  const registerGridApi = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((api) => {
    ctrlRef.current?.registerDetailWithMaster(api);
  }, []);
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: topClassName, ref: setRef2 }, detailGridOptions && /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(
    AgGridReactUi,
    {
      className: gridClassName,
      ...detailGridOptions,
      modules: parentModules,
      rowData: detailRowData,
      passGridApi: registerGridApi
    }
  ));
});
var ReactFrameworkOverrides = class extends ag_grid_community__WEBPACK_IMPORTED_MODULE_1__/* .VanillaFrameworkOverrides */ .pow {
  constructor(processQueuedUpdates) {
    super("react");
    this.processQueuedUpdates = processQueuedUpdates;
    this.queueUpdates = false;
    this.renderingEngine = "react";
    this.frameworkComponents = {
      agGroupCellRenderer: groupCellRenderer_default,
      agGroupRowRenderer: groupCellRenderer_default,
      agDetailCellRenderer: DetailCellRenderer
    };
    this.wrapIncoming = (callback, source) => {
      if (source === "ensureVisible") {
        return runWithoutFlushSync(callback);
      }
      return callback();
    };
  }
  frameworkComponent(name) {
    return this.frameworkComponents[name];
  }
  isFrameworkComponent(comp) {
    if (!comp) {
      return false;
    }
    const prototype = comp.prototype;
    const isJsComp = prototype && "getGui" in prototype;
    return !isJsComp;
  }
  getLockOnRefresh() {
    this.queueUpdates = true;
  }
  releaseLockOnRefresh() {
    this.queueUpdates = false;
    this.processQueuedUpdates();
  }
  shouldQueueUpdates() {
    return this.queueUpdates;
  }
  runWhenReadyAsync() {
    return isReact19();
  }
};

// packages/ag-grid-react/src/agGridReact.tsx
var AgGridReact = class extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
  constructor() {
    super(...arguments);
    this.apiListeners = [];
    this.setGridApi = (api) => {
      this.api = api;
      for (const listener of this.apiListeners) {
        listener(api);
      }
    };
  }
  registerApiListener(listener) {
    this.apiListeners.push(listener);
  }
  componentWillUnmount() {
    this.apiListeners.length = 0;
  }
  render() {
    return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(AgGridReactUi, { ...this.props, passGridApi: this.setGridApi });
  }
};

// packages/ag-grid-react/src/shared/customComp/interfaces.ts

function useGridCustomComponent(methods) {
  const { setMethods } = useContext16(CustomContext);
  setMethods(methods);
}
function useGridCellEditor(callbacks) {
  useGridCustomComponent(callbacks);
}
function useGridDate(callbacks) {
  return useGridCustomComponent(callbacks);
}
function useGridFilter(callbacks) {
  return useGridCustomComponent(callbacks);
}
function useGridFilterDisplay(callbacks) {
  return useGridCustomComponent(callbacks);
}
function useGridFloatingFilter(callbacks) {
  useGridCustomComponent(callbacks);
}
function useGridMenuItem(callbacks) {
  useGridCustomComponent(callbacks);
}



/***/ }),

/***/ 73738:
/***/ ((module) => {

function _typeof(o) {
  "@babel/helpers - typeof";

  return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 77736:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(73738)["default"]);
var toPrimitive = __webpack_require__(89045);
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 89045:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(73738)["default"]);
function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVuZG9yLWNvbW1vbi1jZGQ2MGM2Mi41NzI4NGJhMjhmNjNjODU5MDI0ZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsU0FBUyxhQUFPO0FBQ2hCOztBQUVBLFNBQVMsYUFBTztBQUNoQjtBQUNBLElBQUk7QUFDSjtBQUNBLEdBQUcsRUFBRSxhQUFPO0FBQ1o7OztBQ1JrQztBQUNsQyxTQUFTLHVCQUFXO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FDVmtDO0FBQ1M7QUFDM0MsU0FBUywyQkFBYTtBQUN0QjtBQUNBO0FBQ0E7OztBQ0wrQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7OztBQ1JpRDtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0Isc0JBQXNCO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7Ozs7Ozs7O0FDckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLG9DQUFvQyx5QkFBeUIsU0FBUyx5QkFBeUIsa0I7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekIvRjtBQUNnRztBQUNqQjtBQUNPO0FBQ3RGLDRDQUE0QyxvRUFBdzdPO0FBQ3ArTyw4QkFBOEIsc0VBQTJCLENBQUMsK0VBQXFDO0FBQy9GLHlDQUF5Qyx5RUFBK0I7QUFDeEU7QUFDQTtBQUNBO0FBQ0EsYUFBYSxtQ0FBbUM7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sNEhBQTRILFlBQVksY0FBYyxjQUFjLGFBQWEsTUFBTSxPQUFPLFlBQVksYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsTUFBTSxPQUFPLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLE9BQU8sS0FBSyxZQUFZLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxNQUFNLE9BQU8sYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsT0FBTyxLQUFLLEtBQUssWUFBWSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsTUFBTSxPQUFPLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLE1BQU0sS0FBSyw0QkFBNEIsYUFBYSxhQUFhLE1BQU0sT0FBTyxZQUFZLE1BQU0seUJBQXlCLGFBQWEsYUFBYSxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLE9BQU8sWUFBWSxhQUFhLFdBQVcsTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksYUFBYSxNQUFNLE9BQU8sWUFBWSxNQUFNLGdCQUFnQixZQUFZLGFBQWEsTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxLQUFLLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxVQUFVLFlBQVksTUFBTSxLQUFLLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxPQUFPLFlBQVksYUFBYSxhQUFhLGFBQWEsTUFBTSxPQUFPLFVBQVUsWUFBWSxhQUFhLGFBQWEsTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksTUFBTSxPQUFPLFlBQVksYUFBYSxNQUFNLE9BQU8sWUFBWSxNQUFNLE9BQU8sWUFBWSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxhQUFhLE1BQU0sT0FBTyxZQUFZLGFBQWEsTUFBTSxPQUFPLFlBQVksYUFBYSxhQUFhLE1BQU0sT0FBTyxZQUFZLGFBQWEsYUFBYSxNQUFNLE9BQU8sWUFBWSxNQUFNLE9BQU8sWUFBWSxhQUFhLE1BQU0sT0FBTyxVQUFVLFlBQVksYUFBYSxhQUFhLGFBQWEsYUFBYSxNQUFNLE9BQU8sWUFBWSxXQUFXLEtBQUssT0FBTyxZQUFZLE1BQU0sT0FBTyxZQUFZLE1BQU0sT0FBTyxZQUFZLE1BQU0sVUFBVSxZQUFZLE1BQU0sT0FBTyxVQUFVLEtBQUssT0FBTyxVQUFVLEtBQUssVUFBVSxVQUFVLEtBQUssdURBQXVELGFBQWEsTUFBTSxtQkFBbUIsVUFBVSxNQUFNLE9BQU8sWUFBWSxNQUFNLE9BQU8sVUFBVSxLQUFLLEtBQUssWUFBWSxhQUFhLE9BQU8sS0FBSyxZQUFZLGFBQWEsT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFlBQVksT0FBTyxPQUFPLFVBQVUsWUFBWSxNQUFNLEtBQUssWUFBWSxhQUFhLGFBQWEsT0FBTyxLQUFLLFlBQVksYUFBYSxhQUFhLE9BQU8sT0FBTyxZQUFZLGFBQWEsTUFBTSxPQUFPLFlBQVksTUFBTSxnQkFBZ0IsWUFBWSxNQUFNLE9BQU8sWUFBWSxNQUFNLE9BQU8sWUFBWSxhQUFhLE1BQU0sT0FBTyxZQUFZLE1BQU0sT0FBTyxZQUFZLE1BQU0sVUFBVSxZQUFZLE1BQU0sZ0JBQWdCLFlBQVksc0NBQXNDLGtDQUFrQyw2QkFBNkIsY0FBYyx5NE9BQXk0Tyx3QkFBd0IsdUJBQXVCLEdBQUcseUVBQXlFLHNDQUFzQyxnRUFBZ0Usa0RBQWtELHFEQUFxRCwyREFBMkQsbUVBQW1FLHNFQUFzRSxzRUFBc0Usc0VBQXNFLHdHQUF3RyxnQ0FBZ0MsbUNBQW1DLCtCQUErQix5Q0FBeUMsMENBQTBDLDJDQUEyQywyQ0FBMkMsaURBQWlELDBDQUEwQyxnQ0FBZ0Msd0NBQXdDLGtEQUFrRCxvREFBb0Qsb0RBQW9ELG1EQUFtRCxzREFBc0QsOENBQThDLDZEQUE2RCxxREFBcUQsK0RBQStELCtEQUErRCxxRUFBcUUsZ0VBQWdFLG9EQUFvRCw2REFBNkQsbUZBQW1GLDhFQUE4RSxtRUFBbUUsa0VBQWtFLHFFQUFxRSxtRkFBbUYsMERBQTBELHVEQUF1RCwrREFBK0Qsb0VBQW9FLDRCQUE0Qiw0QkFBNEIsbUNBQW1DLDREQUE0RCxvREFBb0QsZ0RBQWdELGlEQUFpRCx3QkFBd0IseUJBQXlCLG1EQUFtRCxzREFBc0QseURBQXlELHdEQUF3RCxxREFBcUQsa0dBQWtHLGdFQUFnRSw0REFBNEQsMEVBQTBFLDRFQUE0RSxrRUFBa0Usb0NBQW9DLG1DQUFtQyxxSkFBcUoseUJBQXlCLHdDQUF3QyxxRUFBcUUsMkNBQTJDLHVEQUF1RCw4QkFBOEIsNkRBQTZELDZDQUE2QyxxQ0FBcUMsR0FBRywyQkFBMkIsbUNBQW1DLGdDQUFnQywrQkFBK0IsdURBQXVELGdFQUFnRSwwQ0FBMEMsMkNBQTJDLDJDQUEyQyxpREFBaUQsMENBQTBDLGtEQUFrRCx3SEFBd0gsK0tBQStLLDJDQUEyQyw2REFBNkQsMERBQTBELCtEQUErRCxvRUFBb0Usa0RBQWtELG9EQUFvRCxvREFBb0QsbURBQW1ELHNEQUFzRCw2REFBNkQscUVBQXFFLHFFQUFxRSw2Q0FBNkMsdUJBQXVCLEdBQUcseUNBQXlDLGdDQUFnQyxxQ0FBcUMsa0NBQWtDLGlDQUFpQyx5REFBeUQsa0VBQWtFLDRDQUE0Qyw2Q0FBNkMsNkNBQTZDLG1EQUFtRCw0Q0FBNEMsb0RBQW9ELDBIQUEwSCxtTEFBbUwsNkNBQTZDLCtEQUErRCw0REFBNEQsaUVBQWlFLHNFQUFzRSxvREFBb0Qsc0RBQXNELHNEQUFzRCxxREFBcUQsd0RBQXdELCtEQUErRCx1RUFBdUUsdUVBQXVFLCtDQUErQyx5QkFBeUIsS0FBSyxHQUFHLGtuQ0FBa25DLHFCQUFxQiw2Q0FBNkMsR0FBRyxpR0FBaUcsK0NBQStDLEdBQUcsc21DQUFzbUMsOENBQThDLDJDQUEyQyxHQUFHLDB2Q0FBMHZDLHNDQUFzQyxHQUFHLDR2Q0FBNHZDLHVDQUF1QyxHQUFHLG1HQUFtRyw2Q0FBNkMsMkJBQTJCLG1CQUFtQixHQUFHLDRIQUE0SCx5Q0FBeUMsR0FBRyxvR0FBb0csK0RBQStELEdBQUcsNk1BQTZNLCtEQUErRCxHQUFHLHlIQUF5SCwrREFBK0QscUJBQXFCLEdBQUcseUhBQXlILDREQUE0RCxHQUFHLHN4QkFBc3hCLCtEQUErRCx1RUFBdUUsR0FBRyxvSkFBb0osaURBQWlELEdBQUcsMEpBQTBKLDZFQUE2RSxHQUFHLDBLQUEwSyxzQ0FBc0MsR0FBRyw0S0FBNEsscUNBQXFDLEdBQUcsZ2JBQWdiLG9DQUFvQyxHQUFHLHlkQUF5ZCw0RUFBNEUsR0FBRywyZEFBMmQsNkVBQTZFLEdBQUcsaUxBQWlMLDRCQUE0Qiw4Q0FBOEMsc0NBQXNDLGlEQUFpRCxHQUFHLDZNQUE2TSxtQkFBbUIsc0JBQXNCLHFCQUFxQixxQkFBcUIsR0FBRyw2TUFBNk0sc0JBQXNCLEdBQUcsK05BQStOLHFCQUFxQixHQUFHLGdIQUFnSCwrQ0FBK0MscUJBQXFCLEdBQUcsNEhBQTRILHlDQUF5QyxHQUFHLHFJQUFxSSx5QkFBeUIscUJBQXFCLDZCQUE2QiwyQ0FBMkMsc0JBQXNCLGdEQUFnRCx5Q0FBeUMsaURBQWlELHFCQUFxQiwrREFBK0QsR0FBRyx1SkFBdUosZ0RBQWdELGdEQUFnRCxHQUFHLDBKQUEwSixnREFBZ0Qsb0RBQW9ELHNDQUFzQyxHQUFHLGdLQUFnSywrQ0FBK0MsZ0VBQWdFLHdEQUF3RCxHQUFHLG9KQUFvSixxQkFBcUIsR0FBRyxrTEFBa0wsMkNBQTJDLHdCQUF3QixHQUFHLDhMQUE4TCxrQkFBa0Isd0JBQXdCLHVCQUF1Qix5Q0FBeUMsMENBQTBDLDJDQUEyQyxHQUFHLG1LQUFtSyxzQ0FBc0Msa0JBQWtCLEdBQUcseUtBQXlLLHNCQUFzQixHQUFHLHNIQUFzSCx3QkFBd0IsR0FBRyw2SkFBNkoscUJBQXFCLEdBQUcsbVRBQW1ULHFCQUFxQixHQUFHLDZKQUE2SixpQkFBaUIsR0FBRywrS0FBK0ssa0JBQWtCLEdBQUcsOGFBQThhLGtCQUFrQixHQUFHLDJ3RkFBMndGLHlDQUF5QyxHQUFHLG8vQkFBby9CLG1CQUFtQixHQUFHLCtLQUErSyx5Q0FBeUMsR0FBRyxrT0FBa08sa0JBQWtCLEdBQUcsZ0xBQWdMLCtDQUErQyxzQ0FBc0MsR0FBRyxrTEFBa0wsZ0RBQWdELHFDQUFxQyxHQUFHLGdOQUFnTixzQ0FBc0MsR0FBRyxnTkFBZ04sdUNBQXVDLEdBQUcsMExBQTBMLGlCQUFpQiwrREFBK0QsR0FBRyw4TUFBOE0sNEJBQTRCLDhDQUE4QyxpREFBaUQsR0FBRyxnTkFBZ04sNkJBQTZCLCtDQUErQyxrREFBa0QsR0FBRyx1SUFBdUksaURBQWlELG9EQUFvRCxHQUFHLHNLQUFzSyx5Q0FBeUMsR0FBRyxtMEJBQW0wQixzQkFBc0IsR0FBRyxvTUFBb00sb0RBQW9ELEdBQUcsa0xBQWtMLGlDQUFpQyxxQkFBcUIsR0FBRyxnS0FBZ0ssb0RBQW9ELEdBQUcsc0tBQXNLLHlDQUF5QyxHQUFHLGdXQUFnVyxvREFBb0QsR0FBRyxndUJBQWd1QiwrQ0FBK0MsR0FBRyxxQkFBcUI7QUFDM2ozQztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7OztBQzFuQnZDLG9CQUFvQixtQkFBTyxDQUFDLEtBQW9CO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLGtDQUFrQyx5QkFBeUIsU0FBUyx5QkFBeUIsa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUjdGLE1BQXFGO0FBQ3JGLE1BQTJFO0FBQzNFLE1BQWtGO0FBQ2xGLE1BQXFHO0FBQ3JHLE1BQThGO0FBQzlGLE1BQThGO0FBQzlGLE1BQTRIO0FBQzVIO0FBQ0E7O0FBRUE7O0FBRUEsNEJBQTRCLHdGQUFtQjtBQUMvQyx3QkFBd0IscUdBQWE7O0FBRXJDLHVCQUF1QiwwRkFBYTtBQUNwQztBQUNBLGlCQUFpQixrRkFBTTtBQUN2Qiw2QkFBNkIseUZBQWtCOztBQUUvQyxhQUFhLDZGQUFHLENBQUMsK0dBQU87Ozs7QUFJc0U7QUFDOUYsT0FBTyxpRUFBZSwrR0FBTyxJQUFJLCtHQUFPLFVBQVUsK0dBQU8sbUJBQW1CLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCN0UsTUFBcUY7QUFDckYsTUFBMkU7QUFDM0UsTUFBa0Y7QUFDbEYsTUFBcUc7QUFDckcsTUFBOEY7QUFDOUYsTUFBOEY7QUFDOUYsTUFBb0k7QUFDcEk7QUFDQTs7QUFFQTs7QUFFQSw0QkFBNEIsd0ZBQW1CO0FBQy9DLHdCQUF3QixxR0FBYTs7QUFFckMsdUJBQXVCLDBGQUFhO0FBQ3BDO0FBQ0EsaUJBQWlCLGtGQUFNO0FBQ3ZCLDZCQUE2Qix5RkFBa0I7O0FBRS9DLGFBQWEsNkZBQUcsQ0FBQyx1SEFBTzs7OztBQUk4RTtBQUN0RyxPQUFPLGlFQUFlLHVIQUFPLElBQUksdUhBQU8sVUFBVSx1SEFBTyxtQkFBbUIsRUFBQzs7Ozs7Ozs7Ozs7Ozs7OztBQzFCN0U7QUFDMkM7O0FBRTNDO0FBVWU7QUFhWTs7QUFFM0I7QUFVZTtBQUMrQjs7QUFFOUM7QUFDMEI7QUFDMUIsbUJBQW1CLGdEQUFtQixHQUFHO0FBQ3pDLHdCQUF3QixnREFBbUI7O0FBRTNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQzJCO0FBQ007QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiwwQ0FBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnREFBa0I7QUFDdEIsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGtEQUFzQjtBQUMxQixJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNLHVEQUEyQjtBQUNqQyxXQUFXLHVEQUEyQjtBQUN0QyxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixpQkFBaUI7QUFDbkM7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGlCQUFpQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsaUJBQWlCO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSx3QkFBd0IsaURBQVU7QUFDbEMsVUFBVSxvQkFBb0IsRUFBRSxpREFBVTtBQUMxQyxlQUFlLDZDQUFNO0FBQ3JCLG9CQUFvQiw2Q0FBTTtBQUMxQix1QkFBdUIsNkNBQU07QUFDN0IsdUJBQXVCLDZDQUFNO0FBQzdCLHlCQUF5Qiw2Q0FBTTtBQUMvQixrQkFBa0IsNkNBQU07QUFDeEIsa0RBQWtELCtDQUFRO0FBQzFELHNDQUFzQywrQ0FBUTtBQUM5Qyw0QkFBNEIsK0NBQVE7QUFDcEMsc0NBQXNDLCtDQUFRO0FBQzlDLHNEQUFzRCwrQ0FBUTtBQUM5RCwwREFBMEQsK0NBQVE7QUFDbEUsc0RBQXNELCtDQUFRO0FBQzlELEVBQUUsMERBQW1CO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHNEQUFlO0FBQ2pCO0FBQ0EsR0FBRztBQUNILGtCQUFrQixrREFBVztBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxvQkFBb0IsOENBQU8sMEJBQTBCLHNCQUFzQjtBQUMzRSw0QkFBNEIsOENBQU8sNEJBQTRCLDhCQUE4QjtBQUM3Riw4QkFBOEIsOENBQU87QUFDckMsaUNBQWlDLGdDQUFnQztBQUNqRTtBQUNBO0FBQ0EsNEJBQTRCLDhDQUFPLDRCQUE0Qiw4QkFBOEI7QUFDN0Y7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLHVFQUFTO0FBQ2hDLHlCQUF5QixnREFBb0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsMkNBQTJDO0FBQ3RFLEtBQUs7QUFDTCxvQkFBb0IsZ0RBQW9CLFdBQVcsaURBQWlEO0FBQ3BHLG9CQUFvQixnREFBb0IsV0FBVyxxREFBcUQ7QUFDeEcsb0JBQW9CLGdEQUFvQixXQUFXLGlEQUFpRDtBQUNwRyxvQkFBb0IsZ0RBQW9CLFdBQVcsNkNBQTZDLDREQUE0RCxnREFBb0IsZUFBZSw0QkFBNEI7QUFDM04sb0JBQW9CLGdEQUFvQixXQUFXLG1DQUFtQztBQUN0RjtBQUNBLENBQUM7QUFDRDs7QUFFQTtBQUM0RDs7QUFFNUQ7QUFDdUU7O0FBRXZFO0FBQ3NDO0FBQ3RDLG9CQUFvQixvREFBYTtBQUNqQztBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsVUFBVSxvRUFBb0U7QUFDOUUsV0FBVyxlQUFlLGNBQWMsK0NBQVM7QUFDakQsRUFBRSxnREFBUztBQUNYO0FBQ0EsR0FBRztBQUNILHlCQUF5QixnREFBb0IsMkJBQTJCLFNBQVMsY0FBYyxrQkFBa0IsZ0RBQW9CLHlCQUF5QixlQUFlO0FBQzdLO0FBQ0EsZ0NBQWdDLDJDQUFJOztBQUVwQztBQUNzQztBQUNHO0FBQ0s7O0FBRTlDO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixVQUFVO0FBQ2xDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlEQUF5RCxtRUFBUyxzQkFBc0IsbUVBQVM7QUFDakc7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVFQUF1RTtBQUN2RSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVFQUF1RTtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxtRUFBUztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtFQUFrRSwwQkFBMEI7QUFDNUYsa0JBQWtCLHVEQUFZO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxvREFBYTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLEtBQUs7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixLQUFLO0FBQ2hDO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsbUVBQVU7QUFDN0M7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUIsbUVBQVU7QUFDL0I7QUFDQTtBQUNBLGFBQWE7QUFDYixXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZSxtRUFBVTtBQUN6QjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVkscUJBQXFCO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUM0RDtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG1FQUFVO0FBQ2pEO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxtRUFBVTtBQUNsRDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQzREO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QyxtRUFBVTtBQUNqRDtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQzREO0FBQzVEO0FBQ0E7QUFDQSxpQ0FBaUMsbUVBQVU7QUFDM0M7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ21FO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLG1FQUFLO0FBQ1A7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ3lLO0FBQzVIOztBQUU3QztBQUM0SztBQVNqSjs7QUFFM0I7QUFDc0s7QUFDbkg7O0FBRW5EO0FBQ2dKO0FBQ3JGOztBQUUzRDtBQUNxSztBQUN2Rzs7QUFFOUQ7QUFDbU87QUFDcEk7QUFDL0Ysd0JBQXdCLE1BQU07QUFDOUI7QUFDQSxVQUFVLFVBQVUsRUFBRSxpREFBVztBQUNqQyxnREFBZ0QsK0NBQVM7QUFDekQsc0NBQXNDLCtDQUFTO0FBQy9DLG1CQUFtQiw2Q0FBTztBQUMxQixlQUFlLDZDQUFPO0FBQ3RCLGtCQUFrQiw2Q0FBTztBQUN6Qiw2QkFBNkIsNkNBQU87QUFDcEMsc0JBQXNCLDZDQUFPO0FBQzdCLHFCQUFxQiw2Q0FBTztBQUM1QjtBQUNBLDZCQUE2Qix5RUFBZTtBQUM1QztBQUNBLGtCQUFrQixrREFBWTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLG9FQUFVO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQiwwRUFBWSx1QkFBdUIsNkVBQWU7QUFDbkU7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSxzREFBZ0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0EsRUFBRSxnREFBVTtBQUNaO0FBQ0EsR0FBRztBQUNILDRCQUE0Qiw4Q0FBUTtBQUNwQztBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSx5QkFBeUIsZ0RBQW9CLFVBQVUsb0ZBQW9GLGtCQUFrQixnREFBb0IsVUFBVSx3RUFBd0UsbUJBQW1CLGdEQUFvQixVQUFVLHlGQUF5RixzREFBc0QsZ0RBQW9CLGtCQUFrQiwyQkFBMkIsb0JBQW9CLGdEQUFvQixrQkFBa0IsNkNBQTZDO0FBQzNtQjtBQUNBLDZCQUE2QiwyQ0FBSzs7QUFFbEM7QUFDbU87QUFDNUk7O0FBRXZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4QkFBOEIsTUFBTTtBQUNwQyxVQUFVLGVBQWUsRUFBRSxpREFBVztBQUN0QyxzQ0FBc0MsK0NBQVM7QUFDL0Msc0NBQXNDLCtDQUFTO0FBQy9DO0FBQ0E7QUFDQSw4Q0FBOEMsK0NBQVM7QUFDdkQsZ0VBQWdFLCtDQUFTO0FBQ3pFO0FBQ0E7QUFDQSxnRUFBZ0UsK0NBQVM7QUFDekUsZ0RBQWdELCtDQUFTO0FBQ3pELDJCQUEyQiwrQ0FBUztBQUNwQyxtQkFBbUIsNkNBQU87QUFDMUIsZUFBZSw2Q0FBTztBQUN0Qiw4QkFBOEIsNkNBQU87QUFDckMseUJBQXlCLDZDQUFPO0FBQ2hDLGdDQUFnQyw2Q0FBTztBQUN2QywwQkFBMEIsNkNBQU87QUFDakMsMEJBQTBCLDZDQUFPO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixrREFBWTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLG9FQUFXO0FBQ3pELGtDQUFrQyxtRUFBVTtBQUM1QztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsc0RBQWdCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw4Q0FBUTtBQUM1Qix3QkFBd0IsOENBQVE7QUFDaEMsaUNBQWlDLDhDQUFRO0FBQ3pDLDRCQUE0Qiw4Q0FBUTtBQUNwQztBQUNBO0FBQ0EsR0FBRztBQUNILG1DQUFtQyw4Q0FBUTtBQUMzQywrQkFBK0IsOENBQVE7QUFDdkMsZ0VBQWdFLCtDQUFTO0FBQ3pFLEVBQUUsZ0RBQVU7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixnREFBb0IsVUFBVSw4REFBOEQsa0JBQWtCLGdEQUFvQixVQUFVLDBFQUEwRSxvRkFBb0YsZ0RBQW9CO0FBQ3ZWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsb0JBQW9CLGdEQUFvQixrQkFBa0Isd0JBQXdCO0FBQ2xGLHNCQUFzQixnREFBb0Isa0JBQWtCO0FBQzVELElBQUksZUFBZSwyQkFBMkIsZ0RBQW9CO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxvQkFBb0IsZ0RBQW9CO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DLDJDQUFLOztBQUV4QztBQUNtTztBQUNySztBQUM5RCw2QkFBNkIsTUFBTTtBQUNuQyxVQUFVLFVBQVUsRUFBRSxpREFBVztBQUNqQyxzQ0FBc0MsK0NBQVM7QUFDL0Msc0NBQXNDLCtDQUFTO0FBQy9DLHdEQUF3RCwrQ0FBUztBQUNqRSx3REFBd0QsK0NBQVM7QUFDakUsMENBQTBDLCtDQUFTO0FBQ25ELGdEQUFnRCwrQ0FBUztBQUN6RCxtQkFBbUIsNkNBQU87QUFDMUIsZUFBZSw2Q0FBTztBQUN0QixrQkFBa0IsNkNBQU87QUFDekIsNkJBQTZCLDZDQUFPO0FBQ3BDLHNCQUFzQiw2Q0FBTztBQUM3QixrQkFBa0Isa0RBQVk7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QyxvRUFBVztBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtEQUErRCxNQUFNO0FBQ3JFLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSxzREFBZ0I7QUFDbEIsRUFBRSxnREFBVTtBQUNaO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCw0QkFBNEIsOENBQVE7QUFDcEM7QUFDQTtBQUNBLEdBQUc7QUFDSCxvQkFBb0IsOENBQVE7QUFDNUIsNkJBQTZCLDhDQUFRO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsZ0RBQW9CLFVBQVUsaUdBQWlHLGtCQUFrQixnREFBb0IsVUFBVSx5RkFBeUYsc0RBQXNELGdEQUFvQixrQkFBa0IsMkJBQTJCLG9CQUFvQixnREFBb0Isa0JBQWtCLDZDQUE2QywyQkFBMkIsZ0RBQW9CLFVBQVUsaUZBQWlGO0FBQ3pvQjtBQUNBLGtDQUFrQywyQ0FBSzs7QUFFdkM7QUFDQSx1QkFBdUIsTUFBTTtBQUM3QixVQUFVLGVBQWUsRUFBRSxpREFBVztBQUN0QyxVQUFVLHVCQUF1QixFQUFFLDhDQUFRO0FBQzNDLG1CQUFtQiw4Q0FBUTtBQUMzQiwwQ0FBMEMsK0NBQVM7QUFDbkQ7QUFDQSw4QkFBOEIsK0NBQVM7QUFDdkMsd0JBQXdCLCtDQUFTO0FBQ2pDLHVCQUF1Qiw2Q0FBTztBQUM5QixvQ0FBb0MsK0NBQVM7QUFDN0MsbUJBQW1CLDZDQUFPO0FBQzFCLGVBQWUsNkNBQU87QUFDdEIsa0JBQWtCLGtEQUFZO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsb0VBQVc7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxnQkFBZ0IsOENBQVE7QUFDeEI7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3QkFBd0Isa0RBQVk7QUFDcEM7QUFDQTtBQUNBLCtCQUErQixnREFBb0IsZ0NBQWdDLDBDQUEwQztBQUM3SDtBQUNBLCtCQUErQixnREFBb0IsaUNBQWlDLDBDQUEwQztBQUM5SDtBQUNBLCtCQUErQixnREFBb0IsMkJBQTJCLDBDQUEwQztBQUN4SDtBQUNBLEdBQUc7QUFDSCx5QkFBeUIsZ0RBQW9CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLDJDQUFLOztBQUVqQztBQUNBLGdDQUFnQyxRQUFRO0FBQ3hDLG9DQUFvQywrQ0FBUztBQUM3Qyw4Q0FBOEMsK0NBQVM7QUFDdkQsVUFBVSxVQUFVLEVBQUUsaURBQVc7QUFDakMsZUFBZSw2Q0FBTztBQUN0QiwyQkFBMkIsNkNBQU87QUFDbEMsMkJBQTJCLDZDQUFPO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixrREFBWTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELGdGQUFzQjtBQUM1RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsMkVBQTJFLGdEQUFvQiwwQkFBMEIsNEJBQTRCO0FBQ3JKLHNDQUFzQyxnREFBb0IsVUFBVSw0R0FBNEcsbURBQW1ELGdEQUFvQixVQUFVLDZHQUE2Ryw4Q0FBOEMsZ0RBQW9CLFVBQVUsNEZBQTRGLGtCQUFrQixnREFBb0IsVUFBVSwrRUFBK0U7QUFDcnBCO0FBQ0EscUNBQXFDLDJDQUFLOztBQUUxQztBQUNBO0FBQ0Esc0NBQXNDLCtDQUFTO0FBQy9DLDhCQUE4QiwrQ0FBUztBQUN2QyxVQUFVLFVBQVUsRUFBRSxpREFBVztBQUNqQyxlQUFlLDZDQUFPO0FBQ3RCLHNCQUFzQiw2Q0FBTztBQUM3QixrQkFBa0Isa0RBQVk7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCx3RUFBYztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILG9CQUFvQiw4Q0FBUTtBQUM1QjtBQUNBO0FBQ0EsR0FBRztBQUNILGdCQUFnQiw4Q0FBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHlCQUF5QixnREFBcUIsVUFBVSxzREFBc0Qsa0JBQWtCLGdEQUFxQixtQ0FBbUMsZ0JBQWdCLG1CQUFtQixnREFBcUIsbUNBQW1DLGNBQWMsbUJBQW1CLGdEQUFxQixtQ0FBbUMsaUJBQWlCO0FBQzdYO0FBQ0EsNkJBQTZCLDJDQUFLOztBQUVsQztBQUNnRDtBQUNoRDtBQUNBLEVBQUUsZ0RBQVU7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRUE7QUFDNEs7QUFPako7O0FBRTNCO0FBQ3lPO0FBQ3RJOztBQUVuRztBQUN3TjtBQUNsRzs7QUFFdEg7QUFDNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsbUVBQVU7QUFDekM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQzRCOztBQUU1QjtBQUM4SDtBQUNwRTtBQUNEOztBQUV6RDtBQUMwRjtBQUMxRjtBQUNBLG1CQUFtQiw2Q0FBTztBQUMxQixvQkFBb0IsNkNBQU87QUFDM0IsdUJBQXVCLDZDQUFPO0FBQzlCLG1CQUFtQiw2Q0FBTztBQUMxQixxQkFBcUIsK0NBQVM7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsRUFBRSxnREFBVTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBLHNEQUFzRCwrQ0FBVTtBQUNoRSxnQkFBZ0IsaURBQVc7QUFDM0IsVUFBVSxrQ0FBa0M7QUFDNUMsVUFBVSxxQ0FBcUM7QUFDL0M7QUFDQSxZQUFZLGNBQWM7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxrQkFBa0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSxzREFBZ0I7QUFDbEI7QUFDQSw0RUFBNEUsa0ZBQW9CO0FBQ2hHLDRCQUE0QixxQkFBcUI7QUFDakQ7QUFDQTtBQUNBLEdBQUc7QUFDSCxzREFBc0QsdURBQWE7QUFDbkU7QUFDQSw4QkFBOEIsMkNBQUs7O0FBRW5DO0FBQ0E7QUFDQSxVQUFVLFlBQVk7QUFDdEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLGdEQUFxQjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLGtDQUFrQyxnREFBcUIsb0JBQW9CLFVBQVUsb0JBQW9CLGdEQUFxQixvQkFBb0IsK0NBQStDO0FBQ2pNO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkZBQTZGLGdEQUFxQixvQkFBb0IsaURBQWlEO0FBQ3ZMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEhBQTRILGdEQUFxQjtBQUNqSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCxnREFBcUIsNEJBQTRCLHFFQUFxRTtBQUM1Szs7QUFFQTtBQUN3RztBQUN4RztBQUNBLFVBQVUsVUFBVSxFQUFFLGlEQUFXO0FBQ2pDLDhCQUE4QixrREFBWTtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLGdEQUFVO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsR0FBRztBQUNILEVBQUUsZ0RBQVU7QUFDWjtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ3dFO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCw0QkFBNEIsNkNBQU87QUFDbkMsd0JBQXdCLDhDQUFRO0FBQ2hDLFlBQVksY0FBYztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTixHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLGdEQUFxQixzQkFBc0IscUNBQXFDO0FBQzNHO0FBQ0EseUJBQXlCLGdEQUFxQixDQUFDLDJDQUFnQjtBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELGdCQUFnQixpREFBWTtBQUM1QixVQUFVLFVBQVU7QUFDcEI7QUFDQSxjQUFjLGdCQUFnQjtBQUM5QjtBQUNBLElBQUk7QUFDSixtQkFBbUIsNkNBQVE7QUFDM0IsNENBQTRDLCtDQUFVO0FBQ3RELGlEQUFpRDtBQUNqRDtBQUNBLHdDQUF3QywrQ0FBVTtBQUNsRCxvQ0FBb0MsK0NBQVU7QUFDOUMsc0NBQXNDLCtDQUFVO0FBQ2hELGtEQUFrRCwrQ0FBVTtBQUM1RCw4Q0FBOEMsK0NBQVU7QUFDeEQsa0RBQWtELCtDQUFVO0FBQzVELDBDQUEwQywrQ0FBVTtBQUNwRCx1QkFBdUIsOENBQVE7QUFDL0IsdUJBQXVCLDhDQUFRO0FBQy9CLGVBQWUsNkNBQVE7QUFDdkIsbUJBQW1CLDZDQUFRO0FBQzNCLDBCQUEwQiw2Q0FBUTtBQUNsQyw0QkFBNEIsNkNBQVE7QUFDcEMsd0JBQXdCLDZDQUFRO0FBQ2hDLHVCQUF1Qiw2Q0FBUTtBQUMvQixrQ0FBa0MsNkNBQVE7QUFDMUMseUJBQXlCLDZDQUFRO0FBQ2pDLHFCQUFxQiw2Q0FBUTtBQUM3QixrREFBa0QsK0NBQVU7QUFDNUQsMEJBQTBCLGtEQUFZO0FBQ3RDO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLHlCQUF5Qiw4Q0FBUTtBQUNqQztBQUNBLEdBQUc7QUFDSCwyQkFBMkIsa0RBQVk7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHFCQUFxQiw2Q0FBUTtBQUM3QjtBQUNBLDZCQUE2Qix5RUFBZ0I7QUFDN0M7QUFDQTtBQUNBLDRCQUE0Qiw2Q0FBUTtBQUNwQyxFQUFFLHNEQUFnQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHNEQUFnQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsR0FBRztBQUNILDRCQUE0QixrREFBWTtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLCtFQUFpQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsZUFBZSxrREFBWTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsb0VBQVc7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0Esa0JBQWtCLHVCQUF1QjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQSxvREFBb0QscUJBQXFCO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLFVBQVU7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsb0JBQW9CLGtEQUFZO0FBQ2hDO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsd0JBQXdCLGtEQUFZO0FBQ3BDO0FBQ0E7QUFDQSxHQUFHO0FBQ0gscUNBQXFDLDhDQUFRO0FBQzdDO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSxzREFBZ0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0EsWUFBWSxVQUFVO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsWUFBWSxxQkFBcUI7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QixnREFBcUIsQ0FBQywyQ0FBUSxJQUFJLDBCQUEwQixnREFBcUIseUJBQXlCLHdCQUF3QixHQUFHLCtDQUErQyxnREFBcUIsc0JBQXNCLHVDQUF1QyxvQkFBb0IsZ0RBQXFCLHNCQUFzQiw2REFBNkQ7QUFDL1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0MsZ0RBQXFCLFdBQVcsa0NBQWtDLFdBQVcsb0RBQW9EO0FBQ2hMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLGdEQUFxQixDQUFDLDJDQUFnQjtBQUNyRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLGdEQUFxQixVQUFVLGlGQUFpRixvQ0FBb0MsZ0RBQXFCLFVBQVUsNEVBQTRFO0FBQzFTO0FBQ0EsMkJBQTJCLGdEQUFxQixVQUFVLGdGQUFnRjtBQUMxSTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsMkNBQUs7O0FBRTVCO0FBQ0EsaUJBQWlCLHdCQUF3QjtBQUN6QyxVQUFVLHdCQUF3QixFQUFFLGlEQUFZO0FBQ2hELHFCQUFxQixpREFBWTtBQUNqQyxtQkFBbUIsNkNBQVE7QUFDM0Isc0JBQXNCLDZDQUFRO0FBQzlCO0FBQ0E7QUFDQSxrQ0FBa0MsK0NBQVU7QUFDNUM7QUFDQTtBQUNBLDRCQUE0QiwrQ0FBVTtBQUN0Qyw4Q0FBOEMsK0NBQVU7QUFDeEQsc0NBQXNDLCtDQUFVO0FBQ2hELHVCQUF1Qiw2Q0FBUTtBQUMvQixzREFBc0QsK0NBQVU7QUFDaEUsMERBQTBELCtDQUFVO0FBQ3BFLHdCQUF3QiwrQ0FBVTtBQUNsQztBQUNBO0FBQ0Esb0NBQW9DLCtDQUFVO0FBQzlDO0FBQ0E7QUFDQSxlQUFlLDZDQUFRO0FBQ3ZCLDJCQUEyQiw2Q0FBUTtBQUNuQyw2QkFBNkIsNkNBQVE7QUFDckMsMEJBQTBCLDZDQUFRO0FBQ2xDLDhEQUE4RCwrQ0FBVTtBQUN4RSxFQUFFLGdEQUFVO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLEdBQUc7QUFDSCxxQkFBcUIsNkNBQVE7QUFDN0I7QUFDQSw2QkFBNkIseUVBQWdCO0FBQzdDO0FBQ0EsdUJBQXVCLDZDQUFRO0FBQy9CLEdBQUc7QUFDSCxjQUFjLGtEQUFhO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGtEQUFhO0FBQy9CO0FBQ0EscURBQXFELG9FQUFXO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHNEQUFnQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsOENBQVE7QUFDNUIsa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLDhDQUE4Qyw4Q0FBUTtBQUN0RDtBQUNBO0FBQ0EsR0FBRztBQUNILGlDQUFpQyw2Q0FBUTtBQUN6QyxFQUFFLGdEQUFVO0FBQ1o7QUFDQSxHQUFHO0FBQ0gsZ0ZBQWdGLGdEQUFxQjtBQUNyRztBQUNBO0FBQ0E7QUFDQSxrREFBa0Qsc0JBQXNCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxnREFBcUIsa0JBQWtCLGdDQUFnQyxvQkFBb0IsZ0RBQXFCLGtCQUFrQix1REFBdUQ7QUFDMVA7QUFDQSx5QkFBeUIsZ0RBQXFCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLDJDQUFNOztBQUU1QjtBQUNBLDBCQUEwQixNQUFNO0FBQ2hDLFVBQVUsZUFBZSxFQUFFLGlEQUFZO0FBQ3ZDLDJCQUEyQiw4Q0FBUyxPQUFPLHFGQUF1QjtBQUNsRSxvQkFBb0IsNkNBQVE7QUFDNUIscUJBQXFCLDZDQUFRO0FBQzdCLHlCQUF5Qiw2Q0FBUTtBQUNqQyxzQkFBc0IsNkNBQVE7QUFDOUIsMEJBQTBCLDZDQUFRO0FBQ2xDLGdEQUFnRCwrQ0FBVTtBQUMxRDtBQUNBLDZCQUE2Qiw2Q0FBUTtBQUNyQyxpQ0FBaUMsNkNBQVE7QUFDekMsOERBQThELCtDQUFVO0FBQ3hFLHNCQUFzQiw2Q0FBUTtBQUM5Qiw4QkFBOEIsNkNBQVE7QUFDdEMsMEJBQTBCLDhDQUFTLGtDQUFrQyxrRkFBb0I7QUFDekYsMkJBQTJCLDhDQUFTLG1CQUFtQixtRkFBcUI7QUFDNUUsc0JBQXNCLDhDQUFTLDRDQUE0Qyx1RkFBeUI7QUFDcEc7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLGtEQUFhO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILDZCQUE2QixrREFBYTtBQUMxQztBQUNBLEdBQUc7QUFDSCxrQkFBa0Isa0RBQWE7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Qsd0JBQXdCLHdCQUF3QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsK0RBQStELE9BQU87QUFDdEU7QUFDQTtBQUNBO0FBQ0EsMkRBQTJELDBFQUFnQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCwwQkFBMEIsa0RBQWE7QUFDdkM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSw4QkFBOEIsa0RBQWE7QUFDM0M7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx5QkFBeUIsa0RBQWE7QUFDdEM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSwrQ0FBK0MsZ0RBQXFCO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wscURBQXFELGdEQUFxQixvQkFBb0Isd0VBQXdFO0FBQ3RLO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELGdEQUFxQixVQUFVLHdFQUF3RSwwREFBMEQsZ0RBQXFCLG9CQUFvQix3RUFBd0U7QUFDclUseUJBQXlCLGdEQUFxQixVQUFVLG1FQUFtRTtBQUMzSDtBQUNBLCtCQUErQiwyQ0FBTTs7QUFFckM7QUFDQTtBQUNBLGdCQUFnQixpREFBWTtBQUM1QixVQUFVLG9CQUFvQjtBQUM5QixvREFBb0QsK0NBQVU7QUFDOUQsb0NBQW9DLCtDQUFVO0FBQzlDLDBDQUEwQywrQ0FBVTtBQUNwRCxnREFBZ0QsK0NBQVU7QUFDMUQsMENBQTBDLCtDQUFVO0FBQ3BELDhDQUE4QywrQ0FBVTtBQUN4RCxzREFBc0QsK0NBQVU7QUFDaEUsc0RBQXNELCtDQUFVO0FBQ2hFLG9EQUFvRCwrQ0FBVTtBQUM5RCwwQ0FBMEMsK0NBQVU7QUFDcEQsZ0RBQWdELCtDQUFVO0FBQzFELGtFQUFrRSwrQ0FBVTtBQUM1RSw0REFBNEQsK0NBQVU7QUFDdEUsb0RBQW9ELCtDQUFVO0FBQzlELHdDQUF3QywrQ0FBVTtBQUNsRCxxQkFBcUIsNkNBQVE7QUFDN0I7QUFDQSw2QkFBNkIseUVBQWdCO0FBQzdDO0FBQ0EsZ0JBQWdCLDZDQUFRO0FBQ3hCLGVBQWUsNkNBQVE7QUFDdkIscUJBQXFCLDZDQUFRO0FBQzdCLHdCQUF3Qiw2Q0FBUTtBQUNoQyxnQkFBZ0IsNkNBQVE7QUFDeEIsd0JBQXdCLDZDQUFRO0FBQ2hDLGtCQUFrQiw2Q0FBUTtBQUMxQix5QkFBeUIsNkNBQVE7QUFDakMsdUJBQXVCLDZDQUFRO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0Isa0RBQWE7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IseUVBQWU7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2Qix5RUFBZTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSw4RUFBZ0I7QUFDMUI7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLFVBQVUsOEVBQWdCO0FBQzFCO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSx3Q0FBd0MsNEVBQWM7QUFDdEQ7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLHNFQUFZO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILHNCQUFzQiw4Q0FBUztBQUMvQiw4QkFBOEIsOENBQVM7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLDhDQUFTO0FBQy9CLHFCQUFxQiw4Q0FBUztBQUM5QjtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsOENBQVM7QUFDcEMsOEJBQThCLDhDQUFTO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qiw4Q0FBUztBQUNqQztBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsOENBQVM7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHlCQUF5Qiw4Q0FBUztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsNEJBQTRCLDhDQUFTO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxzQkFBc0IsOENBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLDREQUE0RCxnREFBcUIsNkJBQTZCLHlCQUF5QixVQUFVLGFBQWE7QUFDOUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUcscUJBQXFCLGdEQUFxQixVQUFVLHNEQUFzRDtBQUM3Ryx5QkFBeUIsZ0RBQXFCLFVBQVUsc0NBQXNDLGtCQUFrQixnREFBcUI7QUFDckk7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLG1CQUFtQixnREFBcUIsVUFBVSwwREFBMEQ7QUFDL0c7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsMkJBQTJCLDJDQUFNOztBQUVqQztBQUNzTTtBQUNqSTtBQUNyRTtBQUNBLFVBQVUsbUdBQW1HO0FBQzdHLFVBQVUsVUFBVSxFQUFFLGlEQUFZO0FBQ2xDLHlCQUF5Qiw2Q0FBUTtBQUNqQyw0QkFBNEIsNkNBQVE7QUFDcEMsMEJBQTBCLDZDQUFRO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFLDBEQUFvQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsb0JBQW9CLGtEQUFhO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHNFQUFZO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEdBQUc7QUFDSCxvQkFBb0Isa0RBQWE7QUFDakM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx1QkFBdUIsa0RBQWE7QUFDcEM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLHVDQUF1Qyw0RUFBa0IsaUJBQWlCLDRFQUFrQjtBQUM1RiwyQkFBMkIsZ0RBQXFCO0FBQ2hEO0FBQ0E7QUFDQSxzQkFBc0IsNEVBQWtCLFlBQVksRUFBRSxVQUFVO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsZ0RBQXFCLENBQUMsMkNBQWdCO0FBQy9EO0FBQ0EsbUJBQW1CLGlEQUFXO0FBQzlCLDJCQUEyQiwyQ0FBTTs7QUFFakM7QUFDQSxrQkFBa0IsU0FBUztBQUMzQixrQ0FBa0MsK0NBQVU7QUFDNUMsd0NBQXdDLCtDQUFVO0FBQ2xELDhCQUE4QiwrQ0FBVTtBQUN4QyxzQ0FBc0MsK0NBQVU7QUFDaEQsd0NBQXdDLCtDQUFVO0FBQ2xELDRDQUE0QywrQ0FBVTtBQUN0RCxzQkFBc0IsNkNBQVE7QUFDOUIsMEJBQTBCLDZDQUFRO0FBQ2xDLHNCQUFzQiw2Q0FBUTtBQUM5QiwrQ0FBK0MsK0NBQVU7QUFDekQsK0JBQStCLDZDQUFRO0FBQ3ZDLDRCQUE0Qiw2Q0FBUTtBQUNwQyxpQ0FBaUMsNkNBQVE7QUFDekMsdUJBQXVCLGtEQUFhO0FBQ3BDO0FBQ0Esa0JBQWtCLGtEQUFhO0FBQy9CO0FBQ0Esd0RBQXdELGtFQUFRO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qiw4QkFBOEI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLGdEQUFVO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsNkJBQTZCLDhDQUFTO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyw4Q0FBUztBQUMxQztBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsOENBQVM7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLDZCQUE2QixrREFBYTtBQUMxQztBQUNBO0FBQ0EsR0FBRztBQUNILHNCQUFzQixrREFBYTtBQUNuQyx5QkFBeUIsZ0RBQXFCLFVBQVUsb0ZBQW9GLGtCQUFrQixnREFBcUIsVUFBVSxpRkFBaUYsOEVBQThFLGdEQUFxQiwwQkFBMEIsMkJBQTJCLGtCQUFrQixnREFBcUI7QUFDN2M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGdEQUFxQjtBQUN6QztBQUNBO0FBQ0EsdUJBQXVCLDJDQUFNOztBQUU3QjtBQUM2QztBQUM3Qyx3Q0FBd0Msa0VBQVE7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsNkNBQVE7QUFDekIsZUFBZSw2Q0FBUTtBQUN2Qix3QkFBd0IsNkNBQVE7QUFDaEMsdUJBQXVCLDZDQUFRO0FBQy9CLHlCQUF5Qiw2Q0FBUTtBQUNqQyxvQkFBb0IsNkNBQVE7QUFDNUIsZ0NBQWdDLDZDQUFRO0FBQ3hDLG9CQUFvQiw2Q0FBUTtBQUM1QixnQkFBZ0IsNkNBQVE7QUFDeEIsZ0NBQWdDLCtDQUFVO0FBQzFDLGlDQUFpQywrQ0FBVTtBQUMzQyxrQkFBa0Isa0RBQWE7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsMEJBQTBCLDhGQUFnQztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MseUVBQWU7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILGdCQUFnQiw4Q0FBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCwyQkFBMkIsa0RBQWE7QUFDeEM7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsZ0RBQVc7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsOEVBQWdCO0FBQ3hCO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCxzQkFBc0IsdURBQTRCLElBQUksNEVBQWM7QUFDcEUseUJBQXlCLGdEQUFxQixVQUFVLGlEQUFpRCxrQkFBa0IsZ0RBQXFCLCtCQUErQixtQkFBbUIsc0RBQXNELGdEQUFxQixxQkFBcUIsa0NBQWtDO0FBQ3BVO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsbUVBQU0sUUFBUSxlQUFlO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELDhFQUFvQjtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyw0RUFBYztBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiw0RUFBYztBQUNqQztBQUNBLG1CQUFtQiw0RUFBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsaURBQVc7QUFDcEMsZ0JBQWdCLGlEQUFZO0FBQzVCLFVBQVUsbUNBQW1DO0FBQzdDLHNDQUFzQywrQ0FBVTtBQUNoRCw4Q0FBOEMsK0NBQVU7QUFDeEQsb0RBQW9ELCtDQUFVO0FBQzlELDRDQUE0QywrQ0FBVTtBQUN0RCxrQkFBa0IsNkNBQVE7QUFDMUIsa0JBQWtCLDZDQUFRO0FBQzFCLG9DQUFvQyw2Q0FBUTtBQUM1Qyx3QkFBd0IsOENBQVM7QUFDakMsVUFBVSx1RkFBeUI7QUFDbkM7QUFDQTtBQUNBLHVCQUF1Qiw4Q0FBUztBQUNoQyx3QkFBd0IsOENBQVM7QUFDakM7QUFDQSxJQUFJLDBEQUFvQjtBQUN4QjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLElBQUksbUVBQU07QUFDVjtBQUNBLGtCQUFrQixrREFBYTtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLG1GQUFxQixtQkFBbUIsbUZBQXFCO0FBQzdFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyw0RUFBZTtBQUN6RDtBQUNBO0FBQ0EsR0FBRztBQUNILDBCQUEwQixrREFBYTtBQUN2QztBQUNBLEdBQUc7QUFDSCx5QkFBeUIsZ0RBQXFCLFVBQVUsdUNBQXVDLHVDQUF1QyxnREFBcUI7QUFDM0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELDRDQUE0QyxtRkFBeUI7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZ0NBQWdDLDRDQUFTO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkIsZ0RBQXFCLGtCQUFrQiw2Q0FBNkM7QUFDL0c7QUFDQTs7QUFFQTtBQUNtRDtBQUNuRDtBQUNBLFVBQVUsYUFBYTtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWUU7Ozs7Ozs7O0FDL3RHRjtBQUNBOztBQUVBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQSxHQUFHLEVBQUUseUJBQXlCLFNBQVMseUJBQXlCO0FBQ2hFO0FBQ0EsMEJBQTBCLHlCQUF5QixTQUFTLHlCQUF5QixrQjs7Ozs7OztBQ1RyRixjQUFjLHVDQUFpQztBQUMvQyxrQkFBa0IsbUJBQU8sQ0FBQyxLQUFrQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyx5QkFBeUIsU0FBUyx5QkFBeUIsa0I7Ozs7Ozs7QUNOM0YsY0FBYyx1Q0FBaUM7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIseUJBQXlCLFNBQVMseUJBQXlCLGtCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vdHlwZW9mLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL3RvUHJpbWl0aXZlLmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL3RvUHJvcGVydHlLZXkuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZGVmaW5lUHJvcGVydHkuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vb2JqZWN0U3ByZWFkMi5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3IuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvYWctZ3JpZC1jb21tdW5pdHkvc3R5bGVzL2FnLXRoZW1lLWFscGluZS5jc3MiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eS5qcyIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9hZy1ncmlkLWNvbW11bml0eS9zdHlsZXMvYWctZ3JpZC5jc3M/YWJmYSIsIndlYnBhY2s6Ly9ndWl2Mi8uL25vZGVfbW9kdWxlcy9hZy1ncmlkLWNvbW11bml0eS9zdHlsZXMvYWctdGhlbWUtYWxwaW5lLmNzcz85Yjc1Iiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL2FnLWdyaWQtcmVhY3QvZGlzdC9wYWNrYWdlL2luZGV4LmVzbS5tanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2YuanMiLCJ3ZWJwYWNrOi8vZ3VpdjIvLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy90b1Byb3BlcnR5S2V5LmpzIiwid2VicGFjazovL2d1aXYyLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvdG9QcmltaXRpdmUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gX3R5cGVvZihvKSB7XG4gIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcblxuICByZXR1cm4gX3R5cGVvZiA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIFwic3ltYm9sXCIgPT0gdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA/IGZ1bmN0aW9uIChvKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBvO1xuICB9IDogZnVuY3Rpb24gKG8pIHtcbiAgICByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbztcbiAgfSwgX3R5cGVvZihvKTtcbn1cbmV4cG9ydCB7IF90eXBlb2YgYXMgZGVmYXVsdCB9OyIsImltcG9ydCBfdHlwZW9mIGZyb20gXCIuL3R5cGVvZi5qc1wiO1xuZnVuY3Rpb24gdG9QcmltaXRpdmUodCwgcikge1xuICBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKHQpIHx8ICF0KSByZXR1cm4gdDtcbiAgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07XG4gIGlmICh2b2lkIDAgIT09IGUpIHtcbiAgICB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTtcbiAgICBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKGkpKSByZXR1cm4gaTtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7XG4gIH1cbiAgcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTtcbn1cbmV4cG9ydCB7IHRvUHJpbWl0aXZlIGFzIGRlZmF1bHQgfTsiLCJpbXBvcnQgX3R5cGVvZiBmcm9tIFwiLi90eXBlb2YuanNcIjtcbmltcG9ydCB0b1ByaW1pdGl2ZSBmcm9tIFwiLi90b1ByaW1pdGl2ZS5qc1wiO1xuZnVuY3Rpb24gdG9Qcm9wZXJ0eUtleSh0KSB7XG4gIHZhciBpID0gdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7XG4gIHJldHVybiBcInN5bWJvbFwiID09IF90eXBlb2YoaSkgPyBpIDogaSArIFwiXCI7XG59XG5leHBvcnQgeyB0b1Byb3BlcnR5S2V5IGFzIGRlZmF1bHQgfTsiLCJpbXBvcnQgdG9Qcm9wZXJ0eUtleSBmcm9tIFwiLi90b1Byb3BlcnR5S2V5LmpzXCI7XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkge1xuICByZXR1cm4gKHIgPSB0b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHtcbiAgICB2YWx1ZTogdCxcbiAgICBlbnVtZXJhYmxlOiAhMCxcbiAgICBjb25maWd1cmFibGU6ICEwLFxuICAgIHdyaXRhYmxlOiAhMFxuICB9KSA6IGVbcl0gPSB0LCBlO1xufVxuZXhwb3J0IHsgX2RlZmluZVByb3BlcnR5IGFzIGRlZmF1bHQgfTsiLCJpbXBvcnQgZGVmaW5lUHJvcGVydHkgZnJvbSBcIi4vZGVmaW5lUHJvcGVydHkuanNcIjtcbmZ1bmN0aW9uIG93bktleXMoZSwgcikge1xuICB2YXIgdCA9IE9iamVjdC5rZXlzKGUpO1xuICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgIHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTtcbiAgICByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHtcbiAgICAgIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7XG4gICAgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7XG4gIH1cbiAgcmV0dXJuIHQ7XG59XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkMihlKSB7XG4gIGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7XG4gICAgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9O1xuICAgIHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7XG4gICAgICBkZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTtcbiAgICB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gZTtcbn1cbmV4cG9ydCB7IF9vYmplY3RTcHJlYWQyIGFzIGRlZmF1bHQgfTsiLCJmdW5jdGlvbiBhc3luY0dlbmVyYXRvclN0ZXAobiwgdCwgZSwgciwgbywgYSwgYykge1xuICB0cnkge1xuICAgIHZhciBpID0gblthXShjKSxcbiAgICAgIHUgPSBpLnZhbHVlO1xuICB9IGNhdGNoIChuKSB7XG4gICAgcmV0dXJuIHZvaWQgZShuKTtcbiAgfVxuICBpLmRvbmUgPyB0KHUpIDogUHJvbWlzZS5yZXNvbHZlKHUpLnRoZW4ociwgbyk7XG59XG5mdW5jdGlvbiBfYXN5bmNUb0dlbmVyYXRvcihuKSB7XG4gIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHQgPSB0aGlzLFxuICAgICAgZSA9IGFyZ3VtZW50cztcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHIsIG8pIHtcbiAgICAgIHZhciBhID0gbi5hcHBseSh0LCBlKTtcbiAgICAgIGZ1bmN0aW9uIF9uZXh0KG4pIHtcbiAgICAgICAgYXN5bmNHZW5lcmF0b3JTdGVwKGEsIHIsIG8sIF9uZXh0LCBfdGhyb3csIFwibmV4dFwiLCBuKTtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIF90aHJvdyhuKSB7XG4gICAgICAgIGFzeW5jR2VuZXJhdG9yU3RlcChhLCByLCBvLCBfbmV4dCwgX3Rocm93LCBcInRocm93XCIsIG4pO1xuICAgICAgfVxuICAgICAgX25leHQodm9pZCAwKTtcbiAgICB9KTtcbiAgfTtcbn1cbm1vZHVsZS5leHBvcnRzID0gX2FzeW5jVG9HZW5lcmF0b3IsIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCIvLyBJbXBvcnRzXG5pbXBvcnQgX19fQ1NTX0xPQURFUl9BUElfU09VUkNFTUFQX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvc291cmNlTWFwcy5qc1wiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvZ2V0VXJsLmpzXCI7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzBfX18gPSBuZXcgVVJMKFwiZGF0YTpmb250L3dvZmYyO2NoYXJzZXQ9dXRmLTg7YmFzZTY0LGQwOUdNZ0FCQUFBQUFCWWdBQXNBQUFBQUx5UUFBQlhRQUFFQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFISXRLQm1BQWpSSUtzbnlwUEFFMkFpUURnbWdMZ1RZQUJDQUZoRVlIaGtVYjVDaGxCR3djQVBIWVNVQVVKWE16RWxGQktjNysvME9DTmthSStISGFtbEpBa3huUnBrU1Q5dTVldi9YR283SFowMzVmcitKU1lqRFFJeEZDV0dKSis2WXhNVXZudWUyQUljZlFlYy85VHh5ekRaVEREa2xDa3lDYUkyZVRQSUZDb1FnbFl3bm9WVFdna2RXdnF6U0J1eEw2b0p2Zks0UTJOZjFlL1dJR0pCQ2tobFJPMUtieGh2bVc0VGI3ZzdiMUQxYU1aaTNRdzhKQ0d4QUZkWmVvT2ZQclltSUhSaDFjVk9GVjRFVjZ0VmNWL05DTDFGOEJNQVBQUnZqZzZMYUxTV00wV0xlcDNLcHV0S29iT1NGaFprVWRPRFdnWmZlWThjaWFzMVg1Sk4va1M0S3NHYkltZ3RUZHkrUXJ1ajlUMzNLdFNlWWJsblBLbU8zM3ZlNFlkSmlFazNoQ25Fc0UvSi9Pc2wwZElNOFJGOTMxMUhXajBheXQ3Njlacit5ajJWa2lyWTUwckFQaU1GVEUxdnJ5WWg5N1E2Z0FWVW1aVk1CbHVpdjY5S21wYUZLV1Z6UnRzSlJER1Q2QXpTNGxTSEdhSzhLSVhmYjRGYm5veGpUd2VJU1NZNnRqYk5VTmJMV1JoQ2dXWU9URlI3NGRBU3B0dXlSTnpiZ0JNbWNQZlhxRGFjVHN1Z0hQcThmWlUwL3ZnM2FUeUpJdWdZWmNjazlHMDhnbi82TWx4c2RHTnBoZkx5ckpmS0V2K2t0YXlhaTZUUkZKMmp3M0hhTlJjUWFUSUluU3F6Rk5GcHVzYkU3Q0xaaWtKTk1IUWhNSW5TSE1sbTZWYlVtT3lzdXhmbDlYZ09OanA4ODBtdC9ZWmRtbFlRb3JGQVpORzZkSXFkdDFTU2lLRzJENmJDNlZYYjMxQXFvbnBCSThqQ2RQMGVOZ1hOZklWN2hjaWJ3ZGtuQ2xjT3NXQzM5NE1kTm5iTGtpeCtqODE2aDJ5dXFTYTZ6b2NKbnNMeWpiRVU5ZDNCUmloQzJFd2RFSnR1dXE1dm9tcmsvbGJ0bmNTbDlITUQxY0EvbTdyNHlKeWxoMHp2UElGeHVTL0Myd0h5NlA0c3cxaVJSNjJhNHJySSsrcllzWjRUYlJhc1ZBNkJEOWc4ai9YSkRHdG9wUURhczNsamZQODgzUEF6ZDlqQ0pTRFg2TWp2eW9pZmJpU1hjbm5yQlMwY2JHRDc3TDFJdnQrcW5DbWxvUWR4SVBuZkZFNWRiWXh0THVsOUk0TExpOVJSUnVYSW9aNm1KZFh4ajlZa1ozbEZRQmYvMjRXc3B3Ymh1NUloSHUreUlaaVZFbEpkNU54dWxVam9mR2VNNGsxcFdCY0x4bjdFdGRHeEV0VFY2T29NRDJEeW5oMGdmUmFEWmJDcGdkTlpBNTBOeWhMUG13U0Vja1RGdTJhellyUDJ3Y1FUT0RQZktJY0tvZWxZMmZMdmhQUmlsYXpMMEd1OEVlK2QvVWxQTlhiZE4wektGVVBVYmRPV05NclhPbVFielREalFtZ2tKVzNQNGh5aHJLVnMzT25rdGs5SWZlbXhMY253YkhoS2loYklKTUVvckpXYWRWNjkvenloY24wa3RRckkzOVl1QW5odnY2VGlYU0xPR0dGdEdERUllbmtsVUR0aFlsQXNVcy9Ed2NabEI3U0kwc3RzMlR2MzVGcW1yZFZWYmhsaS8ydzFXZWNyQ1JCRmF5b0o1emNVU0dlc0pFWHI4ck9sd2V2KzVmemdqSi9zUWpOTWpXczZQQXZmc2ZQcDdyQ3lxUVVYTE1YdEhhY2Y0SXYzVWxucHV4dTVCU1R1MWJVQTJRT0hzT09rRUJXZi95cXVna1A3SjdUS1NRdEZVdFdnWnZaY056Ny94SWYrTC8vK3R5MzBzZkVrelk2eTFtTW1UbTYxY3RPL1lMQWxGZHptR09vd1BQTlhTNDVWMWlDa1BKSlRCazZSa1lpNURJaUd4Uk1WUmNRbEpLdXBOYlZrNWVRVkZKV2NXRVNWTmptR244Q1hGT1ZVMWRRMVBMdkFXTGxpeGJzV3JOdWcyYnR0UnQyN0ZMbHJObjM0RkRSNDZkT0hYbTNJVkxWNjRoU2pHYnladjhueisrNm5oc3BMVU5kSlo4WVliUUYzZ3d0SHFETWFycHFvSGlvTVY3UWRjMTJRUU9rWEZ3bUt5Q0kyUVJIQ1did1RFeUJZNlRuZUFFbVFBbnlUSTRSV2JBR2JJQ3pwSWxjSTVzQWVmSkhMaEFac0ZGc2cxY0pwUGdDbGtBVjhrMHVFYTJndXRrQjdoQjVzRk5zZ1p1a2UxZ1BYaTdJQUc1QndxUUFBdUlnQXFZZ0F1RVFBcVVRQXVNd0FxY3dBdUNJQXFTSUF1S29BcWFvQXVHWUFxV1lBdU80QXFlNEF1QkVBcVJFQXVKa0FxWmtBdUZVQXFWVUF1TjBBcWQwUHVmYnBEM1JtRVNaaU9IdEl4NlNHdldzd203Y0FpbmNBa1A0U204aExjeEJPa3poaUY5czcyZjhPY2VvQXE3YjgrekFaNUNXUmRVdHBtVnhHc1A4eWdYQkpUbXJvemc0MktGcFkvOEZWK0MxVTFHbEsvTnQySU5VZm5NdDl0cXp2RUxEbitPSkZrNzNyV1A4bXJHaU10Vk5RUkZoWlZzS1FjQ1dabU1KQlZ4NG5wWXdRNXhvVUwveldhelV6WlpLcjlkdEJvanNwRXlrWlRTTmhuWHJqYmRKRDAzQTZrbVZTUm5sTTNxWUxBdEF6RFdsWHN5cVViN2ZGWmJocWVkZGlYVkg1TnVRd0RwRVNMSFh2SDRsclVBb0FRRVlZQ3pZRGVoaXhoZmxhQWt6dnNvWVlzcGp4SFdIZWU4REpra2QyRTNUU3VTWnBJNnUraTAwY1hpclM0R2EvNEJkbjdCU0lxek5PVkpvbUVQWWhnZ0ZidVE5b3A1N3hqdzZjZnY0MWV0aHllaDN6anhZSXZDcVVydlQ3TWpCTU9hN3hYL1BvUU55aGRVa3Iva2xPWWk1YlpEUUg5dXZZVEdsTklFTGVRTjl5QVh6bGhlN0VZdVRaYU1TS01GekdmQWc3MUI2bGZvejNGUU5zQnJ2RUNkQVc5d2hWcE5NRkVrcGlwY2MxaFQ3TG1BTDRNVy90eTdFTnppRDlLQ1VNUzRzMDh2bE12SVBGQXRsWFpBWSsvUmk5ZzZmeGpvT2RNUlMxVmtIZ1A2OW9wVkc1alBXemJWRDUxRDVoam5xQk9aaTBVYld6Vm9sQTZJQjZwSGpLTzFwZlpYaXJtYTVwVE1NdEJ0V3hpOVg3QXJSVTU1UGdvTGUyMGRSRWd1bCs0NEloUEZNdnpGRllxenMzWmFXS2J5Z28yR1hxK2J6U1kwM21ha2Nod1FUVFJhTFd6TjdqWFBIZElQbjdjdUhqV09YRmhwUHV1WkRNWUxsV2J5TzZxbklscUt1TmRkWVYvSWFrTnR6Z3p6R3dleFZXbW5QTm9pWFdNUDBNY1JhaHZ0N0RNUGlFeTNjKzlEWmhVYWF4UTFTZWlLVklLMjlMcGlLa1NPMVJmRkZxWHFxTjVzTWpGNnNrWFAxYWMxdWdKYlBOVW56T1RLQkV0ZWJFTDlKTnJpemFvMk4xZ3RYOWJyUktxd3IwVmVEdGFiSlpuWUswUmprNmRmWFkwQTRtWXd2SktDTk9RYkdFOFJxbUFYNGdoaWFoM01hbkpLRFFSZ1B3akJKUm9FQnJDT0JZSWc2RlYwVTVKY0NXem1CZ2Q0U3BMVExKZ3hiajdGR2JrV1JsRHg1QWFrUzZheGZnU3c5Zmg2NDlvakJJYXVEU2lNM0hndCtGZDl3ZEw5QVJoY2FRR1BZQlVMUGNrVTBvM0I5UE5nTGVoQzhHZ2piZFlMYU1Vem5HZ1crRUtmSDE3Tk1oTGpsQktXb0h3QkppUWoxRWVpOFpoMHBTbWJ6Ymg2dVFIMFRCdHBhTWNUODlFZ3RBeGFoSE1MV0JXOWJGYU4ycktRRjRNZ3hDcUw1cC9maEtQdm4zMlg3NWhhVzNnd0tvODdOTzdjSENMWTdic25IWm8zaXBINGluMlJndEJPN3N5Nk5VNk8xb1p1SFRHQUN6YTJvd2NITXUxMG96SDRxOFhiNnZWWjMvU2RhVGFIZkozWjJXck4vYjQzNUdud3N5K0h0bGJxd3ZibnMwZEROZkp4RWhObnI1eUZoSStiRHprV3VUMzM3c1RhME5YNmNBeFpmUmlHM0RTZkRTSVk0bjZBaCt4NE1hZHZINW9GTUwrREFNNk9CMnM5My9JdDMrcmJ4QmF6SDR4TnpPb2JvL0hXaWxIalkzUG9XRDY5NDJVQUJJOUpaY1BGdnpZTVFpdXdCM1d2cEd5UzNLOHFHVlZXVmJwUjRkMkppU3haWWxaMlJxd0R0dGRuSlIrMjRPNkpDYUo0UGIxWEI1Tm5xSEh5NlZnSzlGV1ozcXc5MDQ5dDJYYWRwbG1YQVFKb2RsTHREd2lLQWxCZDRHeWhGM0MvMVJLcG9UMFpZSmpSc0R0SCtwRzR4M3hodkxTZTY4L1dZa3FmdG9Zd2dmbzVUTkNnV1JYZ21RdjZ0Q2lzU2RabmlENDFiTFNhYWlRVDlvUzZQVUZ2TC90YWFPaW1DVmFiSHVjYjRBek1qNDNHRW14VWVWeTVyVEFoUHI5SmhiWWNXQ0p3T3ZiaTFLTWpTcUxJVHkrc1RaM0kwbkZwRVlsbGFXRlVUalJGa2JUdmJ0czJMc0kyS0FucXhpNGVXenZ0KzJUbFJheEpiaExmRUFMaGpHTkVlZDRTcUwydGJIN2tPS1ptNnhIWEZ0bUhvVHdyVUFHdUlaak0rcWNyMnlPRTJyb216Y0E1VTkwUjVZSk0yWUF1VkpLTjhaY0hnOC9oMW9tNkNyVkVBb3g3Tmk0SEFPR3RFWTVZVFRVblhJRXdpSEZYWitGWVRVa0Vadk1IcmYxQzhwMHZzQkRadUdKQ2NzcjNrLy9BLzMxVXh2L0FIRTg2ZnZ1WXBteDc4VVl5TnRIMVhYU2NIWnd2NXJBZzRSZDBtaGdMQmdkK0w3My81WC95KzUyNStnbGtBRVBmdHRmMXpPdWFNNmRyWHM5M3Bybi9yams5ODc1ajZGNVl0SE9DSWhUWXdlc0FBL3VEdm1iZ0dzaGh3NGloczlQUVpZQzRSV1piNzRqYjNxZnNkb1EzL0hqODJMWnVicW1wRjg1djJwU2FsdTdNRGd0dkNVOHU3TEh0RzRwZTI1eWFHdjQ0dFhidHlySXlLalVwOFlMZTJJWHpGM1lsYmQ4KzV3OE4weDhVNE04ay9wd0QvVGRIZER6ZGdONk1CTmxwNTNYVmcwZGJSSHgzalhzMmZDVXdFVG4ralEzK0trTDFUWjk1eFIvWXF0M1cvOHBDRlJ1VWN1VVYxUlg0SEp1Yko1WG1sYjdWZ1VVVVppNXlBc0h0RDlXVkhjMFQ1SHNvd2RYQk1jRlZ3UUxyMnFxWXZ1K20xNXZPN2htVXU5WWhZdWZIbE9hMTkrM25zbTY3T2xmSGpLeVJ1L21mN1VCY1BCS0NVSnZWRGoySjdUd25qMzFjM3lPVnZqazV6TEdPcTNZN01obHU3aXpIeTk5UXV6bU92VFV0ZjlyVHMxSEh0UjdmQmV1aDIvVzFPNnEzNkhKYjQxQXJTbnZsalRyWTVHK1Z1cnR2UEkvMkpjd0pQY0loR2FIZzFtUFhtV0pMWS9Edk1KcVdPUjBxWkhDdlJWcmJya0Yxc01NK2R1eHh3WU9zNjNja1lnNVBFOFBWVkxtTGhsdjE0akVhSGlZdTdTNXNDeTd3NWJGbUZkNkFKb1lYeEZxYjdIbXBMOVo0S2Zhd01iYnZNRUlKN2tydlNzTWVXblhDNkJGK1pRK2gvRGdNMHIvTm9WM1NNWi9kN1F1NTNhUHI1alNNZHNlZDZQNC9FL0x3dk5XM2lMUFdUbEgyOUpUVWhxenU0NHZST1F4WFJtek8yT3llMkdrMGF5ZGZKeFJheUxoT3hnOE4zMWNudXVFcXFWSnBRb3F6amJLMjNsSHBuRkNCVEh2NkdsbXA1ZFpuZzFIZTF1T1ZMaEltcDFhVVdGK1ZaY1l3eFNWbDR3WHEzOVJzMCtyWU1EV0hvd3lMdGJVcTd1SmxSWUVxZ3FkU3BZclkrUXh4cVVUOUhNZ1pxdENQM254dnpuTjFTUmxUWEh4ajBWdXY5TFplbzJ5SHlpTTRvK0lyZUtVTHB4cERLNk9taVdzQ0NZSzlPcGYzSFNGenB4N2Y5UnYydU5jZTdIdjBHTDd4VHh4WHJMODFuc3RmaVc4RXJPbE5EUmlweHczNEVYMXdQQzdHemlCSnJ5R0REb3ZINGtpY2krc0hETGloS3pERHNONzM3dXpFNDNIOWNCd0doR1h3YWEvQ1dOZG1lVDdxL2JmWmJCbzlNQTFsUnRqemxlMjVsNzA1ZmJPd09DNnVxTlUwSUNUT3h0N3J5VFp4MG9pMHprMXZaYUFJemRLK1dKY0NQRlA0S2RNRGYveW9xbGlvUFVWVlhpSS9oYjh2T2FGdEk1Ti9DQVEyNzJhbVZEQ0FkWFhsUHFOUUpKSzl3VE9yT3k1ZFhYbFBpYUNuMEg5THFNTjBCaDBPOThaMGdBMEl6aFRzdnAvTEE0MVpFZjMvUHNZMHhjZkJXOWFudHVUWkJXRlR3bDN5NGZaYWo2MHRDRThKUzA0T1N3a3ZFRmF6MTkyKzdjbXVUbkdCdUZDVURXSW0xZSs4KzIvR3YyZDMrWU8vMGJMVW5rZEpuOGFlNWc5ZmZ2Nmcya2dZMWhvSXlEQXNXR0R0S1VxYmRXR2x1YTZzWlA3V1JNejdJWXVWUFBCYXFheXVvRmt3QWtUcDUrdVdMSG56aG53N04ycmVYc04zbzdHd0ZiVmxNanZLM2EzYTZJdVh0QzJ5ZTNuZjQvT2RPOURuWW1xUmN6aHlLMlNVVEN2U0gxcjgvU0JzaUQxL0MrT0dhSVBXZmp6VWV2RG5WYm9UeXZQN05PYXc0M0tTSUxJSWNucExDRWVwQ05XMVR5ZmpJUkhraWs5ODk0WDNiQVFzcFpWK2JPOHhtTGN3ak1OKzhaTTdMS0NyRjhlUGp0SDNVZ3FmbTBYZExaeXZIM2RjMzZJYU93NTJmTzcvUUpXbWYvL3QzTlRtS20xUWJ1RE1tWUc1UWRxcnBpbWNPZk8rWVczUTFZVFVsdVdURzdXQ1BENC9UNkI5WExUdVA0K3ZGVHhtMW9hdmcvSldxYlIxT2luajA0UC9uR3hZVFpXUFRHSjZMOHRmQ0dYdzFqeDVNbzNLM1kzdmpoL0V1Qmk4WGVtWXFncmc3RVBjL283d3lkdmtEeWtKVGF2MS9QbFRLaFVKdmIwbEVpQWx1aUlkZk40eEwrMlZjYjFVQW1mT0xLSTBkZ0w1eXFzaXJEUlJ1R1orUzhnbWJWYVd0YXArd3ZobHFocXhjTG05RHI4SDBxOGFqUS9SV2xTb1ZtL2V6RHQwR0tydmVLM0VsMi8ya1BiMjVmaG1tcTJJSldZQmNlY08ya201OVVZSStMb2t1Q3J0dVNCb09HajE5WFdCYVAzUWhFMGFaUXVoSERpRUhUcEFLRm8waXMwVG1GaUlJZ041bXBMdXp2R2k4c1A0NFlGUStKV2J4ak9TUWpRWkJGNWJBMjZUNmgzb0RyczNlanEySFlQUW5uL05VWWRuVU9QbkFHM2NJVzdTTHQwQkhmMXhSd2U1ZnQzNjlTUThjNnFzdkp5U2FrdWRXR2cwZmpmc25SZmxmUFZLUmtaU0tUcno0R0JQV1VtZGVlV0ZrNHBRYTNvdGJOdTJlSEhkK1hSUkFNT0NWbDJoVkw0ZVNPN3BwcE9uVG1yMjdDRVRSSm1abnozdXY3UmIxTFo0Q2IzTnlyMjhvNzBkYlBoT1RrTzZjQUkyNGF4THhseHd3VjNBWmhGZGZtWThOaDVGSkxvVlVqelVYQXUrTmp6OE5QZ3BscjFHNnc5Njh1QmgwK2UyRVAxbEViZGp4dE9LQlkrZUJYMTNFWHQyR3U5cHhncmF0WWZGYnVWT2lObFJvRTlvVUQvWVN1L3V5WkFrenA1bk1mRjVsbDNrOFAvOVoxdExNa3Q2dXUzYnlGbXdGWFJNMitwdVllQ2NlUUdLM2FlMHVMWUdyM0dvdzRGVHAzalhyNk0zcnN1N0Zpc1YwMWQ0elRCUlRETThWeXhYS0ZhRXowQkJQKzcvLy8rc3ViY2Z5MUNIa0lqL2Y2c05IaHdOQUNCU3d6T1hJRDhOSFVuVmpWU0FHVkZHa3JYYjY0K01SMDZZODdrZStQOFBia0wrUW1lc1FaNVV0UVZFaTRoWlZVWThVUS9kZjJaRElnSzJtUlExemFhZXcrNy8vQU5pQnJOZld4Y3hiOElBc2JQb2RkNGh6bTJhaHpTWXJQVElHREIzYWl2WnFBcVZndFJETjRScXBITVVnbmlScEJwa0UrS2lXc2lRMktscTczcVYrYWlHbW9ta21NelR4R29VTWNYeXdsRTBCNHU2YmlCMUxlS05yS1NTR2NqTU5vbjYvNXg0ZFFCdHplWVdPeVYrdDdaRHpJQ1NiL1BtK0hpODVYaVhXSVByOTVnQzlLTmxUdG5XWCtqeWZ4ZkswdG1PZS8reXJMLytFeWs5YmEzK0M1Y3hObUNMandEdzE4d1NaemlQa0NMQkkwa0YvNTRESUlGNEhUU0xsa01KRFRCTUpKWVFnRGxnbXlDa2NIRTdlQjBhQVFGb1lRTVEybUQ4RzNGQkNBcmd2cmJjREI1b2VaeDRRWVQ3NElPV2Z4RUVqR0x4dTJFWVE4bnZNZjZYQlBjbHBrRDRHMzJKUnVpdDBIZjVqNUlEVS9YYTNjdDdmYitRVUl5aXEwNjNLbmYrVGJXcEd1RzIrc20wWGxHTVhDWGhEN1I2UEt1bTkrZWU0L2dOSHkyM1BlTi9TWEJmWWdxRXYzSC95SlZvUkdLSGtQeVBPOGp3WTJPcVhvOHZrdG92NWpFVm9PQjExZW5tK0hQbjMvUXBtOHB5aE5zQWYxYktKQ0UrZ1MrWWtwMFB0RmdkendXYzlQNzgzRmNqcTQ2MkVyN203d1NWai9OSDc1WWlqeUpLb2pUS29qd3FmditncXFQbWw0SFg5bnBCbEdSRjFYVER0R3pIOWZ3Z2pPSWt6Zktpck9xbTdmcGhuT1psM2ZianZHNzN4L09sYWpyamhpa3MyM0hiblc2djcvbEJPQmlPeGpkdWJ0R3JNdDRMZXFPQmFXeEUrSklISnR1eE5XUXhqdXpaaUc1blJiU2ZKNzdXZmhtNkorb3lnUndxU2h2SUtPNTU4d3BKK1plV0kwdWRRcXl0VEVJc0xlVzVaVkl4VnRFTkxhZmJ5QXJuUExDNUc5aWlRNGZaanZCYXR6a2RPNW5LQTkwTWIxam5hUEo1RUZTTW14QnJORWZKSmxtSFhrSWFlZUdTaHNJQUhVWnNkQndES2M1MUV0bTRRSDdhbW10b3d4MkhMVktaR3NxSlhBbXZPaVFtWEJCcmJXTGtDN3BScWlCSEhLUkFveFE2MW1rUzdBS1h2SldTdmgrdVQwV1ZxZWFtMlZEWmFDVEJuM1dZVFlmejNGNFgxNDR2RkRLZHJBVVlXYXpwV1RjWXRHUHVaNitDMkpNNG8xZm1oRFF0MUJiUE1NV1NSeUk2c1drcmRIMzFLaVNxdG05dVh2WXMxZ01veDRVNjNLYVY5VUtFcmo2eEtyZHpva0k1emNmRzdzVGcwcEtXSWRNMGVtWFhnaFVZVjJ2ZTQxOXNiWndib2dzS0Jqd0lJQ2dFWUNDNFFBWUxFYzd3Q1NlNFF1MmdoUUlKYnRCQkEvY2VcIiwgaW1wb3J0Lm1ldGEudXJsKTtcbnZhciBfX19DU1NfTE9BREVSX0VYUE9SVF9fXyA9IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX0FQSV9TT1VSQ0VNQVBfSU1QT1JUX19fKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8wX19fID0gX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfMF9fXyk7XG4vLyBNb2R1bGVcbl9fX0NTU19MT0FERVJfRVhQT1JUX19fLnB1c2goW21vZHVsZS5pZCwgYEBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogXCJhZ0dyaWRBbHBpbmVcIjtcbiAgc3JjOiB1cmwoJHtfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8wX19ffSk7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbn1cbi5hZy10aGVtZS1hbHBpbmUsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmssXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayB7XG4gIC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcjogIzIxOTZmMztcbiAgLS1hZy1zZWxlY3RlZC1yb3ctYmFja2dyb3VuZC1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuMyk7XG4gIC0tYWctcm93LWhvdmVyLWNvbG9yOiByZ2JhKDMzLCAxNTAsIDI0MywgMC4xKTtcbiAgLS1hZy1jb2x1bW4taG92ZXItY29sb3I6IHJnYmEoMzMsIDE1MCwgMjQzLCAwLjEpO1xuICAtLWFnLWlucHV0LWZvY3VzLWJvcmRlci1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuNCk7XG4gIC0tYWctcmFuZ2Utc2VsZWN0aW9uLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMzMsIDE1MCwgMjQzLCAwLjIpO1xuICAtLWFnLXJhbmdlLXNlbGVjdGlvbi1iYWNrZ3JvdW5kLWNvbG9yLTI6IHJnYmEoMzMsIDE1MCwgMjQzLCAwLjM2KTtcbiAgLS1hZy1yYW5nZS1zZWxlY3Rpb24tYmFja2dyb3VuZC1jb2xvci0zOiByZ2JhKDMzLCAxNTAsIDI0MywgMC40OSk7XG4gIC0tYWctcmFuZ2Utc2VsZWN0aW9uLWJhY2tncm91bmQtY29sb3ItNDogcmdiYSgzMywgMTUwLCAyNDMsIDAuNTkpO1xuICAtLWFnLXJvdy1udW1iZXJzLXNlbGVjdGVkLWNvbG9yOiBjb2xvci1taXgoaW4gc3JnYiwgdHJhbnNwYXJlbnQsIHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpIDUwJSk7XG4gIC0tYWctYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgLS1hZy1mb3JlZ3JvdW5kLWNvbG9yOiAjMTgxZDFmO1xuICAtLWFnLWJvcmRlci1jb2xvcjogI2JhYmZjNztcbiAgLS1hZy1zZWNvbmRhcnktYm9yZGVyLWNvbG9yOiAjZGRlMmViO1xuICAtLWFnLWhlYWRlci1iYWNrZ3JvdW5kLWNvbG9yOiAjZjhmOGY4O1xuICAtLWFnLXRvb2x0aXAtYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjhmODtcbiAgLS1hZy1vZGQtcm93LWJhY2tncm91bmQtY29sb3I6ICNmY2ZjZmM7XG4gIC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yOiAjZjhmOGY4O1xuICAtLWFnLXN1YmhlYWRlci1iYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAtLWFnLWludmFsaWQtY29sb3I6ICNlMDI1MjU7XG4gIC0tYWctY2hlY2tib3gtdW5jaGVja2VkLWNvbG9yOiAjOTk5O1xuICAtLWFnLWFkdmFuY2VkLWZpbHRlci1qb2luLXBpbGwtY29sb3I6ICNmMDhlOGQ7XG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLWNvbHVtbi1waWxsLWNvbG9yOiAjYTZlMTk0O1xuICAtLWFnLWFkdmFuY2VkLWZpbHRlci1vcHRpb24tcGlsbC1jb2xvcjogI2YzYzA4YjtcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItdmFsdWUtcGlsbC1jb2xvcjogIzg1YzBlNDtcbiAgLS1hZy1maW5kLW1hdGNoLWNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcbiAgLS1hZy1maW5kLW1hdGNoLWJhY2tncm91bmQtY29sb3I6ICNmZmZmMDA7XG4gIC0tYWctZmluZC1hY3RpdmUtbWF0Y2gtY29sb3I6IHZhcigtLWFnLWZvcmVncm91bmQtY29sb3IpO1xuICAtLWFnLWZpbmQtYWN0aXZlLW1hdGNoLWJhY2tncm91bmQtY29sb3I6ICNmZmE1MDA7XG4gIC0tYWctY2hlY2tib3gtYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XG4gIC0tYWctY2hlY2tib3gtY2hlY2tlZC1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG4gIC0tYWctcmFuZ2Utc2VsZWN0aW9uLWJvcmRlci1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG4gIC0tYWctc2Vjb25kYXJ5LWZvcmVncm91bmQtY29sb3I6IHZhcigtLWFnLWZvcmVncm91bmQtY29sb3IpO1xuICAtLWFnLWlucHV0LWJvcmRlci1jb2xvcjogdmFyKC0tYWctYm9yZGVyLWNvbG9yKTtcbiAgLS1hZy1pbnB1dC1ib3JkZXItY29sb3ItaW52YWxpZDogdmFyKC0tYWctaW52YWxpZC1jb2xvcik7XG4gIC0tYWctaW5wdXQtZm9jdXMtYm94LXNoYWRvdzogMCAwIDJweCAwLjFyZW0gdmFyKC0tYWctaW5wdXQtZm9jdXMtYm9yZGVyLWNvbG9yKTtcbiAgLS1hZy1pbnB1dC1lcnJvci1mb2N1cy1ib3gtc2hhZG93OiAwIDAgMnB4IDAuMXJlbSB2YXIoLS1hZy1pbnZhbGlkLWNvbG9yKTtcbiAgLS1hZy1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1oZWFkZXItYmFja2dyb3VuZC1jb2xvcik7XG4gIC0tYWctbWVudS1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1oZWFkZXItYmFja2dyb3VuZC1jb2xvcik7XG4gIC0tYWctZmlsdGVyLXBhbmVsLWFwcGx5LWJ1dHRvbi1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XG4gIC0tYWctZmlsdGVyLXBhbmVsLWFwcGx5LWJ1dHRvbi1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcbiAgLS1hZy1kaXNhYmxlZC1mb3JlZ3JvdW5kLWNvbG9yOiByZ2JhKDI0LCAyOSwgMzEsIDAuNSk7XG4gIC0tYWctY2hpcC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI0LCAyOSwgMzEsIDAuMDcpO1xuICAtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcjogcmdiYSgxODYsIDE5MSwgMTk5LCAwLjMpO1xuICAtLWFnLWlucHV0LWRpc2FibGVkLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMTg2LCAxOTEsIDE5OSwgMC4xNSk7XG4gIC0tYWctYm9yZGVyczogc29saWQgMXB4O1xuICAtLWFnLWJvcmRlci1yYWRpdXM6IDNweDtcbiAgLS1hZy1ib3JkZXJzLXNpZGUtYnV0dG9uOiBub25lO1xuICAtLWFnLXNpZGUtYnV0dG9uLXNlbGVjdGVkLWJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAtLWFnLWhlYWRlci1jb2x1bW4tcmVzaXplLWhhbmRsZS1kaXNwbGF5OiBibG9jaztcbiAgLS1hZy1oZWFkZXItY29sdW1uLXJlc2l6ZS1oYW5kbGUtd2lkdGg6IDJweDtcbiAgLS1hZy1oZWFkZXItY29sdW1uLXJlc2l6ZS1oYW5kbGUtaGVpZ2h0OiAzMCU7XG4gIC0tYWctZ3JpZC1zaXplOiA2cHg7XG4gIC0tYWctaWNvbi1zaXplOiAxNnB4O1xuICAtLWFnLXJvdy1oZWlnaHQ6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDcpO1xuICAtLWFnLWhlYWRlci1oZWlnaHQ6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDgpO1xuICAtLWFnLWxpc3QtaXRlbS1oZWlnaHQ6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDQpO1xuICAtLWFnLWNvbHVtbi1zZWxlY3QtaW5kZW50LXNpemU6IHZhcigtLWFnLWljb24tc2l6ZSk7XG4gIC0tYWctc2V0LWZpbHRlci1pbmRlbnQtc2l6ZTogdmFyKC0tYWctaWNvbi1zaXplKTtcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItYnVpbGRlci1pbmRlbnQtc2l6ZTogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICsgdmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xuICAtLWFnLWNlbGwtaG9yaXpvbnRhbC1wYWRkaW5nOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAzKTtcbiAgLS1hZy1jZWxsLXdpZGdldC1zcGFjaW5nOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcbiAgLS1hZy13aWRnZXQtY29udGFpbmVyLXZlcnRpY2FsLXBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xuICAtLWFnLXdpZGdldC1jb250YWluZXItaG9yaXpvbnRhbC1wYWRkaW5nOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcbiAgLS1hZy13aWRnZXQtdmVydGljYWwtc3BhY2luZzogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMS41KTtcbiAgLS1hZy10b2dnbGUtYnV0dG9uLWhlaWdodDogMThweDtcbiAgLS1hZy10b2dnbGUtYnV0dG9uLXdpZHRoOiAyOHB4O1xuICAtLWFnLWZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBPeHlnZW4tU2FucywgVWJ1bnR1LCBDYW50YXJlbGwsXG4gICAgICBcIkhlbHZldGljYSBOZXVlXCIsIHNhbnMtc2VyaWY7XG4gIC0tYWctZm9udC1zaXplOiAxM3B4O1xuICAtLWFnLWljb24tZm9udC1mYW1pbHk6IGFnR3JpZEFscGluZTtcbiAgLS1hZy1zZWxlY3RlZC10YWItdW5kZXJsaW5lLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcbiAgLS1hZy1zZWxlY3RlZC10YWItdW5kZXJsaW5lLXdpZHRoOiAycHg7XG4gIC0tYWctc2VsZWN0ZWQtdGFiLXVuZGVybGluZS10cmFuc2l0aW9uLXNwZWVkOiAwLjNzO1xuICAtLWFnLXRhYi1taW4td2lkdGg6IDI0MHB4O1xuICAtLWFnLWNhcmQtc2hhZG93OiAwIDFweCA0cHggMXB4IHJnYmEoMTg2LCAxOTEsIDE5OSwgMC40KTtcbiAgLS1hZy1wb3B1cC1zaGFkb3c6IHZhcigtLWFnLWNhcmQtc2hhZG93KTtcbiAgLS1hZy1zaWRlLWJhci1wYW5lbC13aWR0aDogMjUwcHg7XG59XG5cbi5hZy10aGVtZS1hbHBpbmUtZGFyayB7XG4gIC0tYWctYmFja2dyb3VuZC1jb2xvcjogIzE4MWQxZjtcbiAgLS1hZy1mb3JlZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAtLWFnLWJvcmRlci1jb2xvcjogIzY4Njg2ZTtcbiAgLS1hZy1zZWNvbmRhcnktYm9yZGVyLWNvbG9yOiByZ2JhKDg4LCA4NiwgODIsIDAuNSk7XG4gIC0tYWctbW9kYWwtb3ZlcmxheS1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI0LCAyOSwgMzEsIDAuNjYpO1xuICAtLWFnLWhlYWRlci1iYWNrZ3JvdW5kLWNvbG9yOiAjMjIyNjI4O1xuICAtLWFnLXRvb2x0aXAtYmFja2dyb3VuZC1jb2xvcjogIzIyMjYyODtcbiAgLS1hZy1vZGQtcm93LWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XG4gIC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yOiAjMjIyNjI4O1xuICAtLWFnLXN1YmhlYWRlci1iYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xuICAtLWFnLWlucHV0LWRpc2FibGVkLWJhY2tncm91bmQtY29sb3I6ICMyODJjMmY7XG4gIC0tYWctaW5wdXQtZm9jdXMtYm94LXNoYWRvdzogMCAwIDJweCAwLjVweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSksIDAgMCA0cHggM3B4IHZhcigtLWFnLWlucHV0LWZvY3VzLWJvcmRlci1jb2xvcik7XG4gIC0tYWctaW5wdXQtZXJyb3ItZm9jdXMtYm94LXNoYWRvdzogMCAwIDJweCAwLjVweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSksXG4gICAgICAwIDAgNHB4IDNweCBjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvciksIHZhcigtLWFnLWludmFsaWQtY29sb3IpIDAuNSUpO1xuICAtLWFnLWNhcmQtc2hhZG93OiAwIDFweCAyMHB4IDFweCBibGFjaztcbiAgLS1hZy1kaXNhYmxlZC1mb3JlZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSk7XG4gIC0tYWctY2hpcC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDcpO1xuICAtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcjogcmdiYSgxMDQsIDEwNCwgMTEwLCAwLjMpO1xuICAtLWFnLWlucHV0LWRpc2FibGVkLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMTA0LCAxMDQsIDExMCwgMC4wNyk7XG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLWpvaW4tcGlsbC1jb2xvcjogIzdhM2EzNztcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItY29sdW1uLXBpbGwtY29sb3I6ICMzNTVmMmQ7XG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLW9wdGlvbi1waWxsLWNvbG9yOiAjNWEzMTY4O1xuICAtLWFnLWFkdmFuY2VkLWZpbHRlci12YWx1ZS1waWxsLWNvbG9yOiAjMzc0Yzg2O1xuICAtLWFnLWZpbmQtbWF0Y2gtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xuICAtLWFnLWZpbmQtYWN0aXZlLW1hdGNoLWNvbG9yOiB2YXIoLS1hZy1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgLS1hZy1maWx0ZXItcGFuZWwtYXBwbHktYnV0dG9uLWNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcbiAgLS1hZy1yb3ctbG9hZGluZy1za2VsZXRvbi1lZmZlY3QtY29sb3I6IHJnYmEoMjAyLCAyMDMsIDIwNCwgMC40KTtcbiAgLS1hZy1jZWxsLWJhdGNoLWVkaXQtdGV4dC1jb2xvcjogI2YzZDBiMztcbiAgY29sb3Itc2NoZW1lOiBkYXJrO1xufVxuXG5AbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKSB7XG4gIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIHtcbiAgICAtLWFnLWJhY2tncm91bmQtY29sb3I6ICMxODFkMWY7XG4gICAgLS1hZy1mb3JlZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIC0tYWctYm9yZGVyLWNvbG9yOiAjNjg2ODZlO1xuICAgIC0tYWctc2Vjb25kYXJ5LWJvcmRlci1jb2xvcjogcmdiYSg4OCwgODYsIDgyLCAwLjUpO1xuICAgIC0tYWctbW9kYWwtb3ZlcmxheS1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI0LCAyOSwgMzEsIDAuNjYpO1xuICAgIC0tYWctaGVhZGVyLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XG4gICAgLS1hZy10b29sdGlwLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XG4gICAgLS1hZy1vZGQtcm93LWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XG4gICAgLS1hZy1jb250cm9sLXBhbmVsLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XG4gICAgLS1hZy1zdWJoZWFkZXItYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcbiAgICAtLWFnLWlucHV0LWRpc2FibGVkLWJhY2tncm91bmQtY29sb3I6ICMyODJjMmY7XG4gICAgLS1hZy1pbnB1dC1mb2N1cy1ib3gtc2hhZG93OiAwIDAgMnB4IDAuNXB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KSwgMCAwIDRweCAzcHggdmFyKC0tYWctaW5wdXQtZm9jdXMtYm9yZGVyLWNvbG9yKTtcbiAgICAtLWFnLWlucHV0LWVycm9yLWZvY3VzLWJveC1zaGFkb3c6IDAgMCAycHggMC41cHggcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpLFxuICAgICAgICAwIDAgNHB4IDNweCBjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvciksIHZhcigtLWFnLWludmFsaWQtY29sb3IpIDAuNSUpO1xuICAgIC0tYWctY2FyZC1zaGFkb3c6IDAgMXB4IDIwcHggMXB4IGJsYWNrO1xuICAgIC0tYWctZGlzYWJsZWQtZm9yZWdyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpO1xuICAgIC0tYWctY2hpcC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDcpO1xuICAgIC0tYWctaW5wdXQtZGlzYWJsZWQtYm9yZGVyLWNvbG9yOiByZ2JhKDEwNCwgMTA0LCAxMTAsIDAuMyk7XG4gICAgLS1hZy1pbnB1dC1kaXNhYmxlZC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDEwNCwgMTA0LCAxMTAsIDAuMDcpO1xuICAgIC0tYWctYWR2YW5jZWQtZmlsdGVyLWpvaW4tcGlsbC1jb2xvcjogIzdhM2EzNztcbiAgICAtLWFnLWFkdmFuY2VkLWZpbHRlci1jb2x1bW4tcGlsbC1jb2xvcjogIzM1NWYyZDtcbiAgICAtLWFnLWFkdmFuY2VkLWZpbHRlci1vcHRpb24tcGlsbC1jb2xvcjogIzVhMzE2ODtcbiAgICAtLWFnLWFkdmFuY2VkLWZpbHRlci12YWx1ZS1waWxsLWNvbG9yOiAjMzc0Yzg2O1xuICAgIC0tYWctZmluZC1tYXRjaC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XG4gICAgLS1hZy1maW5kLWFjdGl2ZS1tYXRjaC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XG4gICAgLS1hZy1maWx0ZXItcGFuZWwtYXBwbHktYnV0dG9uLWNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcbiAgICAtLWFnLXJvdy1sb2FkaW5nLXNrZWxldG9uLWVmZmVjdC1jb2xvcjogcmdiYSgyMDIsIDIwMywgMjA0LCAwLjQpO1xuICAgIC0tYWctY2VsbC1iYXRjaC1lZGl0LXRleHQtY29sb3I6ICNmM2QwYjM7XG4gICAgY29sb3Itc2NoZW1lOiBkYXJrO1xuICB9XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1maWx0ZXItdG9vbHBhbmVsLWhlYWRlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci10b29scGFuZWwtc2VhcmNoLFxuLmFnLXRoZW1lLWFscGluZSAuYWctc3RhdHVzLWJhcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1yb3csXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1yb3ctbnVtYmVyLWNlbGwsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1wYW5lbC10aXRsZS1iYXItdGl0bGUsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1tdWx0aS1maWx0ZXItZ3JvdXAtdGl0bGUtYmFyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctZmlsdGVyLWNhcmQtdGl0bGUsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtaGVhZGVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1maWx0ZXItdG9vbHBhbmVsLXNlYXJjaCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhdHVzLWJhcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLXJvdyxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcm93LW51bWJlci1jZWxsLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1wYW5lbC10aXRsZS1iYXItdGl0bGUsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLW11bHRpLWZpbHRlci1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci1jYXJkLXRpdGxlLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtaGVhZGVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtc2VhcmNoLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXN0YXR1cy1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLXJvdyxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1yb3ctbnVtYmVyLWNlbGwsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGFuZWwtdGl0bGUtYmFyLXRpdGxlLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLW11bHRpLWZpbHRlci1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmlsdGVyLWNhcmQtdGl0bGUge1xuICBmb250LXdlaWdodDogNzAwO1xuICBjb2xvcjogdmFyKC0tYWctaGVhZGVyLWZvcmVncm91bmQtY29sb3IpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctcm93LFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1yb3csXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcm93IHtcbiAgZm9udC1zaXplOiBjYWxjKHZhcigtLWFnLWZvbnQtc2l6ZSkgKyAxcHgpO1xufVxuLmFnLXRoZW1lLWFscGluZSBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLFxuLmFnLXRoZW1lLWFscGluZSBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sXG4uYWctdGhlbWUtYWxwaW5lIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sXG4uYWctdGhlbWUtYWxwaW5lIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLFxuLmFnLXRoZW1lLWFscGluZSB0ZXh0YXJlYVtjbGFzc149YWctXSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayB0ZXh0YXJlYVtjbGFzc149YWctXSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIHRleHRhcmVhW2NsYXNzXj1hZy1dIHtcbiAgbWluLWhlaWdodDogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogNCk7XG4gIGJvcmRlci1yYWRpdXM6IHZhcigtLWFnLWJvcmRlci1yYWRpdXMpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSwgLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSwgLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSwgLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSwgLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIHRleHRhcmVhW2NsYXNzXj1hZy1dLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciB0ZXh0YXJlYVtjbGFzc149YWctXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciB0ZXh0YXJlYVtjbGFzc149YWctXSB7XG4gIHBhZGRpbmctbGVmdDogdmFyKC0tYWctZ3JpZC1zaXplKTtcbn1cblxuLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSwgLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSwgLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSwgLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSwgLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIHRleHRhcmVhW2NsYXNzXj1hZy1dLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCB0ZXh0YXJlYVtjbGFzc149YWctXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCB0ZXh0YXJlYVtjbGFzc149YWctXSB7XG4gIHBhZGRpbmctcmlnaHQ6IHZhcigtLWFnLWdyaWQtc2l6ZSk7XG59XG5cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXRhYixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctdGFiLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXRhYiB7XG4gIHBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDEuNSk7XG4gIHRyYW5zaXRpb246IGNvbG9yIDAuNHM7XG4gIGZsZXg6IDEgMSBhdXRvO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctdGFiLXNlbGVjdGVkLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy10YWItc2VsZWN0ZWQsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctdGFiLXNlbGVjdGVkIHtcbiAgY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbWVudSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbWVudSxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1tZW51IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yKTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXBhbmVsLWNvbnRlbnQtd3JhcHBlciAuYWctY29sdW1uLXNlbGVjdCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGFuZWwtY29udGVudC13cmFwcGVyIC5hZy1jb2x1bW4tc2VsZWN0LFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXBhbmVsLWNvbnRlbnQtd3JhcHBlciAuYWctY29sdW1uLXNlbGVjdCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWNvbnRyb2wtcGFuZWwtYmFja2dyb3VuZC1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1tZW51LWhlYWRlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbWVudS1oZWFkZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbWVudS1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1jb250cm9sLXBhbmVsLWJhY2tncm91bmQtY29sb3IpO1xuICBwYWRkaW5nLXRvcDogMXB4O1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctdGFicy1oZWFkZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXRhYnMtaGVhZGVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXRhYnMtaGVhZGVyIHtcbiAgYm9yZGVyLWJvdHRvbTogdmFyKC0tYWctYm9yZGVycykgdmFyKC0tYWctYm9yZGVyLWNvbG9yKTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1zZXR0aW5ncy1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZGF0YS1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnRzLXNldHRpbmdzLWdyb3VwLXRpdGxlLWJhcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnRzLWRhdGEtZ3JvdXAtdGl0bGUtYmFyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdGl0bGUtYmFyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1zZXR0aW5ncy1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWRhdGEtZ3JvdXAtdGl0bGUtYmFyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhciB7XG4gIHBhZGRpbmc6IHZhcigtLWFnLWdyaWQtc2l6ZSkgY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XG4gIGxpbmUtaGVpZ2h0OiBjYWxjKHZhcigtLWFnLWljb24tc2l6ZSkgKyB2YXIoLS1hZy1ncmlkLXNpemUpIC0gMnB4KTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0LW1pbmktdGh1bWJuYWlsLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydC1taW5pLXRodW1ibmFpbCxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydC1taW5pLXRodW1ibmFpbCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnQtc2V0dGluZ3MtbmF2LWJhcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtbmF2LWJhcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydC1zZXR0aW5ncy1uYXYtYmFyIHtcbiAgYm9yZGVyLXRvcDogdmFyKC0tYWctYm9yZGVycy1zZWNvbmRhcnkpIHZhcigtLWFnLXNlY29uZGFyeS1ib3JkZXItY29sb3IpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbiwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbHRyIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbiB7XG4gIG1hcmdpbi1yaWdodDogdmFyKC0tYWctZ3JpZC1zaXplKTtcbn1cblxuLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbiwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbiB7XG4gIG1hcmdpbi1sZWZ0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xufVxuXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10b29sYmFyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10b29sYmFyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIge1xuICBtYXJnaW4tdG9wOiB2YXIoLS1hZy1ncmlkLXNpemUpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10b29sYmFyLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciB7XG4gIHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICogMC41ICsgdmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xufVxuXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyIHtcbiAgcGFkZGluZy1yaWdodDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICogMC41ICsgdmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xufVxuXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAge1xuICBib3JkZXItbGVmdDogZGFzaGVkIDFweDtcbiAgYm9yZGVyLWxlZnQtY29sb3I6IHZhcigtLWFnLWJvcmRlci1jb2xvcik7XG4gIHBhZGRpbmctbGVmdDogdmFyKC0tYWctZ3JpZC1zaXplKTtcbiAgbWFyZ2luLWJvdHRvbTogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC10aXRsZS1iYXIge1xuICBwYWRkaW5nLXRvcDogMDtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC1jb250YWluZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWNvbnRhaW5lcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC1jb250YWluZXIge1xuICBwYWRkaW5nLWJvdHRvbTogMDtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWl0ZW06bGFzdC1jaGlsZCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAtaXRlbTpsYXN0LWNoaWxkLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWl0ZW06bGFzdC1jaGlsZCB7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG4uYWctdGhlbWUtYWxwaW5lLmFnLWRuZC1naG9zdCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyay5hZy1kbmQtZ2hvc3QsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyay5hZy1kbmQtZ2hvc3Qge1xuICBmb250LXNpemU6IGNhbGModmFyKC0tYWctZm9udC1zaXplKSAtIDFweCk7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zaWRlLWJ1dHRvbnMsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXNpZGUtYnV0dG9ucyxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zaWRlLWJ1dHRvbnMge1xuICB3aWR0aDogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogNSk7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zdGFuZGFyZC1idXR0b24sXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YW5kYXJkLWJ1dHRvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b24ge1xuICBmb250LWZhbWlseTogaW5oZXJpdDtcbiAgLW1vei1hcHBlYXJhbmNlOiBub25lO1xuICAgICAgIGFwcGVhcmFuY2U6IG5vbmU7XG4gIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tYWctYm9yZGVyLXJhZGl1cyk7XG4gIGJvcmRlcjogMXB4IHNvbGlkO1xuICBib3JkZXItY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xuICBjb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xuICBmb250LXdlaWdodDogNjAwO1xuICBwYWRkaW5nOiB2YXIoLS1hZy1ncmlkLXNpemUpIGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctc3RhbmRhcmQtYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhbmRhcmQtYnV0dG9uOmhvdmVyIHtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctcm93LWhvdmVyLWNvbG9yKTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXN0YW5kYXJkLWJ1dHRvbjphY3RpdmUsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YW5kYXJkLWJ1dHRvbjphY3RpdmUsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhbmRhcmQtYnV0dG9uOmFjdGl2ZSB7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xuICBjb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zdGFuZGFyZC1idXR0b246ZGlzYWJsZWQsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YW5kYXJkLWJ1dHRvbjpkaXNhYmxlZCxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246ZGlzYWJsZWQge1xuICBjb2xvcjogdmFyKC0tYWctZGlzYWJsZWQtZm9yZWdyb3VuZC1jb2xvcik7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWlucHV0LWRpc2FibGVkLWJhY2tncm91bmQtY29sb3IpO1xuICBib3JkZXItY29sb3I6IHZhcigtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tZHJvcC12ZXJ0aWNhbCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLWRyb3AtdmVydGljYWwsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLWRyb3AtdmVydGljYWwge1xuICBtaW4taGVpZ2h0OiA3NXB4O1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctY29sdW1uLWRyb3AtdmVydGljYWwtdGl0bGUtYmFyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC12ZXJ0aWNhbC10aXRsZS1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLWRyb3AtdmVydGljYWwtdGl0bGUtYmFyIHtcbiAgcGFkZGluZzogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tZHJvcC12ZXJ0aWNhbC1lbXB0eS1tZXNzYWdlLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC12ZXJ0aWNhbC1lbXB0eS1tZXNzYWdlLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLWVtcHR5LW1lc3NhZ2Uge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXI6IGRhc2hlZCAxcHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0tYWctYm9yZGVyLWNvbG9yKTtcbiAgbWFyZ2luOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcbiAgcGFkZGluZzogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tZHJvcC1lbXB0eS1tZXNzYWdlLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC1lbXB0eS1tZXNzYWdlLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1kcm9wLWVtcHR5LW1lc3NhZ2Uge1xuICBjb2xvcjogdmFyKC0tYWctZm9yZWdyb3VuZC1jb2xvcik7XG4gIG9wYWNpdHk6IDAuNzU7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1waWxsLXNlbGVjdCAuYWctY29sdW1uLWRyb3AsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBpbGwtc2VsZWN0IC5hZy1jb2x1bW4tZHJvcCxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1waWxsLXNlbGVjdCAuYWctY29sdW1uLWRyb3Age1xuICBtaW4taGVpZ2h0OiB1bnNldDtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXN0YXR1cy1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YXR1cy1iYXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhdHVzLWJhciB7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zdGF0dXMtbmFtZS12YWx1ZS12YWx1ZSxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhdHVzLW5hbWUtdmFsdWUtdmFsdWUsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhdHVzLW5hbWUtdmFsdWUtdmFsdWUge1xuICBmb250LXdlaWdodDogNzAwO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFnaW5nLW51bWJlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXBhZ2luZy1yb3ctc3VtbWFyeS1wYW5lbC1udW1iZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBhZ2luZy1udW1iZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBhZ2luZy1yb3ctc3VtbWFyeS1wYW5lbC1udW1iZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGFnaW5nLW51bWJlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1wYWdpbmctcm93LXN1bW1hcnktcGFuZWwtbnVtYmVyIHtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLWNlbGwtYnV0dG9uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbiB7XG4gIG9wYWNpdHk6IDAuNTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLWNlbGwtYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbjpob3ZlciB7XG4gIG9wYWNpdHk6IDAuNzU7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1yZWFkb25seS5hZy1pY29uLWdyaXAsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1yZWFkb25seSAuYWctaWNvbi1ncmlwLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1yZWFkb25seS5hZy1pY29uLWdyaXAsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtY29sdW1uLXJlYWRvbmx5IC5hZy1pY29uLWdyaXAsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLXNlbGVjdC1jb2x1bW4tcmVhZG9ubHkuYWctaWNvbi1ncmlwLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtY29sdW1uLXJlYWRvbmx5IC5hZy1pY29uLWdyaXAge1xuICBvcGFjaXR5OiAwLjM1O1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLWNlbGwtbWVudS1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1oZWFkZXItY2VsbC1maWx0ZXItYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctc2lkZS1idXR0b24tYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctdGFiOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1leHBhbmQtaWNvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1ncm91cC1pY29uczpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXNldC1maWx0ZXItZ3JvdXAtaWNvbnM6aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ncm91cC1leHBhbmRlZCAuYWctaWNvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWdyb3VwLWNvbnRyYWN0ZWQgLmFnLWljb246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydC1zZXR0aW5ncy1wcmV2OmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnQtc2V0dGluZ3MtbmV4dDpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctY29sdW1uLXNlbGVjdC1oZWFkZXItaWNvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZsb2F0aW5nLWZpbHRlci1idXR0b24tYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZSAuYWctZmlsdGVyLXRvb2xwYW5lbC1leHBhbmQ6aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydC1tZW51LWljb246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWhlYWRlci1jZWxsLW1lbnUtYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1oZWFkZXItY2VsbC1maWx0ZXItYnV0dG9uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1zaWRlLWJ1dHRvbi1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXRhYjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWV4cGFuZC1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZ3JvdXAtaWNvbnM6aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXNldC1maWx0ZXItZ3JvdXAtaWNvbnM6aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWdyb3VwLWV4cGFuZGVkIC5hZy1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ncm91cC1jb250cmFjdGVkIC5hZy1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydC1zZXR0aW5ncy1wcmV2OmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydC1zZXR0aW5ncy1uZXh0OmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLXNlbGVjdC1oZWFkZXItaWNvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmxvYXRpbmctZmlsdGVyLWJ1dHRvbi1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtZXhwYW5kOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydC1tZW51LWljb246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWNlbGwtbWVudS1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zaWRlLWJ1dHRvbi1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctdGFiOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWV4cGFuZC1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1ncm91cC1pY29uczpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zZXQtZmlsdGVyLWdyb3VwLWljb25zOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWdyb3VwLWV4cGFuZGVkIC5hZy1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWdyb3VwLWNvbnRyYWN0ZWQgLmFnLWljb246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtcHJldjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydC1zZXR0aW5ncy1uZXh0OmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtaGVhZGVyLWljb246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmxvYXRpbmctZmlsdGVyLWJ1dHRvbi1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmlsdGVyLXRvb2xwYW5lbC1leHBhbmQ6aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtbWVudS1pY29uOmhvdmVyIHtcbiAgY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLWNlbGwtbWVudS1idXR0b246aG92ZXIgLmFnLWljb24sXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1oZWFkZXItY2VsbC1maWx0ZXItYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZSAuYWctc2lkZS1idXR0b24tYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZsb2F0aW5nLWZpbHRlci1idXR0b24tYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1oZWFkZXItY2VsbC1tZW51LWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc2lkZS1idXR0b24tYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1mbG9hdGluZy1maWx0ZXItYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1oZWFkZXItY2VsbC1tZW51LWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1oZWFkZXItY2VsbC1maWx0ZXItYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXNpZGUtYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZsb2F0aW5nLWZpbHRlci1idXR0b24tYnV0dG9uOmhvdmVyIC5hZy1pY29uIHtcbiAgY29sb3I6IGluaGVyaXQ7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1maWx0ZXItYWN0aXZlIC5hZy1pY29uLWZpbHRlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmlsdGVyLWFjdGl2ZSAuYWctaWNvbi1maWx0ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmlsdGVyLWFjdGl2ZSAuYWctaWNvbi1maWx0ZXIge1xuICBjb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydC1zZXR0aW5ncy1jYXJkLWl0ZW0uYWctbm90LXNlbGVjdGVkOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydC1zZXR0aW5ncy1jYXJkLWl0ZW0uYWctbm90LXNlbGVjdGVkOmhvdmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0LXNldHRpbmdzLWNhcmQtaXRlbS5hZy1ub3Qtc2VsZWN0ZWQ6aG92ZXIge1xuICBvcGFjaXR5OiAwLjM1O1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbiwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbiB7XG4gIG1hcmdpbi1sZWZ0OiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcbiAgbWFyZ2luLXJpZ2h0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xufVxuXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b24sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uIHtcbiAgbWFyZ2luLXJpZ2h0OiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcbiAgbWFyZ2luLWxlZnQ6IHZhcigtLWFnLWdyaWQtc2l6ZSk7XG59XG5cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciAuYWctZmlsdGVyLXRvb2xwYW5lbC1ncm91cC1jb250YWluZXIsIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIC5hZy1maWx0ZXItdG9vbHBhbmVsLWdyb3VwLWNvbnRhaW5lciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctZmlsdGVyLXRvb2xwYW5lbC1ncm91cC1jb250YWluZXIge1xuICBwYWRkaW5nLWxlZnQ6IHZhcigtLWFnLWdyaWQtc2l6ZSk7XG59XG5cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCAuYWctZmlsdGVyLXRvb2xwYW5lbC1ncm91cC1jb250YWluZXIsIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWdyb3VwLWNvbnRhaW5lciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCAuYWctZmlsdGVyLXRvb2xwYW5lbC1ncm91cC1jb250YWluZXIge1xuICBwYWRkaW5nLXJpZ2h0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xufVxuXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmlsdGVyLXRvb2xwYW5lbC1pbnN0YW5jZS1maWx0ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmlsdGVyLXRvb2xwYW5lbC1pbnN0YW5jZS1maWx0ZXIge1xuICBib3JkZXI6IG5vbmU7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWNvbnRyb2wtcGFuZWwtYmFja2dyb3VuZC1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctZmlsdGVyLXRvb2xwYW5lbC1pbnN0YW5jZS1maWx0ZXIsIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyIHtcbiAgYm9yZGVyLWxlZnQ6IGRhc2hlZCAxcHg7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiB2YXIoLS1hZy1ib3JkZXItY29sb3IpO1xuICBtYXJnaW4tbGVmdDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICogMC41KTtcbn1cblxuLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlciB7XG4gIGJvcmRlci1yaWdodDogZGFzaGVkIDFweDtcbiAgYm9yZGVyLXJpZ2h0LWNvbG9yOiB2YXIoLS1hZy1ib3JkZXItY29sb3IpO1xuICBtYXJnaW4tcmlnaHQ6IGNhbGModmFyKC0tYWctaWNvbi1zaXplKSAqIDAuNSk7XG59XG5cbi5hZy10aGVtZS1hbHBpbmUgLmFnLXNldC1maWx0ZXItbGlzdCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc2V0LWZpbHRlci1saXN0LFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXNldC1maWx0ZXItbGlzdCB7XG4gIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAwLjUpO1xuICBwYWRkaW5nLWJvdHRvbTogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMC41KTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci1hZGQtYnV0dG9uIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1maWx0ZXItYWRkLWJ1dHRvbiAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1maWx0ZXItYWRkLWJ1dHRvbiAuYWctaWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWxheW91dC1hdXRvLWhlaWdodCAuYWctY2VudGVyLWNvbHMtdmlld3BvcnQsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sYXlvdXQtYXV0by1oZWlnaHQgLmFnLWNlbnRlci1jb2xzLWNvbnRhaW5lcixcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWxheW91dC1wcmludCAuYWctY2VudGVyLWNvbHMtdmlld3BvcnQsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sYXlvdXQtcHJpbnQgLmFnLWNlbnRlci1jb2xzLWNvbnRhaW5lcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbGF5b3V0LWF1dG8taGVpZ2h0IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbGF5b3V0LWF1dG8taGVpZ2h0IC5hZy1jZW50ZXItY29scy1jb250YWluZXIsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWxheW91dC1wcmludCAuYWctY2VudGVyLWNvbHMtdmlld3BvcnQsXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWxheW91dC1wcmludCAuYWctY2VudGVyLWNvbHMtY29udGFpbmVyLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWxheW91dC1hdXRvLWhlaWdodCAuYWctY2VudGVyLWNvbHMtdmlld3BvcnQsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbGF5b3V0LWF1dG8taGVpZ2h0IC5hZy1jZW50ZXItY29scy1jb250YWluZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbGF5b3V0LXByaW50IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sYXlvdXQtcHJpbnQgLmFnLWNlbnRlci1jb2xzLWNvbnRhaW5lciB7XG4gIG1pbi1oZWlnaHQ6IDE1MHB4O1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctZGF0ZS10aW1lLWxpc3QtcGFnZS1lbnRyeS1pcy1jdXJyZW50LFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1kYXRlLXRpbWUtbGlzdC1wYWdlLWVudHJ5LWlzLWN1cnJlbnQsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZGF0ZS10aW1lLWxpc3QtcGFnZS1lbnRyeS1pcy1jdXJyZW50IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1hZHZhbmNlZC1maWx0ZXItYnVpbGRlci1idXR0b24sXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWJ1dHRvbixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1hZHZhbmNlZC1maWx0ZXItYnVpbGRlci1idXR0b24ge1xuICBwYWRkaW5nOiB2YXIoLS1hZy1ncmlkLXNpemUpO1xuICBmb250LXdlaWdodDogNjAwO1xufVxuLmFnLXRoZW1lLWFscGluZSAuYWctbGlzdC1pdGVtLWhvdmVyZWQ6OmFmdGVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1saXN0LWl0ZW0taG92ZXJlZDo6YWZ0ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbGlzdC1pdGVtLWhvdmVyZWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1waWxsIC5hZy1waWxsLWJ1dHRvbjpob3Zlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGlsbCAuYWctcGlsbC1idXR0b246aG92ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGlsbCAuYWctcGlsbC1idXR0b246aG92ZXIge1xuICBjb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XG59XG4uYWctdGhlbWUtYWxwaW5lIC5hZy1oZWFkZXItaGlnaGxpZ2h0LWJlZm9yZTo6YWZ0ZXIsXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1oZWFkZXItaGlnaGxpZ2h0LWFmdGVyOjphZnRlcixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWhpZ2hsaWdodC1iZWZvcmU6OmFmdGVyLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1oZWFkZXItaGlnaGxpZ2h0LWFmdGVyOjphZnRlcixcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1oZWFkZXItaGlnaGxpZ2h0LWJlZm9yZTo6YWZ0ZXIsXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWhpZ2hsaWdodC1hZnRlcjo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcbn1cbi5hZy10aGVtZS1hbHBpbmUgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWl0ZW0tYnV0dG9uLWRpc2FibGVkIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZSAuYWctZGlzYWJsZWQgLmFnLWljb24sXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1ncm91cC1yZWFkb25seSAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUgW2Rpc2FibGVkXSAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctYWR2YW5jZWQtZmlsdGVyLWJ1aWxkZXItaXRlbS1idXR0b24tZGlzYWJsZWQgLmFnLWljb24sXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWRpc2FibGVkIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1ncm91cC1yZWFkb25seSAuYWctaWNvbixcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBbZGlzYWJsZWRdIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWl0ZW0tYnV0dG9uLWRpc2FibGVkIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWRpc2FibGVkIC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtY29sdW1uLWdyb3VwLXJlYWRvbmx5IC5hZy1pY29uLFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgW2Rpc2FibGVkXSAuYWctaWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1hZy1kaXNhYmxlZC1mb3JlZ3JvdW5kLWNvbG9yKTtcbn1cbmAsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL2FnLWdyaWQtY29tbXVuaXR5L3N0eWxlcy9hZy10aGVtZS1hbHBpbmUuY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0VBQ0UsMkJBQTJCO0VBQzNCLDRDQUErNk87RUFDLzZPLG1CQUFtQjtFQUNuQixrQkFBa0I7QUFDcEI7QUFDQTs7O0VBR0UsaUNBQWlDO0VBQ2pDLDJEQUEyRDtFQUMzRCw2Q0FBNkM7RUFDN0MsZ0RBQWdEO0VBQ2hELHNEQUFzRDtFQUN0RCw4REFBOEQ7RUFDOUQsaUVBQWlFO0VBQ2pFLGlFQUFpRTtFQUNqRSxpRUFBaUU7RUFDakUsbUdBQW1HO0VBQ25HLDJCQUEyQjtFQUMzQiw4QkFBOEI7RUFDOUIsMEJBQTBCO0VBQzFCLG9DQUFvQztFQUNwQyxxQ0FBcUM7RUFDckMsc0NBQXNDO0VBQ3RDLHNDQUFzQztFQUN0Qyw0Q0FBNEM7RUFDNUMscUNBQXFDO0VBQ3JDLDJCQUEyQjtFQUMzQixtQ0FBbUM7RUFDbkMsNkNBQTZDO0VBQzdDLCtDQUErQztFQUMvQywrQ0FBK0M7RUFDL0MsOENBQThDO0VBQzlDLGlEQUFpRDtFQUNqRCx5Q0FBeUM7RUFDekMsd0RBQXdEO0VBQ3hELGdEQUFnRDtFQUNoRCwwREFBMEQ7RUFDMUQsMERBQTBEO0VBQzFELGdFQUFnRTtFQUNoRSwyREFBMkQ7RUFDM0QsK0NBQStDO0VBQy9DLHdEQUF3RDtFQUN4RCw4RUFBOEU7RUFDOUUseUVBQXlFO0VBQ3pFLDhEQUE4RDtFQUM5RCw2REFBNkQ7RUFDN0QsZ0VBQWdFO0VBQ2hFLDhFQUE4RTtFQUM5RSxxREFBcUQ7RUFDckQsa0RBQWtEO0VBQ2xELDBEQUEwRDtFQUMxRCwrREFBK0Q7RUFDL0QsdUJBQXVCO0VBQ3ZCLHVCQUF1QjtFQUN2Qiw4QkFBOEI7RUFDOUIsdURBQXVEO0VBQ3ZELCtDQUErQztFQUMvQywyQ0FBMkM7RUFDM0MsNENBQTRDO0VBQzVDLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsOENBQThDO0VBQzlDLGlEQUFpRDtFQUNqRCxvREFBb0Q7RUFDcEQsbURBQW1EO0VBQ25ELGdEQUFnRDtFQUNoRCw2RkFBNkY7RUFDN0YsMkRBQTJEO0VBQzNELHVEQUF1RDtFQUN2RCxxRUFBcUU7RUFDckUsdUVBQXVFO0VBQ3ZFLDZEQUE2RDtFQUM3RCwrQkFBK0I7RUFDL0IsOEJBQThCO0VBQzlCO2tDQUNnQztFQUNoQyxvQkFBb0I7RUFDcEIsbUNBQW1DO0VBQ25DLGdFQUFnRTtFQUNoRSxzQ0FBc0M7RUFDdEMsa0RBQWtEO0VBQ2xELHlCQUF5QjtFQUN6Qix3REFBd0Q7RUFDeEQsd0NBQXdDO0VBQ3hDLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFLDhCQUE4QjtFQUM5QiwyQkFBMkI7RUFDM0IsMEJBQTBCO0VBQzFCLGtEQUFrRDtFQUNsRCwyREFBMkQ7RUFDM0QscUNBQXFDO0VBQ3JDLHNDQUFzQztFQUN0QyxzQ0FBc0M7RUFDdEMsNENBQTRDO0VBQzVDLHFDQUFxQztFQUNyQyw2Q0FBNkM7RUFDN0MsbUhBQW1IO0VBQ25IOzhGQUM0RjtFQUM1RixzQ0FBc0M7RUFDdEMsd0RBQXdEO0VBQ3hELHFEQUFxRDtFQUNyRCwwREFBMEQ7RUFDMUQsK0RBQStEO0VBQy9ELDZDQUE2QztFQUM3QywrQ0FBK0M7RUFDL0MsK0NBQStDO0VBQy9DLDhDQUE4QztFQUM5QyxpREFBaUQ7RUFDakQsd0RBQXdEO0VBQ3hELGdFQUFnRTtFQUNoRSxnRUFBZ0U7RUFDaEUsd0NBQXdDO0VBQ3hDLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFO0lBQ0UsOEJBQThCO0lBQzlCLDJCQUEyQjtJQUMzQiwwQkFBMEI7SUFDMUIsa0RBQWtEO0lBQ2xELDJEQUEyRDtJQUMzRCxxQ0FBcUM7SUFDckMsc0NBQXNDO0lBQ3RDLHNDQUFzQztJQUN0Qyw0Q0FBNEM7SUFDNUMscUNBQXFDO0lBQ3JDLDZDQUE2QztJQUM3QyxtSEFBbUg7SUFDbkg7Z0dBQzRGO0lBQzVGLHNDQUFzQztJQUN0Qyx3REFBd0Q7SUFDeEQscURBQXFEO0lBQ3JELDBEQUEwRDtJQUMxRCwrREFBK0Q7SUFDL0QsNkNBQTZDO0lBQzdDLCtDQUErQztJQUMvQywrQ0FBK0M7SUFDL0MsOENBQThDO0lBQzlDLGlEQUFpRDtJQUNqRCx3REFBd0Q7SUFDeEQsZ0VBQWdFO0lBQ2hFLGdFQUFnRTtJQUNoRSx3Q0FBd0M7SUFDeEMsa0JBQWtCO0VBQ3BCO0FBQ0Y7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBd0JFLGdCQUFnQjtFQUNoQix3Q0FBd0M7QUFDMUM7QUFDQTs7O0VBR0UsMENBQTBDO0FBQzVDO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXFCRSx5Q0FBeUM7RUFDekMsc0NBQXNDO0FBQ3hDO0FBQ0E7RUFDRSxpQ0FBaUM7QUFDbkM7O0FBRUE7RUFDRSxrQ0FBa0M7QUFDcEM7O0FBRUE7OztFQUdFLHdDQUF3QztFQUN4QyxzQkFBc0I7RUFDdEIsY0FBYztBQUNoQjtBQUNBOzs7RUFHRSxvQ0FBb0M7QUFDdEM7QUFDQTs7O0VBR0UsMERBQTBEO0FBQzVEO0FBQ0E7OztFQUdFLDBEQUEwRDtBQUM1RDtBQUNBOzs7RUFHRSwwREFBMEQ7RUFDMUQsZ0JBQWdCO0FBQ2xCO0FBQ0E7OztFQUdFLHVEQUF1RDtBQUN6RDtBQUNBOzs7Ozs7Ozs7Ozs7RUFZRSwwREFBMEQ7RUFDMUQsa0VBQWtFO0FBQ3BFO0FBQ0E7OztFQUdFLDRDQUE0QztBQUM5QztBQUNBOzs7RUFHRSx3RUFBd0U7QUFDMUU7QUFDQTtFQUNFLGlDQUFpQztBQUNuQzs7QUFFQTtFQUNFLGdDQUFnQztBQUNsQzs7QUFFQTs7Ozs7O0VBTUUsK0JBQStCO0FBQ2pDO0FBQ0E7RUFDRSx1RUFBdUU7QUFDekU7O0FBRUE7RUFDRSx3RUFBd0U7QUFDMUU7O0FBRUE7OztFQUdFLHVCQUF1QjtFQUN2Qix5Q0FBeUM7RUFDekMsaUNBQWlDO0VBQ2pDLDRDQUE0QztBQUM5QztBQUNBOzs7RUFHRSxjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGdCQUFnQjtFQUNoQixnQkFBZ0I7QUFDbEI7QUFDQTs7O0VBR0UsaUJBQWlCO0FBQ25CO0FBQ0E7OztFQUdFLGdCQUFnQjtBQUNsQjtBQUNBOzs7RUFHRSwwQ0FBMEM7RUFDMUMsZ0JBQWdCO0FBQ2xCO0FBQ0E7OztFQUdFLG9DQUFvQztBQUN0QztBQUNBOzs7RUFHRSxvQkFBb0I7RUFDcEIscUJBQWdCO09BQWhCLGdCQUFnQjtFQUNoQix3QkFBd0I7RUFDeEIsc0NBQXNDO0VBQ3RDLGlCQUFpQjtFQUNqQiwyQ0FBMkM7RUFDM0Msb0NBQW9DO0VBQ3BDLDRDQUE0QztFQUM1QyxnQkFBZ0I7RUFDaEIsMERBQTBEO0FBQzVEO0FBQ0E7OztFQUdFLDJDQUEyQztFQUMzQywyQ0FBMkM7QUFDN0M7QUFDQTs7O0VBR0UsMkNBQTJDO0VBQzNDLCtDQUErQztFQUMvQyxpQ0FBaUM7QUFDbkM7QUFDQTs7O0VBR0UsMENBQTBDO0VBQzFDLDJEQUEyRDtFQUMzRCxtREFBbUQ7QUFDckQ7QUFDQTs7O0VBR0UsZ0JBQWdCO0FBQ2xCO0FBQ0E7OztFQUdFLHNDQUFzQztFQUN0QyxtQkFBbUI7QUFDckI7QUFDQTs7O0VBR0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixrQkFBa0I7RUFDbEIsb0NBQW9DO0VBQ3BDLHFDQUFxQztFQUNyQyxzQ0FBc0M7QUFDeEM7QUFDQTs7O0VBR0UsaUNBQWlDO0VBQ2pDLGFBQWE7QUFDZjtBQUNBOzs7RUFHRSxpQkFBaUI7QUFDbkI7QUFDQTs7O0VBR0UsbUJBQW1CO0FBQ3JCO0FBQ0E7OztFQUdFLGdCQUFnQjtBQUNsQjtBQUNBOzs7Ozs7RUFNRSxnQkFBZ0I7QUFDbEI7QUFDQTs7O0VBR0UsWUFBWTtBQUNkO0FBQ0E7OztFQUdFLGFBQWE7QUFDZjtBQUNBOzs7Ozs7RUFNRSxhQUFhO0FBQ2Y7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbURFLG9DQUFvQztBQUN0QztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7RUFlRSxjQUFjO0FBQ2hCO0FBQ0E7OztFQUdFLG9DQUFvQztBQUN0QztBQUNBOzs7RUFHRSxhQUFhO0FBQ2Y7QUFDQTtFQUNFLDBDQUEwQztFQUMxQyxpQ0FBaUM7QUFDbkM7O0FBRUE7RUFDRSwyQ0FBMkM7RUFDM0MsZ0NBQWdDO0FBQ2xDOztBQUVBO0VBQ0UsaUNBQWlDO0FBQ25DOztBQUVBO0VBQ0Usa0NBQWtDO0FBQ3BDOztBQUVBOzs7RUFHRSxZQUFZO0VBQ1osMERBQTBEO0FBQzVEO0FBQ0E7RUFDRSx1QkFBdUI7RUFDdkIseUNBQXlDO0VBQ3pDLDRDQUE0QztBQUM5Qzs7QUFFQTtFQUNFLHdCQUF3QjtFQUN4QiwwQ0FBMEM7RUFDMUMsNkNBQTZDO0FBQy9DOztBQUVBOzs7RUFHRSw0Q0FBNEM7RUFDNUMsK0NBQStDO0FBQ2pEO0FBQ0E7OztFQUdFLG9DQUFvQztBQUN0QztBQUNBOzs7Ozs7Ozs7Ozs7RUFZRSxpQkFBaUI7QUFDbkI7QUFDQTs7O0VBR0UsK0NBQStDO0FBQ2pEO0FBQ0E7OztFQUdFLDRCQUE0QjtFQUM1QixnQkFBZ0I7QUFDbEI7QUFDQTs7O0VBR0UsK0NBQStDO0FBQ2pEO0FBQ0E7OztFQUdFLG9DQUFvQztBQUN0QztBQUNBOzs7Ozs7RUFNRSwrQ0FBK0M7QUFDakQ7QUFDQTs7Ozs7Ozs7Ozs7O0VBWUUsMENBQTBDO0FBQzVDXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIkBmb250LWZhY2Uge1xcbiAgZm9udC1mYW1pbHk6IFxcXCJhZ0dyaWRBbHBpbmVcXFwiO1xcbiAgc3JjOiB1cmwoZGF0YTpmb250L3dvZmYyO2NoYXJzZXQ9dXRmLTg7YmFzZTY0LGQwOUdNZ0FCQUFBQUFCWWdBQXNBQUFBQUx5UUFBQlhRQUFFQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFISXRLQm1BQWpSSUtzbnlwUEFFMkFpUURnbWdMZ1RZQUJDQUZoRVlIaGtVYjVDaGxCR3djQVBIWVNVQVVKWE16RWxGQktjNysvME9DTmthSStISGFtbEpBa3huUnBrU1Q5dTVldi9YR283SFowMzVmcitKU1lqRFFJeEZDV0dKSis2WXhNVXZudWUyQUljZlFlYy85VHh5ekRaVEREa2xDa3lDYUkyZVRQSUZDb1FnbFl3bm9WVFdna2RXdnF6U0J1eEw2b0p2Zks0UTJOZjFlL1dJR0pCQ2tobFJPMUtieGh2bVc0VGI3ZzdiMUQxYU1aaTNRdzhKQ0d4QUZkWmVvT2ZQclltSUhSaDFjVk9GVjRFVjZ0VmNWL05DTDFGOEJNQVBQUnZqZzZMYUxTV00wV0xlcDNLcHV0S29iT1NGaFprVWRPRFdnWmZlWThjaWFzMVg1Sk4va1M0S3NHYkltZ3RUZHkrUXJ1ajlUMzNLdFNlWWJsblBLbU8zM3ZlNFlkSmlFazNoQ25Fc0UvSi9Pc2wwZElNOFJGOTMxMUhXajBheXQ3Njlacit5ajJWa2lyWTUwckFQaU1GVEUxdnJ5WWg5N1E2Z0FWVW1aVk1CbHVpdjY5S21wYUZLV1Z6UnRzSlJER1Q2QXpTNGxTSEdhSzhLSVhmYjRGYm5veGpUd2VJU1NZNnRqYk5VTmJMV1JoQ2dXWU9URlI3NGRBU3B0dXlSTnpiZ0JNbWNQZlhxRGFjVHN1Z0hQcThmWlUwL3ZnM2FUeUpJdWdZWmNjazlHMDhnbi82TWx4c2RHTnBoZkx5ckpmS0V2K2t0YXlhaTZUUkZKMmp3M0hhTlJjUWFUSUluU3F6Rk5GcHVzYkU3Q0xaaWtKTk1IUWhNSW5TSE1sbTZWYlVtT3lzdXhmbDlYZ09OanA4ODBtdC9ZWmRtbFlRb3JGQVpORzZkSXFkdDFTU2lLRzJENmJDNlZYYjMxQXFvbnBCSThqQ2RQMGVOZ1hOZklWN2hjaWJ3ZGtuQ2xjT3NXQzM5NE1kTm5iTGtpeCtqODE2aDJ5dXFTYTZ6b2NKbnNMeWpiRVU5ZDNCUmloQzJFd2RFSnR1dXE1dm9tcmsvbGJ0bmNTbDlITUQxY0EvbTdyNHlKeWxoMHp2UElGeHVTL0Myd0h5NlA0c3cxaVJSNjJhNHJySSsrcllzWjRUYlJhc1ZBNkJEOWc4ai9YSkRHdG9wUURhczNsamZQODgzUEF6ZDlqQ0pTRFg2TWp2eW9pZmJpU1hjbm5yQlMwY2JHRDc3TDFJdnQrcW5DbWxvUWR4SVBuZkZFNWRiWXh0THVsOUk0TExpOVJSUnVYSW9aNm1KZFh4ajlZa1ozbEZRQmYvMjRXc3B3Ymh1NUloSHUreUlaaVZFbEpkNU54dWxVam9mR2VNNGsxcFdCY0x4bjdFdGRHeEV0VFY2T29NRDJEeW5oMGdmUmFEWmJDcGdkTlpBNTBOeWhMUG13U0Vja1RGdTJhellyUDJ3Y1FUT0RQZktJY0tvZWxZMmZMdmhQUmlsYXpMMEd1OEVlK2QvVWxQTlhiZE4wektGVVBVYmRPV05NclhPbVFielREalFtZ2tKVzNQNGh5aHJLVnMzT25rdGs5SWZlbXhMY253YkhoS2loYklKTUVvckpXYWRWNjkvenloY24wa3RRckkzOVl1QW5odnY2VGlYU0xPR0dGdEdERUllbmtsVUR0aFlsQXNVcy9Ed2NabEI3U0kwc3RzMlR2MzVGcW1yZFZWYmhsaS8ydzFXZWNyQ1JCRmF5b0o1emNVU0dlc0pFWHI4ck9sd2V2KzVmemdqSi9zUWpOTWpXczZQQXZmc2ZQcDdyQ3lxUVVYTE1YdEhhY2Y0SXYzVWxucHV4dTVCU1R1MWJVQTJRT0hzT09rRUJXZi95cXVna1A3SjdUS1NRdEZVdFdnWnZaY056Ny94SWYrTC8vK3R5MzBzZkVrelk2eTFtTW1UbTYxY3RPL1lMQWxGZHptR09vd1BQTlhTNDVWMWlDa1BKSlRCazZSa1lpNURJaUd4Uk1WUmNRbEpLdXBOYlZrNWVRVkZKV2NXRVNWTmptR244Q1hGT1ZVMWRRMVBMdkFXTGxpeGJzV3JOdWcyYnR0UnQyN0ZMbHJObjM0RkRSNDZkT0hYbTNJVkxWNjRoU2pHYnladjhueisrNm5oc3BMVU5kSlo4WVliUUYzZ3d0SHFETWFycHFvSGlvTVY3UWRjMTJRUU9rWEZ3bUt5Q0kyUVJIQ1did1RFeUJZNlRuZUFFbVFBbnlUSTRSV2JBR2JJQ3pwSWxjSTVzQWVmSkhMaEFac0ZGc2cxY0pwUGdDbGtBVjhrMHVFYTJndXRrQjdoQjVzRk5zZ1p1a2UxZ1BYaTdJQUc1QndxUUFBdUlnQXFZZ0F1RVFBcVVRQXVNd0FxY3dBdUNJQXFTSUF1S29BcWFvQXVHWUFxV1lBdU80QXFlNEF1QkVBcVJFQXVKa0FxWmtBdUZVQXFWVUF1TjBBcWQwUHVmYnBEM1JtRVNaaU9IdEl4NlNHdldzd203Y0FpbmNBa1A0U204aExjeEJPa3poaUY5czcyZjhPY2VvQXE3YjgrekFaNUNXUmRVdHBtVnhHc1A4eWdYQkpUbXJvemc0MktGcFkvOEZWK0MxVTFHbEsvTnQySU5VZm5NdDl0cXp2RUxEbitPSkZrNzNyV1A4bXJHaU10Vk5RUkZoWlZzS1FjQ1dabU1KQlZ4NG5wWXdRNXhvVUwveldhelV6WlpLcjlkdEJvanNwRXlrWlRTTmhuWHJqYmRKRDAzQTZrbVZTUm5sTTNxWUxBdEF6RFdsWHN5cVViN2ZGWmJocWVkZGlYVkg1TnVRd0RwRVNMSFh2SDRsclVBb0FRRVlZQ3pZRGVoaXhoZmxhQWt6dnNvWVlzcGp4SFdIZWU4REpra2QyRTNUU3VTWnBJNnUraTAwY1hpclM0R2EvNEJkbjdCU0lxek5PVkpvbUVQWWhnZ0ZidVE5b3A1N3hqdzZjZnY0MWV0aHllaDN6anhZSXZDcVVydlQ3TWpCTU9hN3hYL1BvUU55aGRVa3Iva2xPWWk1YlpEUUg5dXZZVEdsTklFTGVRTjl5QVh6bGhlN0VZdVRaYU1TS01GekdmQWc3MUI2bGZvejNGUU5zQnJ2RUNkQVc5d2hWcE5NRkVrcGlwY2MxaFQ3TG1BTDRNVy90eTdFTnppRDlLQ1VNUzRzMDh2bE12SVBGQXRsWFpBWSsvUmk5ZzZmeGpvT2RNUlMxVmtIZ1A2OW9wVkc1alBXemJWRDUxRDVoam5xQk9aaTBVYld6Vm9sQTZJQjZwSGpLTzFwZlpYaXJtYTVwVE1NdEJ0V3hpOVg3QXJSVTU1UGdvTGUyMGRSRWd1bCs0NEloUEZNdnpGRllxenMzWmFXS2J5Z28yR1hxK2J6U1kwM21ha2Nod1FUVFJhTFd6TjdqWFBIZElQbjdjdUhqV09YRmhwUHV1WkRNWUxsV2J5TzZxbklscUt1TmRkWVYvSWFrTnR6Z3p6R3dleFZXbW5QTm9pWFdNUDBNY1JhaHZ0N0RNUGlFeTNjKzlEWmhVYWF4UTFTZWlLVklLMjlMcGlLa1NPMVJmRkZxWHFxTjVzTWpGNnNrWFAxYWMxdWdKYlBOVW56T1RLQkV0ZWJFTDlKTnJpemFvMk4xZ3RYOWJyUktxd3IwVmVEdGFiSlpuWUswUmprNmRmWFkwQTRtWXd2SktDTk9RYkdFOFJxbUFYNGdoaWFoM01hbkpLRFFSZ1B3akJKUm9FQnJDT0JZSWc2RlYwVTVKY0NXem1CZ2Q0U3BMVExKZ3hiajdGR2JrV1JsRHg1QWFrUzZheGZnU3c5Zmg2NDlvakJJYXVEU2lNM0hndCtGZDl3ZEw5QVJoY2FRR1BZQlVMUGNrVTBvM0I5UE5nTGVoQzhHZ2piZFlMYU1Vem5HZ1crRUtmSDE3Tk1oTGpsQktXb0h3QkppUWoxRWVpOFpoMHBTbWJ6Ymg2dVFIMFRCdHBhTWNUODlFZ3RBeGFoSE1MV0JXOWJGYU4ycktRRjRNZ3hDcUw1cC9maEtQdm4zMlg3NWhhVzNnd0tvODdOTzdjSENMWTdic25IWm8zaXBINGluMlJndEJPN3N5Nk5VNk8xb1p1SFRHQUN6YTJvd2NITXUxMG96SDRxOFhiNnZWWjMvU2RhVGFIZkozWjJXck4vYjQzNUdud3N5K0h0bGJxd3ZibnMwZEROZkp4RWhObnI1eUZoSStiRHprV3VUMzM3c1RhME5YNmNBeFpmUmlHM0RTZkRTSVk0bjZBaCt4NE1hZHZINW9GTUwrREFNNk9CMnM5My9JdDMrcmJ4QmF6SDR4TnpPb2JvL0hXaWxIalkzUG9XRDY5NDJVQUJJOUpaY1BGdnpZTVFpdXdCM1d2cEd5UzNLOHFHVlZXVmJwUjRkMkppU3haWWxaMlJxd0R0dGRuSlIrMjRPNkpDYUo0UGIxWEI1Tm5xSEh5NlZnSzlGV1ozcXc5MDQ5dDJYYWRwbG1YQVFKb2RsTHREd2lLQWxCZDRHeWhGM0MvMVJLcG9UMFpZSmpSc0R0SCtwRzR4M3hodkxTZTY4L1dZa3FmdG9Zd2dmbzVUTkNnV1JYZ21RdjZ0Q2lzU2RabmlENDFiTFNhYWlRVDlvUzZQVUZ2TC90YWFPaW1DVmFiSHVjYjRBek1qNDNHRW14VWVWeTVyVEFoUHI5SmhiWWNXQ0p3T3ZiaTFLTWpTcUxJVHkrc1RaM0kwbkZwRVlsbGFXRlVUalJGa2JUdmJ0czJMc0kyS0FucXhpNGVXenZ0KzJUbFJheEpiaExmRUFMaGpHTkVlZDRTcUwydGJIN2tPS1ptNnhIWEZ0bUhvVHdyVUFHdUlaak0rcWNyMnlPRTJyb216Y0E1VTkwUjVZSk0yWUF1VkpLTjhaY0hnOC9oMW9tNkNyVkVBb3g3Tmk0SEFPR3RFWTVZVFRVblhJRXdpSEZYWitGWVRVa0Vadk1IcmYxQzhwMHZzQkRadUdKQ2NzcjNrLy9BLzMxVXh2L0FIRTg2ZnZ1WXBteDc4VVl5TnRIMVhYU2NIWnd2NXJBZzRSZDBtaGdMQmdkK0w3My81WC95KzUyNStnbGtBRVBmdHRmMXpPdWFNNmRyWHM5M3Bybi9yams5ODc1ajZGNVl0SE9DSWhUWXdlc0FBL3VEdm1iZ0dzaGh3NGloczlQUVpZQzRSV1piNzRqYjNxZnNkb1EzL0hqODJMWnVicW1wRjg1djJwU2FsdTdNRGd0dkNVOHU3TEh0RzRwZTI1eWFHdjQ0dFhidHlySXlLalVwOFlMZTJJWHpGM1lsYmQ4KzV3OE4weDhVNE04ay9wd0QvVGRIZER6ZGdONk1CTmxwNTNYVmcwZGJSSHgzalhzMmZDVXdFVG4ralEzK0trTDFUWjk1eFIvWXF0M1cvOHBDRlJ1VWN1VVYxUlg0SEp1Yko1WG1sYjdWZ1VVVVppNXlBc0h0RDlXVkhjMFQ1SHNvd2RYQk1jRlZ3UUxyMnFxWXZ1K20xNXZPN2htVXU5WWhZdWZIbE9hMTkrM25zbTY3T2xmSGpLeVJ1L21mN1VCY1BCS0NVSnZWRGoySjdUd25qMzFjM3lPVnZqazV6TEdPcTNZN01obHU3aXpIeTk5UXV6bU92VFV0ZjlyVHMxSEh0UjdmQmV1aDIvVzFPNnEzNkhKYjQxQXJTbnZsalRyWTVHK1Z1cnR2UEkvMkpjd0pQY0loR2FIZzFtUFhtV0pMWS9Edk1KcVdPUjBxWkhDdlJWcmJya0Yxc01NK2R1eHh3WU9zNjNja1lnNVBFOFBWVkxtTGhsdjE0akVhSGlZdTdTNXNDeTd3NWJGbUZkNkFKb1lYeEZxYjdIbXBMOVo0S2Zhd01iYnZNRUlKN2tydlNzTWVXblhDNkJGK1pRK2gvRGdNMHIvTm9WM1NNWi9kN1F1NTNhUHI1alNNZHNlZDZQNC9FL0x3dk5XM2lMUFdUbEgyOUpUVWhxenU0NHZST1F4WFJtek8yT3llMkdrMGF5ZGZKeFJheUxoT3hnOE4zMWNudXVFcXFWSnBRb3F6amJLMjNsSHBuRkNCVEh2NkdsbXA1ZFpuZzFIZTF1T1ZMaEltcDFhVVdGK1ZaY1l3eFNWbDR3WHEzOVJzMCtyWU1EV0hvd3lMdGJVcTd1SmxSWUVxZ3FkU3BZclkrUXh4cVVUOUhNZ1pxdENQM254dnpuTjFTUmxUWEh4ajBWdXY5TFplbzJ5SHlpTTRvK0lyZUtVTHB4cERLNk9taVdzQ0NZSzlPcGYzSFNGenB4N2Y5UnYydU5jZTdIdjBHTDd4VHh4WHJMODFuc3RmaVc4RXJPbE5EUmlweHczNEVYMXdQQzdHemlCSnJ5R0REb3ZINGtpY2krc0hETGloS3pERHNONzM3dXpFNDNIOWNCd0doR1h3YWEvQ1dOZG1lVDdxL2JmWmJCbzlNQTFsUnRqemxlMjVsNzA1ZmJPd09DNnVxTlUwSUNUT3h0N3J5VFp4MG9pMHprMXZaYUFJemRLK1dKY0NQRlA0S2RNRGYveW9xbGlvUFVWVlhpSS9oYjh2T2FGdEk1Ti9DQVEyNzJhbVZEQ0FkWFhsUHFOUUpKSzl3VE9yT3k1ZFhYbFBpYUNuMEg5THFNTjBCaDBPOThaMGdBMEl6aFRzdnAvTEE0MVpFZjMvUHNZMHhjZkJXOWFudHVUWkJXRlR3bDN5NGZaYWo2MHRDRThKUzA0T1N3a3ZFRmF6MTkyKzdjbXVUbkdCdUZDVURXSW0xZSs4KzIvR3YyZDMrWU8vMGJMVW5rZEpuOGFlNWc5ZmZ2Nmcya2dZMWhvSXlEQXNXR0R0S1VxYmRXR2x1YTZzWlA3V1JNejdJWXVWUFBCYXFheXVvRmt3QWtUcDUrdVdMSG56aG53N04ycmVYc04zbzdHd0ZiVmxNanZLM2EzYTZJdVh0QzJ5ZTNuZjQvT2RPOURuWW1xUmN6aHlLMlNVVEN2U0gxcjgvU0JzaUQxL0MrT0dhSVBXZmp6VWV2RG5WYm9UeXZQN05PYXc0M0tTSUxJSWNucExDRWVwQ05XMVR5ZmpJUkhraWs5ODk0WDNiQVFzcFpWK2JPOHhtTGN3ak1OKzhaTTdMS0NyRjhlUGp0SDNVZ3FmbTBYZExaeXZIM2RjMzZJYU93NTJmTzcvUUpXbWYvL3QzTlRtS20xUWJ1RE1tWUc1UWRxcnBpbWNPZk8rWVczUTFZVFVsdVdURzdXQ1BENC9UNkI5WExUdVA0K3ZGVHhtMW9hdmcvSldxYlIxT2luajA0UC9uR3hZVFpXUFRHSjZMOHRmQ0dYdzFqeDVNbzNLM1kzdmpoL0V1Qmk4WGVtWXFncmc3RVBjL283d3lkdmtEeWtKVGF2MS9QbFRLaFVKdmIwbEVpQWx1aUlkZk40eEwrMlZjYjFVQW1mT0xLSTBkZ0w1eXFzaXJEUlJ1R1orUzhnbWJWYVd0YXArd3ZobHFocXhjTG05RHI4SDBxOGFqUS9SV2xTb1ZtL2V6RHQwR0tydmVLM0VsMi8ya1BiMjVmaG1tcTJJSldZQmNlY08ya201OVVZSStMb2t1Q3J0dVNCb09HajE5WFdCYVAzUWhFMGFaUXVoSERpRUhUcEFLRm8waXMwVG1GaUlJZ041bXBMdXp2R2k4c1A0NFlGUStKV2J4ak9TUWpRWkJGNWJBMjZUNmgzb0RyczNlanEySFlQUW5uL05VWWRuVU9QbkFHM2NJVzdTTHQwQkhmMXhSd2U1ZnQzNjlTUThjNnFzdkp5U2FrdWRXR2cwZmpmc25SZmxmUFZLUmtaU0tUcno0R0JQV1VtZGVlV0ZrNHBRYTNvdGJOdTJlSEhkK1hSUkFNT0NWbDJoVkw0ZVNPN3BwcE9uVG1yMjdDRVRSSm1abnozdXY3UmIxTFo0Q2IzTnlyMjhvNzBkYlBoT1RrTzZjQUkyNGF4THhseHd3VjNBWmhGZGZtWThOaDVGSkxvVlVqelVYQXUrTmp6OE5QZ3BscjFHNnc5Njh1QmgwK2UyRVAxbEViZGp4dE9LQlkrZUJYMTNFWHQyR3U5cHhncmF0WWZGYnVWT2lObFJvRTlvVUQvWVN1L3V5WkFrenA1bk1mRjVsbDNrOFAvOVoxdExNa3Q2dXUzYnlGbXdGWFJNMitwdVllQ2NlUUdLM2FlMHVMWUdyM0dvdzRGVHAzalhyNk0zcnN1N0Zpc1YwMWQ0elRCUlRETThWeXhYS0ZhRXowQkJQKzcvLy8rc3ViY2Z5MUNIa0lqL2Y2c05IaHdOQUNCU3d6T1hJRDhOSFVuVmpWU0FHVkZHa3JYYjY0K01SMDZZODdrZStQOFBia0wrUW1lc1FaNVV0UVZFaTRoWlZVWThVUS9kZjJaRElnSzJtUlExemFhZXcrNy8vQU5pQnJOZld4Y3hiOElBc2JQb2RkNGh6bTJhaHpTWXJQVElHREIzYWl2WnFBcVZndFJETjRScXBITVVnbmlScEJwa0UrS2lXc2lRMktscTczcVYrYWlHbW9ta21NelR4R29VTWNYeXdsRTBCNHU2YmlCMUxlS05yS1NTR2NqTU5vbjYvNXg0ZFFCdHplWVdPeVYrdDdaRHpJQ1NiL1BtK0hpODVYaVhXSVByOTVnQzlLTmxUdG5XWCtqeWZ4ZkswdG1PZS8reXJMLytFeWs5YmEzK0M1Y3hObUNMandEdzE4d1NaemlQa0NMQkkwa0YvNTRESUlGNEhUU0xsa01KRFRCTUpKWVFnRGxnbXlDa2NIRTdlQjBhQVFGb1lRTVEybUQ4RzNGQkNBcmd2cmJjREI1b2VaeDRRWVQ3NElPV2Z4RUVqR0x4dTJFWVE4bnZNZjZYQlBjbHBrRDRHMzJKUnVpdDBIZjVqNUlEVS9YYTNjdDdmYitRVUl5aXEwNjNLbmYrVGJXcEd1RzIrc20wWGxHTVhDWGhEN1I2UEt1bTkrZWU0L2dOSHkyM1BlTi9TWEJmWWdxRXYzSC95SlZvUkdLSGtQeVBPOGp3WTJPcVhvOHZrdG92NWpFVm9PQjExZW5tK0hQbjMvUXBtOHB5aE5zQWYxYktKQ0UrZ1MrWWtwMFB0RmdkendXYzlQNzgzRmNqcTQ2MkVyN203d1NWai9OSDc1WWlqeUpLb2pUS29qd3FmditncXFQbWw0SFg5bnBCbEdSRjFYVER0R3pIOWZ3Z2pPSWt6Zktpck9xbTdmcGhuT1psM2ZianZHNzN4L09sYWpyamhpa3MyM0hiblc2djcvbEJPQmlPeGpkdWJ0R3JNdDRMZXFPQmFXeEUrSklISnR1eE5XUXhqdXpaaUc1blJiU2ZKNzdXZmhtNkorb3lnUndxU2h2SUtPNTU4d3BKK1plV0kwdWRRcXl0VEVJc0xlVzVaVkl4VnRFTkxhZmJ5QXJuUExDNUc5aWlRNGZaanZCYXR6a2RPNW5LQTkwTWIxam5hUEo1RUZTTW14QnJORWZKSmxtSFhrSWFlZUdTaHNJQUhVWnNkQndES2M1MUV0bTRRSDdhbW10b3d4MkhMVktaR3NxSlhBbXZPaVFtWEJCcmJXTGtDN3BScWlCSEhLUkFveFE2MW1rUzdBS1h2SldTdmgrdVQwV1ZxZWFtMlZEWmFDVEJuM1dZVFlmejNGNFgxNDR2RkRLZHJBVVlXYXpwV1RjWXRHUHVaNitDMkpNNG8xZm1oRFF0MUJiUE1NV1NSeUk2c1drcmRIMzFLaVNxdG05dVh2WXMxZ01veDRVNjNLYVY5VUtFcmo2eEtyZHpva0k1emNmRzdzVGcwcEtXSWRNMGVtWFhnaFVZVjJ2ZTQxOXNiWndib2dzS0Jqd0lJQ2dFWUNDNFFBWUxFYzd3Q1NlNFF1MmdoUUlKYnRCQkEvY2UpO1xcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcXG59XFxuLmFnLXRoZW1lLWFscGluZSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmssXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsge1xcbiAgLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yOiAjMjE5NmYzO1xcbiAgLS1hZy1zZWxlY3RlZC1yb3ctYmFja2dyb3VuZC1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuMyk7XFxuICAtLWFnLXJvdy1ob3Zlci1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuMSk7XFxuICAtLWFnLWNvbHVtbi1ob3Zlci1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuMSk7XFxuICAtLWFnLWlucHV0LWZvY3VzLWJvcmRlci1jb2xvcjogcmdiYSgzMywgMTUwLCAyNDMsIDAuNCk7XFxuICAtLWFnLXJhbmdlLXNlbGVjdGlvbi1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDMzLCAxNTAsIDI0MywgMC4yKTtcXG4gIC0tYWctcmFuZ2Utc2VsZWN0aW9uLWJhY2tncm91bmQtY29sb3ItMjogcmdiYSgzMywgMTUwLCAyNDMsIDAuMzYpO1xcbiAgLS1hZy1yYW5nZS1zZWxlY3Rpb24tYmFja2dyb3VuZC1jb2xvci0zOiByZ2JhKDMzLCAxNTAsIDI0MywgMC40OSk7XFxuICAtLWFnLXJhbmdlLXNlbGVjdGlvbi1iYWNrZ3JvdW5kLWNvbG9yLTQ6IHJnYmEoMzMsIDE1MCwgMjQzLCAwLjU5KTtcXG4gIC0tYWctcm93LW51bWJlcnMtc2VsZWN0ZWQtY29sb3I6IGNvbG9yLW1peChpbiBzcmdiLCB0cmFuc3BhcmVudCwgdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcikgNTAlKTtcXG4gIC0tYWctYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcXG4gIC0tYWctZm9yZWdyb3VuZC1jb2xvcjogIzE4MWQxZjtcXG4gIC0tYWctYm9yZGVyLWNvbG9yOiAjYmFiZmM3O1xcbiAgLS1hZy1zZWNvbmRhcnktYm9yZGVyLWNvbG9yOiAjZGRlMmViO1xcbiAgLS1hZy1oZWFkZXItYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjhmODtcXG4gIC0tYWctdG9vbHRpcC1iYWNrZ3JvdW5kLWNvbG9yOiAjZjhmOGY4O1xcbiAgLS1hZy1vZGQtcm93LWJhY2tncm91bmQtY29sb3I6ICNmY2ZjZmM7XFxuICAtLWFnLWNvbnRyb2wtcGFuZWwtYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjhmODtcXG4gIC0tYWctc3ViaGVhZGVyLWJhY2tncm91bmQtY29sb3I6ICNmZmY7XFxuICAtLWFnLWludmFsaWQtY29sb3I6ICNlMDI1MjU7XFxuICAtLWFnLWNoZWNrYm94LXVuY2hlY2tlZC1jb2xvcjogIzk5OTtcXG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLWpvaW4tcGlsbC1jb2xvcjogI2YwOGU4ZDtcXG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLWNvbHVtbi1waWxsLWNvbG9yOiAjYTZlMTk0O1xcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItb3B0aW9uLXBpbGwtY29sb3I6ICNmM2MwOGI7XFxuICAtLWFnLWFkdmFuY2VkLWZpbHRlci12YWx1ZS1waWxsLWNvbG9yOiAjODVjMGU0O1xcbiAgLS1hZy1maW5kLW1hdGNoLWNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcXG4gIC0tYWctZmluZC1tYXRjaC1iYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZjAwO1xcbiAgLS1hZy1maW5kLWFjdGl2ZS1tYXRjaC1jb2xvcjogdmFyKC0tYWctZm9yZWdyb3VuZC1jb2xvcik7XFxuICAtLWFnLWZpbmQtYWN0aXZlLW1hdGNoLWJhY2tncm91bmQtY29sb3I6ICNmZmE1MDA7XFxuICAtLWFnLWNoZWNrYm94LWJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xcbiAgLS1hZy1jaGVja2JveC1jaGVja2VkLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG4gIC0tYWctcmFuZ2Utc2VsZWN0aW9uLWJvcmRlci1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XFxuICAtLWFnLXNlY29uZGFyeS1mb3JlZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcXG4gIC0tYWctaW5wdXQtYm9yZGVyLWNvbG9yOiB2YXIoLS1hZy1ib3JkZXItY29sb3IpO1xcbiAgLS1hZy1pbnB1dC1ib3JkZXItY29sb3ItaW52YWxpZDogdmFyKC0tYWctaW52YWxpZC1jb2xvcik7XFxuICAtLWFnLWlucHV0LWZvY3VzLWJveC1zaGFkb3c6IDAgMCAycHggMC4xcmVtIHZhcigtLWFnLWlucHV0LWZvY3VzLWJvcmRlci1jb2xvcik7XFxuICAtLWFnLWlucHV0LWVycm9yLWZvY3VzLWJveC1zaGFkb3c6IDAgMCAycHggMC4xcmVtIHZhcigtLWFnLWludmFsaWQtY29sb3IpO1xcbiAgLS1hZy1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1oZWFkZXItYmFja2dyb3VuZC1jb2xvcik7XFxuICAtLWFnLW1lbnUtYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctaGVhZGVyLWJhY2tncm91bmQtY29sb3IpO1xcbiAgLS1hZy1maWx0ZXItcGFuZWwtYXBwbHktYnV0dG9uLWNvbG9yOiB2YXIoLS1hZy1iYWNrZ3JvdW5kLWNvbG9yKTtcXG4gIC0tYWctZmlsdGVyLXBhbmVsLWFwcGx5LWJ1dHRvbi1iYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG4gIC0tYWctZGlzYWJsZWQtZm9yZWdyb3VuZC1jb2xvcjogcmdiYSgyNCwgMjksIDMxLCAwLjUpO1xcbiAgLS1hZy1jaGlwLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMjQsIDI5LCAzMSwgMC4wNyk7XFxuICAtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcjogcmdiYSgxODYsIDE5MSwgMTk5LCAwLjMpO1xcbiAgLS1hZy1pbnB1dC1kaXNhYmxlZC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDE4NiwgMTkxLCAxOTksIDAuMTUpO1xcbiAgLS1hZy1ib3JkZXJzOiBzb2xpZCAxcHg7XFxuICAtLWFnLWJvcmRlci1yYWRpdXM6IDNweDtcXG4gIC0tYWctYm9yZGVycy1zaWRlLWJ1dHRvbjogbm9uZTtcXG4gIC0tYWctc2lkZS1idXR0b24tc2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XFxuICAtLWFnLWhlYWRlci1jb2x1bW4tcmVzaXplLWhhbmRsZS1kaXNwbGF5OiBibG9jaztcXG4gIC0tYWctaGVhZGVyLWNvbHVtbi1yZXNpemUtaGFuZGxlLXdpZHRoOiAycHg7XFxuICAtLWFnLWhlYWRlci1jb2x1bW4tcmVzaXplLWhhbmRsZS1oZWlnaHQ6IDMwJTtcXG4gIC0tYWctZ3JpZC1zaXplOiA2cHg7XFxuICAtLWFnLWljb24tc2l6ZTogMTZweDtcXG4gIC0tYWctcm93LWhlaWdodDogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogNyk7XFxuICAtLWFnLWhlYWRlci1oZWlnaHQ6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDgpO1xcbiAgLS1hZy1saXN0LWl0ZW0taGVpZ2h0OiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiA0KTtcXG4gIC0tYWctY29sdW1uLXNlbGVjdC1pbmRlbnQtc2l6ZTogdmFyKC0tYWctaWNvbi1zaXplKTtcXG4gIC0tYWctc2V0LWZpbHRlci1pbmRlbnQtc2l6ZTogdmFyKC0tYWctaWNvbi1zaXplKTtcXG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLWJ1aWxkZXItaW5kZW50LXNpemU6IGNhbGModmFyKC0tYWctaWNvbi1zaXplKSArIHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG4gIC0tYWctY2VsbC1ob3Jpem9udGFsLXBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDMpO1xcbiAgLS1hZy1jZWxsLXdpZGdldC1zcGFjaW5nOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG4gIC0tYWctd2lkZ2V0LWNvbnRhaW5lci12ZXJ0aWNhbC1wYWRkaW5nOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG4gIC0tYWctd2lkZ2V0LWNvbnRhaW5lci1ob3Jpem9udGFsLXBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xcbiAgLS1hZy13aWRnZXQtdmVydGljYWwtc3BhY2luZzogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMS41KTtcXG4gIC0tYWctdG9nZ2xlLWJ1dHRvbi1oZWlnaHQ6IDE4cHg7XFxuICAtLWFnLXRvZ2dsZS1idXR0b24td2lkdGg6IDI4cHg7XFxuICAtLWFnLWZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFxcXCJTZWdvZSBVSVxcXCIsIFJvYm90bywgT3h5Z2VuLVNhbnMsIFVidW50dSwgQ2FudGFyZWxsLFxcbiAgICAgIFxcXCJIZWx2ZXRpY2EgTmV1ZVxcXCIsIHNhbnMtc2VyaWY7XFxuICAtLWFnLWZvbnQtc2l6ZTogMTNweDtcXG4gIC0tYWctaWNvbi1mb250LWZhbWlseTogYWdHcmlkQWxwaW5lO1xcbiAgLS1hZy1zZWxlY3RlZC10YWItdW5kZXJsaW5lLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG4gIC0tYWctc2VsZWN0ZWQtdGFiLXVuZGVybGluZS13aWR0aDogMnB4O1xcbiAgLS1hZy1zZWxlY3RlZC10YWItdW5kZXJsaW5lLXRyYW5zaXRpb24tc3BlZWQ6IDAuM3M7XFxuICAtLWFnLXRhYi1taW4td2lkdGg6IDI0MHB4O1xcbiAgLS1hZy1jYXJkLXNoYWRvdzogMCAxcHggNHB4IDFweCByZ2JhKDE4NiwgMTkxLCAxOTksIDAuNCk7XFxuICAtLWFnLXBvcHVwLXNoYWRvdzogdmFyKC0tYWctY2FyZC1zaGFkb3cpO1xcbiAgLS1hZy1zaWRlLWJhci1wYW5lbC13aWR0aDogMjUwcHg7XFxufVxcblxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayB7XFxuICAtLWFnLWJhY2tncm91bmQtY29sb3I6ICMxODFkMWY7XFxuICAtLWFnLWZvcmVncm91bmQtY29sb3I6ICNmZmY7XFxuICAtLWFnLWJvcmRlci1jb2xvcjogIzY4Njg2ZTtcXG4gIC0tYWctc2Vjb25kYXJ5LWJvcmRlci1jb2xvcjogcmdiYSg4OCwgODYsIDgyLCAwLjUpO1xcbiAgLS1hZy1tb2RhbC1vdmVybGF5LWJhY2tncm91bmQtY29sb3I6IHJnYmEoMjQsIDI5LCAzMSwgMC42Nik7XFxuICAtLWFnLWhlYWRlci1iYWNrZ3JvdW5kLWNvbG9yOiAjMjIyNjI4O1xcbiAgLS1hZy10b29sdGlwLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XFxuICAtLWFnLW9kZC1yb3ctYmFja2dyb3VuZC1jb2xvcjogIzIyMjYyODtcXG4gIC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yOiAjMjIyNjI4O1xcbiAgLS1hZy1zdWJoZWFkZXItYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcXG4gIC0tYWctaW5wdXQtZGlzYWJsZWQtYmFja2dyb3VuZC1jb2xvcjogIzI4MmMyZjtcXG4gIC0tYWctaW5wdXQtZm9jdXMtYm94LXNoYWRvdzogMCAwIDJweCAwLjVweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSksIDAgMCA0cHggM3B4IHZhcigtLWFnLWlucHV0LWZvY3VzLWJvcmRlci1jb2xvcik7XFxuICAtLWFnLWlucHV0LWVycm9yLWZvY3VzLWJveC1zaGFkb3c6IDAgMCAycHggMC41cHggcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpLFxcbiAgICAgIDAgMCA0cHggM3B4IGNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS1hZy1iYWNrZ3JvdW5kLWNvbG9yKSwgdmFyKC0tYWctaW52YWxpZC1jb2xvcikgMC41JSk7XFxuICAtLWFnLWNhcmQtc2hhZG93OiAwIDFweCAyMHB4IDFweCBibGFjaztcXG4gIC0tYWctZGlzYWJsZWQtZm9yZWdyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjUpO1xcbiAgLS1hZy1jaGlwLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wNyk7XFxuICAtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcjogcmdiYSgxMDQsIDEwNCwgMTEwLCAwLjMpO1xcbiAgLS1hZy1pbnB1dC1kaXNhYmxlZC1iYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDEwNCwgMTA0LCAxMTAsIDAuMDcpO1xcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItam9pbi1waWxsLWNvbG9yOiAjN2EzYTM3O1xcbiAgLS1hZy1hZHZhbmNlZC1maWx0ZXItY29sdW1uLXBpbGwtY29sb3I6ICMzNTVmMmQ7XFxuICAtLWFnLWFkdmFuY2VkLWZpbHRlci1vcHRpb24tcGlsbC1jb2xvcjogIzVhMzE2ODtcXG4gIC0tYWctYWR2YW5jZWQtZmlsdGVyLXZhbHVlLXBpbGwtY29sb3I6ICMzNzRjODY7XFxuICAtLWFnLWZpbmQtbWF0Y2gtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xcbiAgLS1hZy1maW5kLWFjdGl2ZS1tYXRjaC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XFxuICAtLWFnLWZpbHRlci1wYW5lbC1hcHBseS1idXR0b24tY29sb3I6IHZhcigtLWFnLWZvcmVncm91bmQtY29sb3IpO1xcbiAgLS1hZy1yb3ctbG9hZGluZy1za2VsZXRvbi1lZmZlY3QtY29sb3I6IHJnYmEoMjAyLCAyMDMsIDIwNCwgMC40KTtcXG4gIC0tYWctY2VsbC1iYXRjaC1lZGl0LXRleHQtY29sb3I6ICNmM2QwYjM7XFxuICBjb2xvci1zY2hlbWU6IGRhcms7XFxufVxcblxcbkBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspIHtcXG4gIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIHtcXG4gICAgLS1hZy1iYWNrZ3JvdW5kLWNvbG9yOiAjMTgxZDFmO1xcbiAgICAtLWFnLWZvcmVncm91bmQtY29sb3I6ICNmZmY7XFxuICAgIC0tYWctYm9yZGVyLWNvbG9yOiAjNjg2ODZlO1xcbiAgICAtLWFnLXNlY29uZGFyeS1ib3JkZXItY29sb3I6IHJnYmEoODgsIDg2LCA4MiwgMC41KTtcXG4gICAgLS1hZy1tb2RhbC1vdmVybGF5LWJhY2tncm91bmQtY29sb3I6IHJnYmEoMjQsIDI5LCAzMSwgMC42Nik7XFxuICAgIC0tYWctaGVhZGVyLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XFxuICAgIC0tYWctdG9vbHRpcC1iYWNrZ3JvdW5kLWNvbG9yOiAjMjIyNjI4O1xcbiAgICAtLWFnLW9kZC1yb3ctYmFja2dyb3VuZC1jb2xvcjogIzIyMjYyODtcXG4gICAgLS1hZy1jb250cm9sLXBhbmVsLWJhY2tncm91bmQtY29sb3I6ICMyMjI2Mjg7XFxuICAgIC0tYWctc3ViaGVhZGVyLWJhY2tncm91bmQtY29sb3I6ICMwMDA7XFxuICAgIC0tYWctaW5wdXQtZGlzYWJsZWQtYmFja2dyb3VuZC1jb2xvcjogIzI4MmMyZjtcXG4gICAgLS1hZy1pbnB1dC1mb2N1cy1ib3gtc2hhZG93OiAwIDAgMnB4IDAuNXB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KSwgMCAwIDRweCAzcHggdmFyKC0tYWctaW5wdXQtZm9jdXMtYm9yZGVyLWNvbG9yKTtcXG4gICAgLS1hZy1pbnB1dC1lcnJvci1mb2N1cy1ib3gtc2hhZG93OiAwIDAgMnB4IDAuNXB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KSxcXG4gICAgICAgIDAgMCA0cHggM3B4IGNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS1hZy1iYWNrZ3JvdW5kLWNvbG9yKSwgdmFyKC0tYWctaW52YWxpZC1jb2xvcikgMC41JSk7XFxuICAgIC0tYWctY2FyZC1zaGFkb3c6IDAgMXB4IDIwcHggMXB4IGJsYWNrO1xcbiAgICAtLWFnLWRpc2FibGVkLWZvcmVncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41KTtcXG4gICAgLS1hZy1jaGlwLWJhY2tncm91bmQtY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wNyk7XFxuICAgIC0tYWctaW5wdXQtZGlzYWJsZWQtYm9yZGVyLWNvbG9yOiByZ2JhKDEwNCwgMTA0LCAxMTAsIDAuMyk7XFxuICAgIC0tYWctaW5wdXQtZGlzYWJsZWQtYmFja2dyb3VuZC1jb2xvcjogcmdiYSgxMDQsIDEwNCwgMTEwLCAwLjA3KTtcXG4gICAgLS1hZy1hZHZhbmNlZC1maWx0ZXItam9pbi1waWxsLWNvbG9yOiAjN2EzYTM3O1xcbiAgICAtLWFnLWFkdmFuY2VkLWZpbHRlci1jb2x1bW4tcGlsbC1jb2xvcjogIzM1NWYyZDtcXG4gICAgLS1hZy1hZHZhbmNlZC1maWx0ZXItb3B0aW9uLXBpbGwtY29sb3I6ICM1YTMxNjg7XFxuICAgIC0tYWctYWR2YW5jZWQtZmlsdGVyLXZhbHVlLXBpbGwtY29sb3I6ICMzNzRjODY7XFxuICAgIC0tYWctZmluZC1tYXRjaC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XFxuICAgIC0tYWctZmluZC1hY3RpdmUtbWF0Y2gtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xcbiAgICAtLWFnLWZpbHRlci1wYW5lbC1hcHBseS1idXR0b24tY29sb3I6IHZhcigtLWFnLWZvcmVncm91bmQtY29sb3IpO1xcbiAgICAtLWFnLXJvdy1sb2FkaW5nLXNrZWxldG9uLWVmZmVjdC1jb2xvcjogcmdiYSgyMDIsIDIwMywgMjA0LCAwLjQpO1xcbiAgICAtLWFnLWNlbGwtYmF0Y2gtZWRpdC10ZXh0LWNvbG9yOiAjZjNkMGIzO1xcbiAgICBjb2xvci1zY2hlbWU6IGRhcms7XFxuICB9XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci10b29scGFuZWwtaGVhZGVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci10b29scGFuZWwtc2VhcmNoLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXN0YXR1cy1iYXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLXJvdyxcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1yb3ctbnVtYmVyLWNlbGwsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFuZWwtdGl0bGUtYmFyLXRpdGxlLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLW11bHRpLWZpbHRlci1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctZmlsdGVyLWNhcmQtdGl0bGUsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1maWx0ZXItdG9vbHBhbmVsLWhlYWRlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtc2VhcmNoLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhdHVzLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWhlYWRlci1yb3csXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1yb3ctbnVtYmVyLWNlbGwsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1wYW5lbC10aXRsZS1iYXItdGl0bGUsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1tdWx0aS1maWx0ZXItZ3JvdXAtdGl0bGUtYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmlsdGVyLWNhcmQtdGl0bGUsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtaGVhZGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1maWx0ZXItdG9vbHBhbmVsLXNlYXJjaCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhdHVzLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLXJvdyxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcm93LW51bWJlci1jZWxsLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1wYW5lbC10aXRsZS1iYXItdGl0bGUsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLW11bHRpLWZpbHRlci1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci1jYXJkLXRpdGxlIHtcXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XFxuICBjb2xvcjogdmFyKC0tYWctaGVhZGVyLWZvcmVncm91bmQtY29sb3IpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1yb3csXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1yb3csXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJvdyB7XFxuICBmb250LXNpemU6IGNhbGModmFyKC0tYWctZm9udC1zaXplKSArIDFweCk7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV06bm90KFt0eXBlXSksXFxuLmFnLXRoZW1lLWFscGluZSBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLFxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLFxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZWxdLFxcbi5hZy10aGVtZS1hbHBpbmUgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSxcXG4uYWctdGhlbWUtYWxwaW5lIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLFxcbi5hZy10aGVtZS1hbHBpbmUgdGV4dGFyZWFbY2xhc3NePWFnLV0sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPW51bWJlcl0sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRldGltZS1sb2NhbF0sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIHRleHRhcmVhW2NsYXNzXj1hZy1dLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGV4dF0sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGVdLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIHRleHRhcmVhW2NsYXNzXj1hZy1dIHtcXG4gIG1pbi1oZWlnaHQ6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDQpO1xcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tYWctYm9yZGVyLXJhZGl1cyk7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXTpub3QoW3R5cGVdKSwgLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGV4dF0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPW51bWJlcl0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRlbF0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGVdLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRldGltZS1sb2NhbF0sIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciB0ZXh0YXJlYVtjbGFzc149YWctXSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV06bm90KFt0eXBlXSksIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGV4dF0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9bnVtYmVyXSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZWxdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGVdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGV0aW1lLWxvY2FsXSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgdGV4dGFyZWFbY2xhc3NePWFnLV0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV06bm90KFt0eXBlXSksIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZXh0XSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciBpbnB1dFtjbGFzc149YWctXVt0eXBlPW51bWJlcl0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZWxdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbHRyIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZV0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRldGltZS1sb2NhbF0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgdGV4dGFyZWFbY2xhc3NePWFnLV0ge1xcbiAgcGFkZGluZy1sZWZ0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV06bm90KFt0eXBlXSksIC5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT10ZWxdLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSwgLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLCAuYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgdGV4dGFyZWFbY2xhc3NePWFnLV0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPXRleHRdLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPW51bWJlcl0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRlXSwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1kYXRldGltZS1sb2NhbF0sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcnRsIHRleHRhcmVhW2NsYXNzXj1hZy1dLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dOm5vdChbdHlwZV0pLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGV4dF0sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1ydGwgaW5wdXRbY2xhc3NePWFnLV1bdHlwZT1udW1iZXJdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9dGVsXSwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCBpbnB1dFtjbGFzc149YWctXVt0eXBlPWRhdGVdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIGlucHV0W2NsYXNzXj1hZy1dW3R5cGU9ZGF0ZXRpbWUtbG9jYWxdLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIHRleHRhcmVhW2NsYXNzXj1hZy1dIHtcXG4gIHBhZGRpbmctcmlnaHQ6IHZhcigtLWFnLWdyaWQtc2l6ZSk7XFxufVxcblxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXRhYixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXRhYixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctdGFiIHtcXG4gIHBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDEuNSk7XFxuICB0cmFuc2l0aW9uOiBjb2xvciAwLjRzO1xcbiAgZmxleDogMSAxIGF1dG87XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXRhYi1zZWxlY3RlZCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXRhYi1zZWxlY3RlZCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctdGFiLXNlbGVjdGVkIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctbWVudSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLW1lbnUsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLW1lbnUge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFuZWwtY29udGVudC13cmFwcGVyIC5hZy1jb2x1bW4tc2VsZWN0LFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGFuZWwtY29udGVudC13cmFwcGVyIC5hZy1jb2x1bW4tc2VsZWN0LFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1wYW5lbC1jb250ZW50LXdyYXBwZXIgLmFnLWNvbHVtbi1zZWxlY3Qge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctbWVudS1oZWFkZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1tZW51LWhlYWRlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbWVudS1oZWFkZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctY29udHJvbC1wYW5lbC1iYWNrZ3JvdW5kLWNvbG9yKTtcXG4gIHBhZGRpbmctdG9wOiAxcHg7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXRhYnMtaGVhZGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctdGFicy1oZWFkZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXRhYnMtaGVhZGVyIHtcXG4gIGJvcmRlci1ib3R0b206IHZhcigtLWFnLWJvcmRlcnMpIHZhcigtLWFnLWJvcmRlci1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1zZXR0aW5ncy1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnRzLWRhdGEtZ3JvdXAtdGl0bGUtYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1zZXR0aW5ncy1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZGF0YS1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLXNldHRpbmdzLWdyb3VwLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWRhdGEtZ3JvdXAtdGl0bGUtYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdGl0bGUtYmFyIHtcXG4gIHBhZGRpbmc6IHZhcigtLWFnLWdyaWQtc2l6ZSkgY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XFxuICBsaW5lLWhlaWdodDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICsgdmFyKC0tYWctZ3JpZC1zaXplKSAtIDJweCk7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0LW1pbmktdGh1bWJuYWlsLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnQtbWluaS10aHVtYm5haWwsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0LW1pbmktdGh1bWJuYWlsIHtcXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWJhY2tncm91bmQtY29sb3IpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydC1zZXR0aW5ncy1uYXYtYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtbmF2LWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtbmF2LWJhciB7XFxuICBib3JkZXItdG9wOiB2YXIoLS1hZy1ib3JkZXJzLXNlY29uZGFyeSkgdmFyKC0tYWctc2Vjb25kYXJ5LWJvcmRlci1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciAuYWctZ3JvdXAtdGl0bGUtYmFyLWljb24sIC5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbHRyIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbiwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctZ3JvdXAtdGl0bGUtYmFyLWljb24ge1xcbiAgbWFyZ2luLXJpZ2h0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCAuYWctZ3JvdXAtdGl0bGUtYmFyLWljb24sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1ydGwgLmFnLWdyb3VwLXRpdGxlLWJhci1pY29uIHtcXG4gIG1hcmdpbi1sZWZ0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXRvcC1sZXZlbC1ncm91cC10b29sYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtYWR2YW5jZWQtc2V0dGluZ3MtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciB7XFxuICBtYXJnaW4tdG9wOiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUgLmFnLWx0ciAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1sdHIgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyIHtcXG4gIHBhZGRpbmctbGVmdDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICogMC41ICsgdmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ydGwgLmFnLWNoYXJ0cy1mb3JtYXQtdG9wLWxldmVsLWdyb3VwLXRvb2xiYXIsIC5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWNoYXJ0cy1hZHZhbmNlZC1zZXR0aW5ncy10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWZvcm1hdC10b3AtbGV2ZWwtZ3JvdXAtdG9vbGJhciwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXJ0bCAuYWctY2hhcnRzLWFkdmFuY2VkLXNldHRpbmdzLXRvcC1sZXZlbC1ncm91cC10b29sYmFyIHtcXG4gIHBhZGRpbmctcmlnaHQ6IGNhbGModmFyKC0tYWctaWNvbi1zaXplKSAqIDAuNSArIHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG59XFxuXFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAge1xcbiAgYm9yZGVyLWxlZnQ6IGRhc2hlZCAxcHg7XFxuICBib3JkZXItbGVmdC1jb2xvcjogdmFyKC0tYWctYm9yZGVyLWNvbG9yKTtcXG4gIHBhZGRpbmctbGVmdDogdmFyKC0tYWctZ3JpZC1zaXplKTtcXG4gIG1hcmdpbi1ib3R0b206IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC10aXRsZS1iYXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLXRpdGxlLWJhciB7XFxuICBwYWRkaW5nLXRvcDogMDtcXG4gIHBhZGRpbmctYm90dG9tOiAwO1xcbiAgYmFja2dyb3VuZDogbm9uZTtcXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWNvbnRhaW5lcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWNvbnRhaW5lcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnRzLWZvcm1hdC1zdWItbGV2ZWwtZ3JvdXAtY29udGFpbmVyIHtcXG4gIHBhZGRpbmctYm90dG9tOiAwO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC1pdGVtOmxhc3QtY2hpbGQsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jaGFydHMtZm9ybWF0LXN1Yi1sZXZlbC1ncm91cC1pdGVtOmxhc3QtY2hpbGQsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0cy1mb3JtYXQtc3ViLWxldmVsLWdyb3VwLWl0ZW06bGFzdC1jaGlsZCB7XFxuICBtYXJnaW4tYm90dG9tOiAwO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lLmFnLWRuZC1naG9zdCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsuYWctZG5kLWdob3N0LFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrLmFnLWRuZC1naG9zdCB7XFxuICBmb250LXNpemU6IGNhbGModmFyKC0tYWctZm9udC1zaXplKSAtIDFweCk7XFxuICBmb250LXdlaWdodDogNzAwO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zaWRlLWJ1dHRvbnMsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1zaWRlLWJ1dHRvbnMsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXNpZGUtYnV0dG9ucyB7XFxuICB3aWR0aDogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogNSk7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXN0YW5kYXJkLWJ1dHRvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YW5kYXJkLWJ1dHRvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhbmRhcmQtYnV0dG9uIHtcXG4gIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xcbiAgYXBwZWFyYW5jZTogbm9uZTtcXG4gIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcXG4gIGJvcmRlci1yYWRpdXM6IHZhcigtLWFnLWJvcmRlci1yYWRpdXMpO1xcbiAgYm9yZGVyOiAxcHggc29saWQ7XFxuICBib3JkZXItY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xcbiAgY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYmFja2dyb3VuZC1jb2xvcik7XFxuICBmb250LXdlaWdodDogNjAwO1xcbiAgcGFkZGluZzogdmFyKC0tYWctZ3JpZC1zaXplKSBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctc3RhbmRhcmQtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhbmRhcmQtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246aG92ZXIge1xcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLXJvdy1ob3Zlci1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXN0YW5kYXJkLWJ1dHRvbjphY3RpdmUsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246YWN0aXZlLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246YWN0aXZlIHtcXG4gIGJvcmRlci1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG4gIGNvbG9yOiB2YXIoLS1hZy1iYWNrZ3JvdW5kLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctc3RhbmRhcmQtYnV0dG9uOmRpc2FibGVkLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhbmRhcmQtYnV0dG9uOmRpc2FibGVkLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGFuZGFyZC1idXR0b246ZGlzYWJsZWQge1xcbiAgY29sb3I6IHZhcigtLWFnLWRpc2FibGVkLWZvcmVncm91bmQtY29sb3IpO1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctaW5wdXQtZGlzYWJsZWQtYmFja2dyb3VuZC1jb2xvcik7XFxuICBib3JkZXItY29sb3I6IHZhcigtLWFnLWlucHV0LWRpc2FibGVkLWJvcmRlci1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLWRyb3AtdmVydGljYWwsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsIHtcXG4gIG1pbi1oZWlnaHQ6IDc1cHg7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLXRpdGxlLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLWRyb3AtdmVydGljYWwtdGl0bGUtYmFyIHtcXG4gIHBhZGRpbmc6IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xcbiAgcGFkZGluZy1ib3R0b206IDBweDtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctY29sdW1uLWRyb3AtdmVydGljYWwtZW1wdHktbWVzc2FnZSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLWVtcHR5LW1lc3NhZ2UsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1kcm9wLXZlcnRpY2FsLWVtcHR5LW1lc3NhZ2Uge1xcbiAgZGlzcGxheTogZmxleDtcXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICBib3JkZXI6IGRhc2hlZCAxcHg7XFxuICBib3JkZXItY29sb3I6IHZhcigtLWFnLWJvcmRlci1jb2xvcik7XFxuICBtYXJnaW46IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDIpO1xcbiAgcGFkZGluZzogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLWVtcHR5LW1lc3NhZ2UsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZHJvcC1lbXB0eS1tZXNzYWdlLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tZHJvcC1lbXB0eS1tZXNzYWdlIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1mb3JlZ3JvdW5kLWNvbG9yKTtcXG4gIG9wYWNpdHk6IDAuNzU7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXBpbGwtc2VsZWN0IC5hZy1jb2x1bW4tZHJvcCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBpbGwtc2VsZWN0IC5hZy1jb2x1bW4tZHJvcCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGlsbC1zZWxlY3QgLmFnLWNvbHVtbi1kcm9wIHtcXG4gIG1pbi1oZWlnaHQ6IHVuc2V0O1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zdGF0dXMtYmFyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctc3RhdHVzLWJhcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc3RhdHVzLWJhciB7XFxuICBmb250LXdlaWdodDogbm9ybWFsO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zdGF0dXMtbmFtZS12YWx1ZS12YWx1ZSxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXN0YXR1cy1uYW1lLXZhbHVlLXZhbHVlLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zdGF0dXMtbmFtZS12YWx1ZS12YWx1ZSB7XFxuICBmb250LXdlaWdodDogNzAwO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1wYWdpbmctbnVtYmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXBhZ2luZy1yb3ctc3VtbWFyeS1wYW5lbC1udW1iZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1wYWdpbmctbnVtYmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGFnaW5nLXJvdy1zdW1tYXJ5LXBhbmVsLW51bWJlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGFnaW5nLW51bWJlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGFnaW5nLXJvdy1zdW1tYXJ5LXBhbmVsLW51bWJlciB7XFxuICBmb250LXdlaWdodDogNzAwO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNvbHVtbi1kcm9wLWNlbGwtYnV0dG9uLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tZHJvcC1jZWxsLWJ1dHRvbiB7XFxuICBvcGFjaXR5OiAwLjU7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1kcm9wLWNlbGwtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLWRyb3AtY2VsbC1idXR0b246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1kcm9wLWNlbGwtYnV0dG9uOmhvdmVyIHtcXG4gIG9wYWNpdHk6IDAuNzU7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1zZWxlY3QtY29sdW1uLXJlYWRvbmx5LmFnLWljb24tZ3JpcCxcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1yZWFkb25seSAuYWctaWNvbi1ncmlwLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLXNlbGVjdC1jb2x1bW4tcmVhZG9ubHkuYWctaWNvbi1ncmlwLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY29sdW1uLXNlbGVjdC1jb2x1bW4tcmVhZG9ubHkgLmFnLWljb24tZ3JpcCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLXNlbGVjdC1jb2x1bW4tcmVhZG9ubHkuYWctaWNvbi1ncmlwLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1yZWFkb25seSAuYWctaWNvbi1ncmlwIHtcXG4gIG9wYWNpdHk6IDAuMzU7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1jZWxsLW1lbnUtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1jZWxsLWZpbHRlci1idXR0b246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctc2lkZS1idXR0b24tYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXRhYjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1leHBhbmQtaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tZ3JvdXAtaWNvbnM6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctc2V0LWZpbHRlci1ncm91cC1pY29uczpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ncm91cC1leHBhbmRlZCAuYWctaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ncm91cC1jb250cmFjdGVkIC5hZy1pY29uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0LXNldHRpbmdzLXByZXY6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnQtc2V0dGluZ3MtbmV4dDpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1jb2x1bW4tc2VsZWN0LWhlYWRlci1pY29uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZsb2F0aW5nLWZpbHRlci1idXR0b24tYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci10b29scGFuZWwtZXhwYW5kOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNoYXJ0LW1lbnUtaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWhlYWRlci1jZWxsLW1lbnUtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXNpZGUtYnV0dG9uLWJ1dHRvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXRhYjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1oZWFkZXItZXhwYW5kLWljb246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tZ3JvdXAtaWNvbnM6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1zZXQtZmlsdGVyLWdyb3VwLWljb25zOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZ3JvdXAtZXhwYW5kZWQgLmFnLWljb246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ncm91cC1jb250cmFjdGVkIC5hZy1pY29uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtcHJldjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0LXNldHRpbmdzLW5leHQ6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ncm91cC10aXRsZS1iYXItaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtaGVhZGVyLWljb246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1mbG9hdGluZy1maWx0ZXItYnV0dG9uLWJ1dHRvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtZXhwYW5kOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctY2hhcnQtbWVudS1pY29uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1oZWFkZXItY2VsbC1tZW51LWJ1dHRvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc2lkZS1idXR0b24tYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy10YWI6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWhlYWRlci1leHBhbmQtaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY29sdW1uLWdyb3VwLWljb25zOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1zZXQtZmlsdGVyLWdyb3VwLWljb25zOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1ncm91cC1leHBhbmRlZCAuYWctaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZ3JvdXAtY29udHJhY3RlZCAuYWctaWNvbjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtcHJldjpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtc2V0dGluZ3MtbmV4dDpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZ3JvdXAtdGl0bGUtYmFyLWljb246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNvbHVtbi1zZWxlY3QtaGVhZGVyLWljb246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZsb2F0aW5nLWZpbHRlci1idXR0b24tYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1maWx0ZXItdG9vbHBhbmVsLWV4cGFuZDpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctY2hhcnQtbWVudS1pY29uOmhvdmVyIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLWNlbGwtbWVudS1idXR0b246aG92ZXIgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1zaWRlLWJ1dHRvbi1idXR0b246aG92ZXIgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZSAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1mbG9hdGluZy1maWx0ZXItYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWhlYWRlci1jZWxsLW1lbnUtYnV0dG9uOmhvdmVyIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWNlbGwtZmlsdGVyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXNpZGUtYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b246aG92ZXIgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1mbG9hdGluZy1maWx0ZXItYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWNlbGwtbWVudS1idXR0b246aG92ZXIgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWhlYWRlci1jZWxsLWZpbHRlci1idXR0b246aG92ZXIgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXNpZGUtYnV0dG9uLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbjpob3ZlciAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZmxvYXRpbmctZmlsdGVyLWJ1dHRvbi1idXR0b246aG92ZXIgLmFnLWljb24ge1xcbiAgY29sb3I6IGluaGVyaXQ7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci1hY3RpdmUgLmFnLWljb24tZmlsdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmlsdGVyLWFjdGl2ZSAuYWctaWNvbi1maWx0ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci1hY3RpdmUgLmFnLWljb24tZmlsdGVyIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctY2hhcnQtc2V0dGluZ3MtY2FyZC1pdGVtLmFnLW5vdC1zZWxlY3RlZDpob3ZlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWNoYXJ0LXNldHRpbmdzLWNhcmQtaXRlbS5hZy1ub3Qtc2VsZWN0ZWQ6aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWNoYXJ0LXNldHRpbmdzLWNhcmQtaXRlbS5hZy1ub3Qtc2VsZWN0ZWQ6aG92ZXIge1xcbiAgb3BhY2l0eTogMC4zNTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctbHRyIC5hZy1wYW5lbC10aXRsZS1iYXItYnV0dG9uLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbiwgLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWx0ciAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbiB7XFxuICBtYXJnaW4tbGVmdDogY2FsYyh2YXIoLS1hZy1ncmlkLXNpemUpICogMik7XFxuICBtYXJnaW4tcmlnaHQ6IHZhcigtLWFnLWdyaWQtc2l6ZSk7XFxufVxcblxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXJ0bCAuYWctcGFuZWwtdGl0bGUtYmFyLWJ1dHRvbiwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b24sIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1ydGwgLmFnLXBhbmVsLXRpdGxlLWJhci1idXR0b24ge1xcbiAgbWFyZ2luLXJpZ2h0OiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAyKTtcXG4gIG1hcmdpbi1sZWZ0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtZ3JvdXAtY29udGFpbmVyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctZmlsdGVyLXRvb2xwYW5lbC1ncm91cC1jb250YWluZXIsIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtZ3JvdXAtY29udGFpbmVyIHtcXG4gIHBhZGRpbmctbGVmdDogdmFyKC0tYWctZ3JpZC1zaXplKTtcXG59XFxuXFxuLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWdyb3VwLWNvbnRhaW5lciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWZpbHRlci10b29scGFuZWwtZ3JvdXAtY29udGFpbmVyLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWdyb3VwLWNvbnRhaW5lciB7XFxuICBwYWRkaW5nLXJpZ2h0OiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbn1cXG5cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlcixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlciB7XFxuICBib3JkZXI6IG5vbmU7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1hZy1jb250cm9sLXBhbmVsLWJhY2tncm91bmQtY29sb3IpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyLCAuYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWx0ciAuYWctZmlsdGVyLXRvb2xwYW5lbC1pbnN0YW5jZS1maWx0ZXIsIC5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sdHIgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyIHtcXG4gIGJvcmRlci1sZWZ0OiBkYXNoZWQgMXB4O1xcbiAgYm9yZGVyLWxlZnQtY29sb3I6IHZhcigtLWFnLWJvcmRlci1jb2xvcik7XFxuICBtYXJnaW4tbGVmdDogY2FsYyh2YXIoLS1hZy1pY29uLXNpemUpICogMC41KTtcXG59XFxuXFxuLmFnLXRoZW1lLWFscGluZSAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlciwgLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1ydGwgLmFnLWZpbHRlci10b29scGFuZWwtaW5zdGFuY2UtZmlsdGVyLCAuYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctcnRsIC5hZy1maWx0ZXItdG9vbHBhbmVsLWluc3RhbmNlLWZpbHRlciB7XFxuICBib3JkZXItcmlnaHQ6IGRhc2hlZCAxcHg7XFxuICBib3JkZXItcmlnaHQtY29sb3I6IHZhcigtLWFnLWJvcmRlci1jb2xvcik7XFxuICBtYXJnaW4tcmlnaHQ6IGNhbGModmFyKC0tYWctaWNvbi1zaXplKSAqIDAuNSk7XFxufVxcblxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXNldC1maWx0ZXItbGlzdCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLXNldC1maWx0ZXItbGlzdCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctc2V0LWZpbHRlci1saXN0IHtcXG4gIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLWFnLWdyaWQtc2l6ZSkgKiAwLjUpO1xcbiAgcGFkZGluZy1ib3R0b206IGNhbGModmFyKC0tYWctZ3JpZC1zaXplKSAqIDAuNSk7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWZpbHRlci1hZGQtYnV0dG9uIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZmlsdGVyLWFkZC1idXR0b24gLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWZpbHRlci1hZGQtYnV0dG9uIC5hZy1pY29uIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctbGF5b3V0LWF1dG8taGVpZ2h0IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sYXlvdXQtYXV0by1oZWlnaHQgLmFnLWNlbnRlci1jb2xzLWNvbnRhaW5lcixcXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1sYXlvdXQtcHJpbnQgLmFnLWNlbnRlci1jb2xzLXZpZXdwb3J0LFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWxheW91dC1wcmludCAuYWctY2VudGVyLWNvbHMtY29udGFpbmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbGF5b3V0LWF1dG8taGVpZ2h0IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWxheW91dC1hdXRvLWhlaWdodCAuYWctY2VudGVyLWNvbHMtY29udGFpbmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbGF5b3V0LXByaW50IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWxheW91dC1wcmludCAuYWctY2VudGVyLWNvbHMtY29udGFpbmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sYXlvdXQtYXV0by1oZWlnaHQgLmFnLWNlbnRlci1jb2xzLXZpZXdwb3J0LFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1sYXlvdXQtYXV0by1oZWlnaHQgLmFnLWNlbnRlci1jb2xzLWNvbnRhaW5lcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbGF5b3V0LXByaW50IC5hZy1jZW50ZXItY29scy12aWV3cG9ydCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctbGF5b3V0LXByaW50IC5hZy1jZW50ZXItY29scy1jb250YWluZXIge1xcbiAgbWluLWhlaWdodDogMTUwcHg7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWRhdGUtdGltZS1saXN0LXBhZ2UtZW50cnktaXMtY3VycmVudCxcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWRhdGUtdGltZS1saXN0LXBhZ2UtZW50cnktaXMtY3VycmVudCxcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctZGF0ZS10aW1lLWxpc3QtcGFnZS1lbnRyeS1pcy1jdXJyZW50IHtcXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWFnLWFscGluZS1hY3RpdmUtY29sb3IpO1xcbn1cXG4uYWctdGhlbWUtYWxwaW5lIC5hZy1hZHZhbmNlZC1maWx0ZXItYnVpbGRlci1idXR0b24sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1hZHZhbmNlZC1maWx0ZXItYnVpbGRlci1idXR0b24sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWJ1dHRvbiB7XFxuICBwYWRkaW5nOiB2YXIoLS1hZy1ncmlkLXNpemUpO1xcbiAgZm9udC13ZWlnaHQ6IDYwMDtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctbGlzdC1pdGVtLWhvdmVyZWQ6OmFmdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctbGlzdC1pdGVtLWhvdmVyZWQ6OmFmdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1saXN0LWl0ZW0taG92ZXJlZDo6YWZ0ZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLXBpbGwgLmFnLXBpbGwtYnV0dG9uOmhvdmVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctcGlsbCAuYWctcGlsbC1idXR0b246aG92ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLXBpbGwgLmFnLXBpbGwtYnV0dG9uOmhvdmVyIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1hbHBpbmUtYWN0aXZlLWNvbG9yKTtcXG59XFxuLmFnLXRoZW1lLWFscGluZSAuYWctaGVhZGVyLWhpZ2hsaWdodC1iZWZvcmU6OmFmdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWhlYWRlci1oaWdobGlnaHQtYWZ0ZXI6OmFmdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWhpZ2hsaWdodC1iZWZvcmU6OmFmdGVyLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctaGVhZGVyLWhpZ2hsaWdodC1hZnRlcjo6YWZ0ZXIsXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWhlYWRlci1oaWdobGlnaHQtYmVmb3JlOjphZnRlcixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctaGVhZGVyLWhpZ2hsaWdodC1hZnRlcjo6YWZ0ZXIge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tYWctYWxwaW5lLWFjdGl2ZS1jb2xvcik7XFxufVxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWl0ZW0tYnV0dG9uLWRpc2FibGVkIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWRpc2FibGVkIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUgLmFnLWNvbHVtbi1zZWxlY3QtY29sdW1uLWdyb3VwLXJlYWRvbmx5IC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUgW2Rpc2FibGVkXSAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgLmFnLWFkdmFuY2VkLWZpbHRlci1idWlsZGVyLWl0ZW0tYnV0dG9uLWRpc2FibGVkIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUtZGFyayAuYWctZGlzYWJsZWQgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1kYXJrIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1ncm91cC1yZWFkb25seSAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWRhcmsgW2Rpc2FibGVkXSAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayAuYWctYWR2YW5jZWQtZmlsdGVyLWJ1aWxkZXItaXRlbS1idXR0b24tZGlzYWJsZWQgLmFnLWljb24sXFxuLmFnLXRoZW1lLWFscGluZS1hdXRvLWRhcmsgLmFnLWRpc2FibGVkIC5hZy1pY29uLFxcbi5hZy10aGVtZS1hbHBpbmUtYXV0by1kYXJrIC5hZy1jb2x1bW4tc2VsZWN0LWNvbHVtbi1ncm91cC1yZWFkb25seSAuYWctaWNvbixcXG4uYWctdGhlbWUtYWxwaW5lLWF1dG8tZGFyayBbZGlzYWJsZWRdIC5hZy1pY29uIHtcXG4gIGNvbG9yOiB2YXIoLS1hZy1kaXNhYmxlZC1mb3JlZ3JvdW5kLWNvbG9yKTtcXG59XFxuXCJdLFwic291cmNlUm9vdFwiOlwiXCJ9XSk7XG4vLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCBfX19DU1NfTE9BREVSX0VYUE9SVF9fXztcbiIsInZhciB0b1Byb3BlcnR5S2V5ID0gcmVxdWlyZShcIi4vdG9Qcm9wZXJ0eUtleS5qc1wiKTtcbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7XG4gIHJldHVybiAociA9IHRvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwge1xuICAgIHZhbHVlOiB0LFxuICAgIGVudW1lcmFibGU6ICEwLFxuICAgIGNvbmZpZ3VyYWJsZTogITAsXG4gICAgd3JpdGFibGU6ICEwXG4gIH0pIDogZVtyXSA9IHQsIGU7XG59XG5tb2R1bGUuZXhwb3J0cyA9IF9kZWZpbmVQcm9wZXJ0eSwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsIlxuICAgICAgaW1wb3J0IEFQSSBmcm9tIFwiIS4uLy4uL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvaW5qZWN0U3R5bGVzSW50b1N0eWxlVGFnLmpzXCI7XG4gICAgICBpbXBvcnQgZG9tQVBJIGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZURvbUFQSS5qc1wiO1xuICAgICAgaW1wb3J0IGluc2VydEZuIGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRCeVNlbGVjdG9yLmpzXCI7XG4gICAgICBpbXBvcnQgc2V0QXR0cmlidXRlcyBmcm9tIFwiIS4uLy4uL3N0eWxlLWxvYWRlci9kaXN0L3J1bnRpbWUvc2V0QXR0cmlidXRlc1dpdGhvdXRBdHRyaWJ1dGVzLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0U3R5bGVFbGVtZW50IGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbnNlcnRTdHlsZUVsZW1lbnQuanNcIjtcbiAgICAgIGltcG9ydCBzdHlsZVRhZ1RyYW5zZm9ybUZuIGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zdHlsZVRhZ1RyYW5zZm9ybS5qc1wiO1xuICAgICAgaW1wb3J0IGNvbnRlbnQsICogYXMgbmFtZWRFeHBvcnQgZnJvbSBcIiEhLi4vLi4vY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9wb3N0Y3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2FnLWdyaWQuY3NzXCI7XG4gICAgICBcbiAgICAgIFxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLnN0eWxlVGFnVHJhbnNmb3JtID0gc3R5bGVUYWdUcmFuc2Zvcm1Gbjtcbm9wdGlvbnMuc2V0QXR0cmlidXRlcyA9IHNldEF0dHJpYnV0ZXM7XG5cbiAgICAgIG9wdGlvbnMuaW5zZXJ0ID0gaW5zZXJ0Rm4uYmluZChudWxsLCBcImhlYWRcIik7XG4gICAgXG5vcHRpb25zLmRvbUFQSSA9IGRvbUFQSTtcbm9wdGlvbnMuaW5zZXJ0U3R5bGVFbGVtZW50ID0gaW5zZXJ0U3R5bGVFbGVtZW50O1xuXG52YXIgdXBkYXRlID0gQVBJKGNvbnRlbnQsIG9wdGlvbnMpO1xuXG5cblxuZXhwb3J0ICogZnJvbSBcIiEhLi4vLi4vY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9wb3N0Y3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL2FnLWdyaWQuY3NzXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiXG4gICAgICBpbXBvcnQgQVBJIGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanNcIjtcbiAgICAgIGltcG9ydCBkb21BUEkgZnJvbSBcIiEuLi8uLi9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlRG9tQVBJLmpzXCI7XG4gICAgICBpbXBvcnQgaW5zZXJ0Rm4gZnJvbSBcIiEuLi8uLi9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydEJ5U2VsZWN0b3IuanNcIjtcbiAgICAgIGltcG9ydCBzZXRBdHRyaWJ1dGVzIGZyb20gXCIhLi4vLi4vc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9zZXRBdHRyaWJ1dGVzV2l0aG91dEF0dHJpYnV0ZXMuanNcIjtcbiAgICAgIGltcG9ydCBpbnNlcnRTdHlsZUVsZW1lbnQgZnJvbSBcIiEuLi8uLi9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luc2VydFN0eWxlRWxlbWVudC5qc1wiO1xuICAgICAgaW1wb3J0IHN0eWxlVGFnVHJhbnNmb3JtRm4gZnJvbSBcIiEuLi8uLi9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL3N0eWxlVGFnVHJhbnNmb3JtLmpzXCI7XG4gICAgICBpbXBvcnQgY29udGVudCwgKiBhcyBuYW1lZEV4cG9ydCBmcm9tIFwiISEuLi8uLi9jc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4uLy4uL3Bvc3Rjc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vYWctdGhlbWUtYWxwaW5lLmNzc1wiO1xuICAgICAgXG4gICAgICBcblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5zdHlsZVRhZ1RyYW5zZm9ybSA9IHN0eWxlVGFnVHJhbnNmb3JtRm47XG5vcHRpb25zLnNldEF0dHJpYnV0ZXMgPSBzZXRBdHRyaWJ1dGVzO1xuXG4gICAgICBvcHRpb25zLmluc2VydCA9IGluc2VydEZuLmJpbmQobnVsbCwgXCJoZWFkXCIpO1xuICAgIFxub3B0aW9ucy5kb21BUEkgPSBkb21BUEk7XG5vcHRpb25zLmluc2VydFN0eWxlRWxlbWVudCA9IGluc2VydFN0eWxlRWxlbWVudDtcblxudmFyIHVwZGF0ZSA9IEFQSShjb250ZW50LCBvcHRpb25zKTtcblxuXG5cbmV4cG9ydCAqIGZyb20gXCIhIS4uLy4uL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vcG9zdGNzcy1sb2FkZXIvZGlzdC9janMuanMhLi9hZy10aGVtZS1hbHBpbmUuY3NzXCI7XG4gICAgICAgZXhwb3J0IGRlZmF1bHQgY29udGVudCAmJiBjb250ZW50LmxvY2FscyA/IGNvbnRlbnQubG9jYWxzIDogdW5kZWZpbmVkO1xuIiwiLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvYWdHcmlkUmVhY3QudHN4XG5pbXBvcnQgUmVhY3QyMCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9hZ0dyaWRSZWFjdFVpLnRzeFxuaW1wb3J0IFJlYWN0MTksIHtcbiAgZm9yd2FyZFJlZiBhcyBmb3J3YXJkUmVmMyxcbiAgdXNlQ2FsbGJhY2sgYXMgdXNlQ2FsbGJhY2sxNSxcbiAgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MTUsXG4gIHVzZUVmZmVjdCBhcyB1c2VFZmZlY3QxMCxcbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZSBhcyB1c2VJbXBlcmF0aXZlSGFuZGxlMyxcbiAgdXNlTWVtbyBhcyB1c2VNZW1vMTMsXG4gIHVzZVJlZiBhcyB1c2VSZWYxNixcbiAgdXNlU3RhdGUgYXMgdXNlU3RhdGUxNlxufSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIEJhc2VDb21wb25lbnRXcmFwcGVyLFxuICBHcmlkQ29yZUNyZWF0b3IsXG4gIFZhbmlsbGFGcmFtZXdvcmtPdmVycmlkZXMsXG4gIF9jb21iaW5lQXR0cmlidXRlc0FuZEdyaWRPcHRpb25zLFxuICBfZ2V0R3JpZE9wdGlvbixcbiAgX2dldEdyaWRSZWdpc3RlcmVkTW9kdWxlcyxcbiAgX2lzQ2xpZW50U2lkZVJvd01vZGVsLFxuICBfaXNTZXJ2ZXJTaWRlUm93TW9kZWwsXG4gIF9vYnNlcnZlUmVzaXplIGFzIF9vYnNlcnZlUmVzaXplMixcbiAgX3Byb2Nlc3NPbkNoYW5nZSxcbiAgX3dhcm4gYXMgX3dhcm4yXG59IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2NlbGxSZW5kZXJlci9ncm91cENlbGxSZW5kZXJlci50c3hcbmltcG9ydCBSZWFjdDMsIHtcbiAgZm9yd2FyZFJlZixcbiAgdXNlQ2FsbGJhY2ssXG4gIHVzZUNvbnRleHQsXG4gIHVzZUltcGVyYXRpdmVIYW5kbGUsXG4gIHVzZUxheW91dEVmZmVjdCxcbiAgdXNlTWVtbyxcbiAgdXNlUmVmLFxuICB1c2VTdGF0ZVxufSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IF90b1N0cmluZyB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2JlYW5zQ29udGV4dC50c3hcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbnZhciBCZWFuc0NvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHt9KTtcbnZhciBSZW5kZXJNb2RlQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoXCJkZWZhdWx0XCIpO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2pzQ29tcC50c3hcbnZhciBzaG93SnNDb21wID0gKGNvbXBEZXRhaWxzLCBjb250ZXh0LCBlUGFyZW50LCByZWYpID0+IHtcbiAgY29uc3QgZG9Ob3RoaW5nID0gIWNvbXBEZXRhaWxzIHx8IGNvbXBEZXRhaWxzLmNvbXBvbmVudEZyb21GcmFtZXdvcmsgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpO1xuICBpZiAoZG9Ob3RoaW5nKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHByb21pc2UgPSBjb21wRGV0YWlscy5uZXdBZ1N0YWNrSW5zdGFuY2UoKTtcbiAgbGV0IGNvbXA7XG4gIGxldCBjb21wR3VpO1xuICBsZXQgZGVzdHJveWVkID0gZmFsc2U7XG4gIHByb21pc2UudGhlbigoYykgPT4ge1xuICAgIGlmIChkZXN0cm95ZWQpIHtcbiAgICAgIGNvbnRleHQuZGVzdHJveUJlYW4oYyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbXAgPSBjO1xuICAgIGNvbXBHdWkgPSBjb21wLmdldEd1aSgpO1xuICAgIGVQYXJlbnQuYXBwZW5kQ2hpbGQoY29tcEd1aSk7XG4gICAgc2V0UmVmKHJlZiwgY29tcCk7XG4gIH0pO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGRlc3Ryb3llZCA9IHRydWU7XG4gICAgaWYgKCFjb21wKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbXBHdWk/LnJlbW92ZSgpO1xuICAgIGNvbnRleHQuZGVzdHJveUJlYW4oY29tcCk7XG4gICAgaWYgKHJlZikge1xuICAgICAgc2V0UmVmKHJlZiwgdm9pZCAwKTtcbiAgICB9XG4gIH07XG59O1xudmFyIHNldFJlZiA9IChyZWYsIHZhbHVlKSA9PiB7XG4gIGlmICghcmVmKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChyZWYgaW5zdGFuY2VvZiBGdW5jdGlvbikge1xuICAgIGNvbnN0IHJlZkNhbGxiYWNrID0gcmVmO1xuICAgIHJlZkNhbGxiYWNrKHZhbHVlKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCByZWZPYmogPSByZWY7XG4gICAgcmVmT2JqLmN1cnJlbnQgPSB2YWx1ZTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS91dGlscy50c3hcbmltcG9ydCBSZWFjdDIgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbVwiO1xudmFyIGNsYXNzZXNMaXN0ID0gKC4uLmxpc3QpID0+IHtcbiAgY29uc3QgZmlsdGVyZWQgPSBsaXN0LmZpbHRlcigocykgPT4gcyAhPSBudWxsICYmIHMgIT09IFwiXCIpO1xuICByZXR1cm4gZmlsdGVyZWQuam9pbihcIiBcIik7XG59O1xudmFyIENzc0NsYXNzZXMgPSBjbGFzcyBfQ3NzQ2xhc3NlcyB7XG4gIGNvbnN0cnVjdG9yKC4uLmluaXRpYWxDbGFzc2VzKSB7XG4gICAgdGhpcy5jbGFzc2VzTWFwID0ge307XG4gICAgZm9yIChjb25zdCBjbGFzc05hbWUgb2YgaW5pdGlhbENsYXNzZXMpIHtcbiAgICAgIHRoaXMuY2xhc3Nlc01hcFtjbGFzc05hbWVdID0gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgc2V0Q2xhc3MoY2xhc3NOYW1lLCBvbikge1xuICAgIGNvbnN0IG5vdGhpbmdIYXNDaGFuZ2VkID0gISF0aGlzLmNsYXNzZXNNYXBbY2xhc3NOYW1lXSA9PSBvbjtcbiAgICBpZiAobm90aGluZ0hhc0NoYW5nZWQpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBjb25zdCByZXMgPSBuZXcgX0Nzc0NsYXNzZXMoKTtcbiAgICByZXMuY2xhc3Nlc01hcCA9IHsgLi4udGhpcy5jbGFzc2VzTWFwIH07XG4gICAgcmVzLmNsYXNzZXNNYXBbY2xhc3NOYW1lXSA9IG9uO1xuICAgIHJldHVybiByZXM7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgY29uc3QgcmVzID0gT2JqZWN0LmtleXModGhpcy5jbGFzc2VzTWFwKS5maWx0ZXIoKGtleSkgPT4gdGhpcy5jbGFzc2VzTWFwW2tleV0pLmpvaW4oXCIgXCIpO1xuICAgIHJldHVybiByZXM7XG4gIH1cbn07XG52YXIgaXNDb21wb25lbnRTdGF0ZWxlc3MgPSAoQ29tcG9uZW50MikgPT4ge1xuICBjb25zdCBoYXNTeW1ib2wgPSAoKSA9PiB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgU3ltYm9sLmZvcjtcbiAgY29uc3QgZ2V0TWVtb1R5cGUgPSAoKSA9PiBoYXNTeW1ib2woKSA/IFN5bWJvbC5mb3IoXCJyZWFjdC5tZW1vXCIpIDogNjAxMTU7XG4gIHJldHVybiB0eXBlb2YgQ29tcG9uZW50MiA9PT0gXCJmdW5jdGlvblwiICYmICEoQ29tcG9uZW50Mi5wcm90b3R5cGUgJiYgQ29tcG9uZW50Mi5wcm90b3R5cGUuaXNSZWFjdENvbXBvbmVudCkgfHwgdHlwZW9mIENvbXBvbmVudDIgPT09IFwib2JqZWN0XCIgJiYgQ29tcG9uZW50Mi4kJHR5cGVvZiA9PT0gZ2V0TWVtb1R5cGUoKTtcbn07XG52YXIgcmVhY3RWZXJzaW9uID0gUmVhY3QyLnZlcnNpb24/LnNwbGl0KFwiLlwiKVswXTtcbnZhciBpc1JlYWN0VmVyc2lvbjE3TWludXMgPSByZWFjdFZlcnNpb24gPT09IFwiMTZcIiB8fCByZWFjdFZlcnNpb24gPT09IFwiMTdcIjtcbmZ1bmN0aW9uIGlzUmVhY3QxOSgpIHtcbiAgcmV0dXJuIHJlYWN0VmVyc2lvbiA9PT0gXCIxOVwiO1xufVxudmFyIGRpc2FibGVGbHVzaFN5bmMgPSBmYWxzZTtcbmZ1bmN0aW9uIHJ1bldpdGhvdXRGbHVzaFN5bmMoZnVuYykge1xuICBpZiAoIWRpc2FibGVGbHVzaFN5bmMpIHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IGRpc2FibGVGbHVzaFN5bmMgPSBmYWxzZSwgMCk7XG4gIH1cbiAgZGlzYWJsZUZsdXNoU3luYyA9IHRydWU7XG4gIHJldHVybiBmdW5jKCk7XG59XG52YXIgYWdGbHVzaFN5bmMgPSAodXNlRmx1c2hTeW5jLCBmbikgPT4ge1xuICBpZiAoIWlzUmVhY3RWZXJzaW9uMTdNaW51cyAmJiB1c2VGbHVzaFN5bmMgJiYgIWRpc2FibGVGbHVzaFN5bmMpIHtcbiAgICBSZWFjdERPTS5mbHVzaFN5bmMoZm4pO1xuICB9IGVsc2Uge1xuICAgIGZuKCk7XG4gIH1cbn07XG52YXIgYWdTdGFydFRyYW5zaXRpb24gPSAoZm4pID0+IHtcbiAgaWYgKCFpc1JlYWN0VmVyc2lvbjE3TWludXMpIHtcbiAgICBSZWFjdDIuc3RhcnRUcmFuc2l0aW9uKGZuKTtcbiAgfSBlbHNlIHtcbiAgICBmbigpO1xuICB9XG59O1xuZnVuY3Rpb24gYWdVc2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGdldFNuYXBzaG90LCBkZWZhdWx0U25hcHNob3QpIHtcbiAgaWYgKFJlYWN0Mi51c2VTeW5jRXh0ZXJuYWxTdG9yZSkge1xuICAgIHJldHVybiBSZWFjdDIudXNlU3luY0V4dGVybmFsU3RvcmUoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGRlZmF1bHRTbmFwc2hvdDtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0TmV4dFZhbHVlSWZEaWZmZXJlbnQocHJldiwgbmV4dCwgbWFpbnRhaW5PcmRlcikge1xuICBpZiAobmV4dCA9PSBudWxsIHx8IHByZXYgPT0gbnVsbCkge1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIGlmIChwcmV2ID09PSBuZXh0IHx8IG5leHQubGVuZ3RoID09PSAwICYmIHByZXYubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIHByZXY7XG4gIH1cbiAgaWYgKG1haW50YWluT3JkZXIgfHwgcHJldi5sZW5ndGggPT09IDAgJiYgbmV4dC5sZW5ndGggPiAwIHx8IHByZXYubGVuZ3RoID4gMCAmJiBuZXh0Lmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBuZXh0O1xuICB9XG4gIGNvbnN0IG9sZFZhbHVlcyA9IFtdO1xuICBjb25zdCBuZXdWYWx1ZXMgPSBbXTtcbiAgY29uc3QgcHJldk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGNvbnN0IG5leHRNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG5leHQubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjID0gbmV4dFtpXTtcbiAgICBuZXh0TWFwLnNldChjLmluc3RhbmNlSWQsIGMpO1xuICB9XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcHJldi5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGMgPSBwcmV2W2ldO1xuICAgIHByZXZNYXAuc2V0KGMuaW5zdGFuY2VJZCwgYyk7XG4gICAgaWYgKG5leHRNYXAuaGFzKGMuaW5zdGFuY2VJZCkpIHtcbiAgICAgIG9sZFZhbHVlcy5wdXNoKGMpO1xuICAgIH1cbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IG5leHQubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjID0gbmV4dFtpXTtcbiAgICBjb25zdCBpbnN0YW5jZUlkID0gYy5pbnN0YW5jZUlkO1xuICAgIGlmICghcHJldk1hcC5oYXMoaW5zdGFuY2VJZCkpIHtcbiAgICAgIG5ld1ZhbHVlcy5wdXNoKGMpO1xuICAgIH1cbiAgfVxuICBpZiAob2xkVmFsdWVzLmxlbmd0aCA9PT0gcHJldi5sZW5ndGggJiYgbmV3VmFsdWVzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBwcmV2O1xuICB9XG4gIGlmIChvbGRWYWx1ZXMubGVuZ3RoID09PSAwICYmIG5ld1ZhbHVlcy5sZW5ndGggPT09IG5leHQubGVuZ3RoKSB7XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cbiAgaWYgKG9sZFZhbHVlcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbmV3VmFsdWVzO1xuICB9XG4gIGlmIChuZXdWYWx1ZXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG9sZFZhbHVlcztcbiAgfVxuICByZXR1cm4gWy4uLm9sZFZhbHVlcywgLi4ubmV3VmFsdWVzXTtcbn1cblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9jZWxsUmVuZGVyZXIvZ3JvdXBDZWxsUmVuZGVyZXIudHN4XG52YXIgR3JvdXBDZWxsUmVuZGVyZXIgPSBmb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIGNvbnN0IHsgcmVnaXN0cnksIGNvbnRleHQgfSA9IHVzZUNvbnRleHQoQmVhbnNDb250ZXh0KTtcbiAgY29uc3QgZUd1aSA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgZVZhbHVlUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBlQ2hlY2tib3hSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IGVFeHBhbmRlZFJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgZUNvbnRyYWN0ZWRSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IGN0cmxSZWYgPSB1c2VSZWYoKTtcbiAgY29uc3QgW2lubmVyQ29tcERldGFpbHMsIHNldElubmVyQ29tcERldGFpbHNdID0gdXNlU3RhdGUoKTtcbiAgY29uc3QgW2NoaWxkQ291bnQsIHNldENoaWxkQ291bnRdID0gdXNlU3RhdGUoKTtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZSgpO1xuICBjb25zdCBbY3NzQ2xhc3Nlcywgc2V0Q3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgQ3NzQ2xhc3NlcygpKTtcbiAgY29uc3QgW2V4cGFuZGVkQ3NzQ2xhc3Nlcywgc2V0RXhwYW5kZWRDc3NDbGFzc2VzXSA9IHVzZVN0YXRlKCgpID0+IG5ldyBDc3NDbGFzc2VzKFwiYWctaGlkZGVuXCIpKTtcbiAgY29uc3QgW2NvbnRyYWN0ZWRDc3NDbGFzc2VzLCBzZXRDb250cmFjdGVkQ3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgQ3NzQ2xhc3NlcyhcImFnLWhpZGRlblwiKSk7XG4gIGNvbnN0IFtjaGVja2JveENzc0NsYXNzZXMsIHNldENoZWNrYm94Q3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgQ3NzQ2xhc3NlcyhcImFnLWludmlzaWJsZVwiKSk7XG4gIHVzZUltcGVyYXRpdmVIYW5kbGUocmVmLCAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC8vIGZvcmNlIG5ldyBpbnN0YW5jZSB3aGVuIGdyaWQgdHJpZXMgdG8gcmVmcmVzaFxuICAgICAgcmVmcmVzaCgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH07XG4gIH0pO1xuICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiBzaG93SnNDb21wKGlubmVyQ29tcERldGFpbHMsIGNvbnRleHQsIGVWYWx1ZVJlZi5jdXJyZW50KTtcbiAgfSwgW2lubmVyQ29tcERldGFpbHNdKTtcbiAgY29uc3Qgc2V0UmVmMiA9IHVzZUNhbGxiYWNrKChlUmVmKSA9PiB7XG4gICAgZUd1aS5jdXJyZW50ID0gZVJlZjtcbiAgICBpZiAoIWVSZWYgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICBjdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmRlc3Ryb3lCZWFuKGN0cmxSZWYuY3VycmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHNldElubmVyUmVuZGVyZXI6IChkZXRhaWxzLCB2YWx1ZVRvRGlzcGxheSkgPT4ge1xuICAgICAgICBzZXRJbm5lckNvbXBEZXRhaWxzKGRldGFpbHMpO1xuICAgICAgICBzZXRWYWx1ZSh2YWx1ZVRvRGlzcGxheSk7XG4gICAgICB9LFxuICAgICAgc2V0Q2hpbGRDb3VudDogKGNvdW50KSA9PiBzZXRDaGlsZENvdW50KGNvdW50KSxcbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBzZXRDc3NDbGFzc2VzKChwcmV2KSA9PiBwcmV2LnNldENsYXNzKG5hbWUsIG9uKSksXG4gICAgICBzZXRDb250cmFjdGVkRGlzcGxheWVkOiAoZGlzcGxheWVkKSA9PiBzZXRDb250cmFjdGVkQ3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhcImFnLWhpZGRlblwiLCAhZGlzcGxheWVkKSksXG4gICAgICBzZXRFeHBhbmRlZERpc3BsYXllZDogKGRpc3BsYXllZCkgPT4gc2V0RXhwYW5kZWRDc3NDbGFzc2VzKChwcmV2KSA9PiBwcmV2LnNldENsYXNzKFwiYWctaGlkZGVuXCIsICFkaXNwbGF5ZWQpKSxcbiAgICAgIHNldENoZWNrYm94VmlzaWJsZTogKHZpc2libGUpID0+IHNldENoZWNrYm94Q3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhcImFnLWludmlzaWJsZVwiLCAhdmlzaWJsZSkpLFxuICAgICAgc2V0Q2hlY2tib3hTcGFjaW5nOiAoYWRkKSA9PiBzZXRDaGVja2JveENzc0NsYXNzZXMoKHByZXYpID0+IHByZXYuc2V0Q2xhc3MoXCJhZy1ncm91cC1jaGVja2JveC1zcGFjaW5nXCIsIGFkZCkpXG4gICAgfTtcbiAgICBjb25zdCBncm91cENlbGxSZW5kZXJlckN0cmwgPSByZWdpc3RyeS5jcmVhdGVEeW5hbWljQmVhbihcImdyb3VwQ2VsbFJlbmRlcmVyQ3RybFwiLCB0cnVlKTtcbiAgICBpZiAoZ3JvdXBDZWxsUmVuZGVyZXJDdHJsKSB7XG4gICAgICBjdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4oZ3JvdXBDZWxsUmVuZGVyZXJDdHJsKTtcbiAgICAgIGN0cmxSZWYuY3VycmVudC5pbml0KFxuICAgICAgICBjb21wUHJveHksXG4gICAgICAgIGVSZWYsXG4gICAgICAgIGVDaGVja2JveFJlZi5jdXJyZW50LFxuICAgICAgICBlRXhwYW5kZWRSZWYuY3VycmVudCxcbiAgICAgICAgZUNvbnRyYWN0ZWRSZWYuY3VycmVudCxcbiAgICAgICAgR3JvdXBDZWxsUmVuZGVyZXIsXG4gICAgICAgIHByb3BzXG4gICAgICApO1xuICAgIH1cbiAgfSwgW10pO1xuICBjb25zdCBjbGFzc05hbWUgPSB1c2VNZW1vKCgpID0+IGBhZy1jZWxsLXdyYXBwZXIgJHtjc3NDbGFzc2VzLnRvU3RyaW5nKCl9YCwgW2Nzc0NsYXNzZXNdKTtcbiAgY29uc3QgZXhwYW5kZWRDbGFzc05hbWUgPSB1c2VNZW1vKCgpID0+IGBhZy1ncm91cC1leHBhbmRlZCAke2V4cGFuZGVkQ3NzQ2xhc3Nlcy50b1N0cmluZygpfWAsIFtleHBhbmRlZENzc0NsYXNzZXNdKTtcbiAgY29uc3QgY29udHJhY3RlZENsYXNzTmFtZSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gYGFnLWdyb3VwLWNvbnRyYWN0ZWQgJHtjb250cmFjdGVkQ3NzQ2xhc3Nlcy50b1N0cmluZygpfWAsXG4gICAgW2NvbnRyYWN0ZWRDc3NDbGFzc2VzXVxuICApO1xuICBjb25zdCBjaGVja2JveENsYXNzTmFtZSA9IHVzZU1lbW8oKCkgPT4gYGFnLWdyb3VwLWNoZWNrYm94ICR7Y2hlY2tib3hDc3NDbGFzc2VzLnRvU3RyaW5nKCl9YCwgW2NoZWNrYm94Q3NzQ2xhc3Nlc10pO1xuICBjb25zdCB1c2VGd1JlbmRlcmVyID0gaW5uZXJDb21wRGV0YWlscz8uY29tcG9uZW50RnJvbUZyYW1ld29yaztcbiAgY29uc3QgRndSZW5kZXJlciA9IHVzZUZ3UmVuZGVyZXIgPyBpbm5lckNvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzIDogdm9pZCAwO1xuICBjb25zdCB1c2VWYWx1ZSA9IGlubmVyQ29tcERldGFpbHMgPT0gbnVsbCAmJiB2YWx1ZSAhPSBudWxsO1xuICBjb25zdCBlc2NhcGVkVmFsdWUgPSBfdG9TdHJpbmcodmFsdWUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0My5jcmVhdGVFbGVtZW50KFxuICAgIFwic3BhblwiLFxuICAgIHtcbiAgICAgIGNsYXNzTmFtZSxcbiAgICAgIHJlZjogc2V0UmVmMixcbiAgICAgIC4uLiFwcm9wcy5jb2xEZWYgPyB7IHJvbGU6IGN0cmxSZWYuY3VycmVudD8uZ2V0Q2VsbEFyaWFSb2xlKCkgfSA6IHt9XG4gICAgfSxcbiAgICAvKiBAX19QVVJFX18gKi8gUmVhY3QzLmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIsIHsgY2xhc3NOYW1lOiBleHBhbmRlZENsYXNzTmFtZSwgcmVmOiBlRXhwYW5kZWRSZWYgfSksXG4gICAgLyogQF9fUFVSRV9fICovIFJlYWN0My5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7IGNsYXNzTmFtZTogY29udHJhY3RlZENsYXNzTmFtZSwgcmVmOiBlQ29udHJhY3RlZFJlZiB9KSxcbiAgICAvKiBAX19QVVJFX18gKi8gUmVhY3QzLmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIsIHsgY2xhc3NOYW1lOiBjaGVja2JveENsYXNzTmFtZSwgcmVmOiBlQ2hlY2tib3hSZWYgfSksXG4gICAgLyogQF9fUFVSRV9fICovIFJlYWN0My5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7IGNsYXNzTmFtZTogXCJhZy1ncm91cC12YWx1ZVwiLCByZWY6IGVWYWx1ZVJlZiB9LCB1c2VWYWx1ZSA/IGVzY2FwZWRWYWx1ZSA6IHVzZUZ3UmVuZGVyZXIgPyAvKiBAX19QVVJFX18gKi8gUmVhY3QzLmNyZWF0ZUVsZW1lbnQoRndSZW5kZXJlciwgeyAuLi5pbm5lckNvbXBEZXRhaWxzLnBhcmFtcyB9KSA6IG51bGwpLFxuICAgIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDMuY3JlYXRlRWxlbWVudChcInNwYW5cIiwgeyBjbGFzc05hbWU6IFwiYWctZ3JvdXAtY2hpbGQtY291bnRcIiB9LCBjaGlsZENvdW50KVxuICApO1xufSk7XG52YXIgZ3JvdXBDZWxsUmVuZGVyZXJfZGVmYXVsdCA9IEdyb3VwQ2VsbFJlbmRlcmVyO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC9jdXN0b21Db21wb25lbnRXcmFwcGVyLnRzXG5pbXBvcnQgeyBBZ1Byb21pc2UgYXMgQWdQcm9taXNlMiB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2N1c3RvbUNvbXAvY3VzdG9tV3JhcHBlckNvbXAudHN4XG5pbXBvcnQgUmVhY3Q0LCB7IG1lbW8sIHVzZUVmZmVjdCwgdXNlU3RhdGUgYXMgdXNlU3RhdGUyIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL2N1c3RvbUNvbnRleHQudHNcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcbnZhciBDdXN0b21Db250ZXh0ID0gY3JlYXRlQ29udGV4dCh7XG4gIHNldE1ldGhvZHM6ICgpID0+IHtcbiAgfVxufSk7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvY3VzdG9tQ29tcC9jdXN0b21XcmFwcGVyQ29tcC50c3hcbnZhciBDdXN0b21XcmFwcGVyQ29tcCA9IChwYXJhbXMpID0+IHtcbiAgY29uc3QgeyBpbml0aWFsUHJvcHMsIGFkZFVwZGF0ZUNhbGxiYWNrLCBDdXN0b21Db21wb25lbnRDbGFzcywgc2V0TWV0aG9kcyB9ID0gcGFyYW1zO1xuICBjb25zdCBbeyBrZXksIC4uLnByb3BzIH0sIHNldFByb3BzXSA9IHVzZVN0YXRlMihpbml0aWFsUHJvcHMpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFkZFVwZGF0ZUNhbGxiYWNrKChuZXdQcm9wcykgPT4gc2V0UHJvcHMobmV3UHJvcHMpKTtcbiAgfSwgW10pO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0NC5jcmVhdGVFbGVtZW50KEN1c3RvbUNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHsgc2V0TWV0aG9kcyB9IH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDQuY3JlYXRlRWxlbWVudChDdXN0b21Db21wb25lbnRDbGFzcywgeyBrZXksIC4uLnByb3BzIH0pKTtcbn07XG52YXIgY3VzdG9tV3JhcHBlckNvbXBfZGVmYXVsdCA9IG1lbW8oQ3VzdG9tV3JhcHBlckNvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvcmVhY3RDb21wb25lbnQudHNcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCB7IEFnUHJvbWlzZSB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQva2V5R2VuZXJhdG9yLnRzXG52YXIgY291bnRlciA9IDA7XG5mdW5jdGlvbiBnZW5lcmF0ZU5ld0tleSgpIHtcbiAgcmV0dXJuIGBhZ1BvcnRhbEtleV8keysrY291bnRlcn1gO1xufVxuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvcmVhY3RDb21wb25lbnQudHNcbnZhciBSZWFjdENvbXBvbmVudCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IocmVhY3RDb21wb25lbnQsIHBvcnRhbE1hbmFnZXIsIGNvbXBvbmVudFR5cGUsIHN1cHByZXNzRmFsbGJhY2tNZXRob2RzKSB7XG4gICAgdGhpcy5wb3J0YWwgPSBudWxsO1xuICAgIHRoaXMub2xkUG9ydGFsID0gbnVsbDtcbiAgICB0aGlzLnJlYWN0Q29tcG9uZW50ID0gcmVhY3RDb21wb25lbnQ7XG4gICAgdGhpcy5wb3J0YWxNYW5hZ2VyID0gcG9ydGFsTWFuYWdlcjtcbiAgICB0aGlzLmNvbXBvbmVudFR5cGUgPSBjb21wb25lbnRUeXBlO1xuICAgIHRoaXMuc3VwcHJlc3NGYWxsYmFja01ldGhvZHMgPSAhIXN1cHByZXNzRmFsbGJhY2tNZXRob2RzO1xuICAgIHRoaXMuc3RhdGVsZXNzQ29tcG9uZW50ID0gdGhpcy5pc1N0YXRlbGVzcyh0aGlzLnJlYWN0Q29tcG9uZW50KTtcbiAgICB0aGlzLmtleSA9IGdlbmVyYXRlTmV3S2V5KCk7XG4gICAgdGhpcy5wb3J0YWxLZXkgPSBnZW5lcmF0ZU5ld0tleSgpO1xuICAgIHRoaXMuaW5zdGFuY2VDcmVhdGVkID0gdGhpcy5pc1N0YXRlbGVzc0NvbXBvbmVudCgpID8gQWdQcm9taXNlLnJlc29sdmUoZmFsc2UpIDogbmV3IEFnUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgdGhpcy5yZXNvbHZlSW5zdGFuY2VDcmVhdGVkID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgfVxuICBnZXRHdWkoKSB7XG4gICAgcmV0dXJuIHRoaXMuZVBhcmVudEVsZW1lbnQ7XG4gIH1cbiAgLyoqIGBnZXRHdWkoKWAgcmV0dXJucyB0aGUgcGFyZW50IGVsZW1lbnQuIFRoaXMgcmV0dXJucyB0aGUgYWN0dWFsIHJvb3QgZWxlbWVudC4gKi9cbiAgZ2V0Um9vdEVsZW1lbnQoKSB7XG4gICAgY29uc3QgZmlyc3RDaGlsZCA9IHRoaXMuZVBhcmVudEVsZW1lbnQuZmlyc3RDaGlsZDtcbiAgICByZXR1cm4gZmlyc3RDaGlsZDtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIGlmICh0aGlzLmNvbXBvbmVudEluc3RhbmNlICYmIHR5cGVvZiB0aGlzLmNvbXBvbmVudEluc3RhbmNlLmRlc3Ryb3kgPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aGlzLmNvbXBvbmVudEluc3RhbmNlLmRlc3Ryb3koKTtcbiAgICB9XG4gICAgY29uc3QgcG9ydGFsID0gdGhpcy5wb3J0YWw7XG4gICAgaWYgKHBvcnRhbCkge1xuICAgICAgdGhpcy5wb3J0YWxNYW5hZ2VyLmRlc3Ryb3lQb3J0YWwocG9ydGFsKTtcbiAgICB9XG4gIH1cbiAgY3JlYXRlUGFyZW50RWxlbWVudChwYXJhbXMpIHtcbiAgICBjb25zdCBjb21wb25lbnRXcmFwcGluZ0VsZW1lbnQgPSB0aGlzLnBvcnRhbE1hbmFnZXIuZ2V0Q29tcG9uZW50V3JhcHBpbmdFbGVtZW50KCk7XG4gICAgY29uc3QgZVBhcmVudEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KGNvbXBvbmVudFdyYXBwaW5nRWxlbWVudCB8fCBcImRpdlwiKTtcbiAgICBlUGFyZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiYWctcmVhY3QtY29udGFpbmVyXCIpO1xuICAgIHBhcmFtcy5yZWFjdENvbnRhaW5lciA9IGVQYXJlbnRFbGVtZW50O1xuICAgIHJldHVybiBlUGFyZW50RWxlbWVudDtcbiAgfVxuICBzdGF0ZWxlc3NDb21wb25lbnRSZW5kZXJlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5lUGFyZW50RWxlbWVudC5jaGlsZEVsZW1lbnRDb3VudCA+IDAgfHwgdGhpcy5lUGFyZW50RWxlbWVudC5jaGlsZE5vZGVzLmxlbmd0aCA+IDA7XG4gIH1cbiAgZ2V0RnJhbWV3b3JrQ29tcG9uZW50SW5zdGFuY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29tcG9uZW50SW5zdGFuY2U7XG4gIH1cbiAgaXNTdGF0ZWxlc3NDb21wb25lbnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGVsZXNzQ29tcG9uZW50O1xuICB9XG4gIGdldFJlYWN0Q29tcG9uZW50TmFtZSgpIHtcbiAgICByZXR1cm4gdGhpcy5yZWFjdENvbXBvbmVudC5uYW1lO1xuICB9XG4gIGdldE1lbW9UeXBlKCkge1xuICAgIHJldHVybiB0aGlzLmhhc1N5bWJvbCgpID8gU3ltYm9sLmZvcihcInJlYWN0Lm1lbW9cIikgOiA2MDExNTtcbiAgfVxuICBoYXNTeW1ib2woKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBTeW1ib2wuZm9yO1xuICB9XG4gIGlzU3RhdGVsZXNzKENvbXBvbmVudDIpIHtcbiAgICByZXR1cm4gdHlwZW9mIENvbXBvbmVudDIgPT09IFwiZnVuY3Rpb25cIiAmJiAhKENvbXBvbmVudDIucHJvdG90eXBlICYmIENvbXBvbmVudDIucHJvdG90eXBlLmlzUmVhY3RDb21wb25lbnQpIHx8IHR5cGVvZiBDb21wb25lbnQyID09PSBcIm9iamVjdFwiICYmIENvbXBvbmVudDIuJCR0eXBlb2YgPT09IHRoaXMuZ2V0TWVtb1R5cGUoKTtcbiAgfVxuICBoYXNNZXRob2QobmFtZSkge1xuICAgIGNvbnN0IGZyYW1ld29ya0NvbXBvbmVudEluc3RhbmNlID0gdGhpcy5nZXRGcmFtZXdvcmtDb21wb25lbnRJbnN0YW5jZSgpO1xuICAgIHJldHVybiAhIWZyYW1ld29ya0NvbXBvbmVudEluc3RhbmNlICYmIGZyYW1ld29ya0NvbXBvbmVudEluc3RhbmNlW25hbWVdICE9IG51bGwgfHwgdGhpcy5mYWxsYmFja01ldGhvZEF2YWlsYWJsZShuYW1lKTtcbiAgfVxuICBjYWxsTWV0aG9kKG5hbWUsIGFyZ3MpIHtcbiAgICBjb25zdCBmcmFtZXdvcmtDb21wb25lbnRJbnN0YW5jZSA9IHRoaXMuZ2V0RnJhbWV3b3JrQ29tcG9uZW50SW5zdGFuY2UoKTtcbiAgICBpZiAodGhpcy5pc1N0YXRlbGVzc0NvbXBvbmVudCgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5mYWxsYmFja01ldGhvZChuYW1lLCAhIWFyZ3MgJiYgYXJnc1swXSA/IGFyZ3NbMF0gOiB7fSk7XG4gICAgfSBlbHNlIGlmICghZnJhbWV3b3JrQ29tcG9uZW50SW5zdGFuY2UpIHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5jYWxsTWV0aG9kKG5hbWUsIGFyZ3MpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kID0gZnJhbWV3b3JrQ29tcG9uZW50SW5zdGFuY2VbbmFtZV07XG4gICAgaWYgKG1ldGhvZCkge1xuICAgICAgcmV0dXJuIG1ldGhvZC5hcHBseShmcmFtZXdvcmtDb21wb25lbnRJbnN0YW5jZSwgYXJncyk7XG4gICAgfVxuICAgIGlmICh0aGlzLmZhbGxiYWNrTWV0aG9kQXZhaWxhYmxlKG5hbWUpKSB7XG4gICAgICByZXR1cm4gdGhpcy5mYWxsYmFja01ldGhvZChuYW1lLCAhIWFyZ3MgJiYgYXJnc1swXSA/IGFyZ3NbMF0gOiB7fSk7XG4gICAgfVxuICB9XG4gIGFkZE1ldGhvZChuYW1lLCBjYWxsYmFjaykge1xuICAgIHRoaXNbbmFtZV0gPSBjYWxsYmFjaztcbiAgfVxuICBpbml0KHBhcmFtcykge1xuICAgIHRoaXMuZVBhcmVudEVsZW1lbnQgPSB0aGlzLmNyZWF0ZVBhcmVudEVsZW1lbnQocGFyYW1zKTtcbiAgICB0aGlzLmNyZWF0ZU9yVXBkYXRlUG9ydGFsKHBhcmFtcyk7XG4gICAgcmV0dXJuIG5ldyBBZ1Byb21pc2UoKHJlc29sdmUpID0+IHRoaXMuY3JlYXRlUmVhY3RDb21wb25lbnQocmVzb2x2ZSkpO1xuICB9XG4gIGNyZWF0ZU9yVXBkYXRlUG9ydGFsKHBhcmFtcykge1xuICAgIGlmICghdGhpcy5pc1N0YXRlbGVzc0NvbXBvbmVudCgpKSB7XG4gICAgICB0aGlzLnJlZiA9IChlbGVtZW50KSA9PiB7XG4gICAgICAgIHRoaXMuY29tcG9uZW50SW5zdGFuY2UgPSBlbGVtZW50O1xuICAgICAgICB0aGlzLnJlc29sdmVJbnN0YW5jZUNyZWF0ZWQ/Lih0cnVlKTtcbiAgICAgICAgdGhpcy5yZXNvbHZlSW5zdGFuY2VDcmVhdGVkID0gdm9pZCAwO1xuICAgICAgfTtcbiAgICAgIHBhcmFtcy5yZWYgPSB0aGlzLnJlZjtcbiAgICB9XG4gICAgdGhpcy5yZWFjdEVsZW1lbnQgPSB0aGlzLmNyZWF0ZUVsZW1lbnQodGhpcy5yZWFjdENvbXBvbmVudCwgeyAuLi5wYXJhbXMsIGtleTogdGhpcy5rZXkgfSk7XG4gICAgdGhpcy5wb3J0YWwgPSBjcmVhdGVQb3J0YWwoXG4gICAgICB0aGlzLnJlYWN0RWxlbWVudCxcbiAgICAgIHRoaXMuZVBhcmVudEVsZW1lbnQsXG4gICAgICB0aGlzLnBvcnRhbEtleVxuICAgICAgLy8gZml4ZWQgZGVsdGFSb3dNb2RlUmVmcmVzaENvbXBSZW5kZXJlclxuICAgICk7XG4gIH1cbiAgY3JlYXRlRWxlbWVudChyZWFjdENvbXBvbmVudCwgcHJvcHMpIHtcbiAgICByZXR1cm4gY3JlYXRlRWxlbWVudChyZWFjdENvbXBvbmVudCwgcHJvcHMpO1xuICB9XG4gIGNyZWF0ZVJlYWN0Q29tcG9uZW50KHJlc29sdmUpIHtcbiAgICB0aGlzLnBvcnRhbE1hbmFnZXIubW91bnRSZWFjdFBvcnRhbCh0aGlzLnBvcnRhbCwgdGhpcywgcmVzb2x2ZSk7XG4gIH1cbiAgcmVuZGVyZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuaXNTdGF0ZWxlc3NDb21wb25lbnQoKSAmJiB0aGlzLnN0YXRlbGVzc0NvbXBvbmVudFJlbmRlcmVkKCkgfHwgISEoIXRoaXMuaXNTdGF0ZWxlc3NDb21wb25lbnQoKSAmJiB0aGlzLmdldEZyYW1ld29ya0NvbXBvbmVudEluc3RhbmNlKCkpO1xuICB9XG4gIC8qXG4gICAqIGZhbGxiYWNrIG1ldGhvZHMgLSB0aGVzZSB3aWxsIGJlIGludm9rZWQgaWYgYSBjb3JyZXNwb25kaW5nIGluc3RhbmNlIG1ldGhvZCBpcyBub3QgcHJlc2VudFxuICAgKiBmb3IgZXhhbXBsZSBpZiByZWZyZXNoIGlzIGNhbGxlZCBhbmQgaXMgbm90IGF2YWlsYWJsZSBvbiB0aGUgY29tcG9uZW50IGluc3RhbmNlLCB0aGVuIHJlZnJlc2hDb21wb25lbnQgb24gdGhpc1xuICAgKiBjbGFzcyB3aWxsIGJlIGludm9rZWQgaW5zdGVhZFxuICAgKlxuICAgKiBDdXJyZW50bHkgb25seSByZWZyZXNoIGlzIHN1cHBvcnRlZFxuICAgKi9cbiAgcmVmcmVzaENvbXBvbmVudChhcmdzKSB7XG4gICAgdGhpcy5vbGRQb3J0YWwgPSB0aGlzLnBvcnRhbDtcbiAgICB0aGlzLmNyZWF0ZU9yVXBkYXRlUG9ydGFsKGFyZ3MpO1xuICAgIHRoaXMucG9ydGFsTWFuYWdlci51cGRhdGVSZWFjdFBvcnRhbCh0aGlzLm9sZFBvcnRhbCwgdGhpcy5wb3J0YWwpO1xuICB9XG4gIGZhbGxiYWNrTWV0aG9kKG5hbWUsIHBhcmFtcykge1xuICAgIGNvbnN0IG1ldGhvZCA9IHRoaXNbYCR7bmFtZX1Db21wb25lbnRgXTtcbiAgICBpZiAoIXRoaXMuc3VwcHJlc3NGYWxsYmFja01ldGhvZHMgJiYgISFtZXRob2QpIHtcbiAgICAgIHJldHVybiBtZXRob2QuYmluZCh0aGlzKShwYXJhbXMpO1xuICAgIH1cbiAgfVxuICBmYWxsYmFja01ldGhvZEF2YWlsYWJsZShuYW1lKSB7XG4gICAgaWYgKHRoaXMuc3VwcHJlc3NGYWxsYmFja01ldGhvZHMpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kID0gdGhpc1tgJHtuYW1lfUNvbXBvbmVudGBdO1xuICAgIHJldHVybiAhIW1ldGhvZDtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvY3VzdG9tQ29tcG9uZW50V3JhcHBlci50c1xuZnVuY3Rpb24gYWRkT3B0aW9uYWxNZXRob2RzKG9wdGlvbmFsTWV0aG9kTmFtZXMsIHByb3ZpZGVkTWV0aG9kcywgY29tcG9uZW50KSB7XG4gIGZvciAoY29uc3QgbWV0aG9kTmFtZSBvZiBvcHRpb25hbE1ldGhvZE5hbWVzKSB7XG4gICAgY29uc3QgcHJvdmlkZWRNZXRob2QgPSBwcm92aWRlZE1ldGhvZHNbbWV0aG9kTmFtZV07XG4gICAgaWYgKHByb3ZpZGVkTWV0aG9kKSB7XG4gICAgICBjb21wb25lbnRbbWV0aG9kTmFtZV0gPSBwcm92aWRlZE1ldGhvZDtcbiAgICB9XG4gIH1cbn1cbnZhciBDdXN0b21Db21wb25lbnRXcmFwcGVyID0gY2xhc3MgZXh0ZW5kcyBSZWFjdENvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5hd2FpdFVwZGF0ZUNhbGxiYWNrID0gbmV3IEFnUHJvbWlzZTIoKHJlc29sdmUpID0+IHtcbiAgICAgIHRoaXMucmVzb2x2ZVVwZGF0ZUNhbGxiYWNrID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgICB0aGlzLndyYXBwZXJDb21wb25lbnQgPSBjdXN0b21XcmFwcGVyQ29tcF9kZWZhdWx0O1xuICB9XG4gIGluaXQocGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBwYXJhbXM7XG4gICAgcmV0dXJuIHN1cGVyLmluaXQodGhpcy5nZXRQcm9wcygpKTtcbiAgfVxuICBhZGRNZXRob2QoKSB7XG4gIH1cbiAgZ2V0SW5zdGFuY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5zdGFuY2VDcmVhdGVkLnRoZW4oKCkgPT4gdGhpcy5jb21wb25lbnRJbnN0YW5jZSk7XG4gIH1cbiAgZ2V0RnJhbWV3b3JrQ29tcG9uZW50SW5zdGFuY2UoKSB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgY3JlYXRlRWxlbWVudChyZWFjdENvbXBvbmVudCwgcHJvcHMpIHtcbiAgICByZXR1cm4gc3VwZXIuY3JlYXRlRWxlbWVudCh0aGlzLndyYXBwZXJDb21wb25lbnQsIHtcbiAgICAgIGluaXRpYWxQcm9wczogcHJvcHMsXG4gICAgICBDdXN0b21Db21wb25lbnRDbGFzczogcmVhY3RDb21wb25lbnQsXG4gICAgICBzZXRNZXRob2RzOiAobWV0aG9kcykgPT4gdGhpcy5zZXRNZXRob2RzKG1ldGhvZHMpLFxuICAgICAgYWRkVXBkYXRlQ2FsbGJhY2s6IChjYWxsYmFjaykgPT4ge1xuICAgICAgICB0aGlzLnVwZGF0ZUNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrKHRoaXMuZ2V0UHJvcHMoKSk7XG4gICAgICAgICAgcmV0dXJuIG5ldyBBZ1Byb21pc2UyKChyZXNvbHZlKSA9PiB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMucmVzb2x2ZVVwZGF0ZUNhbGxiYWNrKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgc2V0TWV0aG9kcyhtZXRob2RzKSB7XG4gICAgdGhpcy5wcm92aWRlZE1ldGhvZHMgPSBtZXRob2RzO1xuICAgIGFkZE9wdGlvbmFsTWV0aG9kcyh0aGlzLmdldE9wdGlvbmFsTWV0aG9kcygpLCB0aGlzLnByb3ZpZGVkTWV0aG9kcywgdGhpcyk7XG4gIH1cbiAgZ2V0T3B0aW9uYWxNZXRob2RzKCkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBnZXRQcm9wcygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4udGhpcy5zb3VyY2VQYXJhbXMsXG4gICAgICBrZXk6IHRoaXMua2V5LFxuICAgICAgcmVmOiB0aGlzLnJlZlxuICAgIH07XG4gIH1cbiAgcmVmcmVzaFByb3BzKCkge1xuICAgIGlmICh0aGlzLnVwZGF0ZUNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gdGhpcy51cGRhdGVDYWxsYmFjaygpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEFnUHJvbWlzZTIoXG4gICAgICAocmVzb2x2ZSkgPT4gdGhpcy5hd2FpdFVwZGF0ZUNhbGxiYWNrLnRoZW4oKCkgPT4ge1xuICAgICAgICB0aGlzLnVwZGF0ZUNhbGxiYWNrKCkudGhlbigoKSA9PiByZXNvbHZlKCkpO1xuICAgICAgfSlcbiAgICApO1xuICB9XG59O1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC9jZWxsUmVuZGVyZXJDb21wb25lbnRXcmFwcGVyLnRzXG52YXIgQ2VsbFJlbmRlcmVyQ29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQ3VzdG9tQ29tcG9uZW50V3JhcHBlciB7XG4gIHJlZnJlc2gocGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBwYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvZGF0ZUNvbXBvbmVudFdyYXBwZXIudHNcbnZhciBEYXRlQ29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQ3VzdG9tQ29tcG9uZW50V3JhcHBlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5kYXRlID0gbnVsbDtcbiAgICB0aGlzLm9uRGF0ZUNoYW5nZSA9IChkYXRlKSA9PiB0aGlzLnVwZGF0ZURhdGUoZGF0ZSk7XG4gIH1cbiAgZ2V0RGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5kYXRlO1xuICB9XG4gIHNldERhdGUoZGF0ZSkge1xuICAgIHRoaXMuZGF0ZSA9IGRhdGU7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxuICByZWZyZXNoKHBhcmFtcykge1xuICAgIHRoaXMuc291cmNlUGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgZ2V0T3B0aW9uYWxNZXRob2RzKCkge1xuICAgIHJldHVybiBbXCJhZnRlckd1aUF0dGFjaGVkXCIsIFwic2V0SW5wdXRQbGFjZWhvbGRlclwiLCBcInNldElucHV0QXJpYUxhYmVsXCIsIFwic2V0RGlzYWJsZWRcIl07XG4gIH1cbiAgdXBkYXRlRGF0ZShkYXRlKSB7XG4gICAgdGhpcy5zZXREYXRlKGRhdGUpO1xuICAgIHRoaXMuc291cmNlUGFyYW1zLm9uRGF0ZUNoYW5nZWQoKTtcbiAgfVxuICBnZXRQcm9wcygpIHtcbiAgICBjb25zdCBwcm9wcyA9IHN1cGVyLmdldFByb3BzKCk7XG4gICAgcHJvcHMuZGF0ZSA9IHRoaXMuZGF0ZTtcbiAgICBwcm9wcy5vbkRhdGVDaGFuZ2UgPSB0aGlzLm9uRGF0ZUNoYW5nZTtcbiAgICBkZWxldGUgcHJvcHMub25EYXRlQ2hhbmdlZDtcbiAgICByZXR1cm4gcHJvcHM7XG4gIH1cbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL2RyYWdBbmREcm9wSW1hZ2VDb21wb25lbnRXcmFwcGVyLnRzXG52YXIgRHJhZ0FuZERyb3BJbWFnZUNvbXBvbmVudFdyYXBwZXIgPSBjbGFzcyBleHRlbmRzIEN1c3RvbUNvbXBvbmVudFdyYXBwZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMubGFiZWwgPSBcIlwiO1xuICAgIHRoaXMuaWNvbiA9IG51bGw7XG4gICAgdGhpcy5zaGFrZSA9IGZhbHNlO1xuICB9XG4gIHNldEljb24oaWNvbk5hbWUsIHNoYWtlKSB7XG4gICAgdGhpcy5pY29uID0gaWNvbk5hbWU7XG4gICAgdGhpcy5zaGFrZSA9IHNoYWtlO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgc2V0TGFiZWwobGFiZWwpIHtcbiAgICB0aGlzLmxhYmVsID0gbGFiZWw7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxuICBnZXRQcm9wcygpIHtcbiAgICBjb25zdCBwcm9wcyA9IHN1cGVyLmdldFByb3BzKCk7XG4gICAgY29uc3QgeyBsYWJlbCwgaWNvbiwgc2hha2UgfSA9IHRoaXM7XG4gICAgcHJvcHMubGFiZWwgPSBsYWJlbDtcbiAgICBwcm9wcy5pY29uID0gaWNvbjtcbiAgICBwcm9wcy5zaGFrZSA9IHNoYWtlO1xuICAgIHJldHVybiBwcm9wcztcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvZmlsdGVyQ29tcG9uZW50V3JhcHBlci50c1xuaW1wb3J0IHsgQWdQcm9taXNlIGFzIEFnUHJvbWlzZTMgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbnZhciBGaWx0ZXJDb21wb25lbnRXcmFwcGVyID0gY2xhc3MgZXh0ZW5kcyBDdXN0b21Db21wb25lbnRXcmFwcGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm1vZGVsID0gbnVsbDtcbiAgICB0aGlzLm9uTW9kZWxDaGFuZ2UgPSAobW9kZWwpID0+IHRoaXMudXBkYXRlTW9kZWwobW9kZWwpO1xuICAgIHRoaXMub25VaUNoYW5nZSA9ICgpID0+IHRoaXMuc291cmNlUGFyYW1zLmZpbHRlck1vZGlmaWVkQ2FsbGJhY2soKTtcbiAgICB0aGlzLmV4cGVjdGluZ05ld01ldGhvZHMgPSB0cnVlO1xuICAgIHRoaXMuaGFzQmVlbkFjdGl2ZSA9IGZhbHNlO1xuICAgIHRoaXMuYXdhaXRTZXRNZXRob2RzQ2FsbGJhY2sgPSBuZXcgQWdQcm9taXNlMygocmVzb2x2ZSkgPT4ge1xuICAgICAgdGhpcy5yZXNvbHZlU2V0TWV0aG9kc0NhbGxiYWNrID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgfVxuICBpc0ZpbHRlckFjdGl2ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5tb2RlbCAhPSBudWxsO1xuICB9XG4gIGRvZXNGaWx0ZXJQYXNzKHBhcmFtcykge1xuICAgIHJldHVybiB0aGlzLnByb3ZpZGVkTWV0aG9kcy5kb2VzRmlsdGVyUGFzcyhwYXJhbXMpO1xuICB9XG4gIGdldE1vZGVsKCkge1xuICAgIHJldHVybiB0aGlzLm1vZGVsO1xuICB9XG4gIHNldE1vZGVsKG1vZGVsKSB7XG4gICAgdGhpcy5leHBlY3RpbmdOZXdNZXRob2RzID0gdHJ1ZTtcbiAgICB0aGlzLm1vZGVsID0gbW9kZWw7XG4gICAgdGhpcy5oYXNCZWVuQWN0aXZlIHx8ICh0aGlzLmhhc0JlZW5BY3RpdmUgPSB0aGlzLmlzRmlsdGVyQWN0aXZlKCkpO1xuICAgIHJldHVybiB0aGlzLnJlZnJlc2hQcm9wcygpO1xuICB9XG4gIHJlZnJlc2gobmV3UGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBuZXdQYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhZnRlckd1aUF0dGFjaGVkKHBhcmFtcykge1xuICAgIGNvbnN0IHByb3ZpZGVkTWV0aG9kcyA9IHRoaXMucHJvdmlkZWRNZXRob2RzO1xuICAgIGlmICghcHJvdmlkZWRNZXRob2RzKSB7XG4gICAgICB0aGlzLmF3YWl0U2V0TWV0aG9kc0NhbGxiYWNrLnRoZW4oKCkgPT4gdGhpcy5wcm92aWRlZE1ldGhvZHM/LmFmdGVyR3VpQXR0YWNoZWQ/LihwYXJhbXMpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJvdmlkZWRNZXRob2RzLmFmdGVyR3VpQXR0YWNoZWQ/LihwYXJhbXMpO1xuICAgIH1cbiAgfVxuICBnZXRPcHRpb25hbE1ldGhvZHMoKSB7XG4gICAgcmV0dXJuIFtcImFmdGVyR3VpRGV0YWNoZWRcIiwgXCJvbk5ld1Jvd3NMb2FkZWRcIiwgXCJnZXRNb2RlbEFzU3RyaW5nXCIsIFwib25BbnlGaWx0ZXJDaGFuZ2VkXCJdO1xuICB9XG4gIHNldE1ldGhvZHMobWV0aG9kcykge1xuICAgIGlmICh0aGlzLmV4cGVjdGluZ05ld01ldGhvZHMgPT09IGZhbHNlICYmIHRoaXMuaGFzQmVlbkFjdGl2ZSAmJiB0aGlzLnByb3ZpZGVkTWV0aG9kcz8uZG9lc0ZpbHRlclBhc3MgIT09IG1ldGhvZHM/LmRvZXNGaWx0ZXJQYXNzKSB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5zb3VyY2VQYXJhbXMuZmlsdGVyQ2hhbmdlZENhbGxiYWNrKCk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy5leHBlY3RpbmdOZXdNZXRob2RzID0gZmFsc2U7XG4gICAgc3VwZXIuc2V0TWV0aG9kcyhtZXRob2RzKTtcbiAgICB0aGlzLnJlc29sdmVTZXRNZXRob2RzQ2FsbGJhY2soKTtcbiAgICB0aGlzLnJlc29sdmVGaWx0ZXJQYXNzQ2FsbGJhY2s/LigpO1xuICAgIHRoaXMucmVzb2x2ZUZpbHRlclBhc3NDYWxsYmFjayA9IHZvaWQgMDtcbiAgfVxuICB1cGRhdGVNb2RlbChtb2RlbCkge1xuICAgIHRoaXMucmVzb2x2ZUZpbHRlclBhc3NDYWxsYmFjaz8uKCk7XG4gICAgY29uc3QgYXdhaXRGaWx0ZXJQYXNzQ2FsbGJhY2sgPSBuZXcgQWdQcm9taXNlMygocmVzb2x2ZSkgPT4ge1xuICAgICAgdGhpcy5yZXNvbHZlRmlsdGVyUGFzc0NhbGxiYWNrID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgICB0aGlzLnNldE1vZGVsKG1vZGVsKS50aGVuKCgpID0+IHtcbiAgICAgIGF3YWl0RmlsdGVyUGFzc0NhbGxiYWNrLnRoZW4oKCkgPT4ge1xuICAgICAgICB0aGlzLnNvdXJjZVBhcmFtcy5maWx0ZXJDaGFuZ2VkQ2FsbGJhY2soKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGdldFByb3BzKCkge1xuICAgIGNvbnN0IHByb3BzID0gc3VwZXIuZ2V0UHJvcHMoKTtcbiAgICBwcm9wcy5tb2RlbCA9IHRoaXMubW9kZWw7XG4gICAgcHJvcHMub25Nb2RlbENoYW5nZSA9IHRoaXMub25Nb2RlbENoYW5nZTtcbiAgICBwcm9wcy5vblVpQ2hhbmdlID0gdGhpcy5vblVpQ2hhbmdlO1xuICAgIGRlbGV0ZSBwcm9wcy5maWx0ZXJDaGFuZ2VkQ2FsbGJhY2s7XG4gICAgcmV0dXJuIHByb3BzO1xuICB9XG59O1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC9maWx0ZXJEaXNwbGF5Q29tcG9uZW50V3JhcHBlci50c1xuaW1wb3J0IHsgQWdQcm9taXNlIGFzIEFnUHJvbWlzZTQgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbnZhciBGaWx0ZXJEaXNwbGF5Q29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQ3VzdG9tQ29tcG9uZW50V3JhcHBlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgdGhpcy5hd2FpdFNldE1ldGhvZHNDYWxsYmFjayA9IG5ldyBBZ1Byb21pc2U0KChyZXNvbHZlKSA9PiB7XG4gICAgICB0aGlzLnJlc29sdmVTZXRNZXRob2RzQ2FsbGJhY2sgPSByZXNvbHZlO1xuICAgIH0pO1xuICB9XG4gIHJlZnJlc2gobmV3UGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBuZXdQYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBhZnRlckd1aUF0dGFjaGVkKHBhcmFtcykge1xuICAgIGNvbnN0IHByb3ZpZGVkTWV0aG9kcyA9IHRoaXMucHJvdmlkZWRNZXRob2RzO1xuICAgIGlmICghcHJvdmlkZWRNZXRob2RzKSB7XG4gICAgICB0aGlzLmF3YWl0U2V0TWV0aG9kc0NhbGxiYWNrLnRoZW4oKCkgPT4gdGhpcy5wcm92aWRlZE1ldGhvZHM/LmFmdGVyR3VpQXR0YWNoZWQ/LihwYXJhbXMpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJvdmlkZWRNZXRob2RzLmFmdGVyR3VpQXR0YWNoZWQ/LihwYXJhbXMpO1xuICAgIH1cbiAgfVxuICBnZXRPcHRpb25hbE1ldGhvZHMoKSB7XG4gICAgcmV0dXJuIFtcImFmdGVyR3VpRGV0YWNoZWRcIiwgXCJvbk5ld1Jvd3NMb2FkZWRcIiwgXCJvbkFueUZpbHRlckNoYW5nZWRcIl07XG4gIH1cbiAgc2V0TWV0aG9kcyhtZXRob2RzKSB7XG4gICAgc3VwZXIuc2V0TWV0aG9kcyhtZXRob2RzKTtcbiAgICB0aGlzLnJlc29sdmVTZXRNZXRob2RzQ2FsbGJhY2soKTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvZmxvYXRpbmdGaWx0ZXJDb21wb25lbnRQcm94eS50c1xuaW1wb3J0IHsgQWdQcm9taXNlIGFzIEFnUHJvbWlzZTUgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbmZ1bmN0aW9uIHVwZGF0ZUZsb2F0aW5nRmlsdGVyUGFyZW50KHBhcmFtcywgbW9kZWwpIHtcbiAgcGFyYW1zLnBhcmVudEZpbHRlckluc3RhbmNlKChpbnN0YW5jZSkgPT4ge1xuICAgIChpbnN0YW5jZS5zZXRNb2RlbChtb2RlbCkgfHwgQWdQcm9taXNlNS5yZXNvbHZlKCkpLnRoZW4oKCkgPT4ge1xuICAgICAgcGFyYW1zLmZpbHRlclBhcmFtcy5maWx0ZXJDaGFuZ2VkQ2FsbGJhY2soKTtcbiAgICB9KTtcbiAgfSk7XG59XG52YXIgRmxvYXRpbmdGaWx0ZXJDb21wb25lbnRQcm94eSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoZmxvYXRpbmdGaWx0ZXJQYXJhbXMsIHJlZnJlc2hQcm9wcykge1xuICAgIHRoaXMuZmxvYXRpbmdGaWx0ZXJQYXJhbXMgPSBmbG9hdGluZ0ZpbHRlclBhcmFtcztcbiAgICB0aGlzLnJlZnJlc2hQcm9wcyA9IHJlZnJlc2hQcm9wcztcbiAgICB0aGlzLm1vZGVsID0gbnVsbDtcbiAgICB0aGlzLm9uTW9kZWxDaGFuZ2UgPSAobW9kZWwpID0+IHRoaXMudXBkYXRlTW9kZWwobW9kZWwpO1xuICB9XG4gIGdldFByb3BzKCkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi50aGlzLmZsb2F0aW5nRmlsdGVyUGFyYW1zLFxuICAgICAgbW9kZWw6IHRoaXMubW9kZWwsXG4gICAgICBvbk1vZGVsQ2hhbmdlOiB0aGlzLm9uTW9kZWxDaGFuZ2VcbiAgICB9O1xuICB9XG4gIG9uUGFyZW50TW9kZWxDaGFuZ2VkKHBhcmVudE1vZGVsKSB7XG4gICAgdGhpcy5tb2RlbCA9IHBhcmVudE1vZGVsO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgcmVmcmVzaChwYXJhbXMpIHtcbiAgICB0aGlzLmZsb2F0aW5nRmlsdGVyUGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgc2V0TWV0aG9kcyhtZXRob2RzKSB7XG4gICAgYWRkT3B0aW9uYWxNZXRob2RzKHRoaXMuZ2V0T3B0aW9uYWxNZXRob2RzKCksIG1ldGhvZHMsIHRoaXMpO1xuICB9XG4gIGdldE9wdGlvbmFsTWV0aG9kcygpIHtcbiAgICByZXR1cm4gW1wiYWZ0ZXJHdWlBdHRhY2hlZFwiXTtcbiAgfVxuICB1cGRhdGVNb2RlbChtb2RlbCkge1xuICAgIHRoaXMubW9kZWwgPSBtb2RlbDtcbiAgICB0aGlzLnJlZnJlc2hQcm9wcygpO1xuICAgIHVwZGF0ZUZsb2F0aW5nRmlsdGVyUGFyZW50KHRoaXMuZmxvYXRpbmdGaWx0ZXJQYXJhbXMsIG1vZGVsKTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvZmxvYXRpbmdGaWx0ZXJDb21wb25lbnRXcmFwcGVyLnRzXG52YXIgRmxvYXRpbmdGaWx0ZXJDb21wb25lbnRXcmFwcGVyID0gY2xhc3MgZXh0ZW5kcyBDdXN0b21Db21wb25lbnRXcmFwcGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLm1vZGVsID0gbnVsbDtcbiAgICB0aGlzLm9uTW9kZWxDaGFuZ2UgPSAobW9kZWwpID0+IHRoaXMudXBkYXRlTW9kZWwobW9kZWwpO1xuICB9XG4gIG9uUGFyZW50TW9kZWxDaGFuZ2VkKHBhcmVudE1vZGVsKSB7XG4gICAgdGhpcy5tb2RlbCA9IHBhcmVudE1vZGVsO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgcmVmcmVzaChuZXdQYXJhbXMpIHtcbiAgICB0aGlzLnNvdXJjZVBhcmFtcyA9IG5ld1BhcmFtcztcbiAgICB0aGlzLnJlZnJlc2hQcm9wcygpO1xuICB9XG4gIGdldE9wdGlvbmFsTWV0aG9kcygpIHtcbiAgICByZXR1cm4gW1wiYWZ0ZXJHdWlBdHRhY2hlZFwiXTtcbiAgfVxuICB1cGRhdGVNb2RlbChtb2RlbCkge1xuICAgIHRoaXMubW9kZWwgPSBtb2RlbDtcbiAgICB0aGlzLnJlZnJlc2hQcm9wcygpO1xuICAgIHVwZGF0ZUZsb2F0aW5nRmlsdGVyUGFyZW50KHRoaXMuc291cmNlUGFyYW1zLCBtb2RlbCk7XG4gIH1cbiAgZ2V0UHJvcHMoKSB7XG4gICAgY29uc3QgcHJvcHMgPSBzdXBlci5nZXRQcm9wcygpO1xuICAgIHByb3BzLm1vZGVsID0gdGhpcy5tb2RlbDtcbiAgICBwcm9wcy5vbk1vZGVsQ2hhbmdlID0gdGhpcy5vbk1vZGVsQ2hhbmdlO1xuICAgIHJldHVybiBwcm9wcztcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvZmxvYXRpbmdGaWx0ZXJEaXNwbGF5Q29tcG9uZW50V3JhcHBlci50c1xudmFyIEZsb2F0aW5nRmlsdGVyRGlzcGxheUNvbXBvbmVudFdyYXBwZXIgPSBjbGFzcyBleHRlbmRzIEN1c3RvbUNvbXBvbmVudFdyYXBwZXIge1xuICByZWZyZXNoKG5ld1BhcmFtcykge1xuICAgIHRoaXMuc291cmNlUGFyYW1zID0gbmV3UGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgZ2V0T3B0aW9uYWxNZXRob2RzKCkge1xuICAgIHJldHVybiBbXCJhZnRlckd1aUF0dGFjaGVkXCJdO1xuICB9XG59O1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC9pbm5lckhlYWRlckNvbXBvbmVudFdyYXBwZXIudHNcbnZhciBJbm5lckhlYWRlckNvbXBvbmVudFdyYXBwZXIgPSBjbGFzcyBleHRlbmRzIEN1c3RvbUNvbXBvbmVudFdyYXBwZXIge1xuICByZWZyZXNoKHBhcmFtcykge1xuICAgIHRoaXMuc291cmNlUGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL2xvYWRpbmdPdmVybGF5Q29tcG9uZW50V3JhcHBlci50c1xudmFyIExvYWRpbmdPdmVybGF5Q29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQ3VzdG9tQ29tcG9uZW50V3JhcHBlciB7XG4gIHJlZnJlc2gocGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBwYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvbWVudUl0ZW1Db21wb25lbnRXcmFwcGVyLnRzXG52YXIgTWVudUl0ZW1Db21wb25lbnRXcmFwcGVyID0gY2xhc3MgZXh0ZW5kcyBDdXN0b21Db21wb25lbnRXcmFwcGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLmFjdGl2ZSA9IGZhbHNlO1xuICAgIHRoaXMuZXhwYW5kZWQgPSBmYWxzZTtcbiAgICB0aGlzLm9uQWN0aXZlQ2hhbmdlID0gKGFjdGl2ZSkgPT4gdGhpcy51cGRhdGVBY3RpdmUoYWN0aXZlKTtcbiAgfVxuICBzZXRBY3RpdmUoYWN0aXZlKSB7XG4gICAgdGhpcy5hd2FpdFNldEFjdGl2ZShhY3RpdmUpO1xuICB9XG4gIHNldEV4cGFuZGVkKGV4cGFuZGVkKSB7XG4gICAgdGhpcy5leHBhbmRlZCA9IGV4cGFuZGVkO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgZ2V0T3B0aW9uYWxNZXRob2RzKCkge1xuICAgIHJldHVybiBbXCJzZWxlY3RcIiwgXCJjb25maWd1cmVEZWZhdWx0c1wiXTtcbiAgfVxuICBhd2FpdFNldEFjdGl2ZShhY3RpdmUpIHtcbiAgICB0aGlzLmFjdGl2ZSA9IGFjdGl2ZTtcbiAgICByZXR1cm4gdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxuICB1cGRhdGVBY3RpdmUoYWN0aXZlKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy5hd2FpdFNldEFjdGl2ZShhY3RpdmUpO1xuICAgIGlmIChhY3RpdmUpIHtcbiAgICAgIHJlc3VsdC50aGVuKCgpID0+IHRoaXMuc291cmNlUGFyYW1zLm9uSXRlbUFjdGl2YXRlZCgpKTtcbiAgICB9XG4gIH1cbiAgZ2V0UHJvcHMoKSB7XG4gICAgY29uc3QgcHJvcHMgPSBzdXBlci5nZXRQcm9wcygpO1xuICAgIHByb3BzLmFjdGl2ZSA9IHRoaXMuYWN0aXZlO1xuICAgIHByb3BzLmV4cGFuZGVkID0gdGhpcy5leHBhbmRlZDtcbiAgICBwcm9wcy5vbkFjdGl2ZUNoYW5nZSA9IHRoaXMub25BY3RpdmVDaGFuZ2U7XG4gICAgZGVsZXRlIHByb3BzLm9uSXRlbUFjdGl2YXRlZDtcbiAgICByZXR1cm4gcHJvcHM7XG4gIH1cbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL25vUm93c092ZXJsYXlDb21wb25lbnRXcmFwcGVyLnRzXG52YXIgTm9Sb3dzT3ZlcmxheUNvbXBvbmVudFdyYXBwZXIgPSBjbGFzcyBleHRlbmRzIEN1c3RvbUNvbXBvbmVudFdyYXBwZXIge1xuICByZWZyZXNoKHBhcmFtcykge1xuICAgIHRoaXMuc291cmNlUGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL3N0YXR1c1BhbmVsQ29tcG9uZW50V3JhcHBlci50c1xudmFyIFN0YXR1c1BhbmVsQ29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQ3VzdG9tQ29tcG9uZW50V3JhcHBlciB7XG4gIHJlZnJlc2gocGFyYW1zKSB7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMgPSBwYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvdG9vbFBhbmVsQ29tcG9uZW50V3JhcHBlci50c1xudmFyIFRvb2xQYW5lbENvbXBvbmVudFdyYXBwZXIgPSBjbGFzcyBleHRlbmRzIEN1c3RvbUNvbXBvbmVudFdyYXBwZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIHRoaXMub25TdGF0ZUNoYW5nZSA9IChzdGF0ZSkgPT4gdGhpcy51cGRhdGVTdGF0ZShzdGF0ZSk7XG4gIH1cbiAgcmVmcmVzaChwYXJhbXMpIHtcbiAgICB0aGlzLnNvdXJjZVBhcmFtcyA9IHBhcmFtcztcbiAgICB0aGlzLnJlZnJlc2hQcm9wcygpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGdldFN0YXRlKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXRlO1xuICB9XG4gIHVwZGF0ZVN0YXRlKHN0YXRlKSB7XG4gICAgdGhpcy5zdGF0ZSA9IHN0YXRlO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gICAgdGhpcy5zb3VyY2VQYXJhbXMub25TdGF0ZVVwZGF0ZWQoKTtcbiAgfVxuICBnZXRQcm9wcygpIHtcbiAgICBjb25zdCBwcm9wcyA9IHN1cGVyLmdldFByb3BzKCk7XG4gICAgcHJvcHMuc3RhdGUgPSB0aGlzLnN0YXRlO1xuICAgIHByb3BzLm9uU3RhdGVDaGFuZ2UgPSB0aGlzLm9uU3RhdGVDaGFuZ2U7XG4gICAgcmV0dXJuIHByb3BzO1xuICB9XG59O1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC91dGlsLnRzXG5pbXBvcnQgeyBBZ1Byb21pc2UgYXMgQWdQcm9taXNlNiwgX3dhcm4gfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbmZ1bmN0aW9uIGdldEluc3RhbmNlKHdyYXBwZXJDb21wb25lbnQsIGNhbGxiYWNrKSB7XG4gIGNvbnN0IHByb21pc2UgPSB3cmFwcGVyQ29tcG9uZW50Py5nZXRJbnN0YW5jZT8uKCkgPz8gQWdQcm9taXNlNi5yZXNvbHZlKHZvaWQgMCk7XG4gIHByb21pc2UudGhlbigoY29tcCkgPT4gY2FsbGJhY2soY29tcCkpO1xufVxuZnVuY3Rpb24gd2FyblJlYWN0aXZlQ3VzdG9tQ29tcG9uZW50cygpIHtcbiAgX3dhcm4oMjMxKTtcbn1cblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL3BvcnRhbE1hbmFnZXIudHNcbnZhciBNQVhfQ09NUE9ORU5UX0NSRUFUSU9OX1RJTUVfSU5fTVMgPSAxZTM7XG52YXIgUG9ydGFsTWFuYWdlciA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IocmVmcmVzaGVyLCB3cmFwcGluZ0VsZW1lbnQsIG1heENvbXBvbmVudENyZWF0aW9uVGltZU1zKSB7XG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLnBvcnRhbHMgPSBbXTtcbiAgICB0aGlzLmhhc1BlbmRpbmdQb3J0YWxVcGRhdGUgPSBmYWxzZTtcbiAgICB0aGlzLndyYXBwaW5nRWxlbWVudCA9IHdyYXBwaW5nRWxlbWVudCA/IHdyYXBwaW5nRWxlbWVudCA6IFwiZGl2XCI7XG4gICAgdGhpcy5yZWZyZXNoZXIgPSByZWZyZXNoZXI7XG4gICAgdGhpcy5tYXhDb21wb25lbnRDcmVhdGlvblRpbWVNcyA9IG1heENvbXBvbmVudENyZWF0aW9uVGltZU1zID8gbWF4Q29tcG9uZW50Q3JlYXRpb25UaW1lTXMgOiBNQVhfQ09NUE9ORU5UX0NSRUFUSU9OX1RJTUVfSU5fTVM7XG4gIH1cbiAgZ2V0UG9ydGFscygpIHtcbiAgICByZXR1cm4gdGhpcy5wb3J0YWxzO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5kZXN0cm95ZWQgPSB0cnVlO1xuICB9XG4gIGRlc3Ryb3lQb3J0YWwocG9ydGFsKSB7XG4gICAgdGhpcy5wb3J0YWxzID0gdGhpcy5wb3J0YWxzLmZpbHRlcigoY3VyUG9ydGFsKSA9PiBjdXJQb3J0YWwgIT09IHBvcnRhbCk7XG4gICAgdGhpcy5iYXRjaFVwZGF0ZSgpO1xuICB9XG4gIGdldENvbXBvbmVudFdyYXBwaW5nRWxlbWVudCgpIHtcbiAgICByZXR1cm4gdGhpcy53cmFwcGluZ0VsZW1lbnQ7XG4gIH1cbiAgbW91bnRSZWFjdFBvcnRhbChwb3J0YWwsIHJlYWN0Q29tcG9uZW50LCByZXNvbHZlKSB7XG4gICAgdGhpcy5wb3J0YWxzID0gWy4uLnRoaXMucG9ydGFscywgcG9ydGFsXTtcbiAgICB0aGlzLndhaXRGb3JJbnN0YW5jZShyZWFjdENvbXBvbmVudCwgcmVzb2x2ZSk7XG4gICAgdGhpcy5iYXRjaFVwZGF0ZSgpO1xuICB9XG4gIHVwZGF0ZVJlYWN0UG9ydGFsKG9sZFBvcnRhbCwgbmV3UG9ydGFsKSB7XG4gICAgdGhpcy5wb3J0YWxzW3RoaXMucG9ydGFscy5pbmRleE9mKG9sZFBvcnRhbCldID0gbmV3UG9ydGFsO1xuICAgIHRoaXMuYmF0Y2hVcGRhdGUoKTtcbiAgfVxuICBiYXRjaFVwZGF0ZSgpIHtcbiAgICBpZiAodGhpcy5oYXNQZW5kaW5nUG9ydGFsVXBkYXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLmRlc3Ryb3llZCkge1xuICAgICAgICB0aGlzLnJlZnJlc2hlcigpO1xuICAgICAgICB0aGlzLmhhc1BlbmRpbmdQb3J0YWxVcGRhdGUgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLmhhc1BlbmRpbmdQb3J0YWxVcGRhdGUgPSB0cnVlO1xuICB9XG4gIHdhaXRGb3JJbnN0YW5jZShyZWFjdENvbXBvbmVudCwgcmVzb2x2ZSwgc3RhcnRUaW1lID0gRGF0ZS5ub3coKSkge1xuICAgIGlmICh0aGlzLmRlc3Ryb3llZCkge1xuICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHJlYWN0Q29tcG9uZW50LnJlbmRlcmVkKCkpIHtcbiAgICAgIHJlc29sdmUocmVhY3RDb21wb25lbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoRGF0ZS5ub3coKSAtIHN0YXJ0VGltZSA+PSB0aGlzLm1heENvbXBvbmVudENyZWF0aW9uVGltZU1zICYmICF0aGlzLmhhc1BlbmRpbmdQb3J0YWxVcGRhdGUpIHtcbiAgICAgICAgYWdGbHVzaFN5bmModHJ1ZSwgKCkgPT4gdGhpcy5yZWZyZXNoZXIoKSk7XG4gICAgICAgIGlmIChyZWFjdENvbXBvbmVudC5yZW5kZXJlZCgpKSB7XG4gICAgICAgICAgcmVzb2x2ZShyZWFjdENvbXBvbmVudCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLndhaXRGb3JJbnN0YW5jZShyZWFjdENvbXBvbmVudCwgcmVzb2x2ZSwgc3RhcnRUaW1lKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9ncmlkQ29tcC50c3hcbmltcG9ydCBSZWFjdDE4LCB7IG1lbW8gYXMgbWVtbzE0LCB1c2VDYWxsYmFjayBhcyB1c2VDYWxsYmFjazE0LCB1c2VFZmZlY3QgYXMgdXNlRWZmZWN0OSwgdXNlTWVtbyBhcyB1c2VNZW1vMTIsIHVzZVJlZiBhcyB1c2VSZWYxNSwgdXNlU3RhdGUgYXMgdXNlU3RhdGUxNSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgR3JpZEN0cmwgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9ncmlkQm9keUNvbXAudHN4XG5pbXBvcnQgUmVhY3QxNiwgeyBtZW1vIGFzIG1lbW8xMiwgdXNlQ2FsbGJhY2sgYXMgdXNlQ2FsbGJhY2sxMiwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MTMsIHVzZU1lbW8gYXMgdXNlTWVtbzExLCB1c2VSZWYgYXMgdXNlUmVmMTMsIHVzZVN0YXRlIGFzIHVzZVN0YXRlMTQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIENzc0NsYXNzTWFuYWdlciBhcyBDc3NDbGFzc01hbmFnZXI0LFxuICBGYWtlSFNjcm9sbENvbXAsXG4gIEZha2VWU2Nyb2xsQ29tcCxcbiAgR3JpZEJvZHlDdHJsLFxuICBfb2JzZXJ2ZVJlc2l6ZSxcbiAgX3NldEFyaWFDb2xDb3VudCxcbiAgX3NldEFyaWFSb3dDb3VudFxufSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9oZWFkZXIvZ3JpZEhlYWRlckNvbXAudHN4XG5pbXBvcnQgUmVhY3QxMCwgeyBtZW1vIGFzIG1lbW83LCB1c2VDYWxsYmFjayBhcyB1c2VDYWxsYmFjazcsIHVzZUNvbnRleHQgYXMgdXNlQ29udGV4dDcsIHVzZU1lbW8gYXMgdXNlTWVtbzYsIHVzZVJlZiBhcyB1c2VSZWY3LCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTggfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEdyaWRIZWFkZXJDdHJsIH0gZnJvbSBcImFnLWdyaWQtY29tbXVuaXR5XCI7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvaGVhZGVyL2hlYWRlclJvd0NvbnRhaW5lckNvbXAudHN4XG5pbXBvcnQgUmVhY3Q5LCB7IG1lbW8gYXMgbWVtbzYsIHVzZUNhbGxiYWNrIGFzIHVzZUNhbGxiYWNrNiwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0NiwgdXNlUmVmIGFzIHVzZVJlZjYsIHVzZVN0YXRlIGFzIHVzZVN0YXRlNyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSGVhZGVyUm93Q29udGFpbmVyQ3RybCB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2hlYWRlci9oZWFkZXJSb3dDb21wLnRzeFxuaW1wb3J0IFJlYWN0OCwgeyBtZW1vIGFzIG1lbW81LCB1c2VDYWxsYmFjayBhcyB1c2VDYWxsYmFjazUsIHVzZUNvbnRleHQgYXMgdXNlQ29udGV4dDUsIHVzZU1lbW8gYXMgdXNlTWVtbzUsIHVzZVJlZiBhcyB1c2VSZWY1LCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTYgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IF9FbXB0eUJlYW4gYXMgX0VtcHR5QmVhbjQgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9oZWFkZXIvaGVhZGVyQ2VsbENvbXAudHN4XG5pbXBvcnQgUmVhY3Q1LCB7IG1lbW8gYXMgbWVtbzIsIHVzZUNhbGxiYWNrIGFzIHVzZUNhbGxiYWNrMiwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MiwgdXNlRWZmZWN0IGFzIHVzZUVmZmVjdDIsIHVzZUxheW91dEVmZmVjdCBhcyB1c2VMYXlvdXRFZmZlY3QyLCB1c2VNZW1vIGFzIHVzZU1lbW8yLCB1c2VSZWYgYXMgdXNlUmVmMiwgdXNlU3RhdGUgYXMgdXNlU3RhdGUzIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDc3NDbGFzc01hbmFnZXIsIF9FbXB0eUJlYW4sIF9yZW1vdmVBcmlhU29ydCwgX3NldEFyaWFTb3J0IH0gZnJvbSBcImFnLWdyaWQtY29tbXVuaXR5XCI7XG52YXIgSGVhZGVyQ2VsbENvbXAgPSAoeyBjdHJsIH0pID0+IHtcbiAgY29uc3QgaXNBbGl2ZSA9IGN0cmwuaXNBbGl2ZSgpO1xuICBjb25zdCB7IGNvbnRleHQgfSA9IHVzZUNvbnRleHQyKEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IFt1c2VyQ29tcERldGFpbHMsIHNldFVzZXJDb21wRGV0YWlsc10gPSB1c2VTdGF0ZTMoKTtcbiAgY29uc3QgW3VzZXJTdHlsZXMsIHNldFVzZXJTdHlsZXNdID0gdXNlU3RhdGUzKCk7XG4gIGNvbnN0IGNvbXBCZWFuID0gdXNlUmVmMigpO1xuICBjb25zdCBlR3VpID0gdXNlUmVmMihudWxsKTtcbiAgY29uc3QgZVJlc2l6ZSA9IHVzZVJlZjIobnVsbCk7XG4gIGNvbnN0IGVIZWFkZXJDb21wV3JhcHBlciA9IHVzZVJlZjIobnVsbCk7XG4gIGNvbnN0IHVzZXJDb21wUmVmID0gdXNlUmVmMigpO1xuICBjb25zdCBjc3NNYW5hZ2VyID0gdXNlUmVmMigpO1xuICBpZiAoaXNBbGl2ZSAmJiAhY3NzTWFuYWdlci5jdXJyZW50KSB7XG4gICAgY3NzTWFuYWdlci5jdXJyZW50ID0gbmV3IENzc0NsYXNzTWFuYWdlcigoKSA9PiBlR3VpLmN1cnJlbnQpO1xuICB9XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazIoKGVSZWYpID0+IHtcbiAgICBlR3VpLmN1cnJlbnQgPSBlUmVmO1xuICAgIGlmICghZVJlZiB8fCAhY3RybC5pc0FsaXZlKCkgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICBjb21wQmVhbi5jdXJyZW50ID0gY29udGV4dC5kZXN0cm95QmVhbihjb21wQmVhbi5jdXJyZW50KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29tcEJlYW4uY3VycmVudCA9IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgX0VtcHR5QmVhbigpKTtcbiAgICBjb25zdCByZWZyZXNoU2VsZWN0QWxsR3VpID0gKCkgPT4ge1xuICAgICAgY29uc3Qgc2VsZWN0QWxsR3VpID0gY3RybC5nZXRTZWxlY3RBbGxHdWkoKTtcbiAgICAgIGlmIChzZWxlY3RBbGxHdWkpIHtcbiAgICAgICAgZVJlc2l6ZS5jdXJyZW50Py5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJhZnRlcmVuZFwiLCBzZWxlY3RBbGxHdWkpO1xuICAgICAgICBjb21wQmVhbi5jdXJyZW50LmFkZERlc3Ryb3lGdW5jKCgpID0+IHNlbGVjdEFsbEd1aS5yZW1vdmUoKSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBjb21wUHJveHkgPSB7XG4gICAgICBzZXRXaWR0aDogKHdpZHRoKSA9PiB7XG4gICAgICAgIGlmIChlR3VpLmN1cnJlbnQpIHtcbiAgICAgICAgICBlR3VpLmN1cnJlbnQuc3R5bGUud2lkdGggPSB3aWR0aDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBjc3NNYW5hZ2VyLmN1cnJlbnQudG9nZ2xlQ3NzKG5hbWUsIG9uKSxcbiAgICAgIHNldFVzZXJTdHlsZXM6IChzdHlsZXMpID0+IHNldFVzZXJTdHlsZXMoc3R5bGVzKSxcbiAgICAgIHNldEFyaWFTb3J0OiAoc29ydCkgPT4ge1xuICAgICAgICBpZiAoZUd1aS5jdXJyZW50KSB7XG4gICAgICAgICAgc29ydCA/IF9zZXRBcmlhU29ydChlR3VpLmN1cnJlbnQsIHNvcnQpIDogX3JlbW92ZUFyaWFTb3J0KGVHdWkuY3VycmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzZXRVc2VyQ29tcERldGFpbHM6IChjb21wRGV0YWlscykgPT4gc2V0VXNlckNvbXBEZXRhaWxzKGNvbXBEZXRhaWxzKSxcbiAgICAgIGdldFVzZXJDb21wSW5zdGFuY2U6ICgpID0+IHVzZXJDb21wUmVmLmN1cnJlbnQgfHwgdm9pZCAwLFxuICAgICAgcmVmcmVzaFNlbGVjdEFsbEd1aSxcbiAgICAgIHJlbW92ZVNlbGVjdEFsbEd1aTogKCkgPT4gY3RybC5nZXRTZWxlY3RBbGxHdWkoKT8ucmVtb3ZlKClcbiAgICB9O1xuICAgIGN0cmwuc2V0Q29tcChjb21wUHJveHksIGVSZWYsIGVSZXNpemUuY3VycmVudCwgZUhlYWRlckNvbXBXcmFwcGVyLmN1cnJlbnQsIGNvbXBCZWFuLmN1cnJlbnQpO1xuICAgIHJlZnJlc2hTZWxlY3RBbGxHdWkoKTtcbiAgfSwgW10pO1xuICB1c2VMYXlvdXRFZmZlY3QyKFxuICAgICgpID0+IHNob3dKc0NvbXAodXNlckNvbXBEZXRhaWxzLCBjb250ZXh0LCBlSGVhZGVyQ29tcFdyYXBwZXIuY3VycmVudCwgdXNlckNvbXBSZWYpLFxuICAgIFt1c2VyQ29tcERldGFpbHNdXG4gICk7XG4gIHVzZUVmZmVjdDIoKCkgPT4ge1xuICAgIGN0cmwuc2V0RHJhZ1NvdXJjZShlR3VpLmN1cnJlbnQpO1xuICB9LCBbdXNlckNvbXBEZXRhaWxzXSk7XG4gIGNvbnN0IHVzZXJDb21wU3RhdGVsZXNzID0gdXNlTWVtbzIoKCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IHVzZXJDb21wRGV0YWlscz8uY29tcG9uZW50RnJvbUZyYW1ld29yayAmJiBpc0NvbXBvbmVudFN0YXRlbGVzcyh1c2VyQ29tcERldGFpbHMuY29tcG9uZW50Q2xhc3MpO1xuICAgIHJldHVybiAhIXJlcztcbiAgfSwgW3VzZXJDb21wRGV0YWlsc10pO1xuICBjb25zdCByZWFjdFVzZXJDb21wID0gdXNlckNvbXBEZXRhaWxzPy5jb21wb25lbnRGcm9tRnJhbWV3b3JrO1xuICBjb25zdCBVc2VyQ29tcENsYXNzID0gdXNlckNvbXBEZXRhaWxzPy5jb21wb25lbnRDbGFzcztcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDUuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHJlZjogc2V0UmVmMiwgc3R5bGU6IHVzZXJTdHlsZXMsIGNsYXNzTmFtZTogXCJhZy1oZWFkZXItY2VsbFwiLCByb2xlOiBcImNvbHVtbmhlYWRlclwiIH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDUuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHJlZjogZVJlc2l6ZSwgY2xhc3NOYW1lOiBcImFnLWhlYWRlci1jZWxsLXJlc2l6ZVwiLCByb2xlOiBcInByZXNlbnRhdGlvblwiIH0pLCAvKiBAX19QVVJFX18gKi8gUmVhY3Q1LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IGVIZWFkZXJDb21wV3JhcHBlciwgY2xhc3NOYW1lOiBcImFnLWhlYWRlci1jZWxsLWNvbXAtd3JhcHBlclwiLCByb2xlOiBcInByZXNlbnRhdGlvblwiIH0sIHJlYWN0VXNlckNvbXAgPyB1c2VyQ29tcFN0YXRlbGVzcyA/IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDUuY3JlYXRlRWxlbWVudChVc2VyQ29tcENsYXNzLCB7IC4uLnVzZXJDb21wRGV0YWlscy5wYXJhbXMgfSkgOiAvKiBAX19QVVJFX18gKi8gUmVhY3Q1LmNyZWF0ZUVsZW1lbnQoVXNlckNvbXBDbGFzcywgeyAuLi51c2VyQ29tcERldGFpbHMucGFyYW1zLCByZWY6IHVzZXJDb21wUmVmIH0pIDogbnVsbCkpO1xufTtcbnZhciBoZWFkZXJDZWxsQ29tcF9kZWZhdWx0ID0gbWVtbzIoSGVhZGVyQ2VsbENvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2hlYWRlci9oZWFkZXJGaWx0ZXJDZWxsQ29tcC50c3hcbmltcG9ydCBSZWFjdDYsIHsgbWVtbyBhcyBtZW1vMywgdXNlQ2FsbGJhY2sgYXMgdXNlQ2FsbGJhY2szLCB1c2VDb250ZXh0IGFzIHVzZUNvbnRleHQzLCB1c2VFZmZlY3QgYXMgdXNlRWZmZWN0MywgdXNlTGF5b3V0RWZmZWN0IGFzIHVzZUxheW91dEVmZmVjdDMsIHVzZU1lbW8gYXMgdXNlTWVtbzMsIHVzZVJlZiBhcyB1c2VSZWYzLCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEFnUHJvbWlzZSBhcyBBZ1Byb21pc2U3LCBfRW1wdHlCZWFuIGFzIF9FbXB0eUJlYW4yIH0gZnJvbSBcImFnLWdyaWQtY29tbXVuaXR5XCI7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3NoYXJlZC9jdXN0b21Db21wL2Zsb2F0aW5nRmlsdGVyRGlzcGxheUNvbXBvbmVudFByb3h5LnRzXG52YXIgRmxvYXRpbmdGaWx0ZXJEaXNwbGF5Q29tcG9uZW50UHJveHkgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGZsb2F0aW5nRmlsdGVyUGFyYW1zLCByZWZyZXNoUHJvcHMpIHtcbiAgICB0aGlzLmZsb2F0aW5nRmlsdGVyUGFyYW1zID0gZmxvYXRpbmdGaWx0ZXJQYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMgPSByZWZyZXNoUHJvcHM7XG4gIH1cbiAgZ2V0UHJvcHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZmxvYXRpbmdGaWx0ZXJQYXJhbXM7XG4gIH1cbiAgcmVmcmVzaChwYXJhbXMpIHtcbiAgICB0aGlzLmZsb2F0aW5nRmlsdGVyUGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzKCk7XG4gIH1cbiAgc2V0TWV0aG9kcyhtZXRob2RzKSB7XG4gICAgYWRkT3B0aW9uYWxNZXRob2RzKHRoaXMuZ2V0T3B0aW9uYWxNZXRob2RzKCksIG1ldGhvZHMsIHRoaXMpO1xuICB9XG4gIGdldE9wdGlvbmFsTWV0aG9kcygpIHtcbiAgICByZXR1cm4gW1wiYWZ0ZXJHdWlBdHRhY2hlZFwiXTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9oZWFkZXIvaGVhZGVyRmlsdGVyQ2VsbENvbXAudHN4XG52YXIgSGVhZGVyRmlsdGVyQ2VsbENvbXAgPSAoeyBjdHJsIH0pID0+IHtcbiAgY29uc3QgeyBjb250ZXh0LCBnb3MgfSA9IHVzZUNvbnRleHQzKEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IFt1c2VyU3R5bGVzLCBzZXRVc2VyU3R5bGVzXSA9IHVzZVN0YXRlNCgpO1xuICBjb25zdCBbY3NzQ2xhc3Nlcywgc2V0Q3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZTQoXG4gICAgKCkgPT4gbmV3IENzc0NsYXNzZXMoXCJhZy1oZWFkZXItY2VsbFwiLCBcImFnLWZsb2F0aW5nLWZpbHRlclwiKVxuICApO1xuICBjb25zdCBbY3NzQm9keUNsYXNzZXMsIHNldEJvZHlDc3NDbGFzc2VzXSA9IHVzZVN0YXRlNCgoKSA9PiBuZXcgQ3NzQ2xhc3NlcygpKTtcbiAgY29uc3QgW2Nzc0J1dHRvbldyYXBwZXJDbGFzc2VzLCBzZXRCdXR0b25XcmFwcGVyQ3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZTQoXG4gICAgKCkgPT4gbmV3IENzc0NsYXNzZXMoXCJhZy1mbG9hdGluZy1maWx0ZXItYnV0dG9uXCIsIFwiYWctaGlkZGVuXCIpXG4gICk7XG4gIGNvbnN0IFtidXR0b25XcmFwcGVyQXJpYUhpZGRlbiwgc2V0QnV0dG9uV3JhcHBlckFyaWFIaWRkZW5dID0gdXNlU3RhdGU0KFwiZmFsc2VcIik7XG4gIGNvbnN0IFt1c2VyQ29tcERldGFpbHMsIHNldFVzZXJDb21wRGV0YWlsc10gPSB1c2VTdGF0ZTQoKTtcbiAgY29uc3QgWywgc2V0UmVuZGVyS2V5XSA9IHVzZVN0YXRlNCgxKTtcbiAgY29uc3QgY29tcEJlYW4gPSB1c2VSZWYzKCk7XG4gIGNvbnN0IGVHdWkgPSB1c2VSZWYzKG51bGwpO1xuICBjb25zdCBlRmxvYXRpbmdGaWx0ZXJCb2R5ID0gdXNlUmVmMyhudWxsKTtcbiAgY29uc3QgZUJ1dHRvbldyYXBwZXIgPSB1c2VSZWYzKG51bGwpO1xuICBjb25zdCBlQnV0dG9uU2hvd01haW5GaWx0ZXIgPSB1c2VSZWYzKG51bGwpO1xuICBjb25zdCB1c2VyQ29tcFJlc29sdmUgPSB1c2VSZWYzKCk7XG4gIGNvbnN0IHVzZXJDb21wUHJvbWlzZSA9IHVzZVJlZjMoKTtcbiAgY29uc3QgdXNlckNvbXBSZWYgPSAodmFsdWUpID0+IHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1c2VyQ29tcFJlc29sdmUuY3VycmVudCAmJiB1c2VyQ29tcFJlc29sdmUuY3VycmVudCh2YWx1ZSk7XG4gIH07XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazMoKGVSZWYpID0+IHtcbiAgICBlR3VpLmN1cnJlbnQgPSBlUmVmO1xuICAgIGlmICghZVJlZiB8fCAhY3RybC5pc0FsaXZlKCkgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICBjb21wQmVhbi5jdXJyZW50ID0gY29udGV4dC5kZXN0cm95QmVhbihjb21wQmVhbi5jdXJyZW50KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29tcEJlYW4uY3VycmVudCA9IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgX0VtcHR5QmVhbjIoKSk7XG4gICAgdXNlckNvbXBQcm9taXNlLmN1cnJlbnQgPSBuZXcgQWdQcm9taXNlNygocmVzb2x2ZSkgPT4ge1xuICAgICAgdXNlckNvbXBSZXNvbHZlLmN1cnJlbnQgPSByZXNvbHZlO1xuICAgIH0pO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBzZXRDc3NDbGFzc2VzKChwcmV2KSA9PiBwcmV2LnNldENsYXNzKG5hbWUsIG9uKSksXG4gICAgICBzZXRVc2VyU3R5bGVzOiAoc3R5bGVzKSA9PiBzZXRVc2VyU3R5bGVzKHN0eWxlcyksXG4gICAgICBhZGRPclJlbW92ZUJvZHlDc3NDbGFzczogKG5hbWUsIG9uKSA9PiBzZXRCb2R5Q3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhuYW1lLCBvbikpLFxuICAgICAgc2V0QnV0dG9uV3JhcHBlckRpc3BsYXllZDogKGRpc3BsYXllZCkgPT4ge1xuICAgICAgICBzZXRCdXR0b25XcmFwcGVyQ3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhcImFnLWhpZGRlblwiLCAhZGlzcGxheWVkKSk7XG4gICAgICAgIHNldEJ1dHRvbldyYXBwZXJBcmlhSGlkZGVuKCFkaXNwbGF5ZWQgPyBcInRydWVcIiA6IFwiZmFsc2VcIik7XG4gICAgICB9LFxuICAgICAgc2V0V2lkdGg6ICh3aWR0aCkgPT4ge1xuICAgICAgICBpZiAoZUd1aS5jdXJyZW50KSB7XG4gICAgICAgICAgZUd1aS5jdXJyZW50LnN0eWxlLndpZHRoID0gd2lkdGg7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzZXRDb21wRGV0YWlsczogKGNvbXBEZXRhaWxzKSA9PiBzZXRVc2VyQ29tcERldGFpbHMoY29tcERldGFpbHMpLFxuICAgICAgZ2V0RmxvYXRpbmdGaWx0ZXJDb21wOiAoKSA9PiB1c2VyQ29tcFByb21pc2UuY3VycmVudCA/IHVzZXJDb21wUHJvbWlzZS5jdXJyZW50IDogbnVsbCxcbiAgICAgIHNldE1lbnVJY29uOiAoZUljb24pID0+IGVCdXR0b25TaG93TWFpbkZpbHRlci5jdXJyZW50Py5hcHBlbmRDaGlsZChlSWNvbilcbiAgICB9O1xuICAgIGN0cmwuc2V0Q29tcChjb21wUHJveHksIGVSZWYsIGVCdXR0b25TaG93TWFpbkZpbHRlci5jdXJyZW50LCBlRmxvYXRpbmdGaWx0ZXJCb2R5LmN1cnJlbnQsIGNvbXBCZWFuLmN1cnJlbnQpO1xuICB9LCBbXSk7XG4gIHVzZUxheW91dEVmZmVjdDMoXG4gICAgKCkgPT4gc2hvd0pzQ29tcCh1c2VyQ29tcERldGFpbHMsIGNvbnRleHQsIGVGbG9hdGluZ0ZpbHRlckJvZHkuY3VycmVudCwgdXNlckNvbXBSZWYpLFxuICAgIFt1c2VyQ29tcERldGFpbHNdXG4gICk7XG4gIGNvbnN0IGNsYXNzTmFtZSA9IHVzZU1lbW8zKCgpID0+IGNzc0NsYXNzZXMudG9TdHJpbmcoKSwgW2Nzc0NsYXNzZXNdKTtcbiAgY29uc3QgYm9keUNsYXNzTmFtZSA9IHVzZU1lbW8zKCgpID0+IGNzc0JvZHlDbGFzc2VzLnRvU3RyaW5nKCksIFtjc3NCb2R5Q2xhc3Nlc10pO1xuICBjb25zdCBidXR0b25XcmFwcGVyQ2xhc3NOYW1lID0gdXNlTWVtbzMoKCkgPT4gY3NzQnV0dG9uV3JhcHBlckNsYXNzZXMudG9TdHJpbmcoKSwgW2Nzc0J1dHRvbldyYXBwZXJDbGFzc2VzXSk7XG4gIGNvbnN0IHVzZXJDb21wU3RhdGVsZXNzID0gdXNlTWVtbzMoKCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IHVzZXJDb21wRGV0YWlscyAmJiB1c2VyQ29tcERldGFpbHMuY29tcG9uZW50RnJvbUZyYW1ld29yayAmJiBpc0NvbXBvbmVudFN0YXRlbGVzcyh1c2VyQ29tcERldGFpbHMuY29tcG9uZW50Q2xhc3MpO1xuICAgIHJldHVybiAhIXJlcztcbiAgfSwgW3VzZXJDb21wRGV0YWlsc10pO1xuICBjb25zdCByZWFjdGl2ZUN1c3RvbUNvbXBvbmVudHMgPSB1c2VNZW1vMygoKSA9PiBnb3MuZ2V0KFwicmVhY3RpdmVDdXN0b21Db21wb25lbnRzXCIpLCBbXSk7XG4gIGNvbnN0IGVuYWJsZUZpbHRlckhhbmRsZXJzID0gdXNlTWVtbzMoKCkgPT4gZ29zLmdldChcImVuYWJsZUZpbHRlckhhbmRsZXJzXCIpLCBbXSk7XG4gIGNvbnN0IFtmbG9hdGluZ0ZpbHRlckNvbXBQcm94eSwgc2V0RmxvYXRpbmdGaWx0ZXJDb21wUHJveHldID0gdXNlU3RhdGU0KCk7XG4gIHVzZUVmZmVjdDMoKCkgPT4ge1xuICAgIGlmICh1c2VyQ29tcERldGFpbHM/LmNvbXBvbmVudEZyb21GcmFtZXdvcmspIHtcbiAgICAgIGlmIChyZWFjdGl2ZUN1c3RvbUNvbXBvbmVudHMpIHtcbiAgICAgICAgY29uc3QgUHJveHlDbGFzcyA9IGVuYWJsZUZpbHRlckhhbmRsZXJzID8gRmxvYXRpbmdGaWx0ZXJEaXNwbGF5Q29tcG9uZW50UHJveHkgOiBGbG9hdGluZ0ZpbHRlckNvbXBvbmVudFByb3h5O1xuICAgICAgICBjb25zdCBjb21wUHJveHkgPSBuZXcgUHJveHlDbGFzcyh1c2VyQ29tcERldGFpbHMucGFyYW1zLCAoKSA9PiBzZXRSZW5kZXJLZXkoKHByZXYpID0+IHByZXYgKyAxKSk7XG4gICAgICAgIHVzZXJDb21wUmVmKGNvbXBQcm94eSk7XG4gICAgICAgIHNldEZsb2F0aW5nRmlsdGVyQ29tcFByb3h5KGNvbXBQcm94eSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB3YXJuUmVhY3RpdmVDdXN0b21Db21wb25lbnRzKCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbdXNlckNvbXBEZXRhaWxzXSk7XG4gIGNvbnN0IGZsb2F0aW5nRmlsdGVyUHJvcHMgPSBmbG9hdGluZ0ZpbHRlckNvbXBQcm94eT8uZ2V0UHJvcHMoKTtcbiAgY29uc3QgcmVhY3RVc2VyQ29tcCA9IHVzZXJDb21wRGV0YWlscz8uY29tcG9uZW50RnJvbUZyYW1ld29yaztcbiAgY29uc3QgVXNlckNvbXBDbGFzcyA9IHVzZXJDb21wRGV0YWlscz8uY29tcG9uZW50Q2xhc3M7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3Q2LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IHNldFJlZjIsIHN0eWxlOiB1c2VyU3R5bGVzLCBjbGFzc05hbWUsIHJvbGU6IFwiZ3JpZGNlbGxcIiB9LCAvKiBAX19QVVJFX18gKi8gUmVhY3Q2LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IGVGbG9hdGluZ0ZpbHRlckJvZHksIGNsYXNzTmFtZTogYm9keUNsYXNzTmFtZSwgcm9sZTogXCJwcmVzZW50YXRpb25cIiB9LCByZWFjdFVzZXJDb21wID8gcmVhY3RpdmVDdXN0b21Db21wb25lbnRzID8gZmxvYXRpbmdGaWx0ZXJQcm9wcyAmJiAvKiBAX19QVVJFX18gKi8gUmVhY3Q2LmNyZWF0ZUVsZW1lbnQoXG4gICAgQ3VzdG9tQ29udGV4dC5Qcm92aWRlcixcbiAgICB7XG4gICAgICB2YWx1ZToge1xuICAgICAgICBzZXRNZXRob2RzOiAobWV0aG9kcykgPT4gZmxvYXRpbmdGaWx0ZXJDb21wUHJveHkuc2V0TWV0aG9kcyhtZXRob2RzKVxuICAgICAgfVxuICAgIH0sXG4gICAgLyogQF9fUFVSRV9fICovIFJlYWN0Ni5jcmVhdGVFbGVtZW50KFVzZXJDb21wQ2xhc3MsIHsgLi4uZmxvYXRpbmdGaWx0ZXJQcm9wcyB9KVxuICApIDogLyogQF9fUFVSRV9fICovIFJlYWN0Ni5jcmVhdGVFbGVtZW50KFVzZXJDb21wQ2xhc3MsIHsgLi4udXNlckNvbXBEZXRhaWxzLnBhcmFtcywgcmVmOiB1c2VyQ29tcFN0YXRlbGVzcyA/ICgpID0+IHtcbiAgfSA6IHVzZXJDb21wUmVmIH0pIDogbnVsbCksIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDYuY3JlYXRlRWxlbWVudChcbiAgICBcImRpdlwiLFxuICAgIHtcbiAgICAgIHJlZjogZUJ1dHRvbldyYXBwZXIsXG4gICAgICBcImFyaWEtaGlkZGVuXCI6IGJ1dHRvbldyYXBwZXJBcmlhSGlkZGVuLFxuICAgICAgY2xhc3NOYW1lOiBidXR0b25XcmFwcGVyQ2xhc3NOYW1lLFxuICAgICAgcm9sZTogXCJwcmVzZW50YXRpb25cIlxuICAgIH0sXG4gICAgLyogQF9fUFVSRV9fICovIFJlYWN0Ni5jcmVhdGVFbGVtZW50KFxuICAgICAgXCJidXR0b25cIixcbiAgICAgIHtcbiAgICAgICAgcmVmOiBlQnV0dG9uU2hvd01haW5GaWx0ZXIsXG4gICAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAgIGNsYXNzTmFtZTogXCJhZy1idXR0b24gYWctZmxvYXRpbmctZmlsdGVyLWJ1dHRvbi1idXR0b25cIixcbiAgICAgICAgdGFiSW5kZXg6IC0xXG4gICAgICB9XG4gICAgKVxuICApKTtcbn07XG52YXIgaGVhZGVyRmlsdGVyQ2VsbENvbXBfZGVmYXVsdCA9IG1lbW8zKEhlYWRlckZpbHRlckNlbGxDb21wKTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9oZWFkZXIvaGVhZGVyR3JvdXBDZWxsQ29tcC50c3hcbmltcG9ydCBSZWFjdDcsIHsgbWVtbyBhcyBtZW1vNCwgdXNlQ2FsbGJhY2sgYXMgdXNlQ2FsbGJhY2s0LCB1c2VDb250ZXh0IGFzIHVzZUNvbnRleHQ0LCB1c2VFZmZlY3QgYXMgdXNlRWZmZWN0NCwgdXNlTGF5b3V0RWZmZWN0IGFzIHVzZUxheW91dEVmZmVjdDQsIHVzZU1lbW8gYXMgdXNlTWVtbzQsIHVzZVJlZiBhcyB1c2VSZWY0LCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IF9FbXB0eUJlYW4gYXMgX0VtcHR5QmVhbjMgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbnZhciBIZWFkZXJHcm91cENlbGxDb21wID0gKHsgY3RybCB9KSA9PiB7XG4gIGNvbnN0IHsgY29udGV4dCB9ID0gdXNlQ29udGV4dDQoQmVhbnNDb250ZXh0KTtcbiAgY29uc3QgW3VzZXJTdHlsZXMsIHNldFVzZXJTdHlsZXNdID0gdXNlU3RhdGU1KCk7XG4gIGNvbnN0IFtjc3NDbGFzc2VzLCBzZXRDc3NDbGFzc2VzXSA9IHVzZVN0YXRlNSgoKSA9PiBuZXcgQ3NzQ2xhc3NlcygpKTtcbiAgY29uc3QgW2Nzc1Jlc2l6YWJsZUNsYXNzZXMsIHNldFJlc2l6YWJsZUNzc0NsYXNzZXNdID0gdXNlU3RhdGU1KCgpID0+IG5ldyBDc3NDbGFzc2VzKCkpO1xuICBjb25zdCBbcmVzaXphYmxlQXJpYUhpZGRlbiwgc2V0UmVzaXphYmxlQXJpYUhpZGRlbl0gPSB1c2VTdGF0ZTUoXCJmYWxzZVwiKTtcbiAgY29uc3QgW2FyaWFFeHBhbmRlZCwgc2V0QXJpYUV4cGFuZGVkXSA9IHVzZVN0YXRlNSgpO1xuICBjb25zdCBbdXNlckNvbXBEZXRhaWxzLCBzZXRVc2VyQ29tcERldGFpbHNdID0gdXNlU3RhdGU1KCk7XG4gIGNvbnN0IGNvbXBCZWFuID0gdXNlUmVmNCgpO1xuICBjb25zdCBlR3VpID0gdXNlUmVmNChudWxsKTtcbiAgY29uc3QgZVJlc2l6ZSA9IHVzZVJlZjQobnVsbCk7XG4gIGNvbnN0IGVIZWFkZXJDb21wV3JhcHBlciA9IHVzZVJlZjQobnVsbCk7XG4gIGNvbnN0IHVzZXJDb21wUmVmID0gdXNlUmVmNCgpO1xuICBjb25zdCBzZXRSZWYyID0gdXNlQ2FsbGJhY2s0KChlUmVmKSA9PiB7XG4gICAgZUd1aS5jdXJyZW50ID0gZVJlZjtcbiAgICBpZiAoIWVSZWYgfHwgIWN0cmwuaXNBbGl2ZSgpIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgY29tcEJlYW4uY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4oY29tcEJlYW4uY3VycmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbXBCZWFuLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IF9FbXB0eUJlYW4zKCkpO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHNldFdpZHRoOiAod2lkdGgpID0+IHtcbiAgICAgICAgaWYgKGVHdWkuY3VycmVudCkge1xuICAgICAgICAgIGVHdWkuY3VycmVudC5zdHlsZS53aWR0aCA9IHdpZHRoO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgdG9nZ2xlQ3NzOiAobmFtZSwgb24pID0+IHNldENzc0NsYXNzZXMoKHByZXYpID0+IHByZXYuc2V0Q2xhc3MobmFtZSwgb24pKSxcbiAgICAgIHNldFVzZXJTdHlsZXM6IChzdHlsZXMpID0+IHNldFVzZXJTdHlsZXMoc3R5bGVzKSxcbiAgICAgIHNldEhlYWRlcldyYXBwZXJIaWRkZW46IChoaWRkZW4pID0+IHtcbiAgICAgICAgY29uc3QgaGVhZGVyQ29tcFdyYXBwZXIgPSBlSGVhZGVyQ29tcFdyYXBwZXIuY3VycmVudDtcbiAgICAgICAgaWYgKCFoZWFkZXJDb21wV3JhcHBlcikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaGlkZGVuKSB7XG4gICAgICAgICAgaGVhZGVyQ29tcFdyYXBwZXIuc3R5bGUuc2V0UHJvcGVydHkoXCJkaXNwbGF5XCIsIFwibm9uZVwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBoZWFkZXJDb21wV3JhcHBlci5zdHlsZS5yZW1vdmVQcm9wZXJ0eShcImRpc3BsYXlcIik7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzZXRIZWFkZXJXcmFwcGVyTWF4SGVpZ2h0OiAodmFsdWUpID0+IHtcbiAgICAgICAgY29uc3QgaGVhZGVyQ29tcFdyYXBwZXIgPSBlSGVhZGVyQ29tcFdyYXBwZXIuY3VycmVudDtcbiAgICAgICAgaWYgKCFoZWFkZXJDb21wV3JhcHBlcikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsdWUgIT0gbnVsbCkge1xuICAgICAgICAgIGhlYWRlckNvbXBXcmFwcGVyLnN0eWxlLnNldFByb3BlcnR5KFwibWF4LWhlaWdodFwiLCBgJHt2YWx1ZX1weGApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGhlYWRlckNvbXBXcmFwcGVyLnN0eWxlLnJlbW92ZVByb3BlcnR5KFwibWF4LWhlaWdodFwiKTtcbiAgICAgICAgfVxuICAgICAgICBoZWFkZXJDb21wV3JhcHBlci5jbGFzc0xpc3QudG9nZ2xlKFwiYWctaGVhZGVyLWNlbGwtY29tcC13cmFwcGVyLWxpbWl0ZWQtaGVpZ2h0XCIsIHZhbHVlICE9IG51bGwpO1xuICAgICAgfSxcbiAgICAgIHNldFVzZXJDb21wRGV0YWlsczogKGNvbXBEZXRhaWxzKSA9PiBzZXRVc2VyQ29tcERldGFpbHMoY29tcERldGFpbHMpLFxuICAgICAgc2V0UmVzaXphYmxlRGlzcGxheWVkOiAoZGlzcGxheWVkKSA9PiB7XG4gICAgICAgIHNldFJlc2l6YWJsZUNzc0NsYXNzZXMoKHByZXYpID0+IHByZXYuc2V0Q2xhc3MoXCJhZy1oaWRkZW5cIiwgIWRpc3BsYXllZCkpO1xuICAgICAgICBzZXRSZXNpemFibGVBcmlhSGlkZGVuKCFkaXNwbGF5ZWQgPyBcInRydWVcIiA6IFwiZmFsc2VcIik7XG4gICAgICB9LFxuICAgICAgc2V0QXJpYUV4cGFuZGVkOiAoZXhwYW5kZWQpID0+IHNldEFyaWFFeHBhbmRlZChleHBhbmRlZCksXG4gICAgICBnZXRVc2VyQ29tcEluc3RhbmNlOiAoKSA9PiB1c2VyQ29tcFJlZi5jdXJyZW50IHx8IHZvaWQgMFxuICAgIH07XG4gICAgY3RybC5zZXRDb21wKGNvbXBQcm94eSwgZVJlZiwgZVJlc2l6ZS5jdXJyZW50LCBlSGVhZGVyQ29tcFdyYXBwZXIuY3VycmVudCwgY29tcEJlYW4uY3VycmVudCk7XG4gIH0sIFtdKTtcbiAgdXNlTGF5b3V0RWZmZWN0NCgoKSA9PiBzaG93SnNDb21wKHVzZXJDb21wRGV0YWlscywgY29udGV4dCwgZUhlYWRlckNvbXBXcmFwcGVyLmN1cnJlbnQpLCBbdXNlckNvbXBEZXRhaWxzXSk7XG4gIHVzZUVmZmVjdDQoKCkgPT4ge1xuICAgIGlmIChlR3VpLmN1cnJlbnQpIHtcbiAgICAgIGN0cmwuc2V0RHJhZ1NvdXJjZShlR3VpLmN1cnJlbnQpO1xuICAgIH1cbiAgfSwgW3VzZXJDb21wRGV0YWlsc10pO1xuICBjb25zdCB1c2VyQ29tcFN0YXRlbGVzcyA9IHVzZU1lbW80KCgpID0+IHtcbiAgICBjb25zdCByZXMgPSB1c2VyQ29tcERldGFpbHM/LmNvbXBvbmVudEZyb21GcmFtZXdvcmsgJiYgaXNDb21wb25lbnRTdGF0ZWxlc3ModXNlckNvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzKTtcbiAgICByZXR1cm4gISFyZXM7XG4gIH0sIFt1c2VyQ29tcERldGFpbHNdKTtcbiAgY29uc3QgY2xhc3NOYW1lID0gdXNlTWVtbzQoKCkgPT4gXCJhZy1oZWFkZXItZ3JvdXAtY2VsbCBcIiArIGNzc0NsYXNzZXMudG9TdHJpbmcoKSwgW2Nzc0NsYXNzZXNdKTtcbiAgY29uc3QgcmVzaXphYmxlQ2xhc3NOYW1lID0gdXNlTWVtbzQoXG4gICAgKCkgPT4gXCJhZy1oZWFkZXItY2VsbC1yZXNpemUgXCIgKyBjc3NSZXNpemFibGVDbGFzc2VzLnRvU3RyaW5nKCksXG4gICAgW2Nzc1Jlc2l6YWJsZUNsYXNzZXNdXG4gICk7XG4gIGNvbnN0IHJlYWN0VXNlckNvbXAgPSB1c2VyQ29tcERldGFpbHM/LmNvbXBvbmVudEZyb21GcmFtZXdvcms7XG4gIGNvbnN0IFVzZXJDb21wQ2xhc3MgPSB1c2VyQ29tcERldGFpbHM/LmNvbXBvbmVudENsYXNzO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0Ny5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBzZXRSZWYyLCBzdHlsZTogdXNlclN0eWxlcywgY2xhc3NOYW1lLCByb2xlOiBcImNvbHVtbmhlYWRlclwiLCBcImFyaWEtZXhwYW5kZWRcIjogYXJpYUV4cGFuZGVkIH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDcuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHJlZjogZUhlYWRlckNvbXBXcmFwcGVyLCBjbGFzc05hbWU6IFwiYWctaGVhZGVyLWNlbGwtY29tcC13cmFwcGVyXCIsIHJvbGU6IFwicHJlc2VudGF0aW9uXCIgfSwgcmVhY3RVc2VyQ29tcCA/IHVzZXJDb21wU3RhdGVsZXNzID8gLyogQF9fUFVSRV9fICovIFJlYWN0Ny5jcmVhdGVFbGVtZW50KFVzZXJDb21wQ2xhc3MsIHsgLi4udXNlckNvbXBEZXRhaWxzLnBhcmFtcyB9KSA6IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDcuY3JlYXRlRWxlbWVudChVc2VyQ29tcENsYXNzLCB7IC4uLnVzZXJDb21wRGV0YWlscy5wYXJhbXMsIHJlZjogdXNlckNvbXBSZWYgfSkgOiBudWxsKSwgLyogQF9fUFVSRV9fICovIFJlYWN0Ny5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBlUmVzaXplLCBcImFyaWEtaGlkZGVuXCI6IHJlc2l6YWJsZUFyaWFIaWRkZW4sIGNsYXNzTmFtZTogcmVzaXphYmxlQ2xhc3NOYW1lIH0pKTtcbn07XG52YXIgaGVhZGVyR3JvdXBDZWxsQ29tcF9kZWZhdWx0ID0gbWVtbzQoSGVhZGVyR3JvdXBDZWxsQ29tcCk7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvaGVhZGVyL2hlYWRlclJvd0NvbXAudHN4XG52YXIgSGVhZGVyUm93Q29tcCA9ICh7IGN0cmwgfSkgPT4ge1xuICBjb25zdCB7IGdvcywgY29udGV4dCB9ID0gdXNlQ29udGV4dDUoQmVhbnNDb250ZXh0KTtcbiAgY29uc3QgeyB0b3BPZmZzZXQsIHJvd0hlaWdodCB9ID0gdXNlTWVtbzUoKCkgPT4gY3RybC5nZXRUb3BBbmRIZWlnaHQoKSwgW10pO1xuICBjb25zdCB0YWJJbmRleCA9IHVzZU1lbW81KCgpID0+IGdvcy5nZXQoXCJ0YWJJbmRleFwiKSwgW10pO1xuICBjb25zdCBbYXJpYVJvd0luZGV4LCBzZXRBcmlhUm93SW5kZXhdID0gdXNlU3RhdGU2KCgpID0+IGN0cmwuZ2V0QXJpYVJvd0luZGV4KCkpO1xuICBjb25zdCBjbGFzc05hbWUgPSBjdHJsLmhlYWRlclJvd0NsYXNzO1xuICBjb25zdCBbaGVpZ2h0LCBzZXRIZWlnaHRdID0gdXNlU3RhdGU2KCgpID0+IHJvd0hlaWdodCArIFwicHhcIik7XG4gIGNvbnN0IFt0b3AsIHNldFRvcF0gPSB1c2VTdGF0ZTYoKCkgPT4gdG9wT2Zmc2V0ICsgXCJweFwiKTtcbiAgY29uc3QgY2VsbEN0cmxzUmVmID0gdXNlUmVmNShudWxsKTtcbiAgY29uc3QgW2NlbGxDdHJscywgc2V0Q2VsbEN0cmxzXSA9IHVzZVN0YXRlNigoKSA9PiBjdHJsLmdldFVwZGF0ZWRIZWFkZXJDdHJscygpKTtcbiAgY29uc3QgY29tcEJlYW4gPSB1c2VSZWY1KCk7XG4gIGNvbnN0IGVHdWkgPSB1c2VSZWY1KG51bGwpO1xuICBjb25zdCBzZXRSZWYyID0gdXNlQ2FsbGJhY2s1KChlUmVmKSA9PiB7XG4gICAgZUd1aS5jdXJyZW50ID0gZVJlZjtcbiAgICBpZiAoIWVSZWYgfHwgIWN0cmwuaXNBbGl2ZSgpIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgY29tcEJlYW4uY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4oY29tcEJlYW4uY3VycmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbXBCZWFuLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IF9FbXB0eUJlYW40KCkpO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHNldEhlaWdodDogKGhlaWdodDIpID0+IHNldEhlaWdodChoZWlnaHQyKSxcbiAgICAgIHNldFRvcDogKHRvcDIpID0+IHNldFRvcCh0b3AyKSxcbiAgICAgIHNldEhlYWRlckN0cmxzOiAoY3RybHMsIGZvcmNlT3JkZXIsIGFmdGVyU2Nyb2xsKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZDZWxsQ3RybHMgPSBjZWxsQ3RybHNSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgbmV4dENlbGxzID0gZ2V0TmV4dFZhbHVlSWZEaWZmZXJlbnQocHJldkNlbGxDdHJscywgY3RybHMsIGZvcmNlT3JkZXIpO1xuICAgICAgICBpZiAobmV4dENlbGxzICE9PSBwcmV2Q2VsbEN0cmxzKSB7XG4gICAgICAgICAgY2VsbEN0cmxzUmVmLmN1cnJlbnQgPSBuZXh0Q2VsbHM7XG4gICAgICAgICAgYWdGbHVzaFN5bmMoYWZ0ZXJTY3JvbGwsICgpID0+IHNldENlbGxDdHJscyhuZXh0Q2VsbHMpKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNldFdpZHRoOiAod2lkdGgpID0+IHtcbiAgICAgICAgaWYgKGVHdWkuY3VycmVudCkge1xuICAgICAgICAgIGVHdWkuY3VycmVudC5zdHlsZS53aWR0aCA9IHdpZHRoO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgc2V0Um93SW5kZXg6IChyb3dJbmRleCkgPT4ge1xuICAgICAgICBzZXRBcmlhUm93SW5kZXgocm93SW5kZXgpO1xuICAgICAgfVxuICAgIH07XG4gICAgY3RybC5zZXRDb21wKGNvbXBQcm94eSwgY29tcEJlYW4uY3VycmVudCwgZmFsc2UpO1xuICB9LCBbXSk7XG4gIGNvbnN0IHN0eWxlID0gdXNlTWVtbzUoXG4gICAgKCkgPT4gKHtcbiAgICAgIGhlaWdodCxcbiAgICAgIHRvcFxuICAgIH0pLFxuICAgIFtoZWlnaHQsIHRvcF1cbiAgKTtcbiAgY29uc3QgY3JlYXRlQ2VsbEpzeCA9IHVzZUNhbGxiYWNrNSgoY2VsbEN0cmwpID0+IHtcbiAgICBzd2l0Y2ggKGN0cmwudHlwZSkge1xuICAgICAgY2FzZSBcImdyb3VwXCI6XG4gICAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3Q4LmNyZWF0ZUVsZW1lbnQoaGVhZGVyR3JvdXBDZWxsQ29tcF9kZWZhdWx0LCB7IGN0cmw6IGNlbGxDdHJsLCBrZXk6IGNlbGxDdHJsLmluc3RhbmNlSWQgfSk7XG4gICAgICBjYXNlIFwiZmlsdGVyXCI6XG4gICAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3Q4LmNyZWF0ZUVsZW1lbnQoaGVhZGVyRmlsdGVyQ2VsbENvbXBfZGVmYXVsdCwgeyBjdHJsOiBjZWxsQ3RybCwga2V5OiBjZWxsQ3RybC5pbnN0YW5jZUlkIH0pO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDguY3JlYXRlRWxlbWVudChoZWFkZXJDZWxsQ29tcF9kZWZhdWx0LCB7IGN0cmw6IGNlbGxDdHJsLCBrZXk6IGNlbGxDdHJsLmluc3RhbmNlSWQgfSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3Q4LmNyZWF0ZUVsZW1lbnQoXG4gICAgXCJkaXZcIixcbiAgICB7XG4gICAgICByZWY6IHNldFJlZjIsXG4gICAgICBjbGFzc05hbWUsXG4gICAgICByb2xlOiBcInJvd1wiLFxuICAgICAgc3R5bGUsXG4gICAgICB0YWJJbmRleCxcbiAgICAgIFwiYXJpYS1yb3dpbmRleFwiOiBhcmlhUm93SW5kZXhcbiAgICB9LFxuICAgIGNlbGxDdHJscy5tYXAoY3JlYXRlQ2VsbEpzeClcbiAgKTtcbn07XG52YXIgaGVhZGVyUm93Q29tcF9kZWZhdWx0ID0gbWVtbzUoSGVhZGVyUm93Q29tcCk7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvaGVhZGVyL2hlYWRlclJvd0NvbnRhaW5lckNvbXAudHN4XG52YXIgSGVhZGVyUm93Q29udGFpbmVyQ29tcCA9ICh7IHBpbm5lZCB9KSA9PiB7XG4gIGNvbnN0IFtkaXNwbGF5ZWQsIHNldERpc3BsYXllZF0gPSB1c2VTdGF0ZTcodHJ1ZSk7XG4gIGNvbnN0IFtoZWFkZXJSb3dDdHJscywgc2V0SGVhZGVyUm93Q3RybHNdID0gdXNlU3RhdGU3KFtdKTtcbiAgY29uc3QgeyBjb250ZXh0IH0gPSB1c2VDb250ZXh0NihCZWFuc0NvbnRleHQpO1xuICBjb25zdCBlR3VpID0gdXNlUmVmNihudWxsKTtcbiAgY29uc3QgZUNlbnRlckNvbnRhaW5lciA9IHVzZVJlZjYobnVsbCk7XG4gIGNvbnN0IGhlYWRlclJvd0N0cmxSZWYgPSB1c2VSZWY2KCk7XG4gIGNvbnN0IHBpbm5lZExlZnQgPSBwaW5uZWQgPT09IFwibGVmdFwiO1xuICBjb25zdCBwaW5uZWRSaWdodCA9IHBpbm5lZCA9PT0gXCJyaWdodFwiO1xuICBjb25zdCBjZW50cmUgPSAhcGlubmVkTGVmdCAmJiAhcGlubmVkUmlnaHQ7XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazYoKGVSZWYpID0+IHtcbiAgICBlR3VpLmN1cnJlbnQgPSBlUmVmO1xuICAgIGlmICghZVJlZiB8fCBjb250ZXh0LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgIGhlYWRlclJvd0N0cmxSZWYuY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4oaGVhZGVyUm93Q3RybFJlZi5jdXJyZW50KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaGVhZGVyUm93Q3RybFJlZi5jdXJyZW50ID0gY29udGV4dC5jcmVhdGVCZWFuKG5ldyBIZWFkZXJSb3dDb250YWluZXJDdHJsKHBpbm5lZCkpO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHNldERpc3BsYXllZCxcbiAgICAgIHNldEN0cmxzOiAoY3RybHMpID0+IHNldEhlYWRlclJvd0N0cmxzKGN0cmxzKSxcbiAgICAgIC8vIGNlbnRyZSBvbmx5XG4gICAgICBzZXRDZW50ZXJXaWR0aDogKHdpZHRoKSA9PiB7XG4gICAgICAgIGlmIChlQ2VudGVyQ29udGFpbmVyLmN1cnJlbnQpIHtcbiAgICAgICAgICBlQ2VudGVyQ29udGFpbmVyLmN1cnJlbnQuc3R5bGUud2lkdGggPSB3aWR0aDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNldFZpZXdwb3J0U2Nyb2xsTGVmdDogKGxlZnQpID0+IHtcbiAgICAgICAgaWYgKGVHdWkuY3VycmVudCkge1xuICAgICAgICAgIGVHdWkuY3VycmVudC5zY3JvbGxMZWZ0ID0gbGVmdDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIC8vIHBpbm5lZCBvbmx5XG4gICAgICBzZXRQaW5uZWRDb250YWluZXJXaWR0aDogKHdpZHRoKSA9PiB7XG4gICAgICAgIGlmIChlR3VpLmN1cnJlbnQpIHtcbiAgICAgICAgICBlR3VpLmN1cnJlbnQuc3R5bGUud2lkdGggPSB3aWR0aDtcbiAgICAgICAgICBlR3VpLmN1cnJlbnQuc3R5bGUubWluV2lkdGggPSB3aWR0aDtcbiAgICAgICAgICBlR3VpLmN1cnJlbnQuc3R5bGUubWF4V2lkdGggPSB3aWR0aDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgaGVhZGVyUm93Q3RybFJlZi5jdXJyZW50LnNldENvbXAoY29tcFByb3h5LCBlR3VpLmN1cnJlbnQpO1xuICB9LCBbXSk7XG4gIGNvbnN0IGNsYXNzTmFtZSA9ICFkaXNwbGF5ZWQgPyBcImFnLWhpZGRlblwiIDogXCJcIjtcbiAgY29uc3QgaW5zZXJ0Um93c0pzeCA9ICgpID0+IGhlYWRlclJvd0N0cmxzLm1hcCgoY3RybCkgPT4gLyogQF9fUFVSRV9fICovIFJlYWN0OS5jcmVhdGVFbGVtZW50KGhlYWRlclJvd0NvbXBfZGVmYXVsdCwgeyBjdHJsLCBrZXk6IGN0cmwuaW5zdGFuY2VJZCB9KSk7XG4gIHJldHVybiBwaW5uZWRMZWZ0ID8gLyogQF9fUFVSRV9fICovIFJlYWN0OS5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBzZXRSZWYyLCBjbGFzc05hbWU6IFwiYWctcGlubmVkLWxlZnQtaGVhZGVyIFwiICsgY2xhc3NOYW1lLCBcImFyaWEtaGlkZGVuXCI6ICFkaXNwbGF5ZWQsIHJvbGU6IFwicm93Z3JvdXBcIiB9LCBpbnNlcnRSb3dzSnN4KCkpIDogcGlubmVkUmlnaHQgPyAvKiBAX19QVVJFX18gKi8gUmVhY3Q5LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IHNldFJlZjIsIGNsYXNzTmFtZTogXCJhZy1waW5uZWQtcmlnaHQtaGVhZGVyIFwiICsgY2xhc3NOYW1lLCBcImFyaWEtaGlkZGVuXCI6ICFkaXNwbGF5ZWQsIHJvbGU6IFwicm93Z3JvdXBcIiB9LCBpbnNlcnRSb3dzSnN4KCkpIDogY2VudHJlID8gLyogQF9fUFVSRV9fICovIFJlYWN0OS5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBzZXRSZWYyLCBjbGFzc05hbWU6IFwiYWctaGVhZGVyLXZpZXdwb3J0IFwiICsgY2xhc3NOYW1lLCByb2xlOiBcInJvd2dyb3VwXCIsIHRhYkluZGV4OiAtMSB9LCAvKiBAX19QVVJFX18gKi8gUmVhY3Q5LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IGVDZW50ZXJDb250YWluZXIsIGNsYXNzTmFtZTogXCJhZy1oZWFkZXItY29udGFpbmVyXCIsIHJvbGU6IFwicHJlc2VudGF0aW9uXCIgfSwgaW5zZXJ0Um93c0pzeCgpKSkgOiBudWxsO1xufTtcbnZhciBoZWFkZXJSb3dDb250YWluZXJDb21wX2RlZmF1bHQgPSBtZW1vNihIZWFkZXJSb3dDb250YWluZXJDb21wKTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9oZWFkZXIvZ3JpZEhlYWRlckNvbXAudHN4XG52YXIgR3JpZEhlYWRlckNvbXAgPSAoKSA9PiB7XG4gIGNvbnN0IFtjc3NDbGFzc2VzLCBzZXRDc3NDbGFzc2VzXSA9IHVzZVN0YXRlOCgoKSA9PiBuZXcgQ3NzQ2xhc3NlcygpKTtcbiAgY29uc3QgW2hlaWdodCwgc2V0SGVpZ2h0XSA9IHVzZVN0YXRlOCgpO1xuICBjb25zdCB7IGNvbnRleHQgfSA9IHVzZUNvbnRleHQ3KEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IGVHdWkgPSB1c2VSZWY3KG51bGwpO1xuICBjb25zdCBncmlkQ3RybFJlZiA9IHVzZVJlZjcoKTtcbiAgY29uc3Qgc2V0UmVmMiA9IHVzZUNhbGxiYWNrNygoZVJlZikgPT4ge1xuICAgIGVHdWkuY3VycmVudCA9IGVSZWY7XG4gICAgaWYgKCFlUmVmIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgZ3JpZEN0cmxSZWYuY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4oZ3JpZEN0cmxSZWYuY3VycmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGdyaWRDdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IEdyaWRIZWFkZXJDdHJsKCkpO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBzZXRDc3NDbGFzc2VzKChwcmV2KSA9PiBwcmV2LnNldENsYXNzKG5hbWUsIG9uKSksXG4gICAgICBzZXRIZWlnaHRBbmRNaW5IZWlnaHQ6IChoZWlnaHQyKSA9PiBzZXRIZWlnaHQoaGVpZ2h0MilcbiAgICB9O1xuICAgIGdyaWRDdHJsUmVmLmN1cnJlbnQuc2V0Q29tcChjb21wUHJveHksIGVSZWYsIGVSZWYpO1xuICB9LCBbXSk7XG4gIGNvbnN0IGNsYXNzTmFtZSA9IHVzZU1lbW82KCgpID0+IHtcbiAgICBjb25zdCByZXMgPSBjc3NDbGFzc2VzLnRvU3RyaW5nKCk7XG4gICAgcmV0dXJuIFwiYWctaGVhZGVyIFwiICsgcmVzO1xuICB9LCBbY3NzQ2xhc3Nlc10pO1xuICBjb25zdCBzdHlsZSA9IHVzZU1lbW82KFxuICAgICgpID0+ICh7XG4gICAgICBoZWlnaHQsXG4gICAgICBtaW5IZWlnaHQ6IGhlaWdodFxuICAgIH0pLFxuICAgIFtoZWlnaHRdXG4gICk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3QxMC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBzZXRSZWYyLCBjbGFzc05hbWUsIHN0eWxlLCByb2xlOiBcInByZXNlbnRhdGlvblwiIH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEwLmNyZWF0ZUVsZW1lbnQoaGVhZGVyUm93Q29udGFpbmVyQ29tcF9kZWZhdWx0LCB7IHBpbm5lZDogXCJsZWZ0XCIgfSksIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEwLmNyZWF0ZUVsZW1lbnQoaGVhZGVyUm93Q29udGFpbmVyQ29tcF9kZWZhdWx0LCB7IHBpbm5lZDogbnVsbCB9KSwgLyogQF9fUFVSRV9fICovIFJlYWN0MTAuY3JlYXRlRWxlbWVudChoZWFkZXJSb3dDb250YWluZXJDb21wX2RlZmF1bHQsIHsgcGlubmVkOiBcInJpZ2h0XCIgfSkpO1xufTtcbnZhciBncmlkSGVhZGVyQ29tcF9kZWZhdWx0ID0gbWVtbzcoR3JpZEhlYWRlckNvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL3JlYWN0Q29tbWVudC50c3hcbmltcG9ydCB7IHVzZUVmZmVjdCBhcyB1c2VFZmZlY3Q1IH0gZnJvbSBcInJlYWN0XCI7XG52YXIgdXNlUmVhY3RDb21tZW50RWZmZWN0ID0gKGNvbW1lbnQsIGVGb3JDb21tZW50UmVmKSA9PiB7XG4gIHVzZUVmZmVjdDUoKCkgPT4ge1xuICAgIGNvbnN0IGVGb3JDb21tZW50ID0gZUZvckNvbW1lbnRSZWYuY3VycmVudDtcbiAgICBpZiAoZUZvckNvbW1lbnQpIHtcbiAgICAgIGNvbnN0IGVQYXJlbnQgPSBlRm9yQ29tbWVudC5wYXJlbnRFbGVtZW50O1xuICAgICAgaWYgKGVQYXJlbnQpIHtcbiAgICAgICAgY29uc3QgZUNvbW1lbnQgPSBkb2N1bWVudC5jcmVhdGVDb21tZW50KGNvbW1lbnQpO1xuICAgICAgICBlUGFyZW50Lmluc2VydEJlZm9yZShlQ29tbWVudCwgZUZvckNvbW1lbnQpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGVDb21tZW50LnJlbW92ZSgpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgfSwgW2NvbW1lbnRdKTtcbn07XG52YXIgcmVhY3RDb21tZW50X2RlZmF1bHQgPSB1c2VSZWFjdENvbW1lbnRFZmZlY3Q7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvcm93cy9yb3dDb250YWluZXJDb21wLnRzeFxuaW1wb3J0IFJlYWN0MTUsIHsgbWVtbyBhcyBtZW1vMTEsIHVzZUNhbGxiYWNrIGFzIHVzZUNhbGxiYWNrMTEsIHVzZUNvbnRleHQgYXMgdXNlQ29udGV4dDEyLCB1c2VNZW1vIGFzIHVzZU1lbW8xMCwgdXNlUmVmIGFzIHVzZVJlZjEyLCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTEzIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBSb3dDb250YWluZXJDdHJsLFxuICBfZ2V0Um93Q29udGFpbmVyQ2xhc3MsXG4gIF9nZXRSb3dDb250YWluZXJPcHRpb25zLFxuICBfZ2V0Um93U3BhbkNvbnRhaW5lckNsYXNzLFxuICBfZ2V0Um93Vmlld3BvcnRDbGFzc1xufSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9yb3dzL3Jvd0NvbXAudHN4XG5pbXBvcnQgUmVhY3QxNCwgeyBtZW1vIGFzIG1lbW8xMCwgdXNlQ2FsbGJhY2sgYXMgdXNlQ2FsbGJhY2sxMCwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MTEsIHVzZUVmZmVjdCBhcyB1c2VFZmZlY3Q4LCB1c2VMYXlvdXRFZmZlY3QgYXMgdXNlTGF5b3V0RWZmZWN0NywgdXNlTWVtbyBhcyB1c2VNZW1vOSwgdXNlUmVmIGFzIHVzZVJlZjExLCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTEyIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDc3NDbGFzc01hbmFnZXIgYXMgQ3NzQ2xhc3NNYW5hZ2VyMywgX0VtcHR5QmVhbiBhcyBfRW1wdHlCZWFuNiB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2NlbGxzL2NlbGxDb21wLnRzeFxuaW1wb3J0IFJlYWN0MTMsIHsgU3VzcGVuc2UsIG1lbW8gYXMgbWVtbzksIHVzZUNhbGxiYWNrIGFzIHVzZUNhbGxiYWNrOSwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MTAsIHVzZUxheW91dEVmZmVjdCBhcyB1c2VMYXlvdXRFZmZlY3Q2LCB1c2VNZW1vIGFzIHVzZU1lbW84LCB1c2VSZWYgYXMgdXNlUmVmMTAsIHVzZVN0YXRlIGFzIHVzZVN0YXRlMTEgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENzc0NsYXNzTWFuYWdlciBhcyBDc3NDbGFzc01hbmFnZXIyLCBfRW1wdHlCZWFuIGFzIF9FbXB0eUJlYW41LCBfcmVtb3ZlRnJvbVBhcmVudCB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9zaGFyZWQvY3VzdG9tQ29tcC9jZWxsRWRpdG9yQ29tcG9uZW50UHJveHkudHNcbmltcG9ydCB7IEFnUHJvbWlzZSBhcyBBZ1Byb21pc2U4IH0gZnJvbSBcImFnLWdyaWQtY29tbXVuaXR5XCI7XG52YXIgQ2VsbEVkaXRvckNvbXBvbmVudFByb3h5ID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihjZWxsRWRpdG9yUGFyYW1zLCByZWZyZXNoUHJvcHMpIHtcbiAgICB0aGlzLmNlbGxFZGl0b3JQYXJhbXMgPSBjZWxsRWRpdG9yUGFyYW1zO1xuICAgIHRoaXMucmVmcmVzaFByb3BzID0gcmVmcmVzaFByb3BzO1xuICAgIHRoaXMuaW5zdGFuY2VDcmVhdGVkID0gbmV3IEFnUHJvbWlzZTgoKHJlc29sdmUpID0+IHtcbiAgICAgIHRoaXMucmVzb2x2ZUluc3RhbmNlQ3JlYXRlZCA9IHJlc29sdmU7XG4gICAgfSk7XG4gICAgdGhpcy5vblZhbHVlQ2hhbmdlID0gKHZhbHVlKSA9PiB0aGlzLnVwZGF0ZVZhbHVlKHZhbHVlKTtcbiAgICB0aGlzLnZhbHVlID0gY2VsbEVkaXRvclBhcmFtcy52YWx1ZTtcbiAgfVxuICBnZXRQcm9wcygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4udGhpcy5jZWxsRWRpdG9yUGFyYW1zLFxuICAgICAgaW5pdGlhbFZhbHVlOiB0aGlzLmNlbGxFZGl0b3JQYXJhbXMudmFsdWUsXG4gICAgICB2YWx1ZTogdGhpcy52YWx1ZSxcbiAgICAgIG9uVmFsdWVDaGFuZ2U6IHRoaXMub25WYWx1ZUNoYW5nZVxuICAgIH07XG4gIH1cbiAgZ2V0VmFsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH1cbiAgcmVmcmVzaChwYXJhbXMpIHtcbiAgICB0aGlzLmNlbGxFZGl0b3JQYXJhbXMgPSBwYXJhbXM7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxuICBzZXRNZXRob2RzKG1ldGhvZHMpIHtcbiAgICBhZGRPcHRpb25hbE1ldGhvZHModGhpcy5nZXRPcHRpb25hbE1ldGhvZHMoKSwgbWV0aG9kcywgdGhpcyk7XG4gIH1cbiAgZ2V0SW5zdGFuY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5zdGFuY2VDcmVhdGVkLnRoZW4oKCkgPT4gdGhpcy5jb21wb25lbnRJbnN0YW5jZSk7XG4gIH1cbiAgc2V0UmVmKGNvbXBvbmVudEluc3RhbmNlKSB7XG4gICAgdGhpcy5jb21wb25lbnRJbnN0YW5jZSA9IGNvbXBvbmVudEluc3RhbmNlO1xuICAgIHRoaXMucmVzb2x2ZUluc3RhbmNlQ3JlYXRlZD8uKCk7XG4gICAgdGhpcy5yZXNvbHZlSW5zdGFuY2VDcmVhdGVkID0gdm9pZCAwO1xuICB9XG4gIGdldE9wdGlvbmFsTWV0aG9kcygpIHtcbiAgICByZXR1cm4gW1xuICAgICAgXCJpc0NhbmNlbEJlZm9yZVN0YXJ0XCIsXG4gICAgICBcImlzQ2FuY2VsQWZ0ZXJFbmRcIixcbiAgICAgIFwiZm9jdXNJblwiLFxuICAgICAgXCJmb2N1c091dFwiLFxuICAgICAgXCJhZnRlckd1aUF0dGFjaGVkXCIsXG4gICAgICBcImdldFZhbGlkYXRpb25FcnJvcnNcIixcbiAgICAgIFwiZ2V0VmFsaWRhdGlvbkVsZW1lbnRcIlxuICAgIF07XG4gIH1cbiAgdXBkYXRlVmFsdWUodmFsdWUpIHtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgdGhpcy5yZWZyZXNoUHJvcHMoKTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9jZWxscy9jZWxsRWRpdG9yQ29tcC50c3hcbmltcG9ydCBSZWFjdDExIGZyb20gXCJyZWFjdFwiO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2NlbGxzL3BvcHVwRWRpdG9yQ29tcC50c3hcbmltcG9ydCB7IG1lbW8gYXMgbWVtbzgsIHVzZUNvbnRleHQgYXMgdXNlQ29udGV4dDgsIHVzZUxheW91dEVmZmVjdCBhcyB1c2VMYXlvdXRFZmZlY3Q1LCB1c2VTdGF0ZSBhcyB1c2VTdGF0ZTEwIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjcmVhdGVQb3J0YWwgYXMgY3JlYXRlUG9ydGFsMiB9IGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCB7IF9nZXRBY3RpdmVEb21FbGVtZW50IH0gZnJvbSBcImFnLWdyaWQtY29tbXVuaXR5XCI7XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvdXNlRWZmZWN0T25jZS50c3hcbmltcG9ydCB7IHVzZUVmZmVjdCBhcyB1c2VFZmZlY3Q2LCB1c2VSZWYgYXMgdXNlUmVmOCwgdXNlU3RhdGUgYXMgdXNlU3RhdGU5IH0gZnJvbSBcInJlYWN0XCI7XG52YXIgdXNlRWZmZWN0T25jZSA9IChlZmZlY3QpID0+IHtcbiAgY29uc3QgZWZmZWN0Rm4gPSB1c2VSZWY4KGVmZmVjdCk7XG4gIGNvbnN0IGRlc3Ryb3lGbiA9IHVzZVJlZjgoKTtcbiAgY29uc3QgZWZmZWN0Q2FsbGVkID0gdXNlUmVmOChmYWxzZSk7XG4gIGNvbnN0IHJlbmRlcmVkID0gdXNlUmVmOChmYWxzZSk7XG4gIGNvbnN0IFssIHNldFZhbF0gPSB1c2VTdGF0ZTkoMCk7XG4gIGlmIChlZmZlY3RDYWxsZWQuY3VycmVudCkge1xuICAgIHJlbmRlcmVkLmN1cnJlbnQgPSB0cnVlO1xuICB9XG4gIHVzZUVmZmVjdDYoKCkgPT4ge1xuICAgIGlmICghZWZmZWN0Q2FsbGVkLmN1cnJlbnQpIHtcbiAgICAgIGRlc3Ryb3lGbi5jdXJyZW50ID0gZWZmZWN0Rm4uY3VycmVudCgpO1xuICAgICAgZWZmZWN0Q2FsbGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgICBzZXRWYWwoKHZhbCkgPT4gdmFsICsgMSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICghcmVuZGVyZWQuY3VycmVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBkZXN0cm95Rm4uY3VycmVudD8uKCk7XG4gICAgfTtcbiAgfSwgW10pO1xufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9jZWxscy9wb3B1cEVkaXRvckNvbXAudHN4XG52YXIgUG9wdXBFZGl0b3JDb21wID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IFtwb3B1cEVkaXRvcldyYXBwZXIsIHNldFBvcHVwRWRpdG9yV3JhcHBlcl0gPSB1c2VTdGF0ZTEwKCk7XG4gIGNvbnN0IGJlYW5zID0gdXNlQ29udGV4dDgoQmVhbnNDb250ZXh0KTtcbiAgY29uc3QgeyBjb250ZXh0LCBwb3B1cFN2YywgZ29zLCBlZGl0U3ZjIH0gPSBiZWFucztcbiAgY29uc3QgeyBlZGl0RGV0YWlscywgY2VsbEN0cmwsIGVQYXJlbnRDZWxsIH0gPSBwcm9wcztcbiAgdXNlRWZmZWN0T25jZSgoKSA9PiB7XG4gICAgY29uc3QgeyBjb21wRGV0YWlscyB9ID0gZWRpdERldGFpbHM7XG4gICAgY29uc3QgdXNlTW9kZWxQb3B1cCA9IGdvcy5nZXQoXCJzdG9wRWRpdGluZ1doZW5DZWxsc0xvc2VGb2N1c1wiKTtcbiAgICBsZXQgaGlkZUVkaXRvclBvcHVwID0gdm9pZCAwO1xuICAgIGxldCB3cmFwcGVyO1xuICAgIGlmICghY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICB3cmFwcGVyID0gY29udGV4dC5jcmVhdGVCZWFuKGVkaXRTdmMuY3JlYXRlUG9wdXBFZGl0b3JXcmFwcGVyKGNvbXBEZXRhaWxzLnBhcmFtcykpO1xuICAgICAgY29uc3QgZVBvcHVwR3VpID0gd3JhcHBlci5nZXRHdWkoKTtcbiAgICAgIGlmIChwcm9wcy5qc0NoaWxkQ29tcCkge1xuICAgICAgICBjb25zdCBlQ2hpbGRHdWkgPSBwcm9wcy5qc0NoaWxkQ29tcC5nZXRHdWkoKTtcbiAgICAgICAgaWYgKGVDaGlsZEd1aSkge1xuICAgICAgICAgIGVQb3B1cEd1aS5hcHBlbmRDaGlsZChlQ2hpbGRHdWkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCB7IGNvbHVtbiwgcm93Tm9kZSB9ID0gY2VsbEN0cmw7XG4gICAgICBjb25zdCBwb3NpdGlvblBhcmFtcyA9IHtcbiAgICAgICAgY29sdW1uLFxuICAgICAgICByb3dOb2RlLFxuICAgICAgICB0eXBlOiBcInBvcHVwQ2VsbEVkaXRvclwiLFxuICAgICAgICBldmVudFNvdXJjZTogZVBhcmVudENlbGwsXG4gICAgICAgIGVQb3B1cDogZVBvcHVwR3VpLFxuICAgICAgICBwb3NpdGlvbjogZWRpdERldGFpbHMucG9wdXBQb3NpdGlvbixcbiAgICAgICAga2VlcFdpdGhpbkJvdW5kczogdHJ1ZVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHBvc2l0aW9uQ2FsbGJhY2sgPSBwb3B1cFN2Yz8ucG9zaXRpb25Qb3B1cEJ5Q29tcG9uZW50LmJpbmQocG9wdXBTdmMsIHBvc2l0aW9uUGFyYW1zKTtcbiAgICAgIGNvbnN0IGFkZFBvcHVwUmVzID0gcG9wdXBTdmM/LmFkZFBvcHVwKHtcbiAgICAgICAgbW9kYWw6IHVzZU1vZGVsUG9wdXAsXG4gICAgICAgIGVDaGlsZDogZVBvcHVwR3VpLFxuICAgICAgICBjbG9zZU9uRXNjOiB0cnVlLFxuICAgICAgICBjbG9zZWRDYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgIGNlbGxDdHJsLm9uUG9wdXBFZGl0b3JDbG9zZWQoKTtcbiAgICAgICAgfSxcbiAgICAgICAgYW5jaG9yVG9FbGVtZW50OiBlUGFyZW50Q2VsbCxcbiAgICAgICAgcG9zaXRpb25DYWxsYmFjayxcbiAgICAgICAgYXJpYU93bnM6IGVQYXJlbnRDZWxsXG4gICAgICB9KTtcbiAgICAgIGhpZGVFZGl0b3JQb3B1cCA9IGFkZFBvcHVwUmVzID8gYWRkUG9wdXBSZXMuaGlkZUZ1bmMgOiB2b2lkIDA7XG4gICAgICBzZXRQb3B1cEVkaXRvcldyYXBwZXIod3JhcHBlcik7XG4gICAgICBwcm9wcy5qc0NoaWxkQ29tcD8uYWZ0ZXJHdWlBdHRhY2hlZD8uKCk7XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBoaWRlRWRpdG9yUG9wdXA/LigpO1xuICAgICAgY29udGV4dC5kZXN0cm95QmVhbih3cmFwcGVyKTtcbiAgICB9O1xuICB9KTtcbiAgdXNlTGF5b3V0RWZmZWN0NSgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChjZWxsQ3RybC5pc0NlbGxGb2N1c2VkKCkgJiYgcG9wdXBFZGl0b3JXcmFwcGVyPy5nZXRHdWkoKS5jb250YWlucyhfZ2V0QWN0aXZlRG9tRWxlbWVudChiZWFucykpKSB7XG4gICAgICAgIGVQYXJlbnRDZWxsLmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbcG9wdXBFZGl0b3JXcmFwcGVyXSk7XG4gIHJldHVybiBwb3B1cEVkaXRvcldyYXBwZXIgJiYgcHJvcHMud3JhcHBlZENvbnRlbnQgPyBjcmVhdGVQb3J0YWwyKHByb3BzLndyYXBwZWRDb250ZW50LCBwb3B1cEVkaXRvcldyYXBwZXIuZ2V0R3VpKCkpIDogbnVsbDtcbn07XG52YXIgcG9wdXBFZGl0b3JDb21wX2RlZmF1bHQgPSBtZW1vOChQb3B1cEVkaXRvckNvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2NlbGxzL2NlbGxFZGl0b3JDb21wLnRzeFxudmFyIGpzeEVkaXRvclByb3h5ID0gKGVkaXREZXRhaWxzLCBDZWxsRWRpdG9yQ2xhc3MsIHNldFJlZjIpID0+IHtcbiAgY29uc3QgeyBjb21wUHJveHkgfSA9IGVkaXREZXRhaWxzO1xuICBzZXRSZWYyKGNvbXBQcm94eSk7XG4gIGNvbnN0IHByb3BzID0gY29tcFByb3h5LmdldFByb3BzKCk7XG4gIGNvbnN0IGlzU3RhdGVsZXNzID0gaXNDb21wb25lbnRTdGF0ZWxlc3MoQ2VsbEVkaXRvckNsYXNzKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDExLmNyZWF0ZUVsZW1lbnQoXG4gICAgQ3VzdG9tQ29udGV4dC5Qcm92aWRlcixcbiAgICB7XG4gICAgICB2YWx1ZToge1xuICAgICAgICBzZXRNZXRob2RzOiAobWV0aG9kcykgPT4gY29tcFByb3h5LnNldE1ldGhvZHMobWV0aG9kcylcbiAgICAgIH1cbiAgICB9LFxuICAgIGlzU3RhdGVsZXNzID8gLyogQF9fUFVSRV9fICovIFJlYWN0MTEuY3JlYXRlRWxlbWVudChDZWxsRWRpdG9yQ2xhc3MsIHsgLi4ucHJvcHMgfSkgOiAvKiBAX19QVVJFX18gKi8gUmVhY3QxMS5jcmVhdGVFbGVtZW50KENlbGxFZGl0b3JDbGFzcywgeyAuLi5wcm9wcywgcmVmOiAocmVmKSA9PiBjb21wUHJveHkuc2V0UmVmKHJlZikgfSlcbiAgKTtcbn07XG52YXIganN4RWRpdG9yID0gKGVkaXREZXRhaWxzLCBDZWxsRWRpdG9yQ2xhc3MsIHNldFJlZjIpID0+IHtcbiAgY29uc3QgbmV3Rm9ybWF0ID0gZWRpdERldGFpbHMuY29tcFByb3h5O1xuICByZXR1cm4gbmV3Rm9ybWF0ID8ganN4RWRpdG9yUHJveHkoZWRpdERldGFpbHMsIENlbGxFZGl0b3JDbGFzcywgc2V0UmVmMikgOiAvKiBAX19QVVJFX18gKi8gUmVhY3QxMS5jcmVhdGVFbGVtZW50KENlbGxFZGl0b3JDbGFzcywgeyAuLi5lZGl0RGV0YWlscy5jb21wRGV0YWlscy5wYXJhbXMsIHJlZjogc2V0UmVmMiB9KTtcbn07XG52YXIganN4RWRpdFZhbHVlID0gKGVkaXREZXRhaWxzLCBzZXRDZWxsRWRpdG9yUmVmLCBlR3VpLCBjZWxsQ3RybCwganNFZGl0b3JDb21wKSA9PiB7XG4gIGNvbnN0IGNvbXBEZXRhaWxzID0gZWRpdERldGFpbHMuY29tcERldGFpbHM7XG4gIGNvbnN0IENlbGxFZGl0b3JDbGFzcyA9IGNvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzO1xuICBjb25zdCByZWFjdElubGluZUVkaXRvciA9IGNvbXBEZXRhaWxzLmNvbXBvbmVudEZyb21GcmFtZXdvcmsgJiYgIWVkaXREZXRhaWxzLnBvcHVwO1xuICBjb25zdCByZWFjdFBvcHVwRWRpdG9yID0gY29tcERldGFpbHMuY29tcG9uZW50RnJvbUZyYW1ld29yayAmJiBlZGl0RGV0YWlscy5wb3B1cDtcbiAgY29uc3QganNQb3B1cEVkaXRvciA9ICFjb21wRGV0YWlscy5jb21wb25lbnRGcm9tRnJhbWV3b3JrICYmIGVkaXREZXRhaWxzLnBvcHVwO1xuICByZXR1cm4gcmVhY3RJbmxpbmVFZGl0b3IgPyBqc3hFZGl0b3IoZWRpdERldGFpbHMsIENlbGxFZGl0b3JDbGFzcywgc2V0Q2VsbEVkaXRvclJlZikgOiByZWFjdFBvcHVwRWRpdG9yID8gLyogQF9fUFVSRV9fICovIFJlYWN0MTEuY3JlYXRlRWxlbWVudChcbiAgICBwb3B1cEVkaXRvckNvbXBfZGVmYXVsdCxcbiAgICB7XG4gICAgICBlZGl0RGV0YWlscyxcbiAgICAgIGNlbGxDdHJsLFxuICAgICAgZVBhcmVudENlbGw6IGVHdWksXG4gICAgICB3cmFwcGVkQ29udGVudDoganN4RWRpdG9yKGVkaXREZXRhaWxzLCBDZWxsRWRpdG9yQ2xhc3MsIHNldENlbGxFZGl0b3JSZWYpXG4gICAgfVxuICApIDoganNQb3B1cEVkaXRvciAmJiBqc0VkaXRvckNvbXAgPyAvKiBAX19QVVJFX18gKi8gUmVhY3QxMS5jcmVhdGVFbGVtZW50KHBvcHVwRWRpdG9yQ29tcF9kZWZhdWx0LCB7IGVkaXREZXRhaWxzLCBjZWxsQ3RybCwgZVBhcmVudENlbGw6IGVHdWksIGpzQ2hpbGRDb21wOiBqc0VkaXRvckNvbXAgfSkgOiBudWxsO1xufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9jZWxscy9zaG93SnNSZW5kZXJlci50c3hcbmltcG9ydCB7IHVzZUNhbGxiYWNrIGFzIHVzZUNhbGxiYWNrOCwgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0OSwgdXNlRWZmZWN0IGFzIHVzZUVmZmVjdDcgfSBmcm9tIFwicmVhY3RcIjtcbnZhciB1c2VKc0NlbGxSZW5kZXJlciA9IChzaG93RGV0YWlscywgc2hvd1Rvb2xzLCBlQ2VsbFZhbHVlLCBjZWxsVmFsdWVWZXJzaW9uLCBqc0NlbGxSZW5kZXJlclJlZiwgZUd1aSkgPT4ge1xuICBjb25zdCB7IGNvbnRleHQgfSA9IHVzZUNvbnRleHQ5KEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IGRlc3Ryb3lDZWxsUmVuZGVyZXIgPSB1c2VDYWxsYmFjazgoKCkgPT4ge1xuICAgIGNvbnN0IGNvbXAgPSBqc0NlbGxSZW5kZXJlclJlZi5jdXJyZW50O1xuICAgIGlmICghY29tcCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb21wR3VpID0gY29tcC5nZXRHdWkoKTtcbiAgICBpZiAoY29tcEd1aSAmJiBjb21wR3VpLnBhcmVudEVsZW1lbnQpIHtcbiAgICAgIGNvbXBHdWkucmVtb3ZlKCk7XG4gICAgfVxuICAgIGNvbnRleHQuZGVzdHJveUJlYW4oY29tcCk7XG4gICAganNDZWxsUmVuZGVyZXJSZWYuY3VycmVudCA9IHZvaWQgMDtcbiAgfSwgW10pO1xuICB1c2VFZmZlY3Q3KCgpID0+IHtcbiAgICBjb25zdCBzaG93VmFsdWUgPSBzaG93RGV0YWlscyAhPSBudWxsO1xuICAgIGNvbnN0IGpzQ29tcERldGFpbHMgPSBzaG93RGV0YWlscz8uY29tcERldGFpbHMgJiYgIXNob3dEZXRhaWxzLmNvbXBEZXRhaWxzLmNvbXBvbmVudEZyb21GcmFtZXdvcms7XG4gICAgY29uc3Qgd2FpdGluZ0ZvclRvb2xzU2V0dXAgPSBzaG93VG9vbHMgJiYgZUNlbGxWYWx1ZSA9PSBudWxsO1xuICAgIGNvbnN0IHNob3dDb21wID0gc2hvd1ZhbHVlICYmIGpzQ29tcERldGFpbHMgJiYgIXdhaXRpbmdGb3JUb29sc1NldHVwO1xuICAgIGlmICghc2hvd0NvbXApIHtcbiAgICAgIGRlc3Ryb3lDZWxsUmVuZGVyZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY29tcERldGFpbHMgPSBzaG93RGV0YWlscy5jb21wRGV0YWlscztcbiAgICBpZiAoanNDZWxsUmVuZGVyZXJSZWYuY3VycmVudCkge1xuICAgICAgY29uc3QgY29tcCA9IGpzQ2VsbFJlbmRlcmVyUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCBhdHRlbXB0UmVmcmVzaCA9IGNvbXAucmVmcmVzaCAhPSBudWxsICYmIHNob3dEZXRhaWxzLmZvcmNlID09IGZhbHNlO1xuICAgICAgY29uc3QgcmVmcmVzaFJlc3VsdCA9IGF0dGVtcHRSZWZyZXNoID8gY29tcC5yZWZyZXNoKGNvbXBEZXRhaWxzLnBhcmFtcykgOiBmYWxzZTtcbiAgICAgIGNvbnN0IHJlZnJlc2hXb3JrZWQgPSByZWZyZXNoUmVzdWx0ID09PSB0cnVlIHx8IHJlZnJlc2hSZXN1bHQgPT09IHZvaWQgMDtcbiAgICAgIGlmIChyZWZyZXNoV29ya2VkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGRlc3Ryb3lDZWxsUmVuZGVyZXIoKTtcbiAgICB9XG4gICAgY29uc3QgcHJvbWlzZSA9IGNvbXBEZXRhaWxzLm5ld0FnU3RhY2tJbnN0YW5jZSgpO1xuICAgIHByb21pc2UudGhlbigoY29tcCkgPT4ge1xuICAgICAgaWYgKCFjb21wKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvbXBHdWkgPSBjb21wLmdldEd1aSgpO1xuICAgICAgaWYgKCFjb21wR3VpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHBhcmVudCA9IHNob3dUb29scyA/IGVDZWxsVmFsdWUgOiBlR3VpLmN1cnJlbnQ7XG4gICAgICBwYXJlbnQuYXBwZW5kQ2hpbGQoY29tcEd1aSk7XG4gICAgICBqc0NlbGxSZW5kZXJlclJlZi5jdXJyZW50ID0gY29tcDtcbiAgICB9KTtcbiAgfSwgW3Nob3dEZXRhaWxzLCBzaG93VG9vbHMsIGNlbGxWYWx1ZVZlcnNpb25dKTtcbiAgdXNlRWZmZWN0NygoKSA9PiB7XG4gICAgcmV0dXJuIGRlc3Ryb3lDZWxsUmVuZGVyZXI7XG4gIH0sIFtdKTtcbn07XG52YXIgc2hvd0pzUmVuZGVyZXJfZGVmYXVsdCA9IHVzZUpzQ2VsbFJlbmRlcmVyO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2NlbGxzL3NrZWxldG9uQ2VsbENvbXAudHN4XG5pbXBvcnQgUmVhY3QxMiwgeyB1c2VNZW1vIGFzIHVzZU1lbW83LCB1c2VSZWYgYXMgdXNlUmVmOSB9IGZyb20gXCJyZWFjdFwiO1xudmFyIFNrZWxldG9uQ2VsbFJlbmRlcmVyID0gKHtcbiAgY2VsbEN0cmwsXG4gIHBhcmVudFxufSkgPT4ge1xuICBjb25zdCBqc0NlbGxSZW5kZXJlclJlZiA9IHVzZVJlZjkoKTtcbiAgY29uc3QgcmVuZGVyRGV0YWlscyA9IHVzZU1lbW83KCgpID0+IHtcbiAgICBjb25zdCB7IGxvYWRpbmdDb21wIH0gPSBjZWxsQ3RybC5nZXREZWZlckxvYWRpbmdDZWxsUmVuZGVyZXIoKTtcbiAgICByZXR1cm4gbG9hZGluZ0NvbXAgPyB7XG4gICAgICB2YWx1ZTogdm9pZCAwLFxuICAgICAgY29tcERldGFpbHM6IGxvYWRpbmdDb21wLFxuICAgICAgZm9yY2U6IGZhbHNlXG4gICAgfSA6IHZvaWQgMDtcbiAgfSwgW2NlbGxDdHJsXSk7XG4gIHNob3dKc1JlbmRlcmVyX2RlZmF1bHQocmVuZGVyRGV0YWlscywgZmFsc2UsIHZvaWQgMCwgMSwganNDZWxsUmVuZGVyZXJSZWYsIHBhcmVudCk7XG4gIGlmIChyZW5kZXJEZXRhaWxzPy5jb21wRGV0YWlscz8uY29tcG9uZW50RnJvbUZyYW1ld29yaykge1xuICAgIGNvbnN0IENlbGxSZW5kZXJlckNsYXNzID0gcmVuZGVyRGV0YWlscy5jb21wRGV0YWlscy5jb21wb25lbnRDbGFzcztcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTIuY3JlYXRlRWxlbWVudChDZWxsUmVuZGVyZXJDbGFzcywgeyAuLi5yZW5kZXJEZXRhaWxzLmNvbXBEZXRhaWxzLnBhcmFtcyB9KTtcbiAgfVxuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTIuY3JlYXRlRWxlbWVudChSZWFjdDEyLkZyYWdtZW50LCBudWxsKTtcbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvY2VsbHMvY2VsbENvbXAudHN4XG52YXIgQ2VsbENvbXAgPSAoe1xuICBjZWxsQ3RybCxcbiAgcHJpbnRMYXlvdXQsXG4gIGVkaXRpbmdDZWxsXG59KSA9PiB7XG4gIGNvbnN0IGJlYW5zID0gdXNlQ29udGV4dDEwKEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IHsgY29udGV4dCB9ID0gYmVhbnM7XG4gIGNvbnN0IHtcbiAgICBjb2x1bW46IHsgY29sSWRTYW5pdGlzZWQgfSxcbiAgICBpbnN0YW5jZUlkXG4gIH0gPSBjZWxsQ3RybDtcbiAgY29uc3QgY29tcEJlYW4gPSB1c2VSZWYxMCgpO1xuICBjb25zdCBbcmVuZGVyRGV0YWlscywgc2V0UmVuZGVyRGV0YWlsc10gPSB1c2VTdGF0ZTExKFxuICAgICgpID0+IGNlbGxDdHJsLmlzQ2VsbFJlbmRlcmVyKCkgPyB2b2lkIDAgOiB7IGNvbXBEZXRhaWxzOiB2b2lkIDAsIHZhbHVlOiBjZWxsQ3RybC5nZXRWYWx1ZVRvRGlzcGxheSgpLCBmb3JjZTogZmFsc2UgfVxuICApO1xuICBjb25zdCBbZWRpdERldGFpbHMsIHNldEVkaXREZXRhaWxzXSA9IHVzZVN0YXRlMTEoKTtcbiAgY29uc3QgW3JlbmRlcktleSwgc2V0UmVuZGVyS2V5XSA9IHVzZVN0YXRlMTEoMSk7XG4gIGNvbnN0IFt1c2VyU3R5bGVzLCBzZXRVc2VyU3R5bGVzXSA9IHVzZVN0YXRlMTEoKTtcbiAgY29uc3QgW2luY2x1ZGVTZWxlY3Rpb24sIHNldEluY2x1ZGVTZWxlY3Rpb25dID0gdXNlU3RhdGUxMShmYWxzZSk7XG4gIGNvbnN0IFtpbmNsdWRlUm93RHJhZywgc2V0SW5jbHVkZVJvd0RyYWddID0gdXNlU3RhdGUxMShmYWxzZSk7XG4gIGNvbnN0IFtpbmNsdWRlRG5kU291cmNlLCBzZXRJbmNsdWRlRG5kU291cmNlXSA9IHVzZVN0YXRlMTEoZmFsc2UpO1xuICBjb25zdCBbanNFZGl0b3JDb21wLCBzZXRKc0VkaXRvckNvbXBdID0gdXNlU3RhdGUxMSgpO1xuICBjb25zdCBmb3JjZVdyYXBwZXIgPSB1c2VNZW1vOCgoKSA9PiBjZWxsQ3RybC5pc0ZvcmNlV3JhcHBlcigpLCBbY2VsbEN0cmxdKTtcbiAgY29uc3QgY2VsbEFyaWFSb2xlID0gdXNlTWVtbzgoKCkgPT4gY2VsbEN0cmwuZ2V0Q2VsbEFyaWFSb2xlKCksIFtjZWxsQ3RybF0pO1xuICBjb25zdCBlR3VpID0gdXNlUmVmMTAobnVsbCk7XG4gIGNvbnN0IGVXcmFwcGVyID0gdXNlUmVmMTAobnVsbCk7XG4gIGNvbnN0IGNlbGxSZW5kZXJlclJlZiA9IHVzZVJlZjEwKG51bGwpO1xuICBjb25zdCBqc0NlbGxSZW5kZXJlclJlZiA9IHVzZVJlZjEwKCk7XG4gIGNvbnN0IGNlbGxFZGl0b3JSZWYgPSB1c2VSZWYxMCgpO1xuICBjb25zdCBlQ2VsbFdyYXBwZXIgPSB1c2VSZWYxMCgpO1xuICBjb25zdCBjZWxsV3JhcHBlckRlc3Ryb3lGdW5jcyA9IHVzZVJlZjEwKFtdKTtcbiAgY29uc3Qgcm93RHJhZ0NvbXBSZWYgPSB1c2VSZWYxMCgpO1xuICBjb25zdCBlQ2VsbFZhbHVlID0gdXNlUmVmMTAoKTtcbiAgY29uc3QgW2NlbGxWYWx1ZVZlcnNpb24sIHNldENlbGxWYWx1ZVZlcnNpb25dID0gdXNlU3RhdGUxMSgwKTtcbiAgY29uc3Qgc2V0Q2VsbFZhbHVlUmVmID0gdXNlQ2FsbGJhY2s5KChyZWYpID0+IHtcbiAgICBlQ2VsbFZhbHVlLmN1cnJlbnQgPSByZWY7XG4gICAgc2V0Q2VsbFZhbHVlVmVyc2lvbigodikgPT4gdiArIDEpO1xuICB9LCBbXSk7XG4gIGNvbnN0IHNob3dUb29scyA9IHJlbmRlckRldGFpbHMgIT0gbnVsbCAmJiAoaW5jbHVkZVNlbGVjdGlvbiB8fCBpbmNsdWRlRG5kU291cmNlIHx8IGluY2x1ZGVSb3dEcmFnKSAmJiAoZWRpdERldGFpbHMgPT0gbnVsbCB8fCAhIWVkaXREZXRhaWxzLnBvcHVwKTtcbiAgY29uc3Qgc2hvd0NlbGxXcmFwcGVyID0gZm9yY2VXcmFwcGVyIHx8IHNob3dUb29scztcbiAgY29uc3QgY2VsbFZhbHVlQ2xhc3MgPSB1c2VNZW1vOCgoKSA9PiB7XG4gICAgcmV0dXJuIGNlbGxDdHJsLmdldENlbGxWYWx1ZUNsYXNzKCk7XG4gIH0sIFtjZWxsQ3RybF0pO1xuICBjb25zdCBzZXRDZWxsRWRpdG9yUmVmID0gdXNlQ2FsbGJhY2s5KFxuICAgIChjZWxsRWRpdG9yKSA9PiB7XG4gICAgICBjZWxsRWRpdG9yUmVmLmN1cnJlbnQgPSBjZWxsRWRpdG9yO1xuICAgICAgaWYgKGNlbGxFZGl0b3IpIHtcbiAgICAgICAgY29uc3QgZWRpdGluZ0NhbmNlbGxlZEJ5VXNlckNvbXAgPSBjZWxsRWRpdG9yLmlzQ2FuY2VsQmVmb3JlU3RhcnQgJiYgY2VsbEVkaXRvci5pc0NhbmNlbEJlZm9yZVN0YXJ0KCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlmIChlZGl0aW5nQ2FuY2VsbGVkQnlVc2VyQ29tcCkge1xuICAgICAgICAgICAgY2VsbEN0cmwuc3RvcEVkaXRpbmcodHJ1ZSk7XG4gICAgICAgICAgICBjZWxsQ3RybC5mb2N1c0NlbGwodHJ1ZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNlbGxDdHJsLmNlbGxFZGl0b3JBdHRhY2hlZCgpO1xuICAgICAgICAgICAgY2VsbEN0cmwuZW5hYmxlRWRpdG9yVG9vbHRpcEZlYXR1cmUoY2VsbEVkaXRvcik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtjZWxsQ3RybF1cbiAgKTtcbiAgY29uc3QgY3NzTWFuYWdlciA9IHVzZVJlZjEwKCk7XG4gIGlmICghY3NzTWFuYWdlci5jdXJyZW50KSB7XG4gICAgY3NzTWFuYWdlci5jdXJyZW50ID0gbmV3IENzc0NsYXNzTWFuYWdlcjIoKCkgPT4gZUd1aS5jdXJyZW50KTtcbiAgfVxuICBzaG93SnNSZW5kZXJlcl9kZWZhdWx0KHJlbmRlckRldGFpbHMsIHNob3dDZWxsV3JhcHBlciwgZUNlbGxWYWx1ZS5jdXJyZW50LCBjZWxsVmFsdWVWZXJzaW9uLCBqc0NlbGxSZW5kZXJlclJlZiwgZUd1aSk7XG4gIGNvbnN0IGxhc3RSZW5kZXJEZXRhaWxzID0gdXNlUmVmMTAoKTtcbiAgdXNlTGF5b3V0RWZmZWN0NigoKSA9PiB7XG4gICAgY29uc3Qgb2xkRGV0YWlscyA9IGxhc3RSZW5kZXJEZXRhaWxzLmN1cnJlbnQ7XG4gICAgY29uc3QgbmV3RGV0YWlscyA9IHJlbmRlckRldGFpbHM7XG4gICAgbGFzdFJlbmRlckRldGFpbHMuY3VycmVudCA9IHJlbmRlckRldGFpbHM7XG4gICAgaWYgKG9sZERldGFpbHMgPT0gbnVsbCB8fCBvbGREZXRhaWxzLmNvbXBEZXRhaWxzID09IG51bGwgfHwgbmV3RGV0YWlscyA9PSBudWxsIHx8IG5ld0RldGFpbHMuY29tcERldGFpbHMgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByb3dEcmFnQ29tcFJlZi5jdXJyZW50Py5yZWZyZXNoVmlzaWJpbGl0eSgpO1xuICAgIGNvbnN0IG9sZENvbXBEZXRhaWxzID0gb2xkRGV0YWlscy5jb21wRGV0YWlscztcbiAgICBjb25zdCBuZXdDb21wRGV0YWlscyA9IG5ld0RldGFpbHMuY29tcERldGFpbHM7XG4gICAgaWYgKG9sZENvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzICE9IG5ld0NvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChjZWxsUmVuZGVyZXJSZWYuY3VycmVudD8ucmVmcmVzaCA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IGNlbGxSZW5kZXJlclJlZi5jdXJyZW50LnJlZnJlc2gobmV3Q29tcERldGFpbHMucGFyYW1zKTtcbiAgICBpZiAocmVzdWx0ICE9IHRydWUpIHtcbiAgICAgIHNldFJlbmRlcktleSgocHJldikgPT4gcHJldiArIDEpO1xuICAgIH1cbiAgfSwgW3JlbmRlckRldGFpbHNdKTtcbiAgdXNlTGF5b3V0RWZmZWN0NigoKSA9PiB7XG4gICAgY29uc3QgZG9pbmdKc0VkaXRvciA9IGVkaXREZXRhaWxzICYmICFlZGl0RGV0YWlscy5jb21wRGV0YWlscy5jb21wb25lbnRGcm9tRnJhbWV3b3JrO1xuICAgIGlmICghZG9pbmdKc0VkaXRvciB8fCBjb250ZXh0LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY29tcERldGFpbHMgPSBlZGl0RGV0YWlscy5jb21wRGV0YWlscztcbiAgICBjb25zdCBpc1BvcHVwID0gZWRpdERldGFpbHMucG9wdXAgPT09IHRydWU7XG4gICAgY29uc3QgY2VsbEVkaXRvclByb21pc2UgPSBjb21wRGV0YWlscy5uZXdBZ1N0YWNrSW5zdGFuY2UoKTtcbiAgICBjZWxsRWRpdG9yUHJvbWlzZS50aGVuKChjZWxsRWRpdG9yKSA9PiB7XG4gICAgICBpZiAoIWNlbGxFZGl0b3IpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgY29tcEd1aSA9IGNlbGxFZGl0b3IuZ2V0R3VpKCk7XG4gICAgICBzZXRDZWxsRWRpdG9yUmVmKGNlbGxFZGl0b3IpO1xuICAgICAgaWYgKCFpc1BvcHVwKSB7XG4gICAgICAgIGNvbnN0IHBhcmVudEVsID0gKGZvcmNlV3JhcHBlciA/IGVDZWxsV3JhcHBlciA6IGVHdWkpLmN1cnJlbnQ7XG4gICAgICAgIHBhcmVudEVsPy5hcHBlbmRDaGlsZChjb21wR3VpKTtcbiAgICAgICAgY2VsbEVkaXRvci5hZnRlckd1aUF0dGFjaGVkPy4oKTtcbiAgICAgIH1cbiAgICAgIHNldEpzRWRpdG9yQ29tcChjZWxsRWRpdG9yKTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2VsbEVkaXRvclByb21pc2UudGhlbigoY2VsbEVkaXRvcikgPT4ge1xuICAgICAgICBjb25zdCBjb21wR3VpID0gY2VsbEVkaXRvci5nZXRHdWkoKTtcbiAgICAgICAgY2VsbEN0cmwuZGlzYWJsZUVkaXRvclRvb2x0aXBGZWF0dXJlKCk7XG4gICAgICAgIGNvbnRleHQuZGVzdHJveUJlYW4oY2VsbEVkaXRvcik7XG4gICAgICAgIHNldENlbGxFZGl0b3JSZWYodm9pZCAwKTtcbiAgICAgICAgc2V0SnNFZGl0b3JDb21wKHZvaWQgMCk7XG4gICAgICAgIGNvbXBHdWk/LnJlbW92ZSgpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgfSwgW2VkaXREZXRhaWxzXSk7XG4gIGNvbnN0IHNldENlbGxXcmFwcGVyUmVmID0gdXNlQ2FsbGJhY2s5KFxuICAgIChlUmVmKSA9PiB7XG4gICAgICBlQ2VsbFdyYXBwZXIuY3VycmVudCA9IGVSZWY7XG4gICAgICBpZiAoIWVSZWYgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpIHx8ICFjZWxsQ3RybC5pc0FsaXZlKCkpIHtcbiAgICAgICAgY29uc3QgY2FsbGJhY2tzID0gY2VsbFdyYXBwZXJEZXN0cm95RnVuY3MuY3VycmVudDtcbiAgICAgICAgY2VsbFdyYXBwZXJEZXN0cm95RnVuY3MuY3VycmVudCA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGNiIG9mIGNhbGxiYWNrcykge1xuICAgICAgICAgIGNiKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IHJvd0RyYWdDb21wO1xuICAgICAgY29uc3QgYWRkQ29tcCA9IChjb21wKSA9PiB7XG4gICAgICAgIGlmIChjb21wKSB7XG4gICAgICAgICAgZVJlZi5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJhZnRlcmJlZ2luXCIsIGNvbXAuZ2V0R3VpKCkpO1xuICAgICAgICAgIGNlbGxXcmFwcGVyRGVzdHJveUZ1bmNzLmN1cnJlbnQucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICBfcmVtb3ZlRnJvbVBhcmVudChjb21wLmdldEd1aSgpKTtcbiAgICAgICAgICAgIGNvbnRleHQuZGVzdHJveUJlYW4oY29tcCk7XG4gICAgICAgICAgICBpZiAocm93RHJhZ0NvbXBSZWYuY3VycmVudCA9PT0gcm93RHJhZ0NvbXApIHtcbiAgICAgICAgICAgICAgcm93RHJhZ0NvbXBSZWYuY3VycmVudCA9IHZvaWQgMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGlmIChpbmNsdWRlU2VsZWN0aW9uKSB7XG4gICAgICAgIGFkZENvbXAoY2VsbEN0cmwuY3JlYXRlU2VsZWN0aW9uQ2hlY2tib3goKSk7XG4gICAgICB9XG4gICAgICBpZiAoaW5jbHVkZURuZFNvdXJjZSkge1xuICAgICAgICBhZGRDb21wKGNlbGxDdHJsLmNyZWF0ZURuZFNvdXJjZSgpKTtcbiAgICAgIH1cbiAgICAgIGlmIChpbmNsdWRlUm93RHJhZykge1xuICAgICAgICByb3dEcmFnQ29tcCA9IGNlbGxDdHJsLmNyZWF0ZVJvd0RyYWdDb21wKCk7XG4gICAgICAgIHJvd0RyYWdDb21wUmVmLmN1cnJlbnQgPSByb3dEcmFnQ29tcDtcbiAgICAgICAgaWYgKHJvd0RyYWdDb21wKSB7XG4gICAgICAgICAgYWRkQ29tcChyb3dEcmFnQ29tcCk7XG4gICAgICAgICAgcm93RHJhZ0NvbXAucmVmcmVzaFZpc2liaWxpdHkoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgW2NlbGxDdHJsLCBjb250ZXh0LCBpbmNsdWRlRG5kU291cmNlLCBpbmNsdWRlUm93RHJhZywgaW5jbHVkZVNlbGVjdGlvbl1cbiAgKTtcbiAgY29uc3QgaW5pdCA9IHVzZUNhbGxiYWNrOSgoKSA9PiB7XG4gICAgY29uc3Qgc3BhblJlYWR5ID0gIWNlbGxDdHJsLmlzQ2VsbFNwYW5uaW5nKCkgfHwgZVdyYXBwZXIuY3VycmVudDtcbiAgICBjb25zdCBlUmVmID0gZUd1aS5jdXJyZW50O1xuICAgIGlmICghZVJlZiB8fCAhc3BhblJlYWR5IHx8ICFjZWxsQ3RybCB8fCAhY2VsbEN0cmwuaXNBbGl2ZSgpIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgY29tcEJlYW4uY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4oY29tcEJlYW4uY3VycmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbXBCZWFuLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IF9FbXB0eUJlYW41KCkpO1xuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBjc3NNYW5hZ2VyLmN1cnJlbnQudG9nZ2xlQ3NzKG5hbWUsIG9uKSxcbiAgICAgIHNldFVzZXJTdHlsZXM6IChzdHlsZXMpID0+IHNldFVzZXJTdHlsZXMoc3R5bGVzKSxcbiAgICAgIGdldEZvY3VzYWJsZUVsZW1lbnQ6ICgpID0+IGVHdWkuY3VycmVudCxcbiAgICAgIHNldEluY2x1ZGVTZWxlY3Rpb246IChpbmNsdWRlKSA9PiBzZXRJbmNsdWRlU2VsZWN0aW9uKGluY2x1ZGUpLFxuICAgICAgc2V0SW5jbHVkZVJvd0RyYWc6IChpbmNsdWRlKSA9PiBzZXRJbmNsdWRlUm93RHJhZyhpbmNsdWRlKSxcbiAgICAgIHNldEluY2x1ZGVEbmRTb3VyY2U6IChpbmNsdWRlKSA9PiBzZXRJbmNsdWRlRG5kU291cmNlKGluY2x1ZGUpLFxuICAgICAgZ2V0Q2VsbEVkaXRvcjogKCkgPT4gY2VsbEVkaXRvclJlZi5jdXJyZW50ID8/IG51bGwsXG4gICAgICBnZXRDZWxsUmVuZGVyZXI6ICgpID0+IGNlbGxSZW5kZXJlclJlZi5jdXJyZW50ID8/IGpzQ2VsbFJlbmRlcmVyUmVmLmN1cnJlbnQsXG4gICAgICBnZXRQYXJlbnRPZlZhbHVlOiAoKSA9PiBlQ2VsbFZhbHVlLmN1cnJlbnQgPz8gZUNlbGxXcmFwcGVyLmN1cnJlbnQgPz8gZUd1aS5jdXJyZW50LFxuICAgICAgc2V0UmVuZGVyRGV0YWlsczogKGNvbXBEZXRhaWxzLCB2YWx1ZSwgZm9yY2UpID0+IHtcbiAgICAgICAgY29uc3Qgc2V0RGV0YWlscyA9ICgpID0+IHtcbiAgICAgICAgICBzZXRSZW5kZXJEZXRhaWxzKChwcmV2KSA9PiB7XG4gICAgICAgICAgICBpZiAocHJldj8uY29tcERldGFpbHMgIT09IGNvbXBEZXRhaWxzIHx8IHByZXY/LnZhbHVlICE9PSB2YWx1ZSB8fCBwcmV2Py5mb3JjZSAhPT0gZm9yY2UpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICAgICAgICBjb21wRGV0YWlscyxcbiAgICAgICAgICAgICAgICBmb3JjZVxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICAgIGlmIChjb21wRGV0YWlscz8ucGFyYW1zPy5kZWZlclJlbmRlciAmJiAhY2VsbEN0cmwucm93Tm9kZS5ncm91cCkge1xuICAgICAgICAgIGNvbnN0IHsgbG9hZGluZ0NvbXAsIG9uUmVhZHkgfSA9IGNlbGxDdHJsLmdldERlZmVyTG9hZGluZ0NlbGxSZW5kZXJlcigpO1xuICAgICAgICAgIGlmIChsb2FkaW5nQ29tcCkge1xuICAgICAgICAgICAgc2V0UmVuZGVyRGV0YWlscyh7XG4gICAgICAgICAgICAgIHZhbHVlOiB2b2lkIDAsXG4gICAgICAgICAgICAgIGNvbXBEZXRhaWxzOiBsb2FkaW5nQ29tcCxcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIG9uUmVhZHkudGhlbigoKSA9PiBhZ1N0YXJ0VHJhbnNpdGlvbihzZXREZXRhaWxzKSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHNldERldGFpbHMoKTtcbiAgICAgIH0sXG4gICAgICBzZXRFZGl0RGV0YWlsczogKGNvbXBEZXRhaWxzLCBwb3B1cCwgcG9wdXBQb3NpdGlvbiwgcmVhY3RpdmVDdXN0b21Db21wb25lbnRzKSA9PiB7XG4gICAgICAgIGlmIChjb21wRGV0YWlscykge1xuICAgICAgICAgIGxldCBjb21wUHJveHkyID0gdm9pZCAwO1xuICAgICAgICAgIGlmIChjb21wRGV0YWlscy5jb21wb25lbnRGcm9tRnJhbWV3b3JrKSB7XG4gICAgICAgICAgICBpZiAocmVhY3RpdmVDdXN0b21Db21wb25lbnRzKSB7XG4gICAgICAgICAgICAgIGNvbXBQcm94eTIgPSBuZXcgQ2VsbEVkaXRvckNvbXBvbmVudFByb3h5KFxuICAgICAgICAgICAgICAgIGNvbXBEZXRhaWxzLnBhcmFtcyxcbiAgICAgICAgICAgICAgICAoKSA9PiBzZXRSZW5kZXJLZXkoKHByZXYpID0+IHByZXYgKyAxKVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgd2FyblJlYWN0aXZlQ3VzdG9tQ29tcG9uZW50cygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBzZXRFZGl0RGV0YWlscyh7XG4gICAgICAgICAgICBjb21wRGV0YWlscyxcbiAgICAgICAgICAgIHBvcHVwLFxuICAgICAgICAgICAgcG9wdXBQb3NpdGlvbixcbiAgICAgICAgICAgIGNvbXBQcm94eTogY29tcFByb3h5MlxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmICghcG9wdXApIHtcbiAgICAgICAgICAgIHNldFJlbmRlckRldGFpbHModm9pZCAwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgcmVjb3ZlckZvY3VzID0gY2VsbEN0cmwuaGFzQnJvd3NlckZvY3VzKCk7XG4gICAgICAgICAgaWYgKHJlY292ZXJGb2N1cykge1xuICAgICAgICAgICAgY29tcFByb3h5LmdldEZvY3VzYWJsZUVsZW1lbnQoKS5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNlbGxFZGl0b3JSZWYuY3VycmVudCA9IHZvaWQgMDtcbiAgICAgICAgICBzZXRFZGl0RGV0YWlscyh2b2lkIDApO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVmcmVzaEVkaXRTdHlsZXM6IChlZGl0aW5nLCBpc1BvcHVwKSA9PiB7XG4gICAgICAgIGlmICghZUd1aS5jdXJyZW50KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgY3VycmVudCB9ID0gY3NzTWFuYWdlcjtcbiAgICAgICAgY3VycmVudC50b2dnbGVDc3MoXCJhZy1jZWxsLXZhbHVlXCIsICFzaG93Q2VsbFdyYXBwZXIpO1xuICAgICAgICBjdXJyZW50LnRvZ2dsZUNzcyhcImFnLWNlbGwtaW5saW5lLWVkaXRpbmdcIiwgISFlZGl0aW5nICYmICFpc1BvcHVwKTtcbiAgICAgICAgY3VycmVudC50b2dnbGVDc3MoXCJhZy1jZWxsLXBvcHVwLWVkaXRpbmdcIiwgISFlZGl0aW5nICYmICEhaXNQb3B1cCk7XG4gICAgICAgIGN1cnJlbnQudG9nZ2xlQ3NzKFwiYWctY2VsbC1ub3QtaW5saW5lLWVkaXRpbmdcIiwgIWVkaXRpbmcgfHwgISFpc1BvcHVwKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGNlbGxXcmFwcGVyT3JVbmRlZmluZWQgPSBlQ2VsbFdyYXBwZXIuY3VycmVudCB8fCB2b2lkIDA7XG4gICAgY2VsbEN0cmwuc2V0Q29tcChcbiAgICAgIGNvbXBQcm94eSxcbiAgICAgIGVSZWYsXG4gICAgICBlV3JhcHBlci5jdXJyZW50ID8/IHZvaWQgMCxcbiAgICAgIGNlbGxXcmFwcGVyT3JVbmRlZmluZWQsXG4gICAgICBwcmludExheW91dCxcbiAgICAgIGVkaXRpbmdDZWxsLFxuICAgICAgY29tcEJlYW4uY3VycmVudFxuICAgICk7XG4gIH0sIFtdKTtcbiAgY29uc3Qgc2V0R3VpUmVmID0gdXNlQ2FsbGJhY2s5KChyZWYpID0+IHtcbiAgICBlR3VpLmN1cnJlbnQgPSByZWY7XG4gICAgaW5pdCgpO1xuICB9LCBbXSk7XG4gIGNvbnN0IHNldFdyYXBwZXJSZWYgPSB1c2VDYWxsYmFjazkoKHJlZikgPT4ge1xuICAgIGVXcmFwcGVyLmN1cnJlbnQgPSByZWY7XG4gICAgaW5pdCgpO1xuICB9LCBbXSk7XG4gIGNvbnN0IHJlYWN0Q2VsbFJlbmRlcmVyU3RhdGVsZXNzID0gdXNlTWVtbzgoKCkgPT4ge1xuICAgIGNvbnN0IHJlcyA9IHJlbmRlckRldGFpbHM/LmNvbXBEZXRhaWxzPy5jb21wb25lbnRGcm9tRnJhbWV3b3JrICYmIGlzQ29tcG9uZW50U3RhdGVsZXNzKHJlbmRlckRldGFpbHMuY29tcERldGFpbHMuY29tcG9uZW50Q2xhc3MpO1xuICAgIHJldHVybiAhIXJlcztcbiAgfSwgW3JlbmRlckRldGFpbHNdKTtcbiAgdXNlTGF5b3V0RWZmZWN0NigoKSA9PiB7XG4gICAgaWYgKCFlR3VpLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgeyBjdXJyZW50IH0gPSBjc3NNYW5hZ2VyO1xuICAgIGN1cnJlbnQudG9nZ2xlQ3NzKFwiYWctY2VsbC12YWx1ZVwiLCAhc2hvd0NlbGxXcmFwcGVyKTtcbiAgICBjdXJyZW50LnRvZ2dsZUNzcyhcImFnLWNlbGwtaW5saW5lLWVkaXRpbmdcIiwgISFlZGl0RGV0YWlscyAmJiAhZWRpdERldGFpbHMucG9wdXApO1xuICAgIGN1cnJlbnQudG9nZ2xlQ3NzKFwiYWctY2VsbC1wb3B1cC1lZGl0aW5nXCIsICEhZWRpdERldGFpbHMgJiYgISFlZGl0RGV0YWlscy5wb3B1cCk7XG4gICAgY3VycmVudC50b2dnbGVDc3MoXCJhZy1jZWxsLW5vdC1pbmxpbmUtZWRpdGluZ1wiLCAhZWRpdERldGFpbHMgfHwgISFlZGl0RGV0YWlscy5wb3B1cCk7XG4gIH0pO1xuICBjb25zdCB2YWx1ZU9yQ2VsbENvbXAgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBjb21wRGV0YWlscywgdmFsdWUgfSA9IHJlbmRlckRldGFpbHM7XG4gICAgaWYgKCFjb21wRGV0YWlscykge1xuICAgICAgcmV0dXJuIHZhbHVlPy50b1N0cmluZz8uKCkgPz8gdmFsdWU7XG4gICAgfVxuICAgIGlmIChjb21wRGV0YWlscy5jb21wb25lbnRGcm9tRnJhbWV3b3JrKSB7XG4gICAgICBjb25zdCBDZWxsUmVuZGVyZXJDbGFzcyA9IGNvbXBEZXRhaWxzLmNvbXBvbmVudENsYXNzO1xuICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoU3VzcGVuc2UsIHsgZmFsbGJhY2s6IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoU2tlbGV0b25DZWxsUmVuZGVyZXIsIHsgY2VsbEN0cmwsIHBhcmVudDogZUd1aSB9KSB9LCByZWFjdENlbGxSZW5kZXJlclN0YXRlbGVzcyA/IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoQ2VsbFJlbmRlcmVyQ2xhc3MsIHsgLi4uY29tcERldGFpbHMucGFyYW1zLCBrZXk6IHJlbmRlcktleSB9KSA6IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoQ2VsbFJlbmRlcmVyQ2xhc3MsIHsgLi4uY29tcERldGFpbHMucGFyYW1zLCBrZXk6IHJlbmRlcktleSwgcmVmOiBjZWxsUmVuZGVyZXJSZWYgfSkpO1xuICAgIH1cbiAgfTtcbiAgY29uc3Qgc2hvd0NlbGxPckVkaXRvciA9ICgpID0+IHtcbiAgICBjb25zdCBzaG93Q2VsbFZhbHVlID0gKCkgPT4ge1xuICAgICAgaWYgKHJlbmRlckRldGFpbHMgPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzaG93Q2VsbFdyYXBwZXIgPyAvKiBAX19QVVJFX18gKi8gUmVhY3QxMy5jcmVhdGVFbGVtZW50KFwic3BhblwiLCB7IHJvbGU6IFwicHJlc2VudGF0aW9uXCIsIGlkOiBgY2VsbC0ke2luc3RhbmNlSWR9YCwgY2xhc3NOYW1lOiBjZWxsVmFsdWVDbGFzcywgcmVmOiBzZXRDZWxsVmFsdWVSZWYgfSwgdmFsdWVPckNlbGxDb21wKCkpIDogdmFsdWVPckNlbGxDb21wKCk7XG4gICAgfTtcbiAgICBjb25zdCBzaG93RWRpdFZhbHVlID0gKGRldGFpbHMpID0+IGpzeEVkaXRWYWx1ZShkZXRhaWxzLCBzZXRDZWxsRWRpdG9yUmVmLCBlR3VpLmN1cnJlbnQsIGNlbGxDdHJsLCBqc0VkaXRvckNvbXApO1xuICAgIGlmIChlZGl0RGV0YWlscyAhPSBudWxsKSB7XG4gICAgICBpZiAoZWRpdERldGFpbHMucG9wdXApIHtcbiAgICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoUmVhY3QxMy5GcmFnbWVudCwgbnVsbCwgc2hvd0NlbGxWYWx1ZSgpLCBzaG93RWRpdFZhbHVlKGVkaXREZXRhaWxzKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gc2hvd0VkaXRWYWx1ZShlZGl0RGV0YWlscyk7XG4gICAgfVxuICAgIHJldHVybiBzaG93Q2VsbFZhbHVlKCk7XG4gIH07XG4gIGNvbnN0IHJlbmRlckNlbGwgPSAoKSA9PiAvKiBAX19QVVJFX18gKi8gUmVhY3QxMy5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHsgcmVmOiBzZXRHdWlSZWYsIHN0eWxlOiB1c2VyU3R5bGVzLCByb2xlOiBjZWxsQXJpYVJvbGUsIFwiY29sLWlkXCI6IGNvbElkU2FuaXRpc2VkIH0sIHNob3dDZWxsV3JhcHBlciA/IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwiYWctY2VsbC13cmFwcGVyXCIsIHJvbGU6IFwicHJlc2VudGF0aW9uXCIsIHJlZjogc2V0Q2VsbFdyYXBwZXJSZWYgfSwgc2hvd0NlbGxPckVkaXRvcigpKSA6IHNob3dDZWxsT3JFZGl0b3IoKSk7XG4gIGlmIChjZWxsQ3RybC5pc0NlbGxTcGFubmluZygpKSB7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDEzLmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IHNldFdyYXBwZXJSZWYsIGNsYXNzTmFtZTogXCJhZy1zcGFubmVkLWNlbGwtd3JhcHBlclwiLCByb2xlOiBcInByZXNlbnRhdGlvblwiIH0sIHJlbmRlckNlbGwoKSk7XG4gIH1cbiAgcmV0dXJuIHJlbmRlckNlbGwoKTtcbn07XG52YXIgY2VsbENvbXBfZGVmYXVsdCA9IG1lbW85KENlbGxDb21wKTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9yb3dzL3Jvd0NvbXAudHN4XG52YXIgUm93Q29tcCA9ICh7IHJvd0N0cmwsIGNvbnRhaW5lclR5cGUgfSkgPT4ge1xuICBjb25zdCB7IGNvbnRleHQsIGdvcywgZWRpdFN2YyB9ID0gdXNlQ29udGV4dDExKEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IGVuYWJsZVVzZXMgPSB1c2VDb250ZXh0MTEoUmVuZGVyTW9kZUNvbnRleHQpID09PSBcImRlZmF1bHRcIjtcbiAgY29uc3QgY29tcEJlYW4gPSB1c2VSZWYxMSgpO1xuICBjb25zdCBkb21PcmRlclJlZiA9IHVzZVJlZjExKHJvd0N0cmwuZ2V0RG9tT3JkZXIoKSk7XG4gIGNvbnN0IGlzRnVsbFdpZHRoID0gcm93Q3RybC5pc0Z1bGxXaWR0aCgpO1xuICBjb25zdCBpc0Rpc3BsYXllZCA9IHJvd0N0cmwucm93Tm9kZS5kaXNwbGF5ZWQ7XG4gIGNvbnN0IFtyb3dJbmRleCwgc2V0Um93SW5kZXhdID0gdXNlU3RhdGUxMihcbiAgICAoKSA9PiBpc0Rpc3BsYXllZCA/IHJvd0N0cmwucm93Tm9kZS5nZXRSb3dJbmRleFN0cmluZygpIDogbnVsbFxuICApO1xuICBjb25zdCBbcm93SWQsIHNldFJvd0lkXSA9IHVzZVN0YXRlMTIoKCkgPT4gcm93Q3RybC5yb3dJZCk7XG4gIGNvbnN0IFtyb3dCdXNpbmVzc0tleSwgc2V0Um93QnVzaW5lc3NLZXldID0gdXNlU3RhdGUxMigoKSA9PiByb3dDdHJsLmJ1c2luZXNzS2V5KTtcbiAgY29uc3QgW3VzZXJTdHlsZXMsIHNldFVzZXJTdHlsZXNdID0gdXNlU3RhdGUxMigoKSA9PiByb3dDdHJsLnJvd1N0eWxlcyk7XG4gIGNvbnN0IGNlbGxDdHJsc1JlZiA9IHVzZVJlZjExKG51bGwpO1xuICBjb25zdCBbY2VsbEN0cmxzRmx1c2hTeW5jLCBzZXRDZWxsQ3RybHNGbHVzaFN5bmNdID0gdXNlU3RhdGUxMigoKSA9PiBudWxsKTtcbiAgY29uc3QgW2Z1bGxXaWR0aENvbXBEZXRhaWxzLCBzZXRGdWxsV2lkdGhDb21wRGV0YWlsc10gPSB1c2VTdGF0ZTEyKCk7XG4gIGNvbnN0IFt0b3AsIHNldFRvcF0gPSB1c2VTdGF0ZTEyKFxuICAgICgpID0+IGlzRGlzcGxheWVkID8gcm93Q3RybC5nZXRJbml0aWFsUm93VG9wKGNvbnRhaW5lclR5cGUpIDogdm9pZCAwXG4gICk7XG4gIGNvbnN0IFt0cmFuc2Zvcm0sIHNldFRyYW5zZm9ybV0gPSB1c2VTdGF0ZTEyKFxuICAgICgpID0+IGlzRGlzcGxheWVkID8gcm93Q3RybC5nZXRJbml0aWFsVHJhbnNmb3JtKGNvbnRhaW5lclR5cGUpIDogdm9pZCAwXG4gICk7XG4gIGNvbnN0IGVHdWkgPSB1c2VSZWYxMShudWxsKTtcbiAgY29uc3QgZnVsbFdpZHRoQ29tcFJlZiA9IHVzZVJlZjExKCk7XG4gIGNvbnN0IGZ1bGxXaWR0aFBhcmFtc1JlZiA9IHVzZVJlZjExKCk7XG4gIGNvbnN0IGF1dG9IZWlnaHRTZXR1cCA9IHVzZVJlZjExKGZhbHNlKTtcbiAgY29uc3QgW2F1dG9IZWlnaHRTZXR1cEF0dGVtcHQsIHNldEF1dG9IZWlnaHRTZXR1cEF0dGVtcHRdID0gdXNlU3RhdGUxMigwKTtcbiAgdXNlRWZmZWN0OCgoKSA9PiB7XG4gICAgaWYgKGF1dG9IZWlnaHRTZXR1cC5jdXJyZW50IHx8ICFmdWxsV2lkdGhDb21wRGV0YWlscyB8fCBhdXRvSGVpZ2h0U2V0dXBBdHRlbXB0ID4gMTApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZUNoaWxkID0gZUd1aS5jdXJyZW50Py5maXJzdENoaWxkO1xuICAgIGlmIChlQ2hpbGQpIHtcbiAgICAgIHJvd0N0cmwuc2V0dXBEZXRhaWxSb3dBdXRvSGVpZ2h0KGVDaGlsZCk7XG4gICAgICBhdXRvSGVpZ2h0U2V0dXAuY3VycmVudCA9IHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEF1dG9IZWlnaHRTZXR1cEF0dGVtcHQoKHByZXYpID0+IHByZXYgKyAxKTtcbiAgICB9XG4gIH0sIFtmdWxsV2lkdGhDb21wRGV0YWlscywgYXV0b0hlaWdodFNldHVwQXR0ZW1wdF0pO1xuICBjb25zdCBjc3NNYW5hZ2VyID0gdXNlUmVmMTEoKTtcbiAgaWYgKCFjc3NNYW5hZ2VyLmN1cnJlbnQpIHtcbiAgICBjc3NNYW5hZ2VyLmN1cnJlbnQgPSBuZXcgQ3NzQ2xhc3NNYW5hZ2VyMygoKSA9PiBlR3VpLmN1cnJlbnQpO1xuICB9XG4gIGNvbnN0IGNlbGxzQ2hhbmdlZCA9IHVzZVJlZjExKCgpID0+IHtcbiAgfSk7XG4gIGNvbnN0IHN1YiA9IHVzZUNhbGxiYWNrMTAoKG9uU3RvcmVDaGFuZ2UpID0+IHtcbiAgICBjZWxsc0NoYW5nZWQuY3VycmVudCA9IG9uU3RvcmVDaGFuZ2U7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNlbGxzQ2hhbmdlZC5jdXJyZW50ID0gKCkgPT4ge1xuICAgICAgfTtcbiAgICB9O1xuICB9LCBbXSk7XG4gIGNvbnN0IGNlbGxDdHJsc1VzZXMgPSBhZ1VzZVN5bmNFeHRlcm5hbFN0b3JlKFxuICAgIHN1YixcbiAgICAoKSA9PiB7XG4gICAgICByZXR1cm4gY2VsbEN0cmxzUmVmLmN1cnJlbnQ7XG4gICAgfSxcbiAgICBbXVxuICApO1xuICBjb25zdCBjZWxsQ3RybHNNZXJnZWQgPSBlbmFibGVVc2VzID8gY2VsbEN0cmxzVXNlcyA6IGNlbGxDdHJsc0ZsdXNoU3luYztcbiAgY29uc3Qgc2V0UmVmMiA9IHVzZUNhbGxiYWNrMTAoKGVSZWYpID0+IHtcbiAgICBlR3VpLmN1cnJlbnQgPSBlUmVmO1xuICAgIGNvbXBCZWFuLmN1cnJlbnQgPSBlUmVmID8gY29udGV4dC5jcmVhdGVCZWFuKG5ldyBfRW1wdHlCZWFuNigpKSA6IGNvbnRleHQuZGVzdHJveUJlYW4oY29tcEJlYW4uY3VycmVudCk7XG4gICAgaWYgKCFlUmVmKSB7XG4gICAgICByb3dDdHJsLnVuc2V0Q29tcChjb250YWluZXJUeXBlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFyb3dDdHJsLmlzQWxpdmUoKSB8fCBjb250ZXh0LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY29tcFByb3h5ID0ge1xuICAgICAgLy8gdGhlIHJvd1RvcCBpcyBtYW5hZ2VkIGJ5IHN0YXRlLCBpbnN0ZWFkIG9mIGRpcmVjdCBzdHlsZSBtYW5pcHVsYXRpb24gYnkgcm93Q3RybCAobGlrZSBhbGwgdGhlIG90aGVyIHN0eWxlcylcbiAgICAgIC8vIGFzIHdlIG5lZWQgdG8gaGF2ZSBhbiBpbml0aWFsIHZhbHVlIHdoZW4gaXQncyBwbGFjZWQgaW50byBoZSBET00gZm9yIHRoZSBmaXJzdCB0aW1lLCBmb3IgYW5pbWF0aW9uIHRvIHdvcmsuXG4gICAgICBzZXRUb3AsXG4gICAgICBzZXRUcmFuc2Zvcm0sXG4gICAgICAvLyBpIGZvdW5kIHVzaW5nIFJlYWN0IGZvciBtYW5hZ2luZyBjbGFzc2VzIGF0IHRoZSByb3cgbGV2ZWwgd2FzIHRvIHNsb3csIGFzIG1vZGlmeWluZyBjbGFzc2VzIGNhdXNlZCBhIGxvdCBvZlxuICAgICAgLy8gUmVhY3QgY29kZSB0byBleGVjdXRlLCBzbyBhdm9pZGluZyBSZWFjdCBmb3IgbWFuYWdpbmcgQ1NTIENsYXNzZXMgbWFkZSB0aGUgZ3JpZCBnbyBtdWNoIGZhc3Rlci5cbiAgICAgIHRvZ2dsZUNzczogKG5hbWUsIG9uKSA9PiBjc3NNYW5hZ2VyLmN1cnJlbnQudG9nZ2xlQ3NzKG5hbWUsIG9uKSxcbiAgICAgIHNldERvbU9yZGVyOiAoZG9tT3JkZXIpID0+IGRvbU9yZGVyUmVmLmN1cnJlbnQgPSBkb21PcmRlcixcbiAgICAgIHNldFJvd0luZGV4LFxuICAgICAgc2V0Um93SWQsXG4gICAgICBzZXRSb3dCdXNpbmVzc0tleSxcbiAgICAgIHNldFVzZXJTdHlsZXMsXG4gICAgICAvLyBpZiB3ZSBkb24ndCBtYWludGFpbiB0aGUgb3JkZXIsIHRoZW4gY29scyB3aWxsIGJlIHJpcHBlZCBvdXQgYW5kIGludG8gdGhlIGRvbVxuICAgICAgLy8gd2hlbiBjb2xzIHJlb3JkZXJlZCwgd2hpY2ggd291bGQgc3RvcCB0aGUgQ1NTIHRyYW5zaXRpb25zIGZyb20gd29ya2luZ1xuICAgICAgc2V0Q2VsbEN0cmxzOiAobmV4dCwgdXNlRmx1c2hTeW5jKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZDZWxsQ3RybHMgPSBjZWxsQ3RybHNSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgbmV4dENlbGxzID0gZ2V0TmV4dFZhbHVlSWZEaWZmZXJlbnQocHJldkNlbGxDdHJscywgbmV4dCwgZG9tT3JkZXJSZWYuY3VycmVudCk7XG4gICAgICAgIGlmIChuZXh0Q2VsbHMgIT09IHByZXZDZWxsQ3RybHMpIHtcbiAgICAgICAgICBjZWxsQ3RybHNSZWYuY3VycmVudCA9IG5leHRDZWxscztcbiAgICAgICAgICBpZiAoZW5hYmxlVXNlcykge1xuICAgICAgICAgICAgY2VsbHNDaGFuZ2VkLmN1cnJlbnQoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYWdGbHVzaFN5bmModXNlRmx1c2hTeW5jLCAoKSA9PiBzZXRDZWxsQ3RybHNGbHVzaFN5bmMobmV4dENlbGxzKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgc2hvd0Z1bGxXaWR0aDogKGNvbXBEZXRhaWxzKSA9PiB7XG4gICAgICAgIGZ1bGxXaWR0aFBhcmFtc1JlZi5jdXJyZW50ID0gY29tcERldGFpbHMucGFyYW1zO1xuICAgICAgICBzZXRGdWxsV2lkdGhDb21wRGV0YWlscyhjb21wRGV0YWlscyk7XG4gICAgICB9LFxuICAgICAgZ2V0RnVsbFdpZHRoQ2VsbFJlbmRlcmVyOiAoKSA9PiBmdWxsV2lkdGhDb21wUmVmLmN1cnJlbnQsXG4gICAgICBnZXRGdWxsV2lkdGhDZWxsUmVuZGVyZXJQYXJhbXM6ICgpID0+IGZ1bGxXaWR0aFBhcmFtc1JlZi5jdXJyZW50LFxuICAgICAgcmVmcmVzaEZ1bGxXaWR0aDogKGdldFVwZGF0ZWRQYXJhbXMpID0+IHtcbiAgICAgICAgY29uc3QgZnVsbFdpZHRoUGFyYW1zID0gZ2V0VXBkYXRlZFBhcmFtcygpO1xuICAgICAgICBmdWxsV2lkdGhQYXJhbXNSZWYuY3VycmVudCA9IGZ1bGxXaWR0aFBhcmFtcztcbiAgICAgICAgaWYgKGNhblJlZnJlc2hGdWxsV2lkdGhSZWYuY3VycmVudCkge1xuICAgICAgICAgIHNldEZ1bGxXaWR0aENvbXBEZXRhaWxzKChwcmV2RnVsbFdpZHRoQ29tcERldGFpbHMpID0+ICh7XG4gICAgICAgICAgICAuLi5wcmV2RnVsbFdpZHRoQ29tcERldGFpbHMsXG4gICAgICAgICAgICBwYXJhbXM6IGZ1bGxXaWR0aFBhcmFtc1xuICAgICAgICAgIH0pKTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoIWZ1bGxXaWR0aENvbXBSZWYuY3VycmVudCB8fCAhZnVsbFdpZHRoQ29tcFJlZi5jdXJyZW50LnJlZnJlc2gpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZ1bGxXaWR0aENvbXBSZWYuY3VycmVudC5yZWZyZXNoKGZ1bGxXaWR0aFBhcmFtcyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIHJvd0N0cmwuc2V0Q29tcChjb21wUHJveHksIGVSZWYsIGNvbnRhaW5lclR5cGUsIGNvbXBCZWFuLmN1cnJlbnQpO1xuICB9LCBbXSk7XG4gIHVzZUxheW91dEVmZmVjdDcoXG4gICAgKCkgPT4gc2hvd0pzQ29tcChmdWxsV2lkdGhDb21wRGV0YWlscywgY29udGV4dCwgZUd1aS5jdXJyZW50LCBmdWxsV2lkdGhDb21wUmVmKSxcbiAgICBbZnVsbFdpZHRoQ29tcERldGFpbHNdXG4gICk7XG4gIGNvbnN0IHJvd1N0eWxlcyA9IHVzZU1lbW85KCgpID0+IHtcbiAgICBjb25zdCByZXMgPSB7IHRvcCwgdHJhbnNmb3JtIH07XG4gICAgT2JqZWN0LmFzc2lnbihyZXMsIHVzZXJTdHlsZXMpO1xuICAgIHJldHVybiByZXM7XG4gIH0sIFt0b3AsIHRyYW5zZm9ybSwgdXNlclN0eWxlc10pO1xuICBjb25zdCBzaG93RnVsbFdpZHRoRnJhbWV3b3JrID0gaXNGdWxsV2lkdGggJiYgZnVsbFdpZHRoQ29tcERldGFpbHM/LmNvbXBvbmVudEZyb21GcmFtZXdvcms7XG4gIGNvbnN0IHNob3dDZWxscyA9ICFpc0Z1bGxXaWR0aCAmJiBjZWxsQ3RybHNNZXJnZWQgIT0gbnVsbDtcbiAgY29uc3QgcmVhY3RGdWxsV2lkdGhDZWxsUmVuZGVyZXJTdGF0ZWxlc3MgPSB1c2VNZW1vOSgoKSA9PiB7XG4gICAgY29uc3QgcmVzID0gZnVsbFdpZHRoQ29tcERldGFpbHM/LmNvbXBvbmVudEZyb21GcmFtZXdvcmsgJiYgaXNDb21wb25lbnRTdGF0ZWxlc3MoZnVsbFdpZHRoQ29tcERldGFpbHMuY29tcG9uZW50Q2xhc3MpO1xuICAgIHJldHVybiAhIXJlcztcbiAgfSwgW2Z1bGxXaWR0aENvbXBEZXRhaWxzXSk7XG4gIGNvbnN0IGNhblJlZnJlc2hGdWxsV2lkdGhSZWYgPSB1c2VSZWYxMShmYWxzZSk7XG4gIHVzZUVmZmVjdDgoKCkgPT4ge1xuICAgIGNhblJlZnJlc2hGdWxsV2lkdGhSZWYuY3VycmVudCA9IHJlYWN0RnVsbFdpZHRoQ2VsbFJlbmRlcmVyU3RhdGVsZXNzICYmICEhZnVsbFdpZHRoQ29tcERldGFpbHMgJiYgISFnb3MuZ2V0KFwicmVhY3RpdmVDdXN0b21Db21wb25lbnRzXCIpO1xuICB9LCBbcmVhY3RGdWxsV2lkdGhDZWxsUmVuZGVyZXJTdGF0ZWxlc3MsIGZ1bGxXaWR0aENvbXBEZXRhaWxzXSk7XG4gIGNvbnN0IHNob3dDZWxsc0pzeCA9ICgpID0+IGNlbGxDdHJsc01lcmdlZD8ubWFwKChjZWxsQ3RybCkgPT4gLyogQF9fUFVSRV9fICovIFJlYWN0MTQuY3JlYXRlRWxlbWVudChcbiAgICBjZWxsQ29tcF9kZWZhdWx0LFxuICAgIHtcbiAgICAgIGNlbGxDdHJsLFxuICAgICAgZWRpdGluZ0NlbGw6IGVkaXRTdmM/LmlzRWRpdGluZyhjZWxsQ3RybCwgeyB3aXRoT3BlbkVkaXRvcjogdHJ1ZSB9KSA/PyBmYWxzZSxcbiAgICAgIHByaW50TGF5b3V0OiByb3dDdHJsLnByaW50TGF5b3V0LFxuICAgICAga2V5OiBjZWxsQ3RybC5pbnN0YW5jZUlkXG4gICAgfVxuICApKTtcbiAgY29uc3Qgc2hvd0Z1bGxXaWR0aEZyYW1ld29ya0pzeCA9ICgpID0+IHtcbiAgICBjb25zdCBGdWxsV2lkdGhDb21wID0gZnVsbFdpZHRoQ29tcERldGFpbHMuY29tcG9uZW50Q2xhc3M7XG4gICAgcmV0dXJuIHJlYWN0RnVsbFdpZHRoQ2VsbFJlbmRlcmVyU3RhdGVsZXNzID8gLyogQF9fUFVSRV9fICovIFJlYWN0MTQuY3JlYXRlRWxlbWVudChGdWxsV2lkdGhDb21wLCB7IC4uLmZ1bGxXaWR0aENvbXBEZXRhaWxzLnBhcmFtcyB9KSA6IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE0LmNyZWF0ZUVsZW1lbnQoRnVsbFdpZHRoQ29tcCwgeyAuLi5mdWxsV2lkdGhDb21wRGV0YWlscy5wYXJhbXMsIHJlZjogZnVsbFdpZHRoQ29tcFJlZiB9KTtcbiAgfTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE0LmNyZWF0ZUVsZW1lbnQoXG4gICAgXCJkaXZcIixcbiAgICB7XG4gICAgICByZWY6IHNldFJlZjIsXG4gICAgICByb2xlOiBcInJvd1wiLFxuICAgICAgc3R5bGU6IHJvd1N0eWxlcyxcbiAgICAgIFwicm93LWluZGV4XCI6IHJvd0luZGV4LFxuICAgICAgXCJyb3ctaWRcIjogcm93SWQsXG4gICAgICBcInJvdy1idXNpbmVzcy1rZXlcIjogcm93QnVzaW5lc3NLZXlcbiAgICB9LFxuICAgIHNob3dDZWxscyA/IHNob3dDZWxsc0pzeCgpIDogc2hvd0Z1bGxXaWR0aEZyYW1ld29yayA/IHNob3dGdWxsV2lkdGhGcmFtZXdvcmtKc3goKSA6IG51bGxcbiAgKTtcbn07XG52YXIgcm93Q29tcF9kZWZhdWx0ID0gbWVtbzEwKFJvd0NvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL3Jvd3Mvcm93Q29udGFpbmVyQ29tcC50c3hcbnZhciBSb3dDb250YWluZXJDb21wID0gKHsgbmFtZSB9KSA9PiB7XG4gIGNvbnN0IHsgY29udGV4dCwgZ29zIH0gPSB1c2VDb250ZXh0MTIoQmVhbnNDb250ZXh0KTtcbiAgY29uc3QgY29udGFpbmVyT3B0aW9ucyA9IHVzZU1lbW8xMCgoKSA9PiBfZ2V0Um93Q29udGFpbmVyT3B0aW9ucyhuYW1lKSwgW25hbWVdKTtcbiAgY29uc3QgZVZpZXdwb3J0ID0gdXNlUmVmMTIobnVsbCk7XG4gIGNvbnN0IGVDb250YWluZXIgPSB1c2VSZWYxMihudWxsKTtcbiAgY29uc3QgZVNwYW5Db250YWluZXIgPSB1c2VSZWYxMihudWxsKTtcbiAgY29uc3Qgcm93Q3RybHNSZWYgPSB1c2VSZWYxMihbXSk7XG4gIGNvbnN0IHByZXZSb3dDdHJsc1JlZiA9IHVzZVJlZjEyKFtdKTtcbiAgY29uc3QgW3Jvd0N0cmxzT3JkZXJlZCwgc2V0Um93Q3RybHNPcmRlcmVkXSA9IHVzZVN0YXRlMTMoKCkgPT4gW10pO1xuICBjb25zdCBpc1NwYW5uaW5nID0gISFnb3MuZ2V0KFwiZW5hYmxlQ2VsbFNwYW5cIikgJiYgISFjb250YWluZXJPcHRpb25zLmdldFNwYW5uZWRSb3dDdHJscztcbiAgY29uc3Qgc3Bhbm5lZFJvd0N0cmxzUmVmID0gdXNlUmVmMTIoW10pO1xuICBjb25zdCBwcmV2U3Bhbm5lZFJvd0N0cmxzUmVmID0gdXNlUmVmMTIoW10pO1xuICBjb25zdCBbc3Bhbm5lZFJvd0N0cmxzT3JkZXJlZCwgc2V0U3Bhbm5lZFJvd0N0cmxzT3JkZXJlZF0gPSB1c2VTdGF0ZTEzKCgpID0+IFtdKTtcbiAgY29uc3QgZG9tT3JkZXJSZWYgPSB1c2VSZWYxMihmYWxzZSk7XG4gIGNvbnN0IHJvd0NvbnRhaW5lckN0cmxSZWYgPSB1c2VSZWYxMigpO1xuICBjb25zdCB2aWV3cG9ydENsYXNzZXMgPSB1c2VNZW1vMTAoKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy12aWV3cG9ydFwiLCBfZ2V0Um93Vmlld3BvcnRDbGFzcyhuYW1lKSksIFtuYW1lXSk7XG4gIGNvbnN0IGNvbnRhaW5lckNsYXNzZXMgPSB1c2VNZW1vMTAoKCkgPT4gY2xhc3Nlc0xpc3QoX2dldFJvd0NvbnRhaW5lckNsYXNzKG5hbWUpKSwgW25hbWVdKTtcbiAgY29uc3Qgc3BhbkNsYXNzZXMgPSB1c2VNZW1vMTAoKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy1zcGFubmluZy1jb250YWluZXJcIiwgX2dldFJvd1NwYW5Db250YWluZXJDbGFzcyhuYW1lKSksIFtuYW1lXSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlclZpZXdwb3J0ID0gY29udGFpbmVyT3B0aW9ucy50eXBlID09PSBcImNlbnRlclwiIHx8IGlzU3Bhbm5pbmc7XG4gIGNvbnN0IHRvcExldmVsUmVmID0gc2hvdWxkUmVuZGVyVmlld3BvcnQgPyBlVmlld3BvcnQgOiBlQ29udGFpbmVyO1xuICByZWFjdENvbW1lbnRfZGVmYXVsdChcIiBBRyBSb3cgQ29udGFpbmVyIFwiICsgbmFtZSArIFwiIFwiLCB0b3BMZXZlbFJlZik7XG4gIGNvbnN0IGFyZUVsZW1lbnRzUmVhZHkgPSB1c2VDYWxsYmFjazExKCgpID0+IHtcbiAgICBjb25zdCB2aWV3cG9ydFJlYWR5ID0gIXNob3VsZFJlbmRlclZpZXdwb3J0IHx8IGVWaWV3cG9ydC5jdXJyZW50ICE9IG51bGw7XG4gICAgY29uc3QgY29udGFpbmVyUmVhZHkgPSBlQ29udGFpbmVyLmN1cnJlbnQgIT0gbnVsbDtcbiAgICBjb25zdCBzcGFuQ29udGFpbmVyUmVhZHkgPSAhaXNTcGFubmluZyB8fCBlU3BhbkNvbnRhaW5lci5jdXJyZW50ICE9IG51bGw7XG4gICAgcmV0dXJuIHZpZXdwb3J0UmVhZHkgJiYgY29udGFpbmVyUmVhZHkgJiYgc3BhbkNvbnRhaW5lclJlYWR5O1xuICB9LCBbXSk7XG4gIGNvbnN0IGFyZUVsZW1lbnRzUmVtb3ZlZCA9IHVzZUNhbGxiYWNrMTEoKCkgPT4ge1xuICAgIHJldHVybiBlVmlld3BvcnQuY3VycmVudCA9PSBudWxsICYmIGVDb250YWluZXIuY3VycmVudCA9PSBudWxsICYmIGVTcGFuQ29udGFpbmVyLmN1cnJlbnQgPT0gbnVsbDtcbiAgfSwgW10pO1xuICBjb25zdCBzZXRSZWYyID0gdXNlQ2FsbGJhY2sxMSgoKSA9PiB7XG4gICAgaWYgKGFyZUVsZW1lbnRzUmVtb3ZlZCgpKSB7XG4gICAgICByb3dDb250YWluZXJDdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmRlc3Ryb3lCZWFuKHJvd0NvbnRhaW5lckN0cmxSZWYuY3VycmVudCk7XG4gICAgfVxuICAgIGlmIChjb250ZXh0LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGFyZUVsZW1lbnRzUmVhZHkoKSkge1xuICAgICAgY29uc3QgdXBkYXRlUm93Q3RybHNPcmRlcmVkID0gKHVzZUZsdXNoU3luYykgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gZ2V0TmV4dFZhbHVlSWZEaWZmZXJlbnQoXG4gICAgICAgICAgcHJldlJvd0N0cmxzUmVmLmN1cnJlbnQsXG4gICAgICAgICAgcm93Q3RybHNSZWYuY3VycmVudCxcbiAgICAgICAgICBkb21PcmRlclJlZi5jdXJyZW50XG4gICAgICAgICk7XG4gICAgICAgIGlmIChuZXh0ICE9PSBwcmV2Um93Q3RybHNSZWYuY3VycmVudCkge1xuICAgICAgICAgIHByZXZSb3dDdHJsc1JlZi5jdXJyZW50ID0gbmV4dDtcbiAgICAgICAgICBhZ0ZsdXNoU3luYyh1c2VGbHVzaFN5bmMsICgpID0+IHNldFJvd0N0cmxzT3JkZXJlZChuZXh0KSk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCB1cGRhdGVTcGFubmVkUm93Q3RybHNPcmRlcmVkID0gKHVzZUZsdXNoU3luYykgPT4ge1xuICAgICAgICBjb25zdCBuZXh0ID0gZ2V0TmV4dFZhbHVlSWZEaWZmZXJlbnQoXG4gICAgICAgICAgcHJldlNwYW5uZWRSb3dDdHJsc1JlZi5jdXJyZW50LFxuICAgICAgICAgIHNwYW5uZWRSb3dDdHJsc1JlZi5jdXJyZW50LFxuICAgICAgICAgIGRvbU9yZGVyUmVmLmN1cnJlbnRcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG5leHQgIT09IHByZXZTcGFubmVkUm93Q3RybHNSZWYuY3VycmVudCkge1xuICAgICAgICAgIHByZXZTcGFubmVkUm93Q3RybHNSZWYuY3VycmVudCA9IG5leHQ7XG4gICAgICAgICAgYWdGbHVzaFN5bmModXNlRmx1c2hTeW5jLCAoKSA9PiBzZXRTcGFubmVkUm93Q3RybHNPcmRlcmVkKG5leHQpKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgICAgc2V0SG9yaXpvbnRhbFNjcm9sbDogKG9mZnNldCkgPT4ge1xuICAgICAgICAgIGlmIChlVmlld3BvcnQuY3VycmVudCkge1xuICAgICAgICAgICAgZVZpZXdwb3J0LmN1cnJlbnQuc2Nyb2xsTGVmdCA9IG9mZnNldDtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHNldFZpZXdwb3J0SGVpZ2h0OiAoaGVpZ2h0KSA9PiB7XG4gICAgICAgICAgaWYgKGVWaWV3cG9ydC5jdXJyZW50KSB7XG4gICAgICAgICAgICBlVmlld3BvcnQuY3VycmVudC5zdHlsZS5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBzZXRSb3dDdHJsczogKHsgcm93Q3RybHMsIHVzZUZsdXNoU3luYyB9KSA9PiB7XG4gICAgICAgICAgY29uc3QgdXNlRmx1c2ggPSAhIXVzZUZsdXNoU3luYyAmJiByb3dDdHJsc1JlZi5jdXJyZW50Lmxlbmd0aCA+IDAgJiYgcm93Q3RybHMubGVuZ3RoID4gMDtcbiAgICAgICAgICByb3dDdHJsc1JlZi5jdXJyZW50ID0gcm93Q3RybHM7XG4gICAgICAgICAgdXBkYXRlUm93Q3RybHNPcmRlcmVkKHVzZUZsdXNoKTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0U3Bhbm5lZFJvd0N0cmxzOiAocm93Q3RybHMsIHVzZUZsdXNoU3luYykgPT4ge1xuICAgICAgICAgIGNvbnN0IHVzZUZsdXNoID0gISF1c2VGbHVzaFN5bmMgJiYgc3Bhbm5lZFJvd0N0cmxzUmVmLmN1cnJlbnQubGVuZ3RoID4gMCAmJiByb3dDdHJscy5sZW5ndGggPiAwO1xuICAgICAgICAgIHNwYW5uZWRSb3dDdHJsc1JlZi5jdXJyZW50ID0gcm93Q3RybHM7XG4gICAgICAgICAgdXBkYXRlU3Bhbm5lZFJvd0N0cmxzT3JkZXJlZCh1c2VGbHVzaCk7XG4gICAgICAgIH0sXG4gICAgICAgIHNldERvbU9yZGVyOiAoZG9tT3JkZXIpID0+IHtcbiAgICAgICAgICBpZiAoZG9tT3JkZXJSZWYuY3VycmVudCAhPSBkb21PcmRlcikge1xuICAgICAgICAgICAgZG9tT3JkZXJSZWYuY3VycmVudCA9IGRvbU9yZGVyO1xuICAgICAgICAgICAgdXBkYXRlUm93Q3RybHNPcmRlcmVkKGZhbHNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHNldENvbnRhaW5lcldpZHRoOiAod2lkdGgpID0+IHtcbiAgICAgICAgICBpZiAoZUNvbnRhaW5lci5jdXJyZW50KSB7XG4gICAgICAgICAgICBlQ29udGFpbmVyLmN1cnJlbnQuc3R5bGUud2lkdGggPSB3aWR0aDtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHNldE9mZnNldFRvcDogKG9mZnNldCkgPT4ge1xuICAgICAgICAgIGlmIChlQ29udGFpbmVyLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGVDb250YWluZXIuY3VycmVudC5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlWSgke29mZnNldH0pYDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICByb3dDb250YWluZXJDdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IFJvd0NvbnRhaW5lckN0cmwobmFtZSkpO1xuICAgICAgcm93Q29udGFpbmVyQ3RybFJlZi5jdXJyZW50LnNldENvbXAoXG4gICAgICAgIGNvbXBQcm94eSxcbiAgICAgICAgZUNvbnRhaW5lci5jdXJyZW50LFxuICAgICAgICBlU3BhbkNvbnRhaW5lci5jdXJyZW50ID8/IHZvaWQgMCxcbiAgICAgICAgZVZpZXdwb3J0LmN1cnJlbnRcbiAgICAgICk7XG4gICAgfVxuICB9LCBbYXJlRWxlbWVudHNSZWFkeSwgYXJlRWxlbWVudHNSZW1vdmVkXSk7XG4gIGNvbnN0IHNldENvbnRhaW5lclJlZiA9IHVzZUNhbGxiYWNrMTEoXG4gICAgKGUpID0+IHtcbiAgICAgIGVDb250YWluZXIuY3VycmVudCA9IGU7XG4gICAgICBzZXRSZWYyKCk7XG4gICAgfSxcbiAgICBbc2V0UmVmMl1cbiAgKTtcbiAgY29uc3Qgc2V0U3BhbkNvbnRhaW5lclJlZiA9IHVzZUNhbGxiYWNrMTEoXG4gICAgKGUpID0+IHtcbiAgICAgIGVTcGFuQ29udGFpbmVyLmN1cnJlbnQgPSBlO1xuICAgICAgc2V0UmVmMigpO1xuICAgIH0sXG4gICAgW3NldFJlZjJdXG4gICk7XG4gIGNvbnN0IHNldFZpZXdwb3J0UmVmID0gdXNlQ2FsbGJhY2sxMShcbiAgICAoZSkgPT4ge1xuICAgICAgZVZpZXdwb3J0LmN1cnJlbnQgPSBlO1xuICAgICAgc2V0UmVmMigpO1xuICAgIH0sXG4gICAgW3NldFJlZjJdXG4gICk7XG4gIGNvbnN0IGJ1aWxkQ29udGFpbmVyID0gKCkgPT4gLyogQF9fUFVSRV9fICovIFJlYWN0MTUuY3JlYXRlRWxlbWVudChcbiAgICBcImRpdlwiLFxuICAgIHtcbiAgICAgIGNsYXNzTmFtZTogY29udGFpbmVyQ2xhc3NlcyxcbiAgICAgIHJlZjogc2V0Q29udGFpbmVyUmVmLFxuICAgICAgcm9sZTogc2hvdWxkUmVuZGVyVmlld3BvcnQgPyBcInByZXNlbnRhdGlvblwiIDogXCJyb3dncm91cFwiXG4gICAgfSxcbiAgICByb3dDdHJsc09yZGVyZWQubWFwKChyb3dDdHJsKSA9PiAvKiBAX19QVVJFX18gKi8gUmVhY3QxNS5jcmVhdGVFbGVtZW50KHJvd0NvbXBfZGVmYXVsdCwgeyByb3dDdHJsLCBjb250YWluZXJUeXBlOiBjb250YWluZXJPcHRpb25zLnR5cGUsIGtleTogcm93Q3RybC5pbnN0YW5jZUlkIH0pKVxuICApO1xuICBpZiAoIXNob3VsZFJlbmRlclZpZXdwb3J0KSB7XG4gICAgcmV0dXJuIGJ1aWxkQ29udGFpbmVyKCk7XG4gIH1cbiAgY29uc3QgYnVpbGRTcGFuQ29udGFpbmVyID0gKCkgPT4gLyogQF9fUFVSRV9fICovIFJlYWN0MTUuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogc3BhbkNsYXNzZXMsIHJlZjogc2V0U3BhbkNvbnRhaW5lclJlZiwgcm9sZTogXCJwcmVzZW50YXRpb25cIiB9LCBzcGFubmVkUm93Q3RybHNPcmRlcmVkLm1hcCgocm93Q3RybCkgPT4gLyogQF9fUFVSRV9fICovIFJlYWN0MTUuY3JlYXRlRWxlbWVudChyb3dDb21wX2RlZmF1bHQsIHsgcm93Q3RybCwgY29udGFpbmVyVHlwZTogY29udGFpbmVyT3B0aW9ucy50eXBlLCBrZXk6IHJvd0N0cmwuaW5zdGFuY2VJZCB9KSkpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTUuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogdmlld3BvcnRDbGFzc2VzLCByZWY6IHNldFZpZXdwb3J0UmVmLCByb2xlOiBcInJvd2dyb3VwXCIgfSwgYnVpbGRDb250YWluZXIoKSwgaXNTcGFubmluZyA/IGJ1aWxkU3BhbkNvbnRhaW5lcigpIDogbnVsbCk7XG59O1xudmFyIHJvd0NvbnRhaW5lckNvbXBfZGVmYXVsdCA9IG1lbW8xMShSb3dDb250YWluZXJDb21wKTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9ncmlkQm9keUNvbXAudHN4XG52YXIgR3JpZEJvZHlDb21wID0gKCkgPT4ge1xuICBjb25zdCBiZWFucyA9IHVzZUNvbnRleHQxMyhCZWFuc0NvbnRleHQpO1xuICBjb25zdCB7IGNvbnRleHQsIG92ZXJsYXlzIH0gPSBiZWFucztcbiAgY29uc3QgW3Jvd0FuaW1hdGlvbkNsYXNzLCBzZXRSb3dBbmltYXRpb25DbGFzc10gPSB1c2VTdGF0ZTE0KFwiXCIpO1xuICBjb25zdCBbdG9wSGVpZ2h0LCBzZXRUb3BIZWlnaHRdID0gdXNlU3RhdGUxNCgwKTtcbiAgY29uc3QgW2JvdHRvbUhlaWdodCwgc2V0Qm90dG9tSGVpZ2h0XSA9IHVzZVN0YXRlMTQoMCk7XG4gIGNvbnN0IFtzdGlja3lUb3BIZWlnaHQsIHNldFN0aWNreVRvcEhlaWdodF0gPSB1c2VTdGF0ZTE0KFwiMHB4XCIpO1xuICBjb25zdCBbc3RpY2t5VG9wVG9wLCBzZXRTdGlja3lUb3BUb3BdID0gdXNlU3RhdGUxNChcIjBweFwiKTtcbiAgY29uc3QgW3N0aWNreVRvcFdpZHRoLCBzZXRTdGlja3lUb3BXaWR0aF0gPSB1c2VTdGF0ZTE0KFwiMTAwJVwiKTtcbiAgY29uc3QgW3N0aWNreUJvdHRvbUhlaWdodCwgc2V0U3RpY2t5Qm90dG9tSGVpZ2h0XSA9IHVzZVN0YXRlMTQoXCIwcHhcIik7XG4gIGNvbnN0IFtzdGlja3lCb3R0b21Cb3R0b20sIHNldFN0aWNreUJvdHRvbUJvdHRvbV0gPSB1c2VTdGF0ZTE0KFwiMHB4XCIpO1xuICBjb25zdCBbc3RpY2t5Qm90dG9tV2lkdGgsIHNldFN0aWNreUJvdHRvbVdpZHRoXSA9IHVzZVN0YXRlMTQoXCIxMDAlXCIpO1xuICBjb25zdCBbdG9wSW52aXNpYmxlLCBzZXRUb3BJbnZpc2libGVdID0gdXNlU3RhdGUxNCh0cnVlKTtcbiAgY29uc3QgW2JvdHRvbUludmlzaWJsZSwgc2V0Qm90dG9tSW52aXNpYmxlXSA9IHVzZVN0YXRlMTQodHJ1ZSk7XG4gIGNvbnN0IFtmb3JjZVZlcnRpY2FsU2Nyb2xsQ2xhc3MsIHNldEZvcmNlVmVydGljYWxTY3JvbGxDbGFzc10gPSB1c2VTdGF0ZTE0KG51bGwpO1xuICBjb25zdCBbdG9wQW5kQm90dG9tT3ZlcmZsb3dZLCBzZXRUb3BBbmRCb3R0b21PdmVyZmxvd1ldID0gdXNlU3RhdGUxNChcIlwiKTtcbiAgY29uc3QgW2NlbGxTZWxlY3RhYmxlQ3NzLCBzZXRDZWxsU2VsZWN0YWJsZUNzc10gPSB1c2VTdGF0ZTE0KG51bGwpO1xuICBjb25zdCBbbGF5b3V0Q2xhc3MsIHNldExheW91dENsYXNzXSA9IHVzZVN0YXRlMTQoXCJhZy1sYXlvdXQtbm9ybWFsXCIpO1xuICBjb25zdCBjc3NNYW5hZ2VyID0gdXNlUmVmMTMoKTtcbiAgaWYgKCFjc3NNYW5hZ2VyLmN1cnJlbnQpIHtcbiAgICBjc3NNYW5hZ2VyLmN1cnJlbnQgPSBuZXcgQ3NzQ2xhc3NNYW5hZ2VyNCgoKSA9PiBlUm9vdC5jdXJyZW50KTtcbiAgfVxuICBjb25zdCBlUm9vdCA9IHVzZVJlZjEzKG51bGwpO1xuICBjb25zdCBlVG9wID0gdXNlUmVmMTMobnVsbCk7XG4gIGNvbnN0IGVTdGlja3lUb3AgPSB1c2VSZWYxMyhudWxsKTtcbiAgY29uc3QgZVN0aWNreUJvdHRvbSA9IHVzZVJlZjEzKG51bGwpO1xuICBjb25zdCBlQm9keSA9IHVzZVJlZjEzKG51bGwpO1xuICBjb25zdCBlQm9keVZpZXdwb3J0ID0gdXNlUmVmMTMobnVsbCk7XG4gIGNvbnN0IGVCb3R0b20gPSB1c2VSZWYxMyhudWxsKTtcbiAgY29uc3QgYmVhbnNUb0Rlc3Ryb3kgPSB1c2VSZWYxMyhbXSk7XG4gIGNvbnN0IGRlc3Ryb3lGdW5jcyA9IHVzZVJlZjEzKFtdKTtcbiAgcmVhY3RDb21tZW50X2RlZmF1bHQoXCIgQUcgR3JpZCBCb2R5IFwiLCBlUm9vdCk7XG4gIHJlYWN0Q29tbWVudF9kZWZhdWx0KFwiIEFHIFBpbm5lZCBUb3AgXCIsIGVUb3ApO1xuICByZWFjdENvbW1lbnRfZGVmYXVsdChcIiBBRyBTdGlja3kgVG9wIFwiLCBlU3RpY2t5VG9wKTtcbiAgcmVhY3RDb21tZW50X2RlZmF1bHQoXCIgQUcgTWlkZGxlIFwiLCBlQm9keVZpZXdwb3J0KTtcbiAgcmVhY3RDb21tZW50X2RlZmF1bHQoXCIgQUcgUGlubmVkIEJvdHRvbSBcIiwgZUJvdHRvbSk7XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazEyKChlUmVmKSA9PiB7XG4gICAgZVJvb3QuY3VycmVudCA9IGVSZWY7XG4gICAgaWYgKCFlUmVmIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgYmVhbnNUb0Rlc3Ryb3kuY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW5zKGJlYW5zVG9EZXN0cm95LmN1cnJlbnQpO1xuICAgICAgZm9yIChjb25zdCBmIG9mIGRlc3Ryb3lGdW5jcy5jdXJyZW50KSB7XG4gICAgICAgIGYoKTtcbiAgICAgIH1cbiAgICAgIGRlc3Ryb3lGdW5jcy5jdXJyZW50ID0gW107XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGF0dGFjaFRvRG9tID0gKGVQYXJlbnQsIGVDaGlsZCkgPT4ge1xuICAgICAgZVBhcmVudC5hcHBlbmRDaGlsZChlQ2hpbGQpO1xuICAgICAgZGVzdHJveUZ1bmNzLmN1cnJlbnQucHVzaCgoKSA9PiBlQ2hpbGQucmVtb3ZlKCkpO1xuICAgIH07XG4gICAgY29uc3QgbmV3Q29tcCA9IChjb21wQ2xhc3MpID0+IHtcbiAgICAgIGNvbnN0IGNvbXAgPSBjb250ZXh0LmNyZWF0ZUJlYW4obmV3IGNvbXBDbGFzcygpKTtcbiAgICAgIGJlYW5zVG9EZXN0cm95LmN1cnJlbnQucHVzaChjb21wKTtcbiAgICAgIHJldHVybiBjb21wO1xuICAgIH07XG4gICAgY29uc3QgYWRkQ29tcCA9IChlUGFyZW50LCBjb21wQ2xhc3MsIGNvbW1lbnQpID0+IHtcbiAgICAgIGF0dGFjaFRvRG9tKGVQYXJlbnQsIGRvY3VtZW50LmNyZWF0ZUNvbW1lbnQoY29tbWVudCkpO1xuICAgICAgYXR0YWNoVG9Eb20oZVBhcmVudCwgbmV3Q29tcChjb21wQ2xhc3MpLmdldEd1aSgpKTtcbiAgICB9O1xuICAgIGFkZENvbXAoZVJlZiwgRmFrZUhTY3JvbGxDb21wLCBcIiBBRyBGYWtlIEhvcml6b250YWwgU2Nyb2xsIFwiKTtcbiAgICBjb25zdCBvdmVybGF5Q29tcCA9IG92ZXJsYXlzPy5nZXRPdmVybGF5V3JhcHBlckNvbXBDbGFzcygpO1xuICAgIGlmIChvdmVybGF5Q29tcCkge1xuICAgICAgYWRkQ29tcChlUmVmLCBvdmVybGF5Q29tcCwgXCIgQUcgT3ZlcmxheSBXcmFwcGVyIFwiKTtcbiAgICB9XG4gICAgaWYgKGVCb2R5LmN1cnJlbnQpIHtcbiAgICAgIGFkZENvbXAoZUJvZHkuY3VycmVudCwgRmFrZVZTY3JvbGxDb21wLCBcIiBBRyBGYWtlIFZlcnRpY2FsIFNjcm9sbCBcIik7XG4gICAgfVxuICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgIHNldFJvd0FuaW1hdGlvbkNzc09uQm9keVZpZXdwb3J0OiBzZXRSb3dBbmltYXRpb25DbGFzcyxcbiAgICAgIHNldENvbHVtbkNvdW50OiAoY291bnQpID0+IHtcbiAgICAgICAgaWYgKGVSb290LmN1cnJlbnQpIHtcbiAgICAgICAgICBfc2V0QXJpYUNvbENvdW50KGVSb290LmN1cnJlbnQsIGNvdW50KTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNldFJvd0NvdW50OiAoY291bnQpID0+IHtcbiAgICAgICAgaWYgKGVSb290LmN1cnJlbnQpIHtcbiAgICAgICAgICBfc2V0QXJpYVJvd0NvdW50KGVSb290LmN1cnJlbnQsIGNvdW50KTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNldFRvcEhlaWdodCxcbiAgICAgIHNldEJvdHRvbUhlaWdodCxcbiAgICAgIHNldFN0aWNreVRvcEhlaWdodCxcbiAgICAgIHNldFN0aWNreVRvcFRvcCxcbiAgICAgIHNldFN0aWNreVRvcFdpZHRoLFxuICAgICAgc2V0VG9wSW52aXNpYmxlLFxuICAgICAgc2V0Qm90dG9tSW52aXNpYmxlLFxuICAgICAgc2V0Q29sdW1uTW92aW5nQ3NzOiAoY3NzQ2xhc3MsIGZsYWcpID0+IGNzc01hbmFnZXIuY3VycmVudC50b2dnbGVDc3MoY3NzQ2xhc3MsIGZsYWcpLFxuICAgICAgdXBkYXRlTGF5b3V0Q2xhc3Nlczogc2V0TGF5b3V0Q2xhc3MsXG4gICAgICBzZXRBbHdheXNWZXJ0aWNhbFNjcm9sbENsYXNzOiBzZXRGb3JjZVZlcnRpY2FsU2Nyb2xsQ2xhc3MsXG4gICAgICBzZXRQaW5uZWRUb3BCb3R0b21PdmVyZmxvd1k6IHNldFRvcEFuZEJvdHRvbU92ZXJmbG93WSxcbiAgICAgIHNldENlbGxTZWxlY3RhYmxlQ3NzOiAoY3NzQ2xhc3MsIGZsYWcpID0+IHNldENlbGxTZWxlY3RhYmxlQ3NzKGZsYWcgPyBjc3NDbGFzcyA6IG51bGwpLFxuICAgICAgc2V0Qm9keVZpZXdwb3J0V2lkdGg6ICh3aWR0aCkgPT4ge1xuICAgICAgICBpZiAoZUJvZHlWaWV3cG9ydC5jdXJyZW50KSB7XG4gICAgICAgICAgZUJvZHlWaWV3cG9ydC5jdXJyZW50LnN0eWxlLndpZHRoID0gd2lkdGg7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICByZWdpc3RlckJvZHlWaWV3cG9ydFJlc2l6ZUxpc3RlbmVyOiAobGlzdGVuZXIpID0+IHtcbiAgICAgICAgaWYgKGVCb2R5Vmlld3BvcnQuY3VycmVudCkge1xuICAgICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlRnJvbVJlc2l6ZSA9IF9vYnNlcnZlUmVzaXplKGJlYW5zLCBlQm9keVZpZXdwb3J0LmN1cnJlbnQsIGxpc3RlbmVyKTtcbiAgICAgICAgICBkZXN0cm95RnVuY3MuY3VycmVudC5wdXNoKCgpID0+IHVuc3Vic2NyaWJlRnJvbVJlc2l6ZSgpKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNldFN0aWNreUJvdHRvbUhlaWdodCxcbiAgICAgIHNldFN0aWNreUJvdHRvbUJvdHRvbSxcbiAgICAgIHNldFN0aWNreUJvdHRvbVdpZHRoLFxuICAgICAgc2V0R3JpZFJvb3RSb2xlOiAocm9sZSkgPT4gZVJlZi5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsIHJvbGUpXG4gICAgfTtcbiAgICBjb25zdCBjdHJsID0gY29udGV4dC5jcmVhdGVCZWFuKG5ldyBHcmlkQm9keUN0cmwoKSk7XG4gICAgYmVhbnNUb0Rlc3Ryb3kuY3VycmVudC5wdXNoKGN0cmwpO1xuICAgIGN0cmwuc2V0Q29tcChcbiAgICAgIGNvbXBQcm94eSxcbiAgICAgIGVSZWYsXG4gICAgICBlQm9keVZpZXdwb3J0LmN1cnJlbnQsXG4gICAgICBlVG9wLmN1cnJlbnQsXG4gICAgICBlQm90dG9tLmN1cnJlbnQsXG4gICAgICBlU3RpY2t5VG9wLmN1cnJlbnQsXG4gICAgICBlU3RpY2t5Qm90dG9tLmN1cnJlbnRcbiAgICApO1xuICB9LCBbXSk7XG4gIGNvbnN0IHJvb3RDbGFzc2VzID0gdXNlTWVtbzExKCgpID0+IGNsYXNzZXNMaXN0KFwiYWctcm9vdFwiLCBcImFnLXVuc2VsZWN0YWJsZVwiLCBsYXlvdXRDbGFzcyksIFtsYXlvdXRDbGFzc10pO1xuICBjb25zdCBib2R5Vmlld3BvcnRDbGFzc2VzID0gdXNlTWVtbzExKFxuICAgICgpID0+IGNsYXNzZXNMaXN0KFxuICAgICAgXCJhZy1ib2R5LXZpZXdwb3J0XCIsXG4gICAgICByb3dBbmltYXRpb25DbGFzcyxcbiAgICAgIGxheW91dENsYXNzLFxuICAgICAgZm9yY2VWZXJ0aWNhbFNjcm9sbENsYXNzLFxuICAgICAgY2VsbFNlbGVjdGFibGVDc3NcbiAgICApLFxuICAgIFtyb3dBbmltYXRpb25DbGFzcywgbGF5b3V0Q2xhc3MsIGZvcmNlVmVydGljYWxTY3JvbGxDbGFzcywgY2VsbFNlbGVjdGFibGVDc3NdXG4gICk7XG4gIGNvbnN0IGJvZHlDbGFzc2VzID0gdXNlTWVtbzExKCgpID0+IGNsYXNzZXNMaXN0KFwiYWctYm9keVwiLCBsYXlvdXRDbGFzcyksIFtsYXlvdXRDbGFzc10pO1xuICBjb25zdCB0b3BDbGFzc2VzID0gdXNlTWVtbzExKFxuICAgICgpID0+IGNsYXNzZXNMaXN0KFwiYWctZmxvYXRpbmctdG9wXCIsIHRvcEludmlzaWJsZSA/IFwiYWctaW52aXNpYmxlXCIgOiBudWxsLCBjZWxsU2VsZWN0YWJsZUNzcyksXG4gICAgW2NlbGxTZWxlY3RhYmxlQ3NzLCB0b3BJbnZpc2libGVdXG4gICk7XG4gIGNvbnN0IHN0aWNreVRvcENsYXNzZXMgPSB1c2VNZW1vMTEoKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy1zdGlja3ktdG9wXCIsIGNlbGxTZWxlY3RhYmxlQ3NzKSwgW2NlbGxTZWxlY3RhYmxlQ3NzXSk7XG4gIGNvbnN0IHN0aWNreUJvdHRvbUNsYXNzZXMgPSB1c2VNZW1vMTEoXG4gICAgKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy1zdGlja3ktYm90dG9tXCIsIHN0aWNreUJvdHRvbUhlaWdodCA9PT0gXCIwcHhcIiA/IFwiYWctaW52aXNpYmxlXCIgOiBudWxsLCBjZWxsU2VsZWN0YWJsZUNzcyksXG4gICAgW2NlbGxTZWxlY3RhYmxlQ3NzLCBzdGlja3lCb3R0b21IZWlnaHRdXG4gICk7XG4gIGNvbnN0IGJvdHRvbUNsYXNzZXMgPSB1c2VNZW1vMTEoXG4gICAgKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy1mbG9hdGluZy1ib3R0b21cIiwgYm90dG9tSW52aXNpYmxlID8gXCJhZy1pbnZpc2libGVcIiA6IG51bGwsIGNlbGxTZWxlY3RhYmxlQ3NzKSxcbiAgICBbY2VsbFNlbGVjdGFibGVDc3MsIGJvdHRvbUludmlzaWJsZV1cbiAgKTtcbiAgY29uc3QgdG9wU3R5bGUgPSB1c2VNZW1vMTEoXG4gICAgKCkgPT4gKHtcbiAgICAgIGhlaWdodDogdG9wSGVpZ2h0LFxuICAgICAgbWluSGVpZ2h0OiB0b3BIZWlnaHQsXG4gICAgICBvdmVyZmxvd1k6IHRvcEFuZEJvdHRvbU92ZXJmbG93WVxuICAgIH0pLFxuICAgIFt0b3BIZWlnaHQsIHRvcEFuZEJvdHRvbU92ZXJmbG93WV1cbiAgKTtcbiAgY29uc3Qgc3RpY2t5VG9wU3R5bGUgPSB1c2VNZW1vMTEoXG4gICAgKCkgPT4gKHtcbiAgICAgIGhlaWdodDogc3RpY2t5VG9wSGVpZ2h0LFxuICAgICAgdG9wOiBzdGlja3lUb3BUb3AsXG4gICAgICB3aWR0aDogc3RpY2t5VG9wV2lkdGhcbiAgICB9KSxcbiAgICBbc3RpY2t5VG9wSGVpZ2h0LCBzdGlja3lUb3BUb3AsIHN0aWNreVRvcFdpZHRoXVxuICApO1xuICBjb25zdCBzdGlja3lCb3R0b21TdHlsZSA9IHVzZU1lbW8xMShcbiAgICAoKSA9PiAoe1xuICAgICAgaGVpZ2h0OiBzdGlja3lCb3R0b21IZWlnaHQsXG4gICAgICBib3R0b206IHN0aWNreUJvdHRvbUJvdHRvbSxcbiAgICAgIHdpZHRoOiBzdGlja3lCb3R0b21XaWR0aFxuICAgIH0pLFxuICAgIFtzdGlja3lCb3R0b21IZWlnaHQsIHN0aWNreUJvdHRvbUJvdHRvbSwgc3RpY2t5Qm90dG9tV2lkdGhdXG4gICk7XG4gIGNvbnN0IGJvdHRvbVN0eWxlID0gdXNlTWVtbzExKFxuICAgICgpID0+ICh7XG4gICAgICBoZWlnaHQ6IGJvdHRvbUhlaWdodCxcbiAgICAgIG1pbkhlaWdodDogYm90dG9tSGVpZ2h0LFxuICAgICAgb3ZlcmZsb3dZOiB0b3BBbmRCb3R0b21PdmVyZmxvd1lcbiAgICB9KSxcbiAgICBbYm90dG9tSGVpZ2h0LCB0b3BBbmRCb3R0b21PdmVyZmxvd1ldXG4gICk7XG4gIGNvbnN0IGNyZWF0ZVJvd0NvbnRhaW5lciA9IChjb250YWluZXIpID0+IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE2LmNyZWF0ZUVsZW1lbnQocm93Q29udGFpbmVyQ29tcF9kZWZhdWx0LCB7IG5hbWU6IGNvbnRhaW5lciwga2V5OiBgJHtjb250YWluZXJ9LWNvbnRhaW5lcmAgfSk7XG4gIGNvbnN0IGNyZWF0ZVNlY3Rpb24gPSAoe1xuICAgIHNlY3Rpb24sXG4gICAgY2hpbGRyZW4sXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlXG4gIH0pID0+IC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE2LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IHNlY3Rpb24sIGNsYXNzTmFtZSwgcm9sZTogXCJwcmVzZW50YXRpb25cIiwgc3R5bGUgfSwgY2hpbGRyZW4ubWFwKGNyZWF0ZVJvd0NvbnRhaW5lcikpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTYuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHJlZjogc2V0UmVmMiwgY2xhc3NOYW1lOiByb290Q2xhc3NlcyB9LCAvKiBAX19QVVJFX18gKi8gUmVhY3QxNi5jcmVhdGVFbGVtZW50KGdyaWRIZWFkZXJDb21wX2RlZmF1bHQsIG51bGwpLCBjcmVhdGVTZWN0aW9uKHtcbiAgICBzZWN0aW9uOiBlVG9wLFxuICAgIGNsYXNzTmFtZTogdG9wQ2xhc3NlcyxcbiAgICBzdHlsZTogdG9wU3R5bGUsXG4gICAgY2hpbGRyZW46IFtcInRvcExlZnRcIiwgXCJ0b3BDZW50ZXJcIiwgXCJ0b3BSaWdodFwiLCBcInRvcEZ1bGxXaWR0aFwiXVxuICB9KSwgLyogQF9fUFVSRV9fICovIFJlYWN0MTYuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogYm9keUNsYXNzZXMsIHJlZjogZUJvZHksIHJvbGU6IFwicHJlc2VudGF0aW9uXCIgfSwgY3JlYXRlU2VjdGlvbih7XG4gICAgc2VjdGlvbjogZUJvZHlWaWV3cG9ydCxcbiAgICBjbGFzc05hbWU6IGJvZHlWaWV3cG9ydENsYXNzZXMsXG4gICAgY2hpbGRyZW46IFtcImxlZnRcIiwgXCJjZW50ZXJcIiwgXCJyaWdodFwiLCBcImZ1bGxXaWR0aFwiXVxuICB9KSksIGNyZWF0ZVNlY3Rpb24oe1xuICAgIHNlY3Rpb246IGVTdGlja3lUb3AsXG4gICAgY2xhc3NOYW1lOiBzdGlja3lUb3BDbGFzc2VzLFxuICAgIHN0eWxlOiBzdGlja3lUb3BTdHlsZSxcbiAgICBjaGlsZHJlbjogW1wic3RpY2t5VG9wTGVmdFwiLCBcInN0aWNreVRvcENlbnRlclwiLCBcInN0aWNreVRvcFJpZ2h0XCIsIFwic3RpY2t5VG9wRnVsbFdpZHRoXCJdXG4gIH0pLCBjcmVhdGVTZWN0aW9uKHtcbiAgICBzZWN0aW9uOiBlU3RpY2t5Qm90dG9tLFxuICAgIGNsYXNzTmFtZTogc3RpY2t5Qm90dG9tQ2xhc3NlcyxcbiAgICBzdHlsZTogc3RpY2t5Qm90dG9tU3R5bGUsXG4gICAgY2hpbGRyZW46IFtcInN0aWNreUJvdHRvbUxlZnRcIiwgXCJzdGlja3lCb3R0b21DZW50ZXJcIiwgXCJzdGlja3lCb3R0b21SaWdodFwiLCBcInN0aWNreUJvdHRvbUZ1bGxXaWR0aFwiXVxuICB9KSwgY3JlYXRlU2VjdGlvbih7XG4gICAgc2VjdGlvbjogZUJvdHRvbSxcbiAgICBjbGFzc05hbWU6IGJvdHRvbUNsYXNzZXMsXG4gICAgc3R5bGU6IGJvdHRvbVN0eWxlLFxuICAgIGNoaWxkcmVuOiBbXCJib3R0b21MZWZ0XCIsIFwiYm90dG9tQ2VudGVyXCIsIFwiYm90dG9tUmlnaHRcIiwgXCJib3R0b21GdWxsV2lkdGhcIl1cbiAgfSkpO1xufTtcbnZhciBncmlkQm9keUNvbXBfZGVmYXVsdCA9IG1lbW8xMihHcmlkQm9keUNvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL3RhYkd1YXJkQ29tcC50c3hcbmltcG9ydCBSZWFjdDE3LCB7IGZvcndhcmRSZWYgYXMgZm9yd2FyZFJlZjIsIG1lbW8gYXMgbWVtbzEzLCB1c2VDYWxsYmFjayBhcyB1c2VDYWxsYmFjazEzLCB1c2VDb250ZXh0IGFzIHVzZUNvbnRleHQxNCwgdXNlSW1wZXJhdGl2ZUhhbmRsZSBhcyB1c2VJbXBlcmF0aXZlSGFuZGxlMiwgdXNlUmVmIGFzIHVzZVJlZjE0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBUYWJHdWFyZENsYXNzTmFtZXMsIFRhYkd1YXJkQ3RybCB9IGZyb20gXCJhZy1ncmlkLWNvbW11bml0eVwiO1xudmFyIFRhYkd1YXJkQ29tcFJlZiA9IChwcm9wcywgZm9yd2FyZFJlZjQpID0+IHtcbiAgY29uc3QgeyBjaGlsZHJlbiwgZUZvY3VzYWJsZUVsZW1lbnQsIG9uVGFiS2V5RG93biwgZ3JpZEN0cmwsIGZvcmNlRm9jdXNPdXRXaGVuVGFiR3VhcmRzQXJlRW1wdHksIGlzRW1wdHkgfSA9IHByb3BzO1xuICBjb25zdCB7IGNvbnRleHQgfSA9IHVzZUNvbnRleHQxNChCZWFuc0NvbnRleHQpO1xuICBjb25zdCB0b3BUYWJHdWFyZFJlZiA9IHVzZVJlZjE0KG51bGwpO1xuICBjb25zdCBib3R0b21UYWJHdWFyZFJlZiA9IHVzZVJlZjE0KG51bGwpO1xuICBjb25zdCB0YWJHdWFyZEN0cmxSZWYgPSB1c2VSZWYxNCgpO1xuICBjb25zdCBzZXRUYWJJbmRleCA9ICh2YWx1ZSkgPT4ge1xuICAgIGNvbnN0IHByb2Nlc3NlZFZhbHVlID0gdmFsdWUgPT0gbnVsbCA/IHZvaWQgMCA6IHBhcnNlSW50KHZhbHVlLCAxMCkudG9TdHJpbmcoKTtcbiAgICBmb3IgKGNvbnN0IHRhYkd1YXJkIG9mIFt0b3BUYWJHdWFyZFJlZiwgYm90dG9tVGFiR3VhcmRSZWZdKSB7XG4gICAgICBpZiAocHJvY2Vzc2VkVmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgICB0YWJHdWFyZC5jdXJyZW50Py5yZW1vdmVBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRhYkd1YXJkLmN1cnJlbnQ/LnNldEF0dHJpYnV0ZShcInRhYmluZGV4XCIsIHByb2Nlc3NlZFZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHVzZUltcGVyYXRpdmVIYW5kbGUyKGZvcndhcmRSZWY0LCAoKSA9PiAoe1xuICAgIGZvcmNlRm9jdXNPdXRPZkNvbnRhaW5lcih1cCkge1xuICAgICAgdGFiR3VhcmRDdHJsUmVmLmN1cnJlbnQ/LmZvcmNlRm9jdXNPdXRPZkNvbnRhaW5lcih1cCk7XG4gICAgfVxuICB9KSk7XG4gIGNvbnN0IHNldHVwQ3RybCA9IHVzZUNhbGxiYWNrMTMoKCkgPT4ge1xuICAgIGNvbnN0IHRvcFRhYkd1YXJkID0gdG9wVGFiR3VhcmRSZWYuY3VycmVudDtcbiAgICBjb25zdCBib3R0b21UYWJHdWFyZCA9IGJvdHRvbVRhYkd1YXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCF0b3BUYWJHdWFyZCAmJiAhYm90dG9tVGFiR3VhcmQgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICB0YWJHdWFyZEN0cmxSZWYuY3VycmVudCA9IGNvbnRleHQuZGVzdHJveUJlYW4odGFiR3VhcmRDdHJsUmVmLmN1cnJlbnQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodG9wVGFiR3VhcmQgJiYgYm90dG9tVGFiR3VhcmQpIHtcbiAgICAgIGNvbnN0IGNvbXBQcm94eSA9IHtcbiAgICAgICAgc2V0VGFiSW5kZXhcbiAgICAgIH07XG4gICAgICB0YWJHdWFyZEN0cmxSZWYuY3VycmVudCA9IGNvbnRleHQuY3JlYXRlQmVhbihcbiAgICAgICAgbmV3IFRhYkd1YXJkQ3RybCh7XG4gICAgICAgICAgY29tcDogY29tcFByb3h5LFxuICAgICAgICAgIGVUb3BHdWFyZDogdG9wVGFiR3VhcmQsXG4gICAgICAgICAgZUJvdHRvbUd1YXJkOiBib3R0b21UYWJHdWFyZCxcbiAgICAgICAgICBlRm9jdXNhYmxlRWxlbWVudCxcbiAgICAgICAgICBvblRhYktleURvd24sXG4gICAgICAgICAgZm9yY2VGb2N1c091dFdoZW5UYWJHdWFyZHNBcmVFbXB0eSxcbiAgICAgICAgICBmb2N1c0lubmVyRWxlbWVudDogKGZyb21Cb3R0b20pID0+IGdyaWRDdHJsLmZvY3VzSW5uZXJFbGVtZW50KGZyb21Cb3R0b20pLFxuICAgICAgICAgIGlzRW1wdHlcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGNvbnN0IHNldFRvcFJlZiA9IHVzZUNhbGxiYWNrMTMoXG4gICAgKGUpID0+IHtcbiAgICAgIHRvcFRhYkd1YXJkUmVmLmN1cnJlbnQgPSBlO1xuICAgICAgc2V0dXBDdHJsKCk7XG4gICAgfSxcbiAgICBbc2V0dXBDdHJsXVxuICApO1xuICBjb25zdCBzZXRCb3R0b21SZWYgPSB1c2VDYWxsYmFjazEzKFxuICAgIChlKSA9PiB7XG4gICAgICBib3R0b21UYWJHdWFyZFJlZi5jdXJyZW50ID0gZTtcbiAgICAgIHNldHVwQ3RybCgpO1xuICAgIH0sXG4gICAgW3NldHVwQ3RybF1cbiAgKTtcbiAgY29uc3QgY3JlYXRlVGFiR3VhcmQgPSAoc2lkZSkgPT4ge1xuICAgIGNvbnN0IGNsYXNzTmFtZSA9IHNpZGUgPT09IFwidG9wXCIgPyBUYWJHdWFyZENsYXNzTmFtZXMuVEFCX0dVQVJEX1RPUCA6IFRhYkd1YXJkQ2xhc3NOYW1lcy5UQUJfR1VBUkRfQk9UVE9NO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3QxNy5jcmVhdGVFbGVtZW50KFxuICAgICAgXCJkaXZcIixcbiAgICAgIHtcbiAgICAgICAgY2xhc3NOYW1lOiBgJHtUYWJHdWFyZENsYXNzTmFtZXMuVEFCX0dVQVJEfSAke2NsYXNzTmFtZX1gLFxuICAgICAgICByb2xlOiBcInByZXNlbnRhdGlvblwiLFxuICAgICAgICByZWY6IHNpZGUgPT09IFwidG9wXCIgPyBzZXRUb3BSZWYgOiBzZXRCb3R0b21SZWZcbiAgICAgIH1cbiAgICApO1xuICB9O1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTcuY3JlYXRlRWxlbWVudChSZWFjdDE3LkZyYWdtZW50LCBudWxsLCBjcmVhdGVUYWJHdWFyZChcInRvcFwiKSwgY2hpbGRyZW4sIGNyZWF0ZVRhYkd1YXJkKFwiYm90dG9tXCIpKTtcbn07XG52YXIgVGFiR3VhcmRDb21wID0gZm9yd2FyZFJlZjIoVGFiR3VhcmRDb21wUmVmKTtcbnZhciB0YWJHdWFyZENvbXBfZGVmYXVsdCA9IG1lbW8xMyhUYWJHdWFyZENvbXApO1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9yZWFjdFVpL2dyaWRDb21wLnRzeFxudmFyIEdyaWRDb21wID0gKHsgY29udGV4dCB9KSA9PiB7XG4gIGNvbnN0IFtydGxDbGFzcywgc2V0UnRsQ2xhc3NdID0gdXNlU3RhdGUxNShcIlwiKTtcbiAgY29uc3QgW2xheW91dENsYXNzLCBzZXRMYXlvdXRDbGFzc10gPSB1c2VTdGF0ZTE1KFwiXCIpO1xuICBjb25zdCBbY3Vyc29yLCBzZXRDdXJzb3JdID0gdXNlU3RhdGUxNShudWxsKTtcbiAgY29uc3QgW3VzZXJTZWxlY3QsIHNldFVzZXJTZWxlY3RdID0gdXNlU3RhdGUxNShudWxsKTtcbiAgY29uc3QgW2luaXRpYWxpc2VkLCBzZXRJbml0aWFsaXNlZF0gPSB1c2VTdGF0ZTE1KGZhbHNlKTtcbiAgY29uc3QgW3RhYkd1YXJkUmVhZHksIHNldFRhYkd1YXJkUmVhZHldID0gdXNlU3RhdGUxNSgpO1xuICBjb25zdCBncmlkQ3RybFJlZiA9IHVzZVJlZjE1KCk7XG4gIGNvbnN0IGVSb290V3JhcHBlclJlZiA9IHVzZVJlZjE1KG51bGwpO1xuICBjb25zdCB0YWJHdWFyZFJlZiA9IHVzZVJlZjE1KCk7XG4gIGNvbnN0IFtlR3JpZEJvZHlQYXJlbnQsIHNldEdyaWRCb2R5UGFyZW50XSA9IHVzZVN0YXRlMTUobnVsbCk7XG4gIGNvbnN0IGZvY3VzSW5uZXJFbGVtZW50UmVmID0gdXNlUmVmMTUoKCkgPT4gdm9pZCAwKTtcbiAgY29uc3QgcGFnaW5hdGlvbkNvbXBSZWYgPSB1c2VSZWYxNSgpO1xuICBjb25zdCBmb2N1c2FibGVDb250YWluZXJzUmVmID0gdXNlUmVmMTUoW10pO1xuICBjb25zdCBvblRhYktleURvd24gPSB1c2VDYWxsYmFjazE0KCgpID0+IHZvaWQgMCwgW10pO1xuICByZWFjdENvbW1lbnRfZGVmYXVsdChcIiBBRyBHcmlkIFwiLCBlUm9vdFdyYXBwZXJSZWYpO1xuICBjb25zdCBzZXRSZWYyID0gdXNlQ2FsbGJhY2sxNCgoZVJlZikgPT4ge1xuICAgIGVSb290V3JhcHBlclJlZi5jdXJyZW50ID0gZVJlZjtcbiAgICBncmlkQ3RybFJlZi5jdXJyZW50ID0gZVJlZiA/IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgR3JpZEN0cmwoKSkgOiBjb250ZXh0LmRlc3Ryb3lCZWFuKGdyaWRDdHJsUmVmLmN1cnJlbnQpO1xuICAgIGlmICghZVJlZiB8fCBjb250ZXh0LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZ3JpZEN0cmwgPSBncmlkQ3RybFJlZi5jdXJyZW50O1xuICAgIGZvY3VzSW5uZXJFbGVtZW50UmVmLmN1cnJlbnQgPSBncmlkQ3RybC5mb2N1c0lubmVyRWxlbWVudC5iaW5kKGdyaWRDdHJsKTtcbiAgICBjb25zdCBjb21wUHJveHkgPSB7XG4gICAgICBkZXN0cm95R3JpZFVpOiAoKSA9PiB7XG4gICAgICB9LFxuICAgICAgLy8gZG8gbm90aGluZywgYXMgZnJhbWV3b3JrIHVzZXJzIGRlc3Ryb3kgZ3JpZCBieSByZW1vdmluZyB0aGUgY29tcFxuICAgICAgc2V0UnRsQ2xhc3MsXG4gICAgICBmb3JjZUZvY3VzT3V0T2ZDb250YWluZXI6ICh1cCkgPT4ge1xuICAgICAgICBpZiAoIXVwICYmIHBhZ2luYXRpb25Db21wUmVmLmN1cnJlbnQ/LmlzRGlzcGxheWVkKCkpIHtcbiAgICAgICAgICBwYWdpbmF0aW9uQ29tcFJlZi5jdXJyZW50LmZvcmNlRm9jdXNPdXRPZkNvbnRhaW5lcih1cCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRhYkd1YXJkUmVmLmN1cnJlbnQ/LmZvcmNlRm9jdXNPdXRPZkNvbnRhaW5lcih1cCk7XG4gICAgICB9LFxuICAgICAgdXBkYXRlTGF5b3V0Q2xhc3Nlczogc2V0TGF5b3V0Q2xhc3MsXG4gICAgICBnZXRGb2N1c2FibGVDb250YWluZXJzOiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbXBzID0gW107XG4gICAgICAgIGNvbnN0IGdyaWRCb2R5Q29tcEVsID0gZVJvb3RXcmFwcGVyUmVmLmN1cnJlbnQ/LnF1ZXJ5U2VsZWN0b3IoXCIuYWctcm9vdFwiKTtcbiAgICAgICAgaWYgKGdyaWRCb2R5Q29tcEVsKSB7XG4gICAgICAgICAgY29tcHMucHVzaCh7IGdldEd1aTogKCkgPT4gZ3JpZEJvZHlDb21wRWwgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBjb21wIG9mIGZvY3VzYWJsZUNvbnRhaW5lcnNSZWYuY3VycmVudCkge1xuICAgICAgICAgIGlmIChjb21wLmlzRGlzcGxheWVkKCkpIHtcbiAgICAgICAgICAgIGNvbXBzLnB1c2goY29tcCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb21wcztcbiAgICAgIH0sXG4gICAgICBzZXRDdXJzb3IsXG4gICAgICBzZXRVc2VyU2VsZWN0XG4gICAgfTtcbiAgICBncmlkQ3RybC5zZXRDb21wKGNvbXBQcm94eSwgZVJlZiwgZVJlZik7XG4gICAgc2V0SW5pdGlhbGlzZWQodHJ1ZSk7XG4gIH0sIFtdKTtcbiAgdXNlRWZmZWN0OSgoKSA9PiB7XG4gICAgY29uc3QgZ3JpZEN0cmwgPSBncmlkQ3RybFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGVSb290V3JhcHBlciA9IGVSb290V3JhcHBlclJlZi5jdXJyZW50O1xuICAgIGlmICghdGFiR3VhcmRSZWFkeSB8fCAhZ3JpZEN0cmwgfHwgIWVHcmlkQm9keVBhcmVudCB8fCAhZVJvb3RXcmFwcGVyIHx8IGNvbnRleHQuaXNEZXN0cm95ZWQoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBiZWFuc1RvRGVzdHJveSA9IFtdO1xuICAgIGNvbnN0IHtcbiAgICAgIHdhdGVybWFya1NlbGVjdG9yLFxuICAgICAgcGFnaW5hdGlvblNlbGVjdG9yLFxuICAgICAgc2lkZUJhclNlbGVjdG9yLFxuICAgICAgc3RhdHVzQmFyU2VsZWN0b3IsXG4gICAgICBncmlkSGVhZGVyRHJvcFpvbmVzU2VsZWN0b3JcbiAgICB9ID0gZ3JpZEN0cmwuZ2V0T3B0aW9uYWxTZWxlY3RvcnMoKTtcbiAgICBjb25zdCBhZGRpdGlvbmFsRWxzID0gW107XG4gICAgaWYgKGdyaWRIZWFkZXJEcm9wWm9uZXNTZWxlY3Rvcikge1xuICAgICAgY29uc3QgaGVhZGVyRHJvcFpvbmVzQ29tcCA9IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgZ3JpZEhlYWRlckRyb3Bab25lc1NlbGVjdG9yLmNvbXBvbmVudCgpKTtcbiAgICAgIGNvbnN0IGVHdWkgPSBoZWFkZXJEcm9wWm9uZXNDb21wLmdldEd1aSgpO1xuICAgICAgZVJvb3RXcmFwcGVyLmluc2VydEFkamFjZW50RWxlbWVudChcImFmdGVyYmVnaW5cIiwgZUd1aSk7XG4gICAgICBhZGRpdGlvbmFsRWxzLnB1c2goZUd1aSk7XG4gICAgICBiZWFuc1RvRGVzdHJveS5wdXNoKGhlYWRlckRyb3Bab25lc0NvbXApO1xuICAgIH1cbiAgICBpZiAoc2lkZUJhclNlbGVjdG9yKSB7XG4gICAgICBjb25zdCBzaWRlQmFyQ29tcCA9IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgc2lkZUJhclNlbGVjdG9yLmNvbXBvbmVudCgpKTtcbiAgICAgIGNvbnN0IGVHdWkgPSBzaWRlQmFyQ29tcC5nZXRHdWkoKTtcbiAgICAgIGNvbnN0IGJvdHRvbVRhYkd1YXJkID0gZUdyaWRCb2R5UGFyZW50LnF1ZXJ5U2VsZWN0b3IoXCIuYWctdGFiLWd1YXJkLWJvdHRvbVwiKTtcbiAgICAgIGlmIChib3R0b21UYWJHdWFyZCkge1xuICAgICAgICBib3R0b21UYWJHdWFyZC5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJiZWZvcmViZWdpblwiLCBlR3VpKTtcbiAgICAgICAgYWRkaXRpb25hbEVscy5wdXNoKGVHdWkpO1xuICAgICAgfVxuICAgICAgYmVhbnNUb0Rlc3Ryb3kucHVzaChzaWRlQmFyQ29tcCk7XG4gICAgICBmb2N1c2FibGVDb250YWluZXJzUmVmLmN1cnJlbnQucHVzaChzaWRlQmFyQ29tcCk7XG4gICAgfVxuICAgIGNvbnN0IGFkZENvbXBvbmVudFRvRG9tID0gKGNvbXBvbmVudCkgPT4ge1xuICAgICAgY29uc3QgY29tcCA9IGNvbnRleHQuY3JlYXRlQmVhbihuZXcgY29tcG9uZW50KCkpO1xuICAgICAgY29uc3QgZUd1aSA9IGNvbXAuZ2V0R3VpKCk7XG4gICAgICBlUm9vdFdyYXBwZXIuaW5zZXJ0QWRqYWNlbnRFbGVtZW50KFwiYmVmb3JlZW5kXCIsIGVHdWkpO1xuICAgICAgYWRkaXRpb25hbEVscy5wdXNoKGVHdWkpO1xuICAgICAgYmVhbnNUb0Rlc3Ryb3kucHVzaChjb21wKTtcbiAgICAgIHJldHVybiBjb21wO1xuICAgIH07XG4gICAgaWYgKHN0YXR1c0JhclNlbGVjdG9yKSB7XG4gICAgICBhZGRDb21wb25lbnRUb0RvbShzdGF0dXNCYXJTZWxlY3Rvci5jb21wb25lbnQpO1xuICAgIH1cbiAgICBpZiAocGFnaW5hdGlvblNlbGVjdG9yKSB7XG4gICAgICBjb25zdCBwYWdpbmF0aW9uQ29tcCA9IGFkZENvbXBvbmVudFRvRG9tKHBhZ2luYXRpb25TZWxlY3Rvci5jb21wb25lbnQpO1xuICAgICAgcGFnaW5hdGlvbkNvbXBSZWYuY3VycmVudCA9IHBhZ2luYXRpb25Db21wO1xuICAgICAgZm9jdXNhYmxlQ29udGFpbmVyc1JlZi5jdXJyZW50LnB1c2gocGFnaW5hdGlvbkNvbXApO1xuICAgIH1cbiAgICBpZiAod2F0ZXJtYXJrU2VsZWN0b3IpIHtcbiAgICAgIGFkZENvbXBvbmVudFRvRG9tKHdhdGVybWFya1NlbGVjdG9yLmNvbXBvbmVudCk7XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb250ZXh0LmRlc3Ryb3lCZWFucyhiZWFuc1RvRGVzdHJveSk7XG4gICAgICBmb3IgKGNvbnN0IGVsIG9mIGFkZGl0aW9uYWxFbHMpIHtcbiAgICAgICAgZWwucmVtb3ZlKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW3RhYkd1YXJkUmVhZHksIGVHcmlkQm9keVBhcmVudCwgY29udGV4dF0pO1xuICBjb25zdCByb290V3JhcHBlckNsYXNzZXMgPSB1c2VNZW1vMTIoXG4gICAgKCkgPT4gY2xhc3Nlc0xpc3QoXCJhZy1yb290LXdyYXBwZXJcIiwgcnRsQ2xhc3MsIGxheW91dENsYXNzKSxcbiAgICBbcnRsQ2xhc3MsIGxheW91dENsYXNzXVxuICApO1xuICBjb25zdCByb290V3JhcHBlckJvZHlDbGFzc2VzID0gdXNlTWVtbzEyKFxuICAgICgpID0+IGNsYXNzZXNMaXN0KFwiYWctcm9vdC13cmFwcGVyLWJvZHlcIiwgXCJhZy1mb2N1cy1tYW5hZ2VkXCIsIGxheW91dENsYXNzKSxcbiAgICBbbGF5b3V0Q2xhc3NdXG4gICk7XG4gIGNvbnN0IHRvcFN0eWxlID0gdXNlTWVtbzEyKFxuICAgICgpID0+ICh7XG4gICAgICB1c2VyU2VsZWN0OiB1c2VyU2VsZWN0ICE9IG51bGwgPyB1c2VyU2VsZWN0IDogXCJcIixcbiAgICAgIFdlYmtpdFVzZXJTZWxlY3Q6IHVzZXJTZWxlY3QgIT0gbnVsbCA/IHVzZXJTZWxlY3QgOiBcIlwiLFxuICAgICAgY3Vyc29yOiBjdXJzb3IgIT0gbnVsbCA/IGN1cnNvciA6IFwiXCJcbiAgICB9KSxcbiAgICBbdXNlclNlbGVjdCwgY3Vyc29yXVxuICApO1xuICBjb25zdCBzZXRUYWJHdWFyZENvbXBSZWYgPSB1c2VDYWxsYmFjazE0KChyZWYpID0+IHtcbiAgICB0YWJHdWFyZFJlZi5jdXJyZW50ID0gcmVmO1xuICAgIHNldFRhYkd1YXJkUmVhZHkocmVmICE9PSBudWxsKTtcbiAgfSwgW10pO1xuICBjb25zdCBpc0ZvY3VzYWJsZSA9IHVzZUNhbGxiYWNrMTQoKCkgPT4gIWdyaWRDdHJsUmVmLmN1cnJlbnQ/LmlzRm9jdXNhYmxlKCksIFtdKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE4LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyByZWY6IHNldFJlZjIsIGNsYXNzTmFtZTogcm9vdFdyYXBwZXJDbGFzc2VzLCBzdHlsZTogdG9wU3R5bGUsIHJvbGU6IFwicHJlc2VudGF0aW9uXCIgfSwgLyogQF9fUFVSRV9fICovIFJlYWN0MTguY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IGNsYXNzTmFtZTogcm9vdFdyYXBwZXJCb2R5Q2xhc3NlcywgcmVmOiBzZXRHcmlkQm9keVBhcmVudCwgcm9sZTogXCJwcmVzZW50YXRpb25cIiB9LCBpbml0aWFsaXNlZCAmJiBlR3JpZEJvZHlQYXJlbnQgJiYgIWNvbnRleHQuaXNEZXN0cm95ZWQoKSAmJiAvKiBAX19QVVJFX18gKi8gUmVhY3QxOC5jcmVhdGVFbGVtZW50KEJlYW5zQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogY29udGV4dC5nZXRCZWFucygpIH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE4LmNyZWF0ZUVsZW1lbnQoXG4gICAgdGFiR3VhcmRDb21wX2RlZmF1bHQsXG4gICAge1xuICAgICAgcmVmOiBzZXRUYWJHdWFyZENvbXBSZWYsXG4gICAgICBlRm9jdXNhYmxlRWxlbWVudDogZUdyaWRCb2R5UGFyZW50LFxuICAgICAgb25UYWJLZXlEb3duLFxuICAgICAgZ3JpZEN0cmw6IGdyaWRDdHJsUmVmLmN1cnJlbnQsXG4gICAgICBmb3JjZUZvY3VzT3V0V2hlblRhYkd1YXJkc0FyZUVtcHR5OiB0cnVlLFxuICAgICAgaXNFbXB0eTogaXNGb2N1c2FibGVcbiAgICB9LFxuICAgIC8vIHdlIHdhaXQgZm9yIGluaXRpYWxpc2VkIGJlZm9yZSByZW5kaW5nIHRoZSBjaGlsZHJlbiwgc28gR3JpZENvbXAgaGFzIGNyZWF0ZWQgYW5kIHJlZ2lzdGVyZWQgd2l0aCBpdCdzXG4gICAgLy8gR3JpZEN0cmwgYmVmb3JlIHdlIGNyZWF0ZSB0aGUgY2hpbGQgR3JpZEJvZHlDb21wLiBPdGhlcndpc2UgdGhlIEdyaWRCb2R5Q29tcCB3b3VsZCBpbml0aWFsaXNlIGZpcnN0LFxuICAgIC8vIGJlZm9yZSB3ZSBoYXZlIHNldCB0aGUgdGhlIExheW91dCBDU1MgY2xhc3NlcywgY2F1c2luZyB0aGUgR3JpZEJvZHlDb21wIHRvIHJlbmRlciByb3dzIHRvIGEgZ3JpZCB0aGF0XG4gICAgLy8gZG9lc24ndCBoYXZlIGl0J3MgaGVpZ2h0IHNwZWNpZmllZCwgd2hpY2ggd291bGQgcmVzdWx0IGlmIGFsbCB0aGUgcm93cyBnZXR0aW5nIHJlbmRlcmVkIChhbmQgaWYgbWFueSByb3dzLFxuICAgIC8vIGhhbmdzIHRoZSBVSSlcbiAgICAvKiBAX19QVVJFX18gKi8gUmVhY3QxOC5jcmVhdGVFbGVtZW50KGdyaWRCb2R5Q29tcF9kZWZhdWx0LCBudWxsKVxuICApKSkpO1xufTtcbnZhciBncmlkQ29tcF9kZWZhdWx0ID0gbWVtbzE0KEdyaWRDb21wKTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvcmVhY3RVaS9yZW5kZXJTdGF0dXNTZXJ2aWNlLnRzeFxuaW1wb3J0IHsgQmVhblN0dWIgfSBmcm9tIFwiYWctZ3JpZC1jb21tdW5pdHlcIjtcbnZhciBSZW5kZXJTdGF0dXNTZXJ2aWNlID0gY2xhc3MgZXh0ZW5kcyBCZWFuU3R1YiB7XG4gIHBvc3RDb25zdHJ1Y3QoKSB7XG4gICAgaWYgKHRoaXMuYmVhbnMuY29sQXV0b3NpemUpIHtcbiAgICAgIGNvbnN0IHF1ZXVlUmVzaXplT3BlcmF0aW9uc0ZvclRpY2sgPSB0aGlzLnF1ZXVlUmVzaXplT3BlcmF0aW9uc0ZvclRpY2suYmluZCh0aGlzKTtcbiAgICAgIHRoaXMuYWRkTWFuYWdlZEV2ZW50TGlzdGVuZXJzKHtcbiAgICAgICAgcm93RXhwYW5zaW9uU3RhdGVDaGFuZ2VkOiBxdWV1ZVJlc2l6ZU9wZXJhdGlvbnNGb3JUaWNrLFxuICAgICAgICBleHBhbmRPckNvbGxhcHNlQWxsOiBxdWV1ZVJlc2l6ZU9wZXJhdGlvbnNGb3JUaWNrLFxuICAgICAgICAvLyBFbmFibGUgZGV2cyB0byByZXNpemUgYWZ0ZXIgdGhleSB1cGRhdGVkIHZpYSB0aGUgQVBJXG4gICAgICAgIGNlbGxWYWx1ZUNoYW5nZWQ6IHF1ZXVlUmVzaXplT3BlcmF0aW9uc0ZvclRpY2ssXG4gICAgICAgIHJvd05vZGVEYXRhQ2hhbmdlZDogcXVldWVSZXNpemVPcGVyYXRpb25zRm9yVGljayxcbiAgICAgICAgcm93RGF0YVVwZGF0ZWQ6IHF1ZXVlUmVzaXplT3BlcmF0aW9uc0ZvclRpY2tcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBxdWV1ZVJlc2l6ZU9wZXJhdGlvbnNGb3JUaWNrKCkge1xuICAgIGNvbnN0IGNvbEF1dG9zaXplID0gdGhpcy5iZWFucy5jb2xBdXRvc2l6ZTtcbiAgICBjb2xBdXRvc2l6ZS5zaG91bGRRdWV1ZVJlc2l6ZU9wZXJhdGlvbnMgPSB0cnVlO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29sQXV0b3NpemUucHJvY2Vzc1Jlc2l6ZU9wZXJhdGlvbnMoKTtcbiAgICB9LCAwKTtcbiAgfVxuICBhcmVIZWFkZXJDZWxsc1JlbmRlcmVkKCkge1xuICAgIHJldHVybiB0aGlzLmJlYW5zLmN0cmxzU3ZjLmdldEhlYWRlclJvd0NvbnRhaW5lckN0cmxzKCkuZXZlcnkoKGNvbnRhaW5lcikgPT4gY29udGFpbmVyLmdldEFsbEN0cmxzKCkuZXZlcnkoKGN0cmwpID0+IGN0cmwuYXJlQ2VsbHNSZW5kZXJlZCgpKSk7XG4gIH1cbiAgYXJlQ2VsbHNSZW5kZXJlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5iZWFucy5yb3dSZW5kZXJlci5nZXRBbGxSb3dDdHJscygpLmV2ZXJ5KChyb3cpID0+IHJvdy5pc1Jvd1JlbmRlcmVkKCkgJiYgcm93LmdldEFsbENlbGxDdHJscygpLmV2ZXJ5KChjZWxsQ3RybCkgPT4gISFjZWxsQ3RybC5lR3VpKSk7XG4gIH1cbn07XG5cbi8vIHBhY2thZ2VzL2FnLWdyaWQtcmVhY3Qvc3JjL3JlYWN0VWkvYWdHcmlkUmVhY3RVaS50c3hcbnZhciBkZXByZWNhdGVkUHJvcHMgPSB7XG4gIHNldEdyaWRBcGk6IHZvaWQgMCxcbiAgbWF4Q29tcG9uZW50Q3JlYXRpb25UaW1lTXM6IHZvaWQgMCxcbiAgY2hpbGRyZW46IHZvaWQgMFxufTtcbnZhciByZWFjdFByb3BzTm90R3JpZE9wdGlvbnMgPSB7XG4gIGdyaWRPcHRpb25zOiB2b2lkIDAsXG4gIG1vZHVsZXM6IHZvaWQgMCxcbiAgY29udGFpbmVyU3R5bGU6IHZvaWQgMCxcbiAgY2xhc3NOYW1lOiB2b2lkIDAsXG4gIHBhc3NHcmlkQXBpOiB2b2lkIDAsXG4gIGNvbXBvbmVudFdyYXBwaW5nRWxlbWVudDogdm9pZCAwLFxuICAuLi5kZXByZWNhdGVkUHJvcHNcbn07XG52YXIgZXhjbHVkZVJlYWN0Q29tcFByb3BzID0gbmV3IFNldChPYmplY3Qua2V5cyhyZWFjdFByb3BzTm90R3JpZE9wdGlvbnMpKTtcbnZhciBkZXByZWNhdGVkUmVhY3RDb21wUHJvcHMgPSBuZXcgU2V0KE9iamVjdC5rZXlzKGRlcHJlY2F0ZWRQcm9wcykpO1xudmFyIEFnR3JpZFJlYWN0VWkgPSAocHJvcHMpID0+IHtcbiAgY29uc3QgYXBpUmVmID0gdXNlUmVmMTYoKTtcbiAgY29uc3QgZUd1aSA9IHVzZVJlZjE2KG51bGwpO1xuICBjb25zdCBwb3J0YWxNYW5hZ2VyID0gdXNlUmVmMTYobnVsbCk7XG4gIGNvbnN0IGRlc3Ryb3lGdW5jcyA9IHVzZVJlZjE2KFtdKTtcbiAgY29uc3Qgd2hlblJlYWR5RnVuY3MgPSB1c2VSZWYxNihbXSk7XG4gIGNvbnN0IHByZXZQcm9wcyA9IHVzZVJlZjE2KHByb3BzKTtcbiAgY29uc3QgZnJhbWV3b3JrT3ZlcnJpZGVzUmVmID0gdXNlUmVmMTYoKTtcbiAgY29uc3QgZ3JpZElkUmVmID0gdXNlUmVmMTYoKTtcbiAgY29uc3QgcmVhZHkgPSB1c2VSZWYxNihmYWxzZSk7XG4gIGNvbnN0IFtjb250ZXh0LCBzZXRDb250ZXh0XSA9IHVzZVN0YXRlMTYodm9pZCAwKTtcbiAgY29uc3QgWywgc2V0UG9ydGFsUmVmcmVzaGVyXSA9IHVzZVN0YXRlMTYoMCk7XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazE1KChlUmVmKSA9PiB7XG4gICAgZUd1aS5jdXJyZW50ID0gZVJlZjtcbiAgICBpZiAoIWVSZWYpIHtcbiAgICAgIGZvciAoY29uc3QgZiBvZiBkZXN0cm95RnVuY3MuY3VycmVudCkge1xuICAgICAgICBmKCk7XG4gICAgICB9XG4gICAgICBkZXN0cm95RnVuY3MuY3VycmVudC5sZW5ndGggPSAwO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBtb2R1bGVzID0gcHJvcHMubW9kdWxlcyB8fCBbXTtcbiAgICBpZiAoIXBvcnRhbE1hbmFnZXIuY3VycmVudCkge1xuICAgICAgcG9ydGFsTWFuYWdlci5jdXJyZW50ID0gbmV3IFBvcnRhbE1hbmFnZXIoXG4gICAgICAgICgpID0+IHNldFBvcnRhbFJlZnJlc2hlcigocHJldikgPT4gcHJldiArIDEpLFxuICAgICAgICBwcm9wcy5jb21wb25lbnRXcmFwcGluZ0VsZW1lbnQsXG4gICAgICAgIHByb3BzLm1heENvbXBvbmVudENyZWF0aW9uVGltZU1zXG4gICAgICApO1xuICAgICAgZGVzdHJveUZ1bmNzLmN1cnJlbnQucHVzaCgoKSA9PiB7XG4gICAgICAgIHBvcnRhbE1hbmFnZXIuY3VycmVudD8uZGVzdHJveSgpO1xuICAgICAgICBwb3J0YWxNYW5hZ2VyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IG1lcmdlZEdyaWRPcHMgPSBfY29tYmluZUF0dHJpYnV0ZXNBbmRHcmlkT3B0aW9ucyhcbiAgICAgIHByb3BzLmdyaWRPcHRpb25zLFxuICAgICAgcHJvcHMsXG4gICAgICBPYmplY3Qua2V5cyhwcm9wcykuZmlsdGVyKChrZXkpID0+ICFleGNsdWRlUmVhY3RDb21wUHJvcHMuaGFzKGtleSkpXG4gICAgKTtcbiAgICBjb25zdCBwcm9jZXNzUXVldWVkVXBkYXRlcyA9ICgpID0+IHtcbiAgICAgIGlmIChyZWFkeS5jdXJyZW50KSB7XG4gICAgICAgIGNvbnN0IGdldEZuID0gKCkgPT4gZnJhbWV3b3JrT3ZlcnJpZGVzUmVmLmN1cnJlbnQ/LnNob3VsZFF1ZXVlVXBkYXRlcygpID8gdm9pZCAwIDogd2hlblJlYWR5RnVuY3MuY3VycmVudC5zaGlmdCgpO1xuICAgICAgICBsZXQgZm4gPSBnZXRGbigpO1xuICAgICAgICB3aGlsZSAoZm4pIHtcbiAgICAgICAgICBmbigpO1xuICAgICAgICAgIGZuID0gZ2V0Rm4oKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgZnJhbWV3b3JrT3ZlcnJpZGVzID0gbmV3IFJlYWN0RnJhbWV3b3JrT3ZlcnJpZGVzKHByb2Nlc3NRdWV1ZWRVcGRhdGVzKTtcbiAgICBmcmFtZXdvcmtPdmVycmlkZXNSZWYuY3VycmVudCA9IGZyYW1ld29ya092ZXJyaWRlcztcbiAgICBjb25zdCByZW5kZXJTdGF0dXMgPSBuZXcgUmVuZGVyU3RhdHVzU2VydmljZSgpO1xuICAgIGNvbnN0IGdyaWRQYXJhbXMgPSB7XG4gICAgICBwcm92aWRlZEJlYW5JbnN0YW5jZXM6IHtcbiAgICAgICAgZnJhbWV3b3JrQ29tcFdyYXBwZXI6IG5ldyBSZWFjdEZyYW1ld29ya0NvbXBvbmVudFdyYXBwZXIocG9ydGFsTWFuYWdlci5jdXJyZW50LCBtZXJnZWRHcmlkT3BzKSxcbiAgICAgICAgcmVuZGVyU3RhdHVzXG4gICAgICB9LFxuICAgICAgbW9kdWxlcyxcbiAgICAgIGZyYW1ld29ya092ZXJyaWRlcyxcbiAgICAgIHNldFRoZW1lT25HcmlkRGl2OiB0cnVlXG4gICAgfTtcbiAgICBjb25zdCBjcmVhdGVVaUNhbGxiYWNrID0gKGN0eCkgPT4ge1xuICAgICAgc2V0Q29udGV4dChjdHgpO1xuICAgICAgY3R4LmNyZWF0ZUJlYW4ocmVuZGVyU3RhdHVzKTtcbiAgICAgIGRlc3Ryb3lGdW5jcy5jdXJyZW50LnB1c2goKCkgPT4ge1xuICAgICAgICBjdHguZGVzdHJveSgpO1xuICAgICAgfSk7XG4gICAgICBjdHguZ2V0QmVhbihcImN0cmxzU3ZjXCIpLndoZW5SZWFkeShcbiAgICAgICAge1xuICAgICAgICAgIGFkZERlc3Ryb3lGdW5jOiAoZnVuYykgPT4ge1xuICAgICAgICAgICAgZGVzdHJveUZ1bmNzLmN1cnJlbnQucHVzaChmdW5jKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICBpZiAoY3R4LmlzRGVzdHJveWVkKCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgYXBpID0gYXBpUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgaWYgKGFwaSkge1xuICAgICAgICAgICAgcHJvcHMucGFzc0dyaWRBcGk/LihhcGkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9O1xuICAgIGNvbnN0IGFjY2VwdENoYW5nZXNDYWxsYmFjayA9IChjb250ZXh0MikgPT4ge1xuICAgICAgY29udGV4dDIuZ2V0QmVhbihcImN0cmxzU3ZjXCIpLndoZW5SZWFkeShcbiAgICAgICAge1xuICAgICAgICAgIGFkZERlc3Ryb3lGdW5jOiAoZnVuYykgPT4ge1xuICAgICAgICAgICAgZGVzdHJveUZ1bmNzLmN1cnJlbnQucHVzaChmdW5jKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGYgb2Ygd2hlblJlYWR5RnVuY3MuY3VycmVudCkge1xuICAgICAgICAgICAgZigpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB3aGVuUmVhZHlGdW5jcy5jdXJyZW50Lmxlbmd0aCA9IDA7XG4gICAgICAgICAgcmVhZHkuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfTtcbiAgICBjb25zdCBncmlkQ29yZUNyZWF0b3IgPSBuZXcgR3JpZENvcmVDcmVhdG9yKCk7XG4gICAgbWVyZ2VkR3JpZE9wcy5ncmlkSWQgPz8gKG1lcmdlZEdyaWRPcHMuZ3JpZElkID0gZ3JpZElkUmVmLmN1cnJlbnQpO1xuICAgIGFwaVJlZi5jdXJyZW50ID0gZ3JpZENvcmVDcmVhdG9yLmNyZWF0ZShcbiAgICAgIGVSZWYsXG4gICAgICBtZXJnZWRHcmlkT3BzLFxuICAgICAgY3JlYXRlVWlDYWxsYmFjayxcbiAgICAgIGFjY2VwdENoYW5nZXNDYWxsYmFjayxcbiAgICAgIGdyaWRQYXJhbXNcbiAgICApO1xuICAgIGRlc3Ryb3lGdW5jcy5jdXJyZW50LnB1c2goKCkgPT4ge1xuICAgICAgYXBpUmVmLmN1cnJlbnQgPSB2b2lkIDA7XG4gICAgfSk7XG4gICAgaWYgKGFwaVJlZi5jdXJyZW50KSB7XG4gICAgICBncmlkSWRSZWYuY3VycmVudCA9IGFwaVJlZi5jdXJyZW50LmdldEdyaWRJZCgpO1xuICAgIH1cbiAgfSwgW10pO1xuICBjb25zdCBzdHlsZSA9IHVzZU1lbW8xMygoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgICAuLi5wcm9wcy5jb250YWluZXJTdHlsZSB8fCB7fVxuICAgIH07XG4gIH0sIFtwcm9wcy5jb250YWluZXJTdHlsZV0pO1xuICBjb25zdCBwcm9jZXNzV2hlblJlYWR5ID0gdXNlQ2FsbGJhY2sxNSgoZnVuYykgPT4ge1xuICAgIGlmIChyZWFkeS5jdXJyZW50ICYmICFmcmFtZXdvcmtPdmVycmlkZXNSZWYuY3VycmVudD8uc2hvdWxkUXVldWVVcGRhdGVzKCkpIHtcbiAgICAgIGZ1bmMoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2hlblJlYWR5RnVuY3MuY3VycmVudC5wdXNoKGZ1bmMpO1xuICAgIH1cbiAgfSwgW10pO1xuICB1c2VFZmZlY3QxMCgoKSA9PiB7XG4gICAgY29uc3QgY2hhbmdlcyA9IGV4dHJhY3RHcmlkUHJvcGVydHlDaGFuZ2VzKHByZXZQcm9wcy5jdXJyZW50LCBwcm9wcyk7XG4gICAgcHJldlByb3BzLmN1cnJlbnQgPSBwcm9wcztcbiAgICBwcm9jZXNzV2hlblJlYWR5KCgpID0+IHtcbiAgICAgIGlmIChhcGlSZWYuY3VycmVudCkge1xuICAgICAgICBfcHJvY2Vzc09uQ2hhbmdlKGNoYW5nZXMsIGFwaVJlZi5jdXJyZW50KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW3Byb3BzXSk7XG4gIGNvbnN0IHJlbmRlck1vZGUgPSAhUmVhY3QxOS51c2VTeW5jRXh0ZXJuYWxTdG9yZSB8fCBfZ2V0R3JpZE9wdGlvbihwcm9wcywgXCJyZW5kZXJpbmdNb2RlXCIpID09PSBcImxlZ2FjeVwiID8gXCJsZWdhY3lcIiA6IFwiZGVmYXVsdFwiO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0MTkuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7IHN0eWxlLCBjbGFzc05hbWU6IHByb3BzLmNsYXNzTmFtZSwgcmVmOiBzZXRSZWYyIH0sIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE5LmNyZWF0ZUVsZW1lbnQoUmVuZGVyTW9kZUNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHJlbmRlck1vZGUgfSwgY29udGV4dCAmJiAhY29udGV4dC5pc0Rlc3Ryb3llZCgpID8gLyogQF9fUFVSRV9fICovIFJlYWN0MTkuY3JlYXRlRWxlbWVudChncmlkQ29tcF9kZWZhdWx0LCB7IGtleTogY29udGV4dC5pbnN0YW5jZUlkLCBjb250ZXh0IH0pIDogbnVsbCwgcG9ydGFsTWFuYWdlci5jdXJyZW50Py5nZXRQb3J0YWxzKCkgPz8gbnVsbCkpO1xufTtcbmZ1bmN0aW9uIGV4dHJhY3RHcmlkUHJvcGVydHlDaGFuZ2VzKHByZXZQcm9wcywgbmV4dFByb3BzKSB7XG4gIGNvbnN0IGNoYW5nZXMgPSB7fTtcbiAgZm9yIChjb25zdCBwcm9wS2V5IG9mIE9iamVjdC5rZXlzKG5leHRQcm9wcykpIHtcbiAgICBpZiAoZXhjbHVkZVJlYWN0Q29tcFByb3BzLmhhcyhwcm9wS2V5KSkge1xuICAgICAgaWYgKGRlcHJlY2F0ZWRSZWFjdENvbXBQcm9wcy5oYXMocHJvcEtleSkpIHtcbiAgICAgICAgX3dhcm4yKDI3NCwgeyBwcm9wOiBwcm9wS2V5IH0pO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHByb3BWYWx1ZSA9IG5leHRQcm9wc1twcm9wS2V5XTtcbiAgICBpZiAocHJldlByb3BzW3Byb3BLZXldICE9PSBwcm9wVmFsdWUpIHtcbiAgICAgIGNoYW5nZXNbcHJvcEtleV0gPSBwcm9wVmFsdWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBjaGFuZ2VzO1xufVxudmFyIFJlYWN0RnJhbWV3b3JrQ29tcG9uZW50V3JhcHBlciA9IGNsYXNzIGV4dGVuZHMgQmFzZUNvbXBvbmVudFdyYXBwZXIge1xuICBjb25zdHJ1Y3RvcihwYXJlbnQsIGdyaWRPcHRpb25zKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLnBhcmVudCA9IHBhcmVudDtcbiAgICB0aGlzLmdyaWRPcHRpb25zID0gZ3JpZE9wdGlvbnM7XG4gIH1cbiAgY3JlYXRlV3JhcHBlcihVc2VyUmVhY3RDb21wb25lbnQsIGNvbXBvbmVudFR5cGUpIHtcbiAgICBjb25zdCBncmlkT3B0aW9ucyA9IHRoaXMuZ3JpZE9wdGlvbnM7XG4gICAgY29uc3QgcmVhY3RpdmVDdXN0b21Db21wb25lbnRzID0gX2dldEdyaWRPcHRpb24oZ3JpZE9wdGlvbnMsIFwicmVhY3RpdmVDdXN0b21Db21wb25lbnRzXCIpO1xuICAgIGlmIChyZWFjdGl2ZUN1c3RvbUNvbXBvbmVudHMpIHtcbiAgICAgIGNvbnN0IGdldENvbXBvbmVudENsYXNzID0gKHByb3BlcnR5TmFtZSkgPT4ge1xuICAgICAgICBzd2l0Y2ggKHByb3BlcnR5TmFtZSkge1xuICAgICAgICAgIGNhc2UgXCJmaWx0ZXJcIjpcbiAgICAgICAgICAgIHJldHVybiBfZ2V0R3JpZE9wdGlvbihncmlkT3B0aW9ucywgXCJlbmFibGVGaWx0ZXJIYW5kbGVyc1wiKSA/IEZpbHRlckRpc3BsYXlDb21wb25lbnRXcmFwcGVyIDogRmlsdGVyQ29tcG9uZW50V3JhcHBlcjtcbiAgICAgICAgICBjYXNlIFwiZmxvYXRpbmdGaWx0ZXJDb21wb25lbnRcIjpcbiAgICAgICAgICAgIHJldHVybiBfZ2V0R3JpZE9wdGlvbihncmlkT3B0aW9ucywgXCJlbmFibGVGaWx0ZXJIYW5kbGVyc1wiKSA/IEZsb2F0aW5nRmlsdGVyRGlzcGxheUNvbXBvbmVudFdyYXBwZXIgOiBGbG9hdGluZ0ZpbHRlckNvbXBvbmVudFdyYXBwZXI7XG4gICAgICAgICAgY2FzZSBcImRhdGVDb21wb25lbnRcIjpcbiAgICAgICAgICAgIHJldHVybiBEYXRlQ29tcG9uZW50V3JhcHBlcjtcbiAgICAgICAgICBjYXNlIFwiZHJhZ0FuZERyb3BJbWFnZUNvbXBvbmVudFwiOlxuICAgICAgICAgICAgcmV0dXJuIERyYWdBbmREcm9wSW1hZ2VDb21wb25lbnRXcmFwcGVyO1xuICAgICAgICAgIGNhc2UgXCJsb2FkaW5nT3ZlcmxheUNvbXBvbmVudFwiOlxuICAgICAgICAgICAgcmV0dXJuIExvYWRpbmdPdmVybGF5Q29tcG9uZW50V3JhcHBlcjtcbiAgICAgICAgICBjYXNlIFwibm9Sb3dzT3ZlcmxheUNvbXBvbmVudFwiOlxuICAgICAgICAgICAgcmV0dXJuIE5vUm93c092ZXJsYXlDb21wb25lbnRXcmFwcGVyO1xuICAgICAgICAgIGNhc2UgXCJzdGF0dXNQYW5lbFwiOlxuICAgICAgICAgICAgcmV0dXJuIFN0YXR1c1BhbmVsQ29tcG9uZW50V3JhcHBlcjtcbiAgICAgICAgICBjYXNlIFwidG9vbFBhbmVsXCI6XG4gICAgICAgICAgICByZXR1cm4gVG9vbFBhbmVsQ29tcG9uZW50V3JhcHBlcjtcbiAgICAgICAgICBjYXNlIFwibWVudUl0ZW1cIjpcbiAgICAgICAgICAgIHJldHVybiBNZW51SXRlbUNvbXBvbmVudFdyYXBwZXI7XG4gICAgICAgICAgY2FzZSBcImNlbGxSZW5kZXJlclwiOlxuICAgICAgICAgICAgcmV0dXJuIENlbGxSZW5kZXJlckNvbXBvbmVudFdyYXBwZXI7XG4gICAgICAgICAgY2FzZSBcImlubmVySGVhZGVyQ29tcG9uZW50XCI6XG4gICAgICAgICAgICByZXR1cm4gSW5uZXJIZWFkZXJDb21wb25lbnRXcmFwcGVyO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgY29uc3QgQ29tcG9uZW50Q2xhc3MgPSBnZXRDb21wb25lbnRDbGFzcyhjb21wb25lbnRUeXBlLm5hbWUpO1xuICAgICAgaWYgKENvbXBvbmVudENsYXNzKSB7XG4gICAgICAgIHJldHVybiBuZXcgQ29tcG9uZW50Q2xhc3MoVXNlclJlYWN0Q29tcG9uZW50LCB0aGlzLnBhcmVudCwgY29tcG9uZW50VHlwZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHN3aXRjaCAoY29tcG9uZW50VHlwZS5uYW1lKSB7XG4gICAgICAgIGNhc2UgXCJmaWx0ZXJcIjpcbiAgICAgICAgY2FzZSBcImZsb2F0aW5nRmlsdGVyQ29tcG9uZW50XCI6XG4gICAgICAgIGNhc2UgXCJkYXRlQ29tcG9uZW50XCI6XG4gICAgICAgIGNhc2UgXCJkcmFnQW5kRHJvcEltYWdlQ29tcG9uZW50XCI6XG4gICAgICAgIGNhc2UgXCJsb2FkaW5nT3ZlcmxheUNvbXBvbmVudFwiOlxuICAgICAgICBjYXNlIFwibm9Sb3dzT3ZlcmxheUNvbXBvbmVudFwiOlxuICAgICAgICBjYXNlIFwic3RhdHVzUGFuZWxcIjpcbiAgICAgICAgY2FzZSBcInRvb2xQYW5lbFwiOlxuICAgICAgICBjYXNlIFwibWVudUl0ZW1cIjpcbiAgICAgICAgY2FzZSBcImNlbGxSZW5kZXJlclwiOlxuICAgICAgICAgIHdhcm5SZWFjdGl2ZUN1c3RvbUNvbXBvbmVudHMoKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc3VwcHJlc3NGYWxsYmFja01ldGhvZHMgPSAhY29tcG9uZW50VHlwZS5jZWxsUmVuZGVyZXIgJiYgY29tcG9uZW50VHlwZS5uYW1lICE9PSBcInRvb2xQYW5lbFwiO1xuICAgIHJldHVybiBuZXcgUmVhY3RDb21wb25lbnQoVXNlclJlYWN0Q29tcG9uZW50LCB0aGlzLnBhcmVudCwgY29tcG9uZW50VHlwZSwgc3VwcHJlc3NGYWxsYmFja01ldGhvZHMpO1xuICB9XG59O1xudmFyIERldGFpbENlbGxSZW5kZXJlciA9IGZvcndhcmRSZWYzKChwcm9wcywgcmVmKSA9PiB7XG4gIGNvbnN0IGJlYW5zID0gdXNlQ29udGV4dDE1KEJlYW5zQ29udGV4dCk7XG4gIGNvbnN0IHsgcmVnaXN0cnksIGNvbnRleHQsIGdvcywgcm93TW9kZWwgfSA9IGJlYW5zO1xuICBjb25zdCBbY3NzQ2xhc3Nlcywgc2V0Q3NzQ2xhc3Nlc10gPSB1c2VTdGF0ZTE2KCgpID0+IG5ldyBDc3NDbGFzc2VzKCkpO1xuICBjb25zdCBbZ3JpZENzc0NsYXNzZXMsIHNldEdyaWRDc3NDbGFzc2VzXSA9IHVzZVN0YXRlMTYoKCkgPT4gbmV3IENzc0NsYXNzZXMoKSk7XG4gIGNvbnN0IFtkZXRhaWxHcmlkT3B0aW9ucywgc2V0RGV0YWlsR3JpZE9wdGlvbnNdID0gdXNlU3RhdGUxNigpO1xuICBjb25zdCBbZGV0YWlsUm93RGF0YSwgc2V0RGV0YWlsUm93RGF0YV0gPSB1c2VTdGF0ZTE2KCk7XG4gIGNvbnN0IGN0cmxSZWYgPSB1c2VSZWYxNigpO1xuICBjb25zdCBlR3VpUmVmID0gdXNlUmVmMTYobnVsbCk7XG4gIGNvbnN0IHJlc2l6ZU9ic2VydmVyRGVzdHJveUZ1bmMgPSB1c2VSZWYxNigpO1xuICBjb25zdCBwYXJlbnRNb2R1bGVzID0gdXNlTWVtbzEzKFxuICAgICgpID0+IF9nZXRHcmlkUmVnaXN0ZXJlZE1vZHVsZXMocHJvcHMuYXBpLmdldEdyaWRJZCgpLCBkZXRhaWxHcmlkT3B0aW9ucz8ucm93TW9kZWxUeXBlID8/IFwiY2xpZW50U2lkZVwiKSxcbiAgICBbcHJvcHNdXG4gICk7XG4gIGNvbnN0IHRvcENsYXNzTmFtZSA9IHVzZU1lbW8xMygoKSA9PiBjc3NDbGFzc2VzLnRvU3RyaW5nKCkgKyBcIiBhZy1kZXRhaWxzLXJvd1wiLCBbY3NzQ2xhc3Nlc10pO1xuICBjb25zdCBncmlkQ2xhc3NOYW1lID0gdXNlTWVtbzEzKCgpID0+IGdyaWRDc3NDbGFzc2VzLnRvU3RyaW5nKCkgKyBcIiBhZy1kZXRhaWxzLWdyaWRcIiwgW2dyaWRDc3NDbGFzc2VzXSk7XG4gIGlmIChyZWYpIHtcbiAgICB1c2VJbXBlcmF0aXZlSGFuZGxlMyhyZWYsICgpID0+ICh7XG4gICAgICByZWZyZXNoKCkge1xuICAgICAgICByZXR1cm4gY3RybFJlZi5jdXJyZW50Py5yZWZyZXNoKCkgPz8gZmFsc2U7XG4gICAgICB9XG4gICAgfSkpO1xuICB9XG4gIGlmIChwcm9wcy50ZW1wbGF0ZSkge1xuICAgIF93YXJuMigyMzApO1xuICB9XG4gIGNvbnN0IHNldFJlZjIgPSB1c2VDYWxsYmFjazE1KChlUmVmKSA9PiB7XG4gICAgZUd1aVJlZi5jdXJyZW50ID0gZVJlZjtcbiAgICBpZiAoIWVSZWYgfHwgY29udGV4dC5pc0Rlc3Ryb3llZCgpKSB7XG4gICAgICBjdHJsUmVmLmN1cnJlbnQgPSBjb250ZXh0LmRlc3Ryb3lCZWFuKGN0cmxSZWYuY3VycmVudCk7XG4gICAgICByZXNpemVPYnNlcnZlckRlc3Ryb3lGdW5jLmN1cnJlbnQ/LigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb21wUHJveHkgPSB7XG4gICAgICB0b2dnbGVDc3M6IChuYW1lLCBvbikgPT4gc2V0Q3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhuYW1lLCBvbikpLFxuICAgICAgdG9nZ2xlRGV0YWlsR3JpZENzczogKG5hbWUsIG9uKSA9PiBzZXRHcmlkQ3NzQ2xhc3NlcygocHJldikgPT4gcHJldi5zZXRDbGFzcyhuYW1lLCBvbikpLFxuICAgICAgc2V0RGV0YWlsR3JpZDogKGdyaWRPcHRpb25zKSA9PiBzZXREZXRhaWxHcmlkT3B0aW9ucyhncmlkT3B0aW9ucyksXG4gICAgICBzZXRSb3dEYXRhOiAocm93RGF0YSkgPT4gc2V0RGV0YWlsUm93RGF0YShyb3dEYXRhKSxcbiAgICAgIGdldEd1aTogKCkgPT4gZUd1aVJlZi5jdXJyZW50XG4gICAgfTtcbiAgICBjb25zdCBjdHJsID0gcmVnaXN0cnkuY3JlYXRlRHluYW1pY0JlYW4oXCJkZXRhaWxDZWxsUmVuZGVyZXJDdHJsXCIsIHRydWUpO1xuICAgIGlmICghY3RybCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb250ZXh0LmNyZWF0ZUJlYW4oY3RybCk7XG4gICAgY3RybC5pbml0KGNvbXBQcm94eSwgcHJvcHMpO1xuICAgIGN0cmxSZWYuY3VycmVudCA9IGN0cmw7XG4gICAgaWYgKGdvcy5nZXQoXCJkZXRhaWxSb3dBdXRvSGVpZ2h0XCIpKSB7XG4gICAgICBjb25zdCBjaGVja1Jvd1NpemVGdW5jID0gKCkgPT4ge1xuICAgICAgICBpZiAoZUd1aVJlZi5jdXJyZW50ID09IG51bGwpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2xpZW50SGVpZ2h0ID0gZUd1aVJlZi5jdXJyZW50LmNsaWVudEhlaWdodDtcbiAgICAgICAgaWYgKGNsaWVudEhlaWdodCAhPSBudWxsICYmIGNsaWVudEhlaWdodCA+IDApIHtcbiAgICAgICAgICBjb25zdCB1cGRhdGVSb3dIZWlnaHRGdW5jID0gKCkgPT4ge1xuICAgICAgICAgICAgcHJvcHMubm9kZS5zZXRSb3dIZWlnaHQoY2xpZW50SGVpZ2h0KTtcbiAgICAgICAgICAgIGlmIChfaXNDbGllbnRTaWRlUm93TW9kZWwoZ29zLCByb3dNb2RlbCkgfHwgX2lzU2VydmVyU2lkZVJvd01vZGVsKGdvcywgcm93TW9kZWwpKSB7XG4gICAgICAgICAgICAgIHJvd01vZGVsLm9uUm93SGVpZ2h0Q2hhbmdlZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgc2V0VGltZW91dCh1cGRhdGVSb3dIZWlnaHRGdW5jLCAwKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHJlc2l6ZU9ic2VydmVyRGVzdHJveUZ1bmMuY3VycmVudCA9IF9vYnNlcnZlUmVzaXplMihiZWFucywgZVJlZiwgY2hlY2tSb3dTaXplRnVuYyk7XG4gICAgICBjaGVja1Jvd1NpemVGdW5jKCk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGNvbnN0IHJlZ2lzdGVyR3JpZEFwaSA9IHVzZUNhbGxiYWNrMTUoKGFwaSkgPT4ge1xuICAgIGN0cmxSZWYuY3VycmVudD8ucmVnaXN0ZXJEZXRhaWxXaXRoTWFzdGVyKGFwaSk7XG4gIH0sIFtdKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE5LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgeyBjbGFzc05hbWU6IHRvcENsYXNzTmFtZSwgcmVmOiBzZXRSZWYyIH0sIGRldGFpbEdyaWRPcHRpb25zICYmIC8qIEBfX1BVUkVfXyAqLyBSZWFjdDE5LmNyZWF0ZUVsZW1lbnQoXG4gICAgQWdHcmlkUmVhY3RVaSxcbiAgICB7XG4gICAgICBjbGFzc05hbWU6IGdyaWRDbGFzc05hbWUsXG4gICAgICAuLi5kZXRhaWxHcmlkT3B0aW9ucyxcbiAgICAgIG1vZHVsZXM6IHBhcmVudE1vZHVsZXMsXG4gICAgICByb3dEYXRhOiBkZXRhaWxSb3dEYXRhLFxuICAgICAgcGFzc0dyaWRBcGk6IHJlZ2lzdGVyR3JpZEFwaVxuICAgIH1cbiAgKSk7XG59KTtcbnZhciBSZWFjdEZyYW1ld29ya092ZXJyaWRlcyA9IGNsYXNzIGV4dGVuZHMgVmFuaWxsYUZyYW1ld29ya092ZXJyaWRlcyB7XG4gIGNvbnN0cnVjdG9yKHByb2Nlc3NRdWV1ZWRVcGRhdGVzKSB7XG4gICAgc3VwZXIoXCJyZWFjdFwiKTtcbiAgICB0aGlzLnByb2Nlc3NRdWV1ZWRVcGRhdGVzID0gcHJvY2Vzc1F1ZXVlZFVwZGF0ZXM7XG4gICAgdGhpcy5xdWV1ZVVwZGF0ZXMgPSBmYWxzZTtcbiAgICB0aGlzLnJlbmRlcmluZ0VuZ2luZSA9IFwicmVhY3RcIjtcbiAgICB0aGlzLmZyYW1ld29ya0NvbXBvbmVudHMgPSB7XG4gICAgICBhZ0dyb3VwQ2VsbFJlbmRlcmVyOiBncm91cENlbGxSZW5kZXJlcl9kZWZhdWx0LFxuICAgICAgYWdHcm91cFJvd1JlbmRlcmVyOiBncm91cENlbGxSZW5kZXJlcl9kZWZhdWx0LFxuICAgICAgYWdEZXRhaWxDZWxsUmVuZGVyZXI6IERldGFpbENlbGxSZW5kZXJlclxuICAgIH07XG4gICAgdGhpcy53cmFwSW5jb21pbmcgPSAoY2FsbGJhY2ssIHNvdXJjZSkgPT4ge1xuICAgICAgaWYgKHNvdXJjZSA9PT0gXCJlbnN1cmVWaXNpYmxlXCIpIHtcbiAgICAgICAgcmV0dXJuIHJ1bldpdGhvdXRGbHVzaFN5bmMoY2FsbGJhY2spO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNhbGxiYWNrKCk7XG4gICAgfTtcbiAgfVxuICBmcmFtZXdvcmtDb21wb25lbnQobmFtZSkge1xuICAgIHJldHVybiB0aGlzLmZyYW1ld29ya0NvbXBvbmVudHNbbmFtZV07XG4gIH1cbiAgaXNGcmFtZXdvcmtDb21wb25lbnQoY29tcCkge1xuICAgIGlmICghY29tcCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBwcm90b3R5cGUgPSBjb21wLnByb3RvdHlwZTtcbiAgICBjb25zdCBpc0pzQ29tcCA9IHByb3RvdHlwZSAmJiBcImdldEd1aVwiIGluIHByb3RvdHlwZTtcbiAgICByZXR1cm4gIWlzSnNDb21wO1xuICB9XG4gIGdldExvY2tPblJlZnJlc2goKSB7XG4gICAgdGhpcy5xdWV1ZVVwZGF0ZXMgPSB0cnVlO1xuICB9XG4gIHJlbGVhc2VMb2NrT25SZWZyZXNoKCkge1xuICAgIHRoaXMucXVldWVVcGRhdGVzID0gZmFsc2U7XG4gICAgdGhpcy5wcm9jZXNzUXVldWVkVXBkYXRlcygpO1xuICB9XG4gIHNob3VsZFF1ZXVlVXBkYXRlcygpIHtcbiAgICByZXR1cm4gdGhpcy5xdWV1ZVVwZGF0ZXM7XG4gIH1cbiAgcnVuV2hlblJlYWR5QXN5bmMoKSB7XG4gICAgcmV0dXJuIGlzUmVhY3QxOSgpO1xuICB9XG59O1xuXG4vLyBwYWNrYWdlcy9hZy1ncmlkLXJlYWN0L3NyYy9hZ0dyaWRSZWFjdC50c3hcbnZhciBBZ0dyaWRSZWFjdCA9IGNsYXNzIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICB0aGlzLmFwaUxpc3RlbmVycyA9IFtdO1xuICAgIHRoaXMuc2V0R3JpZEFwaSA9IChhcGkpID0+IHtcbiAgICAgIHRoaXMuYXBpID0gYXBpO1xuICAgICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiB0aGlzLmFwaUxpc3RlbmVycykge1xuICAgICAgICBsaXN0ZW5lcihhcGkpO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgcmVnaXN0ZXJBcGlMaXN0ZW5lcihsaXN0ZW5lcikge1xuICAgIHRoaXMuYXBpTGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICB9XG4gIGNvbXBvbmVudFdpbGxVbm1vdW50KCkge1xuICAgIHRoaXMuYXBpTGlzdGVuZXJzLmxlbmd0aCA9IDA7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3QyMC5jcmVhdGVFbGVtZW50KEFnR3JpZFJlYWN0VWksIHsgLi4udGhpcy5wcm9wcywgcGFzc0dyaWRBcGk6IHRoaXMuc2V0R3JpZEFwaSB9KTtcbiAgfVxufTtcblxuLy8gcGFja2FnZXMvYWctZ3JpZC1yZWFjdC9zcmMvc2hhcmVkL2N1c3RvbUNvbXAvaW50ZXJmYWNlcy50c1xuaW1wb3J0IHsgdXNlQ29udGV4dCBhcyB1c2VDb250ZXh0MTYgfSBmcm9tIFwicmVhY3RcIjtcbmZ1bmN0aW9uIHVzZUdyaWRDdXN0b21Db21wb25lbnQobWV0aG9kcykge1xuICBjb25zdCB7IHNldE1ldGhvZHMgfSA9IHVzZUNvbnRleHQxNihDdXN0b21Db250ZXh0KTtcbiAgc2V0TWV0aG9kcyhtZXRob2RzKTtcbn1cbmZ1bmN0aW9uIHVzZUdyaWRDZWxsRWRpdG9yKGNhbGxiYWNrcykge1xuICB1c2VHcmlkQ3VzdG9tQ29tcG9uZW50KGNhbGxiYWNrcyk7XG59XG5mdW5jdGlvbiB1c2VHcmlkRGF0ZShjYWxsYmFja3MpIHtcbiAgcmV0dXJuIHVzZUdyaWRDdXN0b21Db21wb25lbnQoY2FsbGJhY2tzKTtcbn1cbmZ1bmN0aW9uIHVzZUdyaWRGaWx0ZXIoY2FsbGJhY2tzKSB7XG4gIHJldHVybiB1c2VHcmlkQ3VzdG9tQ29tcG9uZW50KGNhbGxiYWNrcyk7XG59XG5mdW5jdGlvbiB1c2VHcmlkRmlsdGVyRGlzcGxheShjYWxsYmFja3MpIHtcbiAgcmV0dXJuIHVzZUdyaWRDdXN0b21Db21wb25lbnQoY2FsbGJhY2tzKTtcbn1cbmZ1bmN0aW9uIHVzZUdyaWRGbG9hdGluZ0ZpbHRlcihjYWxsYmFja3MpIHtcbiAgdXNlR3JpZEN1c3RvbUNvbXBvbmVudChjYWxsYmFja3MpO1xufVxuZnVuY3Rpb24gdXNlR3JpZE1lbnVJdGVtKGNhbGxiYWNrcykge1xuICB1c2VHcmlkQ3VzdG9tQ29tcG9uZW50KGNhbGxiYWNrcyk7XG59XG5leHBvcnQge1xuICBBZ0dyaWRSZWFjdCxcbiAgQ3VzdG9tQ29udGV4dCBhcyBDdXN0b21Db21wb25lbnRDb250ZXh0LFxuICBnZXRJbnN0YW5jZSxcbiAgdXNlR3JpZENlbGxFZGl0b3IsXG4gIHVzZUdyaWREYXRlLFxuICB1c2VHcmlkRmlsdGVyLFxuICB1c2VHcmlkRmlsdGVyRGlzcGxheSxcbiAgdXNlR3JpZEZsb2F0aW5nRmlsdGVyLFxuICB1c2VHcmlkTWVudUl0ZW0sXG4gIHdhcm5SZWFjdGl2ZUN1c3RvbUNvbXBvbmVudHNcbn07XG4iLCJmdW5jdGlvbiBfdHlwZW9mKG8pIHtcbiAgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiO1xuXG4gIHJldHVybiBtb2R1bGUuZXhwb3J0cyA9IF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykge1xuICAgIHJldHVybiB0eXBlb2YgbztcbiAgfSA6IGZ1bmN0aW9uIChvKSB7XG4gICAgcmV0dXJuIG8gJiYgXCJmdW5jdGlvblwiID09IHR5cGVvZiBTeW1ib2wgJiYgby5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG8gIT09IFN5bWJvbC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG87XG4gIH0sIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0cywgX3R5cGVvZihvKTtcbn1cbm1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyIsInZhciBfdHlwZW9mID0gcmVxdWlyZShcIi4vdHlwZW9mLmpzXCIpW1wiZGVmYXVsdFwiXTtcbnZhciB0b1ByaW1pdGl2ZSA9IHJlcXVpcmUoXCIuL3RvUHJpbWl0aXZlLmpzXCIpO1xuZnVuY3Rpb24gdG9Qcm9wZXJ0eUtleSh0KSB7XG4gIHZhciBpID0gdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7XG4gIHJldHVybiBcInN5bWJvbFwiID09IF90eXBlb2YoaSkgPyBpIDogaSArIFwiXCI7XG59XG5tb2R1bGUuZXhwb3J0cyA9IHRvUHJvcGVydHlLZXksIG1vZHVsZS5leHBvcnRzLl9fZXNNb2R1bGUgPSB0cnVlLCBtb2R1bGUuZXhwb3J0c1tcImRlZmF1bHRcIl0gPSBtb2R1bGUuZXhwb3J0czsiLCJ2YXIgX3R5cGVvZiA9IHJlcXVpcmUoXCIuL3R5cGVvZi5qc1wiKVtcImRlZmF1bHRcIl07XG5mdW5jdGlvbiB0b1ByaW1pdGl2ZSh0LCByKSB7XG4gIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YodCkgfHwgIXQpIHJldHVybiB0O1xuICB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTtcbiAgaWYgKHZvaWQgMCAhPT0gZSkge1xuICAgIHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpO1xuICAgIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YoaSkpIHJldHVybiBpO1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTtcbiAgfVxuICByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpO1xufVxubW9kdWxlLmV4cG9ydHMgPSB0b1ByaW1pdGl2ZSwgbW9kdWxlLmV4cG9ydHMuX19lc01vZHVsZSA9IHRydWUsIG1vZHVsZS5leHBvcnRzW1wiZGVmYXVsdFwiXSA9IG1vZHVsZS5leHBvcnRzOyJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==